#### John 1:1  In the beginning was the Word, and the Word was with God, and the Word was God.
#### John 1:2  He was in the beginning with God.
#### John 1:3  All things were made through him, and without him was not any thing made that was made.
#### John 1:4  In him was life, and the life was the light of men.
#### John 1:5  The light shines in the darkness, and the darkness has not overcome it.
#### John 1:6  There was a man sent from God, whose name was John.
#### John 1:7  He came as a witness, to bear witness about the light, that all might believe through him.
#### John 1:8  He was not the light, but came to bear witness about the light.
#### John 1:9  The true light, which gives light to everyone, was coming into the world.
#### John 1:10  He was in the world, and the world was made through him, yet the world did not know him.
#### John 1:11  He came to his own, and his own people did not receive him.
#### John 1:12  But to all who did receive him, who believed in his name, he gave the right to become children of God,
#### John 1:13  who were born, not of blood nor of the will of the flesh nor of the will of man, but of God.
#### John 1:14  And the Word became flesh and dwelt among us, and we have seen his glory, glory as of the only Son from the Father, full of grace and truth.
#### John 1:15  (John bore witness about him, and cried out, “This was he of whom I said, ‘He who comes after me ranks before me, because he was before me.’”)
#### John 1:16  For from his fullness we have all received, grace upon grace.
#### John 1:17  For the law was given through Moses; grace and truth came through Jesus Christ.
#### John 1:18  No one has ever seen God; the only God, who is at the Father's side, he has made him known.
#### John 1:19  And this is the testimony of John, when the Jews sent priests and Levites from Jerusalem to ask him, “Who are you?”
#### John 1:20  He confessed, and did not deny, but confessed, “I am not the Christ.”
#### John 1:21  And they asked him, “What then? Are you Elijah?” He said, “I am not.” “Are you the Prophet?” And he answered, “No.”
#### John 1:22  So they said to him, “Who are you? We need to give an answer to those who sent us. What do you say about yourself?”
#### John 1:23  He said, “I am the voice of one crying out in the wilderness, ‘Make straight the way of the Lord,’ as the prophet Isaiah said.”
#### John 1:24  (Now they had been sent from the Pharisees.)
#### John 1:25  They asked him, “Then why are you baptizing, if you are neither the Christ, nor Elijah, nor the Prophet?”
#### John 1:26  John answered them, “I baptize with water, but among you stands one you do not know,
#### John 1:27  even he who comes after me, the strap of whose sandal I am not worthy to untie.”
#### John 1:28  These things took place in Bethany across the Jordan, where John was baptizing.
#### John 1:29  The next day he saw Jesus coming toward him, and said, “Behold, the Lamb of God, who takes away the sin of the world!
#### John 1:30  This is he of whom I said, ‘After me comes a man who ranks before me, because he was before me.’
#### John 1:31  I myself did not know him, but for this purpose I came baptizing with water, that he might be revealed to Israel.”
#### John 1:32  And John bore witness: “I saw the Spirit descend from heaven like a dove, and it remained on him.
#### John 1:33  I myself did not know him, but he who sent me to baptize with water said to me, ‘He on whom you see the Spirit descend and remain, this is he who baptizes with the Holy Spirit.’
#### John 1:34  And I have seen and have borne witness that this is the Son of God.”
#### John 1:35  The next day again John was standing with two of his disciples,
#### John 1:36  and he looked at Jesus as he walked by and said, “Behold, the Lamb of God!”
#### John 1:37  The two disciples heard him say this, and they followed Jesus.
#### John 1:38  Jesus turned and saw them following and said to them, “What are you seeking?” And they said to him, “Rabbi” (which means Teacher), “where are you staying?”
#### John 1:39  He said to them, “Come and you will see.” So they came and saw where he was staying, and they stayed with him that day, for it was about the tenth hour.
#### John 1:40  One of the two who heard John speak and followed Jesus was Andrew, Simon Peter's brother.
#### John 1:41  He first found his own brother Simon and said to him, “We have found the Messiah” (which means Christ).
#### John 1:42  He brought him to Jesus. Jesus looked at him and said, “You are Simon the son of John. You shall be called Cephas” (which means Peter).
#### John 1:43  The next day Jesus decided to go to Galilee. He found Philip and said to him, “Follow me.”
#### John 1:44  Now Philip was from Bethsaida, the city of Andrew and Peter.
#### John 1:45  Philip found Nathanael and said to him, “We have found him of whom Moses in the Law and also the prophets wrote, Jesus of Nazareth, the son of Joseph.”
#### John 1:46  Nathanael said to him, “Can anything good come out of Nazareth?” Philip said to him, “Come and see.”
#### John 1:47  Jesus saw Nathanael coming toward him and said of him, “Behold, an Israelite indeed, in whom there is no deceit!”
#### John 1:48  Nathanael said to him, “How do you know me?” Jesus answered him, “Before Philip called you, when you were under the fig tree, I saw you.”
#### John 1:49  Nathanael answered him, “Rabbi, you are the Son of God! You are the King of Israel!”
#### John 1:50  Jesus answered him, “Because I said to you, ‘I saw you under the fig tree,’ do you believe? You will see greater things than these.”
#### John 1:51  And he said to him, “Truly, truly, I say to you, you will see heaven opened, and the angels of God ascending and descending on the Son of Man.”
#### John 2:1  On the third day there was a wedding at Cana in Galilee, and the mother of Jesus was there.
#### John 2:2  Jesus also was invited to the wedding with his disciples.
#### John 2:3  When the wine ran out, the mother of Jesus said to him, “They have no wine.”
#### John 2:4  And Jesus said to her, “Woman, what does this have to do with me? My hour has not yet come.”
#### John 2:5  His mother said to the servants, “Do whatever he tells you.”
#### John 2:6  Now there were six stone water jars there for the Jewish rites of purification, each holding twenty or thirty gallons.
#### John 2:7  Jesus said to the servants, “Fill the jars with water.” And they filled them up to the brim.
#### John 2:8  And he said to them, “Now draw some out and take it to the master of the feast.” So they took it.
#### John 2:9  When the master of the feast tasted the water now become wine, and did not know where it came from (though the servants who had drawn the water knew), the master of the feast called the bridegroom
#### John 2:10  and said to him, “Everyone serves the good wine first, and when people have drunk freely, then the poor wine. But you have kept the good wine until now.”
#### John 2:11  This, the first of his signs, Jesus did at Cana in Galilee, and manifested his glory. And his disciples believed in him.
#### John 2:12  After this he went down to Capernaum, with his mother and his brothers and his disciples, and they stayed there for a few days.
#### John 2:13  The Passover of the Jews was at hand, and Jesus went up to Jerusalem.
#### John 2:14  In the temple he found those who were selling oxen and sheep and pigeons, and the money-changers sitting there.
#### John 2:15  And making a whip of cords, he drove them all out of the temple, with the sheep and oxen. And he poured out the coins of the money-changers and overturned their tables.
#### John 2:16  And he told those who sold the pigeons, “Take these things away; do not make my Father's house a house of trade.”
#### John 2:17  His disciples remembered that it was written, “Zeal for your house will consume me.”
#### John 2:18  So the Jews said to him, “What sign do you show us for doing these things?”
#### John 2:19  Jesus answered them, “Destroy this temple, and in three days I will raise it up.”
#### John 2:20  The Jews then said, “It has taken forty-six years to build this temple, and will you raise it up in three days?”
#### John 2:21  But he was speaking about the temple of his body.
#### John 2:22  When therefore he was raised from the dead, his disciples remembered that he had said this, and they believed the Scripture and the word that Jesus had spoken.
#### John 2:23  Now when he was in Jerusalem at the Passover Feast, many believed in his name when they saw the signs that he was doing.
#### John 2:24  But Jesus on his part did not entrust himself to them, because he knew all people
#### John 2:25  and needed no one to bear witness about man, for he himself knew what was in man.
#### John 3:1  Now there was a man of the Pharisees named Nicodemus, a ruler of the Jews.
#### John 3:2  This man came to Jesus by night and said to him, “Rabbi, we know that you are a teacher come from God, for no one can do these signs that you do unless God is with him.”
#### John 3:3  Jesus answered him, “Truly, truly, I say to you, unless one is born again he cannot see the kingdom of God.”
#### John 3:4  Nicodemus said to him, “How can a man be born when he is old? Can he enter a second time into his mother's womb and be born?”
#### John 3:5  Jesus answered, “Truly, truly, I say to you, unless one is born of water and the Spirit, he cannot enter the kingdom of God.
#### John 3:6  That which is born of the flesh is flesh, and that which is born of the Spirit is spirit.
#### John 3:7  Do not marvel that I said to you, ‘You must be born again.’
#### John 3:8  The wind blows where it wishes, and you hear its sound, but you do not know where it comes from or where it goes. So it is with everyone who is born of the Spirit.”
#### John 3:9  Nicodemus said to him, “How can these things be?”
#### John 3:10  Jesus answered him, “Are you the teacher of Israel and yet you do not understand these things?
#### John 3:11  Truly, truly, I say to you, we speak of what we know, and bear witness to what we have seen, but you do not receive our testimony.
#### John 3:12  If I have told you earthly things and you do not believe, how can you believe if I tell you heavenly things?
#### John 3:13  No one has ascended into heaven except he who descended from heaven, the Son of Man.
#### John 3:14  And as Moses lifted up the serpent in the wilderness, so must the Son of Man be lifted up,
#### John 3:15  that whoever believes in him may have eternal life.
#### John 3:16  “For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life.
#### John 3:17  For God did not send his Son into the world to condemn the world, but in order that the world might be saved through him.
#### John 3:18  Whoever believes in him is not condemned, but whoever does not believe is condemned already, because he has not believed in the name of the only Son of God.
#### John 3:19  And this is the judgment: the light has come into the world, and people loved the darkness rather than the light because their works were evil.
#### John 3:20  For everyone who does wicked things hates the light and does not come to the light, lest his works should be exposed.
#### John 3:21  But whoever does what is true comes to the light, so that it may be clearly seen that his works have been carried out in God.”
#### John 3:22  After this Jesus and his disciples went into the Judean countryside, and he remained there with them and was baptizing.
#### John 3:23  John also was baptizing at Aenon near Salim, because water was plentiful there, and people were coming and being baptized
#### John 3:24  (for John had not yet been put in prison).
#### John 3:25  Now a discussion arose between some of John's disciples and a Jew over purification.
#### John 3:26  And they came to John and said to him, “Rabbi, he who was with you across the Jordan, to whom you bore witness—look, he is baptizing, and all are going to him.”
#### John 3:27  John answered, “A person cannot receive even one thing unless it is given him from heaven.
#### John 3:28  You yourselves bear me witness, that I said, ‘I am not the Christ, but I have been sent before him.’
#### John 3:29  The one who has the bride is the bridegroom. The friend of the bridegroom, who stands and hears him, rejoices greatly at the bridegroom's voice. Therefore this joy of mine is now complete.
#### John 3:30  He must increase, but I must decrease.”
#### John 3:31  He who comes from above is above all. He who is of the earth belongs to the earth and speaks in an earthly way. He who comes from heaven is above all.
#### John 3:32  He bears witness to what he has seen and heard, yet no one receives his testimony.
#### John 3:33  Whoever receives his testimony sets his seal to this, that God is true.
#### John 3:34  For he whom God has sent utters the words of God, for he gives the Spirit without measure.
#### John 3:35  The Father loves the Son and has given all things into his hand.
#### John 3:36  Whoever believes in the Son has eternal life; whoever does not obey the Son shall not see life, but the wrath of God remains on him.
#### John 4:1  Now when Jesus learned that the Pharisees had heard that Jesus was making and baptizing more disciples than John
#### John 4:2  (although Jesus himself did not baptize, but only his disciples),
#### John 4:3  he left Judea and departed again for Galilee.
#### John 4:4  And he had to pass through Samaria.
#### John 4:5  So he came to a town of Samaria called Sychar, near the field that Jacob had given to his son Joseph.
#### John 4:6  Jacob's well was there; so Jesus, wearied as he was from his journey, was sitting beside the well. It was about the sixth hour.
#### John 4:7  A woman from Samaria came to draw water. Jesus said to her, “Give me a drink.”
#### John 4:8  (For his disciples had gone away into the city to buy food.)
#### John 4:9  The Samaritan woman said to him, “How is it that you, a Jew, ask for a drink from me, a woman of Samaria?” (For Jews have no dealings with Samaritans.)
#### John 4:10  Jesus answered her, “If you knew the gift of God, and who it is that is saying to you, ‘Give me a drink,’ you would have asked him, and he would have given you living water.”
#### John 4:11  The woman said to him, “Sir, you have nothing to draw water with, and the well is deep. Where do you get that living water?
#### John 4:12  Are you greater than our father Jacob? He gave us the well and drank from it himself, as did his sons and his livestock.”
#### John 4:13  Jesus said to her, “Everyone who drinks of this water will be thirsty again,
#### John 4:14  but whoever drinks of the water that I will give him will never be thirsty again. The water that I will give him will become in him a spring of water welling up to eternal life.”
#### John 4:15  The woman said to him, “Sir, give me this water, so that I will not be thirsty or have to come here to draw water.”
#### John 4:16  Jesus said to her, “Go, call your husband, and come here.”
#### John 4:17  The woman answered him, “I have no husband.” Jesus said to her, “You are right in saying, ‘I have no husband’;
#### John 4:18  for you have had five husbands, and the one you now have is not your husband. What you have said is true.”
#### John 4:19  The woman said to him, “Sir, I perceive that you are a prophet.
#### John 4:20  Our fathers worshiped on this mountain, but you say that in Jerusalem is the place where people ought to worship.”
#### John 4:21  Jesus said to her, “Woman, believe me, the hour is coming when neither on this mountain nor in Jerusalem will you worship the Father.
#### John 4:22  You worship what you do not know; we worship what we know, for salvation is from the Jews.
#### John 4:23  But the hour is coming, and is now here, when the true worshipers will worship the Father in spirit and truth, for the Father is seeking such people to worship him.
#### John 4:24  God is spirit, and those who worship him must worship in spirit and truth.”
#### John 4:25  The woman said to him, “I know that Messiah is coming (he who is called Christ). When he comes, he will tell us all things.”
#### John 4:26  Jesus said to her, “I who speak to you am he.”
#### John 4:27  Just then his disciples came back. They marveled that he was talking with a woman, but no one said, “What do you seek?” or, “Why are you talking with her?”
#### John 4:28  So the woman left her water jar and went away into town and said to the people,
#### John 4:29  “Come, see a man who told me all that I ever did. Can this be the Christ?”
#### John 4:30  They went out of the town and were coming to him.
#### John 4:31  Meanwhile the disciples were urging him, saying, “Rabbi, eat.”
#### John 4:32  But he said to them, “I have food to eat that you do not know about.”
#### John 4:33  So the disciples said to one another, “Has anyone brought him something to eat?”
#### John 4:34  Jesus said to them, “My food is to do the will of him who sent me and to accomplish his work.
#### John 4:35  Do you not say, ‘There are yet four months, then comes the harvest’? Look, I tell you, lift up your eyes, and see that the fields are white for harvest.
#### John 4:36  Already the one who reaps is receiving wages and gathering fruit for eternal life, so that sower and reaper may rejoice together.
#### John 4:37  For here the saying holds true, ‘One sows and another reaps.’
#### John 4:38  I sent you to reap that for which you did not labor. Others have labored, and you have entered into their labor.”
#### John 4:39  Many Samaritans from that town believed in him because of the woman's testimony, “He told me all that I ever did.”
#### John 4:40  So when the Samaritans came to him, they asked him to stay with them, and he stayed there two days.
#### John 4:41  And many more believed because of his word.
#### John 4:42  They said to the woman, “It is no longer because of what you said that we believe, for we have heard for ourselves, and we know that this is indeed the Savior of the world.”
#### John 4:43  After the two days he departed for Galilee.
#### John 4:44  (For Jesus himself had testified that a prophet has no honor in his own hometown.)
#### John 4:45  So when he came to Galilee, the Galileans welcomed him, having seen all that he had done in Jerusalem at the feast. For they too had gone to the feast.
#### John 4:46  So he came again to Cana in Galilee, where he had made the water wine. And at Capernaum there was an official whose son was ill.
#### John 4:47  When this man heard that Jesus had come from Judea to Galilee, he went to him and asked him to come down and heal his son, for he was at the point of death.
#### John 4:48  So Jesus said to him, “Unless you see signs and wonders you will not believe.”
#### John 4:49  The official said to him, “Sir, come down before my child dies.”
#### John 4:50  Jesus said to him, “Go; your son will live.” The man believed the word that Jesus spoke to him and went on his way.
#### John 4:51  As he was going down, his servants met him and told him that his son was recovering.
#### John 4:52  So he asked them the hour when he began to get better, and they said to him, “Yesterday at the seventh hour the fever left him.”
#### John 4:53  The father knew that was the hour when Jesus had said to him, “Your son will live.” And he himself believed, and all his household.
#### John 4:54  This was now the second sign that Jesus did when he had come from Judea to Galilee.
#### John 5:1  After this there was a feast of the Jews, and Jesus went up to Jerusalem.
#### John 5:2  Now there is in Jerusalem by the Sheep Gate a pool, in Aramaic called Bethesda, which has five roofed colonnades.
#### John 5:3  In these lay a multitude of invalids—blind, lame, and paralyzed.
#### John 5:5  One man was there who had been an invalid for thirty-eight years.
#### John 5:6  When Jesus saw him lying there and knew that he had already been there a long time, he said to him, “Do you want to be healed?”
#### John 5:7  The sick man answered him, “Sir, I have no one to put me into the pool when the water is stirred up, and while I am going another steps down before me.”
#### John 5:8  Jesus said to him, “Get up, take up your bed, and walk.”
#### John 5:9  And at once the man was healed, and he took up his bed and walked. Now that day was the Sabbath.
#### John 5:10  So the Jews said to the man who had been healed, “It is the Sabbath, and it is not lawful for you to take up your bed.”
#### John 5:11  But he answered them, “The man who healed me, that man said to me, ‘Take up your bed, and walk.’”
#### John 5:12  They asked him, “Who is the man who said to you, ‘Take up your bed and walk’?”
#### John 5:13  Now the man who had been healed did not know who it was, for Jesus had withdrawn, as there was a crowd in the place.
#### John 5:14  Afterward Jesus found him in the temple and said to him, “See, you are well! Sin no more, that nothing worse may happen to you.”
#### John 5:15  The man went away and told the Jews that it was Jesus who had healed him.
#### John 5:16  And this was why the Jews were persecuting Jesus, because he was doing these things on the Sabbath.
#### John 5:17  But Jesus answered them, “My Father is working until now, and I am working.”
#### John 5:18  This was why the Jews were seeking all the more to kill him, because not only was he breaking the Sabbath, but he was even calling God his own Father, making himself equal with God.
#### John 5:19  So Jesus said to them, “Truly, truly, I say to you, the Son can do nothing of his own accord, but only what he sees the Father doing. For whatever the Father does, that the Son does likewise.
#### John 5:20  For the Father loves the Son and shows him all that he himself is doing. And greater works than these will he show him, so that you may marvel.
#### John 5:21  For as the Father raises the dead and gives them life, so also the Son gives life to whom he will.
#### John 5:22  For the Father judges no one, but has given all judgment to the Son,
#### John 5:23  that all may honor the Son, just as they honor the Father. Whoever does not honor the Son does not honor the Father who sent him.
#### John 5:24  Truly, truly, I say to you, whoever hears my word and believes him who sent me has eternal life. He does not come into judgment, but has passed from death to life.
#### John 5:25  “Truly, truly, I say to you, an hour is coming, and is now here, when the dead will hear the voice of the Son of God, and those who hear will live.
#### John 5:26  For as the Father has life in himself, so he has granted the Son also to have life in himself.
#### John 5:27  And he has given him authority to execute judgment, because he is the Son of Man.
#### John 5:28  Do not marvel at this, for an hour is coming when all who are in the tombs will hear his voice
#### John 5:29  and come out, those who have done good to the resurrection of life, and those who have done evil to the resurrection of judgment.
#### John 5:30  “I can do nothing on my own. As I hear, I judge, and my judgment is just, because I seek not my own will but the will of him who sent me.
#### John 5:31  If I alone bear witness about myself, my testimony is not true.
#### John 5:32  There is another who bears witness about me, and I know that the testimony that he bears about me is true.
#### John 5:33  You sent to John, and he has borne witness to the truth.
#### John 5:34  Not that the testimony that I receive is from man, but I say these things so that you may be saved.
#### John 5:35  He was a burning and shining lamp, and you were willing to rejoice for a while in his light.
#### John 5:36  But the testimony that I have is greater than that of John. For the works that the Father has given me to accomplish, the very works that I am doing, bear witness about me that the Father has sent me.
#### John 5:37  And the Father who sent me has himself borne witness about me. His voice you have never heard, his form you have never seen,
#### John 5:38  and you do not have his word abiding in you, for you do not believe the one whom he has sent.
#### John 5:39  You search the Scriptures because you think that in them you have eternal life; and it is they that bear witness about me,
#### John 5:40  yet you refuse to come to me that you may have life.
#### John 5:41  I do not receive glory from people.
#### John 5:42  But I know that you do not have the love of God within you.
#### John 5:43  I have come in my Father's name, and you do not receive me. If another comes in his own name, you will receive him.
#### John 5:44  How can you believe, when you receive glory from one another and do not seek the glory that comes from the only God?
#### John 5:45  Do not think that I will accuse you to the Father. There is one who accuses you: Moses, on whom you have set your hope.
#### John 5:46  For if you believed Moses, you would believe me; for he wrote of me.
#### John 5:47  But if you do not believe his writings, how will you believe my words?”
#### John 6:1  After this Jesus went away to the other side of the Sea of Galilee, which is the Sea of Tiberias.
#### John 6:2  And a large crowd was following him, because they saw the signs that he was doing on the sick.
#### John 6:3  Jesus went up on the mountain, and there he sat down with his disciples.
#### John 6:4  Now the Passover, the feast of the Jews, was at hand.
#### John 6:5  Lifting up his eyes, then, and seeing that a large crowd was coming toward him, Jesus said to Philip, “Where are we to buy bread, so that these people may eat?”
#### John 6:6  He said this to test him, for he himself knew what he would do.
#### John 6:7  Philip answered him, “Two hundred denarii worth of bread would not be enough for each of them to get a little.”
#### John 6:8  One of his disciples, Andrew, Simon Peter's brother, said to him,
#### John 6:9  “There is a boy here who has five barley loaves and two fish, but what are they for so many?”
#### John 6:10  Jesus said, “Have the people sit down.” Now there was much grass in the place. So the men sat down, about five thousand in number.
#### John 6:11  Jesus then took the loaves, and when he had given thanks, he distributed them to those who were seated. So also the fish, as much as they wanted.
#### John 6:12  And when they had eaten their fill, he told his disciples, “Gather up the leftover fragments, that nothing may be lost.”
#### John 6:13  So they gathered them up and filled twelve baskets with fragments from the five barley loaves left by those who had eaten.
#### John 6:14  When the people saw the sign that he had done, they said, “This is indeed the Prophet who is to come into the world!”
#### John 6:15  Perceiving then that they were about to come and take him by force to make him king, Jesus withdrew again to the mountain by himself.
#### John 6:16  When evening came, his disciples went down to the sea,
#### John 6:17  got into a boat, and started across the sea to Capernaum. It was now dark, and Jesus had not yet come to them.
#### John 6:18  The sea became rough because a strong wind was blowing.
#### John 6:19  When they had rowed about three or four miles, they saw Jesus walking on the sea and coming near the boat, and they were frightened.
#### John 6:20  But he said to them, “It is I; do not be afraid.”
#### John 6:21  Then they were glad to take him into the boat, and immediately the boat was at the land to which they were going.
#### John 6:22  On the next day the crowd that remained on the other side of the sea saw that there had been only one boat there, and that Jesus had not entered the boat with his disciples, but that his disciples had gone away alone.
#### John 6:23  Other boats from Tiberias came near the place where they had eaten the bread after the Lord had given thanks.
#### John 6:24  So when the crowd saw that Jesus was not there, nor his disciples, they themselves got into the boats and went to Capernaum, seeking Jesus.
#### John 6:25  When they found him on the other side of the sea, they said to him, “Rabbi, when did you come here?”
#### John 6:26  Jesus answered them, “Truly, truly, I say to you, you are seeking me, not because you saw signs, but because you ate your fill of the loaves.
#### John 6:27  Do not work for the food that perishes, but for the food that endures to eternal life, which the Son of Man will give to you. For on him God the Father has set his seal.”
#### John 6:28  Then they said to him, “What must we do, to be doing the works of God?”
#### John 6:29  Jesus answered them, “This is the work of God, that you believe in him whom he has sent.”
#### John 6:30  So they said to him, “Then what sign do you do, that we may see and believe you? What work do you perform?
#### John 6:31  Our fathers ate the manna in the wilderness; as it is written, ‘He gave them bread from heaven to eat.’”
#### John 6:32  Jesus then said to them, “Truly, truly, I say to you, it was not Moses who gave you the bread from heaven, but my Father gives you the true bread from heaven.
#### John 6:33  For the bread of God is he who comes down from heaven and gives life to the world.”
#### John 6:34  They said to him, “Sir, give us this bread always.”
#### John 6:35  Jesus said to them, “I am the bread of life; whoever comes to me shall not hunger, and whoever believes in me shall never thirst.
#### John 6:36  But I said to you that you have seen me and yet do not believe.
#### John 6:37  All that the Father gives me will come to me, and whoever comes to me I will never cast out.
#### John 6:38  For I have come down from heaven, not to do my own will but the will of him who sent me.
#### John 6:39  And this is the will of him who sent me, that I should lose nothing of all that he has given me, but raise it up on the last day.
#### John 6:40  For this is the will of my Father, that everyone who looks on the Son and believes in him should have eternal life, and I will raise him up on the last day.”
#### John 6:41  So the Jews grumbled about him, because he said, “I am the bread that came down from heaven.”
#### John 6:42  They said, “Is not this Jesus, the son of Joseph, whose father and mother we know? How does he now say, ‘I have come down from heaven’?”
#### John 6:43  Jesus answered them, “Do not grumble among yourselves.
#### John 6:44  No one can come to me unless the Father who sent me draws him. And I will raise him up on the last day.
#### John 6:45  It is written in the Prophets, ‘And they will all be taught by God.’ Everyone who has heard and learned from the Father comes to me—
#### John 6:46  not that anyone has seen the Father except he who is from God; he has seen the Father.
#### John 6:47  Truly, truly, I say to you, whoever believes has eternal life.
#### John 6:48  I am the bread of life.
#### John 6:49  Your fathers ate the manna in the wilderness, and they died.
#### John 6:50  This is the bread that comes down from heaven, so that one may eat of it and not die.
#### John 6:51  I am the living bread that came down from heaven. If anyone eats of this bread, he will live forever. And the bread that I will give for the life of the world is my flesh.”
#### John 6:52  The Jews then disputed among themselves, saying, “How can this man give us his flesh to eat?”
#### John 6:53  So Jesus said to them, “Truly, truly, I say to you, unless you eat the flesh of the Son of Man and drink his blood, you have no life in you.
#### John 6:54  Whoever feeds on my flesh and drinks my blood has eternal life, and I will raise him up on the last day.
#### John 6:55  For my flesh is true food, and my blood is true drink.
#### John 6:56  Whoever feeds on my flesh and drinks my blood abides in me, and I in him.
#### John 6:57  As the living Father sent me, and I live because of the Father, so whoever feeds on me, he also will live because of me.
#### John 6:58  This is the bread that came down from heaven, not like the bread the fathers ate, and died. Whoever feeds on this bread will live forever.”
#### John 6:59  Jesus said these things in the synagogue, as he taught at Capernaum.
#### John 6:60  When many of his disciples heard it, they said, “This is a hard saying; who can listen to it?”
#### John 6:61  But Jesus, knowing in himself that his disciples were grumbling about this, said to them, “Do you take offense at this?
#### John 6:62  Then what if you were to see the Son of Man ascending to where he was before?
#### John 6:63  It is the Spirit who gives life; the flesh is no help at all. The words that I have spoken to you are spirit and life.
#### John 6:64  But there are some of you who do not believe.” (For Jesus knew from the beginning who those were who did not believe, and who it was who would betray him.)
#### John 6:65  And he said, “This is why I told you that no one can come to me unless it is granted him by the Father.”
#### John 6:66  After this many of his disciples turned back and no longer walked with him.
#### John 6:67  So Jesus said to the twelve, “Do you want to go away as well?”
#### John 6:68  Simon Peter answered him, “Lord, to whom shall we go? You have the words of eternal life,
#### John 6:69  and we have believed, and have come to know, that you are the Holy One of God.”
#### John 6:70  Jesus answered them, “Did I not choose you, the twelve? And yet one of you is a devil.”
#### John 6:71  He spoke of Judas the son of Simon Iscariot, for he, one of the twelve, was going to betray him.
#### John 7:1  After this Jesus went about in Galilee. He would not go about in Judea, because the Jews were seeking to kill him.
#### John 7:2  Now the Jews' Feast of Booths was at hand.
#### John 7:3  So his brothers said to him, “Leave here and go to Judea, that your disciples also may see the works you are doing.
#### John 7:4  For no one works in secret if he seeks to be known openly. If you do these things, show yourself to the world.”
#### John 7:5  For not even his brothers believed in him.
#### John 7:6  Jesus said to them, “My time has not yet come, but your time is always here.
#### John 7:7  The world cannot hate you, but it hates me because I testify about it that its works are evil.
#### John 7:8  You go up to the feast. I am not going up to this feast, for my time has not yet fully come.”
#### John 7:9  After saying this, he remained in Galilee.
#### John 7:10  But after his brothers had gone up to the feast, then he also went up, not publicly but in private.
#### John 7:11  The Jews were looking for him at the feast, and saying, “Where is he?”
#### John 7:12  And there was much muttering about him among the people. While some said, “He is a good man,” others said, “No, he is leading the people astray.”
#### John 7:13  Yet for fear of the Jews no one spoke openly of him.
#### John 7:14  About the middle of the feast Jesus went up into the temple and began teaching.
#### John 7:15  The Jews therefore marveled, saying, “How is it that this man has learning, when he has never studied?”
#### John 7:16  So Jesus answered them, “My teaching is not mine, but his who sent me.
#### John 7:17  If anyone's will is to do God's will, he will know whether the teaching is from God or whether I am speaking on my own authority.
#### John 7:18  The one who speaks on his own authority seeks his own glory; but the one who seeks the glory of him who sent him is true, and in him there is no falsehood.
#### John 7:19  Has not Moses given you the law? Yet none of you keeps the law. Why do you seek to kill me?”
#### John 7:20  The crowd answered, “You have a demon! Who is seeking to kill you?”
#### John 7:21  Jesus answered them, “I did one work, and you all marvel at it.
#### John 7:22  Moses gave you circumcision (not that it is from Moses, but from the fathers), and you circumcise a man on the Sabbath.
#### John 7:23  If on the Sabbath a man receives circumcision, so that the law of Moses may not be broken, are you angry with me because on the Sabbath I made a man's whole body well?
#### John 7:24  Do not judge by appearances, but judge with right judgment.”
#### John 7:25  Some of the people of Jerusalem therefore said, “Is not this the man whom they seek to kill?
#### John 7:26  And here he is, speaking openly, and they say nothing to him! Can it be that the authorities really know that this is the Christ?
#### John 7:27  But we know where this man comes from, and when the Christ appears, no one will know where he comes from.”
#### John 7:28  So Jesus proclaimed, as he taught in the temple, “You know me, and you know where I come from. But I have not come of my own accord. He who sent me is true, and him you do not know.
#### John 7:29  I know him, for I come from him, and he sent me.”
#### John 7:30  So they were seeking to arrest him, but no one laid a hand on him, because his hour had not yet come.
#### John 7:31  Yet many of the people believed in him. They said, “When the Christ appears, will he do more signs than this man has done?”
#### John 7:32  The Pharisees heard the crowd muttering these things about him, and the chief priests and Pharisees sent officers to arrest him.
#### John 7:33  Jesus then said, “I will be with you a little longer, and then I am going to him who sent me.
#### John 7:34  You will seek me and you will not find me. Where I am you cannot come.”
#### John 7:35  The Jews said to one another, “Where does this man intend to go that we will not find him? Does he intend to go to the Dispersion among the Greeks and teach the Greeks?
#### John 7:36  What does he mean by saying, ‘You will seek me and you will not find me,’ and, ‘Where I am you cannot come’?”
#### John 7:37  On the last day of the feast, the great day, Jesus stood up and cried out, “If anyone thirsts, let him come to me and drink.
#### John 7:38  Whoever believes in me, as the Scripture has said, ‘Out of his heart will flow rivers of living water.’”
#### John 7:39  Now this he said about the Spirit, whom those who believed in him were to receive, for as yet the Spirit had not been given, because Jesus was not yet glorified.
#### John 7:40  When they heard these words, some of the people said, “This really is the Prophet.”
#### John 7:41  Others said, “This is the Christ.” But some said, “Is the Christ to come from Galilee?
#### John 7:42  Has not the Scripture said that the Christ comes from the offspring of David, and comes from Bethlehem, the village where David was?”
#### John 7:43  So there was a division among the people over him.
#### John 7:44  Some of them wanted to arrest him, but no one laid hands on him.
#### John 7:45  The officers then came to the chief priests and Pharisees, who said to them, “Why did you not bring him?”
#### John 7:46  The officers answered, “No one ever spoke like this man!”
#### John 7:47  The Pharisees answered them, “Have you also been deceived?
#### John 7:48  Have any of the authorities or the Pharisees believed in him?
#### John 7:49  But this crowd that does not know the law is accursed.”
#### John 7:50  Nicodemus, who had gone to him before, and who was one of them, said to them,
#### John 7:51  “Does our law judge a man without first giving him a hearing and learning what he does?”
#### John 7:52  They replied, “Are you from Galilee too? Search and see that no prophet arises from Galilee.”
#### John 7:53  [[They went each to his own house,
#### John 8:1  but Jesus went to the Mount of Olives.
#### John 8:2  Early in the morning he came again to the temple. All the people came to him, and he sat down and taught them.
#### John 8:3  The scribes and the Pharisees brought a woman who had been caught in adultery, and placing her in the midst
#### John 8:4  they said to him, “Teacher, this woman has been caught in the act of adultery.
#### John 8:5  Now in the Law, Moses commanded us to stone such women. So what do you say?”
#### John 8:6  This they said to test him, that they might have some charge to bring against him. Jesus bent down and wrote with his finger on the ground.
#### John 8:7  And as they continued to ask him, he stood up and said to them, “Let him who is without sin among you be the first to throw a stone at her.”
#### John 8:8  And once more he bent down and wrote on the ground.
#### John 8:9  But when they heard it, they went away one by one, beginning with the older ones, and Jesus was left alone with the woman standing before him.
#### John 8:10  Jesus stood up and said to her, “Woman, where are they? Has no one condemned you?”
#### John 8:11  She said, “No one, Lord.” And Jesus said, “Neither do I condemn you; go, and from now on sin no more.”]]
#### John 8:12  Again Jesus spoke to them, saying, “I am the light of the world. Whoever follows me will not walk in darkness, but will have the light of life.”
#### John 8:13  So the Pharisees said to him, “You are bearing witness about yourself; your testimony is not true.”
#### John 8:14  Jesus answered, “Even if I do bear witness about myself, my testimony is true, for I know where I came from and where I am going, but you do not know where I come from or where I am going.
#### John 8:15  You judge according to the flesh; I judge no one.
#### John 8:16  Yet even if I do judge, my judgment is true, for it is not I alone who judge, but I and the Father who sent me.
#### John 8:17  In your Law it is written that the testimony of two people is true.
#### John 8:18  I am the one who bears witness about myself, and the Father who sent me bears witness about me.”
#### John 8:19  They said to him therefore, “Where is your Father?” Jesus answered, “You know neither me nor my Father. If you knew me, you would know my Father also.”
#### John 8:20  These words he spoke in the treasury, as he taught in the temple; but no one arrested him, because his hour had not yet come.
#### John 8:21  So he said to them again, “I am going away, and you will seek me, and you will die in your sin. Where I am going, you cannot come.”
#### John 8:22  So the Jews said, “Will he kill himself, since he says, ‘Where I am going, you cannot come’?”
#### John 8:23  He said to them, “You are from below; I am from above. You are of this world; I am not of this world.
#### John 8:24  I told you that you would die in your sins, for unless you believe that I am he you will die in your sins.”
#### John 8:25  So they said to him, “Who are you?” Jesus said to them, “Just what I have been telling you from the beginning.
#### John 8:26  I have much to say about you and much to judge, but he who sent me is true, and I declare to the world what I have heard from him.”
#### John 8:27  They did not understand that he had been speaking to them about the Father.
#### John 8:28  So Jesus said to them, “When you have lifted up the Son of Man, then you will know that I am he, and that I do nothing on my own authority, but speak just as the Father taught me.
#### John 8:29  And he who sent me is with me. He has not left me alone, for I always do the things that are pleasing to him.”
#### John 8:30  As he was saying these things, many believed in him.
#### John 8:31  So Jesus said to the Jews who had believed him, “If you abide in my word, you are truly my disciples,
#### John 8:32  and you will know the truth, and the truth will set you free.”
#### John 8:33  They answered him, “We are offspring of Abraham and have never been enslaved to anyone. How is it that you say, ‘You will become free’?”
#### John 8:34  Jesus answered them, “Truly, truly, I say to you, everyone who practices sin is a slave to sin.
#### John 8:35  The slave does not remain in the house forever; the son remains forever.
#### John 8:36  So if the Son sets you free, you will be free indeed.
#### John 8:37  I know that you are offspring of Abraham; yet you seek to kill me because my word finds no place in you.
#### John 8:38  I speak of what I have seen with my Father, and you do what you have heard from your father.”
#### John 8:39  They answered him, “Abraham is our father.” Jesus said to them, “If you were Abraham's children, you would be doing the works Abraham did,
#### John 8:40  but now you seek to kill me, a man who has told you the truth that I heard from God. This is not what Abraham did.
#### John 8:41  You are doing the works your father did.” They said to him, “We were not born of sexual immorality. We have one Father—even God.”
#### John 8:42  Jesus said to them, “If God were your Father, you would love me, for I came from God and I am here. I came not of my own accord, but he sent me.
#### John 8:43  Why do you not understand what I say? It is because you cannot bear to hear my word.
#### John 8:44  You are of your father the devil, and your will is to do your father's desires. He was a murderer from the beginning, and does not stand in the truth, because there is no truth in him. When he lies, he speaks out of his own character, for he is a liar and the father of lies.
#### John 8:45  But because I tell the truth, you do not believe me.
#### John 8:46  Which one of you convicts me of sin? If I tell the truth, why do you not believe me?
#### John 8:47  Whoever is of God hears the words of God. The reason why you do not hear them is that you are not of God.”
#### John 8:48  The Jews answered him, “Are we not right in saying that you are a Samaritan and have a demon?”
#### John 8:49  Jesus answered, “I do not have a demon, but I honor my Father, and you dishonor me.
#### John 8:50  Yet I do not seek my own glory; there is One who seeks it, and he is the judge.
#### John 8:51  Truly, truly, I say to you, if anyone keeps my word, he will never see death.”
#### John 8:52  The Jews said to him, “Now we know that you have a demon! Abraham died, as did the prophets, yet you say, ‘If anyone keeps my word, he will never taste death.’
#### John 8:53  Are you greater than our father Abraham, who died? And the prophets died! Who do you make yourself out to be?”
#### John 8:54  Jesus answered, “If I glorify myself, my glory is nothing. It is my Father who glorifies me, of whom you say, ‘He is our God.’
#### John 8:55  But you have not known him. I know him. If I were to say that I do not know him, I would be a liar like you, but I do know him and I keep his word.
#### John 8:56  Your father Abraham rejoiced that he would see my day. He saw it and was glad.”
#### John 8:57  So the Jews said to him, “You are not yet fifty years old, and have you seen Abraham?”
#### John 8:58  Jesus said to them, “Truly, truly, I say to you, before Abraham was, I am.”
#### John 8:59  So they picked up stones to throw at him, but Jesus hid himself and went out of the temple.
#### John 9:1  As he passed by, he saw a man blind from birth.
#### John 9:2  And his disciples asked him, “Rabbi, who sinned, this man or his parents, that he was born blind?”
#### John 9:3  Jesus answered, “It was not that this man sinned, or his parents, but that the works of God might be displayed in him.
#### John 9:4  We must work the works of him who sent me while it is day; night is coming, when no one can work.
#### John 9:5  As long as I am in the world, I am the light of the world.”
#### John 9:6  Having said these things, he spit on the ground and made mud with the saliva. Then he anointed the man's eyes with the mud
#### John 9:7  and said to him, “Go, wash in the pool of Siloam” (which means Sent). So he went and washed and came back seeing.
#### John 9:8  The neighbors and those who had seen him before as a beggar were saying, “Is this not the man who used to sit and beg?”
#### John 9:9  Some said, “It is he.” Others said, “No, but he is like him.” He kept saying, “I am the man.”
#### John 9:10  So they said to him, “Then how were your eyes opened?”
#### John 9:11  He answered, “The man called Jesus made mud and anointed my eyes and said to me, ‘Go to Siloam and wash.’ So I went and washed and received my sight.”
#### John 9:12  They said to him, “Where is he?” He said, “I do not know.”
#### John 9:13  They brought to the Pharisees the man who had formerly been blind.
#### John 9:14  Now it was a Sabbath day when Jesus made the mud and opened his eyes.
#### John 9:15  So the Pharisees again asked him how he had received his sight. And he said to them, “He put mud on my eyes, and I washed, and I see.”
#### John 9:16  Some of the Pharisees said, “This man is not from God, for he does not keep the Sabbath.” But others said, “How can a man who is a sinner do such signs?” And there was a division among them.
#### John 9:17  So they said again to the blind man, “What do you say about him, since he has opened your eyes?” He said, “He is a prophet.”
#### John 9:18  The Jews did not believe that he had been blind and had received his sight, until they called the parents of the man who had received his sight
#### John 9:19  and asked them, “Is this your son, who you say was born blind? How then does he now see?”
#### John 9:20  His parents answered, “We know that this is our son and that he was born blind.
#### John 9:21  But how he now sees we do not know, nor do we know who opened his eyes. Ask him; he is of age. He will speak for himself.”
#### John 9:22  (His parents said these things because they feared the Jews, for the Jews had already agreed that if anyone should confess Jesus to be Christ, he was to be put out of the synagogue.)
#### John 9:23  Therefore his parents said, “He is of age; ask him.”
#### John 9:24  So for the second time they called the man who had been blind and said to him, “Give glory to God. We know that this man is a sinner.”
#### John 9:25  He answered, “Whether he is a sinner I do not know. One thing I do know, that though I was blind, now I see.”
#### John 9:26  They said to him, “What did he do to you? How did he open your eyes?”
#### John 9:27  He answered them, “I have told you already, and you would not listen. Why do you want to hear it again? Do you also want to become his disciples?”
#### John 9:28  And they reviled him, saying, “You are his disciple, but we are disciples of Moses.
#### John 9:29  We know that God has spoken to Moses, but as for this man, we do not know where he comes from.”
#### John 9:30  The man answered, “Why, this is an amazing thing! You do not know where he comes from, and yet he opened my eyes.
#### John 9:31  We know that God does not listen to sinners, but if anyone is a worshiper of God and does his will, God listens to him.
#### John 9:32  Never since the world began has it been heard that anyone opened the eyes of a man born blind.
#### John 9:33  If this man were not from God, he could do nothing.”
#### John 9:34  They answered him, “You were born in utter sin, and would you teach us?” And they cast him out.
#### John 9:35  Jesus heard that they had cast him out, and having found him he said, “Do you believe in the Son of Man?”
#### John 9:36  He answered, “And who is he, sir, that I may believe in him?”
#### John 9:37  Jesus said to him, “You have seen him, and it is he who is speaking to you.”
#### John 9:38  He said, “Lord, I believe,” and he worshiped him.
#### John 9:39  Jesus said, “For judgment I came into this world, that those who do not see may see, and those who see may become blind.”
#### John 9:40  Some of the Pharisees near him heard these things, and said to him, “Are we also blind?”
#### John 9:41  Jesus said to them, “If you were blind, you would have no guilt; but now that you say, ‘We see,’ your guilt remains.
#### John 10:1  “Truly, truly, I say to you, he who does not enter the sheepfold by the door but climbs in by another way, that man is a thief and a robber.
#### John 10:2  But he who enters by the door is the shepherd of the sheep.
#### John 10:3  To him the gatekeeper opens. The sheep hear his voice, and he calls his own sheep by name and leads them out.
#### John 10:4  When he has brought out all his own, he goes before them, and the sheep follow him, for they know his voice.
#### John 10:5  A stranger they will not follow, but they will flee from him, for they do not know the voice of strangers.”
#### John 10:6  This figure of speech Jesus used with them, but they did not understand what he was saying to them.
#### John 10:7  So Jesus again said to them, “Truly, truly, I say to you, I am the door of the sheep.
#### John 10:8  All who came before me are thieves and robbers, but the sheep did not listen to them.
#### John 10:9  I am the door. If anyone enters by me, he will be saved and will go in and out and find pasture.
#### John 10:10  The thief comes only to steal and kill and destroy. I came that they may have life and have it abundantly.
#### John 10:11  I am the good shepherd. The good shepherd lays down his life for the sheep.
#### John 10:12  He who is a hired hand and not a shepherd, who does not own the sheep, sees the wolf coming and leaves the sheep and flees, and the wolf snatches them and scatters them.
#### John 10:13  He flees because he is a hired hand and cares nothing for the sheep.
#### John 10:14  I am the good shepherd. I know my own and my own know me,
#### John 10:15  just as the Father knows me and I know the Father; and I lay down my life for the sheep.
#### John 10:16  And I have other sheep that are not of this fold. I must bring them also, and they will listen to my voice. So there will be one flock, one shepherd.
#### John 10:17  For this reason the Father loves me, because I lay down my life that I may take it up again.
#### John 10:18  No one takes it from me, but I lay it down of my own accord. I have authority to lay it down, and I have authority to take it up again. This charge I have received from my Father.”
#### John 10:19  There was again a division among the Jews because of these words.
#### John 10:20  Many of them said, “He has a demon, and is insane; why listen to him?”
#### John 10:21  Others said, “These are not the words of one who is oppressed by a demon. Can a demon open the eyes of the blind?”
#### John 10:22  At that time the Feast of Dedication took place at Jerusalem. It was winter,
#### John 10:23  and Jesus was walking in the temple, in the colonnade of Solomon.
#### John 10:24  So the Jews gathered around him and said to him, “How long will you keep us in suspense? If you are the Christ, tell us plainly.”
#### John 10:25  Jesus answered them, “I told you, and you do not believe. The works that I do in my Father's name bear witness about me,
#### John 10:26  but you do not believe because you are not among my sheep.
#### John 10:27  My sheep hear my voice, and I know them, and they follow me.
#### John 10:28  I give them eternal life, and they will never perish, and no one will snatch them out of my hand.
#### John 10:29  My Father, who has given them to me, is greater than all, and no one is able to snatch them out of the Father's hand.
#### John 10:30  I and the Father are one.”
#### John 10:31  The Jews picked up stones again to stone him.
#### John 10:32  Jesus answered them, “I have shown you many good works from the Father; for which of them are you going to stone me?”
#### John 10:33  The Jews answered him, “It is not for a good work that we are going to stone you but for blasphemy, because you, being a man, make yourself God.”
#### John 10:34  Jesus answered them, “Is it not written in your Law, ‘I said, you are gods’?
#### John 10:35  If he called them gods to whom the word of God came—and Scripture cannot be broken—
#### John 10:36  do you say of him whom the Father consecrated and sent into the world, ‘You are blaspheming,’ because I said, ‘I am the Son of God’?
#### John 10:37  If I am not doing the works of my Father, then do not believe me;
#### John 10:38  but if I do them, even though you do not believe me, believe the works, that you may know and understand that the Father is in me and I am in the Father.”
#### John 10:39  Again they sought to arrest him, but he escaped from their hands.
#### John 10:40  He went away again across the Jordan to the place where John had been baptizing at first, and there he remained.
#### John 10:41  And many came to him. And they said, “John did no sign, but everything that John said about this man was true.”
#### John 10:42  And many believed in him there.
