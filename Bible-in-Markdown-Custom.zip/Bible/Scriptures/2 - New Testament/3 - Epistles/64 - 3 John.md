#### 3 John 1:1  The elder to the beloved Gaius, whom I love in truth.
#### 3 John 1:2  Beloved, I pray that all may go well with you and that you may be in good health, as it goes well with your soul.
#### 3 John 1:3  For I rejoiced greatly when the brothers came and testified to your truth, as indeed you are walking in the truth.
#### 3 John 1:4  I have no greater joy than to hear that my children are walking in the truth.
#### 3 John 1:5  Beloved, it is a faithful thing you do in all your efforts for these brothers, strangers as they are,
#### 3 John 1:6  who testified to your love before the church. You will do well to send them on their journey in a manner worthy of God.
#### 3 John 1:7  For they have gone out for the sake of the name, accepting nothing from the Gentiles.
#### 3 John 1:8  Therefore we ought to support people like these, that we may be fellow workers for the truth.
#### 3 John 1:9  I have written something to the church, but Diotrephes, who likes to put himself first, does not acknowledge our authority.
#### 3 John 1:10  So if I come, I will bring up what he is doing, talking wicked nonsense against us. And not content with that, he refuses to welcome the brothers, and also stops those who want to and puts them out of the church.
#### 3 John 1:11  Beloved, do not imitate evil but imitate good. Whoever does good is from God; whoever does evil has not seen God.
#### 3 John 1:12  Demetrius has received a good testimony from everyone, and from the truth itself. We also add our testimony, and you know that our testimony is true.
#### 3 John 1:13  I had much to write to you, but I would rather not write with pen and ink.
#### 3 John 1:14  I hope to see you soon, and we will talk face to face.
#### 3 John 1:15  Peace be to you. The friends greet you. Greet the friends, each by name.
