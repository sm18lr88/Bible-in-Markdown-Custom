#### 2 John 1:1  The elder to the elect lady and her children, whom I love in truth, and not only I, but also all who know the truth,
#### 2 John 1:2  because of the truth that abides in us and will be with us forever:
#### 2 John 1:3  Grace, mercy, and peace will be with us, from God the Father and from Jesus Christ the Father's Son, in truth and love.
#### 2 John 1:4  I rejoiced greatly to find some of your children walking in the truth, just as we were commanded by the Father.
#### 2 John 1:5  And now I ask you, dear lady—not as though I were writing you a new commandment, but the one we have had from the beginning—that we love one another.
#### 2 John 1:6  And this is love, that we walk according to his commandments; this is the commandment, just as you have heard from the beginning, so that you should walk in it.
#### 2 John 1:7  For many deceivers have gone out into the world, those who do not confess the coming of Jesus Christ in the flesh. Such a one is the deceiver and the antichrist.
#### 2 John 1:8  Watch yourselves, so that you may not lose what we have worked for, but may win a full reward.
#### 2 John 1:9  Everyone who goes on ahead and does not abide in the teaching of Christ, does not have God. Whoever abides in the teaching has both the Father and the Son.
#### 2 John 1:10  If anyone comes to you and does not bring this teaching, do not receive him into your house or give him any greeting,
#### 2 John 1:11  for whoever greets him takes part in his wicked works.
#### 2 John 1:12  Though I have much to write to you, I would rather not use paper and ink. Instead I hope to come to you and talk face to face, so that our joy may be complete.
#### 2 John 1:13  The children of your elect sister greet you.
