#### Judges 1:1 And it came to pass after the decease of Joshua, that {asked the sons of Israel} in the LORD, saying, Who shall ascend with us against the Canaanite guiding to wage war against them. 

#### Judges 1:2 And the LORD said, Judah shall ascend; behold, I have put the land in his hand. 

#### Judges 1:3 And Judah said to Simeon his brother, Ascend with me unto my lot, for we should wage war with the Canaanite, and I shall go also with you unto your lot. And {went with him Simeon}. 

#### Judges 1:4 And Judah ascended. And the LORD gave the Canaanite and the Perizzite into his hand; and they struck them in Bezek -- ten thousand men. 

#### Judges 1:5 And they found Adoni-bezek in Bezek. And they waged war with him, and they struck the Canaanite and the Perizzite. 

#### Judges 1:6 And Adoni-bezek fled; and they pursued after him, and took him, and cut off the thumbs of his hands, and the big toes of his feet. 

#### Judges 1:7 And Adoni-bezek said, Seventy kings the thumbs of their hands, and the big toes of their feet being cut off were collected together underneath my table. As then I did, so {recompensed to me God}. And they led him unto Jerusalem, and he died there. 

#### Judges 1:8 And {waged war the sons of Judah} with Jerusalem, and overtook it, and struck it by the mouth of the broadsword, and the city they burnt with fire. 

#### Judges 1:9 And after these things {went down the sons of Judah} to wage war with the Canaanite dwelling the mountainous area, and the south, and the plain country. 

#### Judges 1:10 And Judah went to the Canaanite dwelling in Hebron; and the name Hebron was formerly Kirjath-arba. And they struck Sheshai, and Ahiman, and Talmai, offspring of the Anak. 

#### Judges 1:11 And they went from there to the ones dwelling in Debir; and the name Debir was formerly Kirjath-sepher -- City of Letters. 

#### Judges 1:12 And Caleb said, Who ever should strike the City of Letters, and be first to take it, I will give to him Achsah my daughter for a wife. 

#### Judges 1:13 And first to take it was Othniel son of Kenaz, {brother of Caleb the younger}. And he gave to him Achsah his daughter for a wife. 

#### Judges 1:14 And it came to pass in her entering, that he stirred her to ask for {from her father a field}. And she grumbled upon her beast of burden. And {said to her Caleb}, What is it with you? 

#### Judges 1:15 And {said to him Achsah}, Give indeed to me a blessing, for into the land of the south you have handed me over, and you shall give to me a ransoming of water. And {gave to her Caleb} the ransom of the elevated springs, and the ransom of the ones below. 

#### Judges 1:16 And the sons of Jothor the Kenite, father-in-law of Moses, ascended from out of the city of the palms to the sons of Judah, into the wilderness of Judah, the one being in the south upon the descent of Arad; and they went and dwelt with the people. 

#### Judges 1:17 And Judah went with Simeon his brother, and they struck the Canaanite dwelling in Zephath, and they devoted it to consumption, and utterly destroyed it. And they called the name of the city, Devastation. 

#### Judges 1:18 And Judah inherited Gaza and her border; and Ekron and her border, and Ashkelon and her border and Ashdod and her outskirts. 

#### Judges 1:19 And the LORD was with Judah; and he inherited the mountain, for he was not able to inherit the ones dwelling in the valley, for it was separated to them, and there were chariots of iron to them. 

#### Judges 1:20 And they gave {to Caleb Hebron}, as Moses spoke. And he removed there the three sons of Anak. 

#### Judges 1:21 And {the Jebusite dwelling Jerusalem did not remove the sons of Benjamin}. And {dwelt the Jebusite} with the sons of Benjamin in Jerusalem until this day. 

#### Judges 1:22 And {ascended the sons of Joseph}, and indeed they went into Beth-el, and the LORD was with them. 

#### Judges 1:23 And they camped, and surveyed Beth-el; and the name of the city was formerly Luz. 

#### Judges 1:24 And {beheld the ones keeping guard} a man going forth from out of the city, and they took him, and they said to him, Show to us the entrance of the city, and we will deal {with you mercifully}. 

#### Judges 1:25 And he showed to them the entrance of the city; and they struck the city by the mouth of the broadsword; but the man and his kin they sent out. 

#### Judges 1:26 And {went forth the man} into the land of the Hittite, and he built there a city, and he called the name of it, Luz; this is its name until this day. 

#### Judges 1:27 And {did not remove Manasseh} Beth-shean nor its daughter towns, nor Taanach and her daughter towns, nor the ones dwelling in Dor and her daughter towns, nor the ones dwelling Megiddo and her daughter towns, nor the ones dwelling Ibleam nor her daughter towns. And {began the Canaanite} to dwell in this land. 

#### Judges 1:28 And it came to pass when Israel grew in strength, that he established the Canaanite for tribute, but by removing he did not remove him. 

#### Judges 1:29 And Ephraim did not remove the Canaanite dwelling in Gezer; and {dwelt the Canaanite} in the midst of him in Gezer. 

#### Judges 1:30 And Zebulun did not remove the ones dwelling in Kitron, and the ones dwelling Nahalol. And {dwelt the Canaanite} in the midst of them, and it became for tribute. 

#### Judges 1:31 And Asher did not remove the ones dwelling Accho, and the ones dwelling Sidon, and the ones dwelling Ahlab, and Achzib, and Helbah, and Aphik, and Rehob. 

#### Judges 1:32 And Asher dwelt in the midst of the Canaanite dwelling in the land; for he was not able to remove him. 

#### Judges 1:33 And Naphtali did not remove the ones dwelling in Beth-shemesh, and the ones dwelling in Beth-anath. And Naphtali dwelt in the midst of the Canaanite dwelling in the land. But the ones dwelling in Beth-shemesh and in Beth-anath became to them for tribute. 

#### Judges 1:34 And {squeezed out the Amorite} the sons of Dan into the mountain; for they did not let him go down into the valley. 

#### Judges 1:35 And {began the Amorite} to dwell in mount Heres of which the bears and the foxes are; and {was oppressive the hand of the house of Joseph} upon the Amorite, and he became for tribute. 

#### Judges 1:36 And the border of the Amorite was from the ascending of Akrabbim, from the rock, and above. 

#### Judges 2:1 And ascended an angel of the LORD from Gilgal, unto the Place of Weeping. And he said to them, The LORD transported you from Egypt, and brought you into the land which he swore by an oath to your fathers to give to you. And he said, I shall not efface my covenant with you into the eon. 

#### Judges 2:2 And you shall not ordain a covenant with the ones lying in wait in this land, nor {to their gods in any way shall you do obeisance}; but their carved idols break, and their altars raze! And you hearkened not to my voice, nor {these things did you do}. 

#### Judges 2:3 And I said, In no way shall I remove them from your face; and they will be to you for conflict, and their gods will be to you as an obstacle. 

#### Judges 2:4 And it came to pass as {spoke the angel of the LORD} these words to all the sons of Israel, that {lifted up the people} their voices, and wept. 

#### Judges 2:5 Therefore he called the name of that place, Weeping. And they sacrificed there to the LORD. 

#### Judges 2:6 And Joshua sent out the people, and {departed the sons of Israel each} to his place, and to his inheritance, to inherit the land. 

#### Judges 2:7 And {served the people} to the LORD all the days of Joshua, and all the days of the elders, as many as prolonged their days with Joshua, as many as knew every {work of the LORD great} which he did to Israel. 

#### Judges 2:8 And {came to an end Joshua the son of Nun}, a servant of the LORD, a son of a hundred ten years. 

#### Judges 2:9 And they entombed him in the border of his inheritance in Timnath-heres, in mount Ephraim, from the north of mount Gaash. 

#### Judges 2:10 And indeed all that generation was added to their fathers. And {rose up generation another} after them which did not know the LORD, and indeed the work which he did to Israel. 

#### Judges 2:11 And {acted the sons of Israel} wickedly before the LORD, and they served to the Baalim. 

#### Judges 2:12 And they abandoned the LORD God of their fathers, the one leading them out of the land of Egypt, and they went after other gods of the gods of the peoples surrounding them; and they did obeisance to them, and provoked {to anger the LORD}. 

#### Judges 2:13 And they abandoned the LORD, and served to Baal and to the Ashtoreths. 

#### Judges 2:14 And {was provoked to anger in rage the LORD} with Israel, and he delivered them into the hand of ones despoiling, and they carried {away captive them}. And he gave them into the hand of their enemies round about, and they were not able to oppose against the face of their enemies. 

#### Judges 2:15 In all wherever they went, even the hand of the LORD was against them for bad, as the LORD said, and as the LORD swore to them; and he squeezed them exceedingly. 

#### Judges 2:16 And the LORD raised up judges, and {delivered them the LORD} from the hand of the ones despoiling them. And {their judges they obeyed not}, 

#### Judges 2:17 for they fornicated after other gods, and did obeisance to them, and provoked {to anger the LORD}. And they turned aside quickly from the way of which {went their fathers}, listening to the commandments of the LORD; they did not do so. 

#### Judges 2:18 And when the LORD raised up to them judges, then the LORD was with the judge, and he delivered them from the hand of their enemies all the days of the judge. For {was moved to comfort the LORD} because of their moaning from in front of the ones assaulting them and afflicting them. 

#### Judges 2:19 And it came to pass as {died the judge}, that they turned back, and again corrupted themselves above their fathers, to go after other gods, and to serve them, and to do obeisance to them. They did not disown their practices, and of {way their recalcitrant}. 

#### Judges 2:20 And {was provoked to anger in rage the LORD} with Israel. And he said, Because of as much as {abandoned this nation} my covenant which I gave charge to their fathers, and hearkened not to my voice, 

#### Judges 2:21 then I shall not proceed to remove a man before their presence from the nations whom were left behind by Joshua. 

#### Judges 2:22 And he allowed to test {by him Israel}, if they guard the way of the LORD, to go by it in which manner {guarded their fathers}, or not. 

#### Judges 2:23 And the LORD left these nations so as to not remove them quickly; and he did not deliver them into the hand of Joshua. 

#### Judges 3:1 And these are the nations which the LORD left with them so as to test {by them Israel}, all the ones not knowing all the wars of Canaan, 

#### Judges 3:2 this was only for the sake of the generations of the sons of Israel, to teach them war, except the ones before them did not know them, 

#### Judges 3:3 namely the five satrapies of the Philistines, and every Canaanite, and the Sidonian, and the Hivite dwelling in Lebanon, from mount Baal-hermon unto Hamath. 

#### Judges 3:4 And it happened so as to test {by them Israel}, to know if they will hearken to the commandments of the LORD which he gave charge to their fathers by the hand of Moses. 

#### Judges 3:5 And the sons of Israel dwelt in the midst of the Canaanite, and the Hittite, and the Amorite, and the Perizzite, and the Hivite, and the Jebusite. 

#### Judges 3:6 And they took their daughters unto themselves for wives, and their daughters they gave to their sons, and they served their gods. 

#### Judges 3:7 And {acted the sons of Israel} wickedly before the LORD, and they forgot the LORD their God, and they served to the Baalim, and to the sacred groves. 

#### Judges 3:8 And {was provoked to anger in rage the LORD} with Israel, and he gave them into the hands of Chushan-rishathaim king of Syria Mesopotamia. And {served the sons of Israel} to him {years eight}. 

#### Judges 3:9 And {cried out the sons of Israel} to the LORD, and the LORD raised up a deliver for Israel, and he delivered them -- Othniel son of Kenaz, brother of Caleb the one younger than him. 

#### Judges 3:10 And {came upon him spirit of the LORD}, and he judged Israel, and he went unto the war. And the LORD delivered {into his hand Cushan-rishathaim king of Syria}; And he fortified his hand against Cushan-rishathaim. 

#### Judges 3:11 And {was tranquil the land} forty years, and {died Othniel son of Kenaz}. 

#### Judges 3:12 And {proceeded the sons of Israel} to do wickedly before the LORD. And the LORD strengthened Eglon king of Moab against Israel, because of their acting wickedly before the LORD. 

#### Judges 3:13 And he brought together to himself all the sons of Ammon and Amalek, and he went and struck Israel, and inherited the city of the palms. 

#### Judges 3:14 And {served the sons of Israel} to Eglon king of Moab eighteen years. 

#### Judges 3:15 And {cried out the sons of Israel} to the LORD; and {raised up the LORD} to them a deliverer -- Ehud son of Gera, son of Benjamin, a man ambidextrous. And {sent the sons of Israel} gifts by his hand to Eglon king of Moab. 

#### Judges 3:16 And {made for himself Ehud} a knife, double-edged, a span being the length of it; and he girded it under the uniform, upon {thigh his right}. 

#### Judges 3:17 And he brought the gifts to Eglon king of Moab. And Eglon was a man {fair weight of exceedingly}. 

#### Judges 3:18 And it came to pass as Ehud completed bringing the gifts, that he sent out the ones carrying the gifts, 

#### Judges 3:19 and he returned from the carvings by Gilgal. And Ehud said, {word There is with me a secret} for you, O king. And Eglon said to him, Be silent! And went forth from him all the ones standing around him. 

#### Judges 3:20 And Ehud entered to him, and he sat in {upper harvest room his} alone. And Ehud said, There is a word of God with me to you, O king. And {rose up from the throne Eglon} near him. 

#### Judges 3:21 And it happened together in his rising up, that Ehud stretched out {hand his left} and took the knife from {thigh his right}, and he stuck it into the belly of Eglon. 

#### Judges 3:22 And he brought in addition also indeed the handle after the blade; and {locked the fat} onto the blade, for he could not pull out the knife from out of his belly. 

#### Judges 3:23 And Ehud went forth into the antechamber; and he went forth by the things set in order, and locked the doors of the upper room by him, and wedged them. 

#### Judges 3:24 And he went forth. And his servants entered, and they saw, and behold, the doors of the upper room were wedged. And they said, Perhaps {with the chair he sits} in the voidance of the bedroom. 

#### Judges 3:25 And they remained being ashamed. And behold, there was not one opening the doors of the upper room. And they took the key, and they opened. And behold, their master was fallen upon the ground having died. 

#### Judges 3:26 And Ehud came through safe until they made a disruption. And there was not one paying attention to him. And he went by the carvings, and came through safe into Seirath. 

#### Judges 3:27 And it came to pass when he came, that he trumped a horn in mount Ephraim. and {went down with him the sons of Israel} from the mountain, and he in front of them. 

#### Judges 3:28 And he said to them, Come down after me, for {delivered up the LORD God} our enemies of Moab into our hand. And they went down after him, and first took the ford of the Jordan of Moab, and they did not allow a man to pass over. 

#### Judges 3:29 And they struck Moab in that time, about ten thousand men, all the warriors, and every man having power; and not {came through safe a man}. 

#### Judges 3:30 And Moab felt shame in that day under the hand of Israel; and {was tranquil the land} eighty years. 

#### Judges 3:31 And after him rose up Shamgar son of Anath, and he struck the Philistines up to six hundred men by the plowshare of the oxen; and he himself delivered Israel. 

#### Judges 4:1 And {proceeded the sons of Israel} to act wickedly before the LORD; and Ehud died. 

#### Judges 4:2 And {delivered them the LORD} into the hand of Jabin king of Canaan, who reigned in Hazor; and the ruler of his force was Sisera, and he dwelt in Harosheth of the nations. 

#### Judges 4:3 And {cried out the sons of Israel} to the LORD, because nine hundred chariots of iron were his. And he afflicted Israel by might for twenty years. 

#### Judges 4:4 And Deborah, a woman prophetess, wife of Lapidoth -- she judged Israel in that time. 

#### Judges 4:5 And she sat down under the palm of Deborah, between Rama and between Beth-el, in mount Ephraim; and {ascended to her the sons of Israel} there to be judged. 

#### Judges 4:6 And Deborah sent and called Barak son of Abinoam from out of Kedesh Naphtali. And she said to him, Did not {give charge the LORD God of Israel} to you, that, You shall go forth unto mount Tabor, and you shall take with yourself ten thousand men of the sons of Naphtali, and of the sons of Zebulun? 

#### Judges 4:7 And I shall bring to you at the rushing stream Kishon Sisera ruler of the force of Jabin, and his chariots, and his multitude; and I will deliver him into your hand. 

#### Judges 4:8 And {said to her Barak}, If you should go with me, I will go; and if you should not go, will I not go. 

#### Judges 4:9 And {said to him Deborah}, In going I will go with you. Except know that {will not be the honor} yours in the way which you go; for by the hand of a woman the LORD will deliver up Sisera. And Deborah rose up and went with Barak from out of Kedesh. 

#### Judges 4:10 And Barak summoned Zebulun and Naphtali to Kedesh. And ascended by his feet ten thousand men; and Deborah ascended with him. 

#### Judges 4:11 And the near ones of the Kenite were separated from Kena, from the sons of Hobab father-in-law of Moses. And he pitched his tent by Oak of the ones Resting, which is next to Kedesh. 

#### Judges 4:12 And it was announced to Sisera that {ascended Barak son of Abinoam} unto mount Tabor. 

#### Judges 4:13 And Sisera called all his chariots -- nine hundred chariots of iron, and all the people with him, from Harosheth of the nations unto the rushing stream Kishon. 

#### Judges 4:14 And Deborah said to Barak, Rise up! for this is the day in which the LORD delivers Sisera into your hand. Behold is not the LORD gone in front of you? And Barak went down from mount Tabor, and ten thousand men behind him. 

#### Judges 4:15 And the LORD startled Sisera, and all his chariots, and all his camp, by the mouth of the broadsword before Barak. And Sisera came down from on top of his chariot, and he fled by his feet. 

#### Judges 4:16 And Barak pursued after the chariots, and after the camp unto Oak of the Nations. And {fell all the camp of Sisera} by the mouth of the broadsword; there was not left behind even one. 

#### Judges 4:17 And Sisera withdrew by his feet to the tent of Jael wife of Heber the Kenite; for there was peace between Jabin king of Hazor and between the house of Heber the Kenite. 

#### Judges 4:18 And Jael came forth for a meeting with Sisera, and she said to him, Turn aside, O my master, turn aside to me, do not fear! And he turned aside to her into the tent, and she covered him with her hide covering. 

#### Judges 4:19 And Sisera said to her, Give a drink please to me, a little water! for I am thirsty. And she opened the leather bag of the milk, and she gave him to drink, and she covered his person. 

#### Judges 4:20 And he said to her, Stand in the door of the tent! And it will be if a man should come to you, and should ask you, and should say to you, Is {here a man}? That you shall say, There is not. 

#### Judges 4:21 And {took Jael the wife of Heber} the peg of the tent, and put the hammer in her hand, and she entered to him tranquilly, and she hammered in the peg into his cheek, and thrust it through into the ground. And he being startled was enveloped in darkness and died. 

#### Judges 4:22 And, behold, Barak was pursuing Sisera. And Jael came forth for meeting him, and she said to him, Come, and I will show to you the man whom you seek. And he entered with her. And behold, there was Sisera having fallen dead, and the peg in his temple. 

#### Judges 4:23 And {abased God} in that day Jabin king of Canaan in front of the sons of Israel. 

#### Judges 4:24 And {went forth the hand of the sons of Israel} going, and hardening against Jabin king of Canaan, until of which time they utterly destroyed him. 

#### Judges 5:1 And {sang Deborah and Barak son of Abinoam} in that day, and said, 

#### Judges 5:2 In the rule of chiefs in Israel, in resolve of people, bless the LORD! 

#### Judges 5:3 Hear, O kings! Give ear, O satraps! I {to the LORD shall sing}, and I shall strum to the God of Israel. 

#### Judges 5:4 O LORD, in your exodus from Seir, in your departing from out of the field of Edom, the earth was shaken, and indeed the heaven was disturbed, and the clouds dripped water. 

#### Judges 5:5 Mountains shook from the face of the LORD; this Sinai from the face of the LORD God of Israel. 

#### Judges 5:6 In the days of Shamgar son of Anath, in the days of Jael, {failed the ways}, and they went by short cuts. They went by ways being turned aside. 

#### Judges 5:7 {failed The ones dwelling in Israel}, they failed until of which time Deborah rose up, that {rose up a mother} in Israel. 

#### Judges 5:8 They selected new gods, then {waged war cities of rulers}; {for protection of young women spears appeared}, even a spear -- forty thousand in Israel. 

#### Judges 5:9 My heart is with the things ordered to Israel. The mighty of the people -- you bless the LORD! 

#### Judges 5:10 O ones mounting upon beasts of burden, upon covered royal chariots, sitting down upon a judgment seat, and going by the way -- utter! 

#### Judges 5:11 A sound of the men playing music in the midst of ones making merry. There they shall give righteousness to the LORD. O righteousness grow in strength in Israel! Then shall go down into his cities the people of the LORD. 

#### Judges 5:12 Awaken, awaken, O Deborah! Awaken, awaken! Speak with an ode! Rise up, O Barak! And take captive your captivity, O son of Abinoam! 

#### Judges 5:13 Then {was magnified his strength}. O LORD abase to me the ones stronger than me! People Ephraim punished them in the valley. Your brother Benjamin among your peoples. 

#### Judges 5:14 Ephraim rooted them out among Amalek. After you, Benjamin, with your peoples. Of me, Machir, they came down searching out; and from Zebulun growing in strength in chiefdom of the narrative of a scribe. 

#### Judges 5:15 And the rulers were in Issachar with Deborah and Issachar; so Barak in the valley sent out his footmen in the divisions of Reuben -- in great restrictions of heart. 

#### Judges 5:16 Why with me did you settle between the sheepfolds to listen to whistlings arousing to go through for the ones of Reuben -- in great trackings out of heart? 

#### Judges 5:17 Gilead {on the other side of the Jordan encamped}. And Dan -- why does he sojourn in boats? Asher sojourns by the shore of seas, and at his breaches he will encamp. 

#### Judges 5:18 Zebulun -- a people berating their soul to death; and Naphtali was upon the heights of a field. 

#### Judges 5:19 {came Kings} and deployed; then {waged war the kings of Canaan} in Taanach, at the water of Megiddo; a desire for wealth of silver they did not have. 

#### Judges 5:20 From the heaven they deployed; the stars from their order deployed against Sisera. 

#### Judges 5:21 The rushing stream Kishon cast them out, the rushing stream of antiquity, the rushing stream Kishon; {shall trample them soul my mighty}. 

#### Judges 5:22 Then they were impeded, the heels of horses {with diligence were hastened} by his mighty ones. 

#### Judges 5:23 Curse Meroz! said the angel of the LORD. With a curse, curse every one dwelling in it! for they came not to the help of the LORD. The LORD is a helper against warriors. 

#### Judges 5:24 May she be blessed of women -- Jael wife of Heber the Kenite; above the women in the tent may she be blessed. 

#### Judges 5:25 {for water He asked her}, and {milk she gave} to him in a pan; {of strong ones she drew near butter}. 

#### Judges 5:26 {her hand for a peg She stretched out}, and her right for the hammer of a laborer; and she struck {with a hammer Sisera}; she nailed his head; yes, she struck, she nailed his temple. 

#### Judges 5:27 In between her feet bowing he fell; he slept between her feet; he bent; he fell; in which he bent there he fell miserably. 

#### Judges 5:28 Through the window {looked and studied the mother of Sisera} -- through the latticed window. Why was {late his chariot} to arrive? Why did {pass time the track of his chariots}? 

#### Judges 5:29 {wise ladies leading Her} answered to her, and she returned her words to herself. 

#### Judges 5:30 Shall they not find him dividing the spoils? Befriending friends to {head ruler a mighty}. Spoils of dyed things for Sisera, spoils of dyed embroidery dipped. Dyed embroidered works, {for his neck spoils}. 

#### Judges 5:31 Thus may {be destroyed all your enemies}, O LORD. And the ones loving him be as the rising of the sun in his power. And {was quiet the land} forty years. 

#### Judges 6:1 And {acted the sons of Israel} wickedly before the LORD, and {delivered them over the LORD} into the hand of Midian for seven years. 

#### Judges 6:2 And {prevailed the hand of Midian} against Israel. Because of the presence of Midian {made for themselves the sons of Israel} havens in the mountains, and in the caves, and in the fortresses. 

#### Judges 6:3 And it came to pass when {sowed a man of Israel}, that there ascended up Midian and Amalek; even the sons of the east were ascending against them. 

#### Judges 6:4 And they camped by them, and they ruined the resources of the land unto the coming unto Gaza. And there was not left behind support for life in Israel, even for the flock, and calf, and donkey. 

#### Judges 6:5 For they and their livestock ascended and {their tents they carried about with}; and they came as the locusts by multitude. And for them and their camels there was no number. And they came in the land of Israel to ruin it. 

#### Judges 6:6 And Israel became poor, exceedingly, from the presence of Midian. 

#### Judges 6:7 And {cried out the sons of Israel} to the LORD. And it came to pass when {cried out the sons of Israel} to the LORD on account of Midian, 

#### Judges 6:8 the LORD sent a man, a prophet, to the sons of Israel. And he said to them, Thus says the LORD God of Israel, I am the one bringing you up from Egypt, and I led you from the house of slavery; 

#### Judges 6:9 and I rescued you from the hand of Egypt, and from the hand of all the ones afflicting you; and I cast them from your face, and I gave to you their land. 

#### Judges 6:10 And I said to you, I am the LORD your God; you shall not fear the gods of the Amorites in which you dwell in their land. But you hearkened not to my voice. 

#### Judges 6:11 And {came an angel of the LORD} and sat under the oak, the one being in Ophrah, the one of the {of Joash father} of Ezri. And Gideon his son beat {with a rod wheat} in a wine-vat, to flee from the face of Midian. 

#### Judges 6:12 And {appeared to him the angel of the LORD}, and said to him, The LORD is with you mighty in strength. 

#### Judges 6:13 And {said to him Gideon}, Be it to me, O my Lord, and if the LORD is with us, then why do {find us all these bad things}? And where are all his wonders, as many as {described to us our fathers}, saying, Is it not from out of Egypt {led us the LORD}? And now he thrust us away, and delivered us over into the hand of Midian. 

#### Judges 6:14 And {looked towards him the angel of the LORD}, and said to him, Go in {your strength this}! and you shall deliver Israel. Behold, I send you. 

#### Judges 6:15 And {said to him Gideon}, Be it to me, O my Lord, by what means shall I deliver Israel? Behold, my thousand is humbler in Manasseh, and I am the lesser in the house of my father. 

#### Judges 6:16 And {said to him The LORD} that, I will be with you, and you shall strike Midian as {man one}. 

#### Judges 6:17 And {said to him Gideon}, And if I found favor in your eyes, then you shall give to me a sign that you spoke with me. 

#### Judges 6:18 In no way should you separate from here until {coming my} to you, and I shall bring my sacrifice, and I shall sacrifice before you. And he said, I am settled until you return. 

#### Judges 6:19 And Gideon entered and prepared a kid of the goats, and an ephah {flour of unleavened}, and {the meats he put} upon the bin, and the broth he poured into an earthen pot, and he brought it to him under the oak, and did obeisance. 

#### Judges 6:20 And {said to him the angel of the LORD}, Take the meats and the unleavened breads, and put them on that rock, and {the broth pour out}! And he did so. 

#### Judges 6:21 And {stretched out the angel of the LORD} the tip of the rod in his hand, and touched of the meats, and of the unleavened breads; and {was lit fire} from out of the rock, and it devoured the meats and the unleavened breads. And the angel of the LORD departed from his eyes. 

#### Judges 6:22 And Gideon knew that {the angel of the LORD it is}. And Gideon said, Alas, O my Lord, O LORD, for I beheld the angel of the LORD face to face. 

#### Judges 6:23 And {said to him the LORD}, Peace to you, do not fear, in no way shall you die. 

#### Judges 6:24 And {built there Gideon} an altar to the LORD. And he called it, Peace of the LORD, until this day. It is still being with Ephratah father of Ezri. 

#### Judges 6:25 And it came to pass in that night, that {said to him the LORD}, Take the {calf well fed} of your father, and the {calf second} of seven years old! And you shall demolish the altar of Baal which is of your father; and the sacred grove by it you shall cut down. 

#### Judges 6:26 And you shall build an altar to the LORD your God, to the one appearing to you upon the top {mountain of Maoz of this} in the battle array. And you shall take with the {calf second}, and you shall offer whole burnt-offerings in the trees of the sacred grove which you cut down. 

#### Judges 6:27 And Gideon took ten men from his manservants, and he did as {spoke to him the LORD}. And it came to pass that he feared the household of his father, and the men of the city, so as to not act by day, and he acted it by night. 

#### Judges 6:28 And {rose early the men of the city} in the morning; and behold, {was razed the altar of Baal}, and the sacred grove by it was cut down; and the {calf well fed} was offered for a whole burnt-offering upon the altar having been built. 

#### Judges 6:29 And {said each man} to his neighbor, Who did this thing? And they investigated and inquired. And they said, Gideon son of Joash did this thing. 

#### Judges 6:30 And {said the men of the city} to Joash, Lead out your son and let him die! for he razed the altar of Baal, and because he cut down the sacred grove by it. 

#### Judges 6:31 And Joash said to the men rising against him, Do you now adjudicate for Baal? or shall you deliver him? Who ever pleaded to him let die in the morning. If {God he is}, he shall avenge for himself, for he razed his altar. 

#### Judges 6:32 And he called him in that day, Jerubbaal, saying, The court of justice of Baal, for he razed his altar. 

#### Judges 6:33 And all Midian and Amalek and the sons of the east came together at the same place, and they passed over and camped in the valley of Jezreel. 

#### Judges 6:34 And spirit of God empowered Gideon, and he trumped with the horn; and he called for aid to Abiezer after him. 

#### Judges 6:35 And {messengers he sent} to all Manasseh, and he called also himself others after him. And {messengers he sent out} in Asher, and in Zebulun, and in Naphtali. And they ascended for meeting him. 

#### Judges 6:36 And Gideon said to God, If you deliver {by my hand Israel}, as you spoke, 

#### Judges 6:37 behold, I fasten the fleece of wool pieces in the threshing-floor. And if dew comes upon the fleece only, and upon all the earth be dryness, then I will know that you shall deliver {by my hand Israel} in which manner you spoke. 

#### Judges 6:38 And it came to pass thus. And Gideon rose early on the next day, and he squeezed out the fleece, and {dripped dew} from the fleece -- a full pan of water. 

#### Judges 6:39 And Gideon said to God, Let not {be provoked to anger your rage} against me! for I will speak still once more, and I will test still once more by the fleece. And let there become yet dryness upon the fleece only, and upon all the ground let there become dew! 

#### Judges 6:40 And God did so in that night. And there was dryness upon the fleece only, and upon all the ground became dew. 

#### Judges 7:1 And Jerubbaal rose early (he is Gideon), and all the people with him. And they camped upon the spring of Harod. And the camp of Midian was to him from the north of the hill Moreh, in the valley. 

#### Judges 7:2 And the LORD said to Gideon, {are many The people with you} so as {to not deliver up for me} Midian into their hand, lest at any time Israel should boast instead of me, saying, My hand delivered me. 

#### Judges 7:3 And the LORD said to him, Speak indeed into the ears of the people! saying, Any one fearing and timid return! And they sallied out from mount Gilead. And returned of the people twenty and two thousand, and ten thousand were left behind. 

#### Judges 7:4 And the LORD said to Gideon, Still the people are many, lead them down to the water! and I will try them for you there. And it will be whom ever I should tell to you, This one shall go with you -- he shall go with you. And all whom ever I should say that, He shall not go with you, then he shall not go with you. 

#### Judges 7:5 And {went down the people} to the water. And the LORD said to Gideon, All who ever laps with his tongue of the water as if {should lap the dog}, you shall stand him alone. And all who ever bends upon his knees to drink, you shall remove him by himself. 

#### Judges 7:6 And was the number of the ones lapping with their tongue three hundred men. And all the remaining people bent upon their knees to drink water. 

#### Judges 7:7 And the LORD said to Gideon, By the three hundred men lapping I shall deliver you, and I will put Midian into your hand. And all the people ran, each man to his place. 

#### Judges 7:8 And they took the provision of the people in their hand, and their horns. And every man of Israel he sent out to his tent, and the three hundred men he kept. And the camp of Midian was underneath him in the valley. 

#### Judges 7:9 And it came to pass in that night, that {said to him the LORD}, Rise up, go down into the camp! for I delivered it into your hand. 

#### Judges 7:10 And if you should fear {by yourself to go down}, {go down then you and Phurah your servant} into the camp. 

#### Judges 7:11 And you should hearken to what they speak, and after these things {shall grow in strength your hands}, and you shall go down in the camp. And he went down, he and Phurah his servant, into a portion of the fifty companies of the ones in the camp. 

#### Judges 7:12 And Midian and Amalek and all the sons of the east were encamped in the valley as locust in multitude; and {to their camels there was no number}, but they were as if the sand upon the edge of the sea in multitude. 

#### Judges 7:13 And Gideon came, and behold, a man was describing to his neighbor a dream. And he said, Behold, I dreamed a dream. And behold, a loaf of bread of barley was rolling in the camp of Midian, and it came unto the tent of Midian, and it struck it, and it overturned it, and {fell the tent}. 

#### Judges 7:14 And {answered his neighbor} and said, {not This is} other than the broadsword of Gideon son of Joash, a man of Israel. God delivered up {into his hand Midian}, and all the camp. 

#### Judges 7:15 And it came to pass as Gideon heard the description of the dream, and its interpretation, that he did obeisance to the LORD, and he returned into the camp of Israel. And he said, Rise up! for the LORD delivered up into your hands the camp of Midian. 

#### Judges 7:16 And he divided the three hundred men into three companies, and he put horns into the hand of all, and {water-pitchers empty}, and lamps in the middle of the water-pitchers. 

#### Judges 7:17 And he said to them, Of me you shall see, and thus shall you do. And behold, I will enter into the midst of the camp, and it will be as whenever I shall act, so shall you act. 

#### Judges 7:18 When I shall trump with the horn, I and all with me, then you shall trump with the horns round about the entire camp, and you shall say, For the LORD and for Gideon. 

#### Judges 7:19 And Gideon entered, and the hundred men, the ones with him, into the rank of the camp command of the guard of the middle watch; furthermore rising they roused the ones guarding. And they trumped the horns, and shook off the water-pitchers, the ones in their hands. 

#### Judges 7:20 And {trumped the three companies} with the horns, and they broke the water-pitchers, and took {in hand their left the lamps}, and in {hand their right} was the horns to trump. And they shouted aloud, A broadsword for the LORD and for Gideon. 

#### Judges 7:21 And they stood, each man by himself, round about the camp; and they ran around all the camp, and they signified by an alarm -- and they fled. 

#### Judges 7:22 And they trumped the three hundred horns. And the LORD placed {sword every man's} against his neighbor, even in the whole camp. And {fled the camp} unto Beth-shittah Zererath, unto the edge of Abel-meholah by Tabbath. 

#### Judges 7:23 And {called for aid the man of Israel} of Naphtali, and of Asher, and of all Manasseh; and they pursued after Midian. 

#### Judges 7:24 And {messengers sent out Gideon} to every mountain of Ephraim, saying, Go down to meet Midian, and overtake for yourselves the water unto Beth-barah and the Jordan! And {yelled out every man of Ephraim} and were first to take the water unto Beth-barah and the Jordan. 

#### Judges 7:25 And they seized the two rulers of Midian -- Oreb and Zeeb; and they killed Oreb in Sur, and Zeeb they killed in Jakeb Zeeb. And they pursued Midian. And the head of Oreb, and of Zeeb they brought to Gideon from the other side of the Jordan. 

#### Judges 8:1 And {said to him a man of Ephraim}, What is this thing you do to us, to not call us when you went to deploy against Midian? And they quarreled with him forcefully. 

#### Judges 8:2 And he said to them, What did I do now as concerning you? Is not {better the gleaning of Ephraim} than the gathering the crops of Abiezer? 

#### Judges 8:3 In your hand {delivered up the LORD} the rulers of Midian -- Oreb and Zeeb; and what was I able to do as you? Then {was spared their spirit} towards them in his speaking with them this word. 

#### Judges 8:4 And Gideon came upon the Jordan, and he passed over and the three hundred men, the ones with him, faint-hearted and hungering. 

#### Judges 8:5 And he said to the men of Succoth, Give indeed bread loaves for the nourishment to this people with me! for they hunger, for I pursue after Zebah and Zalmunna, kings of Midian. 

#### Judges 8:6 And {said the rulers of Succoth}, {is not The hand of Zebah and Zalmunna} now in your hand, that we should give {to your military bread loaves}. 

#### Judges 8:7 And Gideon said, Thus in the giving by the LORD Zebah and Zalmunna into my hand, that I will rend in shreds your flesh with the thorn-bushes of the wilderness, and with the Barkenim. 

#### Judges 8:8 And he ascended from there to Penuel, and spoke to them according to these things. And {answered to him the men of Penuel} in which manner {answered to him the men of Succoth}. 

#### Judges 8:9 And Gideon said to the men of Penuel, saying, In my returning with peace, I will raze this tower. 

#### Judges 8:10 And Zebah and Zalmunna were in Karkor, and their camp with them, about fifteen thousand, all the ones being left in all the camp of the sons of the east. And the ones falling were a hundred and twenty thousand men unsheathing the broadsword. 

#### Judges 8:11 And Gideon ascended the way of the ones dwelling in tents from the east of Nobah and Jogbehah, and he struck the camp. And the camp was secure. 

#### Judges 8:12 And Zebah fled, and Zalmunna. And he pursued after them, and he took hold of the two kings of Midian, Zebah and Zalmunna, and all their camp was startled. 

#### Judges 8:13 And {returned Gideon the son of Joash} from the battle from the ascent of Ares. 

#### Judges 8:14 And he seized a servant from the men of Succoth, and he questioned him; and he registered for him the rulers of Succoth, and their elders -- seventy and seven men. 

#### Judges 8:15 And he came to the rulers of Succoth. And he said to them, Behold, Zebah and Zalmunna, by whom you berated me, saying, Not is the hand of Zebah and Zalmunna now in your hand, that we will give {to your men fainting bread loaves}. 

#### Judges 8:16 And he took the rulers and the elders of the city into the thorn-bushes of the wilderness, and the Barkenim, and he rent with them the men of Succoth. 

#### Judges 8:17 And the tower of Penuel he razed, and he killed the men of the city. 

#### Judges 8:18 And he said to Zebah and Zalmunna, What manner are the men whom you killed in Tabor? And they said, As you, so they are likened to you -- likened to them as the appearance of sons of kings. 

#### Judges 8:19 And Gideon said, {of my brothers sons of my mother They are}. As the LORD lives, if you brought them forth alive, I would not have killed you. 

#### Judges 8:20 And he said to Jether his first-born, In rising up, you kill them! And {did not unsheathe the boy} his sword, for he feared, for he was younger. 

#### Judges 8:21 And {said Zebah and Zalmunna}, You rise up indeed yourself and meet us! for as a man is, so also his power. And Gideon rose up, and did away with Zebah and Zalmunna. And he took the crescents on the necks of their camels. 

#### Judges 8:22 And {said a man of Israel} to Gideon, Rule among us, you and your son, and the son of your son! for you have delivered us from the hand of Midian. 

#### Judges 8:23 And {said to them Gideon}, {will not rule I} you, and {will not rule my son} among you -- the LORD shall rule you. 

#### Judges 8:24 And {said to them Gideon}, I will ask from you a request, and you give to me -- every man an ear-ring of his spoils; for ear-rings of gold was to them, because they were Ismaelites. 

#### Judges 8:25 And they said, In giving we will give. And he unfolded his garment, and {tossed there each man} an ear-ring of his spoils. 

#### Judges 8:26 And was the weight of the ear-rings of gold which he asked for -- {shekels a thousand and seven hundred} of gold, besides the ornaments of the crescents, and the wrap around garments of the ones of purple, of the ones upon the kings of Midian, even besides the collars of the ones on the necks of their camels. 

#### Judges 8:27 And {made to himself Gideon} for an ephod, and set it in his city, in Ophrah. And {fornicated all Israel} after it there. And it became {to Gideon and his house an obstacle}. 

#### Judges 8:28 And Midian was in remorse before the sons of Israel, and they did not proceed yet to lift their head; and {was tranquil the land} forty years in the days of Gideon. 

#### Judges 8:29 And {went Jerubbaal son of Joash} and dwelt in his house. 

#### Judges 8:30 And to Gideon there were seventy sons going forth from out of his thighs, for {wives many there were} to him. 

#### Judges 8:31 And his concubine in Shechem, {bore to him also indeed she} a son, and put upon him his name -- Abimelech. 

#### Judges 8:32 And {died Gideon the son of Joash} with {grayness of hair good}. And he was entombed in the burying-place of Joash his father, in Ophrah of the Abi-ezrites. 

#### Judges 8:33 And it came to pass as Gideon died, that {returned the sons of Israel} and fornicated after the Baalim, and established to themselves Baal-berith for a covenant, {to be to them for him} for god. 

#### Judges 8:34 And {did not remember the sons of Israel} the LORD their God, the one rescuing them from out of the hand of all their enemies round about. 

#### Judges 8:35 And they did not do mercy with the house of Jerubbaal -- Gideon, according to all the goodness which he did with Israel. 

#### Judges 9:1 And {went Abimelech the son of Jerubbaal} into Shechem to the brothers of his mother. And he spoke to them, and to all the kin of the house {father of his mother's}, saying, 

#### Judges 9:2 Speak indeed into the ears of all the men of Shechem, saying, Which is best to you, {to rule you for seventy men}, all the sons of Jerubbaal, or {to dominate you man for one}? And you should remember that {of your bone and of your flesh I am}. 

#### Judges 9:3 And {spoke concerning him the brothers of his mother} in the ears of all of the men of Shechem all these words. And {leaned their heart} after Abimelech; for they said, {our brother He is}. 

#### Judges 9:4 And they gave to him seventy pieces of silver from out of the house of Baal-berith; and {hired for them Abimelech men vain and distraught}, and they went behind him. 

#### Judges 9:5 And he entered to the house of his father at Ophrah, and he killed his brothers, the sons of Jerubbaal, seventy men upon {stone one}. But {was left behind Jotham son of Jerubbaal the younger}, for he was hidden. 

#### Judges 9:6 And came together all the men of Shechem, and all the house of Millo, and they went and gave reign to Abimelech as king at the acorn tree of the station, of the one in Shechem. 

#### Judges 9:7 And they announced to Jotham, and he went, and stood on the top of mount Gerizim, and he lifted up his voice, and he called, and he said to them, Hear me men of Shechem! and {shall hear you God}. 

#### Judges 9:8 In going, {went forth the trees} to anoint for themselves a king. And they said to the olive tree, You reign over us! 

#### Judges 9:9 And {said to them the olive tree}, Allowing my fatness which {in me glorified God}, and men, shall I go to rule over the trees? 

#### Judges 9:10 And {said the trees} to the fig-tree, Come, you reign over us! 

#### Judges 9:11 And {said to them the fig-tree}, Allowing my sweetness and {produce my good}, should I go to rule the trees? 

#### Judges 9:12 And {said the trees} to the grapevine, Come, you reign over us! 

#### Judges 9:13 And {said to them the grapevine}, Allowing my wine, the gladness of God, and of the ones of men, should I go to rule over the trees? 

#### Judges 9:14 And {said all the trees} to the white-thorn shrub, Come, You reign over us! 

#### Judges 9:15 And {said the white-thorn shrub} to the trees, If in truth you anoint me yourselves to reign over you, come rely in my protection; and if not may {come forth fire} from the white-thorn shrub, and may it devour the cedars of Lebanon. 

#### Judges 9:16 And now, if in truth and in soundness you made even Abimelech reign, and if {well you did} with Jerubbaal, and with his house, and if according to the recompense of his hand you did to him, 

#### Judges 9:17 as {waged war my father} for you, and tossed his life right opposite, and rescued you from out of the hand of Midian; 

#### Judges 9:18 and you rose up against the house of my father today, and you killed his sons, seventy men upon {stone one}; and you gave reign to Abimelech the son of his maidservant over the men of Shechem, because {your brother he is}; 

#### Judges 9:19 and if {in truth and perfection you acted} with Jerubbaal, and his house in this day, may you be glad in Abimelech, and may he be glad also indeed himself in you. 

#### Judges 9:20 If not, may {come forth fire} from Abimelech, and devour the men of Shechem, and the house Millo; and may {come forth fire} from the men of Shechem, and from out of the house of Millo, and devour Abimelech. 

#### Judges 9:21 And Jotham ran away and fled, and went unto Beer, and dwelt there away from the face of Abimelech his brother. 

#### Judges 9:22 And Abimelech ruled over Israel three years. 

#### Judges 9:23 And God sent {spirit a bad} between Abimelech and between the men of Shechem; and {annulled allegiance the men of Shechem} with the house of Abimelech; 

#### Judges 9:24 so as to bring the injustice done to the seventy sons of Jerubbaal, and for their blood to be put upon Abimelech their brother the one killing them; and upon the men of Shechem, of the ones strengthening their hands so as to kill his brothers. 

#### Judges 9:25 And {put for him the men of Shechem} ones lying in wait upon the top of the mountains. And they kidnapped all the ones going along by them in the way; and it was reported to Abimelech. 

#### Judges 9:26 And {came Gaal the son of Ebed} and his brothers, and they went unto Shechem; and {relied in him the men of Shechem}. 

#### Judges 9:27 And they went forth into the field, and gathered the vintage of their vineyards, and they treaded, and they made a dance, and they entered into the house of their god, and they ate and drank, and they cursed Abimelech. 

#### Judges 9:28 And {said Gaal son of Ebed}, Who is Abimelech, and who is the son of Shechem, that we shall serve to him? Is he not the son of Jerubbaal, and Zebul his overseer, his manservant with the men of Hamor, father of Shechem? And why is it that we shall serve to him ourselves? 

#### Judges 9:29 And if any should give this people into my hand, then I shall remove Abimelech. And I shall say to Abimelech, Multiply your force, and come forth! 

#### Judges 9:30 And {heard Zebul the ruler of the city} the words of Gaal son of Ebed, and he was enraged in anger. 

#### Judges 9:31 And he sent messengers to Abimelech with bribes, saying, Behold, Gaal the son of Ebed, and his brothers have come unto Shechem; and know, they assault the city against you. 

#### Judges 9:32 And now rise up at night, you and the people with you, and lie in wait in the field! 

#### Judges 9:33 And it will be in the morning, together with the rising of the sun, that you shall rise early and stretch out against the city. And behold, he and the people with him go forth against you, and you shall do to him just as {should find opportunity your hand}. 

#### Judges 9:34 And Abimelech rose up, and all the people with him at night, and they laid in wait at Shechem -- four companies. 

#### Judges 9:35 And {came forth Gaal son of Ebed}, and he stood at the door of the gate of the city. And Abimelech rose up, and all the people with him, from the ambush. 

#### Judges 9:36 And {saw Gaal son of Ebed} the people. And he said to Zebul, Behold, a people coming from the tops of the mountains. And {said to him Zebul}, The shadow of the mountains you see as men. 

#### Judges 9:37 And {proceeded still Gaal} to speak, and said, Behold, a people coming down as a sea from the part next to the navel of the earth, and {company one} arrives from the way of the Oak of the Seers. 

#### Judges 9:38 And {said to him Zebul}, Where is your mouth, the one saying, Who is Abimelech, that we will serve him? {not Is this} the people whom you treated with contempt? Go forth indeed now and wage war with him! 

#### Judges 9:39 And Gaal went forth from the presence of the men of Shechem, and he made war against Abimelech. 

#### Judges 9:40 And {pursued him Abimelech}, and he fled from his face, and there fell slain many unto the doors of the city. 

#### Judges 9:41 And Abimelech settled in Arumah, and Zebul cast out Gaal and his brethren, so as to not live in Shechem. 

#### Judges 9:42 And it came to pass in the next day, and came forth the people into the plain, and reported to Abimelech. 

#### Judges 9:43 And he took the people, and he divided them into three companies, and he laid in wait in the field. And he watched, and behold, a people came forth from out of the city, and he rose up against them and struck them. 

#### Judges 9:44 And Abimelech and companies, the ones with him, stretched out and stood by the door of the gate of the city, and the two companies poured out upon all the ones in the field, and he struck them. 

#### Judges 9:45 And Abimelech made war against the city {entire day that}. And they overtook the city, and the people in it they killed; and he demolished the city and sowed it with salt. 

#### Judges 9:46 And {heard all the men of the tower of Shechem}, and they entered into the fortress of the house of Bethel-berith. 

#### Judges 9:47 And it was announced to Abimelech that {were brought together all the men of the tower of Shechem}. 

#### Judges 9:48 And Abimelech ascended into mount Zalmon, he and all the people with him. And Abimelech took the axe in his hand, and he cut a load of wood, and he took it, and put it upon his shoulders. And he said to the people with him, What you see me doing, quickly you do as also I! 

#### Judges 9:49 And they felled wood. And indeed to them all each was a load. And they lifted, and they went after Abimelech. And they placed the wood at the fortress, and they set fire to them at the fortress with fire. And all died, the men of the tower of Shechem, about a thousand men and women. 

#### Judges 9:50 And Abimelech went unto Thebez, and besieged it, and first took it. 

#### Judges 9:51 And {tower a strong there was} in the midst of the city. And fled there all the men, and the women, and all the leaders of the city. And they shut up themselves, and ascended upon the roof of the tower. 

#### Judges 9:52 And Abimelech came unto the tower, and they subdued it by war. And Abimelech approached unto the door of the tower to burn it with fire. 

#### Judges 9:53 And {tossed a woman} one piece of millstone upon the head of Abimelech, and it fractured his skull. 

#### Judges 9:54 And he yelled out quickly to the servant lifting his weapons. And he said to him, Unsheathe my broadsword and kill me! lest at any time they should say that, A woman killed him. And {stabbed him his servant}, and he died. 

#### Judges 9:55 And {saw each man of Israel} that Abimelech died, and {departed each man} to his place. 

#### Judges 9:56 And God returned the evil of Abimelech, which he did to his father, by killing {seventy brothers his}. 

#### Judges 9:57 And all the evil of the men of Shechem, God returned on their own head. And came upon them the curse of Jotham the son of Jerubbaal. 

#### Judges 10:1 And rose up after Abimelech to deliver Israel, Tola son of Phua, son of his uncle, a man of Issachar; and he dwelt in Shamir in mount Ephraim. 

#### Judges 10:2 And he judged Israel twenty and three years, and he died, and he was entombed in Shamir. 

#### Judges 10:3 And rose up after him Jair the Gileadite; and he judged Israel twenty and two years. 

#### Judges 10:4 And there were born to him thirty sons mounted upon thirty foals. And thirty cities were his, and they called them, Properties of Jair until this day, the ones which are in the land of Gilead. 

#### Judges 10:5 And Jair died and was entombed in Camon. 

#### Judges 10:6 And {proceeded the sons of Israel} to do wickedly before the LORD, and they served to the Baalim, and to the Ashtaroths, and to the gods of Syria, and to the gods of Sidon, and to the gods of Moab, and to the gods of the sons of Ammon, and to the gods of the Philistines; and they abandoned the LORD, and did not serve to him. 

#### Judges 10:7 And {was enraged in anger the LORD} against Israel, and he gave them into the hand of the Philistines, and into the hand of the sons of Ammon. 

#### Judges 10:8 And they disintegrated and crushed the sons of Israel in that time -- eighteen years, all of the sons of Israel on the other side of the Jordan, in the land of the Amorite, in Gilead. 

#### Judges 10:9 And {passed over the sons of Ammon} the Jordan to wage war even against Judah and Benjamin, and against the house of Ephraim; and they afflicted the sons of Israel exceedingly. 

#### Judges 10:10 And {cried out the sons of Israel} to the LORD, saying, We sinned against you, for we abandoned our God, and we served to the Baalim. 

#### Judges 10:11 And the LORD said to the sons of Israel, Is it not the Egyptians, and the Amorites, and the sons of Ammon, and Moab, and the Philistines, 

#### Judges 10:12 and Sidonians, and Amalek, and Canaan that squeeze you out? and you cried out to me, and I delivered you from out of their hand. 

#### Judges 10:13 And you abandoned me, and served other gods. On account of this I will not proceed to deliver you. 

#### Judges 10:14 Proceed and yell to the gods whom you chose for yourselves, and let them deliver you in the time of your affliction! 

#### Judges 10:15 And {said the sons of Israel} to the LORD, We sinned, do to us according to all whatever as much as should be pleasing before you, only rescue us in this day! 

#### Judges 10:16 And they removed {gods the alien} from their midst, and they served to the LORD. And he was faint-hearted over the toil of Israel. 

#### Judges 10:17 And there ascended up the sons of Ammon, and they camped in Gilead. And {came forth the sons of Israel} and camped in Mizpeh. 

#### Judges 10:18 And {said the people}, and the rulers of Gilead, each man to his neighbor, Who is the man who shall begin to wage war with the sons of Ammon, for he shall be head to all the ones dwelling in Gilead? 

#### Judges 11:1 And Jephthah the Gileadite was mighty in strength. And he was the son {woman of a harlot}. And she bore {to Gilead Jephthah}. 

#### Judges 11:2 And {bore the wife} to Gilead himself sons. And {matured the sons of the woman}, and they cast out Jephthah, and said to him, You shall not inherit among the house of our father, for {a son woman of a mistress you are}. 

#### Judges 11:3 And Jephthah ran away from the face of his brothers, and he dwelt in the land of Tob. And {collected together with Jephthah men cheap}, and went forth together with him. 

#### Judges 11:4 And it came to pass after some days, that {waged war the sons of Ammon} against Israel. And it came to pass when {waged war the sons of Ammon} with Israel, 

#### Judges 11:5 that {went forth the elders of Gilead} to take Jephthah from the land of Tob. 

#### Judges 11:6 And they said to Jephthah, Come, and you will be to us as a leader, for we shall make war with the sons of Ammon. 

#### Judges 11:7 And Jephthah said to the elders of Gilead, Did you not detest me, and cast me from out of the house of my father, and sent me from you? And why is it that you came to me now when you are afflicted? 

#### Judges 11:8 And {said the elders of Gilead} to Jephthah, Not so, now we gathered together to you, and you shall go with us, and we shall wage war against the sons of Ammon, and you will be to us as head to all the ones dwelling in Gilead. 

#### Judges 11:9 And Jephthah said to the elders of Gilead, If you return me to yourselves to make war against the sons of Ammon, and {should deliver the LORD} them before me, I will be to you for head ruler. 

#### Judges 11:10 And {said the elders of Gilead} to Jephthah, Let the LORD be the one hearing between us! if we do not do according to your word thus we will do. 

#### Judges 11:11 And Jephthah went with the elders of Gilead, and {established the people} him over them as head, and for leader. And Jephthah spoke all his words before the LORD in Mizpeh. 

#### Judges 11:12 And Jephthah sent messengers to the king of the sons of Ammon, saying, What is it to me and to you, that you come to me to wage war in my land? 

#### Judges 11:13 And {said the king of the sons of Ammon} to the messengers of Jephthah, Because Israel took my land in their ascending from out of Egypt, from Arnon unto Jabok, and unto the Jordan. And now return them with peace! 

#### Judges 11:14 And {added Jephthah again}, and he sent messengers to the king of the sons of Ammon. 

#### Judges 11:15 And they said to him, Thus says Jephthah, {did not take Israel} the land of Moab, and the land of the sons of Ammon. 

#### Judges 11:16 In their ascending from out of Egypt, it is that Israel went in the wilderness unto {sea the red}, and came to Kadesh. 

#### Judges 11:17 And Israel sent messengers to the king of Edom, saying, I shall go through your land. And {did not hearken the king of Edom}, and indeed to the king of Moab Israel sent, and he would not, and Israel settled in Kadesh. 

#### Judges 11:18 And Israel went through in the wilderness, and encircled the land of Edom and the land of Moab. And it arrived according to the rising of the sun of the land of Moab, and camped on the other side of Arnon, and did not enter into the border of Moab. 

#### Judges 11:19 And {sent messengers Israel} to Sihon king of the Amorites, king of Heshbon. And {said to him Israel}, I shall go by through your land unto my place. 

#### Judges 11:20 And {did not want Sihon} Israel to go through his borders. And Sihon gathered all his people, and they camped at Jahaz, and he waged war with Israel. 

#### Judges 11:21 And {delivered up the LORD God of Israel} Sihon and all his people into the hand of Israel, and they struck them, and Israel inherited all the land of the Amorites dwelling in that land. 

#### Judges 11:22 And Israel inherited all the border of the Amorites, from Arnon and unto the Jabok, and from the wilderness unto the Jordan. 

#### Judges 11:23 And now the LORD God of Israel lifted away the Amorite from the face of his people Israel, and you, shall you inherit it? 

#### Judges 11:24 Is it not that as much as {allots to you Chemosh your god}, them you will inherit? And all as much as {inherits the LORD our God} from your person we shall inherit them. 

#### Judges 11:25 And now {any better are you} than Balak son of Sephor king of Moab? Did he with battle do combat with Israel, or by war wage war with them? 

#### Judges 11:26 In the living of Israel in Heshbon, and in her daughter cities, and in Aroer, and in her daughter cities, and in all the cities by the Jordan for three hundred years -- Why is it that you did not rescue them in that time? 

#### Judges 11:27 And I sinned not against you, but you do {with me wickedness} to wage war against me. May the LORD judge, the one judging today, between the sons of Israel and between the sons of Ammon. 

#### Judges 11:28 And {would not hearken to the king of the sons of Ammon} the words of Jephthah which he sent to him. 

#### Judges 11:29 And {became upon Jephthah spirit of the LORD}, and he passed over Gilead, and Manasseh, and he passed over the height of Gilead, and from the height of Gilead to the other side of the sons of Ammon. 

#### Judges 11:30 And Jephthah vowed a vow to the LORD, and he said, If by delivering up you should deliver up the sons of Ammon in my hand, 

#### Judges 11:31 then it will be concerning the one going forth, who ever might come from the doors of my house for meeting me in my returning in peace from the sons of Ammon, that it will be to the LORD, and I will offer him a whole burnt-offering. 

#### Judges 11:32 And Jephthah passed over to the sons of Ammon to wage war against them. And {delivered them the LORD} into his hand. 

#### Judges 11:33 And he struck them from Aroer even unto the coming to Minnith -- twenty cities, and unto the Abel vineyards, {beating great an exceedingly}. And {showed respect the sons of Ammon} in front of the sons of Israel. 

#### Judges 11:34 And Jephthah came to Mizpeh to his house. And behold, his daughter went forth for meeting him with tambourines and dancers, and she was an only child. And there was not to him {besides her a son or daughter}. 

#### Judges 11:35 And it happened when he beheld her, that he tore his garments, and said, Alas my daughter you impede me, for {an impediment you became} in my eyes, and I opened my mouth concerning you to the LORD, and I shall not be able to turn back. 

#### Judges 11:36 And she said to him, If about me you opened your mouth to the LORD, let him do to me in which manner it came forth from out of your mouth, because {did for you the LORD vengeance} on your enemies, of the sons of Ammon. 

#### Judges 11:37 And she said to her father, And do to me this thing! Allow me two months and I shall go and shall come down upon the mountains, and I shall weep over the tokens of my virginity, I and my female companions. 

#### Judges 11:38 And he said, Go! And he sent her out for two months. And she went, she and her female companions. And they wept over the tokens of her virginity upon the mountains. 

#### Judges 11:39 And it came to pass after the end of the two months, that she returned to her father, and Jephthah completed his vow which he vowed. And she did not know a man. And it became an order in Israel, 

#### Judges 11:40 from days unto days {go with one another the daughters of Israel} to wail over the daughter of Jephthah the Gileadite four days in the year. 

#### Judges 12:1 And {gathered together the sons of Ephraim}, and they came to Zaphon, and said to Jephthah, Why is it that you went to wage war against the sons of Ammon, and {us you did not call} to go with you? {your house We will burn} over you with fire. 

#### Judges 12:2 And Jephthah said to them, {a man pleading I was}, and my people, and the sons of Ammon humbled me exceedingly, and I yelled out to you, and you did not deliver me from out of their hand. 

#### Judges 12:3 And I saw that there was no one delivering, and I put my life in my hand, and I passed over to the sons of Ammon, and {delivered them over the LORD} into my hand. And why did you ascend against me in this day to wage war against me? 

#### Judges 12:4 And Jephthah gathered together all the men of Gilead, and waged war against Ephraim. And {struck the men of Gilead} Ephraim; for {said the men coming through safe of Ephraim}, You are Gilead in the midst of Ephraim, and in the midst of Manasseh. 

#### Judges 12:5 And Gilead was first to take the ford of the Jordan of Ephraim. And it came to pass when {said to them the ones coming through safe of Ephraim}, We should pass over indeed! That {said to them the men of Gilead}, {not of Ephraim Are you}? And they said, We are not. 

#### Judges 12:6 Then they said to them, Say indeed, Stachys! And if he was not straightly able to speak thus, then they would take hold of them, and slay them at the ford of the Jordan. And they that fell from Ephraim in that time were forty and two thousand. 

#### Judges 12:7 And Jephthah judged Israel six years. Then {died Jephthah the Gileadite}, and he was entombed in his city Gilead. 

#### Judges 12:8 And {judged after him Israel Ibzan of Beth-lehem}. 

#### Judges 12:9 And there were to him thirty sons, and thirty daughters being sent out, and {thirty wives he brought in} for his sons from outside. And he judged Israel seven years. 

#### Judges 12:10 And Ibzan died, and he was entombed in Beth-lehem. 

#### Judges 12:11 And {judged after him Israel Elon the Zebulunite}, and he judged Israel ten years. 

#### Judges 12:12 And {died Elon the Zebulunite}, and was entombed in Aijalon in the land of Zebulun. 

#### Judges 12:13 And {judged after him Israel Abdon son of Hillel the Pirathonite}. 

#### Judges 12:14 And there were to him forty sons, and thirty sons of his sons being mounted upon seventy foals. And he judged Israel eight years. 

#### Judges 12:15 And {died Abdon the son of Hillel the Pirathonite}, and he was entombed in Pirathon in the land of Ephraim, in the mountain of Amalek. 

#### Judges 13:1 And {proceeded still the sons of Israel} to act wickedly before the LORD, and {delivered them the LORD} into the hand of the Philistines -- forty years. 

#### Judges 13:2 And there was {man one} from Zorah, from the tribe of Dan, and the name to him was Manoah, and his wife was sterile, and had not given birth. 

#### Judges 13:3 And {appeared an angel of the LORD} to the woman, and he said to her, Behold indeed, you are sterile, and have not borne; but {in the womb you shall have one}, and shall bear a son. 

#### Judges 13:4 And now guard and do not drink wine and liquor, and do not eat any unclean thing! 

#### Judges 13:5 For behold, you {in the womb have one}, and you shall bear a son, and an iron razor shall not ascend upon his head, for {a Nazarite to God will be the boy} from the womb; and he shall begin to deliver Israel from out of the hand of the Philistines. 

#### Judges 13:6 And {went in the woman} and said to her husband, saying, A man of God came to me, and his appearance was as the appearance of an angel of God -- {prominent very}. And I did not ask him from what place he is, and his name he did not report to me. 

#### Judges 13:7 And he said to me, Behold, you {in the womb have one}, and you shall give birth to a son. And now do not drink wine and strong drink, and do not eat any uncleanness! for {a Nazarite of God will be the boy} from the womb until the day of his death. 

#### Judges 13:8 And Manoah besought of the LORD. And he said, Be to me, O LORD, the man of God whom you sent, let him come yet once more to us and enlighten us! what we should do with the boy to be born. 

#### Judges 13:9 And God heeded the voice of Manoah; and {came the angel of God} again to the woman. And she sat in the field, and Manoah her husband was not with her. 

#### Judges 13:10 And {hastened the woman}, and ran, and reported to her husband, and she said to him, Behold, {has appeared to me the man}, the one coming in this day to me. 

#### Judges 13:11 And {rose up and went Manoah} after his wife. And he came to the man, and said to him, Are you the man speaking to the woman? And {said the angel}, I am. 

#### Judges 13:12 And Manoah said, Now, {going through your word}, what will be the distinguishing manner of the boy, and his works? 

#### Judges 13:13 And {said the angel of the LORD} to Manoah, Of all which I spoke to the woman, let her guard! 

#### Judges 13:14 From every thing which goes forth from out of the grapevine, she shall not eat, and wine and liquor she shall not drink, and every thing unclean she shall not eat; all as much as I gave charge to her, let her guard! 

#### Judges 13:15 And Manoah said to the angel of the LORD, We should indeed force you to stay, and shall prepare before you a kid of the goats. 

#### Judges 13:16 And {said the angel of the LORD} to Manoah, If it should hold me I will not eat from your bread loaves. And if you should offer a whole burnt-offering, {to the LORD you shall offer it}. For {did not know Manoah} that {an angel of the LORD he was}. 

#### Judges 13:17 And Manoah said to the angel of the LORD, What is the name to you, that whenever {should come to pass your word} that we should glorify you? 

#### Judges 13:18 And {said to him the angel of the LORD}, Why is this you ask of my name, for it is Wonderful? 

#### Judges 13:19 And Manoah took the kid of the goats, and the sacrifice offering, and he offered it upon the rock to the LORD, to the wonderful thing being done; and Manoah and his wife were viewing. 

#### Judges 13:20 And it happened in the {ascending flame} on top of the altar unto the heaven, that {ascended the angel of the LORD} in the flame of the altar. And Manoah and his wife were viewing, and they fell upon their face upon the ground. 

#### Judges 13:21 And {did not proceed any longer the angel of the LORD} to appear to Manoah and to his wife. Then Manoah knew that {an angel of the LORD this was}. 

#### Judges 13:22 And Manoah said to his wife, To death we shall die, for we have looked at God. 

#### Judges 13:23 And {said to him his wife}, If {wanted the LORD} to kill us, he would not have received from our hand a whole burnt-offering and a sacrifice offering, and he would not have enlightened us all these things, even as this time, and he would not {audible have made to us these things}. 

#### Judges 13:24 And {bore the woman} a son, and she called his name Samson. And {grew the boy}, and {blessed him the LORD}. 

#### Judges 13:25 And {began spirit of the LORD} to go forth with him in the camp of Dan, between Zorah and between Eshtaol. 

#### Judges 14:1 And Samson went down unto Timnath, and he saw a woman in Timnath from the daughters of the Philistines. 

#### Judges 14:2 And he ascended, and reported to his father and to his mother. And he said, {a woman I have seen} in Timnath from the daughters of the Philistines. And now take her to me for wife! 

#### Judges 14:3 And {said to him his father}, and his mother, Is it that there is not {of the daughters of your brethren and among all my people a woman}, that you should go to take a wife from the {Philistines uncircumcised}? And Samson said to his father, Take this one for me! for she pleases in my eyes. 

#### Judges 14:4 And his father and his mother did not know that {from the LORD it is}, that {recompense he required} of the Philistines. And in that time the Philistines dominated the sons of Israel. 

#### Judges 14:5 And Samson went down, and his father and his mother unto Timnath. And he came to the vineyards of Timnath. And behold, a cub of a lion was roaring in meeting him. 

#### Judges 14:6 And {straightened upon him spirit of the LORD}, and he tore it apart as a kid of the goats, and nothing was in his hand. And he did not report to his father and to his mother what he did. 

#### Judges 14:7 And they went down and spoke to the woman, and she was pleasing before Samson. 

#### Judges 14:8 And he returned after some days to take her, and he turned aside to behold the carcass of the lion. And behold, a swarm as of an apiary of bees was in the mouth of the lion, and honey. 

#### Judges 14:9 And he took of it into his mouth, and went forth going and eating. And he went to his father and to his mother, and he gave to them, and they ate, and he did not announce to them that {from the manner of the lion he took the honey}. 

#### Judges 14:10 And {went down his father} to the woman, and {prepared there Samson} a banquet for seven days; for thus {did the young men}. 

#### Judges 14:11 And it came to pass in their fearing him, that they posted in front to him thirty companions, and they were with him. 

#### Judges 14:12 And {said to them Samson}, I will propound indeed to you a riddle, and if by reporting you should report it to me in the seven days of the banquet, and you should find the solution, I will give to you thirty pieces of fine linen, and thirty robes of clothes. 

#### Judges 14:13 And if you should not be able to report the solution to me, then you shall give to me yourselves thirty pieces of fine linen, and thirty robes of clothes. And they said to him, Propound your riddle, and we shall hear it! 

#### Judges 14:14 And he said to them, From the one eating came forth food, and from the strong came forth sweetness. And they were not able to explain the riddle for three days. 

#### Judges 14:15 And it came to pass in the {day seventh}, and they spoke to the wife of Samson, saying, Deceive indeed your husband! and let him explain to you the riddle, lest at any time we should burn you and the house of your father by fire; or {to make us poor did you call us}? 

#### Judges 14:16 And {wept the wife of Samson} to him, and said to him, You detest me, and do not love me, because the riddle which you propounded to the sons of my people, you did not explain even it to me. And {said to her Samson}, Behold, to my father and to my mother I did not report it, and should I report to you? 

#### Judges 14:17 And she wept upon him for the seven days in which {was to them the banquet}. And it came to pass on the {day seventh} he explained to her, for she troubled him. And she reported to the sons of her people. 

#### Judges 14:18 And {said to him the men of the city} on the {day seventh} before {going down the sun}, What is sweeter than honey, and what is stronger than a lion? And {said to them Samson}, Unless you plowed by my heifer, you would not have found my riddle. 

#### Judges 14:19 And {straightened upon him spirit of the LORD}, and he went down unto Ashkelon, and smote from there thirty men, and took their robes, and gave them to the ones explaining the riddle. And {was enraged in anger Samson}, and he ascended into the house of his father. 

#### Judges 14:20 And {lived with the wife of Samson} his groomsman who was his companion. 

#### Judges 15:1 And it came to pass after some days, at the days {harvest of the wheat}, that Samson visited his wife, carrying a kid of the goats. And he said, I shall enter to my wife into the bedroom. But {would not grant him her father} to enter. 

#### Judges 15:2 And {said her father}, In saying, I said that, By detesting you detested her; and I gave her to your companion. {not Behold sister her younger better than she is}? Let her be to you instead of her! 

#### Judges 15:3 And {said to him Samson}, I am innocent this once concerning the Philistines, that I myself should do {with you evils}. 

#### Judges 15:4 And Samson went and seized three hundred foxes, and took lamps, and tied together tail to tail, and put {lamp one} between the two tails, and guided them. 

#### Judges 15:5 And he kindled fire in the lamps, and he sent them out in the ears of corn of the Philistines. And he burned the ears of corn from the threshing-floor, and unto {ears of corn the straight standing}, and unto the vineyard, and olive orchards. 

#### Judges 15:6 And {said the Philistines}, Who did these things? And they said, Samson, the son-in-law of the Timnite, because he took his wife, and he gave her to his male companion. And {ascended up the Philistines} and burnt her and the house of her father by fire. 

#### Judges 15:7 And {said to them Samson}, Since you should do thus, I shall not think well, but {my vengeance against one each of you I will execute}. 

#### Judges 15:8 And he struck them leg on thigh {beating with a great}. And he went down and sat at the hole in the rock of Etam. 

#### Judges 15:9 And {ascended the Philistines} and camped in Judah, and cast forth about Lehi. 

#### Judges 15:10 And {said to them every man of Judah}, Why have you ascended against us? And {said the Philistines}, {to tie up Samson We ascended}, and to do to him in which manner he did to us. 

#### Judges 15:11 And {went down three thousand men of Judah} unto the hole in the rock of Etam, and said to Samson, Do you not behold that {dominate the Philistines} us? Then why {these things did you do} to us? And {said to them Samson}, In which manner they did to me, so I did to them. 

#### Judges 15:12 And they said to him, {to tie you We came down}, to deliver you up into the hands of the Philistines. And {said to them Samson}, Swear to me by an oath to not kill me yourselves, that lest at any time you should meet up with me yourselves. 

#### Judges 15:13 And they swore by an oath to him, saying, No, but only by a bond will we tie you, for we should deliver you up into their hands; but to death we will not kill you. And they tied him with two {ropes new}, and bore him from the rock. 

#### Judges 15:14 And he came unto Jaw, and the Philistines shouted and ran to meet him. And {straightened upon him spirit of the LORD}, and {became the ropes in his arms} as hemp when {smells fire}, and {melted away the bonds} from his arms. 

#### Judges 15:15 And he found a jaw bone of a donkey having been tossed. And he stretched out his hand, and took it, and struck with it a thousand men. 

#### Judges 15:16 And Samson said, By the jaw bone of a donkey, in wiping away, I wiped them away, for by the jaw bone of the donkey I struck a thousand men. 

#### Judges 15:17 And it came to pass when he finished speaking, that he tossed the jaw bone from his hand, and he called that place, Removal of the Jaw. 

#### Judges 15:18 And he thirsted exceedingly, and he yelled to the LORD, and said, You gave by the hand of your servant {deliverance great this}, and now shall I die in thirst, and fall into the hand of the uncircumcised? 

#### Judges 15:19 And God opened the gash, the one in Jaw, and there came forth from out of it waters, and he drank, and {was restored his spirit}, and he lived. Because of this {is called its name}, Spring of the Calling Upon, which is in Jaw until this day. 

#### Judges 15:20 And he judged Israel in the days of the Philistines twenty years. 

#### Judges 16:1 And Samson went into Gaza, and saw there a woman harlot, and he entered to her. 

#### Judges 16:2 And it was reported to the Gazites, saying, Samson comes here. And they encircled, and laid in wait for him the entire night at the gate of the city. And they were silent the entire night, saying, {until light shows through at dawn We should wait}, and we should kill him. 

#### Judges 16:3 And Samson went to bed until midnight. And he rose up at half the night, and he took hold of the doors of the gate of the city, and the two doorposts, and carried them with the bar, and put them upon his shoulders, and bore them upon the top of the mountain which is at the face of Hebron. 

#### Judges 16:4 And it came to pass after this, that he loved a woman by the rushing stream Sorek, and her name was Delilah. 

#### Judges 16:5 And {ascended to her the satraps of the Philistines}, and said to her, Beguile him, and see by what means {strength his is great}, and by what means we shall be able to prevail against him, and tie him so as to humble him. And we will give to you by man a thousand and a hundred pieces of silver. 

#### Judges 16:6 And Delilah said to Samson, Explain indeed to me by what means {strength is your great}! and by what means you shall be tied so as to humble you? 

#### Judges 16:7 And {said to her Samson}, If they should tie me with seven {strings of a bow wet} that are not ruined, then I will be weakened, and I will be as one of the men. 

#### Judges 16:8 And {brought to her the satraps of the Philistines} seven {strings of a bow wet} not ruined. And she tied him with them. 

#### Judges 16:9 And the ambush sat down for him in the storeroom. And she said to him, The Philistines are upon you, Samson. And he tore up the strings of the bow in which manner one pulls apart yarn of hemp in its smelling of fire, and {was not made known his strength}. 

#### Judges 16:10 And Delilah said to Samson, Behold, you misled me, and you spoke to me by lying. Now then report to me! how you shall be tied. 

#### Judges 16:11 And he said to her, If by binding, they should tie me by {ropes new} which were not used in work, then I shall be weak, and I will be as one of the men. 

#### Judges 16:12 And Delilah took {ropes new}, and tied him with them. And she said to him, The Philistines are upon you, Samson. And the ambush sat in the storeroom. And he pulled them from his arms as thread. 

#### Judges 16:13 And Delilah said to Samson, Until now you misled me, and spoke to me lying. Announce indeed to me! by what means you shall be tied. And he said to her, If you should weave the seven strands of hair of my head with the warp, and hammer with the peg into the wall, then I will be weak as one of the men. 

#### Judges 16:14 And it came to pass in his going to sleep, that Delilah took the seven strands of his head, and weaved them with the warp, and pinned them to the peg into the wall. And she said to him, The Philistines are upon you, Samson. And he was awakened from his sleep, and he pulled out the pegs in the woven work from out of the wall, and the warp; for he did not know his strength. 

#### Judges 16:15 And {said to him Delilah}, How do you say, I love you, and your heart is not with me? This third time you misled me, and did not report to me by what means {strength is your great}. 

#### Judges 16:16 And it came to pass when she worked him by her words the whole night, and troubled him, so that he was faint-hearted unto death. 

#### Judges 16:17 And he reported to her all the things from his heart. And said to her, A razor shall not ascend upon my head, for {a Nazarite of God I am} from the belly of my mother; and if I should be shaven, {shall leave from me my strength}, and I shall be weakened, and I will be as all the men. 

#### Judges 16:18 And Delilah knew that he reported to her all his heart. And she sent and called the satraps of the Philistines, saying, Ascend this once! for he reported to me all his heart. And ascended up to her all the satraps of the Philistines, and they brought the silver into her hands. 

#### Judges 16:19 And she rested him between her knees. And she called the barber, and he shaved the seven curls of his head; and it began to humble him, and {left his strength} from him. 

#### Judges 16:20 And Delilah said, The Philistines are upon you, Samson. And he was awakened from out of his sleep. And he said, I shall go forth, and I shall do as continually before, and I shall brush myself off. And he did not know that the LORD left from him. 

#### Judges 16:21 And {took hold of him the Philistines}, and gouged out his eyes, and carried him unto Gaza. And they bound him with shackles of brass, and he was grinding in the house of the prison. 

#### Judges 16:22 And {began the hair of his head} to grow, as he was shaven. 

#### Judges 16:23 And the rulers of the Philistines came together to sacrifice {sacrifice a great} to Dagon their god, and to be merry. And they said, {delivered Our god} into our hand Samson our enemy. 

#### Judges 16:24 And {saw him the people}, and they praised their god, for they said, {delivered Our god} our enemy into our hands, the one making {quite desolate our land}, who multiplied our slain. 

#### Judges 16:25 And it came to pass when {was feeling good their heart}, that they said, Call Samson from out of the house of the prison, and let him play before us! And they called Samson from out of the house of the jail, and they sported with him. And they stood him in between the two posts. 

#### Judges 16:26 And Samson said to the young man leading him by the hand, Allow me! for I should handle the monumental pillars upon of which the house stays upon them. 

#### Judges 16:27 And the house was full of the men and women, and {were there all the satraps of the Philistines}. And upon the roof were about three thousand men and women, looking at and mocking Samson. 

#### Judges 16:28 And Samson yelled to the LORD, and said, O LORD, O LORD, remember me, and strengthen me indeed besides! even this once O God, and I will avenge {vengeance one} against {two eyes for my the Philistines}. 

#### Judges 16:29 And Samson took hold of the two posts in the midst upon which the house stood, and he stayed against them, one at his right hand, and one at at his left. 

#### Judges 16:30 And Samson said, Let {die my soul} with the Philistines. And he leaned in strength, and {fell the house} upon the satraps, and upon all the people in it. And {were the ones having died whom put to death Samson} in his death many over whom he put to death in his life. 

#### Judges 16:31 And {went down his brothers}, and all the house of his father, and they took him, and they ascended and entombed him between Zorah and between Esthaol in the burying-place of Manoah his father. And he judged Israel twenty years. 

#### Judges 17:1 And there was a man of mount Ephraim, and his name was Micah. 

#### Judges 17:2 And he said to his mother, The thousand and hundred pieces of silver seized from you, and you adjured and said it in my ears -- behold, the silver is with me, I took it. And {said his mother}, Being blessed is my son in the LORD. 

#### Judges 17:3 And he gave back the thousand and hundred pieces of silver to his mother. And {said his mother}, By sanctification, I sanctified the silver to the LORD out of my hand alone, to make a carving and molten image, and now I will give it back to you. 

#### Judges 17:4 And he gave back the silver to his mother. Then {took his mother} two hundred of the pieces of silver, and gave them to the smelterer. And he made it into a carving and molten image. And it was in the house of Micah. 

#### Judges 17:5 And the house of Micah was to him the house of God. And he made an ephod and teraphim. And he filled up the hand of one of his sons, and he became to him for a priest. 

#### Judges 17:6 In those days there was not a king in Israel; a man {upright in his own eyes did}. 

#### Judges 17:7 And there was a young man from out of Beth-lehem Judah from the kin of Judah, and he was a Levite, and he sojourned there. 

#### Judges 17:8 And {went the man} from the city of Beth-lehem Judah to sojourn where ever he should find. And he came unto mount Ephraim, and unto the house of Micah, making his way. 

#### Judges 17:9 And {said to him Micah}, From what place come you? And he said to him, {a Levite I am} from Beth-lehem Judah, and I go to sojourn where ever I should find. 

#### Judges 17:10 And {said to him Micah}, Sit down with me, and become to me as a father and as priest, and I will give to you ten silver pieces for days, and a pair of clothes, and the things for your means of life. 

#### Judges 17:11 And {went the Levite}, and he began to sojourn by the man. And {became the young man} to him as one of his sons. 

#### Judges 17:12 And Micah filled up the hand of the Levite, and {became to him the young man} for a priest, and he was in the house of Micah. 

#### Judges 17:13 And Micah said, Now I know that {did good to me the LORD}, for {became to me the Levite} for a priest. 

#### Judges 18:1 In those days there was not a king in Israel. And in those days the tribe of Dan sought for itself an inheritance to dwell, for {did not fall in to it until that day in the midst of the tribes of Israel an inheritance}. 

#### Judges 18:2 And {sent out the sons of Dan} from their peoples five men from their part, men of sons of power, from Zorah and Esthaol, to survey the land, and to track it. And they said to them, Go, and search out the land! And they came unto mount Ephraim, unto the house of Micah, and they rested there. 

#### Judges 18:3 In their being by the house of Micah, that they knew the voice of the young man, the Levite, and they turned aside there. And they said to him, Who brought you here? And what do you do here? And what is it here? 

#### Judges 18:4 And he said to them, {so and so did with me Micah}, and hired me, and I became to him for a priest. 

#### Judges 18:5 And they said to him, Ask indeed to God! that we will know if {greatly prospers our way} which we go by it. 

#### Judges 18:6 And {said to them the priest}, Go in peace before the LORD! your way by which you go by it. 

#### Judges 18:7 And {went the five men} and came into Laish. And they saw the people in it dwelling in hope as the amalgamation of the Sidonians, being tranquil in hope, and not being able to speak a word in the land, for they are far from Sidon, and {word there was no} to them with Syria. 

#### Judges 18:8 And {came the five men} to their brethren in Zorah and in Esthaol. And {said to them their brethren}, Why do you sit down? 

#### Judges 18:9 And they said, Rise up, for we should ascend against them! for we saw the land, and behold, {good, it is exceedingly}. And you are silent? You should not be reluctant to go and to enter to inherit the land. 

#### Judges 18:10 When ever you should enter, you shall come to a people being secure, and the land of broad space, for {delivered it over God} into your hand. A place where there is not {there any deficiency} of a thing as much as is on the earth. 

#### Judges 18:11 And they departed from there, from the kin of Dan, from Zorah and from Esthaol -- six hundred men being girded with weapons for battle. 

#### Judges 18:12 And they ascended and camped in Kirjath-jearim in Judah. On account of this {was called that place}, Camp of Dan until this day. Behold, it is behind Kirjath-jearim. 

#### Judges 18:13 And they went from there unto mount Ephraim, and came unto the house of Micah. 

#### Judges 18:14 And {responded the five men going to survey the land of Laish}. And they said to their brethren, Did you know that there is in these houses an ephod, and teraphim, and a carved image, and a molten image? And now know what you shall do! 

#### Judges 18:15 And they turned aside there, and entered into the house of the young man -- the Levite, into the house of Micah, and they asked him for peace. 

#### Judges 18:16 And the six hundred men being girded with weapons for their warfare, being set up by the door of the gatehouse, were the ones from the sons of Dan. 

#### Judges 18:17 Then {ascended the five men going to survey the land}; and coming there, they took the carved image, and the ephod, and the teraphim, and the molten image. And the priest was set up by the door of the gatehouse, and the six hundred men were girded with weapons for warfare. 

#### Judges 18:18 And when these entered into the house of Micah, and took the carved image, and the ephod, and the teraphim, and the molten image, that {said to them the priest}, What do you do? 

#### Judges 18:19 And they said to him, Be silent, place your hand over your mouth, and come with us! and you will be to us for a father and for a priest. Is it not better for you to be a priest of the house {man of one}, or for you to be priest of a tribe and kin in Israel? 

#### Judges 18:20 And it was good to the heart of the priest. And he took the ephod, and the teraphim, and the carved image, and the molten image, and entered into the midst of the people. 

#### Judges 18:21 And they turned and went forth, and put the children, and the property, and the load before them. 

#### Judges 18:22 And they were far from the house of Micah, and behold, Micah and the men in the houses, near the house of Micah cried out, and they overtook the sons of Dan. 

#### Judges 18:23 And they yelled to the sons of Dan. And {turned the sons of Dan} their faces, and they said to Micah, What is it to you that you cry out? 

#### Judges 18:24 And he said, The gods which I made you took, and the priest, and you departed. And what is there to me still? And what is this you say to me, Why is this that you cry out? 

#### Judges 18:25 And {said to him the sons of Dan}, {should not be heard Your voice} with us, lest at any time {should confront you men in severe pain of soul}, and you shall add your life, and the life of your household. 

#### Judges 18:26 And {went the sons of Dan} on their way. And Micah saw that {too mighty for him they are}, and he turned aside and returned to his house. 

#### Judges 18:27 And they took as much as Micah made, and the priest who was with him, and they went unto Laish, upon a people being tranquil, and being secure. And they struck them by the mouth of the broadsword, and the city they burned by fire. 

#### Judges 18:28 And there is no one rescuing, for it is far from Sidon, and communication is not to them with man; and it is in the valley which is of the house of Rehob. And they built up the city, and dwelt in it. 

#### Judges 18:29 And they called the name of the city Dan, according to the name of Dan their father, who was born to Israel. And {was Laish the name to the city formerly}. 

#### Judges 18:30 And {set up for themselves the sons of Dan} the carved image. And Jonathan, son of Gershom, son of Manasseh, he and his sons were priests to the tribe of Dan until the day of the displacement of the land. 

#### Judges 18:31 And they themselves stationed the carved image Micah made all the days, as many as {was the house of God} in Shiloh. And it came to pass in those days there was no king in Israel. 

#### Judges 19:1 And there was a man, a Levite, sojourning on the sides of mount Ephraim. And he took to himself a woman concubine from Beth-lehem Judah. 

#### Judges 19:2 And {provoked him to anger his concubine}, and she went forth from him unto the house of her father in Beth-lehem Judah, and she was there the days of four months. 

#### Judges 19:3 And {rose up her husband} and went after her, to speak unto her heart, to reconcile her; and his servant was with him, and a pair of beasts of burden. And he went unto the house of her father. And {beheld him the father of the young woman}, and was at hand for meeting him. 

#### Judges 19:4 And {brought him in his father-in-law}, the father of the young woman, and he stayed with him three days. And they ate and drank and slept there. 

#### Judges 19:5 And it came to pass on the {day fourth}, that they rose early in the morning, and he rose up to depart. And {said the father of the young woman} to his son-in-law, Support your heart with a piece of bread, and after this go! 

#### Judges 19:6 And he sat down, and {ate both} together, and drank. And {said the father of the young woman} to the man, For a beginning, lodge and do good to your heart! 

#### Judges 19:7 And {rose up the man} to depart. And {forced him his father-in-law}, and he stayed and lodged there. 

#### Judges 19:8 And he rose early in the morning on the {day fifth} to depart. And {said the father of the young woman}, Support indeed your heart with bread, and soldier until {should decline the day}! And {ate and drank both}. 

#### Judges 19:9 And {rose up the man} to go, he and his concubine, and his servant. And {said to him his father-in-law}, the father of the young woman, Behold, indeed {is declined the day} into evening, lodge here and do good to your heart, and rise early tomorrow unto your way, and you shall depart unto your tent! 

#### Judges 19:10 And {did not want the man} to lodge. And he rose up and went forth and came unto before Jebus, this is Jerusalem, and with him were a pair of beasts of burden being saddled, and his concubine with him. 

#### Judges 19:11 And they were near Jebus, and the day declined exceedingly. And {said the servant} to his master, Come please, even we should turn aside into {city of the Jebusites this}, and lodge in it. 

#### Judges 19:12 And {said to him his master}, In no way shall we turn aside into {city an alien}, in which there is no one from the sons of Israel; even we shall go by unto Gibeah. 

#### Judges 19:13 And he said to his servant, Come, for we should approach one of the places, and we should lodge in Gibeah or in Ramah. 

#### Judges 19:14 And they went by, and {went down on them the sun} being next to Gibeah, which is of Benjamin. 

#### Judges 19:15 And they turned aside there to enter to rest up in Gibeah. And he entered and sat in the square of the city, and there is no man bringing them into the house to rest up. 

#### Judges 19:16 And behold, {man an old} entered from his works from out of the field at evening, and the man was from mount Ephraim, and he sojourned in Gibeah; and the men of the place were sons of Benjamin. 

#### Judges 19:17 And he looked up with his eyes, and he saw the man, the one journeying in the square of the city. And {said man the old}, Where are you going, and from what place come you? 

#### Judges 19:18 And he said to him, We are passing over from Beth-lehem of Judah unto the side of mount Ephraim. {from there And I am}, and I went unto Beth-lehem of Judah, and {to my house I run}; but there is no man bringing me into a house. 

#### Judges 19:19 And indeed straw and fodder exists for our donkeys, and indeed bread and wine exists to me, and to the maidservant, and to the servant; and to your servants there is no deficiency of any thing. 

#### Judges 19:20 And {said the man old}, Peace to you; only let any deficiency of yours be upon me, only {in the square you should not rest up}. 

#### Judges 19:21 And he brought him into his house, and camped his beasts of burden. And they washed their feet, and they ate and drank. 

#### Judges 19:22 And they were doing {good their heart}; and behold, the men of the city, sons of lawbreakers, encircled the house, and knocked upon the door; and they said to the man, the master of the house, the old man, saying, Lead out the man entering into your house, that we should know him. 

#### Judges 19:23 And {came forth to them the man}, the master of the house, and he said to them, By no means, my brethren, you should not do evil indeed with {entering this man} into my house; you should not do this folly. 

#### Judges 19:24 Behold, my daughter the virgin, and his concubine; and I will bring them, and you humble them, and do to them the good thing in your eyes, but to this man you should not do the thing of this folly. 

#### Judges 19:25 And {did not want the men} to hear him. And {took hold the man} of his concubine, and led her to them outside. And they knew her, and sported with her the entire night until the morning. And they sent her at the same time the {ascended dawn}. 

#### Judges 19:26 And {came the woman} in the morning, and fell by the door of the vestibule of the house of the man of whom {was her master} there, until of which time light shown through. 

#### Judges 19:27 And {rose up her master} in the morning, and he opened the doors of the house, and he came forth to depart into his way. And behold, the woman, his concubine, was fallen by the door of the house, and her hands were upon the threshold. 

#### Judges 19:28 And he said to her, Rise up, for we should go forth! And she did not answer to him for she had died. And he lifted her upon the beast of burden, and {rose up the man} and went forth to his place. 

#### Judges 19:29 And he entered into his house, and he took the knife, and took hold of his concubine, and dismembered her according to her bones into twelve portions, and he sent them unto all the tribes of Israel. 

#### Judges 19:30 And it came to pass all the ones seeing said, Neither happened, nor was thus seen from the days of the ascending of the sons of Israel from out of the land of Egypt until this day. Appoint indeed to yourselves {concerning her counsel} and speak! 

#### Judges 20:1 And there came forth all the sons of Israel, and {held an assembly the congregation} as {man one}, from Dan and unto Beer-sheba, and the land of Gilead, before the LORD in Mizpeh. 

#### Judges 20:2 And {established the region} all of the people in all the tribes of Israel in the assembly of the people of God -- four hundred thousand men on foot unsheathing the broadsword. 

#### Judges 20:3 And {heard the sons of Benjamin} that {ascended the sons of Israel} unto Mizpeh. And {said the sons of Israel}, Tell where {took place evil this}? 

#### Judges 20:4 And {answered the man}, the Levite, the husband of the woman having been murdered. And he said, {unto Gibeah of Benjamin I came}, I and my concubine to rest up. 

#### Judges 20:5 And {rose up against me the men}, the ones of Gibeah, and they encircled upon me, upon the house at night; and {me they wanted to kill}, and {my concubine they humbled}, and sported with her, and she died. 

#### Judges 20:6 And I took hold of my concubine, and I dismembered her, and I sent out into every border of the inheritance of Israel; for they committed folly in Israel. 

#### Judges 20:7 Behold, all you, the sons of Israel, make to yourselves an account and plan here! 

#### Judges 20:8 And {rose up all the people} as {man one}, saying, We shall not enter -- a man into his tent, and we shall not turn aside -- a man to his house. 

#### Judges 20:9 And now {the thing this is} which we shall do to Gibeah; we will ascend against it by lot. 

#### Judges 20:10 And we shall take ten men out of a hundred for all the tribes of Israel, and a hundred out of a thousand men, and a thousand out of ten thousand men, to take a provision for the people, to complete the task to the ones in going unto Gibeah of Benjamin, against all the folly which they did in Israel. 

#### Judges 20:11 And came together every man of Israel to the city as {man one} coming. 

#### Judges 20:12 And {sent out the tribes of Israel} men in all the tribe of Benjamin, saying, What is this evil that took place among you? 

#### Judges 20:13 And now, give over the {men impious} in Gibeah, the sons of Belial, and we shall kill them and lift away evil from Israel. But {did not want the sons of Benjamin} to hear the voice of their brethren of the sons of Israel. 

#### Judges 20:14 And {came together the sons of Benjamin} from their cities to Gibeah, to go forth into battle array against the sons of Israel. 

#### Judges 20:15 And {numbered the sons of Benjamin} in that day of the cities, twenty five thousand men unsheathing the broadsword, apart from the ones dwelling in Gibeah. 

#### Judges 20:16 These numbered seven hundred {men chosen} from all of the people, ambidextrous; all these were slingers casting stones accurate to the hair, and not missing. 

#### Judges 20:17 And every man of Israel -- they were numbered, separate from the sons of Benjamin, four hundred thousand men unsheathing the broadsword; all these were men warriors. 

#### Judges 20:18 And they rose up and ascended unto Beth-el, and asked of God. And {said the sons of Israel}, Who shall ascend to us guiding to wage war with the sons of Benjamin? And the LORD said, Judah shall ascend guiding. 

#### Judges 20:19 And {rose up the sons of Israel} in the morning, and camped at Gibeah. 

#### Judges 20:20 And {went forth every man of Israel} for war against Benjamin; and he deployed against them -- the man of Israel for war against Gibeah. 

#### Judges 20:21 And came forth the sons of Benjamin from the city, and utterly destroyed in Israel on that day two and twenty thousand men upon the ground. 

#### Judges 20:22 And {strengthened the people} -- the man of Israel, and proceeded to deploy for war in the place in which he deployed there on the {day first}. 

#### Judges 20:23 And {ascended up the sons of Israel}, and they wept before the LORD until evening, and they asked of the LORD, saying, Shall I proceed to draw near for war against the sons of Benjamin my brother? And the LORD said, Ascend against him! 

#### Judges 20:24 And {came forward the sons of Israel} against the sons of Benjamin in the {day second}. 

#### Judges 20:25 And Benjamin came forth to meet them from Gibeah on the {day second}. And they utterly destroyed yet of the people of Israel eighteen thousand men upon the ground, all these unsheathing the broadsword. 

#### Judges 20:26 And {ascended up all the sons of Israel}, and all the people, and they came unto Beth-el and wept, and sat there before the LORD, and fasted in that day until evening; and they offered a whole burnt-offering for deliverance before the LORD. 

#### Judges 20:27 And {asked the sons of Israel} in the LORD. And {was there the ark of the covenant of the LORD} in those days. 

#### Judges 20:28 And Phinehas the son of Eleazar, the son of Aaron stood before it in those days, saying, Shall I proceed still to go forth for war against the sons of Benjamin my brother, or slacken? And the LORD said, Ascend, and tomorrow I will deliver him into your hand. 

#### Judges 20:29 And {placed the sons of Israel} an ambush in Gibeah round about. 

#### Judges 20:30 And {ascended the sons of Israel} against the sons of Benjamin on the {day third}. And they deployed against Gibeah as once before, and once before that. 

#### Judges 20:31 And {came forth the sons of Benjamin} for meeting the people, and were drawn away from the city. And they began to strike of the people (slain as once before, and once before that) in the ways which there is one ascending to Beth-el, and one ascending to Gibeah in the field, about thirty men of Israel. 

#### Judges 20:32 And {said the sons of Benjamin}, They stumble before us as before. And the sons of Israel said, We should flee and pull them out from the city into the ways. 

#### Judges 20:33 And every man of Israel rose up from his place, and deployed in Baal-tamar. And the ambush of Israel wrestled from out of its place from the descent of Gibeah. 

#### Judges 20:34 And they arrived right opposite Gibeah -- ten thousand {men chosen} from out of all Israel. And the battle weighed down, and they did not know that {has been affixed upon them hurt}. 

#### Judges 20:35 And {put to flight the LORD Benjamin} before Israel. And {utterly destroyed the sons of Israel} among Benjamin in that day twenty and five thousand and a hundred men, all these unsheathing the broadsword. 

#### Judges 20:36 And {beheld the sons of Benjamin} that they were put to flight. And {gave the man of Israel} place to Benjamin, for they hoped upon the ambush which they arranged near Gibeah. 

#### Judges 20:37 And the ambush advanced, and they poured out against Gibeah. And {went the ambush}, and they struck all the city by the mouth of the broadsword. 

#### Judges 20:38 And the arranged order was with the man of Israel with the ambush, for them to offer a signal-fire of smoke from the city. 

#### Judges 20:39 And {turned the man of Israel} in the battle. And Benjamin began to strike slain against the man of Israel about thirty men. For they said, Surely being put to flight he was put to flight before us as the battle before. 

#### Judges 20:40 And the signal-fire began to ascend from the city as a column of smoke. And Benjamin looked behind him, and behold, there ascended the consummation of the city unto the heaven. 

#### Judges 20:41 And the man of Israel turned. And {hastened the man of Benjamin}, for he beheld that {has touched him a bad thing}. 

#### Judges 20:42 And they leaned before the man of Israel in the way of the wilderness, and the battle fell {unawares upon them}; and the ones from the cities -- they utterly destroyed them in their midst. 

#### Judges 20:43 And they cut up Benjamin, and pursued him according to his feet, and trampled him unto before Gibeah towards the rising of the sun. 

#### Judges 20:44 And {fell of Benjamin eighteen thousand men}; all these men of power. 

#### Judges 20:45 And they turned aside and fled into the wilderness to the rock of Rimmon. And they gleaned him in the ways -- five thousand men. And they cleaved after them unto Gidom, and struck of them two thousand men. 

#### Judges 20:46 And it came to pass all the ones falling among Benjamin was twenty-five thousand men unsheathing the broadsword in that day; all these were men of power. 

#### Judges 20:47 And they turned aside and fled into the wilderness to the rock of Rimmon -- six hundred men; and they stayed at the rock of Rimmon four months. 

#### Judges 20:48 And the man of Israel turned against the sons of Benjamin, and they struck them by the mouth of the broadsword, from {city the next}, unto beast, and unto all being found in the cities; and the cities being found they burned by fire. 

#### Judges 21:1 And the man of Israel swore by an oath in Mizpeh, saying, {man from us No} shall give his daughter to Benjamin for a wife. 

#### Judges 21:2 And {came all the people} unto Beth-el, and sat there until evening before God. And they lifted their voice and wept {weeping a great}. 

#### Judges 21:3 And they said, Why, O LORD God of Israel, was this taken place in Israel, to overlook today in Israel {tribe one}? 

#### Judges 21:4 And it happened the next day that {rose early the people}, and they built there an altar, and offered a whole burnt-offering of deliverance. 

#### Judges 21:5 And {said the sons of Israel}, Who is the one not ascending among the assembly from all of the tribes of Israel to the LORD? For {oath a great there was} concerning the one not ascending to the LORD in Mizpeh, saying, To death he shall die. 

#### Judges 21:6 And {relented the sons of Israel} concerning {Benjamin their brother}, and said, {is removed today tribe one from Israel}. 

#### Judges 21:7 What should we do to them, to the ones left behind for wives, for we swore by an oath to the LORD to not give to them from our daughters for wives? 

#### Judges 21:8 And they said, What one is there of the tribes of Israel which did not ascend to the LORD in Mizpeh? And behold, no {came man} to the camp from Jabish Gilead to the assembly. 

#### Judges 21:9 And {were numbered the people}, And behold, there is not there a man from the ones dwelling in Jabish Gilead. 

#### Judges 21:10 And {sent there the congregation} twelve thousand men from the sons of the force. And they gave charge to them, saying, Go and strike all the ones dwelling in Jabish Gilead by the mouth of the broadsword, even the women and the people! 

#### Judges 21:11 And this is the word which you shall do. Every male and every woman knowing the marriage-bed of a man you shall devote to consumption. 

#### Judges 21:12 And they found of ones dwelling Jabish Gilead four hundred young women virgins, the ones that knew not a man, in the marriage-bed of a man. And they led them into the camp in Shiloh which is in the land of Canaan. 

#### Judges 21:13 And {sent all the congregation} and spoke to the sons of Benjamin, of the ones at the rock of Rimmon, and they called them for peace. 

#### Judges 21:14 And Benjamin returned to the sons of Israel in that time, and they gave them the women who were of the women of Jabish Gilead, and it pleased them thus. 

#### Judges 21:15 And the people were comforted concerning Benjamin, for {made the LORD} a breach among the tribes of Israel. 

#### Judges 21:16 And {said the elders of the congregation}, What shall we do to the remaining for wives, now that {was removed from Benjamin the woman}? 

#### Judges 21:17 And he said, An inheritance for the ones surviving to Benjamin, that in no way {should be wiped away a tribe} from Israel. 

#### Judges 21:18 For we are not able to give to them wives from our daughters, for {swore by an oath the sons of Israel}, saying, Accursed is the one giving a wife to Benjamin. 

#### Judges 21:19 And they said, Behold, there is a holiday to the LORD in Shiloh from days to days, which is from the north of Beth-el, according to the rising of the sun, upon the corridor ascending from Beth-el unto Shechem, and from south of Lebonah. 

#### Judges 21:20 And they gave charge to the sons of Benjamin, saying, Go forth and lie in wait at the vineyards! 

#### Judges 21:21 And look and behold, whenever {should come forth the daughters of the ones dwelling in Shiloh} joining in a dance with a company of dancers, then you shall come forth from the vineyards, and let {seize by force to himself a man} a wife from the daughters of Shiloh! then you shall depart unto the land of Benjamin. 

#### Judges 21:22 And it will be whenever {should come their fathers or their brothers} to quarrel with us, that we shall say to them, Show mercy on them! for {did not take a man} to himself a wife in the battle, for you did not give to them according to the time which you trespassed. 

#### Judges 21:23 And {did thus the sons of Benjamin}; and they took wives according to their number from the ones dancing, whom they snatched. And they went and returned unto their inheritance, and they built up the cities, and dwelt in them. 

#### Judges 21:24 And {walked from there the sons of Israel} in that time, each man to his tribe, and to his kin; and {went forth from there each man} to his inheritance. 

#### Judges 21:25 In those days there was not a king in Israel. A man {the upright thing in his eyes did}.