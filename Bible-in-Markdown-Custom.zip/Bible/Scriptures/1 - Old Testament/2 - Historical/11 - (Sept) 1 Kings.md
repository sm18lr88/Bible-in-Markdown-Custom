#### 1 Kings 1:1 And king David was an old man, advanced in days. And they put {around him clothes}, and he was not warmed. 

#### 1 Kings 1:2 And {said his servants} to him, Let them seek for our master the king a young virgin, and she shall stand beside the king, and will be warming him, and she shall recline in his bosom, and {shall be heated our master the king}. 

#### 1 Kings 1:3 And they sought {young woman a goodly} from every border of Israel. And they found Abishag the Shunammite, and they brought her to the king. 

#### 1 Kings 1:4 And the young woman was goodly to the sight, exceedingly, and was warming the king. And she ministered to him, and the king did not know her. 

#### 1 Kings 1:5 And Adonijah son of Haggith lifted up, saying, I shall reign. And he appointed to himself chariots, and horsemen, and fifty men running in front of him. 

#### 1 Kings 1:6 And {did not make a reproach to him his father} at any time, saying, Why is it that have you done thus? And he was good in appearance, exceedingly. And he was born after Absalom. 

#### 1 Kings 1:7 And {were his communications} with Joab the son of Zeruiah, and with Abiathar the priest. And they helped following after Adonijah. 

#### 1 Kings 1:8 And Zadok the priest, and Benaiah son of Jehoiada, and Nathan the prophet, and Shimei, and Rei, and the ones being mighty to David were not with Adonijah. 

#### 1 Kings 1:9 And Adonijah sacrificed sheep and calves and lambs by the stone Zoheleth, the one being next to the spring of En-rogel. And he called all his brethren of the sons of the king, and all the men of Judah, the servants of the king. 

#### 1 Kings 1:10 But Nathan the prophet, and Benaiah, and the mighty ones, and Solomon his brother he did not call. 

#### 1 Kings 1:11 And Nathan said to Bath-sheba, mother of Solomon, saying, Did you not hear that {reigns Adonijah son of Haggith}, and our master David does not know. 

#### 1 Kings 1:12 And now, come, I will advise you with advice, so that you should preserve your life, and the life of Solomon your son. 

#### 1 Kings 1:13 Come, enter unto king David. And you shall say to him, Have you not, O my master, O king, sworn by an oath to your maidservant, saying that, Solomon your son, he shall reign after me, and he shall sit upon my throne. Then why is it that Adonijah reigns? 

#### 1 Kings 1:14 And behold, while you are speaking there with the king, that I shall enter after you, and I will fulfill your words. 

#### 1 Kings 1:15 And Bath-sheba entered to the king in the inner chamber. And the king was an old man, exceedingly. And Abishag the Shunamite was ministering to the king. 

#### 1 Kings 1:16 And Bath-sheba bowed, and did obeisance to the king. And {said the king}, What is it to you? 

#### 1 Kings 1:17 And she said, O my master, O king, you swore by an oath to the LORD your God to your maidservant, saying that, Solomon your son, he shall reign after me, and he shall sit upon my throne. 

#### 1 Kings 1:18 And now behold, Adonijah reigns; and you, O my master, O king, do not know. 

#### 1 Kings 1:19 And he sacrificed calves and lambs and sheep in multitude, and he called all the sons of the king, and Abiathar the priest, and Joab the ruler of the force; and Solomon your servant he did not call. 

#### 1 Kings 1:20 And you, O my master, O king, the eyes of all Israel are towards you to report to them who shall sit upon the throne of my master the king after him. 

#### 1 Kings 1:21 And it will be in the sleeping of my master the king with his fathers, that I will be myself and Solomon your son as sinners. 

#### 1 Kings 1:22 And behold, while she spoke with the king, that Nathan the prophet entered. 

#### 1 Kings 1:23 And it was announced to the king, saying, Behold, Nathan the prophet. And he entered in front of the king, and did obeisance to the king upon his face upon the ground. 

#### 1 Kings 1:24 And Nathan said, O my master, O king, have you said, Adonijah shall reign after me, and he shall sit upon my throne? 

#### 1 Kings 1:25 For he went down today and sacrificed calves and lambs and sheep in multitude, and called all the sons of the king, and the rulers of the force, and Abiathar the priest; and behold, they are eating and drinking before him, and they said, Let {live king Adonijah}! 

#### 1 Kings 1:26 And me your servant, and Zadok the priest, and Benaiah son of Jehoiada, and Solomon your servant he did not call. 

#### 1 Kings 1:27 If {through my master the king has taken place this thing}, then you did not make known to your servant who shall sit upon the throne of my master the king after him. 

#### 1 Kings 1:28 And {answered king David}, and said, Call to me Bath-sheba! And she entered before the king, and stood before him. 

#### 1 Kings 1:29 And {swore by an oath the king}, and said, As the LORD lives, who ransomed my soul from out of all affliction, 

#### 1 Kings 1:30 that as I swore by an oath to you according to the LORD God of Israel, saying that, Solomon your son shall reign after me, and he shall sit upon my throne instead of me; that thus I will do this day. 

#### 1 Kings 1:31 And Bath-sheba bowed upon her face upon the earth, and did obeisance to the king, and said, Let {live my master king David} into the eon! 

#### 1 Kings 1:32 And {said king David}, Call to me Zadok the priest, and Nathan the prophet, and Benaiah son of Jehoiada! And they entered before the king. 

#### 1 Kings 1:33 And {said the king} to them, Take with you the servants of your master, and set Solomon my son upon {mule my}, and lead him unto Gihon! 

#### 1 Kings 1:34 And let {anoint him there Zadok the priest and Nathan the prophet} for king over Israel! And trump the horn! And you shall say, Let {live king Solomon}! 

#### 1 Kings 1:35 And you shall ascend after him. And he shall enter, and he shall sit upon my throne, and he shall reign instead of me. And to him I gave charge to be for leader over Israel and over Judah. 

#### 1 Kings 1:36 And {responded Benaiah son of Jehoiada} to the king, and said, May it be so. May {confirm it the LORD God of my master the king}. 

#### 1 Kings 1:37 As the LORD was with my master the king, so may it be with Solomon, and to magnify his throne above the throne of my master king David. 

#### 1 Kings 1:38 And {went down Zadok the priest}, and Nathan the prophet, and Benaiah son of Jehoiada, and the Cherethite, and the Pelethite. And they sat Solomon upon the mule of king David, and they took him to Gihon. 

#### 1 Kings 1:39 And {took Zadok the priest} the horn of the oil from out of the tent, and anointed Solomon, and trumped the horn. And {said all the people}, Let {live king Solomon}! 

#### 1 Kings 1:40 And {ascended all the people} after him, and all the people joined in a dance by companies of dancers, and making glad {gladness in great}. And {tore the earth} with the sound of them. 

#### 1 Kings 1:41 And Adonijah heard, and all the invited ones with him; and they completed eating. And Joab heard the sound of the horn, and said, What is the sound of the city sounding? 

#### 1 Kings 1:42 While he was speaking, that behold, Jonathan son of Abiathar the priest came in. And Adonijah said, Enter, for {a man of power you are}, and for good you announce good news! 

#### 1 Kings 1:43 And Jonathan answered and said to Adonijah, And by all means our master king David established Solomon to reign. 

#### 1 Kings 1:44 And {sent with him the king} Zadok the priest, and Nathan the prophet, and Benaiah the son of Jehoiada, and the Cherethite, and the Pelethite. And they sat him upon the mule of the king. 

#### 1 Kings 1:45 And {anointed him Zadok the priest}, and Nathan the prophet as king at Gihon. And they ascended from there making glad. And {sounded the city} this sound which you heard. 

#### 1 Kings 1:46 And Solomon is seated upon the throne of the kingdom. 

#### 1 Kings 1:47 And also {came the servants of the king} to bless our master king David, saying, {make good God} the name of your son Solomon above your name, and magnify his throne above your throne! And {did obeisance the king} upon his bed. 

#### 1 Kings 1:48 And indeed thus {said the king}, Blessed is the LORD God of Israel, who gave today from out of my seed one sitting upon my throne, and my eyes see it. 

#### 1 Kings 1:49 And {were startled and rose up all the ones called by Adonijah}, and {departed each} unto his way. 

#### 1 Kings 1:50 And Adonijah feared from the face of Solomon, and he rose up and went forth, and took hold of of the horns of the altar. 

#### 1 Kings 1:51 And it was announced to Solomon, saying, Behold, Adonijah fears king Solomon, and he takes hold of the horns of the altar, saying, Let {swear by an oath to me today king Solomon} to not put to death his servant by the broadsword. 

#### 1 Kings 1:52 And Solomon said, If he should be a son of power, in no way should there fall from his head a hair upon the ground. But if evil should be found in him, he shall be put to death. 

#### 1 Kings 1:53 And {sent king Solomon}, and brought him from on top of the altar. And he entered and did obeisance to king Solomon. And {said to him Solomon}, Go unto your house! 

#### 1 Kings 2:1 And there approached the days for David himself to die; and he gave charge to his son to Solomon, saying, 

#### 1 Kings 2:2 I am going in the way of all the earth, and you shall be strong, and you shall be a man. 

#### 1 Kings 2:3 And you shall guard the watch of the LORD your God, to go in his ways, to guard his commandments, and the ordinances, and the judgments, and his testimonies, as written in the law of Moses; that you should perceive all what you shall do, and everywhere of which ever you should have paid attention there. 

#### 1 Kings 2:4 So that the LORD should establish his word which he spoke concerning me, saying, If {should guard your sons} their way, to go before me in truth, with {whole heart their}, and with {whole soul their}, saying, There shall not be lifted away to you a man from the throne of Israel. 

#### 1 Kings 2:5 And now you know what {did to me Joab son of Zeruiah}, and what he did to the two rulers of the forces of Israel -- Abner son of Ner, and Amasa son of Jether; and he killed them, and ordered up the blood of war for peace, and put {blood innocent} on his belt, the one on his loin, and on his sandal, the one on his foot. 

#### 1 Kings 2:6 And you shall do according to your wisdom, and you shall not lead down his gray hair in peace into Hades. 

#### 1 Kings 2:7 And to the sons of Barzillai the Gileadite you shall have mercy, and they shall be at the eating of your table, for so they drew near to me in my fleeing from the face of your brother of Absalom. 

#### 1 Kings 2:8 And behold, there is with you Shimei son of Gera, son of the Benjamite from Bahurim. And he cursed me {curse a grievous} in the day in which I went into Camps. And he went down for meeting me at the Jordan, and I swore by an oath to him by the LORD, saying, I shall not put {to death you} by the broadsword. 

#### 1 Kings 2:9 And you shall in no way acquit him, for {man a wise you are}, and you shall know what to do with him, and you shall lead down his gray hair with blood into Hades. 

#### 1 Kings 2:10 And David slept with his fathers, and he was entombed in the city of David. 

#### 1 Kings 2:11 And the days which David reigned over Israel were forty years. In Hebron he reigned seven years, and in Jerusalem he reigned thirty and three years. 

#### 1 Kings 2:12 And Solomon sat upon the throne of David his father. And {was prepared kingdom his} exceedingly. 

#### 1 Kings 2:13 And {entered Adonijah son of Haggith} to Bath-sheba, the mother of Solomon, and did obeisance to her. And she said, {in peace entering Are you}? And he said, Peace. 

#### 1 Kings 2:14 And he said, My word to you. And she said to him, Speak! 

#### 1 Kings 2:15 And he said to her, You know that to me was the kingdom, and upon me {set all Israel} their face for king. And {was turned the kingdom}, and came to my brother; for by the LORD it was to him. 

#### 1 Kings 2:16 And now {request one I ask} from you, you should not turn away your face. And {said to him Bath-sheba}, Speak! 

#### 1 Kings 2:17 And he said to her, Speak indeed to Solomon the king! for he will not turn away your face, so that he shall give to me Abishag the Shunammite for wife. 

#### 1 Kings 2:18 And Bath-sheba said, Well, I will speak for you to the king. 

#### 1 Kings 2:19 And Bath-sheba entered to king Solomon to speak to him concerning Adonijah. And {rose up the king} to meet her, and he did obeisance to her, and he sat upon his throne. And {was set a throne} for the mother of the king; and she sat on his right. 

#### 1 Kings 2:20 And she said to him, {request one small I ask} from you, you should not turn away my face. And {said to her the king}, Ask {mother my}, for I will not turn from you. 

#### 1 Kings 2:21 And she said, Let there be given indeed Abishag the Shunammite to Adonijah your brother for wife! 

#### 1 Kings 2:22 And {answered king Solomon} and said to his mother, And why are you asking Abishag for Adonijah? Then ask for him the kingdom, for this one {brother is my older} over me, and with him are Abiathar the priest, and with him Joab son of Zeruiah commander-in-chief -- his companion. 

#### 1 Kings 2:23 And {swore by an oath king Solomon} according to the LORD, saying, Thus may {do to me God}, and thus may he add to it for {against his own life Adonijah spoke this word}. 

#### 1 Kings 2:24 And now as the LORD lives, who prepared me, and put me upon the throne of David my father, and he made to me a house as the LORD said, that today Adonijah shall be put to death. 

#### 1 Kings 2:25 And {sent out king Solomon} by the hand of Benaiah son of Jehoiada; and he did away with him, and he died. 

#### 1 Kings 2:26 And to Abiathar the priest {said the king}, Run unto Anathoth, to your field! for {a man marked for death your are}, and from this day I will not put {to death you}, for you lifted the ark of the covenant of the LORD before David my father, and because you were mistreated in all ways which {was mistreated my father}. 

#### 1 Kings 2:27 And Solomon cast out Abiathar so that he would not be for priest to the LORD; to fulfill the saying of the LORD, which he said concerning the house of Eli in Shiloh. 

#### 1 Kings 2:28 And the report came unto Joab son of Zeruiah; for Joab was leaning after Adonijah, but {after Solomon he did not turn aside}. And Joab fled to the tent of the LORD, and held the horns of the altar. 

#### 1 Kings 2:29 And it was reported to Solomon, saying that, Joab has fled into the tent of the LORD, and behold, he holds the horns of the altar. And Solomon sent Benaiah son of Jehoiada, saying, Go, and do away with him! 

#### 1 Kings 2:30 And Benaiah came to Joab in the tent of the LORD, and he said to him, Thus says the king, Come forth! And Joab said, I do not go forth, for here I shall die. And Benaiah returned and said to the king, saying, Thus Joab has spoken, and thus he answered me. 

#### 1 Kings 2:31 And {said to him the king}, Go, and do to him as he has said, and do away with him! And you shall bury him, and lift away today the blood which Joab poured out freely from me, and from the house of my father. 

#### 1 Kings 2:32 And the LORD returned the blood of his iniquity onto his head, inasmuch as he met the two {men just and good} above him, and killed them by the broadsword. And my father David did not know about Abner son of Ner, commander-in-chief of Israel, and Amasa son of Jether, commander-in-chief of Judah. 

#### 1 Kings 2:33 And let {return blood their} upon his head, and upon the head of his seed unto the eon! And to David, and to his seed, and to his house, and to his throne, may there be peace by the LORD into the eon. 

#### 1 Kings 2:34 And {ascended Benaiah son of Jehoiada}, and met him, and killed him. And they entombed him in his house in the wilderness. 

#### 1 Kings 2:35 And {appointed the king} Benaiah son of Jehoiada instead of him over the military. And {Zadok the priest appointed the king}, as {priest foremost} instead of Abiathar. 

#### 1 Kings 2:36 And sending, {called the king} Shimei, and said to him, Build for yourself a house in Jerusalem, and settle there, and do not go forth from there -- not at all! 

#### 1 Kings 2:37 And it will be in the day that you exit, and pass over the rushing stream Kidron, in knowing, know that to death you shall die, your blood will be upon your head. 

#### 1 Kings 2:38 And Shimei said to the king, {is good The thing} which you have spoken, O my master, O king, thus shall {do your servant}. And Shimei settled in Jerusalem three years. 

#### 1 Kings 2:39 And it came to pass after three years, that {ran away two servants of Shimei} to Achish son of Maachah king of Gath. And they reported to Shimei, saying, Behold, your servants are in Gath. 

#### 1 Kings 2:40 And Shimei rose up, and saddled his donkey, and went unto Gath to Achish to seek after his servants. And Shimei went and led his servants from Gath. 

#### 1 Kings 2:41 And it was reported to Solomon, saying that, Shimei went from out of Jerusalem unto Gath, and he returned. 

#### 1 Kings 2:42 And {sent the king} and called Shimei, and he said to him, Have I not bound you by an oath according to the LORD, and I attested to you, saying, In which ever day you should go forth from out of Jerusalem, and you should go to the right or left, in knowing, know that to death you shall die? And you said to me, {was good The word which you heard}. 

#### 1 Kings 2:43 And why have you not guarded the oath of the LORD, and the commandment which I gave charge to you? 

#### 1 Kings 2:44 And {said the king} to Shimei, You know all your evil which {knows your heart}, which you did to David my father, and the LORD recompensed your evil on your head. 

#### 1 Kings 2:45 And king Solomon is being blessed, and the throne of David will be prepared before the LORD into the eon. 

#### 1 Kings 2:46 And {gave charge king Solomon} to Benaiah son of Jehoiada. And he came forth, and did away with him, and he died. 

#### 1 Kings 3:1 And the kingdom solidified in the hand of Solomon. And Solomon contracted a marriage with Pharaoh king of Egypt. And he took the daughter of Pharaoh, and he brought her into the city of David, until he completed building his house, and the house of the LORD at first, and the wall of Jerusalem round about. 

#### 1 Kings 3:2 Except the people were burning incense upon the high places, for {was not built a house} to the name of the LORD until now. 

#### 1 Kings 3:3 And Solomon loved the LORD, to go in the orders of David his father; only {in the high places he sacrificed and burned incense}. 

#### 1 Kings 3:4 And he rose up and went into Gibeon to sacrifice there, for it was highest and great. {a thousand whole burnt-offerings Solomon offered} upon the altar in Gibeon. 

#### 1 Kings 3:5 And the LORD appeared to Solomon in sleep at night. And the LORD said to Solomon, Ask any request for yourself! 

#### 1 Kings 3:6 And Solomon said, You did {with your servant David my father mercy great}, as he went before you in truth, and in righteousness, and in straightness of heart with you. And you guarded him {mercy great by this}, to grant to him a son sitting upon his throne as this day. 

#### 1 Kings 3:7 And now, O LORD, my God, you gave reign to your servant in place of David my father. And I am {boy a small}; and I do not know my entering and my exiting. 

#### 1 Kings 3:8 And your servant is in the midst of your people whom you chose, {people a populous} who cannot be counted. 

#### 1 Kings 3:9 And you shall give to your servant a heart to hear and to litigate your people in righteousness, to perceive between good and bad. For who shall be able to judge {for your people this weighty thing}? 

#### 1 Kings 3:10 And {was pleasing the word} before the LORD, that Solomon asked this thing. 

#### 1 Kings 3:11 And the LORD said to him, Because you asked this thing from me, and you did not ask {for yourself days many}, and you did not ask for riches, nor asked for the lives of your enemies; but you asked for yourself understanding to hear judgment; 

#### 1 Kings 3:12 behold, I have done according to your word; behold, I give to you {heart an intelligent and wise}. {as you There has not been one} before you, and after you there shall not rise up one likened to you. 

#### 1 Kings 3:13 And indeed what you have not asked, I have given to you, even riches and glory, as there is not a man likened to you among the kings. 

#### 1 Kings 3:14 And if you should have gone in my way, to guard my commandments, and my orders, as {went David your father}, then I will prolong your days. 

#### 1 Kings 3:15 And Solomon woke up and knew the dream. And he rose up and came unto Jerusalem, and he stood in front of the altar, of the one in front of the ark of the covenant of the LORD, and he led up whole burnt-offerings, and made peace offerings, and made a banquet to all his servants. 

#### 1 Kings 3:16 Then there appeared two women harlots unto the king, and they stood before him. 

#### 1 Kings 3:17 And {said the woman one}, Hear me, O my master. I and this woman live in {house one}, and we gave birth in the house. 

#### 1 Kings 3:18 And it came to pass in the {day third} of my giving birth, {gave birth also this woman}. And we were in the same place, and there was no one with us, only both of us in the house. 

#### 1 Kings 3:19 And {died the son of this woman} in the night, as she rested upon it. 

#### 1 Kings 3:20 And she rose up in the middle of the night, and she took my son from my embrace, and your maidservant rested, and she rested it in her bosom, and the son having died she rested in my bosom. 

#### 1 Kings 3:21 And I rose up in the morning to nurse my son, and that one was the one having died. And behold, I contemplated him in the morning; and behold, he was not my son whom I gave birth. 

#### 1 Kings 3:22 And {said woman the other}, Not so, for my son is the one living, and your son is the one having died. And she said, Not so, your son is the one having died, and my son is the one living. And they spoke before the king. 

#### 1 Kings 3:23 And {said the king} to them, You here say, This my son is the one living, and this one's son is the one having died. And you there say, Not so, but my son is the one living, and this one's son is the one having died. 

#### 1 Kings 3:24 And {said the king}, Take for me a sword! And they brought the sword before the king. 

#### 1 Kings 3:25 And {said the king}, Divide {child the living} into two, and give the one half of him to this one, and the other half of him to this other one! 

#### 1 Kings 3:26 And {answered the woman} of whom was the mother of the {son living}, and she said to the king, for {was disturbed womb her} over her son, and she said, Hear me, O master. give to her the child, and to death let {not be put to death it}! And she the other said, Neither to me nor to her let it be, divide it! 

#### 1 Kings 3:27 And {responded the king} and said, Give the {child living} to the one having said, Give it to her! and unto death you should not put it to death -- she is his mother. 

#### 1 Kings 3:28 And {heard all Israel} this ordinance which {passed judgment the king}, and they feared from the presence of the king, for they knew that intellect of God was in him to do justice. 

#### 1 Kings 4:1 And {was king Solomon} reigning over Israel. 

#### 1 Kings 4:2 And these are the rulers, the ones who were with him -- Azariah son of Zadok the priest; 

#### 1 Kings 4:3 Elihoreph and Ahiah son of Shisha were scribes; Jehoshaphat son of Ahilud was recorder; 

#### 1 Kings 4:4 and Benaiah son of Jehoiada was over the force; and Zadok and Abiathar were priests; 

#### 1 Kings 4:5 and Azariah son of Nathan was over the ones being placed in charge; and Zabud son of Nathan was companion of the king; 

#### 1 Kings 4:6 and Ahishar was manager; and Adoniram son of Abda was over the tribute. 

#### 1 Kings 4:7 And to Solomon were twelve being placed over all Israel, to conduct matters for the king and to his house. A month in the year it happened for one to conduct matters. 

#### 1 Kings 4:8 And these are their names -- Ben-Hur in mount Ephraim. 

#### 1 Kings 4:9 The son of Dekar in Makaz, and in Shaalbim and Beth-shemesh and Elon unto Beth-hanan. 

#### 1 Kings 4:10 The son of Hesed in Aruboth, of him was Sochoh, and all the land of Hepher. 

#### 1 Kings 4:11 {belonged to the son of Abinadab All Nephador}, Taphath daughter of Solomon was to him for wife. 

#### 1 Kings 4:12 Baana son of Ahilud to whom was Taanach, and Magiddo, and all the house of Shean, the one by Zartanah below Jezreel, from Beth-shean unto Abel-meholah unto Maeber Jokneam. 

#### 1 Kings 4:13 The son of Geber in Ramoth Gilead -- of this one were cities of Jair son of Manasseh in Gilead; to this one was a piece of measured out land, Argob in Bashan -- sixty cities, great and walled and bars of brass. 

#### 1 Kings 4:14 Ahinadab son of Iddo had Mahanaim. 

#### 1 Kings 4:15 Ahimaaz was in Naphtali, and he took Basmath daughter of Solomon for a wife. 

#### 1 Kings 4:16 Baanah son of Hushai was in Asher and in Aloth. 

#### 1 Kings 4:17 Jehoshaphat son of Paruah was in Issachar. 

#### 1 Kings 4:18 Shimei son of Elah was in Benjamin. 

#### 1 Kings 4:19 Geber son of Uri was in the land of Gilead of Sihon of the king of the Amorites, and Og king of Bashan; and Naseb in the land of Judah was one. 

#### 1 Kings 4:20 Judah and Israel {many were exceedingly}, as the sand upon the sea in multitude, eating and drinking and rejoicing. 

#### 1 Kings 4:21 And Solomon was ruler in all the kingdoms from the river of the land of the Philistines and unto the border of Egypt. And they were bringing gifts, and they served Solomon all the days of his life. 

#### 1 Kings 4:22 And these were the necessary things for Solomon. In {day one} were thirty cors of fine flour, and sixty cors of flour. 

#### 1 Kings 4:23 Ten {calves choice}, and twenty {oxen grazing}, and a hundred sheep, outside of stags and does, and {hens chosen and feeding}. 

#### 1 Kings 4:24 For he was ruler in all on the other side of the river, from Tiphsah unto Azzah, in all the kingdoms on the other side of the river. And there was to him peace from all of the parts round about. 

#### 1 Kings 4:25 And {dwelt Judah and Israel} being yielded each in his grapevine and under his fig-tree, from Dan and unto Beer-sheba, all the days of Solomon. 

#### 1 Kings 4:26 And there were to Solomon forty thousand horses for chariots, and twelve thousand horsemen. 

#### 1 Kings 4:27 And {conducted the ones being placed in charge} thus to king Solomon, and all the declarations upon the table of the king, each one in charge of his month -- they did not alter a word. 

#### 1 Kings 4:28 And the barley and the straw for the horses and the chariots they took unto the place of which ever {might be the king}, each according to his arrangement. 

#### 1 Kings 4:29 And the LORD gave intellect to Solomon and {wisdom great exceedingly}, and an increase in heart, as the sand by the sea. 

#### 1 Kings 4:30 And Solomon multiplied exceedingly over the intellect of all the ancient men, and above all the intelligent ones of Egypt. 

#### 1 Kings 4:31 And he discerned above all men; and he discerned above Ethan the Ezrahite, and Heman, and Chalcol, and Darda, sons of Mahol. And {became famous his name} among all the nations round about. 

#### 1 Kings 4:32 And he spoke three thousand parables. And {were odes his} five thousand. 

#### 1 Kings 4:33 And he spoke concerning the timbers from the cedars in Lebanon, and unto the hyssop coming forth from the wall. And he spoke concerning the cattle, and concerning the winged creatures, and concerning the reptiles, and concerning the fishes. 

#### 1 Kings 4:34 And {came to him all the peoples} to hear the wisdom of Solomon. And he took gifts from all the kings of the earth, as many as heard his wisdom. 

#### 1 Kings 5:1 And {sent Hiram king of Tyre} his servants to Solomon; for he heard that they anointed him for king in place of David his father. For {loving was Hiram} David all the days. 

#### 1 Kings 5:2 And Solomon sent to Hiram, saying, 

#### 1 Kings 5:3 You knew my father David, that he was not able to build a house to the name of the LORD my God, because of facing the wars that were encircling him, until the LORD put them under the soles of his feet. 

#### 1 Kings 5:4 And now {gave rest the LORD my God} to me round about; there is not a plotter and there is not {sin a wicked}. 

#### 1 Kings 5:5 And behold, I speak concerning building a house to the name of the LORD my God, as the LORD spoke to David my father, saying, Your son whom I shall put instead of you upon your throne, this one shall build the house to my name. 

#### 1 Kings 5:6 And now give charge, and let men fell timbers for me from Lebanon! And behold, my servants shall be with your servants; and the wage of your servants I will give to you according to all as much as you should say. For you know that there is not among us one knowing to fell timbers as the Sidonians. 

#### 1 Kings 5:7 And it came to pass as Hiram heard the words of Solomon, he rejoiced exceedingly. And he said, Blessed be the LORD today who gives to David {son an intelligent} over {people populous this}. 

#### 1 Kings 5:8 And Hiram sent to Solomon, saying, I have heard concerning all which you have sent to me. I will do all your will for timbers of cedars and of pines. 

#### 1 Kings 5:9 My servants shall lead them from out of Lebanon into the sea; and I will put them on barges unto the place of which ever you should send for me. And I shall shake them off there, and you shall lift them. And you shall produce for my want, to give bread loaves to my house. 

#### 1 Kings 5:10 And Hiram was giving to Solomon cedars and pines according to all his want. 

#### 1 Kings 5:11 And Solomon gave to Hiram twenty thousand cors of wheat, and food to his house, and twenty baths of olive oil being pounded. According to this Solomon gave to Hiram yearly. 

#### 1 Kings 5:12 And the LORD gave to Solomon wisdom as he said to him. And there was peace between Hiram and between Solomon. And they ordained a covenant between them. 

#### 1 Kings 5:13 And {brought king Solomon} tribute from all Israel. And {was the tribute} thirty thousand men. 

#### 1 Kings 5:14 And he sent them to Lebanon -- ten thousand {every month being changed}. {month one They were in Lebanon}, and two months at their house. And Adoniram was over the tribute. 

#### 1 Kings 5:15 And were unto Solomon seventy thousand lifting a load, and eighty thousand quarriers in the mountain; 

#### 1 Kings 5:16 separate from the rulers being placed over the works of Solomon -- three thousand and three hundred supervisors over the people of the ones doing the works. 

#### 1 Kings 5:17 And {gave charge the king}, and they lifted {stones great valuable} for the foundation of the house, and {stones unhewn}. 

#### 1 Kings 5:18 And {hewed the servants of Solomon}, and the servants of Hiram, and the Giblites. And they prepared the stones and the timbers to build the house. 

#### 1 Kings 6:1 And it came to pass in the eightieth and four hundredth year of the exodus of the sons of Israel from out of Egypt, in the {year fourth} in the second month in the reigning of king Solomon over Israel, that he built the house to the LORD. 

#### 1 Kings 6:2 And the house which {built king Solomon} to the LORD -- sixty cubits its length, and twenty cubits its width, and thirty cubits its height. 

#### 1 Kings 6:3 And the columned porch in front of the temple -- twenty cubits was the length of it upon the width of the house. And ten in cubit was its width according to the face of the house. 

#### 1 Kings 6:4 And he made for the house a window leaning hidden. 

#### 1 Kings 6:5 And he put upon the wall of the house a ridge round about the temple, and to the dabir. And he made the sides round about. 

#### 1 Kings 6:6 The side underneath -- five cubits was the width of it. And for the middle -- six cubits was the width. And the third -- seven cubits was the width of it. For {a space he made} to the house round about from outside the house, so as to not take hold of the walls of the house. 

#### 1 Kings 6:7 And the house in the constructing it {stones in whole chiseled was built}. And a hammer, and hewing axe, and every item of iron, was not heard in the constructing it. 

#### 1 Kings 6:8 And the vestibule of the side of the one from beneath was by the protrusion of the house on the right side, and there was a winding ascent into the middle, and from the middle unto the third story. 

#### 1 Kings 6:9 And he constructed the house, and completed it. And he vaulted the house with cedars. 

#### 1 Kings 6:10 And he built the chambers through the entire house, five cubits was the height of it, and he held it together by bonding it together with timbers of cedars. 

#### 1 Kings 6:11 And came to pass the word of the LORD to Solomon, saying, 

#### 1 Kings 6:12 This house which you construct, if you travel by my orders, and {my judgments you should observe}, and should keep all my commandments, to pace in them; I will establish my word with you which I spoke to David your father; 

#### 1 Kings 6:13 and I will encamp in the midst of the sons of Israel, and I will not abandon my people Israel. 

#### 1 Kings 6:14 And Solomon built the house and finished it. 

#### 1 Kings 6:15 And he built the walls of the house from inside with wood of cedars, from the floors of the house, and unto the walls, and unto the beams. And he vaulted it holding it together with timbers from inside. And he compassed the inside of the house with ribs of pines. 

#### 1 Kings 6:16 And he built twenty cubits from the top of the house of the sides of the ones of cedars from floor unto the beams. And he made it inside of the dabir in the holy of holies. 

#### 1 Kings 6:17 And {forty cubits was itself the temple} in front of the dabir. 

#### 1 Kings 6:18 And cedar covered the house inside. And there was carved gourds and {opened and spread out leaves} -- all cedar; and stone did not appear. 

#### 1 Kings 6:19 And the dabir was in the middle of the house within, to give place there for the ark of the covenant of the LORD. 

#### 1 Kings 6:20 Twenty cubits was the length, and twenty cubits the width, and twenty cubits the height of it. And he compassed it with gold being closed up. 

#### 1 Kings 6:21 And he made an altar according to the front of the dabir, and he compassed it with gold. 

#### 1 Kings 6:22 And the entire house was compassed in gold, unto completion of all the house. 

#### 1 Kings 6:23 And he made in the dabir two cherubim of wood of cypresses, ten cubits was the greatness being measured by a rule, 

#### 1 Kings 6:24 and five cubits was the wing of the {cherub one}, and {was five cubits of its wing the second}. Ten in a cubit from one part of its wing to the other part of its wing. 

#### 1 Kings 6:25 Thus to the {cherub second} with {measure one} and {completion one} with both. 

#### 1 Kings 6:26 And the height of the {cherub one} was ten in a cubit. So also the second cherub. 

#### 1 Kings 6:27 And he stationed both the cherubim in the middle of the {house innermost}. And {were open and spread out wings their}, and {touched wing the one} the wall of the house, and the wing {cherub of the second} touched the {wall second}, and their wings were in the midst of the house, touching wing to wing. 

#### 1 Kings 6:28 And he compassed the cherubim with gold. 

#### 1 Kings 6:29 And all the walls of the house round about {sculptures he depicted} with a stylus -- cherubim, and palms and {opened and spread out leaves} to the inner and to the outer. 

#### 1 Kings 6:30 And the floor of the house he compassed with gold -- of the innermost and the outermost. 

#### 1 Kings 6:31 And to the doorway of the dabir he made doors of wood of juniper, and {doorways five-fold}. 

#### 1 Kings 6:32 And two doors of woods of pines. And sculptures upon them being sculpted of cherubim, and palms. And panels were opening and spreading out. And he compassed them with gold; and {came down upon the cherubim and over the palms the gold}. 

#### 1 Kings 6:33 And thus he made to the vestibule of the temple doorposts of woods of juniper, {stoas with fourfold}. 

#### 1 Kings 6:34 And in both the doors woods of pines were used -- {was bi- fold the door one}, and their hinges were there; and {was bi- fold door the second} to turn; 

#### 1 Kings 6:35 being sculpted with cherubim and palms; and {opening and spreading out panels}, and being compassed with gold being led upon the impression. 

#### 1 Kings 6:36 And he built the {courtyard inner}, three rows of hewn stones, and a row being manufactured of cedar round about. 

#### 1 Kings 6:37 In the fourth year {was laid a foundation the house of the LORD}, in the month Zif. 

#### 1 Kings 6:38 And in {year the eleventh}, in the month of Bul, this is the {month eighth}, {was completed the house} according to all his words, and according to all his responsibilities. And he built it in seven years. 

#### 1 Kings 7:1 And {constructed Solomon} his own house for thirteen years. And he {completed wholly} his house. 

#### 1 Kings 7:2 And he constructed the house of the forest of Lebanon. A hundred cubits was its length, and fifty cubits its width, and thirty cubits its height upon four rows of columns of cedars, and protrusions of cedars for the columns. 

#### 1 Kings 7:3 And he decorated with fretwork in cedar the house above upon the sides of the columns. And the number of the columns was forty and five -- {row in one ten and seven}. 

#### 1 Kings 7:4 And {ridges three}, with place upon place thrice. 

#### 1 Kings 7:5 And all the doorways and the places were four-cornered being arched over, from the doorway upon the door thrice. 

#### 1 Kings 7:6 And the columned porch of the columns was fifty cubits in length, and thirty cubits in width, being joined together by a columned porch in front of them. And columns and thick beams were at the front to them. 

#### 1 Kings 7:7 And the columned porch of the throne where he judged there, was a columned porch for the judgment seat. And it was decorated with fretwork in cedars from floor unto upper room. 

#### 1 Kings 7:8 And his house in which he shall sit there, {courtyard one} is expanding to these according to this work. And {built a house Solomon} (for the daughter of Pharaoh whom Solomon took) according to this columned porch. 

#### 1 Kings 7:9 These all from out of {stones valuable} being chiseled, at an interval inside from the foundation unto the moldings, and outside to the {courtyard great}, 

#### 1 Kings 7:10 in the laying a foundation with {stones valuable great}; stones ten cubits and eight cubits in size. 

#### 1 Kings 7:11 And on top were {stones valuable} according to the same measure -- hewn stones and cedars, 

#### 1 Kings 7:12 of the {courtyard great} round about with three rows of hewn stones, and a row being chiseled of cedar, even to the {courtyard of the house of the LORD inner}, and to the columned porch of the house. 

#### 1 Kings 7:13 And {sent king Solomon} and took Hiram from out of Tyre, 

#### 1 Kings 7:14 the son {woman of a widow}, and this one was from the tribe of Naphtali, and his father was a Tyrian man, a fabricator of brass, and being accomplished of the wisdom of the craft, and of understanding, and full of knowledge to do all the work in brass. And he was brought to king Solomon, and he did every work. 

#### 1 Kings 7:15 And he cast in a furnace the two columns for the columned porch of the house -- eighteen cubits was the height of the column, and the perimeter had a two and ten cubits cord encircling it. And so was the {column second}. 

#### 1 Kings 7:16 And {two capitals he made} to put upon the heads of the {columns molten} of brass -- five cubits was the height of the {capital one}, and five cubits was the height of the {capital second}. 

#### 1 Kings 7:17 And he made latticed works to cover the capitals of the columns; seven to the capital -- to the one; and seven to the capital -- to the second. 

#### 1 Kings 7:18 And {work a hanging} -- two rows of pomegranates of brass being made of lattice works, {work a hanging}, row upon row. And thus he did for the {capital second}. 

#### 1 Kings 7:19 And capitals upon the heads of the columns, a work of lily for the columned porch -- four cubits; and a ridge upon both of the columns, and on top of the sides of the capital. 

#### 1 Kings 7:20 And the pomegranates were two hundred in rows upon the {capital second}. 

#### 1 Kings 7:21 And he set up the columns of the columned porch of the temple. And he set up the {column right}, and he called the name of it -- Jachin. And he set up the {column left}, and called the name of it -- Boaz. 

#### 1 Kings 7:22 And upon the tops of the columns was a work of lily. And {was finished the work of the columns}. 

#### 1 Kings 7:23 And he made the {sea cast} -- ten by a cubit from its rim unto its rim, globular, round about the same, five by a cubit was its height. And a measuring meeting together thirty cubits encircled it. 

#### 1 Kings 7:24 And supports from beneath its rim round about encircled it. Ten by a cubit raising up the sea round about. Two rows of supports cast in the foundry furnace of them. 

#### 1 Kings 7:25 And twelve oxen were underneath the sea -- the three looking to the north, and the three looking to the west, and the three looking to the south, and the three looking to the east. And the sea was upon them on top. 

#### 1 Kings 7:26 And all the posteriors were to the inside, and the thickness of it was a palm, and the rim of it was as {work a rim} of a cup with {bud a lily}. {of two thousand coos It had a capacity}. 

#### 1 Kings 7:27 And he made ten bases of brass -- four cubits was the length of the {base one}, and four cubits the width of it, and three cubits was the height of it. 

#### 1 Kings 7:28 And this is the work of the base joining it, and joining between the protruding parts. 

#### 1 Kings 7:29 And upon the joineries between the protruding parts were lions and oxen and cherubim. And upon the protruding parts so also from above and from below the lions and the oxen places {work of a descending}. 

#### 1 Kings 7:30 And four wheels of brass were to the {base one} and the fastenings of brass and {four parts its}, of their protrusion supports from beneath the bathing tubs, and protrusion supports pouring from the other side a man being situated before. And the mouth of it within the top and upward one cubit. 

#### 1 Kings 7:31 And the mouth of it was globular, a thing made thus -- a cubit and half a cubit. And upon its mouth were carvings. And their small pillars were four-cornered, not globular. 

#### 1 Kings 7:32 And four wheels were underneath the small pillars. And hands were in the wheels in the base. And the height of the {wheel one} was a cubit and a half. 

#### 1 Kings 7:33 And the work of the wheels was as the work {wheels of chariot}. And their hands and their backs and their matters were all casted. 

#### 1 Kings 7:34 And four protrusion supports were upon the four corners of the {base one}. From out of the base were its shoulders. 

#### 1 Kings 7:35 And upon the head of the base a half a cubit {size was its globular} round about upon the head of the base. And the hands of it and its joineries were of it; and it opened upon the beginnings of its hands. 

#### 1 Kings 7:36 And its joinery was cherubim, and lions, and {palms standing}, each being next to the other in front of it inside, round about. 

#### 1 Kings 7:37 According to this he made ten bases, {order with one} and {measure one} to all. 

#### 1 Kings 7:38 And he made ten pots of brass, {of forty coos having the capacity} to the one pot, measuring four cubits. And {pot one} was upon the {base one} for the ten bases. 

#### 1 Kings 7:39 And he put the ten bases, five on the protrusion support of the house at the right sides, and five on the protrusion support of the house at the left sides; and the sea on the protrusion support of the house at the right sides, according to the east from the side of the south. 

#### 1 Kings 7:40 And Hiram made the kettles, and the tongs, and the bowls. And Hiram completed making all the works which he made for king Solomon in the house of the LORD -- 

#### 1 Kings 7:41 {columns two} and the twisted works of the carvings, the ones being upon the heads of the {columns two}; and {latticed works two}, to cover both the twisted works of the carvings, the ones being upon the columns; 

#### 1 Kings 7:42 and the pomegranates -- four hundred to both the latticed works; two rows of pomegranates to the {latticed work one}, to cover all over both the twisted works, the ones being upon both of the columns; 

#### 1 Kings 7:43 and the ten bases, and the {pots ten} upon the bases; 

#### 1 Kings 7:44 and the {sea one}, and the twelve oxen underneath the sea; 

#### 1 Kings 7:45 and the kettles, and the tongs, and the bowls. And all the items which Hiram made for king Solomon for the house of the LORD {of brass were entirely}. 

#### 1 Kings 7:46 In the adjacent area of the Jordan {cast them the king} in the thick earth between Succoth and between Zarthan. 

#### 1 Kings 7:47 And {put away Solomon the king} all the items, because of {multitude the exceeding} which there was no weight of the brass. 

#### 1 Kings 7:48 And Solomon made all the items in the house of the LORD -- the {altar gold}, and the table (upon which are the bread loaves of the {place setting gold}). 

#### 1 Kings 7:49 And the {lamp-stands five} at the right sides, and five at the left sides, in front of the dabir {of gold being completely made}; and the oil lamp bowls, and the lamps, and the oil funnels were of gold; 

#### 1 Kings 7:50 and the thresholds, and the nails, and the bowls, and the saucers, and the incense pans {of gold were joined}. And the doorways of the doors of the {house innermost}, of the holy of holies, and the doors of the house of the temple were of gold. 

#### 1 Kings 7:51 And {was fulfilled all the work which Solomon did} for the house of the LORD. And Solomon carried in the holy things of David his father, the silver and the gold; and the equipment he put into the treasury of the house of the LORD. 

#### 1 Kings 8:1 Then {held an assembly king Solomon} of all the elders of Israel, and all rulers of tribes, leaders of the families of the sons of Israel, for king Solomon in Jerusalem to bear the ark of the covenant of the LORD from out of the city of David -- this is Zion, 

#### 1 Kings 8:2 in the month Athanim during its holiday, this is {month the seventh}. And {came all the elders of Israel}. 

#### 1 Kings 8:3 And {lifted the priests} the ark, 

#### 1 Kings 8:4 and the tent of the testimony, and all the {items holy}, the ones for the tent of the testimony. 

#### 1 Kings 8:5 And the king and all the people of Israel were before the ark sacrificing oxen and sheep -- innumerable. 

#### 1 Kings 8:6 And {carried the priests} the ark of the covenant of the LORD unto its place, into the dabir of the house, into the holy of holies, under the wings of the cherubim. 

#### 1 Kings 8:7 For the cherubim were being opened and spread out in the wings over the place of the ark. And {covered all the cherubim} over the ark, and over its holy things from above. 

#### 1 Kings 8:8 And {projected the sanctified staves}, and {looked out the heads of the sanctified staves} from the holies unto the front of the dabir. And they were not seen outside, and they were there until this day. 

#### 1 Kings 8:9 There was nothing in the ark except the two tablets of stone, tablets of the covenant, which {put there Moses} in Horeb, which the LORD ordained with the sons of Israel in their going forth from out of the land of Egypt. 

#### 1 Kings 8:10 And it happened as {came forth the priests} from out of the holy place, that the cloud filled the house. 

#### 1 Kings 8:11 And {were not able the priests} to stand to officiate in front of the cloud, for {filled the glory of the LORD} the house of the LORD. 

#### 1 Kings 8:12 Then Solomon said, The LORD spoke of encamping in dimness. 

#### 1 Kings 8:13 And I built a house to your name, holy to you, and readied, and to your chair {to encamp for you} in it into the eons. 

#### 1 Kings 8:14 And {turned the king} his face, and blessed all Israel. And all the assembly of Israel stood. 

#### 1 Kings 8:15 And he said, Blessed be the LORD God of Israel, who spoke by his mouth concerning David my father, and by his hands fulfilled, saying, 

#### 1 Kings 8:16 From which day I led out my people Israel from Egypt, I have not chosen a city in one chiefdom of Israel to build a house {to be name for my} there. But I chose in David to be the one leading over my people Israel. 

#### 1 Kings 8:17 And it was upon the heart of David my father to build a house to the name of the LORD God of Israel. 

#### 1 Kings 8:18 And the LORD said to David my father, That it was upon your heart to construct a house to my name {well you did}, for it was upon your heart. 

#### 1 Kings 8:19 Except you shall not build the house, but your son, the one coming forth from out of your sides, this one shall build the house to my name. 

#### 1 Kings 8:20 And the LORD raised up his word which he spoke. And I am risen up instead of David my father, and I sat down upon the throne of Israel, as the LORD spoke. And I built the house to the name of the LORD God of Israel. 

#### 1 Kings 8:21 And I established there a place for the ark, in which is there the covenant of the LORD, which the LORD ordained with our fathers, in his leading them from out of the land of Egypt. 

#### 1 Kings 8:22 And Solomon stood in front of the altar of the LORD before all the assembly of Israel. And he opened and spread out his hands into the heaven. 

#### 1 Kings 8:23 And he said, O LORD God of Israel, there is no {as you God} in the heaven upward and upon the earth below, guarding covenant and mercy with your servant, to the one going before you with {entire heart his}; 

#### 1 Kings 8:24 which you kept with your servant David, my father, which you have spoken by your mouth; and by your hands you fulfilled as even this day. 

#### 1 Kings 8:25 And now, O LORD God of Israel, keep with your servant David, my father, that which you spoke to him! saying, There shall not be lifted away from you a man from my face sitting upon the throne of Israel, except that {shall guard your sons} their ways to go before me, as you went before me. 

#### 1 Kings 8:26 And now, O LORD God of Israel, trustworthy indeed is your word to David my father. 

#### 1 Kings 8:27 But shall truly God dwell with men upon the earth? Shall the heaven and the heavens of the heavens be sufficient for you? How then also this house which I built to your name? 

#### 1 Kings 8:28 And should you look also upon my prayer, upon my supplication, O LORD God of Israel, to hear the supplication and the prayer which your servant prays before you, to you today. 

#### 1 Kings 8:29 For {to be your eyes} open towards this house day and night, to this place which you said, {shall be My name} there. To listen to the prayer which {prays your servant} in this place. 

#### 1 Kings 8:30 Then you shall hearken to the supplication of your servant, and of your people Israel, as many things as they should pray in this place. And you should hear in {place your dwelling} in heaven, and you shall do; and you shall be propitious, 

#### 1 Kings 8:31 as many things as {should sin a man} against his neighbor. And if he should take upon himself an oath to curse him, and he should come and should declare openly in front of your altar in this house; 

#### 1 Kings 8:32 then you shall listen from the heaven, and shall act, and shall judge your people Israel -- to act as lawless with the lawless, to impute his way upon his head; and to do justice with the just, to impute to him according to his righteousness. 

#### 1 Kings 8:33 And in the failing of your people Israel before their enemies -- because they shall sin against you, and shall return and shall acknowledge your name, and shall pray and beseech in this house; 

#### 1 Kings 8:34 then you shall hearken from the heaven, and shall be propitious to the sins of your people Israel, and shall turn towards them in the land which you gave to their fathers. 

#### 1 Kings 8:35 And in the holding together the heaven and there not being rain because they shall sin against you, and if they shall pray in this place, and shall acknowledge your name, and {from their sins shall turn}, whenever you should humble them; 

#### 1 Kings 8:36 then you shall listen from the heaven, and shall be propitious to the sins of your servant, and your people Israel, for you shall manifest to them the {way good} to go by it; and you shall give rain upon your land, which you gave to your people for an inheritance. 

#### 1 Kings 8:37 And if famine happens, if plague happens, when there will be a combustion, or the grasshopper, if blight happens, and if {shall afflict him his enemy} in one of their cities, every event, every misery, 

#### 1 Kings 8:38 every prayer, every supplication, if it should happen to any man, whenever {should know each one} the infection of his heart, and should open and spread out his hands in this house, 

#### 1 Kings 8:39 then you shall hearken from the heaven, from out of {prepared home your}, and you will be propitious, and you will act, and you will impute to a man according to all his ways, as you know his heart; for you alone know the heart of all of the sons of men; 

#### 1 Kings 8:40 so that they should fear you all the days which they live upon the earth which you gave to our fathers. 

#### 1 Kings 8:41 And to the alien who is not from your people -- this Israel, that shall come from a land far off on account of your name, 

#### 1 Kings 8:42 for they shall hear {name your great}, and {hand your strong}, and {arm your high}, and shall come and pray to this place; 

#### 1 Kings 8:43 then you shall listen from the heaven, from {prepared home your}, and you shall act according to all what {should call upon you the alien}, so that {should know all the peoples of the land} your name, so that they should fear you, as your people Israel, and should know that your name has been called upon in this house, which I built. 

#### 1 Kings 8:44 And if {should go forth your people} to war against their enemies, in the way which you shall send them, and they shall pray in the name of the LORD by way of the city which you chose in it, and the house which I built to your name; 

#### 1 Kings 8:45 then you shall listen from the heaven to their supplication, and their prayer, and shall do justice to them. 

#### 1 Kings 8:46 If it be that they shall sin against you, for there is no man who shall not sin, and if you should strike upon them, and should deliver them up before their enemies, and {should take them captive the ones taking captive} into a land far or near; 

#### 1 Kings 8:47 and they shall turn their hearts in the land which they were led away there, and they shall turn and beseech you in the land of their displacement, saying, We sinned, we acted lawlessly, we did wrong; 

#### 1 Kings 8:48 and they shall turn to you with {entire heart their}, and with {entire soul their} in the land of their enemies who led them away, and should pray to you by way of their land which you gave to their fathers, and of the city which you chose, and of the house of which I constructed to your name; 

#### 1 Kings 8:49 then you shall listen from the heaven, from {prepared home your}, of their prayer and their supplication, and you shall do the just thing for them, 

#### 1 Kings 8:50 and you shall be propitious to their iniquities which they sinned against you, and according to all their wickednesses which ever they disregarded. And you shall appoint them for compassions before the ones capturing them, and they shall pity them. 

#### 1 Kings 8:51 For they are your people, and your inheritance, whom you led out of the land of Egypt, from out of the midst of the foundry furnace of iron. 

#### 1 Kings 8:52 And let {be your eyes and your ears} open to the supplication of your servant, and to the supplication of your people Israel! to hearken to them in all what ever they should call upon you. 

#### 1 Kings 8:53 For you drew them apart unto yourself for an inheritance from out of all the peoples of the earth, as you spoke by the hand of your servant Moses, in your leading out our fathers from the land of Egypt, O Lord, O LORD. 

#### 1 Kings 8:54 And it came to pass as Solomon completed praying to the LORD all the prayer, and this supplication, that he rose up in front of the altar of the LORD, having kneeled upon his knees, and his hands being opened and spread out unto the heaven. 

#### 1 Kings 8:55 And he stood, and blessed all the assembly of Israel {voice with a great}, saying, 

#### 1 Kings 8:56 Blessed be the LORD who gave today rest to his people Israel, according to all as many things as he spoke. Not {perished word one} in all {words of his good} which he spoke by the hand of Moses his servant. 

#### 1 Kings 8:57 May {be the LORD our God} with us as he was with our fathers. May he not abandon us, nor turn from us; 

#### 1 Kings 8:58 but to incline our heart to himself, to go in all his ways, and to guard all his commandments, and his orders, and his judgments, which he gave charge to our fathers. 

#### 1 Kings 8:59 And let {be these words} which I have beseeched before the LORD our God today, approaching to the LORD our God day and night, to do the right action for your servant, and the right action for your people Israel -- {matter a days} in its day! 

#### 1 Kings 8:60 How that {should know all the peoples of the earth} that the LORD God -- he is God, and is there no other. 

#### 1 Kings 8:61 And let {be our hearts} perfect to the LORD our God! {sacredly to go} by his orders, and to keep his commandments as this day. 

#### 1 Kings 8:62 And the king, and all the sons of Israel sacrificed a sacrifice before the LORD. 

#### 1 Kings 8:63 And {sacrificed king Solomon} the sacrifices of the peace offerings which he sacrificed to the LORD -- {oxen two and twenty thousand}, and {sheep a hundred and twenty thousand}. And {dedicated the house of the LORD the king}, and with all the sons of Israel. 

#### 1 Kings 8:64 In that day {sanctified the king} the middle of the courtyard in front of the house of the LORD; for he prepared there the whole burnt-offering, and the sacrifice offerings, and the fat of the peace offerings, because the altar of brass before the LORD was small so as to not be able to receive the whole burnt-offering, and the gift offering, and the sacrifices of the peace offerings. 

#### 1 Kings 8:65 And Solomon observed the holiday feast in that day, and Israel with him, {assembly a great} from the entering of Hamath unto the river of Egypt, before the LORD our God seven days and seven days -- four and ten days. 

#### 1 Kings 8:66 And on the {day eighth} he sent out the people, and they blessed the king. And {went forth each} unto his tent rejoicing, and with good heart over the good things which the LORD did to David his servant, and to Israel his people. 

#### 1 Kings 9:1 And it came to pass as Solomon completed constructing the house of the LORD, and the house of the king, and all the matters of Solomon, as many things as he wanted to do, 

#### 1 Kings 9:2 that the LORD appeared to Solomon the second time, as he appeared to him in Gibeon. 

#### 1 Kings 9:3 And {said to him the LORD}, I heard your prayer and your supplication, which you beseeched before me. I sanctified this house which you built, to establish my name there into the eon. And {will be my eyes and my heart} there all the days. 

#### 1 Kings 9:4 And you, if you should go before me as {David went your father}, in sacredness of heart, and in straightness, to do according to all which I gave charge to him, and {my orders and my commandments you should keep}, 

#### 1 Kings 9:5 then I will raise up the throne of your kingdom over Israel into the eon, as I spoke to your father David, saying, There shall not be removed from you a man leading in Israel. 

#### 1 Kings 9:6 But if by turning, you should turn, you and your children, from me and my orders which I put before you, so as to not keep, and you should go and should serve {gods other}, and should do obeisance to them; 

#### 1 Kings 9:7 then I will remove Israel from the land which I gave to them,; and this house which I sanctified to my name I shall throw away from my face. And Israel will be for extinction and for a discussion among all the peoples. 

#### 1 Kings 9:8 And {house this lofty}, every one traveling by it shall be amazed, and shall whistle. And they shall say, For what reason did the LORD do thus to this land, and to this house? 

#### 1 Kings 9:9 And they shall say, Because they abandoned the LORD their God, the one leading their fathers from out of the house of slavery of Egypt, and they took hold of alien gods, and did obeisance to to them, and served to them. On account of this the LORD brought upon them all this evil. 

#### 1 Kings 9:10 And it came to pass after twenty years in which Solomon constructed the two houses, the house of the LORD, and the house of the king, 

#### 1 Kings 9:11 Hiram the king of Tyre assisted Solomon with timbers of cedars, and with timbers of pines, and in gold, and in all his want. Then {gave king Solomon} to Hiram twenty cities in the land of Galilee. 

#### 1 Kings 9:12 And Hiram came forth from out of Tyre, and went to Galilee to behold the cities which {gave to him Solomon}, and they did not please him. 

#### 1 Kings 9:13 And Hiram said, What are these cities which you gave to me, O brother? And he called them The Border until this day. 

#### 1 Kings 9:14 And Hiram sent to Solomon a hundred and twenty talents of gold. 

#### 1 Kings 9:15 And this is the matter of the plunder which {brought king Solomon} to build the house of the LORD, and the house of the king, and the wall of Jerusalem, and the Akra to enclose the barrier of the city of David, and Hazor, and Megiddo, and Gezer. 

#### 1 Kings 9:16 Pharaoh king of Egypt ascended and first took Gezer, and he burnt it by fire, and the Canaanite dwelling in the city he put to death, and {gave it Pharaoh} as a dowry to his daughter -- to the wife of Solomon. 

#### 1 Kings 9:17 And Solomon built Gezer, and Beth-horon the lower, 

#### 1 Kings 9:18 and Baalath, and Tadmor in the wilderness, 

#### 1 Kings 9:19 and all the cities, the ones fortified which were to Solomon, and all the cities of the chariots, and all the cities of the horsemen, and the matters which Solomon engaged in to construct in Jerusalem, and in Lebanon, and in all the land of his dominion. 

#### 1 Kings 9:20 All the remaining people from the Hittite, and the Amorite, and the Perizzite, and the Canaanite, and the Hivite, and the Jebusite, and the Gergesite of the ones not being of the sons of Israel, 

#### 1 Kings 9:21 their children being left with them in the land, which {were not able the sons of Israel} to utterly destroy them, that {led them Solomon} into tribute until this day. 

#### 1 Kings 9:22 And from the sons of Israel {did not give Solomon} one for servitude, for they were men warriors, and his servants, and rulers, and his third rank, and rulers of his chariots, and his horsemen. 

#### 1 Kings 9:23 {were And the rulers} (the ones having knowledge over the works of Solomon) five hundred fifty dominating among the people doing work. 

#### 1 Kings 9:24 {the daughter And} of Pharaoh ascended from the city of David to her house, which he built to her. Then he built Millo. 

#### 1 Kings 9:25 And Solomon offered thrice in a year whole burnt-offerings and peace offerings upon the altar, the one he built to the LORD. And he burnt incense upon it, the one which was before the LORD, and he finished the house. 

#### 1 Kings 9:26 And {made king Solomon} a ship in Ezion Geber, the city being next to Eloth, upon the edge of the sea of the extreme part, in the land of Edom. 

#### 1 Kings 9:27 And Hiram sent in the ship {of his servants, men mariners}, people knowing to row the sea with the servants of Solomon. 

#### 1 Kings 9:28 And they came unto Ophir, and took from there four hundred and twenty talents of gold, and brought them to king Solomon. 

#### 1 Kings 10:1 And the queen of Sheba heard the name of Solomon, and the name of the LORD, and she came to test him with enigmas. 

#### 1 Kings 10:2 And she came to Jerusalem with {force heavy an exceedingly}, and camels lifting aromatics, and {gold much exceedingly}, and {stone valuable much}. And she went to king Solomon. And she spoke to him all as many things as was in her heart. 

#### 1 Kings 10:3 And {explained to her Solomon} all the words of her questions. There was not a word being overlooked by the king which he did not explain to her. 

#### 1 Kings 10:4 And {beheld the queen of Sheba} all the intellect of Solomon, and the house which he built, 

#### 1 Kings 10:5 and the foods for Solomon, and the form of his servants, and the position of his ministers, and their clothes, and his wine servers, and his whole burnt-offering which he offered in the house of the LORD; and {beside herself she was}. 

#### 1 Kings 10:6 And she said to king Solomon, {is true The word} which I heard in my land concerning the word about you, and concerning your intellect. 

#### 1 Kings 10:7 And I did not trust in the ones speaking to me, until of which I came and {have seen my eyes}. And behold, it is not according to the half as they reported to me. You have added wisdom and good things over all the report which I heard in my land. 

#### 1 Kings 10:8 Blessed are your wives, and blessed are {your servants these} standing before you continually, the ones hearing your intellect. 

#### 1 Kings 10:9 May {be the LORD your God} blessing whom he wants by you, to put you upon the throne of Israel; because the LORD loves Israel to establish it into the eon, and to set you for king over them, to execute judgment in righteousness, and in their equity. 

#### 1 Kings 10:10 And she gave to Solomon a hundred and twenty talents of gold, and {spices much exceedingly}, and {stone valuable}. There had not come as those spices yet in multitude which {gave the queen of Sheba} to king Solomon. 

#### 1 Kings 10:11 And the ship of Hiram, the one carrying the gold from out of Ophir, brought {timbers hewn much exceedingly}, and {stone valuable}. 

#### 1 Kings 10:12 And {made the king} the {timbers hewn} for supports of the house of the LORD, and the house of the king, and stringed instruments, and lutes for the singers. There had not come such {timbers unhewn} unto the land, nor was seen somewhere until this day. 

#### 1 Kings 10:13 And king Solomon gave to the queen of Sheba all as much as she wanted, and as much as she asked, outside of all which was given to her through the hand of king Solomon. And she returned and came unto her land, she and her servants. 

#### 1 Kings 10:14 And was the weight of the gold that came to Solomon in {year one} -- six hundred sixty and six talents of gold, 

#### 1 Kings 10:15 apart from the tribute of the ones submitting, and the merchants, and all the kings of the other side of the Jordan, and the satraps of the land. 

#### 1 Kings 10:16 And {made king Solomon} two hundred spears of gold hammered out -- six hundred weights of gold was used for the {spear one}. 

#### 1 Kings 10:17 And he made three hundred oblong shields of gold hammered out. Three minas of gold were used for the {oblong shield one}. And {put them the king} in the house of the forest of Lebanon. 

#### 1 Kings 10:18 And {made the king throne ivory a great}, and he gilded it {gold in unadulterated}. 

#### 1 Kings 10:19 there were Six stairs to the throne, and the upper part had calves from the places behind it to the throne. And There were hand rails on this side and that side upon the place of the chair, and two lions standing by the hand rails. 

#### 1 Kings 10:20 And there were twelve lions standing upon the six stairs on this side and that side. There was not such in any kingdom. 

#### 1 Kings 10:21 And all the vessels, the ones used by Solomon, were of gold. And bathing tubs of gold, and all the vessels of the house of the forest of Lebanon {of gold were completely}. And there was no silver, for it was not thought anything in the days of Solomon. 

#### 1 Kings 10:22 For a ship of Tarshish belonged to king Solomon upon the sea with the ships of Hiram. One {every three years came to the king ship} out of Tarshish with gold and silver, and {stones turned and hewn}. 

#### 1 Kings 10:23 And Solomon was magnified above all the kings of the earth in riches and intellect. 

#### 1 Kings 10:24 And all the kings of the earth sought the face of Solomon to hear of his intellect, which the LORD put in his heart. 

#### 1 Kings 10:25 And {to him brought each his gifts}, items of silver, and items of gold, and clothes, balsam and spices, and horses, and mules according to year by year. 

#### 1 Kings 10:26 And Solomon brought chariots and horsemen. And there were to him a thousand and four hundred chariots, and twelve thousand horsemen. And he put them in the cities of the chariots, and with the king in Jerusalem. 

#### 1 Kings 10:27 And {put the king} the silver in Jerusalem as stones, and the cedars he put as the sycamine trees in the plain in multitude. 

#### 1 Kings 10:28 And the exiting of the horsemen of Solomon was from out of Egypt. And from out of Kue the merchants of the king took merchandise from out of Kue in barter. 

#### 1 Kings 10:29 And there ascended an exiting from out of Egypt -- a chariot for six hundred pieces of silver, and a horse for a hundred fifty pieces of silver. And thus for all the kings of the Hittites, and to the kings of Syria, by their hand they came forth. 

#### 1 Kings 11:1 And king Solomon was fond of women, and he took {wives alien}, and the daughter of Pharaoh, and Moabitish, and Ammonitish, and Edomites, and Sidonians, and Hittites. 

#### 1 Kings 11:2 of the nations which the LORD forbade to the sons of Israel, saying, You shall not enter to them, and they shall not enter to you; that they should not turn aside your hearts after their idols -- for of them Solomon cleaved to love. 

#### 1 Kings 11:3 And there were to him {wives being female rulers seven hundred}, and {concubines three hundred}. And {inclined away his wives} his heart. 

#### 1 Kings 11:4 And it came to pass in a time of old age of Solomon, his wives turned aside his heart after other gods. And {was not his heart} perfect with the LORD his God, as was the heart of David his father. 

#### 1 Kings 11:5 And Solomon went after Ashtoreth god of the Sidonians, and after Milcom the abomination of Ammon. 

#### 1 Kings 11:6 And Solomon did evil before the LORD, and did not go after the LORD as David his father. 

#### 1 Kings 11:7 Then Solomon built a high place to Chemosh, the idol of Moab, in the mountain before Jerusalem, and to Molech the idol of the sons of Ammon. 

#### 1 Kings 11:8 And thus he did for all {wives his alien}, ones burning incense and sacrificing to their idols. 

#### 1 Kings 11:9 And the LORD was provoked to anger at Solomon, for he turned aside his heart from the LORD God of Israel -- the one appearing to him twice, 

#### 1 Kings 11:10 after being given charge to him, for this word thoroughly, to not go after other gods. And he did not guard what {gave charge to him the LORD}. 

#### 1 Kings 11:11 And the LORD said to Solomon, Because these things happened with you, and you did not guard my commandments, and my orders, which I gave charge to you, in tearing I will tear up your kingdom from out of your hand, and I will give it to your servant. 

#### 1 Kings 11:12 Except in your days I will not do them on account of David your father -- from out of the hand of your son I will take it. 

#### 1 Kings 11:13 Except the entire kingdom in no way shall I take. {chiefdom One} I will give to your son because of David my servant, and because of Jerusalem the city which I chose. 

#### 1 Kings 11:14 And the LORD raised up an adversary against Solomon, Hadad the Edomite; from out of the seed of the kingdom in Edom. 

#### 1 Kings 11:15 And it happened in David utterly destroying Edom, in the going of Joab the ruler of the military to bury the slain, that they smote every male in Edom; 

#### 1 Kings 11:16 for six months {laid in wait there Joab} and all Israel, until of which time he utterly destroyed every man of Edom. 

#### 1 Kings 11:17 And Hadad ran away, he and the Edomite men of the servants of his father with him. And they entered into Egypt. And Hadad {boy was a small}. 

#### 1 Kings 11:18 And they rose up out of Midian, and came into Paran. And they took men with themselves, and they came to Pharaoh king of Egypt. And Hadad entered to Pharaoh. And he gave to him a house, and {bread loaves ordered} for him, and {land gave} to him. 

#### 1 Kings 11:19 And Hadad found favor before Pharaoh, exceedingly. And he gave to him a wife, the sister of his wife -- the {sister of Tahpenes the older}. 

#### 1 Kings 11:20 And {bore to him the sister of Tahpenes}, to Hadad, Genubath her son. And {nourished him Tahpenes} in the midst of the house of Pharaoh. And Genubath was in the house of Pharaoh in the midst of the sons of Pharaoh. 

#### 1 Kings 11:21 And Hadad heard in Egypt that David had gone to sleep with his fathers, and that {had died Joab the ruler of the military}. And Hadad said to Pharaoh, Send me, and I will return unto my land. 

#### 1 Kings 11:22 And Pharaoh said to Hadad, What do you lack with me, that behold, you seek to go forth into your land? And {said to him Hadad}, Not one thing, but by sending you shall send me. 

#### 1 Kings 11:23 And God raised up an adversary against him, Rezon son of Eliadah, who fled from Hadadezer king of Zobah, his master. 

#### 1 Kings 11:24 And {were gathered together against him the men}, and he was ruler of the confederation, and he first took Damascus, and he settled in it, and he reigned in Damascus. 

#### 1 Kings 11:25 And there was an adversary to Israel all the days of Solomon. This is the evil which Hadad did, and oppressed against Israel, and he reigned in the land of Edom. 

#### 1 Kings 11:26 And Jeroboam son of Nebat the Ephrathite from Zereda, son {woman of a widow}, was a servant of Solomon. 

#### 1 Kings 11:27 And this was the thing he did as he lifted up the hand against king Solomon. And king Solomon built the Akra, and he completed the barrier of the city of David his father. 

#### 1 Kings 11:28 And the man Jeroboam was strong in power. And Solomon saw the young man that {a man of works he is}, and he placed him over the tribute of the house of Joseph. 

#### 1 Kings 11:29 And it came to pass in that time that Jeroboam came forth out of Jerusalem, and {found him Ahijah the Shilonite the prophet} in the way; and Ahijah separated him from the way. And Ahijah was wearing {cloak a new}, and both were alone in the plain. 

#### 1 Kings 11:30 And Ahijah took hold of his own cloak, the new one upon him, and he tore it into twelve pieces. 

#### 1 Kings 11:31 And he said to Jeroboam, Take for yourself ten pieces! for thus says the LORD God of Israel, Behold, I tear the kingdom from out of the hand of Solomon, and I give to you ten chiefdoms. 

#### 1 Kings 11:32 And two chiefdoms will be his, on account of my servant David, and on account of Jerusalem the city which I chose in it from out of all the tribes of Israel; 

#### 1 Kings 11:33 because he abandoned me, and offered unto Ashtoreth the abomination of the Sidonians, and to Chemosh the idol of Moab, and to Milcom the loathsome thing of the sons of Ammon. And he did not go in my ways to do the upright thing before me, and my orders, and my ordinances, as {did David his father}. 

#### 1 Kings 11:34 And in no way will I take the kingdom entirely from his hand (for by resisting I shall resist him all the days of his life) because of David my servant -- whom I chose him, who guarded the commandments and my ordinances. 

#### 1 Kings 11:35 And I shall take the kingdom from out of the hand of his son, and I will give to you the ten chiefdoms. 

#### 1 Kings 11:36 But to his son I will give the two chiefdoms, so that there might be a designation to my servant David all the days before me in Jerusalem, the city which I chose for myself to put my name there. 

#### 1 Kings 11:37 And you shall take, and you shall reign in wherever {desires your soul}, and you will be king over Israel. 

#### 1 Kings 11:38 And it will be if you should guard all as much as I gave charge to you, and should go in my ways, and do the upright thing before me, to keep my orders, and my commandments, as did David my servant; then I will be with you, and I shall build for you {house a sure}, as I built for David. 

#### 1 Kings 11:39 And I will give to you Israel, and I will mistreat the seed of David on account of these things, except not for all the days. 

#### 1 Kings 11:40 And Solomon sought to put Jeroboam to death. And he rose up, and ran away unto Egypt, to Shishak king of Egypt. And he was in Egypt until Solomon died. 

#### 1 Kings 11:41 And the rest of the words of Solomon, and all as many things as he did, and all his intellect -- behold, have not these been written in the scroll of the sayings of Solomon? 

#### 1 Kings 11:42 And the days which Solomon reigned in Jerusalem was forty years over all Israel. 

#### 1 Kings 11:43 And Solomon slept with his fathers, and they entombed him in the city of David his father. And {reigned Rehoboam his son} instead of him. 

#### 1 Kings 12:1 And {went king Rehoboam} to Shechem, for {unto Shechem came all Israel} to give him reign. 

#### 1 Kings 12:2 And it came to pass as {heard Jeroboam son of Nebat}, and he was still being in Egypt, as he had fled from the face of king Solomon, and settled in Egypt, 

#### 1 Kings 12:3 that they sent and called him. And Jeroboam came and all the people of Israel. And {spoke the people} to king Rehoboam, saying, 

#### 1 Kings 12:4 Your father hardened our neck yoke. And you now, lighten of {servitude of your father the hard}, and from {neck yoke his heavy}! of which he put upon us, and we will serve to you. 

#### 1 Kings 12:5 And he said to them, Go forth for {days three}, and return to me! And they went forth. 

#### 1 Kings 12:6 And {reported king Rehoboam} to the elders, the ones who were standing before Solomon his father {was still living while he}, saying, How do you counsel that I should answer to this people a word? 

#### 1 Kings 12:7 And they spoke to him, saying, If in this day you will be a servant to this people, and should serve them, and shall speak to them {words with good}, then they will be to you servants all the days. 

#### 1 Kings 12:8 And he abandoned the counsel of the elders which they advised him, and he took up advice with the young men being brought up with him, of the ones standing before his face. 

#### 1 Kings 12:9 And he said to them, What do you advise, and what should I answer to this people speaking to me, saying, Lighten up the neck yoke which {put your father} upon us? 

#### 1 Kings 12:10 And they spoke to him, the young men having been brought up with him; and they said, Thus you shall speak to this people, to the ones speaking to you, saying, Your father oppressed our neck yoke, and you now lighten it from us! Thus you shall say to them, My thinness {thicker than is} the loin of my father. 

#### 1 Kings 12:11 And now, my father saddled you with {neck yoke a heavy}, and I will add unto your neck yoke. My father corrected you with whips, but I will correct you with scorpions. 

#### 1 Kings 12:12 And Jeroboam came, and all Israel to king Rehoboam on the {day third} as {spoke to them the king}, saying, Return to me {day the third}! 

#### 1 Kings 12:13 And {answered the king} to the people hard. And Rehoboam abandoned the counsel of the elders which they advised him. 

#### 1 Kings 12:14 And he spoke to them according to the counsel of the young men, saying, My father oppressed your neck yoke, and I shall add to your neck yoke. My father corrected you with whips, and I will correct you with scorpions. 

#### 1 Kings 12:15 And {did not hear the king} the people, for he was converted by the LORD, so that {should stand his word}, which he spoke by the hand of Ahijah the Shilonite over Jeroboam son of Nebat. 

#### 1 Kings 12:16 And {knew all Israel} that {did not hearken to them the king}. And {answered the people} to the king, saying, What is our portion with David? and, There is no inheritance to us with the son of Jesse. Run, O Israel, to your tents! Now graze your own house, David! And Israel went forth to his tents. 

#### 1 Kings 12:17 And the sons of Israel, the ones dwelling in the cities of Judah -- {reigned over them Rehoboam}. 

#### 1 Kings 12:18 And {sent king Rehoboam} Adoram, the one for collecting the tribute. And {stoned him with stones all Israel}, and he died. And king Rehoboam anticipated to ascend upon the chariot to flee into Jerusalem. 

#### 1 Kings 12:19 And Israel annulled allegiance with the house of David until this day. 

#### 1 Kings 12:20 And it came to pass as {heard all Israel} that Jeroboam returned from out of Egypt, that they sent and called him to the congregation. And they gave him reign over Israel. And there was none following after the house of David except the chiefdom of Judah and Benjamin only. 

#### 1 Kings 12:21 And Rehoboam entered into Jerusalem, and he held an assembly of all the congregation of Judah, and the chiefdom of Benjamin -- a hundred and twenty thousand young men for making war, to wage war against the house of Israel, to return the kingdom of Rehoboam son of Solomon. 

#### 1 Kings 12:22 And there came to pass the word of the LORD to Shemaiah the man of God, saying, 

#### 1 Kings 12:23 Speak to Rehoboam son of Solomon king of Judah, and to all the house of Judah and Benjamin, and to the rest of the people! saying, 

#### 1 Kings 12:24 Thus says the LORD, You shall not ascend, nor wage war with your brethren of the sons of Israel. Let {return each} to his house! for from me {has taken place this thing}. And they hearkened to the word of the LORD, and they ceased to go against the thing of the LORD. 

#### 1 Kings 12:25 And Jeroboam built Shechem in mount Ephraim, and he dwelt in it. And he went forth from there and built Penuel. 

#### 1 Kings 12:26 And Jeroboam said in his heart, Behold, now {shall return the kingdom} to the house of David, 

#### 1 Kings 12:27 if {should ascend this people} to offer a sacrifice in the house of the LORD in Jerusalem, then {shall turn the heart of the people} towards their master, to Rehoboam king of Judah, and they shall kill me. 

#### 1 Kings 12:28 And {consulted the king}, and made two heifers of gold. And he said to the people, Let it be enough for you to ascend to Jerusalem! Behold, your gods, O Israel, the ones leading you from out of the land of Egypt. 

#### 1 Kings 12:29 And he put the one in Beth-el, and the other one he put in Dan. 

#### 1 Kings 12:30 And {came to pass account this} for sin. And {went the people} after the one unto Dan. 

#### 1 Kings 12:31 And he made houses upon high places, and he appointed priests from any part of the people who were not of the sons of Levi. 

#### 1 Kings 12:32 And Jeroboam made a holiday feast in the {month eighth}, on the fifteenth day of the month, according to the holiday, the one in Judah. And he ascended unto the altar which he made in Beth-el, to sacrifice to the heifers which he made. And he placed in Beth-el the priests of the high places which he made. 

#### 1 Kings 12:33 And he ascended unto the altar which he made in the fifteenth day in the {month eighth}, in the holiday which he shaped out of his own heart. And he made the holiday for the sons of Israel, and he ascended unto the altar to sacrifice upon it. 

#### 1 Kings 13:1 And behold, a man of God came from out of Judah with a word of the LORD unto Beth-el. And Jeroboam stood upon the altar to sacrifice. 

#### 1 Kings 13:2 And he called upon the altar with the word of the LORD, and said, O altar, O altar, thus says the LORD, Behold, a son is born to the house of David, Josiah is his name, and he shall sacrifice upon you the priests of the high places, the ones sacrificing upon you, and bones of men he shall burn upon you. 

#### 1 Kings 13:3 And he executed in that day a miracle, saying, This is the saying which the LORD spoke, saying, Behold, the altar is torn, and {shall be poured out the fatness being upon it}. 

#### 1 Kings 13:4 And it came to pass as {heard king Jeroboam} the words of the man of God. of the one calling upon the altar in Beth-el, that he stretched out his hand from the altar, saying, Seize him! And {withered his hand} which he stretched out against him, and he was not able to return it to himself. 

#### 1 Kings 13:5 And the altar tore, and {poured out the fatness} from the altar, according to the portent which {gave the man of God} by the word of the LORD. 

#### 1 Kings 13:6 And {answered the king}, and said to the man of God, Beseech the face of the LORD your God, and return my hand to me! And {beseeched the man of God} the face of the LORD, and {returned the hand of the king} to him, and it became as formerly. 

#### 1 Kings 13:7 And {spoke the king} to the man of God, Enter with me to my house and dine, and I will give to you a gift! 

#### 1 Kings 13:8 And {said the man of God} to the king, If you should give to me half of your house, I will not enter with you, neither will I eat bread, nor drink water in this place. 

#### 1 Kings 13:9 For thus {gave charge to me the LORD} by a word, saying, In no way should you eat bread, nor in any way should you drink water, nor in any way should you return in the way in which you came by it. 

#### 1 Kings 13:10 And he went forth by {way another}, and did not return in the way which he came by it unto Beth-el. 

#### 1 Kings 13:11 And a prophet, one old man, dwelt in Beth-el. And {came his sons} and described to him all the works which {did the man of God} in that day in Beth-el, and the words which he spoke to the king. And they turned the face of their father. 

#### 1 Kings 13:12 And {said to them their father}, saying, Which way has he went? And {showed to him his sons} the way which {went the man of God}, the one coming from out of Judah. 

#### 1 Kings 13:13 And he said to his sons, Saddle for me the donkey! And they saddled for him the donkey. And he mounted upon him, 

#### 1 Kings 13:14 and he went after the man of God. And he found him sitting down under the oak. And he said to him, Are you the man of God, the one coming from out of Judah? And he said, I am. 

#### 1 Kings 13:15 And he said to him, Come with me, and eat bread! 

#### 1 Kings 13:16 And he said, In no way am I able to return with you, nor should I eat bread, nor in any way should I drink water in this place. 

#### 1 Kings 13:17 For so it has been given charge to me by the word of the LORD, saying, You shall not eat bread there, and you shall not drink water, and you shall not return there in the way in which you went by it. 

#### 1 Kings 13:18 And he said to him, And I am a prophet as you, and an angel spoke to me by word of the LORD, saying, Return him with yourself to your house, and let him eat bread, and drink water! But he lied to him. 

#### 1 Kings 13:19 And he returned him, and he ate bread, and he drank water in his house. 

#### 1 Kings 13:20 And it came to pass of them sitting down at the table, that {came the word of the LORD} to the prophet, the one having returned him. 

#### 1 Kings 13:21 And he said to the man of God, the one having come from out of Judah, saying, Thus says the LORD, Because you rebelled against the saying of the LORD, and did not guard the commandment which {gave charge to you the LORD your God}, 

#### 1 Kings 13:22 but you returned and ate bread, and drank water in this place, in which he spoke to you, saying, You shall not eat bread nor drink water -- in no way shall {enter body your} into the burying-place of your fathers. 

#### 1 Kings 13:23 And it came to pass after he ate bread and drank water, that he saddled for him the donkey, for the prophet, and he returned. 

#### 1 Kings 13:24 And he went forth. And {found him a lion} in the way, and it killed him. And {was his body} tossed in the way, and the donkey stood by it, and the lion stood by the body. 

#### 1 Kings 13:25 And behold, men coming near also beheld the decaying flesh tossed in the way, and the lion standing next to the decaying flesh. And they entered and spoke in the city of which the prophet, the old man, dwelt in it. 

#### 1 Kings 13:26 And {heard the one returning him from out of the way}, and said, {the man of God This is} who rebelled against the word of the LORD; and {gave him the LORD} to the lion, and it broke him, and it killed him, according to the word of the LORD which he spoke to him. 

#### 1 Kings 13:27 And he spoke to his sons, saying, Saddle for me the donkey! And they saddled it. 

#### 1 Kings 13:28 And he went and found his body having been tossed in the way, and the donkey and the lion were standing by the body, and {did not eat the lion} the body, and it did not tear apart the donkey. 

#### 1 Kings 13:29 And {lifted the prophet} the body of the man of God, and he placed it upon the donkey, and he returned it to the city of the {prophet old}, to lament and to entomb him. 

#### 1 Kings 13:30 And he put his body in his tomb; and they lamented him, saying, Woe O brother. 

#### 1 Kings 13:31 And it came to pass after lamenting him, that he said to his sons, saying, If I die, entomb me in this tomb in which the man of God was entombed in it! {by his bones Put me}! that {should be preserved bones my} with his bones. 

#### 1 Kings 13:32 For {coming to pass will be the saying which he spoke by the word of the LORD} against the altar in Beth-el, and against the houses of the high places, of the ones in Samaria. 

#### 1 Kings 13:33 And after this saying {did not turn Jeroboam} from his evil, but he returned and appointed from part of the people priests of the high places. The one wanting to be a priest he filled the post by his hand, and he became priest of the high places. 

#### 1 Kings 13:34 And it came to pass this thing became sin to the house of Jeroboam, and for ruin, and for extinction from the face of the earth. 

#### 1 Kings 14:1 In that time {was ill Abijah son of Jeroboam}. 

#### 1 Kings 14:2 And {to his wife said Jeroboam}, Rise up and change that they shall not know that you are the wife of Jeroboam, and go unto Shiloh! Behold, {is there Ahijah the prophet}, he spoke unto me to reign over this people. 

#### 1 Kings 14:3 And take in your hand ten bread loaves, and small cakes, and a jar of honey, and you shall go to him. He will announce to you what will be to the child. 

#### 1 Kings 14:4 And {did thus the wife of Jeroboam}. And she rose up, and went to Shiloh, and she entered into the house of Ahijah. And the man was old for seeing, and {were blunted his eyes} from his old age. 

#### 1 Kings 14:5 And the LORD said to Ahijah, Behold, the wife of Jeroboam enters to seek an utterance from you concerning her son, for he is ill. According to this and according to that you shall speak to her. And it came to pass in her entering that she was as a stranger. 

#### 1 Kings 14:6 And it came to pass as Ahijah heard the sound of her feet of her entering in the passage, that he said, Enter, O wife of Jeroboam! why is this you are as a stranger, and I am {envoy to you a harsh}? 

#### 1 Kings 14:7 In going, say to Jeroboam, Thus says the LORD God of Israel, Because as much as I exalted you from the midst of the people, and appointed you leading over the people of Israel, 

#### 1 Kings 14:8 and tore the crown of state from the house of David, and gave it to you; and yet you have not become as my servant David, who kept my commandments, and who went after me with all his heart, to do the upright thing in my eyes. 

#### 1 Kings 14:9 But you did wickedly doing more than all as many as were in front of you. And you went and made for yourself other gods, and molten images, to provoke me to anger, and tossed me behind you. 

#### 1 Kings 14:10 On account of this behold, I bring evil to the house of Jeroboam, and I will utterly destroy of Jeroboam the one urinating against a wall, the one coming and the one being left behind in Israel. And I shall choose over the house of Jeroboam as one chooses the dung unto finishing it. 

#### 1 Kings 14:11 The one having died of Jeroboam in the city {shall devour the dogs}. And the one having died in the field {shall devour the birds of heaven}; for the LORD spoke. 

#### 1 Kings 14:12 And you, rising up, go unto your house! In the entering {feet of your} in the city {shall die the child}. 

#### 1 Kings 14:13 And {shall lament him all Israel}, and entomb him, for this one only shall enter of Jeroboam to the tomb, for there shall be found in him {word a good} concerning the LORD God of Israel among the house of Jeroboam. 

#### 1 Kings 14:14 And the LORD will raise up for himself a king over Israel who shall strike the house of Jeroboam this day, and yet also indeed now. 

#### 1 Kings 14:15 And the LORD shall strike Israel as {shaken a reed} in the water. And he shall pluck out Israel upward {soil good of this} of which he gave to their fathers. And he shall winnow them on the other side of the river, because of as many {they made of their sacred groves}, provoking {to anger the LORD}. 

#### 1 Kings 14:16 And the LORD gave Israel favor from the sins of Jeroboam, who sinned and who led Israel into sin. 

#### 1 Kings 14:17 And {rose up the wife of Jeroboam}, and went unto Tizrah. And it came to pass as she entered in the threshold of the house, that the child died. 

#### 1 Kings 14:18 And they entombed it, and {lamented it all Israel}, according to the word of the LORD, the word he spoke by the hand of his servant Ahijah the prophet. 

#### 1 Kings 14:19 And the extra things of Jeroboam, as much as he waged war, and as much as he reigned, behold, they are written in the scroll of the words of the days of the kings of Israel. 

#### 1 Kings 14:20 And the days which Jeroboam reigned were twenty and two years. And he slept with his fathers, and {reigned Nadab his son} instead of him. 

#### 1 Kings 14:21 And Rehoboam son of Solomon reigned over Judah. {a son being forty and one years old Rehoboam was} in his being given reign. And seventeen years he reigned in Jerusalem, in the city in which the LORD chose to put his name there from all of the tribes of Israel. And the name of his mother was Naamah the Ammonitess. 

#### 1 Kings 14:22 And Judah acted wickedly before the LORD, and provoked him to jealousy in all the things which {did his fathers} in their sins which they sinned. 

#### 1 Kings 14:23 And they built for themselves high places, and monuments, and sacred groves upon every {hill high}, and underneath every {tree shady}. 

#### 1 Kings 14:24 And bonding together took place in the land, and they did from all the abominations of the nations which the LORD removed in front of the sons of Israel. 

#### 1 Kings 14:25 And it came to pass in the {year fifth} of the reigning of Rehoboam, {ascended Shishak king of Egypt} against Jerusalem. 

#### 1 Kings 14:26 And he took all the treasures of the house of the LORD, and the treasures of the house of the king, even the whole he took, and the shields of gold which Solomon made. 

#### 1 Kings 14:27 And {made Rehoboam the king} shields of brass instead of them, and {were set in place by him the leaders of the bodyguards}, the ones guarding the vestibule of the house of the king. 

#### 1 Kings 14:28 And it came to pass when {entered the king} into the house of the LORD, that {lifted them the bodyguards}, and fastened them in the vestibule of the bodyguards. 

#### 1 Kings 14:29 And the rest of the words of Rehoboam, and all the things which he did, {not behold these are} written upon the scroll of the words of the days of the kings of Judah? 

#### 1 Kings 14:30 And there was war between Rehoboam and Jeroboam all the days. 

#### 1 Kings 14:31 And Rehoboam slept with his fathers. And they entombed him with his fathers in the city of David. And the name of his mother was Naamah the Ammonitess. And {reigned Abijam his son} instead of him. 

#### 1 Kings 15:1 And in the eighteenth year of the reigning of Jeroboam son of Nebat, {reigned Abijam son of Rehoboam} over Judah. 

#### 1 Kings 15:2 And three years he reigned in Jerusalem, and the name of his mother was Maachah daughter of Abishalom. 

#### 1 Kings 15:3 And he went in the sins of his father which he did before him. And {was not his heart} perfect with the LORD his God, as the heart of David his grand father. 

#### 1 Kings 15:4 But on account of David {gave to him the LORD his God} a vestige in Jerusalem, that he should establish his children after him, and establish Jerusalem, 

#### 1 Kings 15:5 as David did the upright thing before the LORD, and did not turn aside from all which he gave charge to him, all the days of his life, 

#### 1 Kings 15:6 except in the matter of Uriah the Hittite. And war was between Rehoboam and between Jeroboam all the days of his life. 

#### 1 Kings 15:7 And the rest of the words of Abijam and all the things which he did, {not behold these are} written upon the scroll of the words of the days of the kings of Judah? And there was war between Abijam and between Jeroboam. 

#### 1 Kings 15:8 And Abijam slept with his fathers. And they entombed him in the city of David. And {reigned Asa his son} instead of him. 

#### 1 Kings 15:9 In the {year twentieth} of Jeroboam king of Israel, Asa reigned over Judah. 

#### 1 Kings 15:10 And forty and one year he reigned in Jerusalem. And the name of his mother was Maachah daughter of Abishalom. 

#### 1 Kings 15:11 And Asa did the upright thing before the LORD as David his father. 

#### 1 Kings 15:12 And he removed the mystic rites from the land, and sent out all the practices which {did his fathers}. 

#### 1 Kings 15:13 And {Maachah his mother he removed} so as to not be ruling, as she observed a convocation in her sacred grove. And Asa cut off her retreats, and he burnt them in fire at the rushing stream Kidron. 

#### 1 Kings 15:14 But the high places he removed not. Except the heart of Asa was perfect with the LORD all his days. 

#### 1 Kings 15:15 And Asa carried into the house of the LORD the monumental pillars of his father, and the monumental pillars of silver and of gold, and he carried into the house of the LORD silver and gold and vessels. 

#### 1 Kings 15:16 And there was war between Asa and between Baasha king of Israel all their days. 

#### 1 Kings 15:17 And {ascended Baasha king of Israel} against Judah, and he built Ramah, so as not to be going forth and entering to Asa king of Judah. 

#### 1 Kings 15:18 And Asa took all the silver and the gold being found in the treasuries of the house of the LORD, and in the treasuries of the house of the king; and he put them into the hands of his servants. And {sent them king Asa} to the son of Hadad, son of Tabrimon, son of Hezion, king of Syria, the one dwelling in Damascus, saying, 

#### 1 Kings 15:19 A covenant between me and between you, and between my father and your father! Behold, I have sent to you gifts of silver and of gold, come efface your covenant with Baasha king of Israel! and he shall ascend from me. 

#### 1 Kings 15:20 And {hearkened the son of Hadad} to king Asa, and he sent the rulers of his force in to the cities of Israel. And he struck Ijon, and Dan, and Abel of the house of Maachah, and all Cinneroth, unto all the land of Naphtali. 

#### 1 Kings 15:21 And it came to pass when Baasha heard, that he stopped the building of Ramah, and he returned unto Tizrah. 

#### 1 Kings 15:22 And king Asa exhorted all Judah with no exceptions. And they lifted the stones of Ramah, and its timbers, which Baasha constructed. And {built with them Asa the king} the hill of Benjamin, and the height. 

#### 1 Kings 15:23 And the rest of the words of Asa, and all his dominion, and all which he did, and the cities which he built, {not behold these written are} upon a scroll of the words of the days of the kings of Judah? Only in the time of his old age {caused pain his feet}. 

#### 1 Kings 15:24 And Asa slept with his fathers. And they entombed him with his fathers in the city of David his fore father. And {reigned Jehoshaphat his son} instead of him. 

#### 1 Kings 15:25 And Nadab son of Jeroboam reigned over Israel in {year the second} of Asa king of Judah. And he reigned over Israel two years. 

#### 1 Kings 15:26 And he acted wickedly before the LORD, and he went in the way of his father, and in his sins in the things which led Israel into sin. 

#### 1 Kings 15:27 And {besieged against him Baasha son of Ahijah over the house of Issachar}, and he struck him in Gibbethon, the city of the Philistines; for Nadab and all Israel were besieging at Gibbethon. 

#### 1 Kings 15:28 And {put him to death Baasha} in {year the third} of Asa king of Judah. And he reigned instead of him. 

#### 1 Kings 15:29 And it came to pass as he reigned, he struck the entire house of Jeroboam; and he left not any that breathed of Jeroboam, until utterly destroying him, (according to the saying of the LORD, which he spoke by the hand of his servant Ahijah the Shilonite,) 

#### 1 Kings 15:30 for the sins of Jeroboam, which he led Israel into sin, and in his provoking to anger in which he provoked to anger the LORD God of Israel. 

#### 1 Kings 15:31 And the rest of the words of Nadab, and all the things which he did, {not behold these written are} in a scroll of the words of the days of the kings of Israel? 

#### 1 Kings 15:32 And war was between Asa and between Baasha king of Israel all their days. 

#### 1 Kings 15:33 In the {year third} of Asa king of Judah, {reigned Baasha son of Ahijah} over Israel in Tizrah twenty and four years. 

#### 1 Kings 15:34 And he did the wicked thing before the LORD, and he went in the way of Jeroboam son of Nebat, and in his sins in which he led Israel into sin. 

#### 1 Kings 16:1 And came to pass the word of the LORD unto Jehu son of Hanani against Baasha, saying, 

#### 1 Kings 16:2 Because I exalted you above the earth, and gave you lead over my people Israel, and you went in the way of Jeroboam, and led {into sin my people Israel}, to provoke me to anger by their vanities; 

#### 1 Kings 16:3 behold, I arouse enemies after Baasha, and after his house. And I will appoint your house as the house of Jeroboam son of Nebat. 

#### 1 Kings 16:4 The one having died of Baasha in the city, {shall eat him the dogs}. And the one having died of his in the plain, {shall eat him the birds of the heaven}. 

#### 1 Kings 16:5 And the rest of the words of Baasha, and all which he did, and his dominations, {not behold these are} written in the scroll of the words of the days of the kings of Israel? 

#### 1 Kings 16:6 And Baasha slept with his fathers, and they entombed him in Tirzah, and {reigned Elah his son} instead of him. 

#### 1 Kings 16:7 And the LORD spoke by the hand of Jehu son of Hanani against Baasha, and against his house, and upon all the evil which he did before the LORD, provoking him to anger by the works of his hands, for him to be as the house of Jeroboam, and for striking him. 

#### 1 Kings 16:8 In the eighth and twentieth year of Asa king of Judah, Elah son of Baasha reigned over Israel in Tirzah two years. 

#### 1 Kings 16:9 And {was confederated against him his servant} -- Zimri the ruler of half the chariots. And Elah was in Tirzah drinking, being intoxicated in the house of Azra the manager, the one in Tirzah. 

#### 1 Kings 16:10 And Zimri entered and struck him, and killed him in {year the seventh and twentieth}, and he reigned instead of him. 

#### 1 Kings 16:11 And it came to pass in his taking reign, in his sitting upon his throne, he struck the entire house of Baasha. And he left not to it one urinating against the wall, even the relatives and his friends. 

#### 1 Kings 16:12 And Zimri destroyed all the house of Baasha, according to the saying which the LORD spoke against the house of Baasha, by Jehu the prophet, 

#### 1 Kings 16:13 on account of all the sins of Baasha, and {Elah his son}, as he led Israel into sin, provoking to anger the LORD God of Israel in their vanities. 

#### 1 Kings 16:14 And the rest of the words of Elah, and all which he did, {not behold these are} written in the scroll of the words of the days of the kings of Israel? 

#### 1 Kings 16:15 In the twentieth and seventh year of Asa king of Judah, Zimri reigned in Tizrah seven days. And the camp of Israel was upon Gibbethon the city of the Philistines. 

#### 1 Kings 16:16 And {heard the people} in the camp, saying, Zimri conspired and smote the king. And they gave reign in Israel to Omri, the one leading the military over Israel in that day, in the camp. 

#### 1 Kings 16:17 And Omri ascended from Gibbethon, and all Israel with him, and they besieged against Tizrah. 

#### 1 Kings 16:18 And it came to pass as Zimri beheld that {was taken his city}, that he entered into the inner room of the house of the king, and he set on fire {over himself the house of the king} with fire, and he died 

#### 1 Kings 16:19 for his sins which he did to act wickedly before the LORD, to go in the way of Jeroboam son of Nebat, and in his sins which he committed as he led Israel into sin. 

#### 1 Kings 16:20 And the rest of the words of Zimri, and his associations which he joined in, {not behold these are} written in the scroll of the words of the days of the kings of Israel? 

#### 1 Kings 16:21 Then {parted the people of Israel}; half the people went after Tibni son of Ginath for him to reign, and half of the people went after Omri. 

#### 1 Kings 16:22 And the people being after Omri prevailed against the people that followed after Tibni son of Ginath. And Tibni died, and Omri reigned. 

#### 1 Kings 16:23 In the thirtieth and first year of Asa king of Judah, Omri reigned over Israel twelve years. In Tirzah he reigned six years. 

#### 1 Kings 16:24 And Omri acquired the mountain Samaria from Shemer the lord of the mountain for two talents of silver. And he built on the mountain, and he called the name of the mountain which he built upon after the name of Shemer the lord of the mountain -- Samaria. 

#### 1 Kings 16:25 And Omri did the wicked thing before the LORD, and was wicked over all the ones being prior of him. 

#### 1 Kings 16:26 And he went in all the way of Jeroboam son of Nebat, and in his sins in which he led Israel into sin, to provoke to anger the LORD God of Israel in their vanities. 

#### 1 Kings 16:27 And the rest of the words of Omri, and all which he did, and his dominations, {not behold these are} written in the scroll of the words of the days of the kings of Israel? 

#### 1 Kings 16:28 And Omri slept with his fathers, and they entombed him in Samaria. And {reigned Ahab his son} instead of him. 

#### 1 Kings 16:29 But Ahab son of Omri reigned over Israel in {year the thirtieth and eighth} of Asa king of Judah. {reigned And Ahab son of Omri} over Israel in Samaria twenty and two years. 

#### 1 Kings 16:30 And Ahab did the wicked thing before the LORD, and he was wicked above all the ones prior of him. 

#### 1 Kings 16:31 And it was not enough for him to go in the sins of Jeroboam son of Nebat, but he took for wife Jezebel the daughter of Ethbaal king of the Sidonians. And he went and served to Baal, and did obeisance to him. 

#### 1 Kings 16:32 And he set up an altar to Baal in the house of Baal which he built in Samaria. 

#### 1 Kings 16:33 And Ahab prepared the sacred grove. And Ahab proceeded to make provocations to provoke {to anger the LORD God of Israel} above all the kings of Israel being prior of him. 

#### 1 Kings 16:34 In his days, {built Hiel the Beth-elite} Jericho; {with Abiram his first-born he laid its foundation}, and with Segub his younger he set up its doors, according to the saying of the LORD, which he spoke by the hand of Joshua son of Nun. 

#### 1 Kings 17:1 And {said Elijah the Tishbite}, the one from Tishbon of Gilead, to Ahab, As the LORD lives, the God of Israel, in whom I stand before him, Shall there be these years dew and rain, no, but unless it be through the word of my mouth. 

#### 1 Kings 17:2 And came to pass the saying of the LORD to Elijah. 

#### 1 Kings 17:3 Go from here according to the east, and hide at the rushing stream Cherith, to the one upon the face of the Jordan! 

#### 1 Kings 17:4 And it will be from out of the rushing stream you shall drink water, and to the crows I shall give charge to nourish you there. 

#### 1 Kings 17:5 And {went and did Elijah} according to the saying of the LORD. And he settled by the rushing stream Cherith upon the face of the Jordan. 

#### 1 Kings 17:6 And the crows brought to him bread loaves and meat in the morning, and bread loaves and meat in the afternoon. And from out of the rushing stream he drank water. 

#### 1 Kings 17:7 And it came to pass after many days, that {dried up the rushing stream}, for there was no rain upon the earth. 

#### 1 Kings 17:8 And {came to pass the word of the LORD} to Elijah, saying, 

#### 1 Kings 17:9 Rise up, and go into Sarepta of the Sidonians! and you shall dwell there. Behold, I have given charge there {woman for a widow} to nourish you. 

#### 1 Kings 17:10 And he rose up and went into Sarepta. And he came unto the gate-house of the city. And behold, there {woman a widow} was collecting together wood. And {yelled out after her Elijah}, and said to her, Take indeed for me a little water into a container, and I shall drink. 

#### 1 Kings 17:11 And she went to take, and {yelled out after her Elijah}, and said to her, Give indeed to me the morsel of bread in your hand, and I will eat. 

#### 1 Kings 17:12 And {said the woman}, As {lives the LORD your God}, If there is to me a cake baked in hot ashes -- good? but I have only as much as a handful of flour in the pitcher, and a little olive oil in the jar. And behold, I shall collected together two sticks, and I shall enter and make it for myself and my children, and we shall eat and die. 

#### 1 Kings 17:13 And {said to her Elijah}, Be of courage! enter and do according to your word! But make for me from there {cake baked in hot ashes a small} at first, and bring it forth to me! and to yourself you shall make and to your children at last. 

#### 1 Kings 17:14 For thus says the LORD God of Israel, The pitcher of flour shall not fail, and the jar of olive oil shall not have less, until the days of the giving by the LORD the rain upon the earth. 

#### 1 Kings 17:15 And {went the woman} and did according to the word of Elijah; and she gave to him, and he ate, and she, and her children. 

#### 1 Kings 17:16 And the pitcher of flour failed not, and the jar of olive oil had not less, according to the saying of the LORD, which he spoke by the hand of Elijah. 

#### 1 Kings 17:17 And it came to pass after these things that {became ill the son of the woman who was the lady of the house}, and {was illness his} fortified very much, until there was not left behind in him a breath. 

#### 1 Kings 17:18 And she said to Elijah, What is it to me and to you, O man of God, for you to enter to me, to call to mind my iniquities and to kill my son? 

#### 1 Kings 17:19 And Elijah said to the woman, Give me your son! And he took him from out of her bosom, and brought him into the upper room in which he settled there, and he rested him upon his bed. 

#### 1 Kings 17:20 And Elijah yelled out to the LORD, and he said, O LORD my God, also indeed the widow with whom I dwell with her, have you inflicted evil to kill her son? 

#### 1 Kings 17:21 And he breathed into the boy three times, and he called upon the LORD, and he said, O LORD my God, return indeed the life of this boy to him! 

#### 1 Kings 17:22 And it became so, and {returned the life of the boy} to him. And {yelled out the boy}. 

#### 1 Kings 17:23 And he led him from the upper room into the house, and he gave it to his mother. And Elijah said, See! {lives your son}. 

#### 1 Kings 17:24 And {said the woman} to Elijah, Behold, I know that {a man of God you are}, and the word of the LORD in your mouth is true. 

#### 1 Kings 18:1 And it came to pass after {days many}, and the word of the LORD came to Elijah in {year the third}, saying, Go, and appear to Ahab! and I will put rain upon the face of the earth. 

#### 1 Kings 18:2 And Elijah went to appear to Ahab, and there was {famine a strong} in Samaria. 

#### 1 Kings 18:3 And Ahab called Obadiah the manager. And Obadiah was fearing the LORD exceedingly. 

#### 1 Kings 18:4 And it came to pass when Jezebel struck the prophets of the LORD, that Obadiah took a hundred prophets, and he hid them by fifty in two caves, and nourished them with bread and water. 

#### 1 Kings 18:5 And Ahab said to Obadiah, Come, and we should go through in the land unto the springs of the waters, and unto all the rushing streams, if perchance we should find pasturage, and we should preserve the horses and mules, and {shall not be destroyed from us cattle}. 

#### 1 Kings 18:6 And they divided to themselves the way to go by it; Ahab went by {way one}, and Obadiah went by {way another} alone. 

#### 1 Kings 18:7 And Obadiah was in the way alone, and behold, Elijah came to meet with him. And Obadiah hastened and fell upon his face, and he said, Are you he, O my master, Elijah? 

#### 1 Kings 18:8 And Elijah said to him, I am, Go, tell your master, Behold, Elijah! 

#### 1 Kings 18:9 And Obadiah said, How have I sinned that you appoint your servant into the hands of Ahab to kill me? 

#### 1 Kings 18:10 As {lives the LORD your God}, is there a nation or kingdom of which {did not send my master} to seek you? And if they said, He is not here; then he adjured the kingdom and its places, for he did not find you. 

#### 1 Kings 18:11 And now you say, Go announce to your master, Behold, Elijah! 

#### 1 Kings 18:12 And it will be if I should go forth from you, and a wind of the LORD shall lift you into the land which I do not know, and I shall enter to report to Ahab, and he should not find you, then he will kill me. But your servant is fearing the LORD from out of his youth. 

#### 1 Kings 18:13 Or was it not reported to you, O my master, what things I have done when Jezebel killed the prophets of the LORD, that I took some of the prophets of the LORD -- a hundred men, and I hid them in the caves by fifty, and I maintained them with bread loaves and water? 

#### 1 Kings 18:14 And now you say, Go, tell your master, Behold, Elijah! and he will kill me. 

#### 1 Kings 18:15 And Elijah said, As {lives the LORD of the forces}, in which I stand before him, that today I will appear to him. 

#### 1 Kings 18:16 And Obadiah went to meet with Ahab, and he reported to him. And Ahab ran forth and went to meet with Elijah. 

#### 1 Kings 18:17 And it came to pass as Ahab saw Elijah, that Ahab said to Elijah, Are you he turning aside Israel? 

#### 1 Kings 18:18 And Elijah said, I do not turn aside Israel, but you, and the house of your father, in your leaving the LORD your God, and to go after the Baalim. 

#### 1 Kings 18:19 And now, send and gather together to me all Israel at mount Carmel, and the prophets of Baal -- four hundred and fifty, and the prophets of the sacred groves -- four hundred, eating at the table of Jezebel! 

#### 1 Kings 18:20 And Ahab sent into all Israel, and he assembled all the prophets to mount Carmel. 

#### 1 Kings 18:21 And Elijah came near to all the people, and he said to them, For how long will you be lame upon both your hams? If the LORD is God, go after him! But if Baal, go after him! And {answered not the people} a word. 

#### 1 Kings 18:22 And Elijah said to the people, I am left {a prophet of the LORD alone}, and the prophets of Baal are four hundred and fifty men. 

#### 1 Kings 18:23 Give then to us two oxen, and let them choose for themselves one, and let them dismember it, and place it upon the wood, and {fire do not put} upon it! And I will do the same {ox with the other}, and {fire in no way will I put} upon it. 

#### 1 Kings 18:24 And you yell out in the name of your gods, and I will call upon the name of the LORD my God. And it will be the God who ever heeds by fire, this is God. And {answered all the people} and said, {is good The word} which you have spoken. 

#### 1 Kings 18:25 And Elijah said to the prophets of Baal, Choose for yourselves the {ox one}, and prepare it first! for you are many; and call in the name of your god, and {fire do not put} upon it! 

#### 1 Kings 18:26 And they took the ox, and offered it, and they called in the name of Baal from morning until midday. And they said, Heed us, O Baal, heed us! And there was no sound, and there was no hearing a thing. And they ran upon the altar of which they made. 

#### 1 Kings 18:27 And it became midday, and {sneered at them Elijah the Tishbite}, and he said, Call with {voice a great}! perhaps {in meditation some he is himself}, and at the same time perhaps {executing business he is}, or perhaps he sleeps and shall rise up. 

#### 1 Kings 18:28 And they called out with {voice a great}, and mutilated themselves according to their custom with knives and by spears, until {poured out blood} of them. 

#### 1 Kings 18:29 And they prophesied until of which time it went into the midday. And it came to pass as the time of the midday to ascend for the sacrifice -- and there was no sound, and there was no hearing. 

#### 1 Kings 18:30 And Elijah said to the people, Come forward to me! And {came forward all the people} to him. And he repaired the altar, the one having been razed. 

#### 1 Kings 18:31 And Elijah took twelve stones, according to the number of the tribes of Israel, as the LORD spoke to him, saying, Israel will be your name. 

#### 1 Kings 18:32 And he built the stones in the name of the LORD, and he repaired the altar of the LORD, the one having been razed. And he made a sea, having the space to hold two measures of seed, round about the altar. 

#### 1 Kings 18:33 And he put the kindling upon the altar which he made. And he dismembered the whole burnt-offering, and he put it upon the kindling, and he piled upon the altar. And Elijah said, Bring to me four {pitchers water}, and pour upon the whole burnt-offering, and upon the kindling! 

#### 1 Kings 18:34 And he said, Repeat it a second time! And they repeated it a second time. And he said, Do it a third time! And they did it a third time. 

#### 1 Kings 18:35 And {went the water} round about the altar, and the sea filled with water. 

#### 1 Kings 18:36 And as it was time of the offering the sacrifice, and {came Elijah the prophet} and said, O LORD God of Abraham, and Isaac, and Israel, today let it be known to all this people! that you are the LORD God of Israel, and I am your servant, and through you I have done all these things. 

#### 1 Kings 18:37 Heed me, O LORD, heed me! And let {know this people} that you are the LORD God! and you turned the heart of this people back. 

#### 1 Kings 18:38 And {fell fire} from the LORD from out of the heaven, and it devoured the whole burnt-offering, and the kindling, and the water in the sea, and the stones, and the dust was licked up by the fire. 

#### 1 Kings 18:39 And {saw all the people}, and fell upon their face. And they said, Truly, the LORD is God. The LORD, he is God. 

#### 1 Kings 18:40 And Elijah said to the people, Seize the prophets of Baal, let not one {escape of them}! And they seized them. And {led them down Elijah} unto the rushing stream Kishon, and slew them there. 

#### 1 Kings 18:41 And Elijah said to Ahab, Ascend, and eat, and drink! for it is the sound of the noise of the rain. 

#### 1 Kings 18:42 And Ahab ascended to eat and to drink. And Elijah ascended unto Carmel, and bowed upon the ground, and put his face between his knees. 

#### 1 Kings 18:43 And he said to his servant-lad, Ascend, and look the way of the sea! And {ascended and looked the servant-lad}. And he said, There is nothing. And Elijah said, Return seven times! 

#### 1 Kings 18:44 And it came to pass in the seventh time, and behold, {cloud a small} as the sole of a man's foot came with water from the sea. And he said, Ascend and say to Ahab! Team up your chariot, and go down, lest {should overtake you the rain}! 

#### 1 Kings 18:45 And it happened from here and here, and the heaven darkened with clouds and wind, and there became {rain a great}. And Ahab rode horseback, and went unto Jezreel. 

#### 1 Kings 18:46 And the hand of the LORD came upon Elijah, and he fastened his loin, and he ran in front of Ahab unto Jezreel. 

#### 1 Kings 19:1 And Ahab announced to Jezebel all as much as Elijah did, and as to kill the prophets by the broadsword. 

#### 1 Kings 19:2 And Jezebel sent to Elijah, and said, Thus may {do to me the gods}, and thus may they add, that this hour tomorrow I shall put your life as the life of one of them. 

#### 1 Kings 19:3 And Elijah feared, and rose up, and went forth for his life. And he came into Beersheba of Judah. And he left his servant-lad there. 

#### 1 Kings 19:4 And he went by the wilderness way a day. And came and stayed underneath a broom shrub, and he asked for his life to die. And he said, It is fit now, O LORD, take indeed my life from me! for {no better I am} than my fathers. 

#### 1 Kings 19:5 And he bedded down and slept there under a plant. And behold, a certain angel touched him, and said to him, Rise up, and eat! 

#### 1 Kings 19:6 And he looked. And behold, by his head was a cake baked in hot ashes of oaten bread, and a jar of water. And Elijah rose up and ate and drank. And he returned and went to bed. 

#### 1 Kings 19:7 And {returned the angel of the LORD} a second time, and touched him, and said to him, Rise up, eat! for {is great for you the journey}. 

#### 1 Kings 19:8 And he rose up, and ate and drank. And he went in the strength of that food forty days and forty nights unto mount Horeb. 

#### 1 Kings 19:9 And he entered there into the cave, and rested up there. And behold, a word of the LORD came to him. And he said, Why are you here, Elijah? 

#### 1 Kings 19:10 And Elijah said, Being zealous, I am zealous for the LORD almighty, for {abandoned you the sons of Israel}. Your altar they razed, and your prophets they killed by the broadsword, and {am left I alone}, and they seek my life to take it. 

#### 1 Kings 19:11 And he said, You shall go forth and stand before the LORD in the mountain! and behold, the LORD will go by. And {wind there was a great strong} parting the mountains, and breaking rocks before the LORD; {was not in the wind but the LORD}. And after the wind a rumbling; {was not in the rumbling but the LORD}. 

#### 1 Kings 19:12 And after the rumbling a fire; {was not in the fire but the LORD}. And after the fire a sound {breeze of a fine} -- there was the LORD. 

#### 1 Kings 19:13 And it came to pass as Elijah heard, that he covered over his face with his sheepskin, and he went forth and stood by the cave. And behold, before him was a voice, and he said, Why are you here, Elijah? 

#### 1 Kings 19:14 And Elijah said, Being zealous, I am zealous for the LORD God almighty, for {abandoned your covenant the sons of Israel}, your altars they razed, and your prophets they killed by the broadsword, and {am left I alone}, and they seek my life to take it. 

#### 1 Kings 19:15 And the LORD said to him, Go, return to your journey! And you shall come unto the way of the wilderness of Damascus, and you shall anoint Hazael as king over Syria. 

#### 1 Kings 19:16 And Jehu son of Nimshi you shall anoint as king over Israel. And Elisha son of Shaphat of Abel-meholah you shall anoint as prophet instead of you. 

#### 1 Kings 19:17 And it will be the one being delivered from the broadsword of Hazael, Jehu shall put to death. And the one being delivered from the broadsword of Jehu, Elisha shall put to death. 

#### 1 Kings 19:18 And I shall leave behind in Israel seven thousand men, all knees which do not bend the knee to Baal, and every mouth which does not do obeisance to him. 

#### 1 Kings 19:19 And he went forth from there, and he finds Elisha son of Shaphat, and he was plowing with oxen. Twelve teams were before him, and he was among the twelve. And {went forth unto Elisha Elijah}, and he tossed upon him his sheepskin. 

#### 1 Kings 19:20 And Elisha left the oxen, and he ran after Elijah, and said, I shall kiss my father and my mother, and I shall follow after you. And he said to him, Go, return! for I have done it to you. 

#### 1 Kings 19:21 And he returned from following after him. And he took the teams of oxen, and he sacrificed and cooked them by the equipment of the oxen, and he gave to the people and they ate. And he rose up, and went after Elijah, and ministered to him. 

#### 1 Kings 20:1 And the son of Hadad king of Syria gathered together all his force, and thirty-two kings with him, and horses and chariots. And they ascended, and laid siege against Samaria, and waged war against it. 

#### 1 Kings 20:2 And he sent messengers to Ahab king of Israel, into the city, and he said to him, Thus says the son of Hadad. 

#### 1 Kings 20:3 Your silver and your gold is mine; and your wives and your children, the best is mine. 

#### 1 Kings 20:4 And {answered the king of Israel} and said, As you have spoken, O my master, O king, {yours I am}, and all my things. 

#### 1 Kings 20:5 And {returned the messengers} and said, Thus says the son of Hadad, I have sent to you, saying, Your silver and your gold and your wives and your children you shall give to me, 

#### 1 Kings 20:6 for this hour tomorrow I will send my servants to you, and they will search your house, and the houses of your servants. And it will be that all the desires of their eyes, of what ever they should put upon with their hands, they shall take. 

#### 1 Kings 20:7 And {called the king of Israel} all the elders of the land, and he said, Know indeed and behold! that {evil this one seeks}, for he has sent to me for my wives, and for my children. And my silver and my gold I have not kept back from him. 

#### 1 Kings 20:8 And {said to him the elders and all the people}, You should not hearken, and you should not want. 

#### 1 Kings 20:9 And he said to the messengers of the son of Hadad, Say to your master! All as much as you sent to your servant at first, I will do; but this thing I shall not be able to do. And {departed the men} and returned to him the word. 

#### 1 Kings 20:10 And {sent to him the son of Hadad} saying, Thus may {do to me the gods}, and thus may they add, if {shall suffice the dust of Samaria} for the handful to all the people, to my footmen. 

#### 1 Kings 20:11 And {answered the king of Israel} and said, Let it be enough! Let not {boast the humpback} as the one standing straight! 

#### 1 Kings 20:12 And it came to pass when he answered to him this word, {was drinking he} and all the kings with him in tents. And he said to his servants, Build a siege mound! And they put a siege mound against the city. 

#### 1 Kings 20:13 And behold, {prophet one} came forward to Ahab king of Israel, and he said, Thus says the LORD, Have you seen all {multitude great this}? Behold, I give it today into your hands; and you shall know that I am the LORD. 

#### 1 Kings 20:14 And Ahab said, By whom? And he said, Thus says the LORD, By the young men of the rulers of the regions. And Ahab said, Who shall join together for the war? And he said, You. 

#### 1 Kings 20:15 And Ahab numbered the servants of the rulers of the regions, and they were two hundred thirty and two. And after these things he numbered the people, every son of power -- seven thousand. 

#### 1 Kings 20:16 And he went forth at midday. And the son of Hadad was drinking and being intoxicated in Succoth, he and the kings, thirty and two kings, the allies with him. 

#### 1 Kings 20:17 And came forth the young men, the rulers of the regions at first. And {sent the son of Hadad}, and they led up to him, saying, Men have come forth from out of Samaria. 

#### 1 Kings 20:18 And he said to them, If in peace they come forth, seize them alive! And if for war they came forth, seize them alive! 

#### 1 Kings 20:19 And {went forth from the city the young men} of the rulers of the regions, and the force after them. 

#### 1 Kings 20:20 And {struck each man} the one by him. And Syria fled, and {pursued them Israel}. And {escaped the son of Hadad king of Syria} upon a horse of a horseman. 

#### 1 Kings 20:21 And {came forth the king of Israel}, and he took the horses, and the chariots, and he struck {calamity a great} against Syria. 

#### 1 Kings 20:22 And {came forward the prophet} to the king of Israel, and he said, Strengthen yourself, and know, and see what you shall do! for returning during the year, the son of Hadad king of Syria will ascend against you. 

#### 1 Kings 20:23 And the servants of the king of Syria said to him, The God of mountains is the God of Israel, and not a God of valleys; on account of this they powered over us. But if we wage war against them according to the straight plains, assuredly we shall power over them. 

#### 1 Kings 20:24 And this thing you do! Let {depart the kings each} to his place, and establish {in place of them satraps}! 

#### 1 Kings 20:25 And you exchange according to the force falling from you -- even horse for horse, and chariots for chariots. And we will wage war against them in the straight plains, and we will power over them. And he hearkened to their voice, and did thus. 

#### 1 Kings 20:26 And it came to pass at the return of the year, that {mustered the son of Hadad} Syria, and he ascended into Aphek for war against Israel. 

#### 1 Kings 20:27 And the sons of Israel were mustered, and they came to meet them. And Israel camped right opposite them, as two flocks of goats. And Syria filled the land. 

#### 1 Kings 20:28 And came forward a man of God, and he said to the king of Israel, Thus says the LORD, Because Syria said, {is God of the mountains the LORD God of Israel}, and {is not God of the valleys he}, that I will give {force great this} into {hand your}, and you shall know that I am the LORD. 

#### 1 Kings 20:29 And these camped before those seven days. And it came to pass in the {day seventh}, that {led on the war}. And Israel struck Syria -- a hundred thousand footmen in one day. 

#### 1 Kings 20:30 And {fled the rest} unto Aphek, into the city. And {fell the wall} upon twenty and seven thousand men of the ones remaining. And the son of Hadad fled, and he entered into the house of the bedroom, into the inner chamber. 

#### 1 Kings 20:31 And {said his servants} to him, Indeed behold we heard that the kings of the house of Israel {kings of mercy are}. We should place indeed sackcloths upon our loins, and rough cords upon our heads, and we should go forth to the king of Israel; if by any means he shall bring forth alive our lives. 

#### 1 Kings 20:32 And they girded sackcloths upon their loins, and put rough cords upon their heads. And they said to the king of Israel, Your servant, the son of Hadad says, Let {live indeed my soul}! And he said, Does he still live? {brother he is my}. 

#### 1 Kings 20:33 And the men foretold and hastened and gathered up the word out of his mouth, and they said, Your brother the son of Hadad. And he said, Enter, and receive him! And {came forth to him the son of Hadad}; and they transported him upon the chariot to him. 

#### 1 Kings 20:34 And he said to him, The cities which {took father my} from your father, I give back to you. And {streets you shall establish} in Damascus for yourself, as {established my father} in Samaria. And I by covenant shall send you out. And he ordained with him a covenant, and sent him out. 

#### 1 Kings 20:35 And {man one} of the sons of the prophets said to his neighbor, by a word of the LORD, Strike me indeed! And {not would the man} strike him. 

#### 1 Kings 20:36 And he said to him, Because you hearkened not to the voice of the LORD, behold, as you run from me, {shall strike you a lion}. And he went forth from him, and {found him a lion}, and struck him. 

#### 1 Kings 20:37 And he finds {man another}, and he said, Strike indeed me! And {struck him the man}, and striking he broke him. 

#### 1 Kings 20:38 And {went the prophet} and stood to the king of Israel upon the way, and he bound {with a ligature his eyes}. 

#### 1 Kings 20:39 And it came to pass as the king came near, that he yelled out to the king. And he said, Your servant went forth with the military for war, and behold, a man brought to me another man, and he said to me, Guard this man! And if by rushing away he should rush away, then {will be required life your} for his life, or a talent of silver you establish for it. 

#### 1 Kings 20:40 And it came to pass as your servant looked round about here this way and here that way, that this man was not around. And {said to him the king of Israel}, Behold, you are the magistrate, {for me you murdered}. 

#### 1 Kings 20:41 And he hastened and removed the ligature from his eyes. And {recognized him the king of Israel}, that {was of the prophets this one}. 

#### 1 Kings 20:42 And he said to him, Thus says the LORD, Because you sent out {man a pernicious} to escape from out of your hand, even {will be required your life} for his life, and your people for his people. 

#### 1 Kings 20:43 And {went forth the king of Israel} being confounded and faint, and came unto Samaria. 

#### 1 Kings 21:1 And it came to pass after these words, that {vineyard one there was} to Naboth the Jezreelite, by the house of Ahab king of Samaria. 

#### 1 Kings 21:2 And Ahab spoke to Naboth, saying, Give to me your vineyard! and it will be to me for a garden of vegetables, for this is near my house! And I will give to you in place of it {vineyard another good} for it, but if not pleasing before you, I will give to you money in barter for {vineyard this your}. 

#### 1 Kings 21:3 And Naboth said to Ahab, May it not be to me from the LORD to give the inheritance of my fathers to you. 

#### 1 Kings 21:4 And Ahab went to his house being in a tumult and loosened over the word which {spoke to him Naboth the Jezreelite}, as he said, I will not give to you the inheritance of my fathers to you. And {became the spirit of Ahab} disturbed, and he went to sleep upon his bed, and covered up his face, and did not eat bread. 

#### 1 Kings 21:5 And {entered Jezebel his wife} to him, and she said to him, Why is your spirit disturbed, and {are not you} eating bread? 

#### 1 Kings 21:6 And he said to her, For I spoke to Naboth the Jezreelite, saying, Give to me your vineyard for money! but if you do not want, I will give to you a vineyard in place of it. And he said, I will not give to you the inheritance of my fathers. 

#### 1 Kings 21:7 And {said to him Jezebel his wife}, Do you now so act as king over Israel? Rise up, and eat bread, and {yourself be}! and I will give to you the vineyard of Naboth the Jezreelite. 

#### 1 Kings 21:8 And she wrote upon a scroll the name of Ahab, and set seal with his seal, and sent the scroll to the elders and to the free men of the ones dwelling with Naboth. 

#### 1 Kings 21:9 And she wrote in the scroll, saying, Fast a fast, and set Naboth at the head place of the people! 

#### 1 Kings 21:10 And set two men, sons of lawbreakers, right opposite him! And let them bear witness against him! saying, You raved against God and king. And let them lead him out and stone him, and let him die! 

#### 1 Kings 21:11 And they did (the men of his city, the elders, and the free men dwelling in his city) as {sent to them Jezebel}, and as was written in the scrolls which she sent to them. 

#### 1 Kings 21:12 And they called a fast, and they sat Naboth at the head of the people. 

#### 1 Kings 21:13 And {entered two men}, sons of lawbreakers, and they sat right opposite him, and bore witness against him, saying, He raved against God and king. And they led him outside the city, and they stoned him with stones, and he died. 

#### 1 Kings 21:14 And they sent to Jezebel, saying, Naboth has been stoned and died. 

#### 1 Kings 21:15 And it came to pass, as Jezebel heard the ones saying, Naboth has been stoned, and has died; Jezebel said to Ahab, Rise up, inherit the vineyard of Naboth the Jezreelite! for he did not give it to you for money, for {is not Naboth} living, but has died. 

#### 1 Kings 21:16 And it came to pass as Ahab heard that Naboth has died, Ahab rose and went down into the vineyard of Naboth the Jezreelite to inherit it. 

#### 1 Kings 21:17 And the LORD said to Elijah the Tishbite, saying, 

#### 1 Kings 21:18 Rise up and go down for a meeting with Ahab king of Israel, the one in Samaria! Behold, he is in the vineyard of Naboth, for he went down there to inherit it. 

#### 1 Kings 21:19 And you shall speak to him, saying, Thus says the LORD, You murdered and inherited. Therefore thus says the LORD, In the place where {licked the dogs} the blood of Naboth, there {shall lick the dogs} your blood. 

#### 1 Kings 21:20 And Ahab said to Elijah, Have you found me, O my enemy? And he said, I have found you, for you sell yourself in folly to act wickedly before the LORD, to provoke him to anger. 

#### 1 Kings 21:21 Thus says the LORD, Behold, I bring upon you evils. And I shall burn away after you, and I shall utterly destroy of Ahab the one urinating against the wall, and the one being constrained, and the one being left in Israel. 

#### 1 Kings 21:22 And I will appoint your house as the house of Jeroboam son of Nebat, and as the house of Baasha son of Ahijah, on account of the provocations which you provoke to anger, and led Israel into sin. 

#### 1 Kings 21:23 And to Jezebel the LORD spoke, saying, The dogs shall eat her in the area around the wall of Jezreel. 

#### 1 Kings 21:24 The one having died of Ahab in the city, {will eat the dogs}; and the one having died of his in the plain, {will eat the birds of the heaven}. 

#### 1 Kings 21:25 Furthermore {not one there was} as Ahab, who sold himself to do the wicked thing before the LORD, as {altered him Jezebel his wife}. 

#### 1 Kings 21:26 And he acted {abhorrent exceedingly} to go after the abominations, according to all as many things which {made the Amorite}, whom the LORD utterly destroyed from the face of the sons of Israel. 

#### 1 Kings 21:27 And it came to pass as Ahab heard these words, he tore his inner-garment, and he wore sackcloth upon his body, and he fasted, and he laid in sackcloth, and he went having downcast eyes. 

#### 1 Kings 21:28 And came to pass the word of the LORD to Elijah the Tishbite, and he said, 

#### 1 Kings 21:29 Have you seen that Ahab was vexed in front of me? Because he was vexed in front of me, I shall not bring the evil in his days, but only in the days of his son will I bring the evil upon his house. 

#### 1 Kings 22:1 And he stayed in place three years, and there was no war between Syria and between Israel. 

#### 1 Kings 22:2 And it came to pass in the {year third}, that {went down Jehoshaphat king of Judah} to the king of Israel. 

#### 1 Kings 22:3 And {said the king of Israel} to his servants, Do you know that {is ours Ramoth Gilead}, and we keep silent to not take it from out of the hand of the king of Syria? 

#### 1 Kings 22:4 And {said the king of Israel} to Jehoshaphat, Shall you not ascend with me unto Ramoth Gilead for war? 

#### 1 Kings 22:5 And Jehoshaphat said, As you, thus also I. As your people, thus also my people. As your horses, so also my horses. And {said Jehoshaphat king of Judah} to the king of Israel, Ask indeed today of the LORD. 

#### 1 Kings 22:6 And {gathered together the king of Israel} all the prophets, about four hundred men. And said to them, Shall I go unto Ramoth Gilead for war, or wait? And they said, Ascend! for by giving, the LORD shall give into the hands of the king. 

#### 1 Kings 22:7 And Jehoshaphat said to the king of Israel, Is there not here a prophet of the LORD, and we shall ask the LORD through him? 

#### 1 Kings 22:8 And {said the king of Israel} to Jehoshaphat, Yet there is one man for the asking the LORD through him, and I detest him, for he does not speak concerning me for good things, but only bad -- Micaiah son of Imlah. And Jehoshaphat said, Let not {speak the king} so. 

#### 1 Kings 22:9 And {called the king of Israel eunuch one}, and he said, Quickly bring Micaiah son of Imlah. 

#### 1 Kings 22:10 And the king of Israel and Jehoshaphat king of Judah sat down each upon his throne, armed, at the threshing-floor gate of Samaria. And all the prophets prophesied before them. 

#### 1 Kings 22:11 And {made for himself Zedekiah son of Chenaanah} horns of iron. And he said, Thus says the LORD, By these you shall gore the Syrian until whenever you finish them off entirely. 

#### 1 Kings 22:12 And all the prophets prophesied thus, saying, Ascend unto Ramoth Gilead! and your way shall prosper, and the LORD shall put into your hands the king of Syria. 

#### 1 Kings 22:13 And the messenger, the one going to call Micaiah spoke to him, saying, Behold, indeed all the prophets speak {mouth by one} good things concerning the king. Let it be indeed that you be with words according to the words of one of these, and speak good! 

#### 1 Kings 22:14 And Micaiah said, As the LORD lives, that what ever the LORD should say to me, these things I shall speak. 

#### 1 Kings 22:15 And he came to the king. And {said to him the king}, Micaiah, Shall I ascend to Ramoth Gilead for war, or wait? And he said to him, Ascend! and the LORD shall prosper the way in the hand of the king. 

#### 1 Kings 22:16 And {said to him the king}, How often shall I adjure you that you should speak to me the truth in the name of the LORD? 

#### 1 Kings 22:17 And Micaiah said thus, I see all Israel being scattered in the mountains as sheep in which there is no shepherd. And the LORD said, There is no lord to these, let {return each} to his house in peace! 

#### 1 Kings 22:18 And {said the king of Israel} to Jehoshaphat king of Judah, Did I not say to you that {would not prophesy this one unto me good things}, but only bad? 

#### 1 Kings 22:19 And Micaiah said, On account of this hear the word of the LORD! I saw the LORD God of Israel sitting upon his throne, and all the military of the heaven standing about him at his right, and at his left. 

#### 1 Kings 22:20 And the LORD said, Who shall deceive Ahab king of Israel, that he shall ascend in Ramoth Gilead and shall fall there? And this one said thus, and this other one thus. 

#### 1 Kings 22:21 And {came forth a spirit}, and stood before the LORD. And he said, I will deceive him. 

#### 1 Kings 22:22 And {said to him the LORD}, In what way? And he said, I shall go forth, and I shall be {spirit a lying} in the mouth of all his prophets. And he said, You shall deceive, and indeed you will be able. Go forth, and do so! 

#### 1 Kings 22:23 And now, behold, the LORD has put {spirit a lying} in the mouth of all {your prophets these}, and the LORD spoke against you bad things. 

#### 1 Kings 22:24 And {came forward Zedekiah son of Chenaanah}, and he struck Micaiah upon the jaw, and he said, What kind of spirit of the LORD departed from me to speak with you? 

#### 1 Kings 22:25 And Micaiah said, Behold, you shall see in that day, whenever you shall enter an inner chamber of the storeroom to hide. 

#### 1 Kings 22:26 And {said the king of Israel}, Take Micaiah, and return him to Amon the ruler of the city, and to Joash son of the king! 

#### 1 Kings 22:27 And say, Thus says the king, Put him in prison, and let him eat bread of affliction and water of affliction until my return in peace! 

#### 1 Kings 22:28 And Micaiah said, If in returning, you should return in peace, {did not speak the LORD} by me. And he said, Let {hearken all the people}! 

#### 1 Kings 22:29 And {ascended up the king of Israel}, and Jehoshaphat king of Judah with him unto Ramoth Gilead. 

#### 1 Kings 22:30 And {said the king of Israel} to Jehoshaphat king of Judah, I shall cover up myself, and enter into the battle; and you put on my clothes! And {covered himself up the king of Israel}, and he entered into the battle. 

#### 1 Kings 22:31 And the king of Syria gave charge to the rulers of his chariots -- thirty and two, saying, Do not do battle against the small or great, but the king of Israel alone. 

#### 1 Kings 22:32 And it came to pass as {saw the ones in charge of the chariots} Jehoshaphat king of Judah, that they said, It appears that {is the king of Israel this one}. And they encircled him to do battle. And Jehoshaphat shouted aloud. 

#### 1 Kings 22:33 And it happened as {saw the rulers of the chariots} that {is not the king of Israel this}, that they turned away from him. 

#### 1 Kings 22:34 And {stretched tight one the bow merely}, and it struck the king of Israel between the lungs and between the chest plate. And he said to his charioteer, Turn your hand and lead me out of the battle! for I have been wounded. 

#### 1 Kings 22:35 And {turned the war} in that day. And the king was set upon the chariot right opposite Syria, from morning until evening. And {poured out the blood} from the wound into the cavity of the chariot. 

#### 1 Kings 22:36 And {stood the herald of the army} in the camp until the going down of the sun, saying, Each to his own city, and each to his own land, 

#### 1 Kings 22:37 for {has died the king}. And they went unto Samaria, and they entombed the king in Samaria. 

#### 1 Kings 22:38 And they washed the blood from the chariot at the fountain of Samaria. And {licked up the dogs} the blood, and the harlots bathed in the blood, according to the saying of the LORD which he spoke. 

#### 1 Kings 22:39 And the rest of the words of Ahab, and all which he did, and the house of ivory which he built, and all the cities which he made, {not behold these have} been written in the scroll of the words of the days of the kings of Israel? 

#### 1 Kings 22:40 And Ahab slept with his fathers; and {reigned Ahaziah his son} instead of him. 

#### 1 Kings 22:41 And Jehoshaphat son of Asa reigned over Judah in {year the fourth} of Ahab king of Israel. 

#### 1 Kings 22:42 And Jehoshaphat was thirty and five years old in his taking reign; and {twenty and five years he reigned} in Jerusalem. And the name of his mother was Azubah daughter of Shilhi. 

#### 1 Kings 22:43 And he went in all the way of Asa his father. He turned not aside from it, to do the upright in the eyes of the LORD. Except the high places he did not lift away; for the people sacrificed and burnt incense on the high places. 

#### 1 Kings 22:44 And Jehoshaphat made peace with the king of Israel. 

#### 1 Kings 22:45 And the rest of the words of Jehoshaphat, and his dominions which he had, {not behold these are} written in the scroll of the words of the days of the kings of Judah? 

#### 1 Kings 22:46 And the rest of the ones being initiated of the things being forsaken in the days of Asa his father he removed from the land. 

#### 1 Kings 22:47 And a king was not established in Edom. 

#### 1 Kings 22:48 And Jehoshaphat prepared ships of Tarshish to go unto Ophir because of gold. And they did not go; for {were destroyed the ships} in Ezion Geber. 

#### 1 Kings 22:49 Then {said Ahaziah son of Ahab} to Jehoshaphat, Let {go my servants} with your servants. And {did not want it Jehoshaphat}. 

#### 1 Kings 22:50 And Jehoshaphat slept with his fathers, and they entombed him by his fathers in the city of David his fore father. And {reigned Jehoram his son} instead of him. 

#### 1 Kings 22:51 And Ahaziah son of Ahab reigned over Israel in Samaria. In {year the seventeenth} of Jehoshaphat king of Judah, Ahaziah son of Ahab reigned over Israel in Samaria two years. 

#### 1 Kings 22:52 And he acted wickedly before the LORD, and went in the way of Ahab his father, and in the way of Jezebel his mother, and in the sins of the house of Jeroboam son of Nebat, who led Israel into sin. 

#### 1 Kings 22:53 And he served to the Baalim, and did obeisance to them, and provoked to anger the LORD God of Israel, according to all what {did his father}.