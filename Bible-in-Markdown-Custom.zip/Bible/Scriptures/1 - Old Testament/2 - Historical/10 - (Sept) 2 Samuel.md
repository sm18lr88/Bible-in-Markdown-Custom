#### 2 Samuel 1:1 And it came to pass after the dying of Saul, that David returned from striking Amalek. And David stayed in Ziklag {days two}. 

#### 2 Samuel 1:2 And it came to pass in the {day third}, that behold, a man came from out of the camp of the people of Saul, and his clothes were torn up, and earth was upon his head. And it happened in his entering to David, that he fell upon the ground and did obeisance to him. 

#### 2 Samuel 1:3 And {said to him David}, From what place do you come? And he said to him, From out of the camp of Israel I have come through safe. 

#### 2 Samuel 1:4 And {said to him David}, What word is this? Report to me! And he said, {have fled The people} from the battle, and {have fallen many} of the people, and they died; and Saul and Jonathan his son died. 

#### 2 Samuel 1:5 And David said to the servant-lad, In the reporting it, how do you know that {have died Saul and Jonathan his son}? 

#### 2 Samuel 1:6 And {said the servant-lad} reporting to him, By chance I fell among the mountain of Giboa; and behold, Saul was stayed upon his spear; and behold, the chariots and the commanders of the cavalry joined together against him. 

#### 2 Samuel 1:7 And he looked behind him, and he beheld me, and he called me. And I said, Behold, it is I. 

#### 2 Samuel 1:8 And he said to me, Who are you? And I said, {an Amalekite I am}. 

#### 2 Samuel 1:9 And he said to me, Stand indeed above me, and put me to death! for {constrained me darkness an awful}, for {is yet my life} in me. 

#### 2 Samuel 1:10 And I stood over him, and put him to death, for I knew that he would not live after he fell. And I took the crown, the one upon his head, and the armlet, the one upon his arm, and I brought them to my master here. 

#### 2 Samuel 1:11 And David took hold of his clothes, and tore them; and all the men, the ones with him. 

#### 2 Samuel 1:12 And they beat their chests and wept, and fasted until evening over Saul, and over Jonathan his son, and over the people of Judah, and over the house of Israel, because they were struck by the broadsword. 

#### 2 Samuel 1:13 And David said to the servant-lad, the one reporting to him, From what place are you? And he said, {the son man sojourner of an Amalekite I am}. 

#### 2 Samuel 1:14 And {said to him David}, How is it you do not fear to bear your hand to utterly destroy the anointed one of the LORD? 

#### 2 Samuel 1:15 And David called one of his servant-lads, and he said, Coming forward, you meet him! And he struck him, and he died. 

#### 2 Samuel 1:16 And {said to him David}, Your blood be upon your head, for your mouth answered against you, saying, I put to death the anointed one of the LORD. 

#### 2 Samuel 1:17 And David lamented this lamentation over Saul, and over Jonathan his son. 

#### 2 Samuel 1:18 And he spoke to teach the sons of Judah. Behold, it is written upon the scroll of the upright. 

#### 2 Samuel 1:19 And he said, Set up a stone monument, O Israel, for the ones having died upon your heights -- being slain! How {are fallen the mighty ones}. 

#### 2 Samuel 1:20 Announce it not in Gath, and announce it not as good news in the streets of Ashkelon! lest at any time {should be glad the daughters of the Philistines}, lest at any time {should exult the daughters of the uncircumcised}. 

#### 2 Samuel 1:21 O mountains in Gilboa, may there not fall upon you neither dew nor rain; and O fields of first-fruits, for there {was loathed the shield of the mighty ones}, the shield of Saul was not anointed with oil. 

#### 2 Samuel 1:22 From the blood of the slain, and from the fat of the mighty ones, the bow of Jonathan did not return empty to the rear; and the broadsword of Saul did not return empty. 

#### 2 Samuel 1:23 Saul and Jonathan, the ones being loved, and beautiful ones; not parted in their life, and in their death they were not parted. {above eagles Nimble}, and {above lions strong}. 

#### 2 Samuel 1:24 Daughters of Israel, weep over Saul! the one dressing you with scarlet apparel, with your ornament; the one bearing {ornament a golden} for your clothes. 

#### 2 Samuel 1:25 How {fell the mighty ones} in the midst of battle, O Jonathan, upon your heights you were slain. 

#### 2 Samuel 1:26 I ache over you, Jonathan, O my brother. You were beautiful to me, exceedingly; {caused wonder your affection to me} -- above the affection of women. 

#### 2 Samuel 1:27 O how {fell the mighty ones}, and {perished the weapons of warfare}. 

#### 2 Samuel 2:1 And it came to pass after these things, and David asked by the LORD, saying, Shall I ascend unto one of the cities of Judah? And the LORD said to him, Ascend! And David said, Where should I ascend? And he said, Unto Hebron. 

#### 2 Samuel 2:2 And {ascended there David}, and both his wives -- Ahinoam the Jezreelitess, and Abigail the wife of Nabal the Carmelite. 

#### 2 Samuel 2:3 And the men were with him, each one and his house. And they dwelt among the cities of Hebron. 

#### 2 Samuel 2:4 And {come the men of Judea} and anoint David there to reign over the house of Judah. And they reported to David, saying, The men of Jabish of the Gileadites entombed Saul. 

#### 2 Samuel 2:5 And David sent messengers to the leaders of Jabish of the Gileadites, And he said to them, Being blessed are you to the LORD, that you performed this mercy for your master, for Saul, and you entombed him. 

#### 2 Samuel 2:6 And now, may the LORD perform {with you mercy and truth}; and indeed I will do with you this good that you did in this matter. 

#### 2 Samuel 2:7 And now strengthen your hands and become as {sons mighty}! for {has died Saul your master}, and indeed {has anointed me the house of Judah} over them for king. 

#### 2 Samuel 2:8 And Abner son of Ner, commander-in-chief of Saul, took Ishbosheth son of Saul, and brought him from out of the camp into Mahanaim, 

#### 2 Samuel 2:9 and gave him to reign over Gilead, and over the Ashurites, and over Jezreel, and over Ephraim, and over Benjamin, and over all Israel. 

#### 2 Samuel 2:10 {was forty years old Ishbosheth son of Saul} when he reigned over Israel; and {two years he reigned}; except for the house of Judah, the ones which were following after David. 

#### 2 Samuel 2:11 And became the number of the days which David reigned in Hebron over the house of Judah -- seven years and {months six}. 

#### 2 Samuel 2:12 And {came forth Abner son of Ner}, and the servants of Ishbosheth son of Saul, out of Mahanaim unto Gibeon. 

#### 2 Samuel 2:13 And Joab son of Zeruiah, and the servants of David, came forth out of Hebron, and met them at the fountain of Gibeon. And these sat here on this side, and these others at the fountain here on that side. 

#### 2 Samuel 2:14 And Abner said to Joab, Raise up indeed the servant-lads and let them play before us! And Joab said, Let them arise! 

#### 2 Samuel 2:15 And they rose up and went by in number -- twelve of the servants of Benjamin of Ishbosheth son of Saul, and twelve of the servants of David. 

#### 2 Samuel 2:16 And they {held each} by their hand the head of his neighbor; and his knife was thrust into the side of his neighbor; and they fell down together. And they called that place, Portion of the Plotters, which is in Gibeon. 

#### 2 Samuel 2:17 And {was the battle} hard so as to an exceeding degree in that day. And {failed Abner and the men of Israel} before the servants of David. 

#### 2 Samuel 2:18 And there were there three sons of Zeruiah -- Joab and Abishai and Asahel. And Asahel was light of his feet, as one doe of the ones in the field. 

#### 2 Samuel 2:19 And Asahel pursued after Abner, and he did not turn aside to go to the right nor to the left after Abner. 

#### 2 Samuel 2:20 And Abner looked to his rear, and said, Are you Asahel himself? And he said, I am. 

#### 2 Samuel 2:21 And {said to him Abner}, Turn aside to the right or to the left, and constrain to yourself one of the servant-lads, and take to yourself his full armor! And {did not want Asahel} to turn aside from being behind him. 

#### 2 Samuel 2:22 And {added yet Abner}, saying to Asahel, Leave from me! that I should not strike you unto the ground. For how shall I lift my face to Joab your brother? 

#### 2 Samuel 2:23 And he was not willing to leave. And {struck him Abner} with the rear of the spear upon his flank. And {went completely through the spear} out behind him. And he falls there and dies underneath him. And it came to pass every one coming unto the place where {fell there Asahel} and died, even stood still. 

#### 2 Samuel 2:24 And {pursued Joab and Abishai} after Abner, and the sun went down. And they entered unto the hill of Ammah, according to the face of Giah, {way the wilderness} of Gibeon. 

#### 2 Samuel 2:25 And {gathered together the sons of Benjamin}, the ones following after Abner, and they came to meet as one, and they stood upon the head {hill of one}. 

#### 2 Samuel 2:26 And Abner called Joab, and he said, Shall {in victory devour the broadsword}, or do you not know that it will be bitter at the last? And for how long {in no way shall you} speak to the people to return from following after their brethren? 

#### 2 Samuel 2:27 And Joab said, As the LORD lives, that if you had not spoken, because then from the morning {ascended even the people} each after his brother. 

#### 2 Samuel 2:28 And Joab trumped the trumpet, and {left all the people}, and did not pursue any longer after Israel, and they did not proceed any longer to wage war. 

#### 2 Samuel 2:29 And Abner and his men went forth at the descent of the sun, and went all that night, and passed over the Jordan, and they went the entire extent, and they came unto Camp. 

#### 2 Samuel 2:30 And Joab returned from following behind Abner, And he gathered together all the people. And they numbered the servants of David, the ones having fallen -- nineteen men and Asahel. 

#### 2 Samuel 2:31 And the servants of David struck of the sons of Benjamin, of the men of Abner -- three hundred and sixty men. 

#### 2 Samuel 2:32 And they lifted up Asahel, and they entombed him in the burying-place of his father in Beth-lehem. And {went the entire night Joab and his men}, and light shined through to them in Hebron. 

#### 2 Samuel 3:1 And there was war for a long time between the house of Saul, and between the house of David. And the house of David went and strengthened. And the house of Saul went and weakened. 

#### 2 Samuel 3:2 And were born to David in Hebron {sons six}, and {was his first-born} was Amnon by Ahinoam the Jezreelitess; 

#### 2 Samuel 3:3 and his second was Chileab of Abigail the Carmelitess; and the third was Absalom son of Maacah daughter of Talmai king of Geshur; 

#### 2 Samuel 3:4 and the fourth was Adonijah son of Haggith; and the fifth was Shephatiah by Abital; 

#### 2 Samuel 3:5 and the sixth was Ithream of Eglah wife of David. These were born to David in Hebron. 

#### 2 Samuel 3:6 And it came to pass in the being the war between the house of Saul, and between the house of David, that Abner was holding rule over the house of Saul. 

#### 2 Samuel 3:7 And to Saul was a concubine, and the name to her was Rizpah, daughter of Aiah. And {said Ishbosheth son of Saul} to Abner, Why is it that you enter to the concubine of my father? 

#### 2 Samuel 3:8 And {was enraged exceedingly Abner} on account of this word by Ishbosheth. And Abner said to him, Am {head a dog's I} that I executed today mercy with the house of Saul your father, and with his brethren, and with his acquaintances, and did not desert to the house of David, that you seek anxiously about me concerning injustice to a woman today? 

#### 2 Samuel 3:9 Thus may God do to Abner, and thus may he add to him that as the LORD swore by an oath to David, that so I should do the same to him in this day, 

#### 2 Samuel 3:10 to remove the kingdom from the house of Saul, and to raise up the throne of David over Israel, and over Judah, from Dan until Beer-sheba. 

#### 2 Samuel 3:11 And {was not able still Ishbosheth} to answer Abner's utterance, because of fearing him. 

#### 2 Samuel 3:12 And Abner sent messengers to David in Hebron, saying, {ordain a covenant You} with me! And behold, My hand is with you to return to you all Israel. 

#### 2 Samuel 3:13 And David said, Well, I shall ordain with you a covenant, except {word one} I ask from you, saying, You shall not see my face, if you do not lead Michal daughter of Saul, in your coming to behold my face. 

#### 2 Samuel 3:14 And David sent {to Ishbosheth son of Saul messengers}, saying, Give back to me my wife Michal which I took for a hundred foreskins of Philistines. 

#### 2 Samuel 3:15 And Ishbosheth sent, and took her from her husband, from Phaltiel son of Laish. 

#### 2 Samuel 3:16 And {went husband her} with her, going and weeping after her unto Behurim. And {said to him Abner}, Go return! And he returned. 

#### 2 Samuel 3:17 And the word of Abner came to the elders of Israel, saying, Yesterday and the third day before you sought David to reign over you. 

#### 2 Samuel 3:18 And now act! for the LORD spoke concerning David, saying, By the hand of my servant David I will deliver my people Israel from the hand of the Philistines, and from the hand of all his enemies. 

#### 2 Samuel 3:19 And Abner spoke in the ears of Benjamin. And Abner went to speak into the ears of David in Hebron, all as much as it pleased in the eyes of Israel, and in the eyes of all the house of Benjamin. 

#### 2 Samuel 3:20 And Abner came to David in Hebron, and with him twenty men. And David made {to Abner and the men with him a banquet}. 

#### 2 Samuel 3:21 And Abner said to David, I will arise indeed and go, and gather together to my master the king all Israel; and I will ordain with you a covenant, and you shall reign over all whom {desires your soul}. And David sent away Abner, and he went in peace. 

#### 2 Samuel 3:22 And behold, the servants of David and Joab came from the expedition, and {spoils many they brought} with themselves. And Abner was not with David in Hebron, for he had sent him away, and he went in peace. 

#### 2 Samuel 3:23 And Joab, and all the military, the one with him, came. And they reported to Joab, saying, {comes Abner son of Ner} to David, and he has sent him, and he went forth in peace. 

#### 2 Samuel 3:24 And Joab entered to the king, and he said to him, What is this you did? Behold, Abner came to you, and why have you sent him away, and he has gone forth in peace? 

#### 2 Samuel 3:25 Or do you not know the evil of Abner son of Ner, that {to deceive you he came}, and to know your entering and your exiting, and to know all together as much as you do? 

#### 2 Samuel 3:26 And Joab went from David, and sent messengers after Abner, and they returned him from the well of Sirah; and David did not know. 

#### 2 Samuel 3:27 And Abner returned to Hebron, and {turned him Joab} from the side of the gate to speak to him laying in wait. And he struck him there in the flank, and he died for the blood {Asahel of his brother}. 

#### 2 Samuel 3:28 And David heard about these things, and he said, {am innocent I} and my kingdom from the LORD and unto the eon of the blood of Abner son of Ner. 

#### 2 Samuel 3:29 Let it arrive upon the head of Joab, and upon all the house of his father! and may there not cease to be one from the house of Joab having gonorrhea, and leprous, and holding a stave, and falling by the broadsword, and lacking bread loaves. 

#### 2 Samuel 3:30 For Joab and Abishai his brother observed Abner, because he killed Asahel their brother in Gibeon in the battle. 

#### 2 Samuel 3:31 And David said to Joab, and to all the people with him, Tear your clothes, and gird on sackcloths, and lament before Abner! And king David went behind the bier. 

#### 2 Samuel 3:32 And they entombed Abner in Hebron, and {lifted the king} his voice and wept over the tomb of Abner, and {wept all the people}. 

#### 2 Samuel 3:33 And {lamented the king} over Abner, and said, Shall {according to the death of Nabal die Abner}, no. 

#### 2 Samuel 3:34 Your hands were not tied, nor your feet not in shackles; you did not lead as Nabal; {in the presence of a son of injustice you fell}. And {were brought together all the people} to weep for him. 

#### 2 Samuel 3:35 And {came all the people} to cause {to eat at the wake David bread loaves} still being day. And David swore by an oath, saying, Thus may {do to me God}, and thus may he add yet more, that until {should go down the sun}, in no way shall I taste bread nor any thing. 

#### 2 Samuel 3:36 And all the people knew. And it was pleasing before them, all as much as {did the king} in the presence of all the people. 

#### 2 Samuel 3:37 And {knew all the people}, and all Israel in that day, that {happened not by the king the putting to death of Abner son of Ner}. 

#### 2 Samuel 3:38 And {said the king} to his servants, Do you not know that a leader, and a great one has fallen in this day in Israel? 

#### 2 Samuel 3:39 And that I am as a relative today, and one being placed for king. But these men, the sons of Zeruiah {hard for me are}. The LORD should recompense to the one doing the wicked things according to his evil. 

#### 2 Samuel 4:1 And {heard Ishbosheth son of Saul} that Abner has died in Hebron, and {were faint his hands}, and all the men of Israel were disturbed. 

#### 2 Samuel 4:2 And there were two men being leaders of the confederation of Ishbosheth son of Saul -- the name to the one was Baanah, and the name of the second, Rechab, the sons of Rimmon the Beerothite from out of the sons of Benjamin; for also Beeroth was considered among the sons of Benjamin. 

#### 2 Samuel 4:3 And {ran away the Beerothites} unto Gittaim, and they were there sojourning until this day. 

#### 2 Samuel 4:4 And to Jonathan, son of Saul, there was a son stricken in the feet, a son {years old five}; and this one was in the way in the coming of the message of Saul and Jonathan his son from out of Jezreel; and {lifted him his wet-nurse} and fled. And it happened in her hastening and withdrawing he fell and became lame. And the name to him was Mephibosheth. 

#### 2 Samuel 4:5 And {went out the sons of Rimmon the Beerothite}, Rechab and Baana; and they entered in the sweltering heat of the day into the house of Ishbosheth, and he was asleep in the bed in the midday. 

#### 2 Samuel 4:6 And behold, the doorkeeper of the house was cleansing wheat, and he slumbered and slept. And Rechab and Baanah his brother escaped notice. 

#### 2 Samuel 4:7 And they entered into the house. And Ishbosheth was sleeping upon his bed in his bedroom. And they strike him, and put him to death, and remove his head. And they took his head, and went forth in the way, the one according to the west, the entire night. 

#### 2 Samuel 4:8 And they brought the head of Ishbosheth to David in Hebron. And they said to the king, Behold, the head of Ishbosheth son of Saul your enemy, who sought your life; and the LORD gave to our master the king punishment of his enemies, as this day, of Saul your enemy, and of his seed. 

#### 2 Samuel 4:9 And David responded to Rechab and to Baanah his brother, sons of Rimmon the Beerothite, and said to them, As the LORD lives, who ransomed my soul from all affliction; 

#### 2 Samuel 4:10 that the one reporting to me that Saul has died, and he was as one announcing good news before me, but I constrained him, and killed him in Ziklag, in which he must have thought to be giving me good news. 

#### 2 Samuel 4:11 And now, {men wicked} killed {man a just} in his house upon his bed. And now, I will require for his blood of your hand, and I will utterly destroy you from the earth. 

#### 2 Samuel 4:12 And David gave charge to his servants, and they killed them, and lopped off their hands and their feet, and they hung them upon the fountain in Hebron. And the head of Ishbosheth they entombed in the tomb of Abner son of Ner in Hebron. 

#### 2 Samuel 5:1 And {came all the tribes of Israel} to David in Hebron. And they say to him, Behold, we are of your bones and of your flesh. 

#### 2 Samuel 5:2 And before yesterday and the third day before, Saul was king over us, you were the one leading out and bringing in Israel. And {said the LORD} to you, You tend my people Israel! and you will be for leader over my people Israel. 

#### 2 Samuel 5:3 And {come all the elders of Israel} to the king in Hebron. And {ordained with them king David} a covenant in Hebron, in the presence of the LORD. And they anoint David for king over all Israel. 

#### 2 Samuel 5:4 {was a son thirty years David} in his reigning, and forty years he reigned. 

#### 2 Samuel 5:5 Seven years and {months six} he reigned in Hebron over Judah. And thirty three years he reigned over all Israel and Judah in Jerusalem. 

#### 2 Samuel 5:6 And {went forth the king}, and all his men unto Jerusalem, to the Jebusite dwelling in the land. And it was said to David, You shall not enter here. For {opposed the blind and the lame}, saying, {shall not enter David} here. 

#### 2 Samuel 5:7 And David overtook the citadel of Zion, this is the city of David. 

#### 2 Samuel 5:8 And David said in that day, Every one striking a Jebusite, let him touch by the dagger both the lame, and the blind, and the ones detesting the soul of David! On account of this they shall say, Blind and lame shall not enter into the house of the LORD. 

#### 2 Samuel 5:9 And David stayed in the citadel, and this was called the city of David. And David built the city round about from the Akra, and his house. 

#### 2 Samuel 5:10 And David went along, going and being magnified, and the LORD almighty was with him. 

#### 2 Samuel 5:11 And {sent Hiram king of Tyre} messengers to David, and wood of cedars, and fabricators of woods, and fabricators of stones, and they built a house for David. 

#### 2 Samuel 5:12 And David knew that {prepared him the LORD} for king over Israel, and that {was lifted up his kingdom} on account of his people Israel. 

#### 2 Samuel 5:13 And David took again wives and concubines from Jerusalem, after his coming from Hebron. And {were born to David still more sons and daughters}. 

#### 2 Samuel 5:14 And these are the names of the ones being born of them in Jerusalem -- Shammuah, and Shobab, and Nathan, and Solomon, 

#### 2 Samuel 5:15 and Ibhar, and Elishua, and Napheg, and Japhia, 

#### 2 Samuel 5:16 and Elishama, and Eliada, and Eliphalet, and Elishua. 

#### 2 Samuel 5:17 And {heard the Philistines} that David was anointed king over Israel. And {ascended all the Philistines} to seek David. And David heard, and went down unto the citadel. 

#### 2 Samuel 5:18 And the Philistines came and met in battle in the valley of the Titans. 

#### 2 Samuel 5:19 And David asked of the LORD, saying, Shall I ascend against the Philistines? and will you deliver them into my hands? And the LORD said to David, Ascend! for in delivering I will deliver the Philistines into your hands. 

#### 2 Samuel 5:20 And David came from the upper breaches, and he smote them there. And David said, The LORD cut through my enemies before me, as he cuts through waters. On account of this {is called the name of that place} Upper Breaches. 

#### 2 Samuel 5:21 And they left behind there their gods, and {took them David} and the men with him. 

#### 2 Samuel 5:22 And {proceeded yet again the Philistines} to ascend, and they met in battle in the valley of the Titans. 

#### 2 Samuel 5:23 And David asked through the LORD. And the LORD said, Do not ascend to meet them! turn from them! and you shall be at hand for them neighboring the Place of Weeping. 

#### 2 Samuel 5:24 And it will be in your hearing the sound of the rumbling from out of the Grove of the Weeping, then you shall go down to them; for then the LORD shall go forth in front of you to strike in the battle of the Philistines. 

#### 2 Samuel 5:25 And David did thus as {gave charge to him the LORD}. And he struck the Philistines from Gibeon unto of Gezer. 

#### 2 Samuel 6:1 And {gathered again David} every young man of Israel -- thirty thousand. 

#### 2 Samuel 6:2 And {rose up and went David}, and all the people with him, and some of the rulers of Judah, to lead from there the ark of God, upon which {is called upon the name of the LORD of the forces}, the one sitting upon the cherubim upon it. 

#### 2 Samuel 6:3 And they set the ark of God upon {wagon a new}, and lifted it from out of the house of Abinadab, the one on the hill. And Uzzah and his brethren, the sons of Abinadab, led the wagon with the ark. 

#### 2 Samuel 6:4 And his brethren went in front of the ark. 

#### 2 Samuel 6:5 And David and all the sons of Israel played before the LORD with instruments in accord, and with odes, and with lutes, and with stringed instruments, and with tambourines, and with cymbals, and with pipes. 

#### 2 Samuel 6:6 And they come unto the threshing-floor of Nachon, and Uzzah stretched out his hand to the ark of God to hold it. And he held it, for {distracted it the calf}. 

#### 2 Samuel 6:7 And {was enraged in anger the LORD} with Uzzah; and {struck him there God} for the rashness; and he died there by the ark of the LORD before God. 

#### 2 Samuel 6:8 And David was depressed because of which the LORD cut severance with Uzzah. And he called that place, Severance of Uzzah, until this day. 

#### 2 Samuel 6:9 And David feared the LORD in that day, saying, How shall {enter to me the ark of God}? 

#### 2 Samuel 6:10 And {did not want David} to turn aside to himself the ark of the covenant of the LORD into the city of David. And {turned off with it David} into the house of Obed Edom the Gittite. 

#### 2 Samuel 6:11 And {stayed the ark of the LORD} in the house of Obed Edom the Gittite {months three}. And the LORD blessed the entire house of Obed Edom and all the things of his. 

#### 2 Samuel 6:12 And it was reported to king David, saying, The LORD blessed the house of Obed Edom, and all of his, because of the ark of God. And David went and led the ark of the LORD from out of the house of Obed Edom into the city of David with gladness. 

#### 2 Samuel 6:13 And there were with him the ones lifting the ark of the LORD, seven companies of dancers, and {for sacrifice a calf and lambs}. 

#### 2 Samuel 6:14 And David played music with instruments in accord in the presence of the LORD. And David was clothed in {robe a special}. 

#### 2 Samuel 6:15 And David and all the house of Israel led the ark of the LORD with a cry, and with the sound of a trumpet. 

#### 2 Samuel 6:16 And it happened of the ark coming unto the city of David, that Michal daughter of Saul looked through the window, and she saw king David dancing and playing music before the LORD; and she treated him with contempt in her heart. 

#### 2 Samuel 6:17 And they carried in the ark of the LORD, and put it aside in its place, in the middle of the tent which {pitched for it David}. And David offered whole burnt-offerings before the LORD, and peace offerings. 

#### 2 Samuel 6:18 And David completed offering the whole burnt-offerings, and the peace offerings; and he blessed the people in the name of the LORD of the forces. 

#### 2 Samuel 6:19 And he portioned to all the people among all the force of Israel, from man unto woman, to each a biscuit of bread, and broiled meat, and a pancake from the frying pan. And {went forth all the people} each to his house. 

#### 2 Samuel 6:20 And David returned to bless his house. And {came forth Michal the daughter of Saul} to meet David, and she said, How was {glorified today the king of Israel}, who was uncovered today in the eyes of the girls of his servants, as {uncovers by uncovering one} of the ones dancing. 

#### 2 Samuel 6:21 And David said to Michal, In the presence of the LORD I will dance, who chose me over your father, and over all his house, to place me in the lead over his people Israel; and I shall play and dance in the presence of the LORD. 

#### 2 Samuel 6:22 And I will be uncovered again thus, and I will be useless in your eyes, and with the girls of whom you said of me, I was not extolled. 

#### 2 Samuel 6:23 And Michal daughter of Saul did not have a child unto the day of her dying. 

#### 2 Samuel 7:1 And it came to pass when {sat the king} in his house, and the LORD rested him round about from all of his enemies; 

#### 2 Samuel 7:2 that {said the king} to Nathan the prophet, Behold, indeed, I dwell in a house of cedar, and the ark of God sits in the midst of the tent. 

#### 2 Samuel 7:3 And Nathan said to the king, All as much as should be in your heart, proceed and do! for the LORD is with you. 

#### 2 Samuel 7:4 And it came to pass in that night, and {came the word of the LORD} to Nathan, saying, 

#### 2 Samuel 7:5 Go, and speak to my servant David! Thus says the LORD, You shall not build for me a house for me to dwell in. 

#### 2 Samuel 7:6 For I have not dwelt in a house from which day I led the sons of Israel out of Egypt, until this day, for I was walking about in a lodging, in a tent. 

#### 2 Samuel 7:7 In all the places which {went by all Israel}, have I in speaking spoke to one tribe of Israel in which I gave charge to tend my people Israel, saying, Why do you not build for me a house of cedar? 

#### 2 Samuel 7:8 And now, thus you shall say to my servant David, Thus says the LORD almighty. I took you from out of the haven of the sheep, for you to be for leader over my people Israel. 

#### 2 Samuel 7:9 And I was with you in all wheresoever you went, and I utterly destroyed all your enemies from your face, and I made to you {name a great}, according to the name of the great ones of the ones upon the earth. 

#### 2 Samuel 7:10 And I will establish a place for my people Israel, and I will plant it, and they shall encamp by themselves, and shall not be anxious any longer. And {shall not proceed the son of iniquity} to humble them as from the beginning, 

#### 2 Samuel 7:11 even from the days which I ordered judges over my people Israel. And I will rest you from all your enemies. And {will report to you the LORD} that {a house he shall build} to you. 

#### 2 Samuel 7:12 And it will be whenever {should have been fulfilled days your}, and you shall sleep with your fathers, that I shall raise up your seed after you, who will be from out of your belly, and I shall prepare his kingdom. 

#### 2 Samuel 7:13 He shall build to me a house to my name, and I will erect his throne unto into the eon. 

#### 2 Samuel 7:14 I will be to him for father, and he will be to me for son. And if {should come injustice his}, then I shall reprove him by a rod of men, and by blows of the sons of men. 

#### 2 Samuel 7:15 But my mercy I will not remove from him, as I removed it from Saul, whom I removed from your face. 

#### 2 Samuel 7:16 And {shall be trustworthy your house}, and your kingdom unto the eon before me. And your throne will be erected into the eon. 

#### 2 Samuel 7:17 According to all these words, and according to all this vision, so spoke Nathan to David. 

#### 2 Samuel 7:18 And {entered king David} and sat before the LORD, and said, Who am I, O my Lord, O LORD? and what is my house, that you love me for these things? 

#### 2 Samuel 7:19 And it was reduced small before you, O my Lord, O LORD, and you spoke about the house of your servant for a far time. And is this the law of man, O my Lord, O LORD? 

#### 2 Samuel 7:20 And what shall David add yet to speak to you? And now you know your servant, O my Lord, O LORD. 

#### 2 Samuel 7:21 Because of your word, and because of your servant, you have acted, and according to your heart you have done all this greatness, to make known to your servant; 

#### 2 Samuel 7:22 so as to magnify you, O my Lord, O LORD. For there is none as you, and there is no God besides you among all in whom we heard with our ears. 

#### 2 Samuel 7:23 And what {is as your people Israel nation other} in the earth? As {guided it God} to ransom to himself a people, to establish your name for the executing greatness and grandeur, for you to cast out from in front of your people, whom you ransomed to yourself from out of Egypt, even nations and tents? 

#### 2 Samuel 7:24 And you prepared for yourself your people Israel for a people unto the eon. And you, O LORD, became to them for God. 

#### 2 Samuel 7:25 And now, O my Lord, O LORD, the word which you spoke for your servant, and for his house, confirm it as trustworthy unto the eon! And as you spoke, do! 

#### 2 Samuel 7:26 And now may {be magnified your name} until the eon, saying, 

#### 2 Samuel 7:27 The LORD almighty, God over Israel. You uncovered the ear of your servant, saying, {a house I shall build for you}. On account of this {found servant your} his own heart to pray to you this prayer. 

#### 2 Samuel 7:28 And now, O my Lord, O LORD, you are God, and your words will be true, and you spoke {concerning your servant these good things}. 

#### 2 Samuel 7:29 And now begin and bless the house of your servant to be into the eon before you! For you, O my Lord, O LORD, spoke, and from your blessing {shall be blessed the house of your servant} into the eon. 

#### 2 Samuel 8:1 And it came to pass after these things, David struck the Philistines, and put them to flight. And David took the things being separated from out of the hand of the Philistines. 

#### 2 Samuel 8:2 And David struck Moab, and he measured them out in measuring lines, resting them upon the ground; and there were the two measured out lines to kill, and the fullness of the third measured out line he took alive. And Moab became to David for servants bearing tribute. 

#### 2 Samuel 8:3 And David struck Hadadezer, son of Rehob, king of Zobah, in his going to set his hand against the Euphrates river. 

#### 2 Samuel 8:4 And David first took of his things a thousand chariots, and seven thousand horsemen, and twenty thousand men -- footmen. And David disabled all the chariots, and he left behind for himself of them a hundred chariots. 

#### 2 Samuel 8:5 And {comes Syria of Damascus} to help Hadadezer king of Zobah. And David struck among the Syrians twenty and two thousand men. 

#### 2 Samuel 8:6 And David put a detachment in Syria near Damascus. And {became the Syrians} to David for servants bearing tribute. And the LORD delivered David wheresoever he went. 

#### 2 Samuel 8:7 And David took the armlets of gold, the ones that were upon the children of Hadadezer king of Zobah, and he brought them unto Jerusalem. 

#### 2 Samuel 8:8 And from Betah, and from the chosen cities of Hadadezer, {took king David brass much exceedingly}. 

#### 2 Samuel 8:9 And {heard Toi the king of Hamath} that David struck all the force of Hadadezer. 

#### 2 Samuel 8:10 And Toi sent Joram his son to king David to ask him the things for peace, and congratulated him over which he waged war with Hadadezer, and struck him, for he was an adversary of Hadadezer. And in his hands were items of silver, and items of gold, and items of brass. 

#### 2 Samuel 8:11 And these things {sanctified king David} to the LORD, with the silver, and the gold of which he sanctified from all of the cities which he overpowered; 

#### 2 Samuel 8:12 and from Edom, and from Moab, and from the sons of Ammon, and from the Philistines, and from Amalek, and from the spoils of Hadadezer, son of Rehob, king of Zobah. 

#### 2 Samuel 8:13 And David made a name for himself. And in his returning he struck Idumea in Gebelem to eighteen thousand. 

#### 2 Samuel 8:14 And he put in Edom detachments; in all Edom he stationed ones setting up monuments, and {became all the ones in Edom} servants to David. And the LORD preserved David wheresoever he went. 

#### 2 Samuel 8:15 And David reigned over all Israel. And David was executing equity and righteousness over all his people. 

#### 2 Samuel 8:16 And Joab son of Zeruiah was over the military. And Jehoshaphat son of Ahilud was over the ones recording. 

#### 2 Samuel 8:17 And Zadok son of Ahitub and Ahimelech son of Abiathar were priests. And Seriah was the scribe, 

#### 2 Samuel 8:18 and Benaiah son of Jehoiada was counselor. And the Cherethite and the Pelethite, and the sons of David were chiefs of the palace. 

#### 2 Samuel 9:1 And David said, Is there anyone still left from the house of Saul, that I should perform with him an act of mercy because of Jonathan? 

#### 2 Samuel 9:2 And from the house of Saul was a servant; and the name to him was Ziba. And they called him to David. And {said to him the king}, You are Ziba? And he said, Your servant. 

#### 2 Samuel 9:3 And {said the king}, Is there left any man from the house of Saul, that I should perform with him an act of mercy of God? And Ziba said to the king, There still is a son to Jonathan being stricken of the feet. 

#### 2 Samuel 9:4 And {said to him the king}, Where is this one? And Ziba said to the king, Behold, in the house of Machir, son of Ammiel. of Lo-debar. 

#### 2 Samuel 9:5 And {sent king David}, and took him from out of the house of Machir, son of Ammiel, of Lo-debar. 

#### 2 Samuel 9:6 And {comes Mephibosheth son of Jonathan son of Saul} to king David. And he fell upon his face and did obeisance to him. And {said to him David}, Mephibosheth! And he said, Behold, your servant. 

#### 2 Samuel 9:7 And {said to him David}, Do not fear, for by dealing with you I shall execute with you an act of mercy because of Jonathan your father, and I will restore to you all the fields of Saul, the father of your father. And you shall eat bread at my table always. 

#### 2 Samuel 9:8 And he did obeisance to him, and said, Who am I your servant, that you looked upon the {dog dying} likened to me. 

#### 2 Samuel 9:9 And {called the king} Ziba, the servant of Saul, and said to him, All as much as is to Saul, and {entire house his}, I have given to the son of your master. 

#### 2 Samuel 9:10 And {shall work for him the land you}, and your sons, and your servants. And you shall carry in to the son of your master bread loaves, and he shall eat. And Mephibosheth son of your master shall eat bread always at my table. And to Ziba were fifteen sons and twenty servants. 

#### 2 Samuel 9:11 And Ziba said to the king, According to all as much as {gives charge my master the king} to his servant, so shall {do your servant}. And Mephibosheth ate at the table of David as one of the sons of the king. 

#### 2 Samuel 9:12 And to Mephibosheth {son a small there was}, and the name to name was Micha. And all the household of the house of Ziba were servants to Mephibosheth. 

#### 2 Samuel 9:13 And Mephibosheth dwelt in Jerusalem, for at the table of the king he ate always. And he was lame of both of his feet. 

#### 2 Samuel 10:1 And it came to pass after these things, that {died the king of the sons of Ammon}, and {reigned Hanun his son} instead of him. 

#### 2 Samuel 10:2 And David said, I will perform an act of kindness with Hanun son of Nahash, in which manner {performed his father} an act of kindness with me. And David sent to comfort him by the hand of his servants concerning his father. And {came the servants of David} into the land of the sons of Ammon. 

#### 2 Samuel 10:3 And {said the rulers of the sons of Ammon} to Hanun their master, Is the reason for David to glorify your father before you that he sent to you comforters? or is it not however that they should search the city, and spy it; for to survey it David sent his servants to you? 

#### 2 Samuel 10:4 And Hanun took the servants of David, and he shaved their beards, and cut off their uniforms in half unto their hips, and he sent them out. 

#### 2 Samuel 10:5 And it was reported to David concerning the men. And he sent to meet them, for {were the men} dishonored exceedingly. And {said the king}, Stay in Jericho until {rise beards your}, and you shall return. 

#### 2 Samuel 10:6 And {saw the sons of Ammon} that {was disgraced the people of David}, and {sent the sons of Ammon}, and they hired the Syrian of Beth-rehob, and the Syrian of Zoba -- twenty thousand footmen, and the king of Maacah -- a thousand men, and the one of Tob -- twelve thousand men. 

#### 2 Samuel 10:7 And David heard, and he sent Joab and all the force of the mighty ones. 

#### 2 Samuel 10:8 And {came forth the sons of Ammon}, and deployed for war by the door of the gate. And the Syrian Zoba, and Rehob, and IshTob, and Maacah were by themselves in the field. 

#### 2 Samuel 10:9 And Joab beheld that it came to pass {him was facing that the war} from the face right opposite, and from the rear. And he chose from out of all the young men of Israel, and deployed right opposite Syria. 

#### 2 Samuel 10:10 And the rest of the people he put into the hand of Abishai his brother. And they deployed right opposite the sons of Ammon. 

#### 2 Samuel 10:11 And he said, If Syria should strengthen over me, then you shall be to me for deliverance. And if the sons of Ammon should be strengthened over you, then I will come to deliver you. 

#### 2 Samuel 10:12 Be manly! for we should be strengthened for our people, and for the cities of our God. And the LORD will do good in his eyes. 

#### 2 Samuel 10:13 And Joab approached and his people with him for war against Syria. And they fled from his face. 

#### 2 Samuel 10:14 And the sons of Ammon beheld that Syria has fled. And they fled from the face of Abishai, and they entered into the city. And Joab returned from the sons of Ammon, and came unto Jerusalem. 

#### 2 Samuel 10:15 And Syria beheld that it failed in front Israel; and they gathered together at the same place. 

#### 2 Samuel 10:16 And Hadarezer sent, and gathered together the Syrian from the other side of the river. And they came unto Helam. And Shobach the commander-in-chief of Hadarezer was in front of them. 

#### 2 Samuel 10:17 And it was reported to David, and he gathered together all Israel, and he passed over the Jordan, and he came to Helam. And Syria deployed before David, and he waged war with him. 

#### 2 Samuel 10:18 And Syria fled from the face of Israel. And David killed of the one from Syria -- seven hundred chariots, and forty thousand horsemen. And Shobach his commander-in-chief he struck, and he died there. 

#### 2 Samuel 10:19 And {beheld all the kings the servants of Hadarezer} that they failed in front of Israel. And they deserted after Israel, and they served them. And Syria feared to yet again deliver the sons of Ammon. 

#### 2 Samuel 11:1 And it came to pass in the turning of the year into the time of the departure of the kings for battle, that David sent Joab and his servants with him and all Israel; and they utterly destroyed the sons of Ammon, and they besieged against Rabbah. And David stayed in Jerusalem. 

#### 2 Samuel 11:2 And it came to pass towards evening, and David rose up from his bed, and walked upon the roof of the house of the king. And he beheld from the roof a woman bathing; and the woman was good in appearance -- exceedingly. 

#### 2 Samuel 11:3 And David sent and sought the woman. And they said said, Is not this Bath-sheba, daughter of Eliam, wife of Uriah the Hittite? 

#### 2 Samuel 11:4 And David sent messengers, and he took her; and he entered to her, and went to bed with her, and she was being set apart from her uncleanness. And she returned to her house. 

#### 2 Samuel 11:5 And {conceived the woman}. And she sent and reported to David, and said, I am one conceiving. 

#### 2 Samuel 11:6 And David sent to Joab, saying, Send to me Uriah the Hittite! And Joab sent Uriah to David. 

#### 2 Samuel 11:7 And Uriah came and entered to him. And David asked for the peace of Joab, and for the peace of the people, and for the peace of the war. 

#### 2 Samuel 11:8 And David said to Uriah, Go down to your house, even to wash your feet! And Uriah went forth from the house of the king; and went forth after him a tribute from the king. 

#### 2 Samuel 11:9 And Uriah went to bed by the door of the house of the king with all the servants of his master; and he did not go down to his house. 

#### 2 Samuel 11:10 And they reported to David, saying that, {did not go down Uriah} to his house. And David said to Uriah, {not from a journey you Are come}? Why did you not go down to your house? 

#### 2 Samuel 11:11 And Uriah said to David, The ark, and Israel, and Judah, dwell in tents; and my master Joab, and the man-servants of my master {upon the face of the field camp}; and shall I enter into my house to eat and to drink and to go to bed with my wife? By your life, and by the life of your soul, in no way shall I do this thing. 

#### 2 Samuel 11:12 And David said to Uriah, Stay here also today! and tomorrow I will send you. And Uriah stayed in Jerusalem on that day, and the next day. 

#### 2 Samuel 11:13 And {called him David}. And he ate before him, and drank. And he intoxicated him. And he went forth at evening to go to bed upon his bed with the servants of his master, but {unto his house he did not go down}. 

#### 2 Samuel 11:14 And it became morning, and David wrote a scroll to Joab, and sent it by the hand of Uriah. 

#### 2 Samuel 11:15 And he wrote in the scroll, saying, Bring Uriah right opposite the battle of the fortified part, and turn away from behind him! so that he shall be struck and shall die. 

#### 2 Samuel 11:16 And it came to pass in Joab's guarding at the city, that he put Uriah into the place where he knew that men of power were there. 

#### 2 Samuel 11:17 And {came forth the men of the city}, and waged war against Joab. And there fell some of the people of the servants of David; and {died also even Uriah the Hittite}. 

#### 2 Samuel 11:18 And Joab sent and reported to David all the matters of the battle. 

#### 2 Samuel 11:19 And Joab gave charge to the messenger, saying, In your completing all the matters of the battle speaking to the king, 

#### 2 Samuel 11:20 that it shall be if {ascends the rage of the king}, and he should say to you, Why is it that you approached to the city to wage war? Did you not know that they would shoot from on top the wall? 

#### 2 Samuel 11:21 Who struck Abimelech son of Jerubbesheth? Did not a woman toss a piece of millstone upon him from above the wall, and he died in Thebez? Why did you lead forward to the wall? And you shall say, And also your servant Uriah the Hittite is dead. 

#### 2 Samuel 11:22 And {came the messenger of Joab} to the king in Jerusalem, and reported to David all as much as Joab spoke. 

#### 2 Samuel 11:23 And {said the messenger} to David that, {strengthened against us The men}, and came forth against us into the field, and we came unto them unto the door of the gate. 

#### 2 Samuel 11:24 And {shot the ones shooting} unto your servants from of the wall, and there died some of the servants of the king, and even your subject Uriah the Hittite has died. 

#### 2 Samuel 11:25 And David said to the messenger, Thus you shall say to Joab, Do not let {be severe in your eyes this matter}, for perhaps indeed it is thus one way, and perhaps thus another way {devours that the broadsword}; strengthen your battle against the city, and raze it, and strengthen against it. 

#### 2 Samuel 11:26 And {heard the wife of Uriah} that {has died Uriah her husband}, and she lamented over her husband. 

#### 2 Samuel 11:27 And {went by the time of mourning}, and David sent and brought her into his house. And she became to him for a wife, and she bore to him a son. And {wicked appeared the matter which David did} in the eyes of the LORD. 

#### 2 Samuel 12:1 And the LORD sent Nathan the prophet to David. And he entered to him, and said to him, There were two men in one city -- one rich and one needy. 

#### 2 Samuel 12:2 And there was to the rich man flocks and herds -- many, exceedingly. 

#### 2 Samuel 12:3 And to the needy there was not anything, but only {ewe-lamb one small} which he acquired, and protected, and nourished it. And it matured with him, and with his sons at the same time. {from his bread It ate}, and {from his cup it drank}, and {in his bosom it slept}, and it was to him as a daughter. 

#### 2 Samuel 12:4 And {came a traveller} to the {man rich}. And he spared to take from his flock, and from his herd, to prepare for the stranger coming to him. And he took the ewe-lamb of the {man needy}; and he prepared it for the man coming to him. 

#### 2 Samuel 12:5 And {was enraged in anger David} exceedingly against the man. And he said to Nathan, As the LORD lives, that {is a son of death man doing this}. 

#### 2 Samuel 12:6 And for the ewe-lamb he shall pay four-fold, because he did this thing, and for which he did not spare. 

#### 2 Samuel 12:7 And Nathan said to David, You are the man, the one doing this thing. Thus says the LORD God of Israel, I anointed you for king over Israel, and I rescued you from out of the hand of Saul. 

#### 2 Samuel 12:8 And I gave to you the house of your master, and the wives of your master into your bosom, and I gave to you the house of Israel and Judah. And if {little to you it is}, I would have added to you as those. 

#### 2 Samuel 12:9 Why is it that you treated as worthless the word of the LORD, to do the wicked thing in his eyes? Uriah the Hittite you struck by the broadsword, and his wife you took to yourself for wife, and him you killed by the broadsword of the sons of Ammon. 

#### 2 Samuel 12:10 And now, {shall not depart the broadsword} from your house unto the eon. Because of this, for you treated me with contempt, and took the wife of Uriah the Hittite to be to you for a wife. 

#### 2 Samuel 12:11 Thus says the LORD, Behold, I shall awaken {against you evils} from out of your house, and I shall take your wives before your eyes, and I will give them to your neighbor, and he shall go to bed with your wives before this sun. 

#### 2 Samuel 12:12 For you did it secretly, but I will do this thing before all Israel, and before this sun. 

#### 2 Samuel 12:13 And David said to Nathan, I have sinned against the LORD. And Nathan said to David, And the LORD cast aside your sin, and you shall not die. 

#### 2 Samuel 12:14 Except that, in provoking to anger, you provoked to anger the enemies of the LORD in this thing, and indeed your son, the one born to you, to death he will die. 

#### 2 Samuel 12:15 And Nathan went forth to his house. And the LORD enfeebled the child which {bore the wife of Uriah} unto David, and he was ill. 

#### 2 Samuel 12:16 And David sought God for the boy. And David fasted with fasting, and he entered and lodged upon the ground. 

#### 2 Samuel 12:17 And {rose up the elders of his house} to him, to raise him from the ground, and he did not want, and he would not eat bread with them. 

#### 2 Samuel 12:18 And it came to pass in {day the seventh}, and {died the boy}. And {feared the servants of David} to announce to him that, {has died The boy}. For they said, Behold, while the boy was still living, we spoke to him, and he did not listen to our voice. And how should we say to him that, {has died The boy}. For he shall do bad things. 

#### 2 Samuel 12:19 And David perceived that his servants were whispering, and David comprehended that {has died the boy}. And David said to his servants, Has {died the boy}? And they said, He has died. 

#### 2 Samuel 12:20 And David rose up from the ground, and bathed, and anointed himself, and changed his clothes. And he entered into the house of God, and did obeisance to him. And he entered unto his house, and asked for bread to eat. And they placed near him bread, and he ate. 

#### 2 Samuel 12:21 And {said his servants} to him, What is this thing which you do because of the boy? While still living you fasted, and wept, and were sleepless; and when {died the boy} you rose up and ate bread and drank? 

#### 2 Samuel 12:22 And David said, While the boy was still living, I fasted and wept. For I said, Who knows if {will show mercy on me the LORD}, and {shall live the boy}? 

#### 2 Samuel 12:23 And now he has died, why this that I fast? I shall not be able to return him, yet I will go to him, but he shall not return to me. 

#### 2 Samuel 12:24 And David comforted his wife Bath-sheba. And he entered to her, and went to bed with her, and she conceived, and gave birth to a son, and called his name Solomon. And the LORD loved him. 

#### 2 Samuel 12:25 And he sent by the hand of Nathan the prophet; and called his name Jedidiah, by the word of the LORD. 

#### 2 Samuel 12:26 And Joab waged war with Rabbah of the sons of Ammon, and he overtook the city of the kingdom. 

#### 2 Samuel 12:27 And Joab sent messengers to David, and said, I waged war against Rabbah, and overtook the city of waters. 

#### 2 Samuel 12:28 And now, gather together the rest of the people, and camp upon the city, and be the first to take it! that {should not be the first to take I} the city, and {should be called my name} upon it. 

#### 2 Samuel 12:29 And David gathered together all the people, and he went to Rabbah, and waged war against it, and overtook it. 

#### 2 Samuel 12:30 And he took the crown of their king from his head. And its weight was a talent of gold, and {stone of precious}. And it was upon the head of David. And {spoils of the city he brought forth much exceedingly}. 

#### 2 Samuel 12:31 And the people, the one in it, he led out and put them to the saw, and to the threshing-machines of iron, and adz of iron. And he led them through the brick-kiln. And thus he did to all the cities of the sons of Ammon. And David returned and all the people to Jerusalem. 

#### 2 Samuel 13:1 And it happened after these things, that there was to Absalom, son of David, a sister good to the sight, exceedingly. And her name was Tamar, and {loved her Amnon son of David}. 

#### 2 Samuel 13:2 And Amnon was afflicted so as to be ill over Tamar his sister, for {a virgin she was}, and it was an enormous thing in the eyes of Amnon to do anything to her. 

#### 2 Samuel 13:3 And there was a companion to Amnon, and his name was Jonadab son of Shimeah the brother of David. And Jonadab was {practical exceedingly}. 

#### 2 Samuel 13:4 And he said to him, What is it to you that thus you are weak morning by morning, O son of the king? Will you not report it to me? And {said to him Amnon}, Tamar, the sister of my brother Absalom, I love. 

#### 2 Samuel 13:5 And {said to him Jonadab}, Go to bed in your bed, and be as infirm! and {will enter your father} to see you. And you shall say to him, Let {come indeed Tamar my sister} and feed me! and let her make {before my eyes food}! so that I should see, and eat from her hand. 

#### 2 Samuel 13:6 And Amnon went to bed, and became as ill. And {entered the king} to see him. And Amnon said to the king, Let {come indeed Tamar my sister} to me! and let her bake {before my eyes two biscuits}! and I will eat from her hand. 

#### 2 Samuel 13:7 And David sent for Tamar to the house, saying, Go indeed to the house of Amnon your brother, and make food for him! 

#### 2 Samuel 13:8 And Tamar went to the house of Amnon her brother. And with him being in bed, that she took the dough and mixed it, and made biscuits before his eyes, and baked the biscuits. 

#### 2 Samuel 13:9 And she took the frying pan, and emptied it before him, and he did not want to eat. And Amnon said, Lead out every man from about me! And they led out every man about him. 

#### 2 Samuel 13:10 And Amnon said to Tamar, Carry in to me the food to the bedroom! and I shall eat from out of your hand. And Tamar took the biscuits which she made, and carried them to Amnon her brother, into the bedroom. 

#### 2 Samuel 13:11 And she brought to him to eat. And he took hold of her, and said to her, Come, go to bed with me my sister! 

#### 2 Samuel 13:12 And she said to him, No, O my brother, you should not abase me, for it shall not be done so in Israel. You should not do this folly. 

#### 2 Samuel 13:13 And I, where shall I carry away my scorn? And you will be as one of the fools in Israel. And now, speak indeed to the king! for in no way will he restrain me from you. 

#### 2 Samuel 13:14 And {did not want Amnon} to hear her voice. And he powered over her, and abased her, and went to bed with her. 

#### 2 Samuel 13:15 And {detested her Amnon} with an {hatred great exceedingly}; for so great was the hatred which he detested her, that it was above the love which he loved her. And {said to her Amnon}, Rise up and go! 

#### 2 Samuel 13:16 And {said to him Tamar} that, Great is the {evil last} over the first which you do with me, to send me away. And {did not want Amnon} to hearken to her voice. 

#### 2 Samuel 13:17 And he called his servant set over his house, and said to him, Send indeed this one from me outside, and lock the door after her! 

#### 2 Samuel 13:18 And upon her was an inner garment with long sleeves, for thus {dressed the daughters of the king}, the virgins, the ones with their outer garments. And {led her minister his} outside, and locked the door after her. 

#### 2 Samuel 13:19 And Tamar took ashes, and put them upon her head. And the inner garment, the one with long sleeves, the one upon her, she tore; and she put her hands upon her head, and she went going and crying out. 

#### 2 Samuel 13:20 And {said to her Absalom her brother}, Has Amnon your brother been with you? And now my sister be silent! for {is your brother he}. Do not put it to your heart to say anything! And Tamar sat expiring in the house of Absalom her brother. 

#### 2 Samuel 13:21 And king David heard all these words, and was enraged exceedingly. 

#### 2 Samuel 13:22 And {did not speak Absalom} with Amnon of bad or good, for Absalom detested Amnon for which he abased Tamar his sister. 

#### 2 Samuel 13:23 And it came to pass after two whole years of days, that they were shearing for Absalom in Baal-hazor, the one by Ephraim. And Absalom called all the sons of the king. 

#### 2 Samuel 13:24 And Absalom came to the king, and said, Behold indeed, {shears your servant}. Let {go indeed the king}, and his servants with your servant. 

#### 2 Samuel 13:25 And {said the king} to Absalom, No indeed, O my son, in no way should we all go ourselves, and in no way should we be burdensome upon you. And Absalom constrained him, and the king did not want to go, but he blessed him. 

#### 2 Samuel 13:26 And Absalom said, And if not, let {go indeed with us Amnon my brother}! And {said to him the king}, Why should he go with you? 

#### 2 Samuel 13:27 And {constrained him Absalom}, and he sent with him Amnon, and all the sons of the king. 

#### 2 Samuel 13:28 And Absalom gave charge to his servants, saying, Behold, when ever {feels good the heart of Amnon} with the wine, and I should say to you, Strike Amnon and put him to death! you should not fear. For is it not I giving charge to you? Be manly and become as sons of power! 

#### 2 Samuel 13:29 And {did the servants of Absalom} to Amnon as he gave charge to them. And {rose up all the sons of the king}, and {mounted each} upon his mule, and they fled. 

#### 2 Samuel 13:30 And it came to pass of their being in the way, that the report came to David saying, Absalom struck all the sons of the king, and did not leave behind of them not even one. 

#### 2 Samuel 13:31 And {rose up the king}, and tore his clothes, and laid upon the ground. And all his servants standing around him tore their clothes. 

#### 2 Samuel 13:32 And {answered Jonadab son of Shimeah brother of David} and said, Let not {say my master the king} that all the boys of the sons of the king he put to death! but only Amnon alone died, for by the mouth of Absalom it was situated to be from the day of which he abased Tamar his sister. 

#### 2 Samuel 13:33 And now, let not {put my master the king} {upon his heart the matter}! saying that, All the sons of the king died; for only Amnon alone died. 

#### 2 Samuel 13:34 And Absalom ran away. And {lifted the servant watchman} his eyes and looked. And behold, {people there were many} going in the way behind him from out of the side of the mountain. 

#### 2 Samuel 13:35 And Jonadab said to the king, Behold, the sons of the king are at hand; according to the word of your servant, thus it has happened. 

#### 2 Samuel 13:36 And it came to pass when he completed speaking, that behold, the sons of the king came and lifted up their voice and wept. And indeed the king and all his servants wept {weeping great an exceedingly}. 

#### 2 Samuel 13:37 And Absalom ran away, and he went to Talmai, son of Ammihud, king of Geshur. And {mourned the king} over his son all the days. 

#### 2 Samuel 13:38 And Absalom fled and went forth unto Geshur, and he was there {years three}. 

#### 2 Samuel 13:39 And {abated the spirit of king David} to go forth unto Absalom; for he was comforted concerning Amnon, that he died. 

#### 2 Samuel 14:1 And {knew Joab son of Zeruiah} that the heart of the king was towards Absalom. 

#### 2 Samuel 14:2 And Joab sent to Tekoah, and he took from there {woman a wise}. And he said to her, You mourn indeed, and put on {garments mournful}, and do not anoint yourself with oil, and be as a woman {days for many mourning} for one having died! 

#### 2 Samuel 14:3 And you shall come to the king, and you shall speak to him according to this thing. And Joab put the words into her mouth. 

#### 2 Samuel 14:4 And {entered the Tekoahite woman} to the king, and she fell upon her face to the ground, and she did obeisance to him. And she said, Deliver, O king, deliver! 

#### 2 Samuel 14:5 And {said to her the king}, What to you is it? And she said, By all means {woman a widow I am}, and {died my husband}. 

#### 2 Samuel 14:6 And indeed to your maidservant are two sons, and they {quarreled both} in the field, and there was no one for rescuing between them, and {hit the one} {one brother his}, and killed him. 

#### 2 Samuel 14:7 And behold, {rose up entire the family} against your maidservant, and they said, Give over the one hitting his brother, and we shall kill him, on account of the life of his brother whom he killed; and we shall take away the heir. And so they shall extinguish my spark of coal, the one being left behind to me, so as to not establish to my husband a vestige and name upon the face of the earth. 

#### 2 Samuel 14:8 And {said the king} to the woman, Go to your house being in health! and I will take charge concerning you. 

#### 2 Samuel 14:9 And {said woman the Tekoahite} to the king, O my master, O king, upon me be the iniquity, and upon the house of my father! and the king and his throne be innocent! 

#### 2 Samuel 14:10 And {said the king}, The one speaking to you a word, lead him to me! and in no way shall anyone proceed yet to touch you. 

#### 2 Samuel 14:11 And {said the woman}, Let now {remember indeed the king} the LORD your God! to multiply a relative for blood to utterly destroy, and in no way take away my son. And he said, As the LORD lives, there shall not fall of the hair of your son upon the ground. 

#### 2 Samuel 14:12 And {said the woman}, Let {speak indeed your maidservant} to my master the king a thing! And he said, Speak! 

#### 2 Samuel 14:13 And {said the woman}, Why have you imputed thus upon the people of God? Yes, by {speaking the king} this word it is as a trespass, {to not return for the king} the one being thrust away by him. 

#### 2 Samuel 14:14 For to death we shall die, and as the water being discharged upon the earth, not being gathered together; that {not God shall} take the life; yet he himself devises a device to not thrust away from him the one being thrusted away. 

#### 2 Samuel 14:15 And now for which I came to speak to {the king my master} this word, for {see me the people}; and {will say maidservant your}, Let {speak indeed your maidservant} to my master the king, if by any means {shall do the king} the matter of his maidservant; 

#### 2 Samuel 14:16 for {shall hear the king} to rescue his maidservant from out of the hand of the man seeking to take me away, and my son, from the inheritance of God. 

#### 2 Samuel 14:17 And said your maidservant, Let indeed the word of my master the king be as an accepted sacrifice. For as a messenger of God, thus is my master the king, to hear the good and the bad; and the LORD your God will be with you. 

#### 2 Samuel 14:18 And {answered the king} and said to the woman, You should not indeed hide from me the matter which ever I shall ask you. And {said the woman}, Let {speak indeed my master the king}! 

#### 2 Samuel 14:19 And {said the king}, Is not the hand of Joab in all this with you? And {answered and said the woman} to the king, As {lives your soul}, O my master, O king, since there is no turning to the right or to the left of all which {spoke my master the king}, for your servant Joab himself gave charge to me, and he put {in the mouth of your maidservant all these words}. 

#### 2 Samuel 14:20 So as for {to come about the face of this matter}, {prepared your servant Joab} this thing. And my master the king is wise as the wisdom of a messenger of God, to know all the things in the land. 

#### 2 Samuel 14:21 And {said the king} to Joab, Behold, indeed I do to you according to {your word this}. Go return the young man Absalom! 

#### 2 Samuel 14:22 And Joab fell upon his face upon the ground, and did obeisance, and blessed the king. And Joab said, Today {knows your servant} that he found favor in your eyes, O my master, O king, for {did my master the king} the matter for his servant. 

#### 2 Samuel 14:23 And Joab rose up and went into Geshur, and he led Absalom into Jerusalem. 

#### 2 Samuel 14:24 And {said the king}, Let him return to his house, but {my face let him not see}! And Absalom returned to his house, but the face of the king he did not see. 

#### 2 Samuel 14:25 And {as Absalom there was no man} in all Israel as {praiseworthy exceedingly}. From the sole of his foot and unto the top of his head -- there was not {on him a blemish}. 

#### 2 Samuel 14:26 And in his shearing his head, and it took place at the end of days unto days that he sheared it, for it became burdensome upon him; and shearing, he set aside the hair of his head two hundred shekels of the {scale-weight royal}. 

#### 2 Samuel 14:27 And there was born to Absalom three sons and {daughter one}, and her name was Tamar, she was {woman goodly an exceedingly}. 

#### 2 Samuel 14:28 And Absalom stayed in Jerusalem two years of days, and the face of the king he did not see. 

#### 2 Samuel 14:29 And Absalom sent for Joab to send him to the king, and he did not want to come to him. And he sent again the second time to him, and he did not want to come. 

#### 2 Samuel 14:30 And Absalom said to his servants, You know the portion in the field of Joab being next to mine, and to him is barley there. You go and burn it by fire! And {burned the servants of Absalom} by fire the portion of the field of Joab. 

#### 2 Samuel 14:31 And Joab rose up, and came to Absalom, to the house, and said to him, Why did {set on fire your servants} my field with fire? 

#### 2 Samuel 14:32 And Absalom said to Joab, Behold, I sent to you, saying, Come here! And I will send you to the king, saying, Why did I come from out of Geshur? {good for me It was} to be there. And now, I shall see indeed the face of the king, and if there is {in me iniquity} then I shall be killed. 

#### 2 Samuel 14:33 And Joab went to the king, and reported to him. And he called Absalom, and he entered to the king, and he did obeisance to him and fell upon his face upon the ground before the king. And {kissed the king} Absalom. 

#### 2 Samuel 15:1 And it came to pass after these things, that {prepared for himself Absalom} chariots, and horsemen, and fifty men to run along in front of him. 

#### 2 Samuel 15:2 And {rose early Absalom}, and stood at the way of the gate. And it came to pass every man in which had a case, and came to the king for a judgment, that {called him Absalom}, and said to him, From out of of what city are you? And he said, {is from one of the tribes of Israel your servant}. 

#### 2 Samuel 15:3 And {said to him Absalom}, Behold, your words are good and well-tempered; but {hearing no one there is} you from the king. 

#### 2 Samuel 15:4 And Absalom said, Why shall he not place me for judge in the land, and {to me shall come every man} to whom ever there might be a dispute, and a case, and I will do justice for him. 

#### 2 Samuel 15:5 And it came to pass when the {approached man} to do obeisance to him, that he stretched out his hand, and took hold of him, and kissed him. 

#### 2 Samuel 15:6 And Absalom did according to this thing to all Israel, to the ones coming for a judgment to the king. And Absalom adopted the heart of the men of Israel. 

#### 2 Samuel 15:7 And it came to pass at the end of forty years, that Absalom said to his father, I will go indeed and pay my vows which I vowed to the LORD in Hebron. 

#### 2 Samuel 15:8 For {a vow vowed servant your} in my living in Geshur in Syria, saying, If in returning {shall return me the LORD} to Jerusalem, then I will serve to the LORD. 

#### 2 Samuel 15:9 And {said to him the king}, Proceed in peace! And rising up he went unto Hebron. 

#### 2 Samuel 15:10 And Absalom sent spies into all the tribes of Israel, saying, In your hearing the sound of the trumpet, that you shall say, {reigns Absalom} in Hebron. 

#### 2 Samuel 15:11 And {went with Absalom two hundred men from out of Jerusalem chosen}; and they went in simplicity, and they did not know not one thing. 

#### 2 Samuel 15:12 And Absalom sent and called Ahithophel the Gilonite, counselor to David, from out of his city Giloh, during his sacrificing the sacrifices. And there was {confederation a strong}. And the people went, and it multiplied with Absalom. 

#### 2 Samuel 15:13 And one came reporting to David, saying, {is committed The heart of the men of Israel} after Absalom. 

#### 2 Samuel 15:14 And David said to all his servants with him in Jerusalem, Rise up! for we should flee, for there is no deliverance for us from the face of Absalom. Hasten to go! that he should not hasten and overtake us, and thrust {upon us evil}, and should strike the city by the mouth of the broadsword. 

#### 2 Samuel 15:15 And {said the servants of the king} to the king, According to all as much as seems good to our master the king, behold, we are your servants. 

#### 2 Samuel 15:16 And {went forth the king}, and all his house on their feet. And {left the king} ten women of his concubines to guard the house. 

#### 2 Samuel 15:17 And {went forth the king}, and all his people by foot. And they set up in a house far away. 

#### 2 Samuel 15:18 And all his servants {by his hand passed}. And every Cherethite, and every Pelethite, and all the Gittites -- six hundred men having come from out of Gath by foot, were passing in front of the king. 

#### 2 Samuel 15:19 And {said the king} to Ittai the Gittite, Why should you go even yourself with us? Return and live with the king! For you are an alien yourself, and because you are displaced from out of your place. 

#### 2 Samuel 15:20 Since {yesterday you came}, then today shall I move you to go with us? And I shall go where ever I shall go. Go, and return your brothers with you! and the LORD shall execute with you an act of kindness and truth. 

#### 2 Samuel 15:21 And Ittai answered the king, and said, As the LORD lives, and as {lives my master the king}, that unto the place where ever {might be my master the king}, and if unto death, or if unto life, that there {will be your servant}. 

#### 2 Samuel 15:22 And David said to Ittai, Go, and pass over with me! And {went Ittai the Gittite}, and all the men, the ones with him, and all his servants. 

#### 2 Samuel 15:23 And all the land wept {voice with a great}. And all the people passed through the rushing stream of the Kidron. And the king passed over the rushing stream Kidron. And all the people came unto the face of the way of the wilderness. 

#### 2 Samuel 15:24 And behold, also indeed Zadok and all the Levites were with him lifting the ark of the covenant of God. And they stationed the ark of God. And Abiathar ascended until {ceased all the people} going out of the city. 

#### 2 Samuel 15:25 And {said the king} to Zadok, Return the ark of God unto the city! If I should find favor in the eyes of the LORD, and he returns me, then he shall show it to me, and its beauty. 

#### 2 Samuel 15:26 And if he should say thus, I have no want in you; behold, I, I let him do to me the pleasing thing before him. 

#### 2 Samuel 15:27 And {said the king} to Zadok the priest, Behold, you return to the city in peace, and Ahimaaz your son, and Jonathan the son of Abiathar, the two sons of yours with you! 

#### 2 Samuel 15:28 Behold, I wait for you in the wilderness of the desert until the coming of a word by you to report to me. 

#### 2 Samuel 15:29 And {returned Zadok and Abiathar} the ark of God to Jerusalem, and it stayed there. 

#### 2 Samuel 15:30 And David ascended upon the ascent of the olive groves, ascending and weeping, and his head being covered over, and he went barefoot. And all the people, the one with him, {covered each man} his head. And they ascended -- ascending and weeping. 

#### 2 Samuel 15:31 And it was announced to David, saying, And Ahithophel is among the ones confederating with Absalom. And David said, O LORD my God, efface indeed the counsel of Ahithophel! 

#### 2 Samuel 15:32 And David was coming unto Ros, where he did obeisance there to God. And behold, {was come for meeting him Hushai the chief friend of David}, tearing his inner garment, with earth upon his head. 

#### 2 Samuel 15:33 And {said to him David}, If you should go through with me, then you will be unto me a load. 

#### 2 Samuel 15:34 If into the city you should return, then you shall say to Absalom, {your servant I am}, O king, allow me to live! {a servant of your father for I was} then and just now, and now I am your servant. And by saying this efface to me the counsel of Ahithophel! 

#### 2 Samuel 15:35 And behold, there are with you Zadok and Abiathar the priests. And it will be every word which ever you should hear from out of the house of the king, that you shall report it to Zadok and Abiathar the priests. 

#### 2 Samuel 15:36 Behold, {there are with them two sons their}, Ahimaaz son of Zadok, and Jonathan son of Abiathar. And you shall send by their hand to me every word which ever you should hear. 

#### 2 Samuel 15:37 And {entered the friend Hushai of David} into the city, and Absalom at present entered into Jerusalem. 

#### 2 Samuel 16:1 And David went through a little way from Ros. And behold, Ziba the servant of Mephibosheth arrived for meeting him, and a pair of donkeys being saddled, and upon them two hundred bread loaves, and an ephah of dried grape clusters, and a hundred dried fruit clusters, and a skin flask of wine. 

#### 2 Samuel 16:2 And {said the king} to Ziba, What are these to you? And Ziba said, The donkeys for the household of the king to mount, and the bread loaves, and the dried fruit clusters, and dried grapes for food to the servants, and the wine to drink to the one faint in the wilderness. 

#### 2 Samuel 16:3 And {said the king}, Where is the son of your master? And Ziba said to the king, Behold, he sits in Jerusalem, for he said, Today {shall return to me the house of Israel} the kingdom of my father. 

#### 2 Samuel 16:4 And {said the king} to Ziba, Behold, I give to you all as much as is Mephibosheth's. And Ziba said, I do obeisance, may I find favor in your eyes, O my master, O king. 

#### 2 Samuel 16:5 And {came king David} until Bahurim. And behold, from there a man came forth from the family of the house of Saul, and the name to him was Shimei, son of Gera. He came forth coming and cursing, 

#### 2 Samuel 16:6 and throwing stones at David, and at all the servants of king David. And all the people, and all the mighty ones of the right and of the left of the king. 

#### 2 Samuel 16:7 And thus Shimei said in his cursing, Go forth! go forth! O man of the blood sheddings, and O man the lawbreaker. 

#### 2 Samuel 16:8 {returned upon you The LORD} all the blood of the house of Saul, because you reigned instead of him. And the LORD gave the kingdom into the hand of Absalom your son. And behold, you are taken in your own evil, for {are a man of blood you}. 

#### 2 Samuel 16:9 And {said Abishai son of Zeruiah} to the king, Why {curse dog dying does this} my master the king? Let me pass indeed! and I shall remove his head. 

#### 2 Samuel 16:10 And {said the king} to Abishai, What is it to me and to you, sons of Zeruiah? Even leave him, and thus let him curse! For the LORD said to him to curse David. And who shall say to him, Why did you do thus? 

#### 2 Samuel 16:11 And David said to Abishai, and to all his servants, Behold, my son, the one coming forth from out of my belly, seeks my life. And moreover, now the son of the Benjamite. Leave him to curse! for {told him the LORD}. 

#### 2 Samuel 16:12 If by any means the LORD may behold in my humiliation, and shall return good to me for his curse this day -- so be it! 

#### 2 Samuel 16:14 13 And David went, and all his men in the way; and Shimei went according to the side of the mountain, being next to him -- he went, and cursed, and cast stones on him, and {dust strewing}.And {went the king}, and all the people with him being faint; and they refreshed there. 

#### 2 Samuel 16:15 And Absalom, and every man of Israel entered into Jerusalem, and Ahithophel was with him. 

#### 2 Samuel 16:16 And it came to pass when {came Hushai the chief friend of David} to Absalom, that Hushai said to Absalom, As lives the king! As lives the king! 

#### 2 Samuel 16:17 And Absalom said to Hushai, Is this your act of kindness with your companion? Why did you not go with your companion? 

#### 2 Samuel 16:18 And Hushai said to Absalom, No, but following after whoever the LORD chooses, and this people, and every man of Israel. {serving to him I will be} and {with him I shall sit down}. 

#### 2 Samuel 16:19 And secondly, to whom shall I serve? Should I not serve before his son? Just as I served before your father, so I will be before you. 

#### 2 Samuel 16:20 And Absalom said to Ahithophel, Give {for yourselves counsel} what we should do. 

#### 2 Samuel 16:21 And Ahithophel said to Absalom, Enter to the concubines of your father! which he left behind to guard his house. And {shall hear all Israel} that you disgraced your father, and {shall grow in strength the hands of all the ones with you}. 

#### 2 Samuel 16:22 And they pitched the tent of Absalom upon the roof, and Absalom entered to the concubines of his father, in the eyes of all Israel. 

#### 2 Samuel 16:23 And the counsel of Ahithophel, which he consulted in the {days first}, was in which manner as if he should ask anything by the word of God; thus was all the counsel of Ahithophel, both to David and to Absalom. 

#### 2 Samuel 17:1 And Ahithophel said to Absalom, I shall choose indeed for myself twelve thousand men, and I shall rise up and pursue after David at night. 

#### 2 Samuel 17:2 And I shall come upon him, and he will be tiring and loosening his hand, and I shall startle him, and {shall flee all the people with him}, and I shall strike the king alone. 

#### 2 Samuel 17:3 And I shall return all the people to you, in which manner {returns a bride} to her husband. Besides {the life man of one you seek}, and all the people will be at peace. 

#### 2 Samuel 17:4 And {was pleasing the word} in the eyes of Absalom, and in the eyes of all the elders of Israel. 

#### 2 Samuel 17:5 And Absalom said, Call indeed Hushai the Archite, and I shall hear what is in his mouth, and indeed of him. 

#### 2 Samuel 17:6 And Hushai entered to Absalom. And Absalom said to him, saying, According to this thing Ahithophel spoke. Shall we do according to his word? But if not you speak! 

#### 2 Samuel 17:7 And Hushai said to Absalom, It is not good, this counsel which Ahithophel counseled this one time. 

#### 2 Samuel 17:8 And Hushai said, You know your father, and his men, that {mighty they are exceedingly}, and {is very bitter their soul} as a bear being made childless in the plain. And your father is {man a warrior}, and in no way shall he rest the people. 

#### 2 Samuel 17:9 For behold he now hides in one of the canyons, or in one of the places. And it will be when they fall upon them at the beginning, that one shall hear the hearing, and should say, There was a devastation among the people, to the one following after Absalom. 

#### 2 Samuel 17:10 And indeed any son of power whose heart is as the heart of a lion, in melting away he shall melt away, for {knows all Israel} that {is mighty your father} and the sons of power, all the ones with him. 

#### 2 Samuel 17:11 Thus advising, I advised. And {in gathering together shall gather together unto you all Israel}, from Dan and unto Beer-sheba, as the sand upon the sea in multitude. And your presence shall be going in the midst of them. 

#### 2 Samuel 17:12 And we shall come upon him in one of the places, which ever we should find him there. And we shall camp upon him as falls the dew upon the ground. And we shall not leave behind among to him, and of his men with him, even indeed one. 

#### 2 Samuel 17:13 And if {into the city he should gather}, then {shall take all Israel} {against that city lines}, and drag it apart unto the rushing stream, unto not leaving behind there neither a stone. 

#### 2 Samuel 17:14 And Absalom said, and every man of Israel, {is good The counsel of Hushai the Archite} over the counsel of Ahithophel. And the LORD gave charge to efface the {counsel of Ahithophel good}, so that the LORD should bring the bad things upon Absalom. 

#### 2 Samuel 17:15 And Hushai said to Zadok and to Abiathar the priests, So and so advised Ahithophel to Absalom, and to the elders of Israel, and so and so I advised. 

#### 2 Samuel 17:16 And now send quickly and report to David! saying, You should not lodge the night according to the descent of the wilderness, but by passing over, pass over! so that {should not be swallowed down the king}, and all the people, the one with him. 

#### 2 Samuel 17:17 And Jonathan and Ahimaaz stopped at the spring of Rogel. And came forth the maidservant, and she reported to them. And they went and reported to king David, for they were not able to appear to enter into the city. 

#### 2 Samuel 17:18 And {beheld them a young man}, and he reported to Absalom. And {went the two} quickly, and they entered into a house of a man in Bahurim, and unto his cistern in the courtyard, and they went down there. 

#### 2 Samuel 17:19 And {took a woman} and opened and spread out a covering over the mouth of the cistern. And she cooled {upon it dried clusters}, and they did not know the thing. 

#### 2 Samuel 17:20 And {came the servants of Absalom} to the woman, into the house, and they said, Where is Ahimaaz and Jonathan? And {said to them the woman}, They went for a little water. And they sought and did not find them, and they returned unto Jerusalem. 

#### 2 Samuel 17:21 And it came to pass, after their going forth, they ascended from out of the cistern, and went, and reported to king David. And they say to him, Rise up and pass over {quickly the water}! for thus {has counseled against you Ahithophel}. 

#### 2 Samuel 17:22 And David rose up, and all the people with him, and they passed over the Jordan until the light of the morning, until one was not unaware of who did not pass over the Jordan. 

#### 2 Samuel 17:23 And Ahithophel knew that he had not taken his counsel, and he saddled his donkey, and rose up, and went forth to his house in his city. And he gave charge to his household, and he hung himself, and died. And they entombed him in the burying-place of his father. 

#### 2 Samuel 17:24 And David went through unto Mahanaim. And Absalom passed over the Jordan, he and every man of Israel with him. 

#### 2 Samuel 17:25 And {Amasa placed Absalom} instead of Joab over the force. And Amasa was a son of a man, and the name to him was Ithra the Israelite. This one entered to Abigail, daughter of Nahash, sister of Zeruiah, mother of Joab. 

#### 2 Samuel 17:26 And Absalom camped and all Israel in the land of Gilead. 

#### 2 Samuel 17:27 And it came to pass when David entered into Mahanaim, that Shobi son of Nahash, from Rabbah of the sons of Ammon, and Machir son of Ammiel from Lo-debar, and Barzillai the Gileadite from Rogelim, 

#### 2 Samuel 17:28 brought beds, and spreads, and kettles, and {utensils ceramic}, and wheat, and barley, and flour, and beans, and lentils and toasted grain, 

#### 2 Samuel 17:29 and honey, and butter, and sheep, and cheese from oxen. And they brought near to David, and to the people with him to eat; for they said, The people are hungering, and fainting, and thirsting, in the wilderness. 

#### 2 Samuel 18:1 And David numbered all the people with him. And he placed over them commanders of thousands, and commanders of hundreds. 

#### 2 Samuel 18:2 And David sent away the people, a third under the hand of Joab, and another third under the hand of Abishai son of Zeruiah, brother of Joab, and other third under the hand of Ittai the Gittite. And {said the king} to the people, In going forth, I shall go forth even indeed I myself with you. 

#### 2 Samuel 18:3 And {said the people}, You shall not go forth; for if {into exile we should flee}, they shall not put us to heart. And if {should die half of us} they shall not put us to heart. For you are as of us ten thousand. And now it is good that you will be with us in the city for our helper. 

#### 2 Samuel 18:4 And {said to them the king}, The pleasing thing before you I will do. And {stood the king} by the side of the gate, and all the people went forth by hundreds and by thousands. 

#### 2 Samuel 18:5 And {gave charge the king} to Joab and to Abishai and to Ittai, saying, Spare for me the young man Absalom! And all the people heard {giving charge the king} to all the rulers concerning Absalom. 

#### 2 Samuel 18:6 And {went forth all the people} into the field for meeting Israel. And {happened the battle} in the grove of Ephraim. 

#### 2 Samuel 18:7 And {failed there the people of Israel} before the children of David. And there became {devastation a great} in that day -- twenty thousand men. 

#### 2 Samuel 18:8 And it came to pass there the war dispersed over the face of all the land. And {was superabundant the forest} in devouring of the people above what {devoured the sword} among the people in that day. 

#### 2 Samuel 18:9 And Absalom met before the servants of David. And Absalom was mounted upon the mule, and {was entering the mule} under the thicket of the {oak great}. And {was twisted his head} in the oak, and he hung between the heaven and between the earth, and the mule underneath him went on. 

#### 2 Samuel 18:10 And {saw it man one}, and announced to Joab. And said, Behold, I have seen Absalom hanging in the oak. 

#### 2 Samuel 18:11 And Joab said to the man announcing to him, And behold, you saw it? And why is it that you did not strike him there to the ground, and I would have given to you ten shekels of silver, and {sash one}? 

#### 2 Samuel 18:12 {said And the man} to Joab, And if you rendered unto my hands a thousand shekels of silver, in no way would I put my hand against the son of the king. For in our ears {gave charge the king} to you, and to Abishai, and to Ittai, saying, Guard for me the young man Absalom, 

#### 2 Samuel 18:13 to not do {against his life anything injust}! And all the matter will not be kept unaware from the king, and you shall set yourself right opposite me. 

#### 2 Samuel 18:14 And Joab said, This I begin; not thus shall I abide before you. And Joab took three arrows in his hand, and he stuck them in the heart of Absalom while yet he was living, in the heart of the oak. 

#### 2 Samuel 18:15 And there encircled ten young men lifting the weapons of Joab, and they struck Absalom, and killed him. 

#### 2 Samuel 18:16 And Joab trumped with the trumpet, and {returned the people} to not pursue after Israel, for Joab spared the people. 

#### 2 Samuel 18:17 And Joab took Absalom, and he tossed him into {chasm a great} in the grove, into the {pit great}, and they set over him a heap {stones great of exceedingly}. And all Israel fled each to his tent. 

#### 2 Samuel 18:18 And Absalom while still living took and set for himself a monument in the valley of the king. For he said, There is not to me a son calling to mind my name. And he called the monument by his name. And he named it Hand of Absalom, until this day. 

#### 2 Samuel 18:19 And Ahimaaz son of Zadok said, Running indeed, I will announce good news to the king, that {passed judgment to him the LORD} on the hand of his enemies. 

#### 2 Samuel 18:20 And {said to him Joab}, {not a man of good news are You} in this day, but you shall announce good news in {day another}. But in this day you shall not announce good news, for a son of the king has died. 

#### 2 Samuel 18:21 And Joab said to Cushi, Go, announce to the king what you have seen! And Cushi did obeisance to Joab, and he ran. 

#### 2 Samuel 18:22 And {added still Ahimaaz son of Zadok}, and he said to Joab, Also let it be that I run also indeed myself after Cushi! And Joab said, Why do you run, my young one? There is not {to you good news} for benefit in going. 

#### 2 Samuel 18:23 And Ahimaaz said, For what if I shall run? And {said to him Joab}, Run! And Ahimaaz ran by the way of Kechar, and he surpassed Cushi. 

#### 2 Samuel 18:24 And David was sitting between the two gates, and {went the watchman} onto the roof of the gate house, unto the wall; and he lifted his eyes and saw, and behold, there was a man running alone before him. 

#### 2 Samuel 18:25 And {yelled out the watchman}, and reported to the king. And {said the king}, If he is alone good news is in his mouth. And he went along, coming and approaching. 

#### 2 Samuel 18:26 And {saw the watchman man another} running. And {yelled out the watchman} at the gate, and said, Behold, {man another} is running alone. And {said the king}, Also this one {announcing good news is}. 

#### 2 Samuel 18:27 And {said the watchman}, I see the racing of the first as the racing of Ahimaaz son of Zadok. And {said the king}, {man a good This is}, and indeed for {news good} he shall come. 

#### 2 Samuel 18:28 And Ahimaaz yelled and said to the king, Peace. And he did obeisance to the king upon his face upon the ground. And he said, Blessed be the LORD your God, who shut up the men, the ones lifting their hand against my master the king. 

#### 2 Samuel 18:29 And {said the king}, Is there peace to the young man Absalom? And Ahimaaz said, I saw the {multitude great} being gladdened in the sending Joab the servant of the king, and your servant, and I do not know what happened there. 

#### 2 Samuel 18:30 And {said the king}, Turn aside and stand by here! And he turned aside and stood. 

#### 2 Samuel 18:31 And behold, Cushi came. And Cushi said to the king, Let there be good news announced, O my master the king! for {passed judgment for you the LORD} today of the hand of all the ones rousing against you. 

#### 2 Samuel 18:32 And {said the king} to Cushi, How is the peace to the young man Absalom? And Cushi said, Let be as that young man, the enemies of my master the king! and all as many as rise up against you for evils. 

#### 2 Samuel 18:33 And {was disturbed the king}, and he ascended into the upper room of the gate and wept. And so he said as he wept, O My son, Absalom. O my son!, O my son, Absalom. What that I couldn't give my death for you, I instead of you, Absalom, O my son! O my son. 

#### 2 Samuel 19:1 And it was announced to Joab, saying, Behold, the king weeps and mourns over Absalom. 

#### 2 Samuel 19:2 And {became the deliverance in that day} for mourning to all the people. For {heard the people} in that day, saying that, {frets The king} for his son. 

#### 2 Samuel 19:3 And {stole away the people} in that day to enter into the city, as {steal away people} being shamed in their fleeing in the battle. 

#### 2 Samuel 19:4 And the king hid his face, and {cried out the king voice with a great}, saying, O my son, Absalom. Absalom, O my son. 

#### 2 Samuel 19:5 And Joab entered to the king into the house, and said, You disgraced today the faces of all your servants, of the ones delivering your life today, and the life of your sons, and of your daughters, and the life of your wives, and the life of your concubines, 

#### 2 Samuel 19:6 to love the ones detesting you, and to detest the ones loving you, that you identify today that {are nothing to you your rulers}, nor your servants. For I know that Absalom, if he were alive today, and even all we had died, that then it would have been pleasing before you. 

#### 2 Samuel 19:7 And now arise! go forth and speak unto the heart of your servants! for by the LORD I swear by an oath, that unless you should go forth, in no way should {remain a man} with you this night. And realize this in yourself! that {evil will be upon you this} over all the evil coming upon you from your youth until now. 

#### 2 Samuel 19:8 And {rose up the king}, and he sat at the gate. And all the people announced, saying, Behold, the king sits down at the gate. And {came all the people} before the king. And Israel fled, each to his tent. 

#### 2 Samuel 19:9 And {were all the people} arguing among all the tribes of Israel, saying, King David rescued us from the hand of all our enemies, and he delivered us from the hand of the Philistines. And now he fled from the land. 

#### 2 Samuel 19:10 And Absalom, whom we anointed over us, died in the war. And now, why are you silent to return the king? And the saying by all Israel came to the king. 

#### 2 Samuel 19:11 And king David sent to Zadok and to Abiathar the priests, saying, Speak to the elders of Judah! saying, Why have you become last to return the king to his house? And the word of all Israel came to the king. 

#### 2 Samuel 19:12 {brethren my You are}, of my bones and of my flesh. Why have you become for the last ones to return the king to his house? 

#### 2 Samuel 19:13 And to Amasa you shall say, Are {not of my bone and of my flesh you}? And now, thus may {do to me God}, and thus add more, if {not ruler of the force you shall be} before me all the days instead of Joab. 

#### 2 Samuel 19:14 And he leaned the heart of every man of Judah, as {man one}. And they sent to the king, saying, You return, and all your servants! 

#### 2 Samuel 19:15 And {returned the king}, and came unto the Jordan. And the men of Judah came to Gilgal to go to meet the king, to cause {to pass over the king} the Jordan. 

#### 2 Samuel 19:16 And {hastened Shimei son of Gera son of the Benjaminite from Bahurim}, and he went down with the men of Judah to meet king David. 

#### 2 Samuel 19:17 And there were a thousand men with him from Benjamin, and Ziba the servant of the house of Saul, and {fifteen sons his}, and {twenty servants his} with him. And they went straight unto the Jordan before the king. 

#### 2 Samuel 19:18 And he passed over the ford to arouse the household of the king, and to do the upright thing in his eyes. And Shimei son of Gera fell upon his face before the king, at his passing over the Jordan. 

#### 2 Samuel 19:19 And he said to the king, Let not indeed {consider my master} my lawlessness! and remember not as much as {did wrong your servant} in the day which {went forth my master the king} from Jerusalem, {to put it for the king} upon his heart! 

#### 2 Samuel 19:20 For {knows your servant} that I have sinned. And behold, I have come today first of all of the house of Joseph to go down myself for the meeting of my master the king. 

#### 2 Samuel 19:21 And {answered Abishai son of Zeruiah} and said, For this should not {be put to death Shimei}, for he cursed the anointed one of the LORD? 

#### 2 Samuel 19:22 And David said, What is it to me and to you, sons of Zeruiah, that you become to me today to plot? Shall today {be put to death any man of Israel}, no. I do not know that today I shall reign over Israel. 

#### 2 Samuel 19:23 And {said the king} to Shimei, You shall not die. And {swore by an oath to him the king}. 

#### 2 Samuel 19:24 And Mephibosheth son of Jonathan, son of Saul went down for a meeting with the king, and attended not to his feet, nor prepared his mustache, and his garments he did not wash from the day which {went forth the king} until the day which he came in peace. 

#### 2 Samuel 19:25 And it came to pass when he entered into Jerusalem for a meeting with the king, that {said to him the king}, Why is it that you did not go with me, Mephibosheth? 

#### 2 Samuel 19:26 And {said to him Mephibosheth}, O my master, O king, my servant misled me, for {said your servant} to him, Saddle for me the donkey, for I should mount upon it and go with the king, for {is lame your servant}. 

#### 2 Samuel 19:27 And he used craft with your servant against my master the king. But my master the king is as a messenger of God, and you do what is good in your eyes! 

#### 2 Samuel 19:28 For there was not any to the house of my father, but only men for death to my master the king. And you put your servant to eat at your table. And what {is there to me still reason}, even to cry out still to the king? 

#### 2 Samuel 19:29 And {said to him the king}, Why do you still speak your words? I said, You and Ziba divide the field! 

#### 2 Samuel 19:30 And Mephibosheth said to the king, And {all the things let him take} after the coming of my master the king in peace to his house. 

#### 2 Samuel 19:31 And Barzillai the Gileadite came down from Rogelim, and passed over {with the king the Jordan}, to send him forward from the Jordan. 

#### 2 Samuel 19:32 And Barzillai was {old man an exceedingly}, a son of eighty years, and he nourished the king during his living in Mahanaim, for {man great he was a very}. 

#### 2 Samuel 19:33 And {said the king} to Barzillai, You shall pass over with me, and I will nourish your old age with me in Jerusalem. 

#### 2 Samuel 19:34 And Barzillai said to the king, How many are the days of years of my life that I should ascend with the king unto Jerusalem? 

#### 2 Samuel 19:35 {a son of eighty years I am today}. Can I know between good and between bad? Shall {still taste servant your} what I shall eat or shall drink, no. Shall I hear still the voice of singing men and singing women, no. Then why {be should your servant} a load upon my master the king? 

#### 2 Samuel 19:36 For {a little shall pass over your servant the Jordan} with the king. And why does my master the king recompense to me this recompense? 

#### 2 Samuel 19:37 Return indeed your servant! and I shall die in my city, by the burying-place of my father and of my mother. And behold, your servant Chimham my son shall pass over with my master the king; and you shall do for him the pleasing thing before you. 

#### 2 Samuel 19:38 And {said the king}, {with me Let pass over Chimham}, and I will do to him the pleasing thing before you, and what ever you should give order to me I will do for you. 

#### 2 Samuel 19:39 And {passed over all the people} the Jordan, and the king was established, and {kissed the king} Barzillai, and blessed him; and he returned to his people. 

#### 2 Samuel 19:40 And {passed over the king} into Gilgal, and Chimham passed over with him. And all the people of Judah caused him to pass over, and half of the people of Israel. 

#### 2 Samuel 19:41 And behold, every man of Israel came to the king. And they said to the king, Why is it that {stole you our brethren the men of Judah}, and caused {to pass over the king and his household} the Jordan, and all the men of David with him? 

#### 2 Samuel 19:42 And {answered the men of Judah} to the men of Israel, and said, Because {is a near relative to us the king}. And why is this you are enraged on account of this matter? Or in eating have we eaten any food from the king, or a gift given to us? 

#### 2 Samuel 19:43 And {answered the men of Israel} to the men of Judah, and said, There are ten hands to me for the king, also indeed in David I am over you. And why is it that you insult me, and it was not my word first to return the king to me? And {was hardened the saying of the men of Judah} above the saying of the men of Israel. 

#### 2 Samuel 20:1 And {there was encountered a man}, {son a mischievous}, and his name was Sheba son of Bichri, a man of Benjamin. And he trumped the trumpet, and said, There is not to us a portion among David, nor an inheritance in the son of Jesse. Each man to his tents, O Israel. 

#### 2 Samuel 20:2 And ascended every man of Israel from behind David to follow after Sheba son of Bichri. But the men of Judah cleaved to their king from the Jordan and unto Jerusalem. 

#### 2 Samuel 20:3 And David entered unto his house in Jerusalem, and {took the king} the ten women of his concubines, whom he left behind to guard the house; and he gave them for house guard, and he nourished them, but {to them he did not enter}. And they were held until the days of their death {as widows living}. 

#### 2 Samuel 20:4 And {said the king} to Amasa, Call to me men of Judah in three days, but you {here stand}! 

#### 2 Samuel 20:5 And Amasa went to summon Judah, and he passed time beyond the time which {ordered him David}. 

#### 2 Samuel 20:6 And David said to Abishai, Now {shall do us evil Sheba son of Bichri} above Absalom. And now take with yourself the servants of your master, and pursue after him! so that he should not find for himself {cities fortified}, and he should shadow our eyes. 

#### 2 Samuel 20:7 And {went forth after him the men of Joab}, and the Cherethites, and the Pelethites, and all the mighty ones. And they went forth from Jerusalem, to pursue after Sheba son of Bichri. 

#### 2 Samuel 20:8 And they were by the {stone great} in Gibeon. And Amasa entered in front of them. And Joab being girded {uniform garment with his}, and upon him {being tied around was a sword} being teamed up on his loin in its sheath. And the sword came forth and fell. 

#### 2 Samuel 20:9 And Joab said to Amasa, Are you in health, my brother? And {constrained the hand right of Joab} the beard of Amasa to kiss him. 

#### 2 Samuel 20:10 And Amasa did not guard from the sword, of the one in the hand of Joab. And {hit him with it Joab} in his flank, and {poured out belly his} upon the ground, and it was not repeated a second time to him, and he died. And Joab and Abishai his brother pursued after Sheba son of Bichri. 

#### 2 Samuel 20:11 And a man stood by him, one of the servants of Joab. And he said, Who is the one wanting Joab, and who is the one wanting David? Be behind Joab. 

#### 2 Samuel 20:12 And Amasa having died, and being befouled in the blood, was in the middle of the road. And {beheld a man} that {stood all the people}. And he returned Amasa from the road to the field, and cast upon him a cloak, for he beheld that every one coming stopped by him. 

#### 2 Samuel 20:13 And it came to pass when he removed him from out of the road, {went by all the people of Israel} after Joab, to pursue after Sheba son of Bichri. 

#### 2 Samuel 20:14 And he went through among all the tribes of Israel, to Abel and Beth-maacah. And they were assembled, and they came after him. 

#### 2 Samuel 20:15 And they came and assaulted against him in Abel and Beth-maacah. And they cast a seige mound against the city, and it stood in the area around the wall. And all the people with Joab purposed to throw down the wall. 

#### 2 Samuel 20:16 And {yelled out woman a wise} from the city, and said, Hearken indeed! hearken! Say indeed to Joab, Approach unto here! and I will speak to him. 

#### 2 Samuel 20:17 And he drew near to her. And {said the woman}, Are you Joab? And he said, I am. And she said to him, Hear the words of your maidservant! And he said, {listening I am}. 

#### 2 Samuel 20:18 And she said, saying, {a word They spoke} at first, saying, By asking they shall ask in Abel; and thus they ceased. 

#### 2 Samuel 20:19 I am peaceable of ones supporting Israel. But you seek to kill a city, even a mother-city in Israel. Why do you swallow down the inheritance of the LORD? 

#### 2 Samuel 20:20 And Joab answered and said, May it not be to me to swallow it, and shall I utterly destroy it? 

#### 2 Samuel 20:21 {is not so The word}. For a man from mount Ephraim, Sheba son of Bichri is his name, lifted up his hand against king David. Give him to me only, and I shall go forth from the city. And {said the woman} to Joab, Behold, {his head I will toss} to you over the wall. 

#### 2 Samuel 20:22 And {went in the woman} to all the people, and she spoke to all the city in her wisdom. And they removed the head of Sheba son of Bichri, and they tossed it to Joab. And he trumped with the horn, and they scattered from the city, each man to his tents. And Joab returned to Jerusalem to the king. 

#### 2 Samuel 20:23 And Joab was over all the force of Israel. And Benaiah son of Jehoiada was over the Cherethites and over the Pelethites. 

#### 2 Samuel 20:24 And Adoram was over the tribute. And Jehoshaphat son of Ahilud was recording. 

#### 2 Samuel 20:25 And Sheva was scribe, And Zadok and Abiathar were priests. 

#### 2 Samuel 20:26 And indeed Ira the Jarite was priest to David. 

#### 2 Samuel 21:1 And there was a famine in the days of David for three years, year next to year. And David sought the face of the LORD. And the LORD said, Against Saul and against his house is the iniquity, in the death of his blood shed, for which he put to death the Gibeonites. 

#### 2 Samuel 21:2 And {called the king} the Gibeonites, and he spoke to them. And the Gibeonites were not of the sons of Israel, for {of the remnants of the Amorites they were}, and the sons of Israel swore an oath to them. But Saul sought to strike them in his zeal for the sons of Israel and Judah. 

#### 2 Samuel 21:3 And David said to the Gibeonites, What shall I do for you? And by what means shall I atone, and you shall bless the inheritance of the LORD? 

#### 2 Samuel 21:4 And {said to him the Gibeonites}, There is not a problem with us over silver nor gold with Saul, and with his house; and there is no man for us to put to death from all Israel. 

#### 2 Samuel 21:5 And he said, What you say even I will do for you. And they said to the king, The man who finished us off entirely, and pursued us, who misled to utterly destroy us, we shall remove him, so that {is not established he} in any border of Israel. 

#### 2 Samuel 21:6 Give to us seven men from his sons, and we will hang them in the sun to the LORD in Gibeah of Saul, chosen of the LORD. And {said the king}, I will give them. 

#### 2 Samuel 21:7 And {spared the king} for Mephibosheth, son of Jonathan, son of Saul, on account of the oath of the LORD between them; even between David and between Jonathan the son of Saul. 

#### 2 Samuel 21:8 And {took the king} the two sons of Rizpah daughter of Aiah, whom she bore to Saul -- Armoni and Mephibosheth, and the five sons of Michal daughter of Saul, whom she bore to Adriel son of Barzillai the Meholahite. 

#### 2 Samuel 21:9 And he gave them into the hand of the Gibeonites. And they hung them in the sun in the mountain before the LORD. And they fell there the seven together. And they were put to death in days of harvest at first, at the beginning {harvest of the barley}. 

#### 2 Samuel 21:10 And {took Rizpah daughter of Aiah} sackcloth, and she strew a bed for herself upon the rock from the beginning {harvest of the barley} until of which time {dripped upon them waters} from God from heaven. And she did not allow the birds of the heaven to rest upon them by day, nor the wild beasts of the field by night. 

#### 2 Samuel 21:11 And it was reported to David all as much as {did Rizpah daughter of Aiah concubine of Saul}. 

#### 2 Samuel 21:12 And David went and took the bones of Saul, and the bones of Jonathan his son from the men of Jabish Gilead, of the ones stealing them from the square of Beth-shan, {hanging them there of the Philistines} in the day in which {struck the Philistines} Saul in Gilboa. 

#### 2 Samuel 21:13 And he bore from there the bones of Saul, and the bones of Jonathan his son, and he gathered the bones of the ones hanging in the sun. 

#### 2 Samuel 21:14 And he entombed the bones of Saul, and of Jonathan his son, and the bones of the ones being expose to the sun, in the land of Benjamin, in the side of the hill, in the tomb of Kish his father. And they did all as much as {gave charge the king}. And God heeded to the land after these things. 

#### 2 Samuel 21:15 And there was still war against the Philistines with Israel. And David went down and his servants with him, and they waged war with the Philistines; and David grew faint. 

#### 2 Samuel 21:16 And Ishbi of Nob, who was among the progeny of Rapha, and the weight of his spear was three hundred shekels scale-weight of brass, and he being girded with a truncheon, even considered to strike David. 

#### 2 Samuel 21:17 And {helped him Abishai son of Zeruiah}, and he struck the Philistine and killed him. Then {swore by an oath the men of David}, saying, You shall not come forth still with us into battle, that in no way {should be extinguished the lamp of Israel}. 

#### 2 Samuel 21:18 And it came to pass after these things war was still with the Philistines in Nob. Then {struck Sibbechai the Hushathite} the ones assembling of the descendants of the giants. 

#### 2 Samuel 21:19 And there was still war with the Philistines in Nob. And {struck Elhanan son of Jaareoregim the Beth-lehemite} Goliath the Gittite, and the wood of his spear was as the beam of a loom of one weaving. 

#### 2 Samuel 21:20 And there was still war in Gath. And there was a man of Madon, and the fingers of his hands, and the toes of his feet were six and six, twenty-four in number; and indeed he was born to Rapha. 

#### 2 Samuel 21:21 And he berated Israel, and {struck him Jonathan son of Shimea brother of David}. 

#### 2 Samuel 21:22 These four were born to descendants of the giants in Gath, to the {of Rapha house}. And they fell by the hand of David, and by the hand of his servants. 

#### 2 Samuel 22:1 And David spoke to the LORD the words of this ode in the day which {rescued him the LORD} from the hand of all his enemies, and from out of the hand of Saul. 

#### 2 Samuel 22:2 And he said, The LORD my rock, and my fortress, and the one rescuing me. 

#### 2 Samuel 22:3 My God, my guard, I will be yielded upon him; my defender and horn of my deliverance; my shielder and my refuge; my deliverance from the unjust; you shall deliver me. 

#### 2 Samuel 22:4 Praiseworthy, I shall call upon the LORD, and from my enemies I shall be delivered. 

#### 2 Samuel 22:5 For {compassed me conflicts of death}, and the rushing streams of lawlessness made me distraught. 

#### 2 Samuel 22:6 Cords of Hades encircled me, and {anticipated me shackles of death}. 

#### 2 Samuel 22:7 In my affliction I shall call upon the LORD, and to my God I will yell. And he heard {from out of his temple my voice}, and my cry in his ears. 

#### 2 Samuel 22:8 And {was shaken and disturbed the earth}; even the foundations of the heaven were disturbed and thrown into a spasm, for the LORD was enraged with them. 

#### 2 Samuel 22:9 There ascended smoke in his wrath, and fire from out of his mouth devoured; coals were kindled by it. 

#### 2 Samuel 22:10 And he leaned the heavens, and came down; and dimness was under his feet. 

#### 2 Samuel 22:11 And he mounted upon cherubim, and was spread out, and was seen upon the wings of the winds. 

#### 2 Samuel 22:12 And he placed darkness for his concealment. Round about him his tent was darkness of waters; thickened in clouds of air. 

#### 2 Samuel 22:13 From the brightness before him {were kindled coals of fire}. 

#### 2 Samuel 22:14 {thundered from out of heaven The LORD}, and the highest gave out his voice. 

#### 2 Samuel 22:15 And he sent arrows, and he dispersed them; and he flashed lightning, and he startled them. 

#### 2 Samuel 22:16 And {were seen the releases of the sea}, and {were uncovered the foundations of the inhabitable world} at the reproach of the LORD, by the breath of spirit of his rage. 

#### 2 Samuel 22:17 He sent from the height, and took me; he drew me out of {waters many}. 

#### 2 Samuel 22:18 He delivered me from the strength of my enemies, from the ones detesting me; for they were strong above me. 

#### 2 Samuel 22:19 They anticipated me in a day of my affliction, and the LORD became my stay. 

#### 2 Samuel 22:20 And he led me into an enlargement, and rescued me, for he thought to do well by me. 

#### 2 Samuel 22:21 And {recompensed unto me the LORD} according to my righteousness. And according to the cleanliness of my hands he shall make recompense to me. 

#### 2 Samuel 22:22 For I guarded the ways of the LORD, and was not impious before my God. 

#### 2 Samuel 22:23 For all his judgments were in front of me, and his ordinances did not depart from me. 

#### 2 Samuel 22:24 And I will be unblemished to him, and I shall keep guard from my lawlessness. 

#### 2 Samuel 22:25 And {shall recompense to me the LORD} according to my righteousness, and according to the cleanliness of my hands before his eyes. 

#### 2 Samuel 22:26 With the sacred you shall be sacred, and with the innocent you shall be innocent, 

#### 2 Samuel 22:27 and with the chosen you shall be chosen; and with the crooked you shall be crooked. 

#### 2 Samuel 22:28 And the {people poor} you shall preserve, and the eyes of the proud you shall humble. 

#### 2 Samuel 22:29 For you shall light my lamp, O LORD; and the LORD shall shine forth in my darkness. 

#### 2 Samuel 22:30 For in you I shall run lightly armed, and by my God I shall leap over a wall. 

#### 2 Samuel 22:31 God -- unblemished is his way. The saying of the LORD is tried in the fire. He is a defender to all the ones yielding upon him. 

#### 2 Samuel 22:32 For who is God besides the LORD? And who is creator besides our God? 

#### 2 Samuel 22:33 God -- the one strengthening me, is power; and he established {as unblemished my way}; 

#### 2 Samuel 22:34 setting my feet as a stag, and standing me upon the heights; 

#### 2 Samuel 22:35 teaching my hands for war, and breaking the bow of brass by my arms. 

#### 2 Samuel 22:36 And you gave to me a shield of my deliverance, and obedience of you multiplied me. 

#### 2 Samuel 22:37 And you widened my footsteps underneath me, and {did not shake my legs}. 

#### 2 Samuel 22:38 I will pursue my enemies, and I will remove them. And I shall not return until of which time I shall finish them off. 

#### 2 Samuel 22:39 And I will crush them, and they shall not rise up; and they shall fall under my feet. 

#### 2 Samuel 22:40 And you shall gird on me power for war. You shall bend the ones rising up against me, underneath me. 

#### 2 Samuel 22:41 And {my enemies you gave} to me; {the back of the neck of ones detesting me I trampled}. 

#### 2 Samuel 22:42 They yelled out, and there was not one delivering; to the LORD, and he did not take heed of them. 

#### 2 Samuel 22:43 And I ground them as dust of the earth; {as the mud of the streets I made them fine}. 

#### 2 Samuel 22:44 And you rescued me from disputes of people; you shall guard me as head of nations. A people whom not knowing, served to me. 

#### 2 Samuel 22:45 With a hearing ear it obeyed me. {sons Alien} lied to me; 

#### 2 Samuel 22:46 {sons alien} shall reel -- and they shall trip from their confinement. 

#### 2 Samuel 22:47 As the LORD lives -- for blessed be the one shaping me, and {shall be raised up high my God} -- my deliverer. 

#### 2 Samuel 22:48 The LORD is strong, the one giving acts of vengeance to me, and humbling peoples underneath me. 

#### 2 Samuel 22:49 And he led me from my enemies. And from the ones rousing up against me, you shall raise me up high. {from men of offences You shall rescue me}. 

#### 2 Samuel 22:50 On account of this I will make acknowledgement to you, O LORD, among the nations. And {to your name I will strum}, 

#### 2 Samuel 22:51 O one magnifying the deliverance of his king, and doing mercy to his anointed one, to David and to his seed unto the eon. 

#### 2 Samuel 23:1 And these are the {words of David last}. Trustworthy David, son of Jesse, and a trustworthy man whom God raised up -- anointed one of the God of Jacob, and for beauty is the psalm of Israel. 

#### 2 Samuel 23:2 Spirit of the LORD spoke by me, and his word was upon my tongue. 

#### 2 Samuel 23:3 {spoke The God of Israel} to me; {spoke the guardian of Israel}, {ruling among men justice}, the prince in fear of God. 

#### 2 Samuel 23:4 And as {light the early morning}, {arises the sun} in the morning, and it shall not darken; from brightness and from out of rain as pasturage of the earth. 

#### 2 Samuel 23:5 For is not thus my house with God? for {covenant an eternal he established} with me, to deliver me, prepared at all time being guarded. For all my deliverance, and all my will is in the LORD, for in no way shall {grow the lawbreaker}; 

#### 2 Samuel 23:6 as a thorn-bush being pushing out are all these; for no hand shall take them. 

#### 2 Samuel 23:7 And a man who shall labor among them, full of iron and wooden spear, and in fire burning, they shall be burnt in their shame. 

#### 2 Samuel 23:8 These are the names of the mighty ones of David. Joshabbasshebeth the Tachmonite -- {first of the three this one is}. Adino the Eznite -- this one unsheathed his broadsword against eight hundred slain at once. 

#### 2 Samuel 23:9 And with him is Eleazar son of Dodo, son of his uncle among the three mighty ones, this one was with David in his berating among the Philistines. And the Philistines gathered together there for war. And {ascended the men of Israel} before their face, 

#### 2 Samuel 23:10 and he rose up and struck the Philistines, until of which {tired his hand}, and {was cleaved his hand} upon the sword. And the LORD made {deliverance a great} in that day. And the people returned after for despoiling. 

#### 2 Samuel 23:11 And after him Shammah son of Agee the Hararite. And {gathered together the Philistines} in Theria, and there was there a portion of a field full of lentils. And the people fled from the face of the Philistines. 

#### 2 Samuel 23:12 And he stood in the midst of the portion, and rescued it, and struck the Philistines. And the LORD executed {deliverance a great}. 

#### 2 Samuel 23:13 And {went down three from the thirty rulers}, and they entered unto David into the cave of Adullam. And the battle order of the Philistines camped in the valley of Rephaim. 

#### 2 Samuel 23:14 And David was then in the citadel, and the garrison of the Philistines was then in Beth-lehem. 

#### 2 Samuel 23:15 And David desired, and said, Who will give {to drink me water} from the well, the one in Beth-lehem, of the one at the gate? 

#### 2 Samuel 23:16 And {tore up the three mighty ones} the camp of the Philistines, and they drew water from the well, of the one in Beth-lehem, of the one by the gate. And they took of it, and came to David. And he did not want to drink it, and he offered it a libation to the LORD. 

#### 2 Samuel 23:17 And he said, Kindness be to me, O LORD, to do this. Shall {the blood of the men going with their lives I drink}, no. And he did not want to drink it. These things {did the three mighty ones}. 

#### 2 Samuel 23:18 And Abishai the brother of Joab, son of Zeruiah, was foremost of the three. And he awakened his spear upon three hundred slain, and to him was a name among the three. 

#### 2 Samuel 23:19 Of the three he was honored, and was to them for ruler, and unto the first three he did not arrive at. 

#### 2 Samuel 23:20 And Benaiah son of Jehoiada, son {man of a mighty}, with great works from Kabzeel. This one struck the two sons of Ariel of Moab. And he went down and struck the lion in the midst of the pit in {day a snowy}. 

#### 2 Samuel 23:21 And he struck the Egyptian man, {man a remarkable}; and in the hand of the Egyptian was a spear. And he went down to him with a rod, and seized by force the wooden spear from out of the hand of the Egyptian, and killed him with his spear. 

#### 2 Samuel 23:22 These things {did Benaiah son of Jehoiada}, and to him was a name among the three mighty ones. 

#### 2 Samuel 23:23 He was over the thirty honorable ones, but to the first three he did not arrive at. And {ordered him David} for his reports. And these are the names of the mighty ones of David the king. 

#### 2 Samuel 23:24 Asahel brother of Joab among the thirty. Elhanan son of Dodo his uncle in Beth-lehem. 

#### 2 Samuel 23:25 Shammah the Harodite. Elika the Harodite. 

#### 2 Samuel 23:26 Helez the Paltite. Ira son of Ikkesh the Tekoite. 

#### 2 Samuel 23:27 Abiezer the Anathothite. Mebunnai the Hushathite. 

#### 2 Samuel 23:28 Zalmon the Ahohite. Maharai the Netophathite. 

#### 2 Samuel 23:29 Heleb son of Baanah the Netophathite. Ittai son Ribai the one of the hill of Benjamin. 

#### 2 Samuel 23:30 Benaiah the Pirathonite. Hiddai from out of Naxali-Gaash. 

#### 2 Samuel 23:31 Abi-albon the Arbathite. Azmaveth the Barhumite. 

#### 2 Samuel 23:32 Eliahba the Shaalbonite. Sons of Jashen, Jonathan, 

#### 2 Samuel 23:33 Shammah the Hararite. Ahiam son of Sharar the Hararite. 

#### 2 Samuel 23:34 Eliphelet son of Ahasbai, son of the Maachathite. Eliam son of Ahithophel the Gilonite. 

#### 2 Samuel 23:35 Hezrai the Carmelite. Paarai the Arbite. 

#### 2 Samuel 23:36 Igal son of Nathan of Zobah. Bani the Gadite. 

#### 2 Samuel 23:37 Zelek the Ammonite. Nahari the Beerothite, the one lifting the equipment of Joab son of Zeruiah. 

#### 2 Samuel 23:38 Ira the Ithrite. Gareb the Ithrite. 

#### 2 Samuel 23:39 Uriah the Hittite. In all thirty and seven. 

#### 2 Samuel 24:1 And {proceeded in anger the LORD} to burn in Israel. And he stirred up David against them, saying, Go count Israel and Judah! 

#### 2 Samuel 24:2 And {said the king} to Joab, ruler of the forces of the ones with him, Go around indeed all the tribes of Israel and Judah, from Dan and unto Beer-sheba, and number the people! and I shall know the number of the people. 

#### 2 Samuel 24:3 And Joab said to the king, And may {add the LORD your God} to your people, as even these a hundred foldly, and the eyes of my master the king seeing it -- but my master the king, why do you want to do this matter? 

#### 2 Samuel 24:4 And {excelled the word of the king} against Joab, and the rulers of the force. And Joab went forth, and the rulers of the force before the king to number the people of Israel. 

#### 2 Samuel 24:5 And they passed over the Jordan, and they camped in Aroer at the right of the city of the one in the midst of the ravine of Gad and Eleizer. 

#### 2 Samuel 24:6 And they came into Gilead, and into the land Tahtim Hodshi; and they came into Dan, and encircled to Sidon, 

#### 2 Samuel 24:7 and they came into Mapsar of Tyre, and to all the cities of the Hivite, and the Canaanite. And they went out unto the south of Judah into Beer-sheba. 

#### 2 Samuel 24:8 And they traveled about in all the land, and came at the end of nine months and twenty days into Jerusalem. 

#### 2 Samuel 24:9 And Joab gave the number of the numbering of the people to the king. And there was to Israel eight hundred thousand men of the force unsheathing the broadsword. And men of Judah -- five hundred thousand men warriors. 

#### 2 Samuel 24:10 And {struck the heart of David} him after counting the people. And David said to the LORD, I have sinned exceedingly -- I having done this thing. And now, O LORD, remove indeed the iniquity of your servant, for I was in folly exceedingly. 

#### 2 Samuel 24:11 And David rose up in the morning, and the word of the LORD came to Gad the prophet, the one seeing for David, saying, 

#### 2 Samuel 24:12 Go and speak to David! saying, Thus says the LORD, Three things I lift unto you; you choose for yourself one of them! and I will execute against you. 

#### 2 Samuel 24:13 And Gad went to David, and he announced, and he said to him, Choose for yourself what is to be to you! Three years of famine in your land, or three months for you to flee before your enemies, and they will be pursuing you, or {to be three days of plague} in your land. Now then, know and perceive! what I shall answer to the one sending me. 

#### 2 Samuel 24:14 And David said to Gad, {narrow choice to me an exceedingly It is} -- the three things. I shall fall into the hands of the LORD, for {great his compassions are exceedingly}, but into the hands of men in no way shall I fall. 

#### 2 Samuel 24:15 And {chose for himself David} plague. And the LORD appointed plague in Israel from morning and unto the hour of dinner. And there died from out of the people from Dan and unto Beer-sheba seventy thousand men. 

#### 2 Samuel 24:16 And {stretched out the angel} his hand to Jerusalem, to utterly destroy it. And the LORD relented over the evil, and said to the angel destroying among the people, Enough now, spare your hand! And the angel of the LORD was by the threshing-floor of Araunah the Jebusite. 

#### 2 Samuel 24:17 And David spoke to the LORD in his beholding the angel striking among the people, and he said, Behold, I sinned, and I the shepherd did evil, and these are the sheep, what did they do? Let {come indeed your hand} against me, and against the house of my father! 

#### 2 Samuel 24:18 And Gad came to David in that day, and said to him, Ascend, and set up an altar to the LORD in the threshing-floor of Araunah the Jebusite! 

#### 2 Samuel 24:19 And David ascended according to the word of Gad the prophet, in which manner {gave charge to him the LORD}. 

#### 2 Samuel 24:20 And Araunah looked, and he beheld the king, and his servants coming near unto him. And Araunah went forth, and did obeisance to the king upon his face upon the ground. 

#### 2 Samuel 24:21 And Araunah said, For what reason comes my master the king to his servant? And David said, To acquire from you the threshing-floor, to build an altar to the LORD, so that {should be constrained the devastation upon the people}. 

#### 2 Samuel 24:22 And Araunah said to David, Take it and offer, O my master the king, to the LORD what is good in your eyes! Behold, the oxen are for a whole burnt-offering, and the wheels, and the items of the oxen are for wood. 

#### 2 Samuel 24:23 The whole amount Araunah gave to the king. And Araunah said to the king, The LORD your God, may he bless you. 

#### 2 Samuel 24:24 And {said the king} to Araunah, Not so, but only by acquiring shall I acquire it from you for a price, for I shall not offer to the LORD my God a whole burnt-offering without paying a charge. And David acquired the threshing-floor, and the oxen with {silver shekels fifty}. 

#### 2 Samuel 24:25 And {built there David} an altar to the LORD, and he offered whole burnt-offerings, and peace offerings. And the LORD heeded the land, and held up the devastation on top of Israel.