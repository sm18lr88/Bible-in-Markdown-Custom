#### 2 Kings 1:1 And Moab annulled allegiance with Israel after the dying of Ahab. 

#### 2 Kings 1:2 And Ahaziah fell through the lattice in his upper room, in Samaria, and was infirm. And he sent for messengers, and he said to them, Go and ask of Baal the fly god of Ekron if I shall live through {infirmity my this}! And they went to ask. 

#### 2 Kings 1:3 And an angel of the LORD spoke to Elijah the Tishbite, saying, Rise up, go to meet the messengers of Ahaziah king of Samaria! and say to them, Is it on account of the not being a God in Israel you go to ask of Baal the fly god of Ekron? 

#### 2 Kings 1:4 On account of this thus says the LORD, The bed upon which you ascended upon it, you shall not go from it, for to death you shall die. And Elijah went, and spoke to them. 

#### 2 Kings 1:5 And {returned the messengers} to him. And he said to them, Why is it that you have returned? 

#### 2 Kings 1:6 And they said to him, A man ascended to meet us, and he said to us, Go, return to the king, the one sending you, and say to him! Thus says the LORD, Is it because there is no God in Israel you go to seek anxiously by Baal the fly god of Ekron? On account of this, the bed upon which you ascended upon it, you shall not go from it, for to death you shall die. 

#### 2 Kings 1:7 And {said to them the king}, What was the distinguishing mark of the man ascending to meet you, and speaking to you these words? 

#### 2 Kings 1:8 And they said to him, {man He was a hairy}, and a belt made of skin was girded upon his loin. And he said, {Elijah the Tishbite This is}. 

#### 2 Kings 1:9 And he sent to him a commander of fifty, and his fifty. And he ascended to him. And he sat upon the top of the mountain. And {spoke the commander of fifty} to him, O man of God, the king calls you, come down! 

#### 2 Kings 1:10 And Elijah answered and said to the commander of fifty, And if {a man of God I am}, {shall come down fire} from heaven and shall devour you and your fifty. And there came down fire from heaven, and devoured him and his fifty. 

#### 2 Kings 1:11 And {proceeded the king}, and he sent to him another commander of fifty, and his fifty. And {ascended the commander of fifty} and spoke to him, and said, O man of God, thus says the king, Quickly come down! 

#### 2 Kings 1:12 And Elijah answered and said to him, If {a man of God I am}, {shall come down fire} from heaven, and shall devour you and your fifty. And there came down fire from heaven and devoured him and his fifty. 

#### 2 Kings 1:13 And {proceeded the king} again to send {commander of fifty a third} and his fifty. And {came the commander of fifty third}, and he bent upon his knees in front of Elijah, and beseeched him, and spoke to him, and said, O man of God, value indeed my life, and the lives of your servants -- these fifty, in your eyes! 

#### 2 Kings 1:14 Behold, there came down fire from the heaven, and devoured the {two commanders of fifties first} and their fifties. And now value indeed the life of your servants in your eyes! 

#### 2 Kings 1:15 And {said the angel of the LORD} to Elijah, Go down with him, you should not fear from their presence. And Elijah rose up and went down with them to the king. 

#### 2 Kings 1:16 And he said to him, Thus says the LORD, Because you sent messengers to ask to Baal the fly god of Ekron, as if there was not a God in Israel to ask the word of him, on account of this the bed upon which you ascended upon it, you shall not go down from it, for in death you shall die. 

#### 2 Kings 1:17 And he died according to the saying of the LORD which Elijah spoke. And {reigned Jehoram the brother of Ahaziah} instead of him, (for there was no son to him) in the {year second} of Jehoram son of Jehoshaphat king of Judah. 

#### 2 Kings 1:18 And the rest of the words of Ahaziah, as many things as he did, behold are not these written in the scroll of the words of the days of the kings of Israel? 

#### 2 Kings 2:1 And it came to pass in the LORD to lead Elijah in a rumbling as into the heaven, that {went Elijah and Elisha} from out of Gilgal. 

#### 2 Kings 2:2 And Elijah said to Elisha, Sit down indeed here! for the LORD has sent me unto Bethel. And Elisha said, As the LORD lives, and as {lives your soul}, shall I abandon you, no. And they came unto Bethel. 

#### 2 Kings 2:3 And {came the sons of the prophets in Bethel} to Elisha, and they said to him, Do you know that the LORD today takes your master above your head? And he said, Indeed even I knew, keep silent! 

#### 2 Kings 2:4 And Elijah said to Elisha, Sit down indeed here! for the LORD has sent me to Jericho. And Elisha said, As the LORD lives, and as {lives your soul}, shall I abandon you, no. And they came unto Jericho. 

#### 2 Kings 2:5 And {approached the sons of the prophets in Jericho} to Elisha, and they said to him, Do you know that today the LORD takes your master from above your head? And he said, I knew, keep silent! 

#### 2 Kings 2:6 And {said to him Elijah}, Sit down indeed here! for the LORD has sent me unto the Jordan. And Elisha said, As the LORD lives, and as {lives your soul}, shall I abandon you, no. And they {went both}. 

#### 2 Kings 2:7 And fifty men from the sons of the prophets came, and they stood right opposite far off. And both stood at the Jordan. 

#### 2 Kings 2:8 And Elijah took his sheepskin, and wrapped it, and struck the water, and {was divided the water} here and there, and they {passed over both} through dry ground. 

#### 2 Kings 2:9 And it came to pass, in their passing over, Elijah said to Elisha, Ask! what I shall do for you before my being taken up from you. And Elisha said, Let there be indeed a double of your spirit upon me! 

#### 2 Kings 2:10 And Elijah said, You hardened to ask. If you should behold me being taken up from you, it will be thus to you; but if not, in no way will it be. 

#### 2 Kings 2:11 And it came to pass of their going and speaking, that behold, a chariot of fire, and horses of fire, and they drew apart between both; and Elijah was taken up in a rumbling unto into the heaven. 

#### 2 Kings 2:12 And Elisha was beholding, and he yelled, O father, O father, the chariot of Israel, and his horseman. And he did not see him any longer. And he took hold of his garments and tore them into two. 

#### 2 Kings 2:13 And he raised up high the sheepskin of Elijah which fell on top of him. And Elisha turned, and stood upon the edge of the Jordan. 

#### 2 Kings 2:14 And he took the sheepskin of Elijah, which fell on top of him, and he struck the waters, and said, Where is the God of Elijah now? And he struck the waters, and they tore apart here and there; and Elisha passed over. 

#### 2 Kings 2:15 And {beheld him the sons of the prophets}, the ones in Jericho right opposite. And they said, {rests The spirit of Elijah} upon Elisha. And they came to meet with him, and they did obeisance to him upon the ground. 

#### 2 Kings 2:16 And they said to him, Behold indeed, there are with your servants fifty men, sons of power. In going indeed, let them seek your master! lest at some time {lifted him spirit of the LORD}, and tossed him in the mountains, or upon one of the hills. And Elisha said, You shall not send. 

#### 2 Kings 2:17 And they pressed him until he was shamed. And he said, Send them! And they sent fifty men; and they sought three days, and they did not find him. 

#### 2 Kings 2:18 And they returned to him. And he stayed in Jericho. And he said to them, Did I not say to you, Do not go? 

#### 2 Kings 2:19 And {said the men of the city} to Elisha, Behold now, the site of the city is good, as you, O master, see; but the waters are bad, and the ground being barren. 

#### 2 Kings 2:20 And Elisha said, Bring to me {water-pot a new}, and cast salt there! And they took it to him. 

#### 2 Kings 2:21 And he went forth unto the outlet of the waters, and he tossed there the salt. And he said, Thus says the LORD, I have healed these waters, there will not be any longer there death and being barren. 

#### 2 Kings 2:22 And {were healed the waters} until this day, according to the word of Elisha which he spoke. 

#### 2 Kings 2:23 And he ascended from there unto Bethel. And in his ascending in the way, that {boys small} came forth from out of the city, and they mocked him, and said to him, Ascend, bald one! Ascend, bald one! 

#### 2 Kings 2:24 And he turned behind him, and beheld them, and cursed them in the name of the LORD. And {came forth two bears} from out of the forest, and they tore asunder of them forty and two children. 

#### 2 Kings 2:25 And he went from there to mount Carmel, and from there he turned unto Samaria. 

#### 2 Kings 3:1 And Jehoram son of Ahab reigned in Israel in Samaria in the eighteenth year of Jehoshaphat king of Judah. And he reigned twelve years. 

#### 2 Kings 3:2 And he did the wicked thing in the eyes of the LORD, only not as his father and his mother. And he removed the monuments of Baal which {made his father}. 

#### 2 Kings 3:3 Except in the sins of Jeroboam son of Nebat, who led Israel into sin, he cleaved to; he did not abstain from it. 

#### 2 Kings 3:4 And Mesha king of Moab was a shepherd, and he restored to the king of Israel a hundred thousand lambs, and a hundred thousand rams with fleece. 

#### 2 Kings 3:5 And it came to pass after the dying of Ahab, Moab annulled allegiance with the king of Israel. 

#### 2 Kings 3:6 And {went forth king Jehoram} in that day from out of Samaria, and he numbered Israel. 

#### 2 Kings 3:7 And he went and sent to Jehoshaphat king of Judah, saying, The king of Moab annulled allegiance with me. Shall you go with me unto Moab for war? And he said, I will go; likened to you, likened to me; as your people, so my people; as your horses, so my horses. 

#### 2 Kings 3:8 And he said, What way shall we ascend? And he said, The way of the wilderness of Edom. 

#### 2 Kings 3:9 And {went the king of Israel}, and the king of Judah, and the king of Edom. And they encircled a journey of seven days. And there was no water for the camp, and for the cattle, the ones at their feet. 

#### 2 Kings 3:10 And {said the king of Israel}, O that the LORD called {three kings these} to deliver them up into the hand of Moab. 

#### 2 Kings 3:11 And Jehoshaphat said to him, Is there not here a prophet of the LORD, that we should seek anxiously the LORD by him? And answered one of the servants of the king of Israel, and said, {is here Elisha son of Shaphat}, who poured water upon the hands of Elijah. 

#### 2 Kings 3:12 And Jehoshaphat said, {is with him The word of the LORD}. And {went down to him the king of Israel}, and Jehoshaphat king of Judah, and the king of Edom. 

#### 2 Kings 3:13 And Elisha said to the king of Israel, What is there between me and you? Go to the prophets of your father, and to the prophets of your mother. And {said to him the king of Israel}, Is it that the LORD calls {three kings these} to deliver them into the hands of Moab? 

#### 2 Kings 3:14 And Elisha said, As {lives the LORD of the forces}, in whom I stand before him, that if it were not the face of Jehoshaphat king of Judah which I receive, shall I have looked upon you or beheld you, no. 

#### 2 Kings 3:15 And now bring to me one for strumming! And it came to pass as {strummed the one strumming}, that {came upon him the hand of the LORD}. 

#### 2 Kings 3:16 And he said, Thus says the LORD, Make this dry stream cistern upon cistern. 

#### 2 Kings 3:17 For thus says the LORD, You shall not see wind, and you shall not see rain; but this dry stream shall be filled with water, and you shall drink, you and your possessions, and your cattle. 

#### 2 Kings 3:18 But it is a light thing in the eyes of the LORD. And I will deliver up Moab into your hands. 

#### 2 Kings 3:19 And you shall strike every {city fortified}, and every {city choice}; and every {tree good} you shall throw down, and all springs of water you shall obstruct, and every {portion of land good} you shall make useless with stones. 

#### 2 Kings 3:20 And it came to pass in the morning of the ascending of the sacrifice, that behold, waters came from out of the way of Edom, and {was filled the earth} of the waters. 

#### 2 Kings 3:21 And all Moab heard that {ascended the kings} to wage war against them, and they yelled out from all sides girding on the belt, and went forward, and they stood at the border. 

#### 2 Kings 3:22 And they rose early in the morning, and the sun rose upon the waters. And Moab beheld the waters right opposite fiery red as blood. 

#### 2 Kings 3:23 And they said, This is blood of a broadsword. {did combat The kings}, and {struck each man} his neighbor. And now, {are for the spoils} Moab. 

#### 2 Kings 3:24 And they entered into the camp of Israel. And Israel rose up and struck Moab. And they fled in front of them; and they entered going and beating Moab. 

#### 2 Kings 3:25 And {the cities they demolished}, and every {portion of land good} {tossed each man} his stone, and they filled it. And every spring of water they obstructed, and every {tree good} they threw down unto leaving behind the stones of the wall being demolished. And {encircled the slingers} and struck it. 

#### 2 Kings 3:26 And {beheld the king of Moab} that {overpowered him the battle}; and he took with himself seven hundred men unsheathing the broadsword to cut through the king of Edom; but they were not able. 

#### 2 Kings 3:27 And he took {son his first-born} whom he gave reign instead of him, and offered him as a whole burnt-offering upon the wall. And came to pass {repentance a great} in Israel. And they departed from him, and they returned to the land. 

#### 2 Kings 4:1 And {wife one} of the sons of the prophets yelled to Elisha, saying, Your servant, my husband died, and you know that your servant was fearing the LORD. And the money-lender came to take {two sons my} for servants to himself. 

#### 2 Kings 4:2 And Elisha said to her, What should I do for you, announce it to me? What is there to you in the house? And she said, There is not to your maidservant one thing in the house, only a vessel of olive oil in the house which I anoint with. 

#### 2 Kings 4:3 And he said to her, Go ask for yourself vessels from outside, from all your neighbors, {vessels empty}, not a few. 

#### 2 Kings 4:4 And you shall enter and lock the door after you and after your sons. And you shall pour out into these vessels, and the one being filled you shall take away. 

#### 2 Kings 4:5 And she went forth from him, and did thus. And she locked the door after herself and after her sons, and they drew near to her; and she poured until {were filled the vessels}. 

#### 2 Kings 4:6 And she said to her sons, Bring near to me a vessel! And they said to her, There is not yet a vessel. And {stopped the olive oil}. 

#### 2 Kings 4:7 And she came and reported to the man of God. And he said to her, Go, and render the olive oil for sale, and pay your interest! and you and your sons shall live by the rest. 

#### 2 Kings 4:8 And {came a day} and Elisha passed over into Shunem, and there was {there woman a great}, and she took hold of him to eat bread. And it came to pass whenever it was fit for him to enter that he turned aside there to eat bread. 

#### 2 Kings 4:9 And {said the woman} to her husband, Behold indeed, I know that {man of God this is a holy}, who travels unto us continually. 

#### 2 Kings 4:10 We should indeed make for him {upper room a small}, and we should put for him there a bed, and a table, and a chair, and a lamp-stand. And it will be in his coming to us, that he shall turn aside there. 

#### 2 Kings 4:11 And {came a day}, and he entered there, and he turned aside into the upper room, and went to bed there. 

#### 2 Kings 4:12 And he said to Gehazi his servant, Call this Shunammite! And he called her, and she stood before him. 

#### 2 Kings 4:13 And he said to him, Say indeed to her, Behold, you startled us all with this change of state, what shall we do for you? Is there to you a word to say to the king, or to the ruler of the force? And she said, {in the midst of my people I dwell}. 

#### 2 Kings 4:14 And he said to Gehazi, What must be done for her? And Gehazi said, That by all means a son is not to her, and her husband is old. 

#### 2 Kings 4:15 And he said, Call her! And he called her, and she stood by the door. 

#### 2 Kings 4:16 And Elisha said to her, At this time next year, about this hour, and living, you shall be holding a son. But she said, No, O master, O man of God, you should not disappoint your maidservant. 

#### 2 Kings 4:17 And {conceived the woman}, and bore a son at this same time about the same hour living, as {spoke to her Elisha}. 

#### 2 Kings 4:18 And {matured the boy}. And it came to pass {went forth the boy} to his father -- to the ones harvesting. 

#### 2 Kings 4:19 And he said to his father, My head, my head. And he said to the servant, Carry him to his mother. 

#### 2 Kings 4:20 And he lifted him, and he carried him in to his mother, and he laid him down to rest upon her knees until midday, and he died. 

#### 2 Kings 4:21 And she bore him, and rested him upon the bed of the man of God, and locked after him, and went forth. 

#### 2 Kings 4:22 And she called her husband, and said, Send indeed for me one of the servants, and one of the donkeys, and I shall run unto the man of God, and I shall return. 

#### 2 Kings 4:23 And he said, Why is it that you should go to him today? It is not a new moon nor a Sabbath. And she said, Peace. 

#### 2 Kings 4:24 And she saddled the donkey, and said to her servant, You lead, and go! Do not wait for me to mount. For if I said to you, Go, then you shall go and shall come to the man of God in mount Carmel. 

#### 2 Kings 4:25 And she went, and came unto the man of God in the mountain. And it came to pass as {saw her the man of God} right opposite, that he said to Gehazi, to his servant, Behold, that Shunammite. 

#### 2 Kings 4:26 Now run to meet her! and you shall say to her, Is peace to you? Is peace to your husband? Is peace to the boy? And she said, Peace. 

#### 2 Kings 4:27 And she straightened to the man of God in the mountain, and she seized his feet. And Gehazi approached to thrust her away, and {said to him the man of God}, Allow her! for her soul pains her, and the LORD concealed it from me, and announced it not to me. 

#### 2 Kings 4:28 And she said, Did I ask a son from my master? Did I not say, Do not mislead with me? 

#### 2 Kings 4:29 And Elisha said to Gehazi, Tie up your loin, and take my staff in your hand and go! And if you should find a man in the way, you shall not bless him; and if {should bless you a man}, you shall not answer him; and you shall place my staff upon the face of the boy. 

#### 2 Kings 4:30 And {said the mother of the boy}, As the LORD lives, and as {lives your soul}, shall I leave you behind, no. And Elisha rose up, and went after her. 

#### 2 Kings 4:31 And Gehazi went in front of them, and he placed the staff upon the face of the boy; and there was no sound, and there was no hearing. And he returned to meet him, and he reported to him, saying, {was not arisen the boy}. 

#### 2 Kings 4:32 And Elisha entered into the house, and behold, the boy having died was resting upon his bed. 

#### 2 Kings 4:33 And Elisha entered, and locked the door after the two of them. And he prayed to the LORD. 

#### 2 Kings 4:34 And he ascended, and bedded down upon the boy, and put his mouth upon his mouth, and his eyes upon his eyes, and his hands upon his hands. And he bent upon him, and warmed the flesh of the boy. 

#### 2 Kings 4:35 And he returned, and went about the house this side and that side, and he ascended, and bent downwards upon the boy for seven times. And {opened the boy} his eyes. 

#### 2 Kings 4:36 And Elisha yelled out loud to Gehazi, and said, Call this Shunammite! And he called her, and she entered to him. And Elisha said, Receive your son! 

#### 2 Kings 4:37 And {entered the woman}, and fell at his feet, and did obeisance upon the ground, and took her son, and went forth. 

#### 2 Kings 4:38 And Elisha returned to Gilgal. And the famine was in the land. And the sons of the prophets sat down before him. And Elisha said to his servant, Stand by the {kettle great}, and boil stew for the sons of the prophets! 

#### 2 Kings 4:39 And he went forth into the field to collect together herbs. And he found a vine in the field, and he collected together from it {gourd a wild} to fill his cloak, and he entered and put it into the kettle of the stew -- but they did not know. 

#### 2 Kings 4:40 And he poured out to the men to eat. And it came to pass in their eating from the stew, that they yelled out and said, Death is in the kettle, O man of God. And they were not able to eat. 

#### 2 Kings 4:41 And he said, You take flour, and put it in the kettle! And they put. And Elisha said to Gehazi, Pour out to the people, and let them eat! And there was not {thing a bad} still in the kettle. 

#### 2 Kings 4:42 And a man came from out of Baal-shalisha, and he brought to the man of God first produce of twenty bread loaves of barley, and dried clusters of figs. And he said, Give them to the people, and let them eat! 

#### 2 Kings 4:43 And {said his minister}, What, should I give before {hundred men this}? And he said, Give to the people, and let them eat! for thus says the LORD, They shall eat, and shall leave over. 

#### 2 Kings 4:44 And they ate, and left behind according to the saying of the LORD. 

#### 2 Kings 5:1 And Naaman. the ruler of the force of the king of Syria was {man a great} before his master, and being an admired person, for through him the LORD gave deliverance to Syria. And the man was mighty in strength, but leprous. 

#### 2 Kings 5:2 And the Syrians went forth in armed bands, and they captured from out of the land of Israel {young woman a small}; and she was in the presence of the wife of Naaman. 

#### 2 Kings 5:3 And she said to her lady, Ought that my master was in the presence of the prophet in Samaria, then he shall cure him from his leprosy. 

#### 2 Kings 5:4 And she entered and reported it to her master, and she said, Thus and thus says the young woman from out of the land of Israel. 

#### 2 Kings 5:5 And {said the king of Syria}, Come, enter! and I will send out a scroll to the king of Israel. And he went and took in his hand ten talents of silver, and six thousand pieces of gold, and ten changes of apparels. 

#### 2 Kings 5:6 And he brought the scroll to the king of Israel, saying, And now when ever {should come scroll this} to you, behold, I sent to you Naaman my servant, and you shall cure him from his leprosy. 

#### 2 Kings 5:7 And it came to pass as {read the king of Israel} the scroll, that he tore his garments, and said, Am I God, the one putting to death and restoring to life, that this one sends to me to cure a man from his leprosy? For besides, you know and see that this one makes an excuse towards me. 

#### 2 Kings 5:8 And it came to pass as {heard Elisha the man of God} that {tore the king} his garments, that he sent to the king of Israel, saying, Why do you tear your garments? Let {come indeed to me Naaman}! and he shall know that there is a prophet in Israel. 

#### 2 Kings 5:9 And Naaman came by horse and chariot, and he stood at the door of the house of Elisha. 

#### 2 Kings 5:10 And Elisha sent to him a messenger, saying, In going, bathe in the Jordan seven times, and {shall return your flesh} to you, and you shall be cleansed. 

#### 2 Kings 5:11 And Naaman was enraged, and went forth, and said, Behold, I said, he will come forth to me, and he shall stand and shall call in the name of the LORD his God, and shall place his hand upon the place, and shall cure the leper. 

#### 2 Kings 5:12 Are not {good the Abana and Phaphar rivers of Damascus} over the Jordan, and all the waters of Israel? Shall I not go bathe in them, and be cleansed? And he turned aside, and went forth in rage. 

#### 2 Kings 5:13 And {approached his servants}, and they said to him, If {a great word spoke the prophet} to you, would you not have done in so far as he said to you? Bathe and be cleansed! 

#### 2 Kings 5:14 And Naaman went down, and he immersed in the Jordan seven times, according to the word of the man of God. And {returned his flesh} as the flesh {boy of a small}, and he was cleansed. 

#### 2 Kings 5:15 And he returned to the man of God, he and his camp. And he came, and stood before him, and said, Behold, now I know that there is not a God in all the earth, but only in Israel. And now, receive a blessing from your servant! 

#### 2 Kings 5:16 And Elisha said, As the LORD lives in whom I stand before him, shall I take it? And he pressed him to take, but he resisted persuasion. 

#### 2 Kings 5:17 And Naaman said, And if not, let there be given indeed to your servant a cargo team of mules of earth, for {shall not offer any longer your servant} a whole burnt-offering and sacrifice {gods to other}; but only to the LORD alone. 

#### 2 Kings 5:18 And concerning this matter, {shall deal kindly with me the LORD}, to your servant in the entering of my master into the house of Rimmon to do obeisance there, for he shall rest upon my hand. And I shall do obeisance in the house of Rimmon, in his doing obeisance in the house of Rimmon. And {shall deal kindly with me the LORD} to your servant over this matter. 

#### 2 Kings 5:19 And Elisha said to Naaman, Go in peace! And he went forth from him into Havratha the land. 

#### 2 Kings 5:20 And {said Gehazi}, the servant of Elisha the man of God, Behold, {spared my master} Naaman this Syrian, so as to not take from his hand of what he brought. As lives the LORD, that I shall run after him, and I shall take something from him. 

#### 2 Kings 5:21 And Gehazi pursued after Naaman. And {saw him Naaman} running after him, and he leaped down from the chariot for meeting him. And he said, Peace. 

#### 2 Kings 5:22 And Gehazi said, Peace. My master has sent me, saying, Behold, now there came to me two young men from out of mount Ephraim, from the sons of the prophets. Give indeed to them a talent of silver and two changes of apparel! 

#### 2 Kings 5:23 And Naaman said, Take two talents of silver! And he forced him, and he took to him two talents of silver in two purses, and two changes of apparel. And he gave unto {two servants his}, and they carried them in front of him. 

#### 2 Kings 5:24 And he came to a dark place, and he took from their hands, and he placed them in the house, and sent out the men, and they left. 

#### 2 Kings 5:25 And he entered and stood before his master. And {said to him Elisha}. From what place did you come from Gehazi? And Gehazi said, {has not gone Your servant} here or there. 

#### 2 Kings 5:26 And {said to him Elisha}, Did not my heart go with you when {turned the man} from his chariot for meeting you? And now, you took the silver, and the garments, and you shall take with it gardens, and olive groves, and vineyards, and flocks, and herds, and bondmen and bondwomen. 

#### 2 Kings 5:27 And the leprosy of Naaman shall cleave to you, and among your seed into the eon. And he went forth from his face being leprous as snow. 

#### 2 Kings 6:1 And {said the sons of the prophets} to Elisha, Behold, indeed the place in which we live before you is scant for us. 

#### 2 Kings 6:2 We should go indeed unto the Jordan, and we should take from there {man per one beam one}; and we should make for ourselves a shelter to live there. And he said, Go! 

#### 2 Kings 6:3 And {said one}, Please come with your servants. And he said, I will go. 

#### 2 Kings 6:4 And he went with them, and they came unto the Jordan, and they trimmed the wood. 

#### 2 Kings 6:5 And it happened to one casting down the beam, that {fell off of the stick the iron implement} into the water. And he yelled, and said, O master. And it was hidden. 

#### 2 Kings 6:6 And {said the man of God}, Where did it fall? And he showed to him the place. And he plucked off wood and tossed it there, and {floated the iron implement}. 

#### 2 Kings 6:7 And he said, Raise it to yourself! And he stretched out his hand and took it. 

#### 2 Kings 6:8 And the king of Syria was waging war against Israel. And he consulted with his servants, saying, In the place thus {in a certain concealed place I will camp}. 

#### 2 Kings 6:9 And {sent the man of God} to the king of Israel, saying, Guard to not go by this place, for there Syria hides. 

#### 2 Kings 6:10 And {sent the king of Israel} to the place which {told him the man of God}. And he guarded from there not once nor twice. 

#### 2 Kings 6:11 And {was startled the soul of the king of Syria} on account of this word. And he called his servants, and he said to them, Shall you not announce to me who betrays me to the king of Israel? 

#### 2 Kings 6:12 And {said one of his servants}, Not so, O my master, O king. For Elisha the prophet, the one in Israel, he announces to the king of Israel all the words which ever you should speak in the closet of your bedroom. 

#### 2 Kings 6:13 And he said, Go, and see where this one is! and sending I will take him. And they reported to him, saying, Behold, he is in Dothan. 

#### 2 Kings 6:14 And he sent horses and chariots, and {force a heavy}. And they came at night, and surrounded the city. 

#### 2 Kings 6:15 And {early the minister of the man of God rose up}, and went forth. And behold, the force was encircling the city, and with horses and chariots. And {said his servant} to him, O master, what shall we do? 

#### 2 Kings 6:16 And Elisha said, Do not fear, for many are the ones with us over the ones with them. 

#### 2 Kings 6:17 And Elisha prayed, and said, O LORD, open his eyes, and let him see! And the LORD opened wide the eyes of the young man, and he saw. And behold, the mountain was full of horses, and a chariot of fire surrounding Elisha. 

#### 2 Kings 6:18 And they came down to him. And Elisha prayed to the LORD, and said, Strike indeed this nation with inability to see! And he struck them with inability to see, according to the saying of Elisha. 

#### 2 Kings 6:19 And Elisha said to them, This is not the city, and this is not the way. Come after me! and I will lead you to the man whom you seek. And he took them to Samaria. 

#### 2 Kings 6:20 And it came to pass, as he entered into Samaria, that Elisha said, O LORD, open the eyes of these, and let them see! And the LORD opened wide their eyes, and they saw. And behold, they were in the midst of Samaria. 

#### 2 Kings 6:21 And {said the king of Israel} to Elisha, as he beheld them, Shall by striking, I strike them, O father? 

#### 2 Kings 6:22 And he said, You shall not strike. Whom you captured by your broadsword, and your bow you shall strike. Place bread loaves and water before them, and let them eat and let them drink and let them go forth to their master! 

#### 2 Kings 6:23 And he placed for them {fete a great}. And they ate, and drank, and he sent them. And they went forth to their master. And {did not proceed still the armed bands of Syrians} to come into the land of Israel. 

#### 2 Kings 6:24 And it came to pass after these things, that {gathered the son of Hadad king of Syria} all his camp, and ascended, and besieged against Samaria. 

#### 2 Kings 6:25 And there was {famine a great} in Samaria. And behold, they laid siege against it until of which {was worth the head of a donkey} eighty shekels of silver; and a fourth of a cab {dung of doves} five shekels of silver. 

#### 2 Kings 6:26 And {was the king of Israel} traveling upon the wall. And a woman yelled to him, saying, Deliver us, O master, O king! 

#### 2 Kings 6:27 And he said to her, Unless {delivers you the LORD}, from what place shall I deliver you -- from the threshing-floor or from the wine vat? 

#### 2 Kings 6:28 And {said to her the king}, What is it with you? And she said, This woman said to me, Give your son! and we shall eat him today, and my son we shall eat tomorrow. 

#### 2 Kings 6:29 And we boiled my son, and we ate him. And I said to her the {day other}, Give your son! for we should eat him. And she hid her son. 

#### 2 Kings 6:30 And it came to pass as {heard the king} the words of the woman, he tore his garments, and he traveled over upon the wall. And {saw the people} the sackcloth upon his flesh inside. 

#### 2 Kings 6:31 And he said, Thus {do to me God}, and thus add more, if {shall stand the head of Elisha son of Shaphat} upon him today. 

#### 2 Kings 6:32 And Elisha was sitting down in his house, and the elders were sitting down with him. And the king sent a man before his face. But before the coming of the messenger to him, that Elisha himself said to the elders, Do you see that {sent son of a murderer this} to remove my head? Know as when {should come the messenger}, you lock the door, and press against him on the door! Is not the sound of the feet of his master right after him? 

#### 2 Kings 6:33 While he was speaking with them, that behold, the messenger came to him. And he said, Behold, this evil is from the LORD, why remain behind for the LORD any longer? 

#### 2 Kings 7:1 And Elisha said, Hear the word of the LORD! Thus says the LORD, At this same hour tomorrow, a measure of fine flour shall be sold for a shekel, and two measures of barley for a shekel, at the gate of Samaria. 

#### 2 Kings 7:2 And {responded the tribune} (upon whom the king rested upon his hand) to the man of God, and he said, And if the LORD should make a torrent in the heaven, shall {be this thing}, no. And Elisha said, Behold, you shall see with your eyes, but {from there you shall not eat}. 

#### 2 Kings 7:3 And four men, lepers, were by the door of the city. And said one man to his neighbor, Why do we sit here until we die? 

#### 2 Kings 7:4 If we should say, We should enter into the city, and the famine is in the city, then we shall die there. And if we sit here, then we shall die. And now, come, and we shall fall into the camp of Syria. If they should bring us forth alive, then we shall live. And if they should kill us, then we shall die. 

#### 2 Kings 7:5 And they rose up in the darkness to enter into the camp of Syria. And they entered unto a part of the camp of Syria. And behold, there was not a man there. 

#### 2 Kings 7:6 For the LORD {audible made} in the camp of Syria a sound of chariots, and a sound of horses, and a sound {force of a great}. And {said each man} to his neighbor, Behold, {has hired against us the king of Israel} the kings of the Hittites, and the kings of Egypt, to come against us. 

#### 2 Kings 7:7 And they rose up, and ran away in the darkness. And they abandoned their tents, and their horses, and their donkeys, as was in the camp; and they fled for their lives. 

#### 2 Kings 7:8 And {came these lepers} unto a part of the camp. And they entered into {tent one}, and ate, and drank, and lifted from there silver, and gold, and clothes, and they went and hid everything. And they returned and entered into {tent another}, and they took from there, and went and hid them. 

#### 2 Kings 7:9 And said one man to his neighbor, {not thus We are} doing right. This day {a day of good news is}, and we keep silent, and are waiting until light of the morning, and we shall find iniquity. Now then, come, we should go and announce to the house of the king. 

#### 2 Kings 7:10 And they entered and yelled by the gate of the city. And they announced to them, saying, We entered into the camp of Syria, and behold, there is not there a man nor a voice of a man, but only a horse being tied and a donkey being tied, and their tents as they are. 

#### 2 Kings 7:11 And they called the doorkeepers. And they announce to the house of the king inside. 

#### 2 Kings 7:12 And {rose up the king} in the night, and said to his servants, I shall report indeed to you what {have done to us the Syrians}. They know that we hunger, and they went forth from out of the camp, to hide in a field, saying, They shall come forth from out of the city, and we shall seize them alive, and we shall enter into the city. 

#### 2 Kings 7:13 And answered one of his servants, and said, Let them take indeed five of the horses, of the ones being left behind, which they left behind here. Behold, they are for all the multitude of Israel faltering; for we will send there and see. 

#### 2 Kings 7:14 And they took two riders of horses; and {sent them the king of Israel} after Syria, saying, Go and see! 

#### 2 Kings 7:15 And they went after them unto the Jordan. And behold, all the way was full of clothes and items, which the Syrians tossed in their being distraught. And {returned the messengers}, and announced to the king. 

#### 2 Kings 7:16 And {came forth the people}, and they tore in pieces the camp of Syria. And {became worth a measure of fine flour} a shekel, and two measures of barley for a shekel, according to the saying of the LORD. 

#### 2 Kings 7:17 And the king placed the tribune (upon whom the king rested upon his hand) over the gate. And {trampled him the people} at the gate, and he died as {said the man of God}, who spoke with the {coming down messenger} to him. 

#### 2 Kings 7:18 And it came to pass as Elisha said to the king, saying, Two measures of barley for a shekel, and a measure of fine flour for a shekel, and it will be at this hour tomorrow at the gate of Samaria. 

#### 2 Kings 7:19 And {answered the tribune} to the man of God, and said, And if the LORD should make a torrent in the heaven, shall {be this thing}, no. And {said the man of God} Behold, you will see with your eyes, but from there you will not eat. 

#### 2 Kings 7:20 And it came to pass so; and {trampled him the people} in the gate, and he died. 

#### 2 Kings 8:1 And Elisha spoke to the woman of whom {was enlivened the son}, saying, Rise up and go, you and your household, and sojourn of which ever place you should want to sojourn! for the LORD has called a famine upon the land; and it will be at hand upon the land for seven years. 

#### 2 Kings 8:2 And {rose up the woman}, and did according to the saying of the man of God. And she went and her household, and sojourned in the land of the philistines seven years. 

#### 2 Kings 8:3 And it came to pass after the end of the seven years, that {returned the woman} from out of the land of the philistines. And she went to yell to the king on account of her house, and on account of her fields. 

#### 2 Kings 8:4 And the king spoke to Gehazi the servant of Elisha, the man of God, saying, Describe indeed to me! all the great things which Elisha did. 

#### 2 Kings 8:5 And it came to pass, of his describing to the king of how he enlivened the son having died, that behold, the woman of whom he enlivened her son came yelling to the king concerning her house and concerning her fields. And Gehazi said, O master, O king, this is the woman, and this is her son whom Elisha enlivened. 

#### 2 Kings 8:6 And {asked the king} the woman, and she described to him. And {appointed to her the king eunuch one}, saying, Return all the things of hers, and all the offspring of her field from the day of which she left the land until the present. 

#### 2 Kings 8:7 And Elisha came unto Damascus. And the son of Hadad king of Syria was infirm. And they announced to him, saying, {comes The man of God} unto here. 

#### 2 Kings 8:8 And {said the king} to Hazael, Take in your hand a gift, and go for a meeting with the man of God, and seek anxiously of the LORD through him, saying, Shall I live from out of {my illness this}? 

#### 2 Kings 8:9 And Hazael went to meet him, and he took a gift in his hand of all the good things of Damascus, a tribute of forty camels. And he came and stood before him, and said, Your son, the son of Hadad king of Syria sent me to you, saying, Shall I live from out of {my illness this}? 

#### 2 Kings 8:10 And {said to him Elisha}, Go, say to him, To life you shall live! But {showed to me the LORD} that to death he shall die. 

#### 2 Kings 8:11 And Hazael stood in front of him, and he placed before him the gifts until he was ashamed. And {wept the man of God}. 

#### 2 Kings 8:12 And Hazael said, Why is it that my master weeps? And he said that, I have beheld as many things as you shall do to the sons of Israel -- bad things. {their fortresses You will send} up in fire, and their chosen ones you will kill by broadsword, and their infants you shall dash, and the ones {one in the womb having of them} you shall tear apart. 

#### 2 Kings 8:13 And Hazael said, What is your servant, the dog having died, that he will do {thing this great}? And Elisha said, {showed to me The LORD} you reigning over Syria. 

#### 2 Kings 8:14 And he went forth from Elisha, and came to his master. And he said to him, What said Elisha to you? And he said, He said to me, To life you shall live. 

#### 2 Kings 8:15 And it came to pass in the next day, and he took a rag, and he dipped it in water, and put it upon his face, and he died. And Hazael reigned instead of him. 

#### 2 Kings 8:16 In {year the fifth} of Jehoram son of Ahab king of Israel, {reigned Jehoram son of Jehoshaphat king of Judah}. 

#### 2 Kings 8:17 {a son of thirty and two years old He was} in his taking reign. And eight years he reigned in Jerusalem. 

#### 2 Kings 8:18 And he went in the way of the kings of Israel, as did the house of Ahab; for the daughter of Ahab was his wife. And he did the wicked thing before the LORD. 

#### 2 Kings 8:19 And {did not want the LORD} to corrupt Judah because of David his servant; as he said to give to him the lamp and to his sons all the days. 

#### 2 Kings 8:20 In his days Edom annulled allegiance from beneath the hand of Judah, and they gave reign to {over themselves a king}. 

#### 2 Kings 8:21 And Jehoram ascended into Zair, and all the chariots with him. And it happened as he rose up at night, that he struck Edom circling upon him, and the commanders of the chariots. And {fled the people} to its tents. 

#### 2 Kings 8:22 But Edom annulled allegiance from beneath the hand of Judah until this day. Then Libnah annulled allegiance in that time. 

#### 2 Kings 8:23 And the rest of the words of Jehoram, and all as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 8:24 And Jehoram slept with his fathers, and he is entombed with his fathers in the city of David his father. And {reigned Ahaziah his son} instead of him. 

#### 2 Kings 8:25 In {year the twelfth} of Jehoram son of Ahab king of Israel {reigned Ahaziah son of Jehoram king of Judah}. 

#### 2 Kings 8:26 {was a son of twenty and two years of age Ahaziah} in his taking reign. And he reigned a year in Jerusalem. And the name of his mother was Athaliah, daughter of Omri king of Israel. 

#### 2 Kings 8:27 And he went in the way of the house of Ahab, and he did the wicked thing before the LORD, as the house of Ahab, for {son-in-law of the house of Ahab he is}. 

#### 2 Kings 8:28 And he went with Jehoram son of Ahab to war against Hazael king of Syria in Ramoth Gilead. And {struck the Syrians} Jehoram. 

#### 2 Kings 8:29 And {returned king Jehoram} to be treated medically in Jezreel from the wounds of which {struck him the Syrians} in Ramoth Gilead, during his waging war against Hazael king of Syria. And Ahaziah, son of Jehoram king of Judah went down to see Jehoram son of Ahab in Jezreel, because he was infirm. 

#### 2 Kings 9:1 And Elisha the prophet called one of the sons of the prophets, and he said to him, Tie up your loin, and take the flask of this oil in your hand, and be gone unto Ramoth Gilead! 

#### 2 Kings 9:2 And you shall enter there, and you shall see there Jehu son of Jehoshaphat son of Nimshi. And you shall enter, and you shall raise him from the midst of his brethren. And you shall bring him into the closet of a storeroom. 

#### 2 Kings 9:3 And you shall take the flask of the oil, and you shall pour upon his head. And you shall say, Thus says the LORD, I have anointed you for king over Israel. And you shall open the door, and shall flee, and not wait. 

#### 2 Kings 9:4 And {went the young prophet} unto Ramoth Gilead. 

#### 2 Kings 9:5 And he entered. And behold, the commanders of the force were sitting down. And he said, A word from me to you, commander. And Jehu said, To whom of all of us? And he said, To you, commander. 

#### 2 Kings 9:6 And he rose up, and entered into the house. And he poured the oil upon his head. And he said to him, Thus says the LORD God of Israel, I have anointed you for king over the people of the LORD, over Israel. 

#### 2 Kings 9:7 And you shall utterly destroy the house of Ahab your master from my face, and you shall avenge the blood of my servants the prophets, and the blood of all the servants of the LORD. at the hand of Jezebel, 

#### 2 Kings 9:8 and by the hand of the entire house of Ahab. And you shall utterly destroy to Ahab the ones urinating against a wall, and the one being held and the one left free in Israel. 

#### 2 Kings 9:9 And I will appoint the house of Ahab as the house of Jeroboam son of Nebat, and as the house of Baasha son of Ahijah. 

#### 2 Kings 9:10 And {shall eat Jezebel the dogs} in the part of Jezreel, and there shall not be one burying her. And he opened the door, and fled. 

#### 2 Kings 9:11 And Jehu came forth to the servants of his master, and they said to him, Peace? What is it that {entered overcome by convulsions this one} to you? And he said to them, You know the man, and his meditation. 

#### 2 Kings 9:12 And they said, That's unjust, but announce to us! And he said to them, Such and such he said to me, saying, Thus says the LORD, I anoint you for king over Israel. 

#### 2 Kings 9:13 And hearing, they hastened, and {took each} his cloak, and put them under him upon the frame of the stairs. And they trumped with the horn, and said, Jehu reigns. 

#### 2 Kings 9:14 And {confederated Jehu son of Jehoshaphat son of Nimshi} against Jehoram. And Jehoram guarded in Ramoth Gilead, he and all Israel before Hazael king of Syria. 

#### 2 Kings 9:15 And {returned Jehoram the king} to be treated medically in Jezreel from the wounds which {hit him the Syrians} in his waging war against Hazael king of Syria. And Jehu said, If {is your soul} with me, let there not go forth out of the city any one escaping to go and report in Jezreel. 

#### 2 Kings 9:16 And {rode and went Jehu} unto Jezreel, for Jehoram was being attended to in Jezreel. And Ahaziah king of Judah came down to see Jehoram. 

#### 2 Kings 9:17 And the watchman was standing upon the tower in Jezreel. And he beheld the cloud of dust of the multitude of Jehu in his coming. And he said, {a cloud of dust of the multitude I see}. And Jehoram said, Take a rider, and send for meeting them! and let him say, Is it peace? 

#### 2 Kings 9:18 And {went the rider} upon the horse for meeting him. And he said, Thus says the king, Is it peace? And Jehu said, What is it to you and peace? You turn to the ones behind me! And {reported the watchman}, saying, {came The messenger} unto them, and returned not. 

#### 2 Kings 9:19 And he sent {rider of a horse a second}. And he came to them, and he said, Thus says the king, Is it peace? And Jehu said, What is it to you and peace? You turn to the ones behind me! 

#### 2 Kings 9:20 And {reported the watchman}, saying, He came unto them and returned not. And the leader is as the leader Jehu son of Nimshi; for {in a frenzy he is}. 

#### 2 Kings 9:21 And Jehoram said, Team up chariots! And they teamed up. And {went forth Jehoram king of Israel}, and Ahaziah king of Judah, each man in his chariot. And they came forth for meeting Jehu. And they found him in the portion of Naboth the Jezreelite. 

#### 2 Kings 9:22 And it came to pass as Jehoram beheld Jehu, that he said, Is it peace Jehu? And Jehu said, What is it to you and peace with still the harlotries of Jezebel your mother and {potions her many}? 

#### 2 Kings 9:23 And Jehoram turned his hands to flee. And he said to Ahaziah, Treachery Ahaziah. 

#### 2 Kings 9:24 And Jehu filled his hand with the bow, and he struck Jehoram between his arms, and came forth the arrow through his heart, and he bent upon his knees. 

#### 2 Kings 9:25 And Jehu said to Bidkar his tribune, Take and toss him in the portion of the field of Naboth the Jezreelite! for I remember, I and you mounting upon teams after Ahab his father, and the LORD took upon him this concern, saying, 

#### 2 Kings 9:26 If in deed {the blood of Naboth and the blood of his sons I beheld yesterday}, says the LORD? And I shall recompense to you in this portion of land, says the LORD. And now lift him, and toss him in the portion of land, according to the word of the LORD! 

#### 2 Kings 9:27 And Ahaziah king of Judah beheld, and he fled the way of Beth-agan. And {pursued after him Jehu}. And he said, Even indeed him, strike him upon the chariot! And the did so in the ascent of Gur, which is the one of Ibleam. And he fled into Megiddo, and died there. 

#### 2 Kings 9:28 And {set him his servants} upon the chariot, and led him into Jerusalem. And they entombed him with his fathers in his tomb in the city of David. 

#### 2 Kings 9:29 And in {year the eleventh} of Jehoram king of Israel, Ahaziah took reign over Judah. 

#### 2 Kings 9:30 And Jehu came to Jezreel. And Jezebel heard, and she tinged {with antimony her eyes}, and she adorned her head, and she looked through the window. 

#### 2 Kings 9:31 And Jehu entered into the city. And she said, Is it peace with Omri, the murderer of his master? 

#### 2 Kings 9:32 And he lifted up his face unto the window, and he beheld her. And he said, Who are you? Come down to me! And {stooped forward to look down at him two eunuchs}. 

#### 2 Kings 9:33 And he said, Roll her over! And they rolled her over, and {sprinkled her blood} against the wall, and against the horses; and they trampled upon her. 

#### 2 Kings 9:34 And Jehu entered, and ate and drank, and said, Watch indeed this cursed one, and bury her, for {the daughter of a king she is}. 

#### 2 Kings 9:35 And they went to bury her, and they did not find of her but only the skull, and the feet, and the palms of her hands. 

#### 2 Kings 9:36 And they returned, and announced it to him. And he said, The word of the LORD which he spoke by the hand of his servant Elijah the Tishbite, saying, In the portion of land in Jezreel {shall eat the dogs} the flesh of Jezebel. 

#### 2 Kings 9:37 And {will be the decaying flesh of Jezebel} as dung upon the face of the field in the portion of Jezreel, so as to not say, This is Jezebel. 

#### 2 Kings 10:1 And to Ahab were seventy sons in Samaria. And Jehu wrote a scroll, and sent it unto Samaria, to the rulers of Samaria, and to the elders, and to the wet-nurses of the sons of Ahab, saying, 

#### 2 Kings 10:2 And now, whenever {comes scroll this} to you, and with you are the sons of your master, and with you the chariots and the horses, and {cities fortified}, and weapons, 

#### 2 Kings 10:3 that you shall look for the good, and the upright one among the sons of your master. And you shall place him upon the throne of his father, and you shall wage war for the house of your master. 

#### 2 Kings 10:4 And they feared exceedingly, and said, Behold, the two kings did not stand against his face, and how shall we stand? 

#### 2 Kings 10:5 And they sent the ones over the household, and the ones over the city, and the elders, and the wet-nurses to Jehu, saying, {your servants We are}, and all as much as you should say to us we shall do. We will not give {reign anyone}. The thing good in your eyes we will do. 

#### 2 Kings 10:6 And {wrote to them Jehu scroll a second}, saying, If you are with me, and {my voice you listen to}, take the heads of the men of the sons of your master, and bring them to me at this hour tomorrow in Jezreel! And the sons of the king were seventy men, whom the stout men of the city nourished them. 

#### 2 Kings 10:7 And it came to pass as {came the scroll} to them, that they took the sons of the king, and they slew them -- seventy men. And they put their heads in baskets, and they sent to him in Jezreel. 

#### 2 Kings 10:8 And {came the messenger} and reported to him, saying, They brought the heads of the sons of the king. And he said, Place them in two hills by the door of the gate until morning. 

#### 2 Kings 10:9 And it became morning, and he came forth and stood. And he said to all the people, You are just. Behold, I confederated against my master, and I killed him; but who struck all of these? 

#### 2 Kings 10:10 See that there shall not fall of the saying of the LORD unto the ground, of which the LORD spoke against the house of Ahab. And the LORD did as much as he spoke by the hand of his servant Elijah. 

#### 2 Kings 10:11 And Jehu struck all the ones being left among the house of Ahab in Jezreel, and all his stout men, and his well known men, and his priests, unto {not leaving behind his} a vestige. 

#### 2 Kings 10:12 And he rose up and went into Samaria. He was in Beth-Akad of the shepherds in the way. 

#### 2 Kings 10:13 And Jehu found the brothers of Ahaziah king of Judah, and he said, Who are you? And they said, {brothers of Ahaziah we are}, and we came down in peace of the sons of the king, and the sons of the woman being in power. 

#### 2 Kings 10:14 And he said, Seize them alive! And they seized them, and slew them in Beth-akad -- forty and two men. And he did not leave a man of them. 

#### 2 Kings 10:15 And he went from there, and he found Jehonadab son of Rechab in the way for meeting him. And he blessed him, and {said to him Jehu}, Is {straight your heart} with my heart, as my heart is with your heart? And Jehonadab said, It is. And Jehu said, Then if it is, give your hand! And he gave his hand. And he hauled him to himself upon the chariot. 

#### 2 Kings 10:16 And he said to him, Come with me, and see in my zealousness to the LORD! And he sat by him in his chariot. 

#### 2 Kings 10:17 And he entered into Samaria, and he struck all the ones left of Ahab in Samaria, unto obliterating him according to the saying of the LORD, which he spoke to Elijah. 

#### 2 Kings 10:18 And Jehu gathered together all the people. And said to them, Ahab served to Baal a little, Jehu shall serve to him much. 

#### 2 Kings 10:19 And now call to me all the prophets of Baal, and his priests, and all his servants! Let not a man be overlooked! for {sacrifice a great I make} to Baal. All who ever overlooked shall not live. And Jehu did it by trickery, that he might destroy the servants of Baal. 

#### 2 Kings 10:20 And Jehu said, Sanctify a service to Baal! And they proclaimed it. 

#### 2 Kings 10:21 And Jehu sent in all Israel. And {came all the servants of Baal}; there was not left behind a man who did not come. And they entered into the house of Baal, and {was filled the house of Baal} -- mouth unto mouth. 

#### 2 Kings 10:22 And Jehu told to the one over the house wardrobe to bring out garments for all the servants of Baal. And {brought them forth to them the keeper of the wardrobe}. 

#### 2 Kings 10:23 And Jehu entered, and Jehonadab son of Rechab, into the house of Baal. And he said to the servants of Baal, Search and see if there is with you servants of the LORD! for there is to be only the servants of Baal alone. 

#### 2 Kings 10:24 And they entered to offer the sacrifices and the whole burnt-offerings. And Jehu stationed for himself outside eighty men. And he said, A man who ever should preserve anyone of the men whom I bring in unto your hands, his life will be for his life. 

#### 2 Kings 10:25 And it came to pass as he completed offering the whole burnt-offering, that Jehu said to the bodyguards and to the tribunes, In entering, strike them! Let not come forth from them a man! And {struck them the bodyguards and the tribunes} by the mouth of the broadsword; and they tossed the bodies, and went unto the city of the house of Baal. 

#### 2 Kings 10:26 And they brought forth the monument of Baal, and burnt it. 

#### 2 Kings 10:27 And they tore down the monuments of Baal, and they demolished his house. And the house of Baal they established for a bathhouse until this day. 

#### 2 Kings 10:28 And Jehu removed Baal from Israel. 

#### 2 Kings 10:29 Except from the sins of Jeroboam son of Nebat, who led Israel into sin {did not abstain Jehu} from following after them -- the heifers of gold in Bethel and in Dan. 

#### 2 Kings 10:30 And the LORD said to Jehu, Because you did good to do the upright thing in my eyes, and you did according to all the things in my heart to the house of Ahab, sons unto the fourth generation shall sit down for you upon the throne of Israel. 

#### 2 Kings 10:31 And Jehu did not guard to go in the law of the LORD God of Israel with {entire heart his}. He did not abstain from the sins of Jeroboam son of Nebat, who led Israel into sin. 

#### 2 Kings 10:32 In those days the LORD began to cut down in Israel. And {struck them Hazael} in every border of Israel; 

#### 2 Kings 10:33 from the Jordan according to the rising of the sun -- all the land of Gilead of the Gadites, and of Reuben, and of Manasseh -- from Aroer, which is upon the edge of the rushing stream Arnon, and Gilead and Bashan. 

#### 2 Kings 10:34 And the rest of the words of Jehu, and all as much as he did, and all his dominations, and the associations which he joined, behold are not these written upon the scroll of the words of the days of the kings of Israel? 

#### 2 Kings 10:35 And Jehu slept with his fathers, and they entombed him in Samaria, and {reigned Jehoahaz his son} instead of him. 

#### 2 Kings 10:36 And the days which Jehu reigned over Israel were twenty-eight years in Samaria. 

#### 2 Kings 11:1 And Athaliah the mother of Ahaziah saw that {died her son}, and she rose up and destroyed all the seed of the kingdom. 

#### 2 Kings 11:2 And {took Jehosheba daughter of king Jehoram sister of Ahaziah} Joash, the son of her brother, and she stole him away from the midst of the sons of the king, of the ones being put to death, him and his nurse. And she hid him in the inner chamber of the beds from the face of Athaliah, and he was not put to death. 

#### 2 Kings 11:3 And he was with her in the house of the LORD being hid six years. And Athaliah reigned over the land. 

#### 2 Kings 11:4 And in the {year seventh sent Jehoiada the priest} and took the commanders of hundreds of the patrols, and of the couriers, and brought them in to himself in the house of the LORD. And he ordained with them a covenant, and he bound them to an oath in the presence of the LORD. And he showed to them the son of the king. 

#### 2 Kings 11:5 And he gave charge to them, saying, This is the thing which you shall do; the third part of you -- the ones entering on the Sabbath, let them guard the watch of the house of the king! 

#### 2 Kings 11:6 And the third part in the gate of the way, and the third part in the gate behind the bodyguards, even guard the watch of the house! 

#### 2 Kings 11:7 And two hands among you, any going forth on the Sabbath shall guard the watch of the house of the LORD unto the king. 

#### 2 Kings 11:8 And you shall encircle around the king -- {round about every man}, and his weapon shall be in his hand. And the one entering into the ranks shall die. And they will be with the king in his entering and in his exiting. 

#### 2 Kings 11:9 And {did the commanders of hundreds} according to all as much as Jehoiada gave charge. And {took each commander} his men of the ones entering on the Sabbath, with the ones exiting on the Sabbath. And they entered to Jehoiada the priest. 

#### 2 Kings 11:10 And {gave the priest} to the commanders of a hundred the spears and the shields of king David, of the ones in the house of the LORD. 

#### 2 Kings 11:11 And {stood the bodyguards each}, and his weapon was in his hand, at the protrusion of the house at the right, unto the protrusion of the house at the left of the altar, and of the house around the king round about. 

#### 2 Kings 11:12 And he brought forth the son of the king, and he put upon him the diadem, and the testimony. And he anointed him, and gave him reign. And they clapped their hands, and said, Let {live the king}! 

#### 2 Kings 11:13 And Athaliah heard the sound of the running of the people, and she went to the people into the house of the LORD. 

#### 2 Kings 11:14 And she saw. And behold, the king stood at the column according to their practice. And the singers and the ones with trumpets were around the king. And all the people of the land were rejoicing, and trumpeting with trumpets. And Athaliah tore her garments, and she yelled, Conspiracy, conspiracy. 

#### 2 Kings 11:15 And {gave charge Jehoiada the priest} to the commanders of hundreds, and to the overseers of the force, and said to them, Lead her outside the ranks and the one entering after her! To death she shall be put to death by the broadsword. For {said the priest}, She should not die in the house of the LORD. 

#### 2 Kings 11:16 And they put {upon her hands}, and she entered by way of the entrance of the horses of the house of the king. And they put her to death there. 

#### 2 Kings 11:17 And Jehoiada ordained a covenant between the LORD and between the king and between the people, for them to be a people to the LORD. 

#### 2 Kings 11:18 And {entered all the people of the land} into the house of Baal, and they tore it down. And his altars, and his images they broke diligently. And Mathan the priest of Baal they killed before the face of the altars. And {established the priest} overseers in the house of the LORD. 

#### 2 Kings 11:19 And he took the commanders of hundreds, and the patrol, and the couriers, and all the people of the land. And they led the king from the house of the LORD, and entered the way of the gate of the bodyguards of the house of the king. And they seated him upon the throne of the kings. 

#### 2 Kings 11:20 And {rejoiced all the people of the land}, and the city was still. And Athaliah they put to death by the broadsword in the house of the king. 

#### 2 Kings 11:21 {was a son seven years Joash} in his taking reign. 

#### 2 Kings 12:1 {in year the seventh of Jehu reigned Joash}, and forty years he reigned in Jerusalem. And the name of his mother was Zibiah of Beer-sheba. 

#### 2 Kings 12:2 And Joash did the upright thing before the LORD all the days which {enlightened him Jehoiada the priest}. 

#### 2 Kings 12:3 Only the high places he did not remove, and {there still the people sacrificed}, and burned incense in the high places. 

#### 2 Kings 12:4 And Joash said to the priests, All the money of the holy things coming in as income into the house of the LORD, the money of the valuation of a man, the money of valuation of souls, all money what ever ascends upon the heart of a man to bring in the house of the LORD, 

#### 2 Kings 12:5 let {take it for themselves the priests}! every man from their sale, and they shall repair the breach of the house in all the places where ever {should be found there a breach}. 

#### 2 Kings 12:6 And it came to pass in the twentieth and third year of king Joash, {did not repair that the priests} the breach of the house. 

#### 2 Kings 12:7 And {called Joash the king} Jehoiada the priest, and the priests, and he said to them, Why is it that {was not repaired the breach of the house}? And now, do not take the money from your sales! for unto the breach of the house you shall appoint it. 

#### 2 Kings 12:8 And {joined in harmony the priests} to not take money from the people, and to not strengthen the breach of the house. 

#### 2 Kings 12:9 And {took Jehoiada the priest} {chest one}, and he made in it {opening one}, and he put it by the altar, at the right side of the ones entering of men into the house of the LORD. And {gave there the priests guarding at the thresholds} all the money being carried into the house of the LORD. 

#### 2 Kings 12:10 And it came to pass as they saw that there was much money in the chest, that {ascended the scribe of the king}, and the {priest great}, and they grasped and counted the money being found in the house of the LORD. 

#### 2 Kings 12:11 And they gave the money being prepared into the hands of the ones doing the works of the ones overseeing the house of the LORD. And they handed over to the fabricators of the wood items, and to the builders doing work in the house of the LORD, 

#### 2 Kings 12:12 and to the stonemasons, and to the quarriers of the stones; to acquire wood and {stones quarried}, to repair the breach of the house of the LORD, for all as much as was spent upon the house to repair it. 

#### 2 Kings 12:13 Only they were not to make for the house of the LORD {doors silver}, nails, bowls, and trumpets, or any {item gold}, or {item silver} from out of the money being carried in the house of the LORD. 

#### 2 Kings 12:14 For to the ones doing the works they gave it. And they repaired by it the house of the LORD. 

#### 2 Kings 12:15 And they did not call into account the men to whom was given the money into their hands, to give to the ones doing the work; for {in trust they were acting}. 

#### 2 Kings 12:16 But money for a trespass offering, and money for a sin offering was not carried into the house of the LORD, for {to the priests it was}. 

#### 2 Kings 12:17 Then {ascended up Hazael king of Syria}, and waged war against Gath, and was first to take it. And Hazael arranged his face to ascend against Jerusalem. 

#### 2 Kings 12:18 And {took Joash king of Judah} all the holy things which Jehoshaphat sanctified, and Jehoram, and Ahaziah, his fathers, kings of Judah, and his holy things, and all the gold being found in the treasuries of the house of the LORD, and of the house of the king, and sent them to Hazael king of Syria. And he ascended away from Jerusalem. 

#### 2 Kings 12:19 And the rest of the words of Joash, and all as many things as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 12:20 And {rose up his servants}, and they made a conspiracy; and they struck Joash in the house of Millo, the one in the descent to Silla. 

#### 2 Kings 12:21 And Jozachar son of Shimeath, and Jehozabad son of Shomer, his servants struck him, and he died. And they entombed him with his fathers in the city of David. And {reigned Amaziah his son} instead of him. 

#### 2 Kings 13:1 In {year the twentieth and third} of Joash son of Ahaziah king of Judah, {reigned Jehoahaz son of Jehu} over Israel in Samaria seventeen years. 

#### 2 Kings 13:2 And he did the wicked thing in the eyes of the LORD, and went after the sins of Jeroboam son of Nebat, who led Israel into sin. He did not abstain from them. 

#### 2 Kings 13:3 And {was provoked in anger to rage the LORD} against Israel. And he gave them into the hand of Hazael king of Syria, and in the hand of the son of Hadad, son of Hazael all the days. 

#### 2 Kings 13:4 And Jehoahaz beseeched the face of the LORD, and {heeded him the LORD}. For he beheld the affliction of Israel, because {afflicted them the king of Syria}. 

#### 2 Kings 13:5 And the LORD gave deliverance to Israel, and Israel came forth from beneath the hand of Syria. And {sat the sons of Israel} in their tents as yesterday and the third day before. 

#### 2 Kings 13:6 Only they did not abstain from the sins of the house of Jeroboam, who led Israel into sin; {by them they went}. And indeed the sacred grove was established in Samaria. 

#### 2 Kings 13:7 For there was not left behind to Jehoahaz a people, but only fifty horsemen, and ten chariots, and ten thousand footmen, for {destroyed them the king of Syria}, and he appointed them as dust for trampling. 

#### 2 Kings 13:8 And the rest of the words of Jehoahaz, and all as much as he did, and his dominations, behold are not these written upon the scroll of the words of the days of the kings of Israel? 

#### 2 Kings 13:9 And Jehoahaz slept with his fathers, and they entombed him in Samaria. And {reigned Joash his son} instead of him. 

#### 2 Kings 13:10 In the thirtieth and seventh year of Joash king of Judah, {reigned Joash son of Jehoahaz} over Israel in Samaria sixteen years. 

#### 2 Kings 13:11 And he did the wicked thing in the eyes of the LORD. He did not abstain from all the sins of Jeroboam son of Nebat, who led Israel into sin -- {by them he went}. 

#### 2 Kings 13:12 And the rest of the words of Joash and all as much as he did, and his dominations which he did with Amaziah king of Judah, have these not been written upon the scroll of the words of the days of the kings of Israel? 

#### 2 Kings 13:13 And Joash slept with his fathers. And Jeroboam sat upon his throne. And Joash was entombed in Samaria with the kings of Israel. 

#### 2 Kings 13:14 And Elisha became ill with his illness of which he died. And {went down Joash king of Israel} to him and wept upon his face, and said, O father, O father, the chariot of Israel and his horseman. 

#### 2 Kings 13:15 And {said to him Elisha}, Take a bow and arrows. And he took to himself a bow and arrows. 

#### 2 Kings 13:16 And he said to the king of Israel, Set your hand upon the bow! And he set his hand. And Elisha placed his hands upon the hands of the king. 

#### 2 Kings 13:17 And he said, Open the window according to the east! And he opened. And Elisha said, Shoot! And he shot. And he said, The arrow of deliverance of the LORD, and the arrow of deliverance in Syria. And you shall strike Syria in Aphek until completion. 

#### 2 Kings 13:18 And {said to him Elisha}, Take arrows! And he took. And he said to the king of Israel, Strike against the ground! And he struck three times and stopped. 

#### 2 Kings 13:19 And {fretted over him the man of God}, and he said, If you struck five times or six times, then you would have struck the Syrian until completion. And now three times you shall strike Syria. 

#### 2 Kings 13:20 And Elisha died, and they entombed him. And armed bands of Moab came in the land at the coming of the year. 

#### 2 Kings 13:21 And it came to pass as they were entombing the man, that behold, they beheld the armed band, and they tossed the man in the burying-place of Elisha, and it went and touched the bones of Elisha. And he came alive, and rose upon his feet. 

#### 2 Kings 13:22 And Hazael king of Syria squeezed against Israel all the days of Jehoahaz. 

#### 2 Kings 13:23 And the LORD showed mercy on them, and pitied them, and looked upon them on account of his covenant, the one with Abraham, and Isaac, and Jacob. And {did not want the LORD} to utterly destroy them, and he did not throw them from his face until now. 

#### 2 Kings 13:24 And {died Hazael king of Syria}, and {reigned the son of Hadad his son} instead of him. 

#### 2 Kings 13:25 And {returned Joash son of Jehoahaz} and took the city from out of the hand of the son of Hadad, son of Hazael, the ones who took it from out of the hand of Jehoahaz his father in the war. Three times {struck him Joash}, and he returned the cities of Israel. 

#### 2 Kings 14:1 In {year the second} of Joash son of Jehoahaz king of Israel, {reigned Amaziah son of Joash king of Judah}. 

#### 2 Kings 14:2 {a son being twenty and five years old He was} in his reigning. And twenty and nine years he reigned in Jerusalem. And the name of his mother was Jehoaddan of Jerusalem. 

#### 2 Kings 14:3 And he did upright in the eyes of the LORD, only not as David his father. According to all as much as {did Joash his father} he did. 

#### 2 Kings 14:4 Only the high places he did not remove, and still the people sacrificed and burned incense in the high places. 

#### 2 Kings 14:5 And it came to pass when {grew strong the kingdom} in his hand, that he struck his servants, the ones striking his father. 

#### 2 Kings 14:6 And the sons of the ones striking he did not put to death, as it is written upon the scroll of the law of Moses, as the LORD gave charge, saying, {shall not die Fathers} for the sons, and the sons shall not die for the fathers, but only each for his sin shall he die. 

#### 2 Kings 14:7 He struck Edom in Gemela -- ten thousand. And he seized Rock in the war, and he called its name, Joktheel until this day. 

#### 2 Kings 14:8 Then Amaziah sent messengers to Joash son of Jehoahaz son of Jehu king of Israel, saying, Come, we should see faces. 

#### 2 Kings 14:9 And {sent Joash king of Israel} to Amaziah king of Judah, saying, The thorn in Lebanon sent to the cedar in Lebanon, saying, Give your daughter to my son for a wife! And {went through the wild beasts} the field in Lebanon, and trampled upon the thorn. 

#### 2 Kings 14:10 Having beaten you struck Edom, and {encouraged you your heart}. Be glorified sitting down in your house. And why do you contend in your evil, that you shall fall and Judah with you? 

#### 2 Kings 14:11 And {did not hearken Amaziah}. And {ascended Joash king of Israel}, and {saw faces he and Amaziah king of Judah} in Beth-shemesh of Judea. 

#### 2 Kings 14:12 And Judah failed from in front of Israel, and {fled each man} to his tent. 

#### 2 Kings 14:13 And {Amaziah son of Joash son of Ahaziah king of Judah seized Joash king of Israel} in Beth-shemesh. And he came into Jerusalem and demolished in the wall of Jerusalem at the gate of Ephraim unto the gate of the corner -- four hundred cubits. 

#### 2 Kings 14:14 And he took the gold, and the silver, and all the items being found in the house of the LORD, and in the treasuries of the house of the king, and of the sons of the alliances, and he returned unto Samaria. 

#### 2 Kings 14:15 And the rest of the words of Joash, as much as he did in his domination in which he waged war with Amaziah king of Judah, are not these written upon the scroll of the words of the days of the kings of Israel? 

#### 2 Kings 14:16 And Joash slept with his fathers, and they entombed him in Samaria with the kings of Israel. And {reigned Jeroboam his son} instead of him. 

#### 2 Kings 14:17 And {lived Amaziah son of Joash king of Judah} after the dying of Joash son of Jehoahaz king of Israel fifteen years. 

#### 2 Kings 14:18 And the rest of the words of Amaziah, and all as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 14:19 And they confederated against him with a confederation in Jerusalem. And he fled unto Lachish. And they sent after him unto Lachish, and put him to death there. 

#### 2 Kings 14:20 And they lifted him upon the horses, and he was entombed in Jerusalem with his fathers in the city of David. 

#### 2 Kings 14:21 And {took all the people of Judah} Azariah, and he was a son sixteen years old, and they gave him reign instead of his father Amaziah. 

#### 2 Kings 14:22 He built Elath, and returned it to Judah after {slept the king} with his fathers. 

#### 2 Kings 14:23 In {year the fifteenth} of Amaziah son of Joash king of Judah, {reigned Jeroboam son of Joash} over Israel in Samaria -- forty and one year. 

#### 2 Kings 14:24 And he did the wicked thing before the LORD. He did not abstain from all of the sins of Jeroboam son of Nebat, who led Israel into sin. 

#### 2 Kings 14:25 He restored the boundary of Israel from the entrance of Hamath unto the sea of the Arabah, according to the saying of the LORD God of Israel, who spoke by the hand of his servant Jonah, son of Amittai, the prophet, the one from out of Gath-hepher. 

#### 2 Kings 14:26 For the LORD beheld the humiliation of Israel, {bitter that it was exceedingly}, and very few, and being held together, and being depleted, and being abandoned, and there was no one helping Israel. 

#### 2 Kings 14:27 And {did not speak the LORD} to wipe away the name of Israel from beneath heaven. And he delivered them by the hand of Jeroboam son of Joash. 

#### 2 Kings 14:28 And the rest of the words of Jeroboam, and all as much as he did, and his dominations, as much as he waged war, and as much as he returned Damascus and Hamath to Judah in Israel, behold are not these written upon the scroll of the words of the days of the kings of Israel? 

#### 2 Kings 14:29 And Jeroboam slept with his fathers with the kings of Israel. And {reigned Zechariah his son} instead of him. 

#### 2 Kings 15:1 In {year the twentieth and seventh} of Jeroboam king of Israel, {reigned Azariah son of Amaziah king of Judah}. 

#### 2 Kings 15:2 {a son being sixteen years old He was} in his reign, and fifty-two years he reigned in Jerusalem. And the name of his mother was Jecholiah of Jerusalem. 

#### 2 Kings 15:3 And he did the upright thing in the eyes of the LORD according to all as much as {did Amaziah his father}. 

#### 2 Kings 15:4 Only the high places he did not remove, and still the people sacrificed and burned incense in the high places. 

#### 2 Kings 15:5 And the LORD touched the king, and he was being leprous until the day of his death, and he reigned in a house apart. And Jotham son of the king was over the house, judging the people of the land. 

#### 2 Kings 15:6 And the rest of the words of Azariah and all as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 15:7 And Azariah slept with his fathers. And they entombed him with his fathers in the city of David. And {reigned Jotham his son} instead of him. 

#### 2 Kings 15:8 In {year the thirtieth and eighth} of Azariah king of Judah, {reigned Zechariah son of Jeroboam} over Israel in Samaria six months. 

#### 2 Kings 15:9 And he did the wicked thing in the eyes of the LORD as did his fathers. He did not abstain from the sins of Jeroboam son of Nebat, who led Israel into sin. 

#### 2 Kings 15:10 And {confederated against him Shallum son of Jabesh}, and he struck him in Keblaam, and killed him, and reigned instead of him. 

#### 2 Kings 15:11 And the rest of the words of Zechariah, behold, these are written upon the scroll of the words of the days of the kings of Israel. 

#### 2 Kings 15:12 This is the word of the LORD which he spoke to Jehu, saying, {sons unto the fourth generation shall sit Your} upon the throne of Israel. And it became so. 

#### 2 Kings 15:13 And Shallum son of Jabesh reigned in {year the thirtieth and ninth} of Azariah king of Judah, and he reigned a month of days in Samaria. 

#### 2 Kings 15:14 And {ascended Menahem son of Gadi from Tirzah}, and came into Samaria, and he struck Shallum son of Jabesh in Samaria, and he killed him, and he reigned instead of him. 

#### 2 Kings 15:15 And the rest of the words of Shallum, and of his confederacy which he confederated, behold, these are written upon the scroll of the words of the days of the kings of Israel. 

#### 2 Kings 15:16 Then Menahem struck Tiphsah, and all the ones in it, and its borders from Tirzah; for it did not open up to him, and he struck it; and the ones {one in the womb having} he tore asunder. 

#### 2 Kings 15:17 In {year the thirtieth and ninth} of Azariah king of Judah {reigned Menahem son of Gadi} over Israel in Samaria ten years. 

#### 2 Kings 15:18 And he did the wicked thing in the eyes of the LORD. He did not abstain from the sins of Jeroboam son of Nebat, who led Israel to sin. 

#### 2 Kings 15:19 In his days {ascended Pul king of the Assyrians} upon the land. And Menahem gave to Pul a thousand talents of silver {to be for his hand} with him, to strengthen his kingdom in his hand. 

#### 2 Kings 15:20 And Menahem brought forth the silver for Israel, excised upon every mighty man in strength, to give to the king of the Assyrians -- fifty shekels for the {man one}. And {returned the king of the Assyrians} and did not station there in the land. 

#### 2 Kings 15:21 And the rest of the words of Menahem, and all as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Israel? 

#### 2 Kings 15:22 And Menahem slept with his fathers. And {reigned Pekahiah his son} instead of him. 

#### 2 Kings 15:23 In {year the fiftieth} of Azariah king of Judah, {reigned Pekahiah son of Menahem} over Israel in Samaria two years. 

#### 2 Kings 15:24 And he did the wicked thing in the eyes of the LORD. He did not abstain from the sins of Jeroboam son of Nebat, who led Israel into sin. 

#### 2 Kings 15:25 And {confederated against him Pekah son of Remaliah his tribune}, and he struck him in Samaria, before the house of the king, with Argob, and with Arieh, and with him fifty men from the sons of the Gileadites. And he killed him, and reigned instead of him. 

#### 2 Kings 15:26 And the rest of the words of Pekahiah, and all as much as he did, behold, these are written upon the scroll of the words of the days of the kings of Israel. 

#### 2 Kings 15:27 In {year the fiftieth and second} of Azariah king of Judah {reigned Pekah son of Remaliah} over Israel in Samaria twenty years. 

#### 2 Kings 15:28 And he did the wicked thing in the eyes of the LORD. He did not abstain from all the sins of Jeroboam son of Nebat, who led Israel into sin. 

#### 2 Kings 15:29 In the days of Pekah king of Israel came Tiglath-pileser king of the Assyrians, and he took Ijon, and Abel-beth-maachah, and Janoah, and Kenez, and Hazor, and Gilead, and Galilee, all the land of Naphtali, and he resettled them among Assyria. 

#### 2 Kings 15:30 And {confederated a confederation Hoshea son of Elah} against Pekah son of Remaliah, and he struck him, and killed him, and he reigned instead of him in {year the twentieth} of Jotham son of Uzziah. 

#### 2 Kings 15:31 And the rest of the words of Pekah, and all as much as he did, behold, these are written upon the scroll of the words of the days of the kings of Israel. 

#### 2 Kings 15:32 In {year the second} of Pekah son of Remaliah king of Israel {reigned Jotham son of Uzziah king of Judah}. 

#### 2 Kings 15:33 {a son being twenty and five years old He was} in his taking reign, and sixteen years he reigned in Jerusalem. And the name of his mother was Jerusha, daughter of Zadok. 

#### 2 Kings 15:34 And he did upright in the eyes of the LORD according to all as much as {did Uzziah his father}. 

#### 2 Kings 15:35 Only the high places he did not remove, and still the people sacrificed and burned incense on the high places. He built the gate of the house of the LORD -- the upper. 

#### 2 Kings 15:36 And the rest of the words of Jotham and all as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 15:37 In those days the LORD began to send against Judah Rezin king of Syria, and Pekah son of Remaliah. 

#### 2 Kings 15:38 And Jotham slept with his fathers, and they entombed him with his fathers in the city of David his father. And {reigned Ahaz his son} instead of him. 

#### 2 Kings 16:1 In {year the seventeenth} of Pekah son of Remaliah, {reigned Ahaz son of Jotham king of Judah}. 

#### 2 Kings 16:2 {a son being twenty years old Ahaz was} in his reigning. And sixteen years he reigned in Jerusalem, and he did not do the upright thing in the eyes of the LORD his God as David his father. 

#### 2 Kings 16:3 And he went in the way of the kings of Israel, and indeed {his son he led} through fire, according to the abominations of the nations, which the LORD removed in front of the sons of Israel. 

#### 2 Kings 16:4 And he sacrificed and burned incense in the high places, and upon the hills, and underneath every tree of the woods. 

#### 2 Kings 16:5 Then {ascended Rezin king of Syria}, and Pekah son of Remaliah king of Israel, to Jerusalem for war. And they made assault against Ahaz, and they were not able to wage war. 

#### 2 Kings 16:6 In that time {returned Rezin king of Syria} Elath to Syria, and cast out the Jews from Elath. And the Edomites came into Elath, and they dwelt there until this day. 

#### 2 Kings 16:7 And Ahaz sent messengers to Tiglath-pileser king of the Assyrians, saying, {your servant and your son I am}. Ascend and deliver me from the hand of the king of Syria and from the hand of the king of Israel! the ones rising up against me. 

#### 2 Kings 16:8 And Ahaz took the silver and the gold he found in the treasuries of the house of the LORD and of the house of the king, and he sent {to the king of the Assyrians gifts}. 

#### 2 Kings 16:9 And {heard him the king of the Assyrians}. And {ascended up the king of the Assyrians} against Damascus, and he seized it, and he resettled it, and he killed Rezin. 

#### 2 Kings 16:10 And {went king Ahaz} to meet Tiglath-pileser king of the Assyrians in Damascus. And he saw the altar, the one in Damascus. And {sent king Ahaz} to Urijah the priest the likeness of the altar, and the proportions of it, according to all its makings. 

#### 2 Kings 16:11 And {built Urijah the priest} the altar according to all as much as {sent king Ahaz} from Damascus. Thus {did Urijah the priest} until the coming of the king from Damascus. 

#### 2 Kings 16:12 And {came the king} from Damascus. And {beheld the king} the altar. And {drew near to the altar the king}, and ascended unto it. 

#### 2 Kings 16:13 And he offered his whole burnt-offering, and his sacrifice offering; and {of his libation offering he offered a libation} to it; and he poured upon it the blood {peace offerings of his} -- upon the altar, 

#### 2 Kings 16:14 And the brass altar which was before the LORD he brought forward in front of the house of the LORD, from between the altar and from between the house of the LORD. And he put it by the side of the altar according to the north. 

#### 2 Kings 16:15 And {gave charge king Ahaz} to Uriah the priest, saying, Upon the {altar great} offer the whole burnt-offering, the early morning sacrifice, and the {sacrifice offering the evening}, and the whole burnt-offerings of the king, and his sacrifice offerings, and the whole burnt-offering of all the people, and their sacrifice offerings, and their libation offerings! And all the blood of the whole burnt-offering, and all the blood of the sacrifice offering {upon it you shall pour out}! And the altar of brass will be for me in the morning. 

#### 2 Kings 16:16 And {did Urijah the priest} according to all as much as {gave charge to him Ahaz the king}. 

#### 2 Kings 16:17 And {cut down king Ahaz} the joinery of the bases, and he moved {from them the bathing tub}; and the sea he lowered from the oxen of brass, of the ones underneath it, and he put it upon {base a stone}. 

#### 2 Kings 16:18 And the foundation of the chair of the Sabbaths he built in the house of the LORD, and the entrance of the king the one outside, he turned in the house of the LORD from in front of the king of the Assyrians. 

#### 2 Kings 16:19 And the rest of the words of Ahaz, as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 16:20 And Ahaz slept with his fathers, and he was entombed with his fathers in the city of David. And {reigned Hezekiah his son} instead of him. 

#### 2 Kings 17:1 In {year the twelfth} of Ahaz king of Judah, {reigned Hoshea son of Elah} in Samaria over Israel for nine years. 

#### 2 Kings 17:2 And he did the wicked thing in the eyes of the LORD, only not as the kings of Israel who were before him. 

#### 2 Kings 17:3 Against him there ascended Shalmaneser king of the Assyrians; and {became to him Hoshea} as a servant, and he bore {to him gifts}. 

#### 2 Kings 17:4 And {found the king of the Assyrians by Hoshea a plot}, for Hoshea sent messengers to So king of Egypt, and did not bring gifts to the king of the Assyrians year by year. And {assaulted him the king of the Assyrians}, and tied him up in the house of the prison. 

#### 2 Kings 17:5 And the king of the Assyrians ascended unto all the land, and ascended unto Samaria, and assaulted it for three years. 

#### 2 Kings 17:6 In {year the ninth} of Hoshea, {seized the king of the Assyrians} Samaria, and he resettled Israel into Assyria, and he settled them in Halah and in Habor, the rivers of Gozan, in the mountains of the Medes. 

#### 2 Kings 17:7 And it came to pass that {sinned the sons of Israel} against the LORD their God, the one leading them from out of the land of Egypt, from beneath the hand of Pharaoh king of Egypt, and they feared {gods other}. 

#### 2 Kings 17:8 And they went by the ordinances of the nations which the LORD removed in front of the sons of Israel, and the kings of Israel as many as they did. 

#### 2 Kings 17:9 And {clothed the sons of Israel} words of wrongdoings against the LORD their God. And they built to themselves high places in all their cities, from {tower guard} unto {city fortified}. 

#### 2 Kings 17:10 And they set up to themselves stone monuments and sacred groves upon every {hill high}, and underneath every tree of the woods. 

#### 2 Kings 17:11 And they burned incense there in all the high places, as the nations which the LORD moved far away from their face. And they made partners, and they graved images to provoke {to anger the LORD}. 

#### 2 Kings 17:12 And they served to the idols which the LORD said to them, Do not do this thing! 

#### 2 Kings 17:13 And the LORD testified to Israel, and to Judah, by the hand of all his prophets, every one of them seers, saying, Turn from {ways your wicked}, and guard my commandments, and my ordinances, and every law! which I gave charge to your fathers, as many as I sent to them by the hand of my servants the prophets. 

#### 2 Kings 17:14 And they did not hearken, and they hardened their back above the back of their fathers, the ones that trusted not in the LORD their God; 

#### 2 Kings 17:15 even thrusting away his covenant, and the ordinances which he ordained with their fathers, and his testimonies, as many as he testified to them; and they went after the vain things, and acted in folly, and followed after the nations surrounding them, which the LORD gave charge to them to not do according to these things. 

#### 2 Kings 17:16 And they abandoned the commandments of the LORD their God, and they made for themselves molten castings of two heifers, and they made a sacred grove, and did obeisance to all the military of the heaven, and they served to Baal. 

#### 2 Kings 17:17 And they led their sons and their daughters through fire. And they used oracles of divinations, and they foretold. And they were sold to do the wicked thing in the eyes of the LORD, to provoke him to anger. 

#### 2 Kings 17:18 And the LORD was enraged exceedingly with Israel, and he removed them from his face. He did not leave any behind except the tribe of Judah alone. 

#### 2 Kings 17:19 And indeed Judah did not guard the commandments of the LORD his God, and they went by the ordinances of Israel, which they did, and they thrusted away the LORD. 

#### 2 Kings 17:20 And the LORD was enraged with all the seed of Israel, and he shook them off, and gave them into the hand of the ones tearing them in pieces, until of which time he threw them away from his face. 

#### 2 Kings 17:21 Except that Israel was torn from the house of David; and they gave reign to Jeroboam son of Nebat. And Jeroboam banished Israel from following the LORD, and he led them into sin -- {sin a great}. 

#### 2 Kings 17:22 And {went the sons of Israel} in all the sins of Jeroboam which he did -- they did not abstain from them; 

#### 2 Kings 17:23 until of which time the LORD removed Israel from his face, as the LORD spoke by the hand of all his servants the prophets. And Israel was resettled from its land into Assyria until this day. 

#### 2 Kings 17:24 And {led the king of the Assyrians} from out of Babylon the one from out of Cuthah, and from out of Ava, and from out of Hamath, and Sepharvaim, and settled them in the cities of Samaria instead of the sons of Israel. And they inherited Samaria, and they settled in its cities. 

#### 2 Kings 17:25 And it came to pass in the beginning of their place of sitting down, they did not fear the LORD. And the LORD sent among them the lions, and they were being killed by them. 

#### 2 Kings 17:26 And they said to the king of the Assyrians, saying, The nations which you resettled and relocated, in the cities of Samaria, they know not the distinguishing manner of the God of the land. And he sent to them lions, and behold, they are killing them, in so far as they do not know the distinguishing manner of the God of the land. 

#### 2 Kings 17:27 And {gave charge the king of the Assyrians}, saying, Lead away there one of the priests whom I resettled from Samaria! and let him go and let him dwell there! and he shall enlighten them on the distinguishing manner of the God of the land. 

#### 2 Kings 17:28 And they brought one of the priests which they resettled from Samaria, and he settled in Bethel. And he was enlightening them how they should fear the LORD. 

#### 2 Kings 17:29 And {were making nation by nation} their gods. And they put them in the houses of the high places, which {made the Samaritans}, nation by nation in their cities in which they dwelt. 

#### 2 Kings 17:30 And the men of Babylon made Succoth Benoth. And the men of Cuth made Nergal. And the men of Hamath made Ashima. 

#### 2 Kings 17:31 And the Avites made Nibhaz and Tartak. And the Sepharvites incinerated their sons by fire to Adrammelech and Anammelech, gods of the Sepharvaim. 

#### 2 Kings 17:32 And they were fearing the LORD, and they made for themselves priests of the high places; and they offered for themselves in the houses of the high places. 

#### 2 Kings 17:33 {the LORD They were fearing}, and {their gods they served}, according to the distinguishing manner of the nations from where he resettled them from there. 

#### 2 Kings 17:34 Until this day they do according to their distinguishing manner. They are not fearing the LORD, and they do not do according to their ordinances, and according to their judgment, and according to the law, and according to the commandment which the LORD gave charge to the sons of Jacob, of whom he established his name Israel. 

#### 2 Kings 17:35 And the LORD ordained with them a covenant, and he gave charge to them, saying, You shall not fear {gods other}, and you shall not do obeisance to them, and you shall not serve to them, and you shall not sacrifice to them. 

#### 2 Kings 17:36 For only to the LORD, who led you from out of the land of Egypt with {strength great} and with {arm a high}, him you shall fear, and to him you shall do obeisance, and to him you shall sacrifice. 

#### 2 Kings 17:37 And his ordinances, and the judgments, and the commandments, and the law which he wrote for you, you shall guard to do all the days, and you shall not fear {gods other}. 

#### 2 Kings 17:38 And the covenant which he ordained with you you shall not forget; and you shall not fear {gods other}. 

#### 2 Kings 17:39 For only the LORD your God -- him you shall fear; and he will rescue you from the hand of all your enemies. 

#### 2 Kings 17:40 And they hearkened not, but only in {ordinances their former} they acted. 

#### 2 Kings 17:41 And {were nations these} fearing the LORD, and {to their carvings they served}; even indeed their sons, and the sons of their sons -- {as did their fathers they do} unto this day. 

#### 2 Kings 18:1 And it came to pass in {year the third} of Hoshea son of Elah king of Israel, {reigned Hezekiah son of Ahaz king of Judah}. 

#### 2 Kings 18:2 {a son being twenty and five years old He was} in his taking reign, and twenty and nine years he reigned in Jerusalem. And the name of his mother was Abi, daughter of Zachariah. 

#### 2 Kings 18:3 And he did upright in the eyes of the LORD, according to all as much as {did David his father}. 

#### 2 Kings 18:4 He removed the high places, and he broke the monuments, and {the sacred groves he cut down}, and he cut up the serpent of brass which Moses made; for unto those days {were the sons of Israel} burning incense to it. And he called it Nehushtan. 

#### 2 Kings 18:5 In the LORD God of Israel he hoped, there was not {after him one likened to him} among the kings of Judah, and among the ones taking place before him. 

#### 2 Kings 18:6 And he cleaved to the LORD. He did not leave from behind him, and he guarded his commandments, as many as the LORD gave charge to Moses. 

#### 2 Kings 18:7 And the LORD was with him; in all the things which he did he perceived. And he annulled allegiance to the king of the Assyrians, and he did not serve to him. 

#### 2 Kings 18:8 He struck the Philistines unto Gaza, and unto its border, from the tower of the ones guarding, and unto {city the fortified}. 

#### 2 Kings 18:9 And it came to pass in the {year fourth} to king Hezekiah, this is {year the seventh} of Hoshea son of Elah king of Israel, ascended Shalmaneser king of the Assyrians against Samaria, and assaulted it. 

#### 2 Kings 18:10 And he overtook it at the end of three years. In {year the sixth} of Hezekiah -- this is {year the ninth} of Hoshea king of Israel, Samaria was seized. 

#### 2 Kings 18:11 And {resettled the king of the Assyrians} the Samarian into Assyria, and he put them in Halah, and in Habor by the river Gozan, and in the mountains of the Medes; 

#### 2 Kings 18:12 because they did not hearken to the voice of the LORD their God, and they violated his covenant, all as much as he gave charge to Moses the manservant of the LORD; and they did not hearken, and they did not do. 

#### 2 Kings 18:13 And in the fourteenth year of king Hezekiah {ascended Sennacherib king of the Assyrians} against the {cities of Judah fortified}, and he seized them. 

#### 2 Kings 18:14 And {sent Hezekiah king of Judah} messengers to the king of the Assyrians, to Lachish, saying, I have sinned, turn from me! What ever you should place upon me I will bear. And {placed a tribute the king of the Assyrians} upon Hezekiah king of Judah of three hundred talents of silver and thirty talents of gold. 

#### 2 Kings 18:15 And Hezekiah gave all the silver he found in the house of the LORD, and in the treasuries of the house of the king. 

#### 2 Kings 18:16 In that time {cut off Hezekiah king of Judah} the doors of the temple of the LORD, and the supports which {gilded Hezekiah the king of Judah}, and gave them to the king of the Assyrians. 

#### 2 Kings 18:17 And {sent the king of the Assyrians} Tartan, and Rabsaris, and Rabshakeh from Lachish to king Hezekiah with {force a heavy} to Jerusalem. And they ascended, and came to Jerusalem. And they stood by the aqueduct of the upper pool, which is in the way of the field of the fuller. 

#### 2 Kings 18:18 And they yelled to Hezekiah. And {came to them Eliakim son of Hilkiah the manager}, and Shebna the scribe, and Joah the son of Asaph the one taking record. 

#### 2 Kings 18:19 And {said to them Rabshakeh}, Say indeed to Hezekiah, Thus says the {king great}, the king of the Assyrians, What is this reliance which you yield on? 

#### 2 Kings 18:20 How then do words of the lips and counsel {the battle array become} for war? Now then, upon whom are you relying upon, that you annulled allegiance to me? 

#### 2 Kings 18:21 Behold, are you {relying yourself} upon {rod of reed fractured this} -- upon Egypt? Thus if {should stay man} upon it, it will enter into his hand and puncture it. Thus is Pharaoh king of Egypt to all the ones relying upon him. 

#### 2 Kings 18:22 And if you should say to me, Upon the LORD our God we rely on. Is it not he that Hezekiah removed his high places and his altars, and he said to Judah and to Jerusalem, Before this altar you shall do obeisance in Jerusalem? 

#### 2 Kings 18:23 And now mix in with my master the king of the Assyrians, and I will give to you two thousand horses -- if you shall be able to put for yourself a rider upon them. 

#### 2 Kings 18:24 And how will you turn back the face {toparch of one} of the {servants of my master least of the}, and hope for yourself upon Egypt for chariots and horsemen? 

#### 2 Kings 18:25 And now, is it without the LORD that we ascended against this place to utterly destroy it? The LORD said to me, Ascend against this land and utterly destroy it! 

#### 2 Kings 18:26 And {said Eliakim son of Hilkiah and Shebna and Joah} to Rabshakeh, Speak indeed to your servants in Syrian! for we hear. And do not speak with us in Jewish to the ears of the people upon the wall! 

#### 2 Kings 18:27 And {said to them Rabshakeh}, Is it to your master, and to you {sent me my master} to speak these words? Is it not to the men, the ones sitting upon the wall, to eat their dung, and to drink their urine with you together? 

#### 2 Kings 18:28 And Rabshakeh stood and yelled {voice with a great} in Jewish, and spoke, and he said, Hear the words of the king, of the great king of the Assyrians! 

#### 2 Kings 18:29 Thus says the king, Let not {lift you Hezekiah}! for in no way should he be able to rescue you from out of my hand. 

#### 2 Kings 18:30 And let not {raise your hope Hezekiah} unto the LORD! saying, In rescuing, {will rescue us the LORD}, and and in no way shall {be delivered this city} into the hand of the king of the Assyrians. 

#### 2 Kings 18:31 Do not listen to Hezekiah! for thus says the king of the Assyrians, Do for me a blessing, and come forth to me! and {shall eat each} of his grapevine, and each of his fig tree, and {shall drink each} water of his well; 

#### 2 Kings 18:32 until whenever I should come, and I should take you into a land as your land, a land of grain and wine and bread and vineyards, a land of olive oil and honey, and you shall live and you shall not die. And do not listen to Hezekiah! for he deceives you, saying, The LORD shall deliver you. 

#### 2 Kings 18:33 Have by rescuing {rescued the gods of the nations} each his land from out of the hand of the king of the Assyrians? 

#### 2 Kings 18:34 Where is the god of Hamath, and Arphad? Where is the god of Sepharvaim -- Hena and Ivah? Did they deliver Samaria from out of my hand? 

#### 2 Kings 18:35 Who among all the gods of the lands is the one who rescued his land from out of my hand, that the LORD shall rescue Jerusalem from out of my hand? 

#### 2 Kings 18:36 And they kept silent, and did not answer him a word, because of the commandment of the king, saying, You shall not answer him. 

#### 2 Kings 18:37 And {entered Eliakim son of Hilkiah the manager}, and Shebna the scribe, and Joah son of Asaph the one recording to Hezekiah tearing their garments. And announced to him the words of Rabshakeh. 

#### 2 Kings 19:1 And it came to pass as {heard king Hezekiah}, that he tore his garments, and put on sackcloth, and entered into the house of the LORD. 

#### 2 Kings 19:2 And he sent Eliakim the manager, and Shebna the scribe, and the elders of the priests, having put on sackcloths, to Isaiah son of Amoz the prophet. 

#### 2 Kings 19:3 And they said to him, Thus says Hezekiah, A day of affliction, and of rebuke, and provocation to anger is this day; for {came the sons} unto birth pangs, and there is no strength to give birth. 

#### 2 Kings 19:4 If by any means {shall hearken to the LORD your God} all the words of Rabshakeh, whom {sent him the king of the Assyrians his master} to berate the living God, and to reprove by words which {heard the LORD your God}, that you shall take up a prayer for the remnant being found. 

#### 2 Kings 19:5 And {came the servants of king Hezekiah} to Isaiah. 

#### 2 Kings 19:6 And {said to them Isaiah}, Thus you shall say to your master, Thus says the LORD, You should not fear from the words which you heard, which {blasphemed against me the servants of the king of the Assyrians}. 

#### 2 Kings 19:7 Behold, I give a spirit to him, and he shall hear a message, and shall return unto his land, and I will cast him down by the broadsword in his land. 

#### 2 Kings 19:8 And Rabshakeh returned, and found the king of the Assyrians waging war against Libnah; for he heard that he departed from Lachish. 

#### 2 Kings 19:9 And he heard concerning Tirhakah king of the Ethiopians, saying, Behold, he comes forth to wage war against you. And he returned, and sent messengers to Hezekiah, saying, 

#### 2 Kings 19:10 Thus shall you say to Hezekiah king of Judah, Let not {you deceive your God} in whom you rely upon him, saying, In no way should Jerusalem be delivered up into the hands of the king of the Assyrians. 

#### 2 Kings 19:11 Behold, you heard all as much as {did the king of the Assyrians} in all the lands, as they utterly destroyed them; and how shall you be rescued? 

#### 2 Kings 19:12 Have {rescued the gods of the nations} which {utterly destroyed my fathers} -- both Gozan, and Haran, and Rezeph, and the sons of Eden, the ones in Thelasar? 

#### 2 Kings 19:13 Where is the king of Hamath, and the king of Arpad, and the king of the city of Sepharvaim -- Hena and Ivah? 

#### 2 Kings 19:14 And Hezekiah took the scrolls from out of the hand of the messengers and read them. And he ascended into the house of the LORD, and {unrolled them Hezekiah} before the LORD. 

#### 2 Kings 19:15 And Hezekiah prayed to the LORD, saying, O Lord God of Israel, the one sitting upon the cherubim, you are God alone among all the kingdoms of the earth. You made the heaven and the earth. 

#### 2 Kings 19:16 Lean, O LORD, your ear, and hear! Open, O LORD, your eyes, and behold! And hear the words of Sennacherib! which he sent to berate the living God. 

#### 2 Kings 19:17 For truth, O LORD, {made desolate the kings of the Assyrians} the nations, and all their land, 

#### 2 Kings 19:18 and put their gods into the fire, for {not gods they are}, but only the works of the hands of men -- wood and stone. And they destroyed them. 

#### 2 Kings 19:19 And now, O LORD our God, deliver us from out of his hand! And they shall know in all the kingdoms of the earth that you are the LORD God alone. 

#### 2 Kings 19:20 And {sent Isaiah son of Amoz} to Hezekiah, saying, Thus says the LORD God of Israel, I heard what you pray for to me concerning Sennacherib king of the Assyrians. 

#### 2 Kings 19:21 This is the word which the LORD spoke against him, {treats you with contempt and sneers at you The virgin daughter of Zion}. Over you {her head shakes the daughter of Jerusalem}. 

#### 2 Kings 19:22 Whom have you berated and blasphemed? And against whom have you raised up your voice, and lifted {into the height your eyes}? even against the holy one of Israel. 

#### 2 Kings 19:23 By the hand of your messengers you have berated the LORD, and said, By the multitude of my chariots I ascended into the height of the mountains, the sides of Lebanon, and I felled the greatness of his cedar, {chosen cypresses his}, and I came in the midst of the grove of Carmel. 

#### 2 Kings 19:24 I cooled myself and drank {waters alien}; and I made quite desolate with the sole of my feet all the rivers of the citadel. 

#### 2 Kings 19:25 Heard you not that far off I made her? From {days ancient} I formed her, and now I brought her. And she became for haughtiness {resettlements of combative cities of fortified}. 

#### 2 Kings 19:26 And the ones dwelling in them weakened in the hand. They were alarmed and were disgraced. They became as grass of the field, and as the green pasturage; as tender shoots growing on roofs, and trampled before standing. 

#### 2 Kings 19:27 And of your sitting-down, and of your exiting, and of your entering, and of your rage against me I knew. 

#### 2 Kings 19:28 On account of your being provoked to anger against me, that your indulgence ascended to my ears, and I shall put my hook in your nostrils, and bits in your lips, and I will return you in the way which you came by it. 

#### 2 Kings 19:29 And this is to you the sign. You shall eat this year the things grown by themselves, and in in the {year second} the things rising up, and {year the third} you shall sow, and you shall reap, and you shall plant vineyards, and you shall eat their fruit. 

#### 2 Kings 19:30 And he shall add to the one being preserved of the house of Judah, the one being left behind as a root below. And he shall produce fruit upward. 

#### 2 Kings 19:31 For from out of Jerusalem shall come forth a vestige, and the one rescuing from out of mount Zion. The zeal of the LORD of the forces shall do this. 

#### 2 Kings 19:32 Therefore thus says the LORD to the king of the Assyrians, He shall not enter into this city, and he shall not shoot an arrow there, and he shall not anticipate it with a shield, nor shall he pour out dirt against it for a seige mound. 

#### 2 Kings 19:33 By the way in which he came by it, he shall return; and into this city he shall not enter, says the LORD. 

#### 2 Kings 19:34 And I shall shield over this city to deliver her because of myself, and because of David my servant. 

#### 2 Kings 19:35 And it came to pass at night, that there came forth an angel of the LORD, and he struck among the camp of the Assyrians a hundred eighty-five thousand. And they rose early in the morning, and behold, all {bodies dead}. 

#### 2 Kings 19:36 And {departed and returned and went Sennacherib king of the Assyrians}, and he lived in Nineveh. 

#### 2 Kings 19:37 And it came to pass when he did obeisance in the house of Nisroch his god, Adrammelech and Sharezer his sons struck him with a sword; and they escaped into the land of Ararat. And {reigned Esar-haddon his son} instead of him. 

#### 2 Kings 20:1 In those days Hezekiah was infirm unto death. And {entered to him Isaiah son of Amoz the prophet}. And he said to him, Thus says the LORD, Give charge concerning your house! for you die, and shall not live. 

#### 2 Kings 20:2 And Hezekiah turned his face to the wall, and he prayed to the LORD, saying, 

#### 2 Kings 20:3 O LORD, remember indeed as much as I walked before you in truth, and in {heart a perfect}! and {good in your eyes I did}. And Hezekiah wept in {weeping a great}. 

#### 2 Kings 20:4 And Isaiah was in the courtyard between, and the saying of the LORD came to him, saying, 

#### 2 Kings 20:5 Return! and you shall say to Hezekiah, the one leading my people, Thus says the LORD, the God of David your father! I heard your prayer, and I beheld your tears. Behold, I shall heal you on the {day third}, and you shall ascend into the house of the LORD. 

#### 2 Kings 20:6 And I will add to your days fifteen years; and from the hand of the king of the Assyrians I will deliver you and this city. And I shall shield over this city because of myself, and because of David my servant. 

#### 2 Kings 20:7 And Isaiah said, Let them take a dried cluster of figs, and place them upon the sore! and he shall be healed. 

#### 2 Kings 20:8 And Hezekiah said to Isaiah, What is the sign that {shall heal me the LORD}, and I shall ascend into the house of the LORD on the {day third}? 

#### 2 Kings 20:9 And Isaiah said, This to you is the sign by the LORD, that the LORD shall do the word which he spoke. Shall {go the shadow} ten stairs or shall it return ten stairs. 

#### 2 Kings 20:10 And Hezekiah said, It is a light thing for the shadow to lean ten stairs, not thus, but let {return the shadow} ten stairs to the rear. 

#### 2 Kings 20:11 And {yelled out Isaiah the prophet} to the LORD, and he returned the shadow on the stairs of Ahaz, in which it went down the ten stairs, to the rear. 

#### 2 Kings 20:12 In that time {sent Berodach Baladan the son of Baladan king of Babylon} letters and gifts to Hezekiah; for he heard that Hezekiah was infirm. 

#### 2 Kings 20:13 And {rejoiced over them Hezekiah}, and showed to them all the house of the spices -- the silver, and the gold, the aromatics, and the {olive oil good}, and the house of his weapons, and all as much as was found in his treasuries. There was no place which {did not show to them Hezekiah} in his house, and in all under his authority. 

#### 2 Kings 20:14 And {entered Isaiah the prophet} to Hezekiah the king, and he said to him, What did {say men these}, and from what place came they to you? And Hezekiah said, From a land at a distance -- they came to me from Babylon. 

#### 2 Kings 20:15 And he said, What did they behold in your house? And Hezekiah said, All as much is in my house they beheld. There was nothing in my house which I did not show to them, and in my treasuries. 

#### 2 Kings 20:16 And Isaiah said to Hezekiah, Hear the word of the LORD! 

#### 2 Kings 20:17 Behold, days come, says the LORD, and there shall be taken away all the things in your house, and as much as {treasured up your fathers} until this day into Babylon. There shall not be left behind a thing, said the LORD. 

#### 2 Kings 20:18 And from your sons of the ones coming forth from you, whom you procreated, they shall take them, and they will be eunuchs in the house of the king of Babylon. 

#### 2 Kings 20:19 And Hezekiah said to Isaiah, {is good The word of the LORD} which he spoke, let there be peace and justice in my days! 

#### 2 Kings 20:20 And the rest of the words of Hezekiah, and all as much as he did, and all his dominations, and the fountain and the aqueduct, and how he brought the water into the city; behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 20:21 And Hezekiah slept with his fathers, and he was entombed in the city of David. And {reigned Manasseh his son} instead of him. 

#### 2 Kings 21:1 {a son years old being twelve Manasseh was} in his taking reign, and fifty and five years he reigned in Jerusalem. And the name of his mother was Hephzi-bah. 

#### 2 Kings 21:2 And he did the wicked thing in the eyes of the LORD; and he went according to the abominations of the nations, which the LORD removed from in front of the sons of Israel. 

#### 2 Kings 21:3 And he returned and built the high places which {tore down Hezekiah his father}. And he reestablished an altar to Baal, and made the sacred groves as did Ahab king of Israel; and did obeisance to all the military of the heaven, and he served to them. 

#### 2 Kings 21:4 And he built an altar in the house of the LORD, in which he said, In Jerusalem I will establish my name. 

#### 2 Kings 21:5 And he built altars to all the military of the heaven in the two courtyards of the house of the LORD. 

#### 2 Kings 21:6 And he led his sons through the fire, and he prognosticated, and foretold. And he made ones who deliver oracles and diviners to multiply to do the wicked thing in the eyes of the LORD, to provoke him to anger. 

#### 2 Kings 21:7 And he put the carving of the sacred grove in the house, in which the LORD said to David, and to Solomon his son, In this house, and in Jerusalem, in which I chose from out of all the tribes of Israel, that I will put my name there into the eon. 

#### 2 Kings 21:8 And I will not proceed to shake the foot of Israel from the land which I gave to their fathers; only if they should guard to do according to all which I gave charge to them, according to every law which {gave charge to them my servant Moses}. 

#### 2 Kings 21:9 And they did not hearken. And Manasseh misled them to do the wicked thing in the eyes of the LORD above the nations which the LORD removed in front of the sons of Israel. 

#### 2 Kings 21:10 And the LORD spoke by the hand of his servants the prophets, saying, 

#### 2 Kings 21:11 On account of as much as {did Manasseh king of Judah abominations these wicked} according to all as much as {did the Amorite} before him, and {into sin even indeed Judah} by his idols. 

#### 2 Kings 21:12 Is it not so? Thus says the LORD God of Israel, Behold, I bring evils upon Jerusalem and Judah, so that all hearing, it shall sound in both of his ears. 

#### 2 Kings 21:13 And I stretch out over Jerusalem the measure of Samaria, and the weight of the house of Ahab. And I will wipe Jerusalem as one wipes a writing tablet, and overturns it upon its face. 

#### 2 Kings 21:14 And I will wipe away the vestige of my inheritance, and I will deliver them into the hands of their enemies. And they will be for ravaging and for plunder by all their enemies, 

#### 2 Kings 21:15 because of as much as they did the wicked thing in my eyes, and they were provoking me to anger from the day which I led their fathers from out of Egypt, and until this day. 

#### 2 Kings 21:16 And indeed {blood innocent Manasseh poured out much exceedingly}, until of which he filled Jerusalem of it mouth to mouth; outside of his sins, which he led Judah into sin, to do the wicked thing in the eyes of the LORD. 

#### 2 Kings 21:17 And the rest of the words of Manasseh, and all as much as he did, and his sin which he sinned, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 21:18 And Manasseh slept with his fathers, and they entombed him in the garden of his house in the garden of Uzza. And {reigned Amon his son} instead of him. 

#### 2 Kings 21:19 {a son being twenty and two years old Amon was} in his taking reign. And two years he reigned in Jerusalem. And the name of his mother was Meshullemeth, daughter of Haruz from out of Jotbah. 

#### 2 Kings 21:20 And he did the wicked thing in the eyes of the LORD, as {did Manasseh his father}. 

#### 2 Kings 21:21 And he went in every way in which {went his father}, and he slaved to the idols whom {slaved to his father}, and did obeisance to them. 

#### 2 Kings 21:22 And he abandoned the LORD God of his fathers, and he did not go in the way of the LORD. 

#### 2 Kings 21:23 And {confederated the servants of Amon} against him, and they killed the king in his house. 

#### 2 Kings 21:24 And {struck the people of the land} the ones confederating against king Amon. And {gave reign to the people of the land} Josiah his son instead of him. 

#### 2 Kings 21:25 And the rest of the words of Amon, as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 21:26 And they entombed him in his tomb in the garden of Uzza. And {reigned Josiah his son} instead of him. 

#### 2 Kings 22:1 {a son being eight years old Josiah was} in his taking reign, and thirty and one year s he reigned in Jerusalem. And the name of his mother was Jedidah, daughter of Adaiah of Boseath. 

#### 2 Kings 22:2 And he did upright in the eyes of the LORD, and he went in every way of David his father. He did not separate to the right nor the left. 

#### 2 Kings 22:3 And it came to pass in the eighteenth year to king Josiah, {sent the king} Shaphan son of Azaliah, son of Meshullam, the scribe of the house of the LORD, saying, 

#### 2 Kings 22:4 Ascend to Hilkiah the {priest great}, and set a seal upon the money! the money being carried into the house of the LORD, which {gathered together the ones guarding the money} from the people. 

#### 2 Kings 22:5 And let them put it into the hand of the ones doing the works, of the ones being ordained for the house of the LORD! And he gave it to the ones doing the works in the house of the LORD, to strengthen the breach of the house, 

#### 2 Kings 22:6 to the fabricators, and to the builders, and to the stonemasons, and to acquire wood and {stones quarried}, to fortify the breach of the house. 

#### 2 Kings 22:7 Only they did not call them to account for the money being given to them, for {in trust they act}. 

#### 2 Kings 22:8 And {said Hilkiah the priest great} to Shaphan the scribe, {a scroll of the law I found} in the house of the LORD. And Hilkiah gave to Shaphan the scroll, and he read it. 

#### 2 Kings 22:9 And Shapan entered to king Josiah. And he turned to the king for a word, and said, {cast Your servants} the silver being found in the house of the LORD, and they put it in the hand of the ones doing the works being ordained in the house of the LORD. 

#### 2 Kings 22:10 And {reported Shaphan the scribe} to the king, saying, {a scroll gave to me Hilkiah the priest}. And {read it Shaphan} before the king. 

#### 2 Kings 22:11 And it came to pass as {heard the king} the words of the scroll of the law, that he tore his garments. 

#### 2 Kings 22:12 And {gave charge the king} to Hilkiah the priest, and to Ahikam son of Shaphan, and to Achbor son of Michaiah, and to Shaphan the scribe, and to Asahiah the servant of the king, saying, 

#### 2 Kings 22:13 Go, seek after the LORD for me! and for all my people, and for all Judah, concerning the words of this scroll being found; for great is the anger of the LORD burning away against us, because {hearkened not our fathers} concerning the words of this scroll, to do according to all the things being written concerning us. 

#### 2 Kings 22:14 And {went Hilkiah the priest}, and Ahikam, and Achbor, and Shaphan, and Asahiah to Huldah the prophetess, wife of Shallum son of Tikvah, son of Harhas, the keeper of the cloaks. And she dwelt in Jerusalem in Masena. And they spoke to her. 

#### 2 Kings 22:15 And she said to them, Thus says the LORD the God of Israel, Speak to the man sending you to me, 

#### 2 Kings 22:16 Thus says the LORD, Behold, I bring bad things against this place, and against the ones dwelling in it -- all the words of the scroll of which {read the king of Judah}, 

#### 2 Kings 22:17 because they abandoned me, and burned incense to other gods, that they should provoke me to anger in all the works of their hands. And {shall burn my rage} against this place, and shall not be extinguished. 

#### 2 Kings 22:18 And to the king of Judah, the one sending you to inquire of the LORD, thus you shall say to him, Thus says the LORD God of Israel concerning the words which you heard; 

#### 2 Kings 22:19 for because {was tender your heart}, and you felt shame in front of me, as you hear as much as I spoke concerning this place, and concerning the ones dwelling it, to be for extinction and for a curse, and you tore your garments, and you wept before me -- even indeed I heard, says the LORD. 

#### 2 Kings 22:20 Is it not so, behold, I add you to your fathers, and you shall be brought into your tomb in peace. And {shall not see your eyes} all the bad things which I bring against this place. And they returned to the king the word. 

#### 2 Kings 23:1 And {sent the king}, and brought together to him all the elders of Judah and Jerusalem. 

#### 2 Kings 23:2 And {ascended the king} to the house of the LORD, and all the men of Judah, and all the ones dwelling Jerusalem with him, and the priests, and the prophets, and all the people from small and unto great. And he read in their ears all the words of the scroll of the covenant of the one being found in the house of the LORD. 

#### 2 Kings 23:3 And {stood the king} near the column, and he ordained the covenant before the LORD to go after the LORD, and to guard his commandments, and his testimonies, and his orders, with a whole heart, and in the whole in life, to raise up the words of this covenant being written in this scroll. And he established all the people in the covenant. 

#### 2 Kings 23:4 And {gave charge the king} to Hilkiah the {priest great}, and to the priests being second, and to the ones guarding the doorpost, to bring out from the temple of the LORD all the items which they made to Baal, and to the sacred grove, and all the military of the heaven. And he incinerated them outside Jerusalem in the plain of Kidron, and he took their dust into Beth-el. 

#### 2 Kings 23:5 And he incinerated the idolatrous priests, of whom {appointed the kings of Judah} to burn incense in the high places, and in the cities of Judah, and in the surroundings of Jerusalem, and the ones burning incense to Baal, and to the sun, and to the moon, and to the Mazuroth, and to all the military of the heaven. 

#### 2 Kings 23:6 And he brought forth the sacred grove carving from out of the house of the LORD outside of Jerusalem unto the rushing stream Kidron. And he incinerated it at the rushing stream Kidron, and ground it fine as dust. And he tossed its dust into the tombs of the sons of the people. 

#### 2 Kings 23:7 And he demolished the house of the male prostitutes of the ones in the house of the LORD in which the women wove apparel there for the sacred grove. 

#### 2 Kings 23:8 And he brought in all the priests from the cities of Judah, and he defiled the high places where {were burning incense there the priests}, from Geba and unto Beer-sheba. And he demolished the high places by the door of the gate of Joshua ruler of the city, of the ones at the left sides of a man at the gate of the city. 

#### 2 Kings 23:9 Only {did not ascend the priests of the high places} to the altar of the LORD in Jerusalem; in no way they ate unleavened breads in the midst of their brethren. 

#### 2 Kings 23:10 And he defiled Topheth, the one in the ravine of the son of Hinnom, {to not lead for a man} his son and his daughter in fire to Molech. 

#### 2 Kings 23:11 And he incinerated the horses which {presented the kings of Judah} to the sun, in the entrance of the house of the LORD, towards the treasury room of Nathan the eunuch of the king, of the one in the compound. And the chariot of the sun he incinerated by fire. 

#### 2 Kings 23:12 And the altars, the ones upon the roof of the upper room of Ahaz, which {made the kings of Judah}, and the altars which Manasseh made in the two courtyards of the house of the LORD, {demolished the king}, and tore down from there, and tossed their dust into the rushing stream Kidron. 

#### 2 Kings 23:13 And the house upon the face of Jerusalem, the one at the right of the mount of Mosoath, which {built Solomon king of Israel} to Ashtoreth the loathsome thing of the Sidonians, and to Chemosh the loathsome thing of Moab, and to Molech the abomination of the sons of Ammon, {defiled the king}. 

#### 2 Kings 23:14 And he broke the monuments, and cut down the sacred groves, and filled their places of bones of men. 

#### 2 Kings 23:15 And indeed the {altar in Beth-el high}, which {made Jeroboam son of Nebat}, who led Israel into sin, also indeed {altar that high he tore down}, and he broke its stones, and made them fine into dust, and he incinerated the sacred grove. 

#### 2 Kings 23:16 And Josiah turned and saw the tombs of the ones being there in the mount, and he sent and took the bones from out of the tombs, and he incinerated them upon the altar, and defiled it, according to the saying of the LORD which {spoke the man of God} when Jeroboam stood near the altar in the holiday. And turning Josiah lifted his eyes upon the burying-place of the man of God, the one speaking these words; 

#### 2 Kings 23:17 and he said, What is that high rock which I see? And {said to him the men of the city}, The grave of the man of God, of the one coming from out of Judah, and calling these words which you did against the altar in Beth-el. 

#### 2 Kings 23:18 And he said, Allow him! no one move his bones! And he preserved his bones with the bones of the prophet having come from out of Samaria. 

#### 2 Kings 23:19 And indeed all the houses of the high places, of the ones in the cities of Samaria which {made the kings of Israel} to provoke the LORD to anger, Josiah removed, and he did to them according to all the works which he did in Beth-el. 

#### 2 Kings 23:20 And he sacrificed all the priests of the high places being there upon the altars. And he incinerated the bones of the men upon them. And returned to Jerusalem. 

#### 2 Kings 23:21 And {gave charge the king} to all the people, saying, Observe the passover to the LORD your God! as it is written in the scroll of this covenant. 

#### 2 Kings 23:22 For did not take place according to this passover from the days of the judges that judged Israel, and in all the days of the kings of Israel, and of the kings of Judah, 

#### 2 Kings 23:23 for only in the eighteenth year of king Josiah {took place this passover to the LORD} in Jerusalem. 

#### 2 Kings 23:24 And indeed the soothsayers, and the diviners, and the teraphim, and the idols, and all the loathsome things taking place in the land of Judah and in Jerusalem, {removed king Josiah}, that {should be established the words of the law}, the ones being written upon the scroll which {found Hilkiah the priest} in the house of the LORD. 

#### 2 Kings 23:25 {likened to him There was no king before him}, who turned towards the LORD with {entire heart his}, and with {entire life his}, and with {entire strength his}, according to all the law of Moses. And after him rose up not one like him. 

#### 2 Kings 23:26 Only {did not turn the LORD} from {rage of his anger the great} of which {was enraged anger his} against Judah, against all the provocations to anger which {provoked him to anger Manasseh}. 

#### 2 Kings 23:27 And the LORD said, And indeed Judah I shall remove from my face, as I removed Israel, and I will thrust away this city which I chose -- Jerusalem, and the house of which I said, {will be My name} there. 

#### 2 Kings 23:28 And the rest of the words of Josiah, and all as much as he did, are these not written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 23:29 In his days ascended Pharaoh Necho king of Egypt against the king of the Assyrians at the river Euphrates. And {went Josiah the king} for a meeting against him. And {killed him Necho} in Megiddo, in his seeing him. 

#### 2 Kings 23:30 And {conducted him his servants} dead in Megiddo. And they led him into Jerusalem, and they entombed him in his tomb in the city of David. And {took the people of the land} Jehoahaz son of Josiah, and anointed him and gave him reign instead of his father. 

#### 2 Kings 23:31 {a son being twenty and three years old Jehoahaz was} in his taking reign; and three months he reigned in Jerusalem. And the name of his mother was Hamutal, daughter of Jeremiah of Libnah. 

#### 2 Kings 23:32 And he did the wicked thing in the eyes of the LORD according to all as much as {did his fathers}. 

#### 2 Kings 23:33 And {moved him Pharaoh Necho} to Riblah in the land of Hamath, so as to not reign in Jerusalem. And he put a penalty against the land -- a hundred talents of silver, and ten talents of gold. 

#### 2 Kings 23:34 And {put to reign Pharaoh Necho} over them Eliakim son of Josiah instead of Josiah his father, and he turned his name into Jehoiakim. And {Jehoahaz he took}, and he led him away into Egypt, and he died there. 

#### 2 Kings 23:35 And the silver and the gold Jehoiakim gave to Pharaoh, but he assessed the land to give the money by the mouth of Pharaoh; from each man according to his assessed value; they gave the silver and the gold with the people of the land to give to Pharaoh Necho. 

#### 2 Kings 23:36 {a son being twenty and five years old Jehoiakim was} in his taking reign, and eleven years he reigned in Jerusalem. And the name of his mother was Zebudah, daughter of Pedaiah of Rumah. 

#### 2 Kings 23:37 And he did the wicked thing in the eyes of the LORD according to all as much as {did his fathers}. 

#### 2 Kings 24:1 In his days {ascended Nebuchadnezzar the king of Babylon}. And {became his Jehoiakim} servant three years. And he turned and annulled allegiance to him. 

#### 2 Kings 24:2 And the LORD sent against him the armed bands of the Chaldeans, and the armed bands of Syrians, and the armed bands of Moab, and the armed bands of the sons of Ammon. And he sent them against Judah to prevail against it, according to the word of the LORD, which he spoke by the hand of his servants the prophets. 

#### 2 Kings 24:3 Only a rage of the LORD was against Judah, to remove it from in front of him, on account of the sins of Manasseh, according to all as much as he did; 

#### 2 Kings 24:4 and indeed for the {blood innocent} which he poured out, and filled Jerusalem {blood of innocent}. And {did not want the LORD} to atone. 

#### 2 Kings 24:5 And the rest of the words of Jehoiakim, and all as much as he did, behold are not these written upon the scroll of the words of the days of the kings of Judah? 

#### 2 Kings 24:6 And Jehoiakim slept with his fathers. And {reigned Jehoiachin his son} instead of him. 

#### 2 Kings 24:7 And {did not proceed any longer the king of Egypt} to come forth out of his land, for {took the king of Babylon} from the rushing stream of Egypt unto the river Euphrates all as much as was of the king of Egypt. 

#### 2 Kings 24:8 {a son being eighteen years old Jehoiachin was} in his taking reign, and three months he reigned in Jerusalem. And the name to his mother was Nehushta daughter of Elnathan of Jerusalem. 

#### 2 Kings 24:9 And he did the wicked thing in the eyes of the LORD, according to all as much as {did his father}. 

#### 2 Kings 24:10 In that time {ascended Nebuchadnezzar king of Babylon} to Jerusalem, and {came the city} to be encompassed about. 

#### 2 Kings 24:11 And {entered Nebuchadnezzar king of Babylon} unto the city, and his servants assaulted it. 

#### 2 Kings 24:12 And {came forth Jehoiachin king of Judah} to the king of Babylon, he and his mother, and his servants, and his rulers, and his eunuchs. And {took them the king of Babylon} in the eighth year of his kingdom. 

#### 2 Kings 24:13 And he brought forth from there all the treasures of the ones in the house of the LORD, and the treasures of the house of the king. And he cut off all the items of gold which {made Solomon the king of Israel} for the temple of the LORD, according to the saying of the LORD. 

#### 2 Kings 24:14 And he resettled Jerusalem, and all the rulers, and all the mighty ones with strength into captivity -- ten thousand, and every fabricator, and the one so consigned. They did not leave behind except the ones being in need of the people of the land. 

#### 2 Kings 24:15 And he resettled Jehoiachin into Babylon, and the mother of the king, and the wives of the king, and his eunuchs. And the strong ones of the land he took away for resettlement from out of Jerusalem unto Babylon. 

#### 2 Kings 24:16 And all the {men mighty} -- seven thousand, and the fabricator, and the one so consigned -- thousands of all the mighty men in strength making war. And {led them the king of Babylon} in a displacement unto Babylon. 

#### 2 Kings 24:17 And {gave reign to the king of Babylon} Mattaniah brother of his father instead of him. And he placed {to him the name Zedekiah}. 

#### 2 Kings 24:18 {a son being twenty and one years old Zedekiah was} in his taking reign. And eleven years he reigned in Jerusalem. And the name to his mother was Hamutal, daughter of Jeremiah of Libnah. 

#### 2 Kings 24:19 And he did the wicked thing before the LORD according to all as much as Jehoiakim did. 

#### 2 Kings 24:20 For by the rage of the LORD the rage was on Jerusalem and on Judah, until he threw them from his face. And Zedekiah annulled allegiance to the king of Babylon. 

#### 2 Kings 25:1 And it came to pass in the ninth year of his kingdom, in the {month tenth}, on the tenth of the month, came Nebuchadnezzar king of Babylon and all his force, against Jerusalem. And he camped about it, and built upon it a rampart round about. 

#### 2 Kings 25:2 And {became the city} for being encompassed about until the eleventh year of Zedekiah the king, the ninth of the month. 

#### 2 Kings 25:3 And {grew in strength the hunger} in the city, and there was no bread to the people of the land. 

#### 2 Kings 25:4 And {was torn through the city}, and all the men of war went forth by night in the way of the gate between the walls, which is of the garden of the king. (And the Chaldeans were upon the city round about;) and they went the way, the one unto the descent. 

#### 2 Kings 25:5 And {pursued the force of the Chaldeans} after the king, and they overtook him by the descent of Jericho; and all his force were dispersed from about him. 

#### 2 Kings 25:6 And they seized the king, and they led him to the king of Babylon in Riblah. And he spoke against him a judgment. 

#### 2 Kings 25:7 And he slew the sons of Zedekiah before his eyes. And the eyes of Zedekiah he blinded, and he tied him in shackles, and led him unto Babylon. 

#### 2 Kings 25:8 And in the {month fifth}, the seventh of the month, this is {year the nineteenth} of the reign of Nebuchadnezzar king of Babylon, came Nabuzar-adan, the chief guard, the one standing in the presence of the king of Babylon, into Jerusalem. 

#### 2 Kings 25:9 And he burned the house of the LORD, and the house of the king, and all the houses of Jerusalem; and every {house great} he burned by fire. 

#### 2 Kings 25:10 And the wall of Jerusalem round about {tore down the force of the Chaldeans}. 

#### 2 Kings 25:11 And the extra ones of the people being left behind in the city, and the ones falling in who fell in with the king of Babylon, and the rest of the support {removed Nabuzar-adan the chief guard}. 

#### 2 Kings 25:12 And of the poor of the land {left behind the chief guard} as vine dressers and farmers. 

#### 2 Kings 25:13 And the columns, of the ones of brass, of the ones in the house of the LORD, and the bases, and the {sea brass}, the one in the house of the LORD, {cut up the Chaldeans}, and they carried their brass unto Babylon. 

#### 2 Kings 25:14 And the kettles, and the shovels, and the bowls, and the incense pans, and all the items of brass in which they officiated with them, he took. 

#### 2 Kings 25:15 And the censers, and the bowls, the ones of gold, and the ones of silver, {took the chief guard}. 

#### 2 Kings 25:16 {columns The two}, and the {sea one}, and the bases which Solomon made for the house of the LORD. There was no measuring the weight of the brass of all the items. 

#### 2 Kings 25:17 Eighteen cubits was the height of the {column one}, and the capital upon it of brass. Three cubits was the height of the capital. And the lattice work and pomegranates upon the capital round about were entirely of brass. And according to these it was to the {column second} upon the lattice work. 

#### 2 Kings 25:18 And {took the chief guard} Seraiah the {priest foremost}, and Zephaniah the {priest second rank}, and the three guarding the money; 

#### 2 Kings 25:19 and from out of the city he took {eunuch one} who was supervisor of the men warriors, and five men of the ones appearing in front of the king, of the ones being found in the city, and the scribe of the ruler of the force, the one arraying the people of the land, and sixty men of the people of the land being found in the city. 

#### 2 Kings 25:20 And {took them Nabuzar-adan the chief guard}, and he led them away to the king of Babylon in Riblah. 

#### 2 Kings 25:21 And {smote them the king of Babylon}, and killed them in Riblah in the land of Hamath. And he resettled Judah from its land. 

#### 2 Kings 25:22 And over the people being left behind in the land of Judah, whom {left behind Nebuchadnezzar king of Babylon}, he placed over it Gedaliah son of Ahikam, son of Shaphan. 

#### 2 Kings 25:23 And {heard all the rulers of the force}, they and their men, that {placed the king of Babylon} Gedaliah in charge. And they came to Gedaliah in Mizpah -- even Ishmael son of Nethaniah, and Johanan son of Careah, and Seraiah son of Tanhumeth the Netophathite, and Jaazaniah son of the Maachathite, they and their men. 

#### 2 Kings 25:24 And Gedaliah swore by an oath to them, and to their men, and said to them, Do not fear the passing by of the Chaldeans! Settle in the land, and serve the king of Babylon! and it will be well to you. 

#### 2 Kings 25:25 And it came to pass in the {month seventh}, came Ishmael son of Nethaniah, son of Elishama, of the seed of the kingdom, and ten men with him. And he struck Gedaliah and he died, even the Jews, and the Chaldeans who were with him in Mizpah. 

#### 2 Kings 25:26 And {rose up all the people} from small unto great, and the rulers of the force, and they entered into Egypt; for they feared from the face of the Chaldeans. 

#### 2 Kings 25:27 And it came to pass in the thirtieth and seventh year of the resettlement of Jehoiachin king of Judah, in the twelfth month, seventh and twentieth day of the month, {raised up high Evil-merodach king of Babylon} in the first year of his kingdom the head of Jehoiachin the king of Judah, and he led him from out of the house of the prison. 

#### 2 Kings 25:28 And he spoke with him for good, and put his throne above the thrones of the kings with him in Babylon. 

#### 2 Kings 25:29 And he changed the garments of his prison, and he ate bread always in his presence all the days of his life. 

#### 2 Kings 25:30 And his feasting was a feasting always given to him from out of the house of the king -- {reckoning a day's} in his day, all the days of his life.