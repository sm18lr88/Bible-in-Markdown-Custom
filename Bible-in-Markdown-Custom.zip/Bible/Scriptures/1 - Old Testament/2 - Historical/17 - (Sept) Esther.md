#### Esther 1:1 And it came to pass in the days of Artaxerxes. This Artaxerxes {from India a hundred twenty-seven regions held}. 

#### Esther 1:2 And in those days when {was enthroned king Artaxerxes} in Shushan the city, 

#### Esther 1:3 in the third year of his reign, {banquet he made a} to his friends, and to the rest of the nations, and to the Persians and Medes -- the honorable ones, and to the rulers of the satrapies. 

#### Esther 1:4 And after these things, after the showing to them the riches of his kingdom, and the glory of his gladness for {days a hundred eighty}, 

#### Esther 1:5 and when {were fulfilled the days} of the wedding, {made the king} a banquet for the nations, to the ones found in the city, for {days six}, in the courtyard of the house of the king, 

#### Esther 1:6 being adorned in fine linen, and cotton being stretched upon lines of fine linen and of purple, upon cube studs of gold and silver, upon columns of Parian marble, and stones, with beds of gold and silver upon a stone pavement of emerald stone, and mother of pearl, and Parian marble stone, and {strewn beds transparent variously being decorated}, 

#### Esther 1:7 with cups of gold and silver, wine abundant and agreeable, which {himself the king} drank. 

#### Esther 1:8 But this banquet {not according to being situated the law took place}; but thus {wanted the king}, and he gave orders to the managers to do his will, and for the men. 

#### Esther 1:9 And Vashti the queen made a banquet for the women in the palace where king Artaxerxes was. 

#### Esther 1:10 And on the {day seventh} {with pleasure being the king}, said to Mehuman, and Biztha, and Harbona, and Bigtha, and Abagtha, and Zethar, and Carcas, the seven eunuchs of king Artaxerxes, 

#### Esther 1:11 to bring in the queen to him, to give her reign, and to put on her the diadem, and to show her to all the rulers and to the nations of her beauty, for she was beautiful. 

#### Esther 1:12 And {did not listen to him Vashti queen} to come with the eunuchs. And {fretted the king}, and he was provoked to anger. 

#### Esther 1:13 And he said to his friends, Thus these things Vashti spoke, you deal then concerning this law and judgment! 

#### Esther 1:14 And came forward to him Carshena, and Shethar and Admatha, and Tarshish, and Meres and Marsena and Memucan seven rulers of the Persians and Medes, the ones near the king, the ones foremost being seated near the king. 

#### Esther 1:15 And they reported to him according to the laws as what {must do Vashti the queen}, for she had not done the things {by the king, having been assigned} through the eunuchs. 

#### Esther 1:16 And Memucan said to the king and to the rulers, Not {the king only wronged Vashti queen}, but also all the rulers, and the leaders of the king, 

#### Esther 1:17 (for he described to them the sayings of the queen) and how ever she contradicted the king, as then she did contradict to king Artaxerxes, 

#### Esther 1:18 so today, the wives of the sovereigns of the rest of the rulers of the Persians and Medes hearing the things {against the king having been said} by her, they shall dare in like manner to dishonor their husbands. 

#### Esther 1:19 If then it seems good to the king, let him assign a royal decree, and let him write it according to the laws of the Medes and Persians! and not otherwise treat nor let {enter any longer the queen} to him, and {her royalty let give the king} to a woman better than her! 

#### Esther 1:20 And let {be heard the law by the king}! which ever he should make for his kingdom. And thus all the women shall invest honor to their own husbands, from poor unto rich. 

#### Esther 1:21 And {pleased the word} the king and the rulers. And {did the king} as Memucan said. 

#### Esther 1:22 And he sent letters into all the kingdom, according to place, according to their form of speech, so as to be fearing them in their households. 

#### Esther 2:1 And after these matters {was abated the king's rage}, and no longer was {mentioned Vashti}, remembering as much as she spoke, and how he condemned her. 

#### Esther 2:2 And {said the servants of the king}, Let there be sought to the king young women uncorrupted, beautiful in appearance! 

#### Esther 2:3 And {shall place the king} magistrates in all the places of his kingdom, and let them choose young women, virgins, beautiful in appearance to be brought to Shushan the city, into the chamber of the women! And let them be delivered to the eunuch of the king, the keeper of the women! And let there be given to them a beauty treatment, and the remaining care! 

#### Esther 2:4 And the woman who ever should be pleasing to the king shall reign instead of Vashti. And {pleased the king the thing}, and he did so. 

#### Esther 2:5 And there was a man, a Jew, in Shushan the city. And his name was Mordecai, the son of Jair, the son of Shimei, the son of Kish, of the tribe of Benjamin; 

#### Esther 2:6 who was a captive from Jerusalem, which {captured Nebuchadnezzar the king of Babylon}. 

#### Esther 2:7 And there was to this man a child that he brought up, the daughter of the brother of his father, and her name was Esther. And at the changeover of her parents, he instructed her to himself for a woman. And {was the young woman} good in appearance. 

#### Esther 2:8 And when {was heard the king's order}, {were gathered together many young women} in Shushan the city, by the hand of Hegai; and Esther was led to Hegai the keeper of the women. 

#### Esther 2:9 And {pleased him the young woman}, and she found favor before him. And he hastened to give her the beauty treatment, and her portion, and the seven young women being exhibited to her from the royal palace. And he treated her well, and her handmaidens in the chamber of the women. 

#### Esther 2:10 But {did not plainly show Esther} her race, nor her fatherland. For Mordecai gave charge to her not to report it. 

#### Esther 2:11 And each day Mordecai walked by the {courtyard feminine}, overseeing what would come to pass with Esther. 

#### Esther 2:12 For this was the time for a young woman to enter to the king, whenever she should have fulfilled {months twelve}, for thus are fulfilled the days of the treatment, {months six} with the aromatics and with the beauty treatments for the women, 

#### Esther 2:13 and {months six} being anointed with myrrh oil, and then she enters to the king. And to whom ever he should tell, he delivers her to enter together with him, from the chamber of the women unto the palaces. 

#### Esther 2:14 In the evening she enters, and by day she runs to the {chamber of the women second}, where Hegai the eunuch of the king the keeper of the women is. And no longer does she enter to the king if she should not be called by name. 

#### Esther 2:15 And in the fulfilling the time, Esther the daughter of Abihail, brother of the father of Mordecai, entered to the king. Not one thing she disregarded which {gave charge to her the eunuch keeper of the women}. {was For Esther} found in favor by all the ones seeing her. 

#### Esther 2:16 And Esther entered to Artaxerxes the king in the tenth month, which is Tebeth, in the seventh year of his kingship. 

#### Esther 2:17 And {loved passionately the king Esther}, and she found favor above all the virgins; and he placed upon her the {diadem feminine}. 

#### Esther 2:18 And {made the king} a banquet for all his friends, and the powerful ones, for {days seven}. And he exalted the wedding feasts of Esther; and {a release he made} to the ones under his kingdom. 

#### Esther 2:19 But Mordecai attended to affairs in the courtyard. 

#### Esther 2:20 Now Esther did not plainly tell of her fatherland, for thus {gave charge to her Mordecai}, to fear God, and to observe his orders, as she was with him. And Esther did not change her conduct. 

#### Esther 2:21 And {fretted the two eunuchs of the king}, and the chiefs of the body guards, for Mordecai advanced. And they sought to kill Artaxerxes the king. 

#### Esther 2:22 And {was made manifest to Mordecai the matter}, and he signaled it to Esther, and she revealed to the king the things of the plot. 

#### Esther 2:23 And the king examined the two eunuchs, and he hanged them. And {gave order the king} to write for a memorial in the royal library about the good-will of Mordecai with commendation. 

#### Esther 3:1 After these things {extolled king Artaxerxes} Haman the son of Hammedatha the Agagite, and exalted him, and seated him first above all his friends. 

#### Esther 3:2 And all the ones in the courtyard did obeisance to him, for so {assigned it the king} to do. But Mordecai did not do obeisance to him. 

#### Esther 3:3 And {said the ones in the courtyard of the king} to Mordecai, O Mordecai, why do you disregard the things {by the king being said}? 

#### Esther 3:4 Accordingly each day they spoke to him, and he did not hearken to them; and they indicated to Haman that Mordecai {against of the king the words was rebelling}; and {indicated to them Mordecai} that he is a Jew. 

#### Esther 3:5 And Haman, realizing that {did not do obeisance to him Mordecai}, was enraged exceedingly. 

#### Esther 3:6 And he took counsel to remove all {under the of Artaxerxes kingdom the Jews}. 

#### Esther 3:7 And he made a referendum in {year the twelfth} of the kingdom of Artaxerxes. And he cast lots day by day, and month by month, so as to destroy in one day the race of Mordecai. And {fell the lot} on the fourteenth of the month, which is Adar. 

#### Esther 3:8 And he spoke to king Artaxerxes, saying, There exists a nation having been disseminated among the nations in all your kingdom, but their laws are special from all the nations; and of the laws of the king they disregard, and it is not advantageous to the king to allow them. 

#### Esther 3:9 If it seems good to the king, let him decree to destroy them, and I will circumscribe for the treasury of the king {of silver talents ten thousand}. 

#### Esther 3:10 And {removing the king} the ring, gave it into the hands of Haman, to set a seal on the things being written against the Jews. 

#### Esther 3:11 And {said the king} to Haman, As for the silver, you have it! and for the nation, you treat it as you want! 

#### Esther 3:12 And {were called the scribes} by the king {month in the first}, the thirteenth day, and they wrote as Haman gave orders to the commandants, and to the rulers in every place from India unto Ethiopia, to a hundred twenty-seven places, to the rulers of the nations according to their form of speech, through Artaxerxes the king. 

#### Esther 3:13 And it was sent by couriers unto the kingdom of Artaxerxes, to remove the race of the Jews on day one {month of the twelfth}, which is Adar, and to plunder their possessions. 

#### Esther 3:14 And the copies of the letters were displayed in each place. And it was assigned to all to be prepared for that day. 

#### Esther 3:15 {was hastened And the thing}, even in Shushan. And the king and Haman toasted, {was disturbed but the city}. 

#### Esther 4:1 But Mordecai realizing the end, tore his garments, and put on sackcloth, and strewed ashes; and rushing through the square of the city, he yelled {voice with a great}, {is going to be taken away A nation no one having wronged}. 

#### Esther 4:2 And he came unto the gate of the king, and stood; {not for it was for him allowed} to enter into the courtyard {sackcloth having on} and ashes. 

#### Esther 4:3 And in every place where {were displayed the letters} there was a cry, and beating of the breast, and {mourning great} among the Jews; and with sackcloth and ashes they made beds for themselves. 

#### Esther 4:4 And {entered the handmaidens and the eunuchs of the queen}, and they announced to her. And she was disturbed hearing the thing taking place. And she sent to robe Mordecai, and to remove from him the sackcloth; but he did not yield. 

#### Esther 4:5 And then Esther called on Hatach her eunuch who stood beside her. And she sent to learn for herself from Mordecai the exact situation. 

#### Esther 4:7 And Mordecai indicated to him the thing taking place, and the promise which Haman promised to the king, for {to the treasury talents to be paid ten thousand}, that he should destroy the Jews. 

#### Esther 4:8 And the copy, the one in Shushan being displayed for purpose of destroying them, he gave to him to show to Esther. And he told him to give charge to her to enter to ask pardon of the king, and to be found worthy by him for the people, remembering, said he, The days of your low estate, how you were maintained by my hand; because Haman the one being second to the king speaks against us for death. You call upon the LORD, and speak to the king concerning us! even to rescue us from death. 

#### Esther 4:9 {entered And Hatach} and spoke to Esther all these words. 

#### Esther 4:10 {said And Esther} to Hatach, You go to Mordecai, and say! 

#### Esther 4:11 that, {the nations All} of the kingdom know that every man or woman, who shall enter to the king, into the {courtyard inner} uncalled, there is no deliverance to him, except to whomever {stretches out the king} the golden rod, this one shall be delivered; and I have not been called to enter to the king -- they are these {days thirty}. 

#### Esther 4:12 And Hatach reported to Mordecai all the words of Esther. 

#### Esther 4:13 And Mordecai said to Hatach, Go and say to her! Esther, you should not say to yourself that you shall be delivered alone in the kingdom of all the Jews. 

#### Esther 4:14 So that if you should disregard at this time, from elsewhere help and protection will be to the Jews, but you and the house of your father will be destroyed; and who knows if it be for this occasion you reigned. 

#### Esther 4:15 And Esther sent the one having come to her to Mordecai, saying, 

#### Esther 4:16 In proceeding, you hold an assembly of the Jews in Shushan, and you all fast for me! And you should not eat nor drink for {days three} -- night and day. And I and the handmaidens of mine shall go without food; and then I shall enter to the king contrary to the law, even if {to perish for me it is necessary}. 

#### Esther 4:17 And proceeding, Mordecai did as much as {gave charge to him Esther}. 

#### Esther 5:1 And it came to pass in the {day third}, Esther put on royal apparel, and she stood in the courtyard of the house of the king, in the inner courtyard, right opposite the royal house of the king. And the king sat down on the throne of his own kingdom in the {house royal}, right opposite the door of the house. 

#### Esther 5:2 And as {saw the king} Esther the queen standing in the courtyard, that she found favor in his eyes; and {stretching out the king} to Esther the {rod golden}, the one in his hand, that Esther approached and touched the tip of the rod. 

#### Esther 5:3 And {said the king}, What do you want, Esther, and what is your request? The worth unto half of my kingdom will be to you. 

#### Esther 5:4 And Esther said, {day for me a notable Today is}. If then it seems good to the king, let {come both the king and Haman} to the banquet which I shall prepare today! 

#### Esther 5:5 And {said the king}, Hasten Haman, so that we should do the word of Esther! And they came both to the banquet which Esther made. 

#### Esther 5:6 And at the banquet {said the king} to Esther, What is it to you, queen Esther, and it will be to you as much as is worthy? 

#### Esther 5:7 And she said, The request of mine and my petition, 

#### Esther 5:8 if I found favor before the king, let {come the king and Haman} upon the morrow to the banquet which I shall prepare for them, and tomorrow I will do the same! 

#### Esther 5:9 And {went forth Haman} from the king overjoyed and being glad. But in Haman seeing Mordecai the Jew in the courtyard, he was enraged exceedingly. 

#### Esther 5:10 And entering into his own place he called his friends, and Zeresh his wife. 

#### Esther 5:11 And he showed to them his riches, and the glory which the king invested in him, and how he made him to be preeminent, and to take the lead of the kingdom. 

#### Esther 5:12 And Haman said, {no one has called The queen} with the king, not one to the banquet but me, and for tomorrow she has invited me. 

#### Esther 5:13 And these things {me do not please}, whenever I behold Mordecai the Jew in the courtyard. 

#### Esther 5:14 And {said to him Zeresh his wife}, and his friends, Fell for yourself a tree {cubits of fifty}, and at dawn speak to the king, and hang Mordecai upon the tree; and you enter into the banquet with the king, and be glad! And {pleased the saying} Haman, and {was prepared the tree}. 

#### Esther 6:1 But the LORD removed the sleep from the king that night; and he told his servant to carry in {letters the memorandum} of the days to read to him. 

#### Esther 6:2 And he found letters having been written concerning Mordecai, as was reported to the king concerning the two eunuchs of the king, during their watching and their seeking to put hands on Artaxerxes. 

#### Esther 6:3 {said And the king}, What glory or favor did we do for Mordecai? And {said the servants of the king}, We did not do for him one thing. 

#### Esther 6:4 And during the inquiring by the king concerning the good-will of Mordecai, behold, Haman was in the courtyard. {said And the king}, Who is in the courtyard? And he entered to speak to the king to hang Mordecai upon the tree which he prepared. 

#### Esther 6:5 And {said the servants of the king}, Behold, Haman stands in the courtyard. And {said the king}, Call him! 

#### Esther 6:6 {said And the king} to Haman, What shall I do to the man whom I want to extol? {said And to himself Haman}, Who does {want the king} to extol unless me? 

#### Esther 6:7 And he said to the king, As for the man whom the king wants to extol, 

#### Esther 6:8 let {bring the servants of the king apparel fine linen} which the king puts on, and the horse upon which the king mounts, 

#### Esther 6:9 and give it to one of the friends of the king of the honorable ones; and robe the man whom the king loves, and mount him upon the horse, and let him proclaim through the square of the city! saying, So shall it be done to every man whom the king extols. 

#### Esther 6:10 {said And the king} to Haman, {well You spoke}, you do thus to Mordecai the Jew, to the one attending in the courtyard, and do not let fall from you a word which you spoke! 

#### Esther 6:11 And Haman took the robe, and the horse, and he robed Mordecai, and mounted him upon the horse, and went through the square of the city, and proclaimed, saying, So it will be to every man the king wants to extol. 

#### Esther 6:12 {returned And Mordecai} to the courtyard. And Haman returned to his own place fretting with a down cast head. 

#### Esther 6:13 And Haman described the things coming to pass to him to Zeresh his wife, and to his friends. And {said to him the friends and wife}, Since {of the race of the Jews Mordecai is}, and you began to be humbled before him, in falling you shall fall, in no way should you be able to defend against him, for the living God is with him. 

#### Esther 6:14 While they were yet speaking, {came the eunuchs} to hurry Haman unto the banquet which Esther prepared. 

#### Esther 7:1 And they entered, the king and Haman, to drink together with the queen. 

#### Esther 7:2 {said And the king} to Esther on the second day at the banquet, What is it queen Esther? And what is your request? And what is your petition? And it will be yours unto half of my kingdom! 

#### Esther 7:3 And answering she said, If I found favor before the king, let him give life to my request, and my people to my petition. 

#### Esther 7:4 {were sold For both I and my people} into destruction, and ravaging, and slavery; we, and both our children for manservants and maidservants, and I neglected to speak; {is not for worthy the slanderer} of the courtyard of the king. 

#### Esther 7:5 {said And the king}, Who is this who dared to do this thing? 

#### Esther 7:6 And Esther said, A man, an enemy, Haman, this wicked man. And Haman was disturbed before the king and the queen. 

#### Esther 7:7 And the king rose up from the party to go into the garden. And Haman appealed to the queen, for he saw himself {in evils being}. 

#### Esther 7:8 {returned And the king} from out of the garden; and Haman had fallen upon the bed petitioning the queen. {said And the king}, So as even with my wife you use force in my house. And Haman, hearing, was overawed in front of him. 

#### Esther 7:9 {said And Harbonah one of the eunuchs} to the king, Behold, {even a tree Haman prepared} for Mordecai, to the one speaking for the king, and it was set straight up in the places of Haman -- {cubits of fifty}. {said And the king}, Let him be crucified upon it! 

#### Esther 7:10 And Haman was hung upon the tree which he prepared for Mordecai. And then the king slackened from the rage. 

#### Esther 8:1 And in that day king Artaxerxes presented to Esther as much as existed to Haman the slanderer. And Mordecai was called on by the king, for Esther indicated how he was related to her. 

#### Esther 8:2 {took And the king} the ring which he removed from Haman, and he gave it to Mordecai. And Esther placed Mordecai over all the things of Haman. 

#### Esther 8:3 And proceeding, she spoke to the king, and fell unto his feet, and petitioned him to remove the evil of Haman, and as much as he did to the Jews. 

#### Esther 8:4 {stretched out And the king} to Esther the {rod gold}, and Esther arose to stand beside the king. 

#### Esther 8:5 And Esther said, If it seems good to you, and I found favor, let it be sent forth to return the letters being sent from Haman, the ones having been written to destroy the Jews who are in your kingdom. 

#### Esther 8:6 For how shall I be able to behold the ill treatment of my people? And how shall I be able to be delivered in the destruction of my fatherland? 

#### Esther 8:7 And {said the king} to Esther, If all the possessions of Haman I gave and granted to you, and he I hanged upon the tree for the hands he bore against the Jews, what yet do you anxiously seek? 

#### Esther 8:8 {write And you} in my name as it seems good to you, and set a seal with my ring! For as much as is written of the king in giving an order, and the seal should be set by my ring, it is not to them to contradict. 

#### Esther 8:9 {were called And the scribes} in the first month, which is Nisan, on the third and twentieth day of the same year. And it was written to the Jews, as much as was given charge to the local managers, and to the rulers of the satrapies from India unto Ethiopia -- a hundred twenty-seven satrapies, according to place by place, according to their form of speech. 

#### Esther 8:10 And it was written through the king, and the seal was set by his ring, and they sent out the letters by couriers, 

#### Esther 8:11 as he gave orders to them to deal with their laws in every city, both to help them and to deal with their opponents, and with their adversaries as they wanted, 

#### Esther 8:12 on {day one} in all the kingdom of Artaxerxes, on the thirteenth day of the twelfth month, which is Adar. 

#### Esther 8:13 And the copies, let them be displayed clear to the eyes in all the kingdom, {prepared and for to be all the Jews} for this day, for them to wage war against their opponents. 

#### Esther 8:14 Then the horsemen went forth hastening {the things by the king being spoken to complete}. {was displayed And the order} also in Shushan. 

#### Esther 8:15 And Mordecai went forth robed in the royal apparel, and {a crown having} of gold, and a diadem {fine line of purple}. {beholding And the ones in Shushan} rejoiced. 

#### Esther 8:16 And to the Jews there became light and gladness. 

#### Esther 8:17 In each city and place of which ever {was displayed the public notice}, there was joy and gladness among the Jews, with toasting and gladness. And many of the nations were circumcised, and were Jewish-like because of the fear of the Jews. 

#### Esther 9:1 For in the twelfth month, on the thirteenth of the month, which is Adar, {were at hand the letters written by the king}. 

#### Esther 9:2 And in that day {were destroyed the adversaries of the Jews}, {no one for opposed fearing them}. 

#### Esther 9:3 For the rulers of the satraps, and the sovereigns, and the royal scribes esteemed the Jews, for the fear of Mordecai rested upon them. 

#### Esther 9:4 {fell For the order of the king} for him to be named in all the kingdom. 

#### Esther 9:6 And in Shushan the city the Jews killed {men five hundred} -- 

#### Esther 9:7 both Parshandatha, and Dalphon, and Aspatha, 

#### Esther 9:8 and Poratha, and Adalia, and Aridatha and Parmashta, and Arisai, 

#### Esther 9:9 and Aridai, and Vajezatha, 

#### Esther 9:10 even the ten sons of Haman, son of Hammedatha the Bougean, the enemy of the Jews; but they plundered not in that day. 

#### Esther 9:11 And was given the number to the king of the ones being destroyed in Shushan. 

#### Esther 9:12 {said And the king} to Esther, The Jews destroyed in Shushan {men five hundred} in the city; and in the place round about, how do you imagine they were treated? What then do you still petition, for it will be yours? 

#### Esther 9:13 And Esther said to the king, Let it be given for the Jews to deal likewise tomorrow, so as far the ten sons of Haman to hang. 

#### Esther 9:14 And {committed it the king} so to be. And he displayed to the Jews of the city the bodies of the sons of Haman to hang. 

#### Esther 9:15 And {gathered together the Jews} in Shushan on the fourteenth day of Adar, and they killed {men three hundred}, but nothing they plundered. 

#### Esther 9:16 And the rest of the Jews, of the ones in the kingdom, gathered together and helped themselves, and gained rest from the warlike men; for they destroyed of them, {ten thousands seven}, and five thousand men on the thirteenth of Adar, but {nothing they plundered}. 

#### Esther 9:17 And they rested on the fourteenth of the same month, and they celebrated it as a day of rest with joy and gladness. 

#### Esther 9:18 And the Jews in Shushan the city gathered together also on the fourteenth and rested. But they celebrated even on the fifteenth with joy and gladness. 

#### Esther 9:19 Because of this then the Jews, the ones being disseminated in every place outside, celebrate on the fourteenth of Adar, {day a good} with gladness, {sending portions each} to his neighbor. 

#### Esther 9:20 {wrote And Mordecai} these words in a scroll and sent them to the Jews, as many as were in the kingdom of Artaxerxes, to the ones near and to the ones far; 

#### Esther 9:21 to establish these days as good days, and to celebrate both the fourteenth and the fifteenth of Adar. 

#### Esther 9:22 For in these days {gained rest the Jews} from their enemies. And the month in which things turned for them, which was Adar, from mourning to joy, and from grief to good days, was to celebrate entirely for good days of wedding feasts and gladness, sending gift portions to their friends and to the poor. 

#### Esther 9:23 And {favorably received it the Jews} as {wrote to them Mordecai}, 

#### Esther 9:24 of how Haman son of Hammedatha the Macedonian waged war against them; as he ordained a referendum and the lot, to obliterate them; 

#### Esther 9:25 and how he entered to the king, telling him to hang Mordecai. But as much as he attempted to bring {upon the Jews bad things}, upon himself it came to pass; and he was hanged, he and his children. 

#### Esther 9:26 On account of this they call these days Purim because of the lots, (for in their dialect they are called purim), because of the words of this letter, and as much as they suffered on account of it, and as much as happened to them and was stopped. 

#### Esther 9:27 And {favorably received it the Jews} for themselves, and for their seed, and for the ones purposed unto them to observe it -- nor in fact {otherwise shall they treat it}. And these days were a memorial being completed according to generation and generation, and city, and family, and place. 

#### Esther 9:28 And these days were celebrated for all time, and their memorial in no way should fail unto generations. 

#### Esther 9:29 And {wrote Esther the queen daughter of Abihail}, and Mordecai the Jew, as much as they did, and the confirmation of the letter of the purim. 

#### Esther 9:31 And {Mordecai and Esther the queen they established to themselves} for themselves; and then establishing according to their fasting and their counsel. 

#### Esther 9:32 And Esther {the matter established} for the eon, and it was written for a memorial. 

#### Esther 10:1 {wrote And the king} unto the kingdom by both land and sea. 

#### Esther 10:2 And his strength, and the valor, riches, and also the glory of his kingdom, behold, they are written in the scroll of the Persians and Medes for a memorial. 

#### Esther 10:3 For Mordecai relieved king Artaxerxes, and was great in the kingdom, and being extolled by the Jews, and being fond to describe the welfare to all their nation.