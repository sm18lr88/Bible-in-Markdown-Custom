#### Nehemiah 1:1 The words of Nehemiah son of Hachaliah. And it came to pass in the month of Chislev, {year in the twentieth}, that I was in Susa Abira. 

#### Nehemiah 1:2 And there came Hanani one of my brethren, he and the men of Judah. And I asked them concerning the Jews, of the ones having survived, the ones left behind from the captivity, and concerning Jerusalem. 

#### Nehemiah 1:3 And they said to me, The ones remaining behind surviving from the captivity there in the place are among {wickedness great}, and in scorning; and the walls of Jerusalem are being demolished, and its gates were burnt by fire. 

#### Nehemiah 1:4 And it came to pass in my hearing these words, I sat and wept and mourned for days, and I was fasting and praying before the God of heaven. 

#### Nehemiah 1:5 And I said, O indeed, O LORD God of heaven, the strong and great and fearful one, guarding the covenant and the mercy to the ones loving him and to the ones guarding his commandments. 

#### Nehemiah 1:6 Let it be indeed your ear heeds, and your eyes open to hear the prayer of your servant! which I pray before you today's day and night, for the sons of Israel your servants. And I declare openly concerning the sins of the sons of Israel, in which we sinned against you; both I and the house of my father sinned. 

#### Nehemiah 1:7 In parting, we parted from you, and we guarded not the commandments, and the orders, and the judgments, which you gave charge to Moses your servant. 

#### Nehemiah 1:8 Remember indeed! the word which you gave charge to Moses, to your servant, saying, If {should break contract You}, I shall disperse you among the peoples. 

#### Nehemiah 1:9 But if you should return to me, and should guard my commandments, and observe them; and if {might be your dispersion} unto the tip of the heaven, from there I will gather them, and I will bring them into the place which I chose to encamp my name there. 

#### Nehemiah 1:10 And they are your children and your people, whom you ransomed by {power your great}, and by {hand your fortified}. 

#### Nehemiah 1:11 Indeed, O LORD, let be your ear heeding to the prayer of your servant, and to the prayer of your children! of the ones wanting to fear your name. And prosper the way indeed of your servant today, and give him for compassions before this man! And I was a wine server to the king. 

#### Nehemiah 2:1 And it came to pass in the month of Nisan, {year the twentieth} of Artaxerxes the king, that {was the wine} before him. And I took the wine and gave it to the king, and there was no other before him. 

#### Nehemiah 2:2 And {said to me the king}, Why is your face in a sorry state, and you are not content? For {not is this} unless there is a sorrowful heart. And I was afraid {much exceedingly}. 

#### Nehemiah 2:3 And I said to the king, O king, {into the eon Live}! Why should not {be sorry face my}, for the city, the house of the sepulchres of my fathers, was made desolate, and its gates were devoured by fire? 

#### Nehemiah 2:4 And {said to me the king}, For what is this you seek? And I prayed to the LORD God of heaven. 

#### Nehemiah 2:5 And I said to the king, If it be upon the king for good, and if {shall seem good your servant} before you, so as to send him to Judah, to the city of the sepulchres of my fathers, then I will rebuild it. 

#### Nehemiah 2:6 And {said to me the king}, and his concubine sitting next to him, For how long will {be going you}, and when will you return? And it was good before the king. And he sent me, and I gave to him a confirmation. 

#### Nehemiah 2:7 And I said to the king, If it be upon the king for good, let him give to me letters to the chief rulers on the other side of the river! so as to allow me to pass until I come unto Judah; 

#### Nehemiah 2:8 and a letter to Asaph the keeper of the garden, which is to the king, so as to give to me wood to roof the gates of the palace of the house, and for the wall of the city, and for the house, for which I shall enter unto it. And {gave to me the king} by {hand of God the good} upon me. 

#### Nehemiah 2:9 And I came to the chief rulers on the other side of the river, and I gave to them the letters of the king. And {sent with me the king} chiefs of the force, and horsemen. 

#### Nehemiah 2:10 And {heard of it Sanballat the Horonite}, and Tobiah the servant, the Ammonite, and it was a bad thing to them that it happened. And they were grieved that {comes a man} to seek good to the sons of Israel. 

#### Nehemiah 2:11 And I came unto Jerusalem, and I was there {days three}. 

#### Nehemiah 2:12 And I rose up at night, I and {men a few} with me. And I did not report to a man, for God put it into my heart to do this with Jerusalem. And {beast no there is} with me, except the beast which I mounted upon it. 

#### Nehemiah 2:13 And I went forth through the gate of Gai at night to the mouth of the spring of the serpent, and to {gate the dung}. And I was studying the walls of Jerusalem, the ones being torn down, and her gates, the ones having been consumed by fire. 

#### Nehemiah 2:14 And I went by the gate of the fountain, and into the pool of the king. And there was no place for the beast {to pass underneath me}. 

#### Nehemiah 2:15 And I was ascending by the rushing stream at night. And I was studying the wall, and I was at the gate of the ravine, and I returned. 

#### Nehemiah 2:16 And the ones guarding did not know why I went, and what I was doing. And to the Jews, and to the priests, and to the important ones, and to the commandants, and to the rest of the ones doing the works until then, I did not report. 

#### Nehemiah 2:17 Then I said to them, You see this wickedness in which we are in it, how Jerusalem is desolate, and its gates were given to fire. Come, and let us build throughout the wall of Jerusalem! and we shall not be any longer for scorn. 

#### Nehemiah 2:18 And I reported to them the hand of God which is good upon me, and the words of the king which he spoke to me. And they said, Let us arise and build! And {were fortified their hands} for good. 

#### Nehemiah 2:19 And {heard Sanaballat the Horonite}, and Tobiah the servant, the Ammonite, and Geshem the Arab. And they laughed out loud at us, and they disdained us, and they said, What is this thing which you are doing? or is it {against the king that you are defecting}? 

#### Nehemiah 2:20 And I returned to them a word, and I said to them, The God of heaven, he shall prosper the way for us. And we his servants are pure, and we shall arise and build, and to you there is no portion, nor judicial right, nor a memorial in Jerusalem. 

#### Nehemiah 3:1 And {rose up Eliashib the priest great}, and his brethren the priests, and they constructed the {gate sheep}; they sanctified it, and they set its doors; even unto the tower of the hundred they sanctified it, unto the tower of Hananeel. 

#### Nehemiah 3:2 And near his hands {constructed men of Jericho}; and near his hands {constructed Zaccur son of Imri}. 

#### Nehemiah 3:3 And {the gate fish constructed the sons of Hassenaah}; they roofed it, and they set its doors, and its bolts, and its bars. 

#### Nehemiah 3:4 And near their hands Maremoth took control, the son of Urijah, son of Kos; and near their hand Meshullam took control, son of Barechiah, son of Meshezabeel; and near their hand Zadok took control, son of Baana. 

#### Nehemiah 3:5 And near their hand {took control the Tekoites}; but their strong ones did not insert their neck into a service of their Lord. 

#### Nehemiah 3:6 And the gate of Jasanah {repaired Jehoiada son of Paseah}, and Meshullam son of Bosodeiah. They roofed it, and set its doors, and its bolts, and its bars. 

#### Nehemiah 3:7 And near their hand Melatiah repaired, the Gibeonite, and Jadon the Meronothite, the men of Gibeon, and of Mizpah, unto the throne of the ruler of the other side of the river. 

#### Nehemiah 3:8 And near their hand Uzziel repaired, son of Harhaiah of the refiners, and near his hand Hananiah repaired, son of the perfumers, and they established Jerusalem unto the {wall broad}. 

#### Nehemiah 3:9 And near their hand Rephaiah repaired, son of Hur, ruler of half of the place round about Jerusalem. 

#### Nehemiah 3:10 And near their hand Jedaiah repaired, son of Harumaph, even against his house. And near his hand Hattush repaired, son of Hashabniah. 

#### Nehemiah 3:11 And {measured section a second repaired Malchijah son of Harim and Hashub son of Pahath-moab}, even unto the tower of the furnaces. 

#### Nehemiah 3:12 And near his hand Shallum repaired, son of Halohesh, ruler of half the place round about Jerusalem, he and his daughters. 

#### Nehemiah 3:13 The gate of the ravine Hanun repaired, and the ones dwelling at Zanoah; they constructed it, and set its doors, and its bolts, and its bars, and a thousand cubits of the wall unto the {gate dung}. 

#### Nehemiah 3:14 And the {gate dung} Malchiah repaired, son of Rechab, ruler of a place round about the house of Beth-heccerem, he and his sons; and they sheltered it, and set its doors, and its bolts, and its bars. 

#### Nehemiah 3:15 And the gate of the spring was safeguarded by Shallum son of Col-hozeh, ruler of part of Mizpah; he built it, and roofed it, and set its doors, and its bars, and the wall of the pool of Siloah to the garden of the king, and unto the stairways of the ones going down from the city of David. 

#### Nehemiah 3:16 After him Nehemiah repaired, son of Azabuk, ruler of half the place round about Beth-zur, unto the garden of the burying-place of David, and unto the pool being built by man, and unto the house of the mighty ones. 

#### Nehemiah 3:17 After him {repaired the Levites} -- Rehum son of Bani; near his hand Hashabiah repaired, ruler of half the place round about Keilah, to the place round about him. 

#### Nehemiah 3:18 And after him {repaired their brethren} -- Bavai son of Henadad, ruler of half the place round about Keilah. 

#### Nehemiah 3:19 And repaired near his hand Ezer son of Jeshua ruler of Mizpah {measured section a second} right opposite the ascending unto the weapons site, of the one joining together at the corner. 

#### Nehemiah 3:20 After him Baruch repaired, son of Zabbai {measured section a second} from the corner unto the door of the house of Eliashib the {priest great}. 

#### Nehemiah 3:21 And after him Meramoth repaired, son of Uriah son of Kos {measured section a second}, from the door of the house of Eliashib unto the completion of the house of Eliashib. 

#### Nehemiah 3:22 And after him {repaired the priests}, the men of Ekchechar. 

#### Nehemiah 3:23 And after him Benjamin repaired and Hashub over against their house. And after them Azariah repaired, son of Maaseiah, son of Ananiah, next to his house. 

#### Nehemiah 3:24 And after him Binnui repaired, son of Henadad {measured section a second}, from the house of Azariah unto the corner, and unto the curve. 

#### Nehemiah 3:25 Palal son of Uzai, right opposite the corner, and the tower, the one protruding from out of the house of the king, higher than the courtyard of the prison. And after him Pedaiah son of Parosh. 

#### Nehemiah 3:26 And the Nethinim were living in Ophel unto before the garden {gate of the water} to the east, and the {tower protruding}. 

#### Nehemiah 3:27 And after them {repaired the Tekoites} {measured section a second}, right opposite the {tower great protruding}, and unto the wall of Ophel. 

#### Nehemiah 3:28 Upward of the gate of the horses {repaired the priests}, every man right opposite his own house. 

#### Nehemiah 3:29 And after them Zadok repaired, son of Immer, right opposite his own house. And after him Shemaiah repaired, son of Shechaniah, keeper of the {gate east}. 

#### Nehemiah 3:30 And after him Hananiah repaired, son of Shelemiah, and Hanun son of Zalaph the sixth son, {measured section a second}. And after him Meshullam repaired, son of Barechiah right opposite his treasury. 

#### Nehemiah 3:31 And after him Malchiah repaired, son of Sarefi, unto the house of the Nethinim, and of the traders, before the gate of Miphkad, and unto the ascending of the curve. 

#### Nehemiah 3:32 And between the ascending of the {gate sheep} {repaired the braziers and the traders}. 

#### Nehemiah 4:1 And it came to pass when Sanballat heard that we were building the wall, that it was evil to him, and he was angry very much, and he was laughing out loud over the Jews. 

#### Nehemiah 4:2 And he spoke before his brethren, and the force of the Samaritans, and he said, What do these Judahmen do -- the Jews? Shall we not abandon them? Is it to sacrifice? Is it that they will be able to? And today, will they repair the stones with the embankment rubbish for being burnt? 

#### Nehemiah 4:3 And Tobiah the Ammonite was next to him, and he said to them, And even if they shall build, shall not {ascend a fox} and demolish {wall of stones their}? 

#### Nehemiah 4:4 Hear, O our God! for we became for sneering. And return their scorning upon their head, and give them for sneering in a land of captivity! 

#### Nehemiah 4:5 And you should not cover over their lawlessness; and their sin -- {from your face may it not be wiped away}. For they provoked you to anger before the ones building. 

#### Nehemiah 4:6 And we built the wall, and {was joined together all the wall} unto the half of it. And {became the heart of the people} so as to construct. 

#### Nehemiah 4:7 And it came to pass as Sanballat heard, (and Tobiah, and the Arabians, and the Ammonites, and the Ashdodites, that {ascended the development of the walls of Jerusalem},) that they began {the gaps to block up}, that {wicked to them it appeared exceedingly}. 

#### Nehemiah 4:8 And they gathered all together to come and to deploy against Jerusalem, and to do it for a delusion. 

#### Nehemiah 4:9 And we prayed to our God, and we set an advance guard against them day and night, in front of them. 

#### Nehemiah 4:10 And Judah said, {is broken The strength of the enemies}, and the dust is vast, and we shall not be able to build on the wall. 

#### Nehemiah 4:11 And {said the ones afflicting us}, They shall not know, and they shall not see until whenever we should come into the midst of them, and should murder them, and should cause {to cease the work}. 

#### Nehemiah 4:12 And it came to pass as {came the Jews living next to them}, that they said to us, They ascend from out of all the places that you returned from us. 

#### Nehemiah 4:13 And I stood men in the lowermost place from behind the wall, in the protected places. And I stood the people according to peoples, with their broadswords, and their wooden spears, and their bows. 

#### Nehemiah 4:14 And I beheld, and I rose up, and I spoke to the important ones, and to the commandants, and to the rest of the people, saying, You should not fear from their face. You should remember {God our great and fearful}, and deploy for your brethren, your sons, and your daughters, and your wives, and your residences! 

#### Nehemiah 4:15 And it came to pass when {heard our enemies} that it was made known to us, that {effaced God} their counsel, that {returned we all} to the wall, every man to his work. 

#### Nehemiah 4:16 And it came to pass from that day, that half of the ones being arrayed did the work, and half of them resisted with lances, and shields, and bows, and chest plates; and the rulers were behind the whole house of Judah. 

#### Nehemiah 4:17 The ones building on the wall, and the ones lifting things on their shoulders, {armed in one hand did his work}, and with one hand held the arrow. 

#### Nehemiah 4:18 And the builders -- a man had his broadsword tied upon his loin, and they built. And the one trumpeting by the horn was next to me. 

#### Nehemiah 4:19 And I said to the important ones, and to the rulers, and to the rest of the people, The work is spacious and vast, and we are dispersed upon the wall, {far with each man} from his brother. 

#### Nehemiah 4:20 In the place where ever you should hear the sound of the horn, gather together there to us, and our God shall wage war for us. 

#### Nehemiah 4:21 And we were doing the work, and the half of us were holding the lances from the ascending of the dawn until the coming out of the stars. 

#### Nehemiah 4:22 And in that time I said to the people, Each one with his young one shall lodge in the midst of Jerusalem, and let {be to us in the night an advance guard}, and let the day be for work! 

#### Nehemiah 4:23 And I was there, and my brethren, and the young men, and the men of the advance guard were behind me; and there was not of us {being stripped a man} of his own garments; a man and his weapons into the water. 

#### Nehemiah 5:1 And {was the cry of the people and their wives} great against their brethren of the Jews. 

#### Nehemiah 5:2 And there were some saying, With our sons and with our daughters we are many; and we shall take grain, and shall eat and shall live. 

#### Nehemiah 5:3 And there are some saying, Our fields, and our vineyards, and our houses we mortgaged, and we shall take grain and we shall eat. 

#### Nehemiah 5:4 And there are some saying, We borrowed money for tribute of the king of our fields, and our vineyards, and our houses. 

#### Nehemiah 5:5 And now {is as the flesh of our brethren our flesh}; as their sons our sons; and behold, we are tyrannizing over our sons and our daughters selling them for servants, and there are some of our daughters being tyrannized already; and there is no power to redeem them by our hands, for our fields and our vineyards belong to the important ones. 

#### Nehemiah 5:6 And I fretted very much as I heard their cry and these words. 

#### Nehemiah 5:7 And {took counsel my heart} with me, and I did combat against the important ones, and the rulers. And I said to them, Shall {exact a man} from his brother what you do? And I put upon them {assembly a great}. 

#### Nehemiah 5:8 And I said to them, We have acquired our brethren of the Jews, of the ones having been sold to the nations, by our voluntary offerings; and do you sell your brethren? Or shall they be sold to us? And they were quiet, and they did not find a word. 

#### Nehemiah 5:9 And I said, {is not good The matter} which you do. {not thus in the fear of our God Should you go forth} because of the scorn of the nations of our enemies? 

#### Nehemiah 5:10 And also I, and my brethren, and my acquaintances, put up for them money and grain; we abandoned indeed this exaction. 

#### Nehemiah 5:11 Return indeed to them, even today, their fields, and their vineyards, and their olive groves, and their houses, and of the money for the grain, and {the wine and the olive oil bring forth to them}! 

#### Nehemiah 5:12 And they said, We will give it back, and {from them we will not seek}, we shall do thus as you say. And I called the priests, and bound them by an oath to do as this saying. 

#### Nehemiah 5:13 And {my wrap I shook off}, and said, Thus shall {shake off God} every man who does not stand by this word, of his house, and of his toil; and he will be thus shaken and empty. And {said all the assembly}, Amen. And they praised the LORD. And {did the people} this thing. 

#### Nehemiah 5:14 And also from the day which he gave charge to me to be as their ruler in the land of Judah, from {year the twentieth}, and until {year the thirtieth and second} of Artaxerxes the king, {years twelve}, that even I and my brethren {bread of my governing did not eat}. 

#### Nehemiah 5:15 But the rulers, the ones before me, oppressed upon the people, and took from them in bread loaves and in wine; and last money {shekels of forty}. And also their servants dominated over the people. But I did not do so because of the countenance of the fear of the LORD. 

#### Nehemiah 5:16 And in the work of the wall {these things I repaired}. {fields of land I did not acquire}, and my servants and all the ones gathering were there for work. 

#### Nehemiah 5:17 And the Jews, and the rulers were a hundred fifty men, and the ones coming to us from the nations round about us were at my table. 

#### Nehemiah 5:18 And there was coming in {day one} -- {calf one}, and {sheep six choice}, and a winter yearling; there came to me also in the midst of ten days all wine in multitude. And with these {bread of my governing I did not seek}, for {was heavy the slavery} upon this people. 

#### Nehemiah 5:19 Remember me, O God! for all good as much as I did to this people. 

#### Nehemiah 6:1 And it came to pass as Sanballat heard, and Tobiah, and Geshem the Arabian, and the rest of our enemies, that I built the wall, that there was no {left in it breach}; (and indeed until that time {the doors I did not set up} in the gates) 

#### Nehemiah 6:2 that {sent Sanballat and Geshem} to me, saying, Come, for we should come together in the towns in the plain of Ono! But they were considering {against me to do harm}. 

#### Nehemiah 6:3 And I sent {unto them messengers}, saying, The work is great that I do, and I am not able to go down, lest at any time {should rest the work}; when ever I shall perfect it, I shall go down to you. 

#### Nehemiah 6:4 And they sent to me as this saying four returns; and I sent to them according to this word. 

#### Nehemiah 6:5 And {sent to me Sanballat} according to this word the fifth time by his servant, and a letter being open was in his hand. 

#### Nehemiah 6:6 And was written on it, Among the nations it was heard, and Geshem said that you and the Jews are considering to defect. On account of this you are building the wall, and you should be to them for king. 

#### Nehemiah 6:7 And to these things {prophets you established to yourself} to proclaim for you in Jerusalem, saying that you reigned in Judea. And now {will be reported to the king these words}. And now come we should consult together. 

#### Nehemiah 6:8 And I sent to him, saying, It happened not as these words which you say, for {from the heart you lie} about them. 

#### Nehemiah 6:9 For all were throwing us into fear, saying, {shall be made faint Their hands} from this work, and it shall not be done. And now I strengthened my hands. 

#### Nehemiah 6:10 And I entered into the house of Shemaiah son of Dalaiah, son of Mehetabeel, and he was constrained; and he said, We should gather together in the house of God, in the midst of it, and we should lock its doors, for they are coming by night to murder you. 

#### Nehemiah 6:11 And I said, Who is the man such as I that shall flee? Or who such as I shall enter into the house and shall live? 

#### Nehemiah 6:12 I shall not enter. And I realized, and behold, God did not send him, for the prophesy was a word against me. And Tobiah and Sanballat hired him, 

#### Nehemiah 6:13 so that I should fear, and should do thus, and should sin, and that I should become to them for {name a bad}, so as to berate me. 

#### Nehemiah 6:14 Remember, O my God, Tobiah and Sanballat! according to {their actions these}, and Noadiah the prophet, and to the rest of the prophets who were throwing me into fear. 

#### Nehemiah 6:15 And {was finished the wall} the fifth and twentieth of the {Elul month}, in fifty two days. 

#### Nehemiah 6:16 And it came to pass when {heard all our enemies}, that {feared all the nations round about us}, and {fell upon fear great an exceedingly} their eyes. And they knew that by God {of ours was perfected work this}. 

#### Nehemiah 6:17 And in those days {from many important men of Judah letters went} to Tobiah, and those of Tobiah came to them. 

#### Nehemiah 6:18 For many in Judah {bound by an oath were} to him, for {son-in-law he was} of Shechaniah son of Arah. And Johanan his son took the daughter of Meshullam, son of Berechiah for wife. 

#### Nehemiah 6:19 And indeed the things being advantageous to him he spoke before me; and {my words they were bringing} to him. And {letters sent Tobiah} to throw me into fear. 

#### Nehemiah 7:1 And it came to pass when {was built the wall}, and I set the doors, and numbered out the gatekeepers, and the singers, and the Levites, 

#### Nehemiah 7:2 and gave charge to Hanani my brother, and to Hananiah the ruler of the palace in Jerusalem, (for he was as {man a true}, and one fearing God more than many,) 

#### Nehemiah 7:3 that I said to them, {shall not be opened The gates of Jerusalem} until at the same time the sun rises; and while they are still vigilant let {be locked the doors} and be safeguarded! And you set advance guards of ones living in Jerusalem, every man at his own post, and every man before his own house! 

#### Nehemiah 7:4 And the city was spacious and great, and the people were few in it, and there were no houses having been built. 

#### Nehemiah 7:5 And {put it God} into my heart, and I gathered the important ones, and the rulers, and the people into groups. And I found a scroll of the group, to the ones which ascended at first, and I found things being written in it. 

#### Nehemiah 7:6 These are the sons of the place, the ones ascending from the captivity of the resettlement of whom {resettled Nebuchadnezzar the king of Babylon}, and they returned to Jerusalem, and to Judah, every man to his own city; 

#### Nehemiah 7:7 the ones coming with Zerubbabel, and Jeshua, and Nehemiah, Azariah, and Raamiah, Nahamani, Mordecai, Bilshan, Mispereth Bigvai, Nehum, Baana and Masphar; the men of the people of Israel -- 

#### Nehemiah 7:8 sons of Parosh, two thousand one hundred seventy-two; 

#### Nehemiah 7:9 sons of Shephatiah, three hundred seventy-two; 

#### Nehemiah 7:10 sons of Arah, six hundred fifty-two; 

#### Nehemiah 7:11 sons of Pahath-moab, with the sons of Jeshua, and Joab, two thousand eight hundred eighteen; 

#### Nehemiah 7:12 sons of Elam, a thousand two hundred fifty-four; 

#### Nehemiah 7:13 sons of Zattu, eight hundred forty-five; 

#### Nehemiah 7:14 sons of Zaccai, seven hundred sixty; 

#### Nehemiah 7:15 sons of Binnui, six hundred forty-eight; 

#### Nehemiah 7:16 sons of Bebai, six hundred twenty-eight; 

#### Nehemiah 7:17 sons of Azgad, two thousand three hundred twenty-two; 

#### Nehemiah 7:18 sons of Adonikam, six hundred sixty-seven; 

#### Nehemiah 7:19 sons of Bigvai, two thousand sixty-seven; 

#### Nehemiah 7:20 sons of Adin, six hundred fifty-five; 

#### Nehemiah 7:21 sons of Ater of Hezekiah, ninety-eight; 

#### Nehemiah 7:22 sons of Hashum, three hundred twenty-eight; 

#### Nehemiah 7:23 sons of Bezai, three hundred twenty-four; 

#### Nehemiah 7:24 sons of Hariph, a hundred twelve; sons of Asen -- two hundred twenty-three; 

#### Nehemiah 7:25 sons of Gibeon, ninety-five; 

#### Nehemiah 7:26 sons of Beth-lehem and Netophah, a hundred twenty-three.; 

#### Nehemiah 7:27 sons of Anathoth, a hundred twenty-eight; 

#### Nehemiah 7:28 sons of Beth-azmaveth, {men forty-two}; 

#### Nehemiah 7:29 men of Kirjath-jearim, Chephirah and Beeroth, seven hundred forty-three; 

#### Nehemiah 7:30 men of Ramah and Gaba, six hundred twenty-one; 

#### Nehemiah 7:31 men of Michmas, a hundred twenty-two; 

#### Nehemiah 7:32 men of Beth-el and Ai, a hundred twenty-three; 

#### Nehemiah 7:33 men of the other Nebo, fifty-two; 

#### Nehemiah 7:34 sons of the other Elam, a thousand two hundred fifty-four; 

#### Nehemiah 7:35 sons of Harim, three hundred twenty; 

#### Nehemiah 7:36 sons of Jericho, three hundred forty-five; 

#### Nehemiah 7:37 sons of Lod Hadid and Ono, seven hundred twenty-one; 

#### Nehemiah 7:38 sons of Senaah, three thousand nine hundred thirty. 

#### Nehemiah 7:39 The priests; the sons of Jedaiah in the house of Jeshua, nine hundred seventy-three; 

#### Nehemiah 7:40 sons of Immer, a thousand fifty-two; 

#### Nehemiah 7:41 sons of Pashur, a thousand two hundred forty-seven; 

#### Nehemiah 7:42 sons of Harim, a thousand seventeen. 

#### Nehemiah 7:43 The Levites; sons of Jeshua the son of Kadmiel, with the sons of Hodevah, seventy-four. 

#### Nehemiah 7:44 The singers; sons of Asaph, a hundred forty-eight. 

#### Nehemiah 7:45 The gatekeepers; sons of Shallum, sons of Ater, sons of Talmon, sons of Akkub, sons of Hatita, sons of Shobai, a hundred thirty-eight. 

#### Nehemiah 7:46 The Nethinim; sons of Ziha, sons of Hashupha, sons of Tabbaoth, 

#### Nehemiah 7:47 sons of Keros, sons of Sia, sons of Padon, 

#### Nehemiah 7:48 sons of Lebana, sons of Hagaba, sons of Shalmai, 

#### Nehemiah 7:49 sons of Hanan, sons of Giddel, sons of Gahar, 

#### Nehemiah 7:50 sons of Reaiah, sons of Rezin, sons of Nekoda, 

#### Nehemiah 7:51 sons of Gazzam, sons of Uzza, sons of Phaseah, 

#### Nehemiah 7:52 sons of Besai, sons of Meunim, sons of Nephishesim, 

#### Nehemiah 7:53 sons of Bakbuk, sons of Hakupha, sons of Harhur, 

#### Nehemiah 7:54 sons of Bazlith, sons of Mehida, sons of Harsha, 

#### Nehemiah 7:55 sons of Barkos, sons of Sisera, sons of Tamah, 

#### Nehemiah 7:56 sons of Neziah, sons of Hatipha. 

#### Nehemiah 7:57 The sons of the servants of Solomon were the sons of Sotai, sons of Sophereth, sons of Perida, 

#### Nehemiah 7:58 sons of Jaala, sons of Darkon, sons of Giddel, 

#### Nehemiah 7:59 sons of Shephatiah, sons of Hattil, sons of Pochereth, sons of Zebaim, sons of Amon. 

#### Nehemiah 7:60 All the Nethinim, and the sons of the servants of Solomon were three hundred ninety-two. 

#### Nehemiah 7:61 And these ascended from Tel-melah, Tel-haresha, Cherub, Addon, Immer. And they were not able to identify the houses of their families, and their seed, if {of Israel they are}. 

#### Nehemiah 7:62 The sons of Dalaiah, sons of Tobiah, sons of Nekoda, were six hundred forty-two. 

#### Nehemiah 7:63 And from the priests; sons of Habaiah, sons of Koz, sons of Barzillai, which took of the daughters of Barzillai the Gileadite for wife, and was called by their name. 

#### Nehemiah 7:64 These sought the record of their own group, and it was not found, and they were thrust away of the priesthood. 

#### Nehemiah 7:65 And Arthasastha said to them, that they should not eat from the holy of holies until {should rise up a priest} to the lights and the perfections. 

#### Nehemiah 7:66 And {was all the assembly} in one accord, as four ten thousands and two thousand three hundred sixty, 

#### Nehemiah 7:67 besides their menservants and their maidservants -- these were seven thousand three hundred thirty-seven; and male singers and female singers -- two hundred forty-five. 

#### Nehemiah 7:68 Their horses -- seven hundred thirty-six; mules -- two hundred forty-five; camels -- four hundred thirty five; 

#### Nehemiah 7:69 donkeys -- six thousand seven hundred twenty. 

#### Nehemiah 7:70 And from a portion of the heads of the families gave for the work, to the Arthasastha for a treasure -- {of gold drachmas a thousand}, {bowls fifty}, {robes for the priests five hundred thirty}. 

#### Nehemiah 7:71 And from the heads of the families they gave into the treasuries of the work {of gold money} -- {ten thousands two}, and {silver minas two thousand two hundred}. 

#### Nehemiah 7:72 And {gave the rest of the people} {of gold drachmas two ten thousands}, and {silver minas two thousand}, and {garments for the priests sixty-seven}. 

#### Nehemiah 7:73 And {settled the priests}, and the Levites, and the gatekeepers, and the singers, and the ones from the people, and the Nethinim, and all Israel in their cities. 

#### Nehemiah 8:1 And {arrived month the seventh}, and the sons of Israel were in their cities. And {gathered together all the people} as {man one} into the wide place in front of {gate the water}. And they told Ezra the scribe to bring the scroll of the law of Moses, which the LORD gave charge to Israel. 

#### Nehemiah 8:2 And {brought Ezra the priest} the law before the assembly, from man unto woman, and all the ones perceiving to hear, on day one of the {month seventh}. 

#### Nehemiah 8:3 And he read in it before the square of the one before the gate of the waters, from the hour of the illuminating by the sun until the middle of the day, before men and women. And they were perceiving, even all the ears of the people, to the scroll of the law. 

#### Nehemiah 8:4 And {stood Ezra the scribe} upon {rostrum the wooden}, the one he made for delivering a public address. And stood next to him, Mattithiah, and Shema, and Anaiah, and Uriah, and Hilkiah, and Maaseiah at his right. And at the left, Pedaiah, and Mishael, and Malchiah, and Hashum, and Hashbadana, and Zechariah, and Meshullam. 

#### Nehemiah 8:5 And Ezra opened the scroll before all the people, for he was above the people. And it came to pass when he opened it, {stood all the people}. 

#### Nehemiah 8:6 And Ezra blessed the LORD, the {God great}. And {answered all the people}, and said, Amen, amen, lifting up their hands; and they bowed and did obeisance to the LORD with their face upon the ground. 

#### Nehemiah 8:7 And Joshua, and Bani, and Sherebiah, Jamin, and Akkub, Shabbethai, and Hodijah, and Maaseiah, and Kelita, and Azariah, and Jozabad and Hanan, and Pelaiah, and the Levites, were bringing understanding to the people in the law. And the people were at their station. 

#### Nehemiah 8:8 And they read in the scroll of the law of God; and Ezra taught and gave orders in a higher knowledge of the LORD, and {perceived the people} in the reading. 

#### Nehemiah 8:9 And Nehemiah spoke, who is the Artasastha, and Ezra the priest and scribe, and the Levites, the ones bringing understanding to the people. And they said to all the people, {day a holy It is} to the LORD our God, do not mourn nor weep! for {wept all the people} as they heard the words of the law. 

#### Nehemiah 8:10 And he said to them, Go and eat fatness, and drink sweetness, and send portions to the ones not having! for {holy is the day} to the LORD our God. And do not faint! for the joy of the LORD, this is our strength. 

#### Nehemiah 8:11 And the Levites quelled all the people, saying, Keep silent, for the day is holy, and do not fall down! 

#### Nehemiah 8:12 And {went forth all the people} to eat, and to drink, and to send portions, and to make {gladness great}; for they perceived the words which he made known to them. 

#### Nehemiah 8:13 And on the {day second} {gathered together the rulers of the families} with all the people, and the priests, and the Levites, to Ezra the scribe, to attend to all the words of the law. 

#### Nehemiah 8:14 And they found written in the law which the LORD gave charge to Moses, that {should dwell the sons of Israel} in tents in the holiday in {month the seventh}; 

#### Nehemiah 8:15 and that they should signify with trumpets in all their cities, and in Jerusalem. And Ezra said, Go forth unto the mountain, and bring {leaves olive}, and leaves {trees of cypress}, and leaves of a myrtle tree, and leaves of palms, and leaves {tree of the bushy}! to make tents according to the writing. 

#### Nehemiah 8:16 And {went forth the people}, and brought, and they made for themselves tents, each man upon his roof, and in their courtyards, and in the courtyards of the house of God, and in the squares of the gate of the waters, and in the squares of the gate of Ephraim. 

#### Nehemiah 8:17 And {made all the assembly of the ones returning from the captivity} tents, and they stayed in tents; for {did not do from the days of Joshua son of Nun thus the sons of Israel} until that day. And there became {gladness a great} -- exceedingly much. 

#### Nehemiah 8:18 And he read in the scroll of the law of God day by day; from the {day first} until the {day last}. And they observed the holiday seven days, and the {day eighth} was a holiday recess, according to the distinguishing manner. 

#### Nehemiah 9:1 And on {day the twentieth and fourth} of this month, {gathered together the sons of Israel} for fasting, and with sackcloths and ashes upon their head. 

#### Nehemiah 9:2 And {separated the sons of Israel} from every {son alien}; and they stood and declared openly their sins, and the lawless deeds of their fathers. 

#### Nehemiah 9:3 And they stood in their position, and they read in the scroll of the law of the LORD their God the fourth of the day. And they were declaring openly to the LORD the fourth of the day, and doing obeisance to the LORD their God. 

#### Nehemiah 9:4 And {stood upon the ascent of the Levites Jeshua}, and the sons of Kadmiel, Secheniah son of Sherebiah, son of Chenani. And they yelled {voice with a great} to the LORD their God. 

#### Nehemiah 9:5 And {said the Levites}, Jeshua and Kadmiel, Bani, Sherebiah, Hodijah Shebaniah, Pethahiah, Rise up, bless the LORD our God from the eon and unto the eon! And they shall bless {name glorious your}, and shall raise it up high with all blessing and praise. 

#### Nehemiah 9:6 And Ezra said, You are he, the LORD alone. You made the heaven and the heaven of the heaven, and all their positions; the earth and all as much as is in it; the seas and all the things in them. And you restore to life all things; and to you {do obeisance the militaries of the heavens}. 

#### Nehemiah 9:7 You are, O LORD, the God. You chose Abram, and you led him from the place of the Chaldeans, and placed unto him the name Abraham. 

#### Nehemiah 9:8 And you found his heart trustworthy before you, and you ordained with him a covenant, so as to give to him the land of the Canaanites, and Hittites, and Amorites, and Perizzites, and Jebusites, and Girgashites, and to give it to his seed. And you established your words, for you are just. 

#### Nehemiah 9:9 And you beheld the humiliation of our fathers in Egypt, and {their cry you heard} at {sea the red}. 

#### Nehemiah 9:10 And you gave signs and miracles in Egypt to Pharaoh, and among all his servants, and among all the people of his land, for you knew that they extolled themselves above them; and you made for yourself a name as it is this day. 

#### Nehemiah 9:11 And {the sea you tore up} before them, and they went in the midst of the sea in dryness; and the ones pursuing them you tossed into the bottom of the sea, as a stone in {water vehement}. 

#### Nehemiah 9:12 And in a column of cloud you guided them by day; and by a column of fire at night, to give light to them for the way in which they went by it. 

#### Nehemiah 9:13 And upon mount Sinai you went down and spoke to them from out of heaven, and you gave to them {judgments right}, and laws of truth, orders, and {commandments good}. 

#### Nehemiah 9:14 And {Sabbath your holy} you made known to them; commandments, and orders, and law, you gave charge to them by the hand of Moses your servant. 

#### Nehemiah 9:15 And bread from heaven you gave to them for their provision, and water from out of the rock you brought forth for them for their thirst. And you spoke to them to enter to inherit the land into which you stretched out your hand to give to them. 

#### Nehemiah 9:16 But they and our fathers were prideful, and they hardened their neck, and they did not hearken unto your commandments. 

#### Nehemiah 9:17 And they shook their heads in dissent to listen, and did not remember your wonders which you performed among them. And they hardened their neck, and they granted a sovereign to return {to slavery them} in Egypt. But you, O God, in forgiving sins are merciful and pitying, lenient and full of mercy, and did not abandon them. 

#### Nehemiah 9:18 And still also they made for themselves {calf a molten}. And they said, These are the gods, the ones leading us from Egypt. And they committed {provocations to anger great}. 

#### Nehemiah 9:19 And you in {compassions your great} did not abandon them in the wilderness. The column of cloud did not turn aside from them by day to guide them in the way; and the column of fire by night to give light to them in the way in which they went by it. 

#### Nehemiah 9:20 And {spirit your good} gave a bringing of understanding to them, and your manna you did not withhold from their mouth, and {water you gave} to them in their thirst. 

#### Nehemiah 9:21 And forty years you nourished them in the wilderness, and {lacked not they} one thing; their garments did not become old, and their sandals were not torn up. 

#### Nehemiah 9:22 And you gave them kingdoms, and {peoples you divided} to them. And they inherited the land of Sihon king of Heshbon, and the land of Og king of Bashan. 

#### Nehemiah 9:23 And their sons you multiplied as the stars of the heaven, and brought them into the land which you spoke to their fathers, to enter and to inherit. 

#### Nehemiah 9:24 And {entered their sons} and inherited the land. And you obliterated before them the ones dwelling the land of the Canaanites, and you gave them into their hands, even their kings, and the peoples of the land, to do to them as was pleasing before them. 

#### Nehemiah 9:25 And they overtook {cities high}, and {land a fertile}. And they inherited houses full of all good things, and pits for quarrying, vineyards and olive groves, and every tree of eatable things in multitude. And they ate, and were filled up, and were fattened, and indulged in {goodness your great}. 

#### Nehemiah 9:26 And they changed and revolted from you. And they tossed your law behind their body, and {your prophets they killed}, the ones testifying to them to turn them towards you. And they made {provocations to anger great}. 

#### Nehemiah 9:27 And you gave them into the hand of ones afflicting them, and they afflicted them. And they yelled out to you in the time of their affliction, and you {from out of your heaven heard}, and in {compassions your great} you gave deliverers to them, and they delivered them from the hand of ones afflicting them. 

#### Nehemiah 9:28 And as they were caused to rest, they turned to act wickedly before you. And you abandoned them into the hands of their enemies, and they ruled among them. And again they yelled out to you. And you from out of heaven listened and rescued them by {compassions your abundant}. 

#### Nehemiah 9:29 And you attested to them, to turn them to your law. But they acted superior, and hearkened not of your commandments. And in your judgments they sinned, (which {doing them a man} shall live by them;) and they gave their back unto resisting persuasion, and {their neck they hardened}, and they did not hearken. 

#### Nehemiah 9:30 And you were long-suffering unto them {years many}, and drew out patience unto them {years many}, and attested to them by your spirit, by the hand of your prophets. But they did not give ear, and you gave them into the hand of the peoples of the land. 

#### Nehemiah 9:31 And you, in {compassions your abundant} did not appoint them to consummation, and you did not abandon them; for you are strong, and merciful, and pitying. 

#### Nehemiah 9:32 And now, O our God, the strong, the great, the fortified and fearsome; guarding your covenant, and your mercy; do not let your attention be lessened before you concerning all the trouble which found us, and our kings, and our rulers, and our priests, and our prophets, and our fathers, and among all your people from the days of the kings of Assyria, and until this day! 

#### Nehemiah 9:33 For you are just concerning all the things coming upon us, for truth you acted, but we were led into sin. 

#### Nehemiah 9:34 And our kings, and our rulers, and our priests, and our fathers observed not your law, and heeded not your commandments, and your testimonies which you testified to them. 

#### Nehemiah 9:35 And they in your kingdom, and in {goodness your abundant} which you gave to them, and in the {land spacious and lustrous} which you put before them, did not serve you, and they did not turn from {practices their wicked}. 

#### Nehemiah 9:36 Behold, we are today servants, and the land which you gave to our fathers, to eat the fruit of it, and the good things of it, even behold, we are servants upon it. 

#### Nehemiah 9:37 And {fruits its many} became to the kings which you put over us because of our sins; and {over our bodies they exercise authority}, and over our cattle as is pleasing to them, and {in affliction great we are}. 

#### Nehemiah 9:38 And in all these things we are ordained a trust, and we write it; and {put a seal upon it our rulers} -- our Levites, our priests. 

#### Nehemiah 10:1 And over the ones setting the seal were Nehemiah the Artasastha, son of Hachaliah, and Zidkijah, 

#### Nehemiah 10:2 son of Seraiah, and Azariah, and Jeremiah, 

#### Nehemiah 10:3 Pashur, Amariah, Malchijah, 

#### Nehemiah 10:4 Hattush, Shebaniah Harim, Malluch, 

#### Nehemiah 10:5 Meremoth, Obadiah, 

#### Nehemiah 10:6 Daniel, Ginnethon, Baruch, 

#### Nehemiah 10:7 Meshullam, Abijah, Mijamin, 

#### Nehemiah 10:8 Maaziah, Bilgai, and Shemaiah; these were the priests. 

#### Nehemiah 10:9 And the Levites; Jeshua son of Azaniah, Binnui of the sons of Henadad, Kadmiel; 

#### Nehemiah 10:10 and his brethren, Shebaniah, Hodijah, Kelita, Pelaiah, Hanan. 

#### Nehemiah 10:11 Micha, Rehob, Hashabiah, 

#### Nehemiah 10:12 Zaccur, Sherebiah, Shebaniah, and Hodijah, 

#### Nehemiah 10:13 the sons of Beninu. 

#### Nehemiah 10:14 The rulers of the people; Parosh, Pahath-moab, Elam, and Zatthu, sons of Bunni, 

#### Nehemiah 10:15 Azgad, Bebai, 

#### Nehemiah 10:16 Adonijah, Bigvai, Adin, 

#### Nehemiah 10:17 Ater, Hizkijah, Azzur, 

#### Nehemiah 10:18 Hodijah, Hashum, Bezai, 

#### Nehemiah 10:19 Hariph, Anathoth, Nebai, 

#### Nehemiah 10:20 Magpiash, Meshullam, Hezir, 

#### Nehemiah 10:21 Meshezabeel, Zadok, Jaddua, 

#### Nehemiah 10:22 Pelatiah, Hanan, Anaiah, 

#### Nehemiah 10:23 Hoshea, Hananiah, Hashub, 

#### Nehemiah 10:24 Hallohesh, Pileha, Shobek, 

#### Nehemiah 10:25 Rehum, Hashabnah, Maaseiah, 

#### Nehemiah 10:26 Ahijah, Hanan, Anan, 

#### Nehemiah 10:27 Malluch, Harim, Baanah. 

#### Nehemiah 10:28 And the rest of the people, the priests, the Levites, the gatekeepers, the singers, the Nethinim, and all the ones being parted from the peoples of the land to the law of God -- their wives, their sons, their daughters, every one knowing and perceiving, 

#### Nehemiah 10:29 growing in strength with their brethren, and imprecating maledictions upon themselves, and entering into a curse, and into an oath, to go by the law of God, which was given by the hand of Moses the servant of God, to guard and to observe all the commandments of the LORD our God, and his judgments, and his orders; 

#### Nehemiah 10:30 and to not give our daughters to the peoples of the land, and {their daughters to not take} for our sons. 

#### Nehemiah 10:31 And concerning the peoples of the land bringing things for purchase, and all things for sale during {day the Sabbath}, to deliver up for sale -- we shall not buy from them during the Sabbath, nor during {days the holy}. And we shall ascend the {year seventh}, and the exaction of every debt of hand. 

#### Nehemiah 10:32 And we shall establish for us commandments to yield up for us a third of the double-drachma per year for the service of the house of our God, 

#### Nehemiah 10:33 for the bread loaves in front, and {sacrifice offering the perpetual}, and for {whole burnt-offering the perpetual}, of the Sabbaths, of the new moons, for the holidays, and for the holy things, and the things for a sin offering, to atone for Israel, and for the works of the house of our God. 

#### Nehemiah 10:34 And {lots we cast} for the gifts of bearing wood (the priests, and the Levites, and the people), to bring into the house of our God, according to houses of our families, at seasons, from times, year by year, to burn upon the altar of the LORD our God, as is written in the law; 

#### Nehemiah 10:35 and to bring the first produce of our land, and the first produce of the fruit of every tree, year by year, into the house of the LORD; 

#### Nehemiah 10:36 and the first-born of our sons, and of our cattle, as is written in the law, and the first-born of our oxen, and of our flocks, to bring into the house of our God, for the priests, to the ones officiating in the house of our God. 

#### Nehemiah 10:37 And the first-fruit of our grain, and our first-fruit offerings, and the fruit of every tree, of wine and olive oil, we shall bring to the priests, into the treasuries of the house of our God. And tenths of our land to the Levites. And they themselves, the Levites, are receiving a tenth in all the cities of our servitude. 

#### Nehemiah 10:38 And {will be the priest the son of Aaron} with the Levites in the tenth of the Levites. And the Levites shall offer the tenth of the tenth for the house of our God, into a treasury of the house of the treasury. 

#### Nehemiah 10:39 For into the treasuries {shall carry in the sons of Israel and sons of the Levites} the first-fruits of the grain, and of the wine, and of the olive oil. And {are there vessels the holy}, and the priests, the ministers, and the gatekeepers, and the singers. And we shall not abandon the house of our God. 

#### Nehemiah 11:1 And {were settled the rulers of the people} in Jerusalem. And the rest of the people cast lots to bring one from every ten to settle in Jerusalem {city the holy}, and nine parts in the other cities. 

#### Nehemiah 11:2 And {blessed the people} all the men of the ones willing to settle in Jerusalem. 

#### Nehemiah 11:3 And these are the rulers of the place, the ones they settled in Jerusalem, and in the cities of Judah. {settled Every man} in his possession in their cities -- Israelites, the priests, and the Levites, and the Nethinim, and the sons of the servants of Solomon. 

#### Nehemiah 11:4 And in Jerusalem were settled some from the sons of Judah, and from the sons of Benjamin. From the sons of Judah; Athaiah son of Uzziah, son of Zechariah, son of Amariah, son of Shephatiah, son of Mahalaleel, and of the sons of Perez; 

#### Nehemiah 11:5 Maaseiah son of Baruch, son of Col-hozeh, son of Hazaiah, son of Adaiah, son of Joiarib, son of Zechariah, son of the Shiloni. 

#### Nehemiah 11:6 All the sons of Perez, the ones settling down in Jerusalem were four hundred sixty-eight men of power. 

#### Nehemiah 11:7 And these are the sons of Benjamin; Sallu son of Meshullam, son of Joed, son of Pedaiah, son of Kolaiah, son of Masseiah, son of Ithiel, son of Jesaiah. 

#### Nehemiah 11:8 And after him Gabbai, Sallai, nine hundred twenty-eight. 

#### Nehemiah 11:9 And Joel son of Zichri was overseer over them; and Judah son of Senuah over the city was second. 

#### Nehemiah 11:10 Of the priests; even Jadaiah son of Joiarib, Jachin. 

#### Nehemiah 11:11 Seraiah son of Hilkiah, son of Meshullam, son of Zadok, son of Maraioth, son of Ahitub ruling the house of God. 

#### Nehemiah 11:12 And their brethren doing the work of the house -- eight hundred twenty-two; and Adaiah, son of Jeroham, son of Pelaliah, of the son of Amzi, son of Zechariah, son of Pashur, son of Malchiah. 

#### Nehemiah 11:13 And his brethren the rulers of families -- two hundred forty-two; even Amashai son of Azareel, son of Sikiah, son of Meshillemoth, son of Immer, 

#### Nehemiah 11:14 and his brethren, mighty men of battle array -- a hundred twenty-eight. And overseer over them was Zabdiel, son of the great ones. 

#### Nehemiah 11:15 And from the Levites; Shemaiah son of Hashub, son of Azrikam, son of Hashabiah son of Bunni, 

#### Nehemiah 11:16 and Shabbethai and Jozabad were over the works of the house of God, the outermost; and of the rulers of the Levites. 

#### Nehemiah 11:17 And Mattaniah son of Micha, son Zechri son of Asaph was one in charge of the praise, and Juda of the prayer, and Bakbukiah second of of his brethren, and Abda son of Shammua, son of Galal, son of Jeduthun. 

#### Nehemiah 11:18 All the Levites in the {city holy} -- two hundred eighty-four. 

#### Nehemiah 11:19 And the gatekeepers; Akkub, Talmon, and their brethren, the ones guarding at the gates -- a hundred seventy-two. 

#### Nehemiah 11:20 And the rest of Israel, and the priests, and the Levites were in all the cities of Judah, every man in his inheritance. 

#### Nehemiah 11:21 And the Nethinim dwelt in Ophel; and Ziha and Gispa were of the Nethinim. 

#### Nehemiah 11:22 And the overseer of the Levites in Jerusalem was Uzzi son of Bani, son of Hashabiah, son of Mattaniah, son of Micha, from the sons of Asaph the singers before the work of the house of God. 

#### Nehemiah 11:23 For a commandment of the king was upon them, and it continued in trust unto the singers a reckoning each day in its day. 

#### Nehemiah 11:24 And Pethahiah son of Meshezabeel of the sons of Zerah, son of Judah, was by the hand of the king for all matters concerning the people. 

#### Nehemiah 11:25 And for the properties in their fields, some from the sons of Judah settled in Kirjath-arba, and in her daughter towns, and in Dibon, and in her daughter towns, and in Jekabseel, and in her courtyards, 

#### Nehemiah 11:26 and in Jeshua, and in Moladah, and in Beth-phelet, 

#### Nehemiah 11:27 and in Hazar-shual and in Beer-sheba, and her daughter towns, 

#### Nehemiah 11:28 and in Ziklag, and in Mabne, and in her daughter towns, 

#### Nehemiah 11:29 and in Rimmon, and in Zereah, and in Jarmuth, 

#### Nehemiah 11:30 and in Zanoah, and Adullam, and her properties, and in Lachish, and her fields, and in Azekah, and in her daughter towns. And they camped in Beer-sheba unto the ravine of Hinnom. 

#### Nehemiah 11:31 And the sons of Benjamin dwelt from Geba and unto Michmash, and Aija, and Beth-el, and her daughter towns; 

#### Nehemiah 11:32 and in Anathoth, Nob, Ananiah, 

#### Nehemiah 11:33 Hazor, Ramah, Gittaim, 

#### Nehemiah 11:34 Hadid, Zeboim, Neballat, 

#### Nehemiah 11:35 Lod, and Ono-kareseim. 

#### Nehemiah 11:36 And of the Levites there were portions in Judah and Benjamin. 

#### Nehemiah 12:1 And these are the priests and the Levites, the ones ascending with Zerubbabel son of Shealtiel, and Jeshua; Saraiah, Jeremiah, Ezra, 

#### Nehemiah 12:2 Amariah, Malluch, Hattush, 

#### Nehemiah 12:3 Shechaniah, Rehum, Meremoth, 

#### Nehemiah 12:4 Iddo, Ginnetho, Abijah, 

#### Nehemiah 12:5 Miamin, Maadiah, Bilgah, 

#### Nehemiah 12:6 Shemaiah, Joiarib, Jedaiah, 

#### Nehemiah 12:7 Sallu, Amok, Hilkiah, Jedaiah. These were the rulers of the priests, and their brethren in the days of Jeshua. 

#### Nehemiah 12:8 And the Levites; Jeshua, Binnui, Kadmiel, Sherebiah, Joiada, Mattaniah, which was over the acknowledgments, he and his brethren. 

#### Nehemiah 12:9 And Bakbukiah and Unni, their brethren were over against them in the daily rotations. 

#### Nehemiah 12:10 And Jeshua engendered Joiakim, and Joiakim engendered Eliashib, and Eliashib engendered Joiada, 

#### Nehemiah 12:11 and Joiada engendered Jonathan, and Jonathan engendered Jaddua. 

#### Nehemiah 12:12 And in the days of Joiakim were the priests, and the rulers of the families -- to Seraiah, Meraiah; to Jeremiah, Hananiah; 

#### Nehemiah 12:13 to Ezra, Meshullam; to Amariah, Jehohanan; 

#### Nehemiah 12:14 to Melicu, Jonathan; to Secheniah, Joseph; 

#### Nehemiah 12:15 to Harim, Adna; to Maraioth, Helkai; 

#### Nehemiah 12:16 to Iddo, Zechariah; to Ginnethon, Meshullam; 

#### Nehemiah 12:17 to Abijah, Zichri; to Miniamin, Moadiah, to Piltai, 

#### Nehemiah 12:18 to Bilgah, Shammua; to Shemaiah, Jehonathan; 

#### Nehemiah 12:19 to Joiarib, Mattenai; to Jedaiah, Uzzi; 

#### Nehemiah 12:20 to Sallai, Kallai; to Amok, Eber; 

#### Nehemiah 12:21 to Hilkiah, Hashabiah; to Jedaiah, Nethaneel. 

#### Nehemiah 12:22 The Levites in the days of Eliashib, were Joiada, and Joa, and Johanan, and Jaddua they were written down as rulers of the families; and the priests in the kingdom of Darius the Persian. 

#### Nehemiah 12:23 And the sons of Levi, rulers of the families were written upon the scroll of the words of the days, even until the days of Johanan son of Eliashib. 

#### Nehemiah 12:24 And the rulers of the Levites -- Hashabiah, and Sherebiah, and Jeshua. And the sons of Kadmiel, and their brethren over against them, for praising and making acknowledgment, by the command of David the man of God, in daily rotation by daily rotation. 

#### Nehemiah 12:25 Mattaniah and Bakbukiah, Obadiah, Meshullam, Talmon, Akkub, were guarding gatekeepers of the watch in my gathering the gatekeepers. 

#### Nehemiah 12:26 These were in the days of Joiakim son of Jeshua, son of Jozadak, and in the days of Nehemiah the ruler, and Ezra the priest and scribe. 

#### Nehemiah 12:27 And in the festival of dedication of the wall of Jerusalem they sought out the Levites in their places, to bring them into Jerusalem, to observe the holiday of rededication with gladness, and in praise, and in odes, playing cymbals, and psalteries, and lutes. 

#### Nehemiah 12:28 And {gathered the sons of the singers} even from the place round about Jerusalem, and from the properties of the Netophathi. 

#### Nehemiah 12:29 And in Beth-gilgal and from the fields of Geba and Azmaveth; for {nearby properties built for themselves the singers} surrounding Jerusalem. 

#### Nehemiah 12:30 And {cleansed themselves the priests and the Levites}, and they cleansed the people, and the gates, and the wall. 

#### Nehemiah 12:31 And they brought the rulers of Judah upon the wall, and I stationed two {for praise great companies}, and they went at the right the wall of the gate of the dung. 

#### Nehemiah 12:32 And {went behind them Hoshaiah and half of the rulers of Judah}, 

#### Nehemiah 12:33 and Azariah, and Ezra, and Meshullam, 

#### Nehemiah 12:34 and Judah, and Benjamin, and Shemaiah, and Jeremiah. 

#### Nehemiah 12:35 And some from the sons of the priests with trumpets; Zechariah son of Jonathan, son of Shemaiah, son of Mathaniah son of Michaiah, son of Zaccur, son of Asaph. 

#### Nehemiah 12:36 And his brethren, Shemaiah, and Azarael, Gilalai, Maai, Nethaneel, and Judah and Hanani, to praise by instruments in odes of David the man of God; and Ezra the scribe was in front of them. 

#### Nehemiah 12:37 At the gate of the spring, over by them, they ascended upon the stairways of the city of David, by ascending the wall on top of the house of David, and unto the {gate water} according to the east. 

#### Nehemiah 12:38 And for praise, the second group went forth to meet them, and I was behind them. And half of the people were above the wall, up above the tower of the furnaces, and unto the {wall broad}, 

#### Nehemiah 12:39 and up above the gate of Ephraim, and upon the gate, the one of Eisiana, and upon the {gate fish}, and by the tower of Hananeel, and from the tower of Meah, and unto the gate of the sheep; and they stopped upon the gate of the prison. 

#### Nehemiah 12:40 And {stood the two groups} for praise in the house of God, and I, and the half of the commandants with me. 

#### Nehemiah 12:41 And the priests, Eliakim, Maaseiah, Miniamin, Michaiah, Elioenai, Zechariah, Hananiah, were with trumpets; 

#### Nehemiah 12:42 and Maaseiah, and Shemaiah, Eleazar, Uzzi, Jehohanan, Melchijah, and Elam, and Ezer. And {were heard the singers}, and Jezrahiah the overseer. 

#### Nehemiah 12:43 And they sacrificed in that day {sacrifices great}, and they were glad. For God gladdened them {gladness with great}; and their wives and their children were glad; and {was heard the gladness in Jerusalem} from far off. 

#### Nehemiah 12:44 And they ordained in that day men over the treasuries, for the treasures, for the first-fruits, and for the tenths, to gather in to them from the fields of the cities portions to the priests and to the Levites; for there was gladness in Judah, and upon the priests, and the Levites, of the ones standing. 

#### Nehemiah 12:45 And they guarded the watch of their God, and the watches of the cleansing, even the singers and the gatekeepers, according to the commands of David, and Solomon his son. 

#### Nehemiah 12:46 For in the days of David and Asaph from the beginning there was a first of the singers, and a hymn and praise to God. 

#### Nehemiah 12:47 And all Israel in the days of Zerubbabel, and in the days of Nehemiah, were giving portions of the singers and of the gatekeepers -- an account {day by day of it}. And they sanctified them to the Levites; and the Levites sanctified them to the sons of Aaron. 

#### Nehemiah 13:1 In that day they read in the scroll of Moses into the ears of the people. And it was found written in it how that {should not enter the Ammonite and Moabite} into the assembly of God unto the eon. 

#### Nehemiah 13:2 For they did not meet the sons of Israel with bread and water, and they hired against them Balaam to curse them. And {turned our God} the curse into a blessing. 

#### Nehemiah 13:3 And it came to pass as they heard the law, that they separated all the intermixed in Israel. 

#### Nehemiah 13:4 And before this Eliashib the priest lived in the treasury of the house of our God, near Tobiah. 

#### Nehemiah 13:5 And he made for him {treasury a great}, and there they were formerly giving the sacrifice offering, and the frankincense, and the vessels, and the tenth of the grain, and of the wine, and of the olive oil, a commandment of the Levites, and of the singers, and of the gatekeepers, and the first-fruits of the priests. 

#### Nehemiah 13:6 And during all this I was not in Jerusalem. For in {year the thirtieth and second} of Artaxerxes king of Babylon I went to the king, and after the end of the days I asked things of the king. 

#### Nehemiah 13:7 And I came into Jerusalem, and I perceived the wickedness which Eliashib did for Tobiah, to make for him a treasury in the courtyard of the house of God. 

#### Nehemiah 13:8 And {wicked to me it appeared exceedingly}, and I tossed all the items of the house of Tobiah outside of the treasury. 

#### Nehemiah 13:9 And I spoke, and they cleansed the treasuries. And I returned there the vessels of the house of God for the sacrifice offering and the frankincense. 

#### Nehemiah 13:10 And I knew that the portions of the Levites were not given them; and {fled every man} unto his own field, the Levites and the singers, and ones doing the work. 

#### Nehemiah 13:11 And I quarreled with the commandants, and said, Why did it abandon the house of God? And I gathered them, and set them at their station. 

#### Nehemiah 13:12 And all Judah brought a tenth of the wheat and of the wine and of the olive oil into the treasuries. 

#### Nehemiah 13:13 And I gave charge unto the hand of Shelemiah the priest, and Zadok the scribe, and Pedaiah of the Levites; and near their hand was Hanan son of Zaccur, son of Mattaniah. For {trustworthy they were considered}, as it was upon them to portion out to their brethren. 

#### Nehemiah 13:14 Remember me, O God, in this! that {should not be wiped away my acts of mercy}, which I did in the house of the LORD my God, and in his watches. 

#### Nehemiah 13:15 In those days I beheld in Judah ones treading the wine vats on the Sabbath, and bringing sheaves, and loading upon the donkeys; even wine, and the grape cluster, and figs, and every burden, and bringing them into Jerusalem on the day of the Sabbath. And I attested to them in the day of their sale. 

#### Nehemiah 13:16 For {sold provision even the ones of Tyre}, and sat by it bringing fish, and {every item for sale selling} on the Sabbath to the sons of Judah, and in Jerusalem. 

#### Nehemiah 13:17 And I quarreled with the free men of Judah, and I said to them, What is {matter this wicked} which you do, and profane the day of the Sabbath? 

#### Nehemiah 13:18 Did not {thus do your fathers}, and {brought upon them our God} and upon us all these evils, even upon this city? And you add to the anger upon Israel to profane the Sabbath. 

#### Nehemiah 13:19 And it came to pass when {were stood the gates} in Jerusalem before the Sabbath, that I spoke, and they locked the gates. And I spoke so as to not open them until after the Sabbath. And {some of my young men I stood} at the gates, so as to not lift burdens on the day of the Sabbath. 

#### Nehemiah 13:20 And {lodged all the traders} and did business outside of Jerusalem once or twice. 

#### Nehemiah 13:21 And I testified to them, and I said to them, Why do you lodge before the wall? If you repeat it a second time, I will stretch out my hand against you. From that time they did not come on the Sabbath. 

#### Nehemiah 13:22 And I spoke to the Levites who were being cleansed, and the ones coming guarding the gates to sanctify the day of the Sabbath. For these things remember me, O my God, and spare me according to the magnitude of your mercy! 

#### Nehemiah 13:23 And in those days I saw the Jews who settled with wives of Ashdod, of Ammon, and Moab. 

#### Nehemiah 13:24 And their sons {half were speaking} Ashdodish, and are not knowing to speak Jewish, but spoke according to the language of this people and that people. 

#### Nehemiah 13:25 And I quarreled with them, and cursed them, and I struck some of their men, and I plucked their hair, and I bound them to an oath by God, You shall not give your daughters to their sons, and you shall not indeed take of their daughters for your sons, and to yourselves. 

#### Nehemiah 13:26 Did not {thus sin Solomon king of Israel}? and among {nations many} there was not a king likened to him, and {one being loved by God he was}, and {appointed him God} as king over all Israel, and in this {turned him aside the wives alien}. 

#### Nehemiah 13:27 So {with you should we not hearken} to do this wickedness, to break contract with our God, and to settle with {wives alien}? 

#### Nehemiah 13:28 And from the sons of Joiada, Eliashib the {priest great}, in-law to Sanballat the Horonite -- even I threw him from me. 

#### Nehemiah 13:29 Remember them, O my God, for they were against the right of inheritance of the priesthood, and the covenant of the priesthood, and of the Levites! 

#### Nehemiah 13:30 And I cleansed them from all alien connection, and I set the daily rotations for the priests and for the Levites, every man according to his work; 

#### Nehemiah 13:31 even for the gift of the wood offerings in seasons, from times, and in the first produce. Remember me, O our God, for goodness!