#### Joshua 1:1 And it came to pass after the decease of Moses the servant of the LORD, that the LORD spoke to Joshua son of Nun, the aid of Moses, saying, 

#### Joshua 1:2 Moses, my attendant has come to an end; now then rising up, pass over the Jordan! you, and all this people, into the land which I give to them. 

#### Joshua 1:3 Every place upon which ever you should mount the track of your feet, {to you I will give it}, in which manner I spoke to Moses. 

#### Joshua 1:4 The wilderness and the Antilebanon unto the {river great}, the river Euphrates, all the land of the Hittites, and unto the {sea great} from {of the sun the descent} will be your boundaries. 

#### Joshua 1:5 {shall not withstand A man} before you all the days of your life. And as I was with Moses, so I will be also with you, and I will not abandon you, nor will I neglect you. 

#### Joshua 1:6 Be strong and manly! for you shall divide up to this people the land which I swore by an oath to your fathers to give to them. 

#### Joshua 1:7 Be strong then and manly! to guard and to do in so far as I gave charge Moses my servant. And do not turn aside from them to the right or to the left! that you should perceive in all what ever you should act on. 

#### Joshua 1:8 And {shall not leave book of the law this} from your mouth, and you shall meditate in it day and night, that you should perceive to do all the things written in it. Then you shall prosper your ways, and then you shall perceive. 

#### Joshua 1:9 Behold, I give charge to you; be strong and be manly! You should not be timid, nor should you be terrified, for {is with you the LORD your God} in every place where ever you should go. 

#### Joshua 1:10 And Joshua gave charge to the scribes of the people, saying, 

#### Joshua 1:11 Enter in the midst of the camp of the people, and give charge to the people! saying, Prepare provisions! for yet in three days even you pass over this Jordan, entering to take control of the land which the LORD God of your fathers gives to you. 

#### Joshua 1:12 And to Reuben, and to Gad, and to the half tribe of Manasseh, Joshua said, 

#### Joshua 1:13 Remember the word of the LORD! which {gave charge to you Moses the servant of the LORD}, saying, The LORD your God rested you, and gave to you this land. 

#### Joshua 1:14 Your wives, and your children, and your cattle -- let them dwell in the land which {gave to you Moses} on the other side of the Jordan! And you shall pass over well-equipped prior to your brethren, every one being strong, and you shall fight along with them, 

#### Joshua 1:15 until whenever {should rest the LORD your God} your brethren, as also you; and so they shall be heir also to this land which the LORD your God gives to them. Then you shall go forth each unto his own inheritance, which {gave to you Moses} on the other side of the Jordan from the east sun. 

#### Joshua 1:16 And answering to Joshua, they said, All as much as you should give charge to us we will do, and into every place where ever you should send us, we will go. 

#### Joshua 1:17 According to all as much as we hearkened to Moses, we will hearken to you. Furthermore let {be the LORD our God} with you, in which manner he was with Moses! 

#### Joshua 1:18 And the man who ever should resist you, and who ever should not hearken to your words, in so far as you should give charge to him, let him die! But be strong and be manly! 

#### Joshua 2:1 And {sent Joshua son of Nun} from out of Shittin two men to spy, saying, Ascend and behold the land and Jericho! And going, they entered into a house of a woman harlot, whose name was Rahab, and they rested up there. 

#### Joshua 2:2 And it was reported to the king of Jericho, saying, {have entered here Men} of the sons of Israel to spy out the land. 

#### Joshua 2:3 And {sent the king of Jericho}, and said to Rahab, saying, Lead out the men! the ones entering into your house in the night, {to spy out for the land they have come}. 

#### Joshua 2:4 And {taking the woman} the two men hid them. And she said to them, saying, {entered to me The men}, and I know not from where they were. 

#### Joshua 2:5 But as the gate was locked in the darkness, and the men went forth, I do not know where they went. You pursue after them! and you shall overtake them. 

#### Joshua 2:6 But she brought them upon the roof, and hid them in the stalk of flax having been piled by her upon the roof. 

#### Joshua 2:7 And the men pursued after them on the way unto the Jordan near the ford, and the gate was locked. 

#### Joshua 2:8 And it came to pass as {went forth the ones pursuing after them}, and before their going to sleep, that she ascended upon the roof to them. 

#### Joshua 2:9 And she said to them, I know that {gave to you the LORD the land}; {has fallen for the fear of you} upon us, and {are struck with awe all the ones dwelling the land} of you. 

#### Joshua 2:10 For we have heard that {totally dried up the LORD God} the {sea red} before your face, when you went forth from out of Egypt, and as much as you did to the two kings of the Amorites, the ones who were on the other side of the Jordan, to Sihon and to Og, of which you utterly destroyed them. 

#### Joshua 2:11 And having heard, we were amazed in our heart, and there was no {established longer a spirit} in any one because of your presence; for the LORD your God is the God in heaven upward, and upon the earth below. 

#### Joshua 2:12 And now, swear by an oath to me by the LORD God! for I performed an act of mercy to you, and you shall also perform yourself an act of mercy in the house of my father, And you shall give to me {sign a true}. 

#### Joshua 2:13 Take alive the house of my father, and my mother, and my brothers, and my sisters, and all of my house, and all as much as is theirs! And you shall rescue our life from death. 

#### Joshua 2:14 And {said to her the men}, Our life for yours, even unto death. And she said, Whenever the LORD should deliver up {to you the city}, you shall perform for me an act of mercy and truth. 

#### Joshua 2:15 And she let them down through the window, for her house was in the wall, and in the wall she dwelt. 

#### Joshua 2:16 And she said to them, {into the mountainous area Go forth}, lest there should meet up with you the ones pursuing! And you shall be hidden there three days until whenever {should return the ones pursuing after you}; and after this you shall go forth into your way. 

#### Joshua 2:17 And {said to her the men}, We are innocent {your oath in this}. 

#### Joshua 2:18 Behold, as we enter into a part of the city, then you shall place a sign -- {string this scarlet you shall suspend} in the window through which you let us down through it. And your father, and your mother, and your brothers, and all the house of your father, you shall bring together to yourself into your house. 

#### Joshua 2:19 And it will be any which ever should come forth by the door of your house unto outside, {liable to himself shall be}, and we will be innocent {your oath in this}. And as many as should be with you in your house, we will be liable if a hand should have touched him. 

#### Joshua 2:20 But if anyone should wrong us, and should uncover {our words these}, we will be innocent {your oath in this}, which we bound you by. 

#### Joshua 2:21 And she said to them, According to your word thus let it be! And she sent them out, and they went. And she tied the {sign scarlet} in the window. 

#### Joshua 2:22 And they went, and they came unto the mountainous area, and they stayed there three days, until {returned the ones following}. And {sought after them the ones pursuing} in all the ways, and did not find. 

#### Joshua 2:23 And {returned the two young men}, and they went down from out of the mountain, and passed over, and came to Joshua son of Nun. And they described to him all the things coming to pass to them. 

#### Joshua 2:24 And they said to Joshua that, The LORD has delivered all the land in our hand, and {are struck with awe all dwelling in that land} at us. 

#### Joshua 3:1 And Joshua rose early in the morning. And they departed from Shittin, and they came unto the Jordan, he and all the sons of Israel. And they rested up there before passing over. 

#### Joshua 3:2 And it came to pass after three days, {went that the scribes} through the camp. 

#### Joshua 3:3 And they gave charge to the people, saying, Whenever you should behold the ark of the covenant of the LORD our God, and the priests, and the Levites lifting it, that you shall depart from your place and go after it! 

#### Joshua 3:4 But let there be a far space between you and that ark, as much as two thousand cubits! You shall stand -- you should not draw near it, that you should know the way which you go by it. {not For you have} gone the way either yesterday or the third day before. 

#### Joshua 3:5 And Joshua said to the people, Be sanctified by the morrow! for tomorrow the LORD shall do {among you wonders}. 

#### Joshua 3:6 And Joshua said to the priests, saying, Lift the ark of the covenant of the LORD, and go before in front of the people! And {lifted the priests} the ark of the covenant of the LORD, and they went in front of the people. 

#### Joshua 3:7 And the LORD said to Joshua, On this day I begin to raise you up high in front of all the sons of Israel, that they should know in so far as I was with Moses, so shall I also be with you. 

#### Joshua 3:8 And now give charge to the priests lifting the ark of the covenant! saying, As soon as you should enter upon a part of the water of the Jordan, then in the Jordan you shall stand. 

#### Joshua 3:9 And Joshua said to the sons of Israel, Lead forward here and hearken to the word of the LORD your God! 

#### Joshua 3:10 And Joshua said, In this you shall know that God is living among you, and by annihilating he will annihilate from our face the Canaanite, and the Hittite, and the Hivite, and the Perizzite, and the Amorite, and the Girgashite, and the Jebusite. 

#### Joshua 3:11 Behold, the ark of the covenant of the LORD of all the earth passes over {before you the Jordan}. 

#### Joshua 3:12 And now handpick for yourselves twelve men from the sons of Israel, one from each tribe! 

#### Joshua 3:13 And it will be as whenever {shall rest the feet of the priests}, of the ones lifting the ark of the covenant of the LORD of all the earth in the water of the Jordan, the water of the Jordan shall fail, and the water going down shall stand from above as a heap. 

#### Joshua 3:14 And it happened as {departed the people} from out of their tents, to pass over the Jordan, that the priests lifted the ark of the covenant of the LORD in front of the people. 

#### Joshua 3:15 And as {entered the priests} lifting the ark of the covenant unto the Jordan, that the feet of the priests lifting the ark were dipped into a part of the water of the Jordan, and the Jordan filled up {entire bank its} as in days of harvest, 

#### Joshua 3:16 and {stood the waters} going down from above, it stood as a bank of water in abstaining far off, very vehemently unto Adam the city, unto the part of Kirjath Jearim. And the part going down went down into the sea of Araba, the sea of salts, unto the end were it ceased. And the people stood before Jericho. 

#### Joshua 3:17 And {stood the priests}, the ones lifting the ark of the covenant of the LORD, upon dry land in the midst of the Jordan ready. And all the sons of Israel passed over through dry land, until of which time {completed all the people} passing over the Jordan. 

#### Joshua 4:1 And when {completed all the people} passing over the Jordan, that the LORD spoke to Joshua, saying, 

#### Joshua 4:2 Taking twelve men from the people, {man one} from each tribe, 

#### Joshua 4:3 give orders to them! saying, Take up to yourselves from here from the midst of the Jordan, from the station of the feet of the priests, {prepared twelve} stones! And these, in carrying {across together with you them}, put them in your military encampment! where ever you should camp there the night. 

#### Joshua 4:4 And Joshua calling by name twelve men of the honorable ones from the sons of Israel, {man one} from each tribe, 

#### Joshua 4:5 {said to them Joshua}, Lead forward before the presence of the LORD your God into the midst of the Jordan! And by taking up, lift away from there each {stone one} upon his shoulders, according to the number of the tribes of Israel! 

#### Joshua 4:6 That {should exist to you these} for a sign, being situated always; that whenever {should ask you your son} tomorrow, saying, What are these stones to you? 

#### Joshua 4:7 And you shall make manifest to your son, saying that, {ceased The Jordan river} from in front of the ark of the covenant of the LORD of all the earth as it passed over the Jordan -- even {ceased the water of the Jordan}. And {shall be these stones} to you a memorial to the sons of Israel unto the eon. 

#### Joshua 4:8 And {did thus the sons of Israel}, in so far as the LORD gave charge to Joshua. And taking twelve stones from the midst of the Jordan, just as the LORD gave orders to Joshua, in the completion of the fording of the sons of Israel, that they carried them across together themselves into the camp, and they put them aside there. 

#### Joshua 4:9 {set And Joshua} also another twelve stones in {itself the Jordan}, in the {being place} under the feet of the priests lifting the ark of the covenant of the LORD. And they are there until today's day. 

#### Joshua 4:10 {stood And the priests}, the ones lifting the ark of the covenant, in the midst the Jordan, until of which he completed all the words which the LORD gave charge to Joshua to announce to the people, according to all as much as Moses gave charge to Joshua. And {hastened the people}, and passed over. 

#### Joshua 4:11 And it came to pass as {completed all the people} to pass over, that {passed over the ark of the covenant of the LORD}, and the priests in front of them. 

#### Joshua 4:12 And there passed over the sons of Reuben, and the sons of Gad, and the half tribe of Manasseh, being equipped in front of the sons of Israel, just as Moses gave charge to them. 

#### Joshua 4:13 Forty thousand well-equipped for battle passed over before the LORD for war against Jericho the city. 

#### Joshua 4:14 In that day the LORD increased Joshua before all of Israel, and they feared him as they feared Moses, as much time as he lived. 

#### Joshua 4:15 And the LORD spoke to Joshua, saying, 

#### Joshua 4:16 Give charge to the priests lifting the ark of the covenant of the testimony! to go up out of the Jordan. 

#### Joshua 4:17 And Joshua gave charge to the priests, saying, Go up out of the Jordan! 

#### Joshua 4:18 And it came to pass as {went up the priests}, the ones lifting the ark of the covenant of the LORD, from the midst of the Jordan, that {put the feet the priests} upon the dry land, and {advanced the water of the Jordan} according to place, and it went as also yesterday and the third day before, through all its bank. 

#### Joshua 4:19 And the people ascended from out of the Jordan on the tenth of the {month first}. And {bivouacked the sons of Israel} in Gilgal in the part towards the sun, rising by Jericho. 

#### Joshua 4:20 And {twelve stones these} which he took from out of the Jordan, Joshua set in Gilgal. 

#### Joshua 4:21 And he spoke to the sons of Israel, saying, Whenever {ask your sons tomorrow you}, saying, What are these stones? 

#### Joshua 4:22 You announce to your sons! saying that, {upon dry ground Israel passed over this Jordan}. 

#### Joshua 4:23 {caused to dry up The LORD our God the water of the Jordan} from in front of them, until of which time they passed over, just as {did the LORD our God} to the {sea red}, which {caused to dry up the LORD God} in front of us until we went by. 

#### Joshua 4:24 So that {might know all the nations of the earth} that the power of the LORD is strong, and that you should worship the LORD our God at all time. 

#### Joshua 5:1 And it came to pass as {heard all the kings} (the kings of the Amorites who were on the other side of the Jordan by the sea, and all the kings of Phoenicia by the sea) that {caused to dry up the LORD God the Jordan river} from before the sons of Israel in their passing over, that {melted away their thoughts}, and they were struck with terror, and there was not among them {with intellect any one} because of the presence of the sons of Israel. 

#### Joshua 5:2 And about this time the LORD said to Joshua, Make for yourself {knives flint rock}, and sitting down circumcise the sons of Israel a second time! 

#### Joshua 5:3 And {made for himself Joshua knives flint rock}, and he circumcised the sons of Israel upon the {being called place}, Hill of Foreskins. 

#### Joshua 5:4 And this is the account for which Joshua circumcised all the people, the ones coming forth from Egypt. {the male All} men of war that died in the wilderness in the way of their coming forth from the land of Egypt, 

#### Joshua 5:5 that {circumcised were all the people coming forth}. And all the people being born in the wilderness, in the way of their coming forth from the land of Egypt were not circumcised. For forty years Israel paced in the wilderness. 

#### Joshua 5:6 Therefore {were uncircumcised most of them} of the ones for combat, of the ones coming forth from out of the land of Egypt, the ones resisting the commandments of the LORD God; and the ones whom {separated the LORD} to them, {to not behold for them} the land which the LORD swore by an oath to our fathers to give to us, a land flowing milk and honey. 

#### Joshua 5:7 Their sons he firmed instead of these, whom Joshua circumcised. For they were uncircumcised on account of them being born along the way of uncircumcised ones. 

#### Joshua 5:8 And being circumcised, all the nation {rest had} at that time, sitting down in the camp until they were healed. 

#### Joshua 5:9 And the LORD said to Joshua, In today's day I removed the scorn of Egypt from you. And he called the name of that place, Gilgal, until this day. 

#### Joshua 5:10 And {camped the sons of Israel} in Gilgal. And they observed the passover on the fourteenth day of the month, at evening, at the descent of Jericho in the plain. 

#### Joshua 5:11 And they ate from the grain of the land on the next day of the passover -- unleavened breads and new corn. 

#### Joshua 5:12 On this day {failed the manna}, on the next day after their eating from the grain of the land, and no longer {existed to the sons of Israel manna}. And they gathered fruit of the place of the Phoenicians in that year. 

#### Joshua 5:13 And it came to pass as Joshua was in Jericho, that lifting up his eyes, he beheld a man standing before him, and his broadsword was unsheathed in his hand. And coming forward, Joshua said to him, Are you ours or of our opponents? 

#### Joshua 5:14 And he said to him that, I am the commander-in-chief of the force of the LORD, now I have come. And Joshua fell upon his face upon the ground, and he did obeisance, and he said to him, My master what do you assign to your servant? 

#### Joshua 5:15 And {says the commander-in-chief of the LORD} to Joshua, Untie your sandal from your feet! for the place upon which you stand upon it is holy. And Josua did thus. 

#### Joshua 6:1 And Jericho was closed up, and fortified from before the sons of Israel. And no one went forth from out of it, and neither entered. 

#### Joshua 6:2 And the LORD said to Joshua, Behold, I deliver up to you {under your hand to you Jericho}, and its king, the one in it, and the mighty ones in strength. 

#### Joshua 6:3 And let {circle the city all men of war} round about the city! Once thus they shall do for six days. 

#### Joshua 6:4 And seven priests shall take seven horns of the ram before the ark. And on the {day seventh} circle the city seven times! and the priests shall trump the horns. 

#### Joshua 6:5 And it will be as whenever you should sound the trumpet of the ram, in your hearing the sound of the horn, let {shout aloud all the people}! And with their shouting aloud {shall fall by themselves the walls of the city} underneath them, and {shall enter all the people}, {advancing each} in front into the city. 

#### Joshua 6:6 And {entered Joshua the son of Nun} to the priests, and he said to them, You take the ark of the covenant! and seven priests shall take seven horns of the ram, according to the front of the ark of the LORD. 

#### Joshua 6:7 And he said to them, saying, Exhort the people to go around and circle the city, and {the ones for combat let} come near! arming themselves before the ark of the LORD. 

#### Joshua 6:8 And it came to pass as Joshua spoke to the people, that the seven priests having seven {trumpets consecrated} also went by likewise before the LORD, and they passed and signified intensely. And the ark of the covenant of the LORD followed after them. 

#### Joshua 6:9 And the ones for combat came near in front. And the priests trumpeting the horns, and the rest of the multitude all together after the ark of the covenant of the LORD, were going and trumpeting with the horns. 

#### Joshua 6:10 And to the people Joshua gave charge, saying, Do not yell nor let {hear any one} your voice! There shall not go through from your mouth a word until whenever he himself declares the day to yell out, and you shall yell out then. 

#### Joshua 6:11 And {having gone around the ark of the covenant of God} the city round about, immediately they went forth into the camp, and spent the night there. 

#### Joshua 6:12 And on the {day second} Joshua rose up in the morning, and {lifted the priests} the ark of the LORD. 

#### Joshua 6:13 And the seven priests, the ones bringing the seven {trumpets consecrated} before the ark the LORD went forth, and the priests trumping the trumpets, and after these, there entered the ones for combat, and the remaining multitude all together were behind the ark of the covenant of the LORD, going and trumping with the horns. 

#### Joshua 6:14 And they encircled the city on the {day second}, once near to it; and they went forth again into the camp. So it was done for six days. 

#### Joshua 6:15 And it came to pass on the {day seventh rose up the expedition} at dawn and went around the city according to this practice seven times, only on that day they circled the city seven times. 

#### Joshua 6:16 And it came to pass in the {circuit seventh trumped the priests} with trumpets, and Joshua said to the sons of Israel, Cry out, {delivered up for the LORD} the city to you! 

#### Joshua 6:17 And {will be the city} an offering for consumption, it and all as much as is in it, to the LORD of the forces. Except Rahab the harlot -- protect her, and all as much as is of hers in the house! for she hid the messengers whom we sent. 

#### Joshua 6:18 But you guard from the offering for consumption! lest at any time pondering, you should take of the offering for consumption, and should make the camp of the sons of Israel an offering for consumption, and he should obliterate us. 

#### Joshua 6:19 And all silver or gold, and all brass and iron, will be holy to the LORD; {into the treasury of the LORD it shall be carried}. 

#### Joshua 6:20 And {shouted the people}, and {trumped the trumpets the priests}. And as {heard the people} the sound of the trumpets, {shouted all the people} {shout a great and strong}. And {fell the wall} round about; and {ascended the people} into the city, each at his opposite, and overtook the city. 

#### Joshua 6:21 And they devoted it to consumption, and as much as was in the city, from man and unto woman, from young and unto old, and unto calf and sheep and beast of burden, by the mouth of the broadsword. 

#### Joshua 6:22 And to the two young men spying out the land, Joshua said, You enter into the house of the woman, the harlot, and lead her from there, and all as much as is with her, as you swore by an oath to her! 

#### Joshua 6:23 And {entered the two young men}, the ones spying out the city, into the house of the woman; and they led out Rahab the harlot, and her father, and her mother, and her brothers, and all as much as was to her, and her kin. And they placed her outside the camp of Israel. 

#### Joshua 6:24 And the city was burned by fire with all the things in it. Except silver and gold and all brass and iron they yielded up unto the treasury to be carried in. 

#### Joshua 6:25 And Rahab the harlot, and all the house of her father, and all the things of hers, Joshua took alive. And she dwelt in Israel until the day today, because she hid the ones spying which Joshua sent to spy out Jericho. 

#### Joshua 6:26 And Joshua bound them by an oath in that day, saying, Accursed is the man who before the LORD, who shall raise up or shall build that city Jericho; with his first-born he will lay the foundation for it, and with the least of his he shall set the gates of it. 

#### Joshua 6:27 And the LORD was with Joshua, and {was his name} in all the land. 

#### Joshua 7:1 And {trespassed the sons of Israel} a trespass, and pilfered from the offering for consumption. And Achan took (son of Carmi, son of Zabdi, son of Zerah, from the tribe of Judah) from the offering for consumption. And {was enraged the anger of the LORD} with the sons of Israel. 

#### Joshua 7:2 And Joshua sent men from Jericho unto Ai, which is by Beth-aven, according to the east of Beth-el. And he spoke to to them, saying, In ascending, survey the land! And {ascended the men} and surveyed Ai. 

#### Joshua 7:3 And they returned to Joshua, and said to him, Do not let {ascend all the people}, but about two thousand or three thousand men, let them ascend! And let them capture the city! You should not lead there all the people, {few for they are}. 

#### Joshua 7:4 And ascended from the people there about three thousand men. And they fled from the face of the men of Ai. 

#### Joshua 7:5 And {killed of them the men of Ai} about thirty-six men, and they pursued them from the gate until they defeated them. And they struck them by the incline. And {was terrified the heart of the people}, and it became as water. 

#### Joshua 7:6 And Joshua tore his garments, and fell upon his face upon the earth before the ark of the LORD until evening, he and the elders of Israel. And they put dust upon their heads. 

#### Joshua 7:7 And Joshua said, I beseech, O Lord, O LORD, why in causing to pass over was {caused to pass over your servant} this people the Jordan, to deliver it to the Amorite to destroy us? And if we stayed and were settled by the Jordan, what is it to me, O LORD. 

#### Joshua 7:8 And what shall I say when Israel turned the back of the neck before its enemy? 

#### Joshua 7:9 And hearing, the Canaanite and all the ones dwelling in the land shall surround us, and shall obliterate us from the land. And what will you do {name for your great}? 

#### Joshua 7:10 And the LORD said to Joshua, Rise up! Why do you do this -- fall upon your face? 

#### Joshua 7:11 {have sinned The people}, and violated my covenant which I ordained with it. For even they took from the offering for consumption, and stealing they lie, and they cast {for the items} themselves. 

#### Joshua 7:12 And {in no way will be able the sons of Israel} to stand in front of its enemies. {the back of the neck They shall turn} before their enemies, for they were become an offering for consumption. I will not add any longer to be with you, if you should not lift away the offering for consumption from among you of them. 

#### Joshua 7:13 In rising up, purify the people, and tell them to be sanctified for tomorrow! For thus says the LORD God of Israel, The offering devoted for consumption is among you, O Israel; you shall not be able to withstand before your enemies, until whenever you should lift away the offering for consumption from you. 

#### Joshua 7:14 And you shall gather all in the morning according to your tribes. And it will be to the tribe which ever the LORD shows, and you shall lead forward according to peoples. And the people which ever the LORD shows you shall lead forward according to house. And the house which ever the LORD shows, by man you shall lead forward. 

#### Joshua 7:15 And who ever should be pointed out in the offering for consumption, he shall be burnt by the fire himself, and all as much as is his; for he violated the covenant of the LORD, and that he committed a violation of the law in Israel. 

#### Joshua 7:16 And Joshua rose early in the morning, and he led {forward the people} by its tribe. And {was made manifest the tribe of Judah}. 

#### Joshua 7:17 And {were made manifest people the Zarhite}. And he led forward {people the Zarhite} according to man, and Zabdi was made manifest. 

#### Joshua 7:18 And he led forward his house by man, and was made manifest Achan son of Carmi, son of Zabdi, son of Zerah of the tribe of Judah. 

#### Joshua 7:19 And Joshua said to Achan, O my son, today give indeed glory to the LORD God of Israel, and make to him the acknowledgment, and announce to me what you did! and you should not hide it from me. 

#### Joshua 7:20 And Achan answered to Joshua, and said, Truly I sinned before the LORD God of Israel, so and so I have done. 

#### Joshua 7:21 I beheld in the spoils standing bare {colored robe one goodly}, and two hundred double-drachmas of silver, and {wedge of gold one} -- fifty double-drachmas its scale weight. And I coveted them, and I took. And behold, these are hid in the ground in my tent, and the silver is hid underneath them. 

#### Joshua 7:22 And Joshua sent messengers, and they ran to the tent in the camp; and these were being hid in his tent, and the silver underneath them. 

#### Joshua 7:23 And they brought them from the tent, and brought them to Joshua, and to all elders of Israel. And they put them before the LORD. 

#### Joshua 7:24 And Joshua took Achan son of Zerah, and the silver, and the robe, and the {wedge gold}, and his sons, and his daughters, and his calves, and his beasts of burden, and his sheep, and his tent, and all his possessions, and all Israel with him. And they led them into Emek Achor. 

#### Joshua 7:25 And Joshua said, Why did you annihilate us {to utterly destroy you for the LORD} even today? And {stoned him all Israel} with stones, and they burned them in fire, and they stoned them with stones. 

#### Joshua 7:26 And they set over him a heap {stones of great} until this day. And the LORD ceased the rage of anger. Therefore this is the name of it -- Emek Achor, unto this day. 

#### Joshua 8:1 And the LORD said to Joshua, You should not fear, nor should you be timid. Take with you all the men, the ones making war, and rising up ascend unto Ai! Behold, I give into your hands the king of Ai, and his people, and his city, and his land. 

#### Joshua 8:2 And you shall do to Ai, and to her king in which manner you did to Jericho and to her king. And her spoils and her cattle you shall despoil for yourself. But place for yourself an ambush for the city to the rear of her. 

#### Joshua 8:3 And Joshua rose up, and all the people, the warriors, so as to ascend to Ai. {chose And Joshua} thirty thousand men, mighty in strength, and sent them by night. 

#### Joshua 8:4 And he gave charge to them, saying, See that you lie in wait the city, behind the city greatly! and you shall all be prepared. 

#### Joshua 8:5 And I, and all the ones with me, will lead forward to the city. And it will be as whenever {should come forth the ones dwelling in Ai} to meet you, just as also the day before, and we fled from their face, 

#### Joshua 8:6 that whenever they should come forth after us, we shall draw them away from the city. And they will say, They flee from our face in which manner before; and we shall flee from them. 

#### Joshua 8:7 And you shall rise up from the ambush, and you shall go into the city, and you shall obliterate the city, and {shall give it the LORD our God} into our hands. 

#### Joshua 8:8 And it will be when ever you should seize the city, burn it by fire! According to this matter you shall act. Behold, I have given charge to you. 

#### Joshua 8:9 And {sent them Joshua}, and they went to the ambush, and sat in place between Beth-el and between Ai, from the west of Ai. And Joshua lodged that night in the midst of the people. 

#### Joshua 8:10 And Joshua rising early in the morning, numbered the people. And they ascended, he and the elders of Israel, before the face of the people, against Ai. 

#### Joshua 8:11 And all the people, the warrior, the one with him, ascended. And going, they came right opposite the city from the east. And the ambushes of the city were from the west. And they encamped from north of Ai. And the valley was between it and Ai 

#### Joshua 8:12 And he took about five thousand men, and he stationed them in ambush between Beth-el and Ai, west of Ai. 

#### Joshua 8:13 And he arranged {the people all} of the camp, which was from north of the city, the ends of it west of the city. And Joshua went that night in the midst of the valley. 

#### Joshua 8:14 And it happened as {beheld the king of Ai}, that he hastened and rose early. And there went forth the men of the city to meet them straight on into the battle, he and all his people at the opportune time, in front of the Araba. And he did not know that an ambush against him is behind the city. 

#### Joshua 8:15 And {beheld and withdrew Joshua and all Israel} from in front of them. 

#### Joshua 8:16 And the people fled by the way of the wilderness, and {grew in strength all the people of Ai} to pursue after them of the sons of Israel. And they departed from the city. 

#### Joshua 8:17 They did not leave behind any one in Ai and in Beth-el who did not pursue after Israel. And they left the city being open, and they pursued after Israel. 

#### Joshua 8:18 And the LORD said to Joshua, Stretch out your hand with the javelin, the one in your hand, against the city, for into your hands I gave it. And the ones in ambush shall rise up quickly from out of their place. 

#### Joshua 8:19 And Joshua stretched the javelin and his hand against the city, and the ones in ambush rose up quickly from out of their place. And they went forth when he stretched out the hand. And they entered into the city, and overtook it. And hastening they burned the city in fire. 

#### Joshua 8:20 And {looking about the inhabitants of Ai} unto the rear of them, and they viewed the smoke of the city ascending into the heaven; and no longer had they anywhere to flee here on this side or here on that side. And the people fleeing into the wilderness turned upon the ones pursuing. 

#### Joshua 8:21 And Joshua and all Israel beheld that {took the ones in ambush} the city, and that {ascended the smoke of the city} into the heaven; and turning they struck the men of Ai. 

#### Joshua 8:22 And these came forth from the city to meet them. And they came in the midst of the camp, some of these here and some of these here. And they struck them until there was not one being left behind of them being delivered and escaping. 

#### Joshua 8:23 And the king of Ai was seized alive, and they led him to Joshua. 

#### Joshua 8:24 And it happened as {ceased the sons of Israel} killing all the ones in Ai, and in the plains, and in the mountain upon the descent of which they pursued them, that all fell by the mouth of the broadsword, by it unto completion. And Joshua returned to Ai, and struck it by the mouth of the broadsword. 

#### Joshua 8:25 And it came to pass that all the ones falling in that day, from man and unto woman -- twelve thousand, all the ones dwelling in Ai. 

#### Joshua 8:26 And Joshua returned not his hand which he stretched out by the javelin until he devoted to consumption the whole of the ones dwelling Ai. 

#### Joshua 8:27 Except the cattle and the spoils in that city {despoiled for themselves the sons of Israel} according to the order of the LORD, in which manner the LORD gave orders to Joshua. 

#### Joshua 8:28 And Joshua burned the city by fire, and he established it for an embankment into the eon, uninhabited until this day. 

#### Joshua 8:29 And the king of Ai he hung upon {tree a twin}. And he was upon the tree until the time of the evening. And at the setting of the sun Joshua gave orders, and they lowered his body from the tree, and they tossed him into the cesspool before the gate of the city, and set over him {heap of stones a large} until this day. 

#### Joshua 8:30 Then Joshua built an altar to the LORD God of Israel on mount Ebal, 

#### Joshua 8:31 as {gave charge Moses the attendant of the LORD} to the sons of Israel, as it is written in the law of Moses, An altar {stone entirely}, upon which {was not put upon it an iron tool}. And he transported there whole burnt-offerings to the LORD, and a sacrifice of deliverance. 

#### Joshua 8:32 And Joshua wrote upon the stones the second book of the law, the law of Moses, which he wrote in the presence of the sons of Israel. 

#### Joshua 8:33 And all Israel, and their elders, and their magistrates, and their scribes, were coming near on this side and that side {the ark before}; and the priests and the Levites lifted the ark of the covenant of the LORD; and the foreigner and the native born were there; the halves of them neighboring mount Gerizim, and the halves neighboring mount Ebal, as {gave charge Moses the attendant of the LORD to bless the people Israel at first}. 

#### Joshua 8:34 And after these things Joshua read the whole sayings of this law, the blessings and the curses, according to all the things being written in the law of Moses. 

#### Joshua 8:35 There was not a word from all which Moses gave charge to Joshua, which {did not read Joshua} into the ears of all the assembly of Israel, to the men, and to the women, and to the servants, and to the foreigners going with Israel. 

#### Joshua 9:1 And as they all heard (the kings of the Amorites on the other side of the Jordan, the ones in the mountainous area, and the ones on the plain, and the ones in all the coast of the {sea great}, and the ones towards Antilebanon, and the Hittites, and the Amorites, and the Gergashites, and the Canaanites, and the Perizzites, and the Hivites, and the Jebusites) 

#### Joshua 9:2 that they came together to the same place to wage war against Joshua and Israel all together. 

#### Joshua 9:3 And the ones dwelling in Gibeon heard all as much as Joshua did to Jericho and to Ai. 

#### Joshua 9:4 And they acted, even indeed themselves with astuteness. And coming, they stood by and prepared. And taking {sackcloths old} upon their donkeys, and {leather bags of wine old} being broken down and all tied up, 

#### Joshua 9:5 and the hollows in their shoes, and their sandals old and mended on their feet, and their garments being old upon them, and the bread loaves of their provisions {dry were} and moldy and worm eaten, 

#### Joshua 9:6 that they came to Joshua into the camp of Israel in Gilgal. And they said to Joshua, and to all Israel, From out of a land far off we have come, and now ordain with us a covenant! 

#### Joshua 9:7 And {said the sons of Israel} to the Hivites, Look, {not with me you do dwell together}, so how do we ordain with you a covenant? 

#### Joshua 9:8 And they said to Joshua, {your servants We are}. And {said to them Joshua}, From what place are you, and from what place do you come? 

#### Joshua 9:9 And they said to him, {from out of a land far off exceedingly have come your servants} in the name of the LORD your God. For we have heard his name, and all as much as he did in Egypt; 

#### Joshua 9:10 and all as much as he did to the two kings of the Amorites, to the ones who were on the other side of the Jordan, to Sihon king of Heshbon, and to Og king of Bashan, who dwelt in Ashtaroth and in Edrain. 

#### Joshua 9:11 And {spoke to us our elders}, and all the ones dwelling in our land, saying, Take for yourselves provisions for the journey, and go to meet with them! And you shall say to them, {your servants We are}, and now ordain with us the covenant! 

#### Joshua 9:12 These are our bread loaves we took hot, being provided of them from our houses in the day in which we came forth to come to you. And now behold, they are dry, and have become worm eaten. 

#### Joshua 9:13 And these are the leather bags for the wine which we filled new, And these are torn. And these are our garments made old from the {long journey exceedingly}. 

#### Joshua 9:14 And {took the rulers} their provisions, and the mouth of the LORD they did not ask. 

#### Joshua 9:15 And {made with them Joshua peace}, and ordained with them a covenant, and {swore by an oath to them the rulers of the congregation}. 

#### Joshua 9:16 And it came to pass after three days, after the ordaining with them a covenant, they heard that {near they are} them, and that {among them they dwelt}. 

#### Joshua 9:17 And {departed the sons of Israel}, and came forth into their cities the {day third}. And their cities were Gibeon, and Chephirah, and Beeroth, and cities of Jearim. 

#### Joshua 9:18 And {did not wage war with them the sons of Israel}, for {swore by an oath to them all the rulers of the congregation} by the LORD God of Israel. And {complained all the congregation} about the rulers. 

#### Joshua 9:19 And {said all the rulers} to all the congregation, We swore by an oath to them by the LORD God of Israel. And now, we shall not be able to touch them. 

#### Joshua 9:20 This we will do to them -- to take them alive, and we will preserve them, and there will not be {against us anger} on account of the oath which we swore by an oath to them. 

#### Joshua 9:21 And {said to them the rulers}, They shall live, and they shall be woodcutters and water-carriers to all the congregation, just as {said to them the rulers}. 

#### Joshua 9:22 And {called them together Joshua}, and he spoke to them, saying, Why did you mislead me, saying, {far We are from you exceedingly}; but you are natives of the ones dwelling among us? 

#### Joshua 9:23 And now you are accursed, in no way shall there fail from one of you being a servant, nor woodcutter, nor a water-carrier to me, and to my God. 

#### Joshua 9:24 And they answered Joshua, saying that, A message was announced to us as much as {ordered the LORD your God} Moses his servant to give to you this land, and to utterly destroy us, and all the ones dwelling upon it, from in front of you. And we feared exceedingly for our lives from your presence, and we did this thing. 

#### Joshua 9:25 And now, behold, we are under your hands as it pleases you. And as it seems good to do to us, you do it! 

#### Joshua 9:26 And they did to them thus, and {rescued them Joshua} in that day from the hands of the sons of Israel, and they did not do away with them. 

#### Joshua 9:27 And {established them Joshua} in that day as woodcutters and water-carriers to all the congregation, and for the altar of God until the day today, and for the place which ever the LORD should choose. 

#### Joshua 10:1 And as {heard Adoni-zedec the king of Jerusalem} that Joshua took Ai, and utterly destroyed it, in which manner he did to Jericho and her king, and thus they did also to Ai and her king, and that {deserted the ones dwelling in Gibeon} to Joshua and to Israel, and were in the midst of them; 

#### Joshua 10:2 that they feared among themselves exceedingly. For he knew that {city was a great Gibeon}, as also one of the mother-cities of the kings, for it was great, over Ai, and all its men were strong. 

#### Joshua 10:3 And {sent Adoni-zedec king of Jerusalem} to Holam king of Hebron, and to Piram king of Jarmuth, and to Japhia king of Lachish, and to Debir king of Eglon, saying, 

#### Joshua 10:4 Come, ascend to me, and help me! and we shall wage war against Gibeon. For it deserted to Joshua, and to the sons of Israel! 

#### Joshua 10:5 And they gathered and ascended -- the five kings of the Amorites -- the king of Jerusalem, and the king of Hebron, and the king of Jerimuth, and the king of Lachish, and the king of Eglon, they and all their people; and they besieged Gibeon and attempted to capture it. 

#### Joshua 10:6 And {sent the ones dwelling in Gibeon} to Joshua into the camp of Israel in Gilgal, saying, Do not loosen your hands from your servants! Ascend to us quickly and rescue us, and help us! for {are gathering against us all the kings of the Amorites}, the ones dwelling in the mountainous area. 

#### Joshua 10:7 And Joshua ascended from Gilgal, he and every warrior with him, all mighty in strength. 

#### Joshua 10:8 And the LORD said to Joshua, Do not fear them! for into your hands I have delivered them; there shall not stand even one of them before you. 

#### Joshua 10:9 And when {came upon them Joshua} suddenly, for the entire night he was gone from out of Gilgal, 

#### Joshua 10:10 that {startled them the LORD} from in front of Israel, and {defeated them the LORD defeat with a great} in Gibeon. And they pursued them by the way ascending to Beth-horon, and they slew them unto Azekah and unto Makkedah. 

#### Joshua 10:11 But in their fleeing from in front of the sons of Israel at the descent of Beth-horon, that the LORD cast upon them stones of hail from out of the heaven unto Azekah. And there were more dying by the stones of hail than which were killed by the sons of Israel by sword in the battle. 

#### Joshua 10:12 Then Joshua spoke to the LORD in the day God delivered up the Amorites under the hand of the sons of Israel. And Joshua said, {the sun over Gibeon Let stand}, and the moon over the ravine of Ajalon. 

#### Joshua 10:13 And {stood the sun and the moon} in position until God repulsed their enemies. Is this not written in the scroll of the upright? And {stood the sun} in the midst of the heaven, it did not go forth into descent for the completion {day of one}. 

#### Joshua 10:14 And there was not {a day such} nor former nor latter, so as for God to heed the voice of man, because the LORD joined in war with Israel. 

#### Joshua 10:15 And Joshua returned, and all Israel with him to the camp in Gilgal. 

#### Joshua 10:16 And {fled five kings these} and hid in the cave -- the one in Makkedah. 

#### Joshua 10:17 And it was reported to Joshua, saying, {have been found The five kings} hiding in the cave, the one in Makkedah. 

#### Joshua 10:18 And Joshua said, Roll {stones great} upon the mouth of the cave, and place upon them men to guard them! 

#### Joshua 10:19 But you do not stand firmly! be pursuing after your enemies, and overtake their rear guard, and do not let them enter into their cities! {delivered for them the LORD our God} into our hands. 

#### Joshua 10:20 And it came to pass as Joshua rested, and the son of Israel, in beating them {slaughter great with an exceedingly} even unto completion, that the ones surviving were delivered from them, and entered into the {cities fortified}. 

#### Joshua 10:21 And {returned all the people} to Joshua in Makkedah in the camp in health; and not {growled of the sons of Israel one} with his tongue. 

#### Joshua 10:22 And Joshua said, Open the cave, and lead out to me {five kings these} from out of the cave! 

#### Joshua 10:23 And they did thus, and they led to him {five kings these} out of the cave -- the king of Jerusalem, and the king of Hebron, and the king of Jarmuth, and the king of Lachish, and the king of Eglon. 

#### Joshua 10:24 And when they led them to Joshua, then Joshua called together every man of Israel, saying to them, and the ones commencing the war of the ones going with him, saying to them, Go forth and place your feet upon their necks! And coming forward, they placed their feet upon their necks. 

#### Joshua 10:25 And {said to them Joshua}, You should not fear them nor be timid; be manly and be strong! for thus the LORD shall do to all your enemies whom you make war against them. 

#### Joshua 10:26 And {killed them Joshua after this}, and put them to death, and hung them upon five trees. And they were hanging upon the trees until evening. 

#### Joshua 10:27 And it came to pass towards the descent of the sun, and Joshua gave charge, and they lowered them from the trees. And they tossed them into the cave into which they took refuge there. And they rolled {stones great} upon the cave, which remains until the day today. 

#### Joshua 10:28 And {Makkedah took Joshua} in that day, and he slaughtered it by the mouth of the sword, and the king. And they utterly destroyed them, and every one breathing that was in it. And there was not left behind in it any one surviving. And they did to the king of Makkedah in which manner they did to the king of Jericho. 

#### Joshua 10:29 And Joshua went forth, and all Israel with him, from out of Makkedah unto Libna. And they assaulted against Libna. 

#### Joshua 10:30 And the LORD delivered it also into the hand of Israel. And they took it, and its king. And they slaughtered it by the mouth of the sword, and every one breathing that was in it; there was not left behind in her not even one surviving and having escaped. And they did to its king in which manner they did to the king of Jericho. 

#### Joshua 10:31 And Joshua went forth, and all Israel with him, from out of Libna unto Lachish; and he besieged it, and assaulted it. 

#### Joshua 10:32 And the LORD delivered Lachish into the hands of Israel. And he took it on the second day, and he slaughtered it by the mouth of the sword, and utterly destroyed it in which manner he did to Libna. 

#### Joshua 10:33 Then {ascended Horam king of Gezer} to help Lachish. And {struck him Joshua} by the mouth of the sword, and his people, until there was not being left behind of them one being delivered and escaping. 

#### Joshua 10:34 And Joshua went forth, and all Israel with him, from Lachish unto Eglon, and he besieged it, and captured it. 

#### Joshua 10:35 And {delivered it the LORD} into the hand of Israel. And he took it in that day, and he slaughtered it by the mouth of the sword, and every one breathing in it. In that day they slaughtered in which manner they did to Lachish. 

#### Joshua 10:36 And Joshua went forth, and all Israel with him, from Eglon unto Hebron. And they besieged it. 

#### Joshua 10:37 And they overtook it, and struck it by the mouth of the sword, and its king, and all its villages, and every one breathing, as many as was in it. There was not one surviving. In which manner they did to Eglon, also they utterly destroyed it and all breathing, as much as was in it. 

#### Joshua 10:38 And Joshua returned, and all Israel with him, to Debir; and they besieged it. 

#### Joshua 10:39 And and they took it, and its king, and all her towns; and they struck it by the mouth of the sword, and they utterly destroyed it, and every one breathing in it, and they did not leave behind one surviving. In which manner they did to Hebron, so they did to Dabir, and to its king; just as he did to Libna and its king. 

#### Joshua 10:40 And Joshua struck all the land of the mountainous area, and the Negev, and the plain, and Asedoth, and all its kings; they did not leave behind in it one being delivered, and every one breathing life they utterly destroyed; in which manner {gave charge the LORD God of Israel}. 

#### Joshua 10:41 And {killed them Joshua} from Kadesh Barnea unto Gaza, all the land of Goshen unto Gibeon. 

#### Joshua 10:42 And all these kings and their land Joshua took at once; for the LORD God of Israel joined in war with Israel. 

#### Joshua 10:43 And Joshua returned to Gilgal. 

#### Joshua 11:1 And when {heard Jabin king of Hazor}, he sent to Jobab king of Madon, and to king Shimron, and to king Achshaph, 

#### Joshua 11:2 and to the kings of the places by {Sidon the great}, unto the mountainous area, and unto the wilderness before Chinneroth, and the plain, and unto Napedor, 

#### Joshua 11:3 and to the ones on the coast -- the Canaanites from the east, and to the ones on the coast -- the Amorites, and the Hittites, and Perizzites, and Jebusites, the ones in the mountain, and the Hivites under Hermon unto the land of Mizpeh. 

#### Joshua 11:4 And they came forth, they and their kings with them, {people a vast} as the sand which is by the edge of the sea in multitude, and horses, and {chariots many very}. 

#### Joshua 11:5 And {united all these kings}, and came and camped together by the water of Merom to wage war against Israel. 

#### Joshua 11:6 And the LORD said to Joshua, You should not fear from their face, for tomorrow at this hour I will deliver all of them being putting to flight before the sons Israel. Their horses you shall hamstring, and their chariots you shall incinerate by fire. 

#### Joshua 11:7 And Joshua came, and all the {people warrior} with him, against them at the water of Merom, suddenly. And they fell against them in the mountainous area. 

#### Joshua 11:8 And {delivered them the LORD} under the hands of Israel. And beating them they pursued them unto {Sidon the great}, and unto Misrephoth-maim, and unto the plains of Mizpeh and eastwards. And they slew them until the not being left behind of them one surviving. 

#### Joshua 11:9 And {did to them Joshua} in so far as {gave charge to him the LORD}. {their horses He hamstrung}, and {their chariots he burned} by fire. 

#### Joshua 11:10 And Joshua returned in that time, and overtook Hazor; and her king he killed by the broadsword. {was And Hazor} formerly ruling all these kingdoms. 

#### Joshua 11:11 And he killed everyone breathing in it by the mouth of the sword, and he utterly destroyed all, and there was not left behind in it one breathing. And Hazor they burned by fire. 

#### Joshua 11:12 And all the cities of these kingdoms, and all their kings, Joshua took and did away with them by the mouth of the sword. And he utterly destroyed them in which manner {ordered Moses the servant of the LORD}. 

#### Joshua 11:13 But all the cities being fortified by a mound of them {did not burn Israel}. Except {Hazor only burned Joshua}. 

#### Joshua 11:14 And all her spoils, and the cattle, {despoiled for themselves the sons of Israel}. {of them And all} they utterly destroyed by the mouth of the sword; and he destroyed them, they did not leave behind of them one breathing. 

#### Joshua 11:15 In which manner the LORD gave orders to Moses, to his servant, likewise Moses gave charge to Joshua, and thus Joshua did; he did not violate anything of all which {gave orders to him Moses}. 

#### Joshua 11:16 And Joshua took all this land -- the mountainous area, and the whole land of Negev, and all the land of Goshen, and the plain, and the land towards the west, and the mountain of Israel, and the low lands, the ones towards the mountain; 

#### Joshua 11:17 from mount Halak, and the ascent into Seir, and unto Baal-gad, and the plain of Lebanon under mount Hermon. And {all their kings he took}, and he did away with them, and killed them. 

#### Joshua 11:18 And {days for many} Joshua made {against all these kings war}. 

#### Joshua 11:19 And there was not a city which he did not deliver over to the sons of Israel, except the Hivite dwelling in Gibeon. He took all by war. 

#### Joshua 11:20 For it was by the LORD to become strong of their heart to meet for war against Israel, that they should be utterly destroyed; so that no {should be given to them mercy}, but that they should be utterly destroyed in which manner the LORD told to Moses. 

#### Joshua 11:21 And Joshua came in that time and utterly destroyed the Anakim from out of the mountainous area, from Hebron and from Debir, and from Anab, and from every mountain of Judah, and from every mountain of Israel with their cities. And {utterly destroyed them Joshua}. 

#### Joshua 11:22 He did not leave of the Anakim from the sons of Israel, but except for in Gaza, and in Gath, and in Ashdod, some were left. 

#### Joshua 11:23 And Joshua took all the land, as far as the LORD gave charge to Moses. And {gave them Joshua} by inheritance to Israel in their distribution according to their tribes. And the land rested from waging war. 

#### Joshua 12:1 And these are the kings of the land which {did away with the sons of Israel}, and inherited their land on the other side of the Jordan, of the east sun of the ravine of Arnon unto mount Hermon, and all Araba of the east -- 

#### Joshua 12:2 Sihon the king of the Amorites, who dwelt in Heshbon, dominating from Aroer, which is by the river bank in the ravine of Arnon, in the midst of the ravine, and the half of Gilead, unto Jabbok the rushing stream, the borders of the sons of Ammon. 

#### Joshua 12:3 And Araba unto the sea of Chinneroth according to the east, and unto the sea of Araba, the sea of salts from the east, by the way according to Beth-jeshimoth; and from Teman, the one under Ashdoth Pisgah. 

#### Joshua 12:4 And the border of Og king of Bashan, which was left behind of the giants, the one dwelling in Ashtaroth and in Edrei, 

#### Joshua 12:5 ruling from mount Hermon, and from Salcah, and all Bashan, unto the borders of the Geshurite, and Maachathite, and the half of Gilead, unto the borders of Sihon king of Heshbon. 

#### Joshua 12:6 Moses the servant of the LORD and the sons of Israel struck them. And {gave it Moses the servant of the LORD} by inheritance to Reuben, and Gad, and to the half tribe of Manasseh. 

#### Joshua 12:7 And these are the kings of the Amorites which Joshua did away with, and the sons of Israel on the other side of the Jordan by west of Baal-gad in the plain of Lebanon, and unto mount Halak ascending unto Seir. And {gave it Joshua} to the tribes of Israel as an inheritance according to their lot; 

#### Joshua 12:8 in the mountain, and in the plain, and in Araba, and in Ashdod, and in the wilderness, and Negev -- the Hittite, and the Amorite, and the Canaanite, and the Perizzite, and the Hivite, and the Jebusite -- 

#### Joshua 12:9 the king of Jericho, one; and the king of Ai which is neighboring Beth-el, one; 

#### Joshua 12:10 the king of Jerusalem, one; the king of Hebron, one; 

#### Joshua 12:11 the king of Jarmuth, one; the king of Lachish, one; 

#### Joshua 12:12 the king of Eglon, one; the king of Gezer, one; 

#### Joshua 12:13 the king of Debir, one; the king of Geder, one; 

#### Joshua 12:14 the king of Hormah, one; the king of Arad, one; 

#### Joshua 12:15 the king of Libnah, one; the king of Adullam, one; 

#### Joshua 12:16 the king of Makkedah, one; the king of Beth-el, one; 

#### Joshua 12:17 the king of Tappuah, one; the king of Hepher, one; 

#### Joshua 12:18 the king of Aphek, one; the king of Lasharon, one; 

#### Joshua 12:19 the king of Madon, one; the king of Hazor, one; 

#### Joshua 12:20 the king of Meron, one; the king of Achshaph, one; 

#### Joshua 12:21 the king of Taanach, one; the king of Megiddo, one; 

#### Joshua 12:22 the king of Kedesh, one; the king of Jokneam of Carmel, one; 

#### Joshua 12:23 the king of Dor of Nephedor, one; the king of Goim of Gilgal, one; 

#### Joshua 12:24 the king of Tizrah, one. All these kings were thirty and one. 

#### Joshua 13:1 And Joshua was older being advanced of days; and the LORD said to Joshua, You are grown old, advanced of days, and {land is left much} exceedingly for inheritance. 

#### Joshua 13:2 And this is the land being left; all the borders of the Philistines, and all the Geshurite and the Canaanite, 

#### Joshua 13:3 from the uninhabited part by the face of Egypt, unto the borders of Ekron, from the left of the Canaanites -- which is counted in addition to; the five satrapies of the Philistines, to the Gazite, and to the Ashdodite and to the Ashkelonite, and to the Gittite, and to the Ekronite, and to the Hivite; 

#### Joshua 13:4 from Teman, and all the land of Canaan from Gaza, and the Sidonians unto Aphek, unto the borders of the Amorites. 

#### Joshua 13:5 And all the land of Gabli of the Philistines, and all Lebanon from the east sun from Baal-gad under mount Hermon, unto the entrance of Hamath; 

#### Joshua 13:6 every one dwelling the mountainous area from Lebanon unto Misrephoth-maim, and all the ones of Sidon -- I will utterly destroy them from the face of the sons of Israel; but distribute it to Israel by lot! in which manner I charged you. 

#### Joshua 13:7 And now portion this land by lot of inheritance to the nine tribes, and to the half tribe of Manasseh! 

#### Joshua 13:8 To the ones with him, to Reuben and to Gad, they received their inheritance which {gave to them Moses} on the other side of the Jordan; according to the rising of the sun {granted to them Moses the servant of the LORD}, 

#### Joshua 13:9 from Aroer, which is upon the edge of the stream Arnon, and the city in the midst of the ravine, and all Misor from Medeba unto Dibon; 

#### Joshua 13:10 and all the cities of Sihon king of the Amorites, which reigned in Heshbon, unto the borders of the sons of Ammon; 

#### Joshua 13:11 and Gilead, and the borders of the Geshurites and the Maachathites, all mount Hermon, and all Bashan unto Salcah; 

#### Joshua 13:12 all the kingdom of Og in Bashan, who reigned in Ashtaroth and in Edrei -- this one was left from the remnant of giants; for {struck him Moses} and utterly destroyed him. 

#### Joshua 13:13 But {did not utterly destroy the sons of Israel} the Geshurite, and the Maachathite. And {dwelt the king of the Geshurites and the Maachathites} among the sons of Israel until this day. 

#### Joshua 13:14 Except to the tribe of Levi there was not given an inheritance; the LORD God of Israel, this is their inheritance, as {said to them the LORD}. 

#### Joshua 13:15 And Moses gave to the tribe of the sons of Reuben according to their peoples. 

#### Joshua 13:16 And became theirs the boundaries from Aroer, which is by the face of the ravine Arnon, and the city, the one in the ravine of Arnon, and all Misor and Medeba unto Heshbon, 

#### Joshua 13:17 and all their cities being in Misor, and Dibon, and Bamoth-baal, and the house of Baal-meon, 

#### Joshua 13:18 and Jahaza, and Kedemoth, and Mephaath, 

#### Joshua 13:19 and Kirjathaim, and Sibmah, and Zerath, and Sharah in mount Emak; 

#### Joshua 13:20 and Beth-peor, and Ashdoth Pisgah, and Beth-jeshimoth, 

#### Joshua 13:21 and all the cities of Misor, and all the kingdom of Sihon king of the Amorites, which reigned in Heshbon, whom Moses struck he and the leaders of Midian even Evi and Rekem, and Zur, and Hur, and Reba, rulers of Sihon, the ones dwelling in the land. 

#### Joshua 13:22 And Balaam son Beor the clairvoyant {killed the sons of Israel} by the broadsword in the routing of the enemy. 

#### Joshua 13:23 And became the borders of the sons of Reuben the Jordan boundary. This is the inheritance of the sons of Reuben according to their peoples, the cities, and their properties. 

#### Joshua 13:24 {gave And Moses} to the sons of Gad according to their peoples. 

#### Joshua 13:25 And {were their borders} Jazer, and all the cities of Gilead, and half of the land of the sons of Ammon, unto Aroer which is against the face of Rabbah. 

#### Joshua 13:26 And from Heshbon unto Ramath by Mizpha, Betonim, and Mahanaim unto the borders of Debir; 

#### Joshua 13:27 and Enemek, Beth-aram, and Beth-nimrah, and Succoth, and Zaphon, and the remaining kingdom of Sihon king of Heshbon. The Jordan shall define the bounds, unto part of the sea of Chinnereth, on the other side of the Jordan from the east. 

#### Joshua 13:28 This is the inheritance of the sons of Gad according to their peoples, and according to their cities, and their properties. 

#### Joshua 13:29 And Moses gave to the half tribe of Manasseh, and it became to the halves of the tribe of the sons of Manasseh according to their peoples. 

#### Joshua 13:30 And {were their borders} from Mahanaim, and all the kingdom of Bashan, and all the kingdom of Og king of Bashan, and all the towns of Jair, which are in the land of Bashan, sixty cities; 

#### Joshua 13:31 even half of Gilead, and in Ashtaroth, and in Edrei, cities of the kingdom of Og in Bashan -- these were to the sons of Machir the son of Manasseh, and to the half of the sons of Machir the son of Manasseh according to their peoples. 

#### Joshua 13:32 These are which Moses gave to inherit in the wilderness of Moab on the other side of the Jordan by Jericho from the east. 

#### Joshua 13:33 And to the tribe of Levi {did not give Moses} an inheritance. The LORD God of Israel, he is their inheritance in which manner he said to them. 

#### Joshua 14:1 And these are the ones inheriting of the sons of Israel in the land of Canaan, which {allotted to them Eleazar the priest}, and Joshua the son of Nun, and the rulers of families of the tribes of the sons of Israel. 

#### Joshua 14:2 According to lots they inherited, in which manner the LORD gave charge by the hand of Moses, to the nine tribes, and to the half tribe. 

#### Joshua 14:3 {gave for Moses} a lot to the two tribes and to the half tribe of the other side of the Jordan. And to the Levites {was not given a lot} among them. 

#### Joshua 14:4 For {were the sons of Joseph} two tribes -- Manasseh and Ephraim. And {was not given a portion} to the Levites in the land, but only cities to dwell in, and their outskirts for their cattle and their herds. 

#### Joshua 14:5 In which manner the LORD gave charge to Moses, so {did the sons of Israel}, and they portioned the land. 

#### Joshua 14:6 And there came forward sons of Judah to Joshua in Gilgal. And said to him Caleb the son of Jephunneh the Kenezite, You know the word which the LORD spoke to Moses the man of God concerning me and you in Kadesh Barnea. 

#### Joshua 14:7 {forty For years old I was} when {sent me Moses the servant of God} from Kadesh Barnea to spy out the land. And I answered him a word according to his mind. 

#### Joshua 14:8 But my brethren the ones ascending with me changed over the mind of the people. But I proceeded to follow after the LORD my God. 

#### Joshua 14:9 And Moses swore by an oath in that day, saying that, The land upon which you mounted in it will be yours by lot, and to your children into the eon, for you proceeded to follow after the LORD my God. 

#### Joshua 14:10 And now, {maintained me the LORD} in which manner he said this fortieth and fifth year, from which the LORD spoke this word to Moses; and Israel went in the wilderness. And now behold, I am today a son eighty and five years old. 

#### Joshua 14:11 Yet I am today of strength as when {sent me Moses}, likewise I am strong now {for war to go forth and to enter}. 

#### Joshua 14:12 And now I ask you this mountain as the LORD said in that day, for you heard this word in that day, saying, And now the Anakim are there, in cities great and fortified. If then the LORD {with me should be}, I shall utterly destroy them in which manner {spoke to me the LORD}. 

#### Joshua 14:13 And {blessed him Joshua}, and he gave Hebron to Caleb son of Jephunneh by lot. 

#### Joshua 14:14 On account of this Hebron came to Caleb, to the son of Jephunneh the Kenezite by lot until today's day, because he followed after the order of the LORD God of Israel. 

#### Joshua 14:15 And the name of Hebron formerly was City Arbai, {is the mother-city of the Anakim this}. Then the land abated of war. 

#### Joshua 15:1 And {were the boundaries of the tribe of Judah} according to their peoples; from the borders of Edom from the wilderness of Zin to the south unto Kadesh. 

#### Joshua 15:2 And {were their borders} from the south unto a part {sea of the salty} from the ridge bearing to the south. 

#### Joshua 15:3 And it travels over before the ascent leading to Acrabbim, and goes around Zin, and ascends from the south upon Kadesh Barnea, and it goes forth to Hezron, and ascends into Adar, and it marches around by the descent of Kadesh. 

#### Joshua 15:4 And it goes forth upon Azmon, and it passes out unto the rushing stream of Egypt. And {will be his outer reaches} of the borders at the sea. This is their borders from the south. 

#### Joshua 15:5 And the borders from the east are all the {sea salty}, unto part of the Jordan; and their borders by the north are from the ridge of the sea, and from the part of the Jordan. 

#### Joshua 15:6 {mount The borders} upon Beth-hoglah, and go near from the north unto Beth-arabah. And it ascends unto the borders at the stone of Bohan of the son of Reuben. 

#### Joshua 15:7 And {ascend the borders} unto Debir of the ravine of Achor, and according to the north it goes down to Gilgal, which is before the entrance approach of Adummim, which is towards the south in the ravine. And passes out the border unto the water of the spring of sun. And {will be his outer reaches} the spring of Rogel. 

#### Joshua 15:8 And {ascend the borders} unto the ravine of the son of Hinnom at the back of Jebus from the south, this is Jerusalem. And {pass out the borders} unto the top of the mountain which is by the face of the ravine of Hinnom towards the west, which is by part of the land of Rephaim towards the north. 

#### Joshua 15:9 And {passes out through the border} from the top of the mountain at the spring of the water of Nephtoah; and it passes out unto the towns of mount Ephron; and {leads the border} unto Baalah -- this is the city Jearim. 

#### Joshua 15:10 And {went around the border} from Baalah unto west, and shall go by unto mount Seir, and shall go by unto the back of the city Jearim from the north -- this is Chesalon, and it shall go down to the city of the sun, and shall go by to the south. 

#### Joshua 15:11 And {shall pass out the border} at the back of Ekron towards the north; and {shall pass out the borders} into Shicron, and shall go by the mount of the land of Baalah, and pass out at Jebneel; and {will be the outer reaches} the borders at the sea. And their borders from the west -- the {sea great} shall define the bounds. 

#### Joshua 15:12 These are the borders of the sons of Judah round about according to their peoples. 

#### Joshua 15:13 And to Caleb son of Jephunneh he gave a portion in the midst of the sons of Judah according to the order of God. And {gave to him Joshua} the city Arba, the mother-city of Anak -- this is Hebron. 

#### Joshua 15:14 And {utterly destroyed from there Caleb son of Jephunneh} the three sons of Anak -- Sheshai, and Ahiman, and Talmai, offspring of the Anak. 

#### Joshua 15:15 And {ascended from there Caleb} upon the ones dwelling in Debir; and the name Debir was formerly City of Letters. 

#### Joshua 15:16 And Caleb said, Who ever should take the City of Letters, and should dominate it, I will give to him Achsah my daughter for a wife. 

#### Joshua 15:17 And {took it Othniel son of Kenaz the brother of Caleb younger}. And he gave to him Achsah his daughter to him for a wife. 

#### Joshua 15:18 And it came to pass in her going forth, that she advised him, saying, I will ask my father for a field; and she yelled from the donkey. And Caleb said, What is it with you? 

#### Joshua 15:19 And she said to him, Give a blessing to me! for {for the land of the Negev you have appointed me}. Give to me Golath-maim. And {gave her Caleb} Golath-maim the upper part, and Golath the part below. 

#### Joshua 15:20 This was the inheritance of the tribe of the sons of Judah according to their peoples. 

#### Joshua 15:21 {became And their cities cities foremost} of the tribe of the sons of Judah, upon the borders of Edom, by the wilderness Kabzeel, and Eder, and Jagur, 

#### Joshua 15:22 and Kinah, and Dimonah, and Adadah, 

#### Joshua 15:23 and Kadesh, and Hazor, and Ithnan, 

#### Joshua 15:24 Ziph, and Telem Bealath, 

#### Joshua 15:25 Hazor the new, and the cities of Hezron -- this is Hazor. 

#### Joshua 15:26 Aman, and Shema, and Moladah, 

#### Joshua 15:27 and Hazar-shual, and Hazar-gaddah, and Heshmon, and Beth-palet. 

#### Joshua 15:28 and Beer-sheba, and Biziothiah 

#### Joshua 15:29 and Baalah, and Iim, and Azem, 

#### Joshua 15:30 and Eltolad, and Chesil, and Hormah, 

#### Joshua 15:31 and Ziglag, and Madmannah, and Sansannah, 

#### Joshua 15:32 and Lebaoth, and Shilhim, and Ain, and Rimmon; all the {cities twenty-nine} and their towns. 

#### Joshua 15:33 In the plain, Eshtaol, and Zoreah, and Ashnah, 

#### Joshua 15:34 and Zanoah, and En-gannim, Tapphuah, and Enam, 

#### Joshua 15:35 and Jarmuth, and Adullam, and Socoh, and Azekah, 

#### Joshua 15:36 and Sharaim, and Adithaim, and Gederah, its properties -- {cities fourteen} and their towns; 

#### Joshua 15:37 Zenan, and Hadashah, and Migdal-gad, 

#### Joshua 15:38 and Dilean, and Mizpeh, and Joktheel, 

#### Joshua 15:39 and Lachish, and Bozkath, and Eglon, 

#### Joshua 15:40 and Cabbon, and Lahmam, and Kithlish, 

#### Joshua 15:41 and Gederoth, and Beth-dagon, and Naamah, and Makkedah; {cities sixteen} and their towns; 

#### Joshua 15:42 Libnah, and Ether, and Ashan, 

#### Joshua 15:43 and Jiphtah, and Ashnah, and Nezib, 

#### Joshua 15:44 and Keilah, and Achzib, and Mareshah; {cities nine} and their towns; 

#### Joshua 15:45 Ekron, and her towns, and her properties. 

#### Joshua 15:46 From Ekron and unto the sea, Jemnath and all as much as are neighboring Ashdod, and their towns. 

#### Joshua 15:47 Ashdod and her towns, and her properties; Gaza and her towns, and her properties, unto the rushing stream of Egypt, and the {sea great} separates. 

#### Joshua 15:48 And in the mountainous area, Shamir, and Jatir, and Socoh, 

#### Joshua 15:49 and Dannah, and the city of Letters, this is Debir; 

#### Joshua 15:50 and Anab, and Eshtemoh, and Anim, 

#### Joshua 15:51 and Goshen, and Holon, and Giloh; {cities eleven}, and their towns; 

#### Joshua 15:52 Arab, and Rumah, and Eshean, 

#### Joshua 15:53 and Janum, and Beth-tappuah, and Aphekah, 

#### Joshua 15:54 and Humtah, and the city Arba -- this is Hebron, and Zior; {cities nine} and their properties; 

#### Joshua 15:55 Maon, and Carmel, and Ziph, and Juttah, 

#### Joshua 15:56 and Jezreel, and Jokdeam, and Zanoah, 

#### Joshua 15:57 Cain, and Gibeah, and Timnah; {cities ten} and their towns; 

#### Joshua 15:58 Halhul, and Beth-zur, and Gedor, 

#### Joshua 15:59 and Maarath, and Beth-anoth, and Eltekon; {cities six}, and their towns; 

#### Joshua 15:60 Kirjath-baal -- this is the city Jearim, and Rabbah; {cities two} and their properties; 

#### Joshua 15:61 In the wilderness, Beth-arabah, and Middin, and Secacah, 

#### Joshua 15:62 and Nibshan, and the cities of the of Salts, and En-gedi; {cities six} and their towns. 

#### Joshua 15:63 And the Jebusite dwelt in Jerusalem, and {were not able the sons of Judah} to destroy them; and {dwelt the Jebusites} with the sons of Judah in Jerusalem until this day. 

#### Joshua 16:1 And {were the borders of the sons of Joseph} from the Jordan by Jericho from the east wilderness; and it shall ascend from Jericho unto the mountainous area into Beth-el. 

#### Joshua 16:2 And it shall go forth from Beth-el to Luz, and it shall go by unto the borders of Archi Ataroth. 

#### Joshua 16:3 And it shall go to the west by the borders of Japhleti unto the borders of Beth-horon the part below, and unto Gezer; and {shall be their outer reaches} to the sea. 

#### Joshua 16:4 And {inherited the sons of Joseph -- Manasseh and Ephraim}. 

#### Joshua 16:5 And {were the borders of the sons of Ephraim} according to their peoples; and {were the borders of their inheritance} from the east -- Ataroth Addar unto Beth-horon the upper. 

#### Joshua 16:6 And {shall go the borders} to the sea unto Michmethah from the north, and {shall go by the border} unto eastwards into Taanath-shiloh, and it shall go towards the east to Janoah; 

#### Joshua 16:7 and it shall go down from Janoah to Ataroth, and their towns, and to Naarath, and it shall come to Jericho, and pass out at the Jordan. 

#### Joshua 16:8 And from Tappuah {will go the borders} west unto the rushing stream Kanah; and {will be its outer reaches} at the sea. This is the inheritance of the tribe of the sons of Ephraim according to their peoples. 

#### Joshua 16:9 And the {cities separated} to the sons of Ephraim were in the midst of the inheritance of the sons of Manasseh, all the cities, and their towns. 

#### Joshua 16:10 And {did not destroy Ephraim} the Canaanite dwelling in Gezer; but {dwelt the Canaanite} in Ephraim until this day, and they became {subject to tribute bondmen}. 

#### Joshua 17:1 And {were the borders of the tribe of Manasseh} (for this one is first-born of Joseph) to Machir first-born of Manasseh, father of Gilead. For he was a man of war in Gilead and in the Bashan area. 

#### Joshua 17:2 And there became to the sons of Manasseh, to the ones remaining according to their peoples -- to the sons of Abiezer, and to the sons of Helek, and to the sons of Asriel, and to the sons of Shechem, and to the sons of Hepher, and to the sons of Shemida; these are sons of Manasseh son of Joseph, the males according to their peoples. 

#### Joshua 17:3 And to Zelophehad, son of Hepher, son of Gilead, son of Machir, son of Manasseh, there were no sons to him, but daughters. And these are the names of the daughters of Zelophehad -- Mahlah, and Noah, and Hoglah, and Milcha, and Tirzah. 

#### Joshua 17:4 And they stood before Eleazar the priest, and before Joshua son of Nun, and before the rulers, saying, God gave charge through the hand of Moses to give to us an inheritance in the midst of our brethren. And there was given to them an inheritance by order of the LORD, a lot in the midst of their brethren of their father. 

#### Joshua 17:5 And {fell a piece of measured out land} to Manasseh -- the plain of Labed of the land of Gilead and Bashan, which is on the other side of the Jordan; 

#### Joshua 17:6 for the daughters of the sons of Manasseh inherited a lot in the midst of their brethren. And the land of Gilead became to the sons of Manasseh, to the ones left behind. 

#### Joshua 17:7 And {were the borders of Manasseh} from Asher to Michmethah, which is by the face of Shechem; and it goes to the borders unto Jamin and to Jassib, and to the spring Naphthoth, 

#### Joshua 17:8 upon the borders of Manasseh belonging to the sons of Ephraim. 

#### Joshua 17:9 And {will go down the borders} to the ravine to the south by the ravine of Jariel -- the terebinth of Ephraim, in the midst of the city of Manasseh. And the borders of Manasseh towards north were to the rushing stream, and {will be its outer reaches} the sea. 

#### Joshua 17:10 From the south it was to Ephraim, and towards the north to Manasseh; and {will be the sea} their borders, and at Asher they join together towards the north, and with Issachar from the east. 

#### Joshua 17:11 And Manasseh will be with Issachar; and in Asher Beth-shean and their towns, and Ibleam and her daughter towns, and unto the ones dwelling in Dor and her towns; and unto the ones dwelling in En-dor and her towns, and unto the ones dwelling Taanach and her towns; and the ones dwelling Megiddo and her towns; and the third part of Napheta and her towns. 

#### Joshua 17:12 And {were not able the sons of Manasseh} to utterly destroy these cities. And {began the Canaanite} to dwell in this land. 

#### Joshua 17:13 And it came to pass when {grew strong the sons of Israel} that they made the Canaanites subjects; and as to utterly destroy, they did not utterly destroy them. 

#### Joshua 17:14 {contradicted And the sons of Joseph} Joshua, saying, Why do you allot us {lot one}, and {piece of measured out land one}, and I {people am a populous}, and {blessed me God}? 

#### Joshua 17:15 And {said to them Joshua}, If {people a populous are you}, ascend into the forest, and clear it out for yourself there in the land of the Perizzites and of the Rephaim, if {restricts mount Ephraim}. 

#### Joshua 17:16 And {said the sons of Joseph}, {does not please us Mount Ephraim}, for {horses choice} and an iron weapon is to all the Canaanite dwelling in the land Emek in Beth-shean, and in her towns, and in the valley of Jezreel. 

#### Joshua 17:17 And Joshua said to the sons of Joseph, to Ephraim and to Manasseh, saying, If {people you are many}, and {strength great have}, there shall not be to you {lot only one}. 

#### Joshua 17:18 For the forest shall be to you, for {a forest it is}, and you shall clear it out. And {will be to you his departure} whenever you should utterly destroy the Canaanite, for {cavalry a choice there is} to him, for he is strong; for you excel in strength over him. 

#### Joshua 18:1 And an assembly was held, all the congregation of the sons of Israel in Shiloh; and they pitched there the tent of the testimony, and the land was seized by them. 

#### Joshua 18:2 And {were left the sons of Israel}, for {did not inherit their inheritance seven tribes}. 

#### Joshua 18:3 And Joshua said to the sons of Israel, For how long shall you faint to enter to inherit the land which {gave to us the LORD God of our fathers}? 

#### Joshua 18:4 Give from out of yours three men from a tribe, and send them; and rising up let them go through the land, and let them diagram it before me! as it shall behoove to divide it. And they came to him. 

#### Joshua 18:5 And he divided to them seven portions -- Judah shall stand as a border from the south to them, and the sons of Joseph shall stand upon their border from the north. 

#### Joshua 18:6 And you portion the land into seven portions, and bring the diagram to me here! and I shall bring forth to you a lot here before the LORD your God. 

#### Joshua 18:7 {no For there is} portion to the sons of Levi among you; for the priesthood of the LORD is his portion. And Gad, and Reuben, and the half tribe of Manasseh received its inheritance on the other side of the Jordan eastward, which {gave to them Moses the servant of the LORD}. 

#### Joshua 18:8 And rising up the men went. And Joshua gave charge to the men going to explore the land, saying, Spread, and go through the land, and explore it, and come to me! and I will bring forth to you here a lot before the LORD in Shiloh. 

#### Joshua 18:9 And {went the men} and spread in the land, and explored it. And they beheld it, and they wrote about it according to her cities, seven portions in a scroll, and they brought it to Joshua in the camp in Shiloh. 

#### Joshua 18:10 And {cast for them Joshua} a lot in Shiloh before the LORD. 

#### Joshua 18:11 And {portioned there Joshua} the land to the sons of Israel according to their distributions. And there came forth the lot of the tribe of the sons of Benjamin first according to their peoples. And {came forth the borders of their lot} between the sons of Judah and between the sons of Joseph. 

#### Joshua 18:12 And {were their borders} from the north of the Jordan; {shall ascend the borders} by the back of Jericho at the north, and shall ascend unto the mountain to the west; and {will be its outer reaches} Madbariti of Beth-aven. 

#### Joshua 18:13 And {will go from there the borders} to Luz from the south -- this is Beth-el. And {will go down the borders} from Ataroth Adar upon the mountainous area which is towards the south of Beth-horon, the part below. 

#### Joshua 18:14 And {shall go through the borders} and go around upon the part that looks upon the west from the south, from the mountain upon the face of Beth-horon south. And {will be its outer reaches} unto Kirjath-baal (this is Kirjath-jearim) a city of the sons of Judah. This is the part towards the west. 

#### Joshua 18:15 And the part towards the south of the part of Kirjath-baal, even shall go through unto Gasin, and it shall go forth to the spring of the water Nephtoah. 

#### Joshua 18:16 And {shall go down the borders} unto the part of the mountain which is at the face of the grove of the son Hinnom, which is of the part of Emek-rephaim from the north, and it shall go down unto Gehenna at the back of Jebus from the south. And it shall go down upon the spring of Rogel. 

#### Joshua 18:17 And it shall pass out unto the north, and it shall go through to the spring of Beth-shemesh. 

#### Joshua 18:18 And it shall go by unto Geliloth, which is before by the ascent of Adummim. And it shall go down upon the stone of Bohan of the sons of Reuben. And shall go by the back of Beth-araba from the north, and shall go down to Arabah. And it shall go by at the borders at the back of the sea from the north. 

#### Joshua 18:19 And {shall be the outer reaches of the borders} upon the ridge of the sea of salts from the north, to part of the Jordan from the south. These {the borders are} of the south. 

#### Joshua 18:20 And the Jordan shall define the bounds of it from the part from the east. This is the inheritance of the sons of Benjamin, its borders round about, according to their peoples. 

#### Joshua 18:21 And {were the cities of the tribe of the sons of Benjamin} according to their peoples -- Jericho, and Beth-hoglah, and Mekeziz, 

#### Joshua 18:22 and Beth-arabah, and Zemaraim, and Beth-el, 

#### Joshua 18:23 and Avim, and Parah, and Ophrah, 

#### Joshua 18:24 and Chephar-haammonai, and Ophni and Gaba; {cities twelve} and their towns; 

#### Joshua 18:25 Gibeon, and Ramah, and Beeroth, 

#### Joshua 18:26 and Mizpeh, and Chephirah, and Mozah, 

#### Joshua 18:27 and Rekem, and Irpeel, and Taralah, 

#### Joshua 18:28 and Jebus (this is Jerusalem), and Gibeath, and the city Jearim; {cities thirteen} and their towns. This is the inheritance of the sons of Benjamin according to their peoples. 

#### Joshua 19:1 And {came forth the lot second} to Simeon, to the tribe of the sons of Simeon, according to their peoples; and {was their inheritance} between the lots of the sons of Judah. 

#### Joshua 19:2 And {was to them their lot} Beer-sheba, and Sheba, and Moladah, 

#### Joshua 19:3 and Hazar-shual, and Balah, and Azem, 

#### Joshua 19:4 and Eltolad, and Bethul, and Hormah, 

#### Joshua 19:5 and Ziglag, and Beth-marcaboth, and Hazar-susah, 

#### Joshua 19:6 and Beth-lebaoth, and their fields; {cities thirteen} and their towns. 

#### Joshua 19:7 Ain, and Remmon, and Ether, and Ashan; {cities four} and their towns; 

#### Joshua 19:8 and all the properties round about these cities unto Baalath Beer Ramoth going towards the south. This is the inheritance of the tribe of the sons of Simeon according to their peoples. 

#### Joshua 19:9 From the lot of Judah was the inheritance of the tribe of the sons of Simeon, for it was that the portion of the sons of Judah was greater than theirs; and {inherited the sons of Simeon} in the midst of their lot. 

#### Joshua 19:10 And came forth the {lot third} to Zebulun according to their peoples; {will be the borders of their inheritance} unto Sarid. 

#### Joshua 19:11 And {ascend their borders} unto the west, and Maralah, and it joins together at Dabbasheth, and meets at the ravine which is at the face of Jokneam. 

#### Joshua 19:12 And they return from Sarid right opposite from east of Samis, unto the borders of Chisloth-tabor, and it shall go through upon Daberath, and shall ascend to Japhia. 

#### Joshua 19:13 And from there it shall go around right opposite eastwards upon Gittah-hepher and Zin, and shall go through to Remmon Methoar to Neah. 

#### Joshua 19:14 And {shall go around the borders} towards the north unto Hannathon, and {will be their outer reaches} unto Gai Jiphthah-el, 

#### Joshua 19:15 and Kattath, and Nahallel, and Shimron, and Idalah, and Beth-lehem. {cities Twelve} and their towns. 

#### Joshua 19:16 This is the inheritance of the tribe of the sons of Zebulun according to their peoples, their cities, and their towns. 

#### Joshua 19:17 And to Issachar came forth the {lot fourth}, to the sons of Issachar, according to their kin. 

#### Joshua 19:18 And {were their borders} Jezreel, and Chesulloth, and Shunem, 

#### Joshua 19:19 and Haphraim, and Shihon, and Anaharath, 

#### Joshua 19:20 and Rabbith, and Kishion, and Abez, 

#### Joshua 19:21 and Remeth, and En-gannim, and En-haddah, and Beth-pazzez. 

#### Joshua 19:22 And {joined together the borders} at Tabor, and at Shahazinah, and Beth-shemesh; and {will be the outer reaches of their borders} the Jordan, {cities Sixteen} and their towns. 

#### Joshua 19:23 This is the inheritance of the tribe of the sons of Issachar according to peoples, and the cities and their towns. 

#### Joshua 19:24 And came forth the {lot fifth} to the tribe of the sons of Asher according to their peoples. 

#### Joshua 19:25 And {were their borders} Helkath, and Hali, and Beten, and Achshaph, 

#### Joshua 19:26 and Alammelech, and Amad, and Misheal, and it shall join together with Carmel by the west, and to Shihor, and Libnath. 

#### Joshua 19:27 And it will turn from the east of the sun and Beth-dagon, and shall join together with Zebulun and unto Jiphthah-el, according to the north of Beth-emek and Neiel, and shall go unto Cabul from the left, 

#### Joshua 19:28 and Akran, and Rehob, and Hammon, and Kanah unto {Sidon the great}. 

#### Joshua 19:29 And {shall turn the borders} to Ramah, and unto {city the fortress} of the Tyrians; and {shall turn the borders} to Hosah; and {will be his outer reaches} the sea, and it shall be from the measured land of Achzib, 

#### Joshua 19:30 and Ummah, and Aphek, and Rehob; {cities twenty-two} and their towns. 

#### Joshua 19:31 This is the inheritance of the tribe of the sons of Asher, according to their peoples, their cities, and their towns. 

#### Joshua 19:32 And came forth to Naphtali the {lot sixth}, to the sons of Naphtali according to their peoples. 

#### Joshua 19:33 And {were their borders} Heleph, and Allon to Zaanannim, and Adami, Nekeb, and Jabneel, unto Lakum; and {were their outer reaches} the Jordan. 

#### Joshua 19:34 And {turned the borders} unto the west to Aznoth Tabor, and it shall go from there unto Hukkok, and it shall join together with Zebulun from the south, and Asher will join it towards the west, and Judah of the Jordan from the east sun. 

#### Joshua 19:35 And the {cities walled} of the Tyrians -- Tyre, and Hammath and Rakkath, and Chinnereth, 

#### Joshua 19:36 and Adamah, and Ramah, and Hazor, 

#### Joshua 19:37 and Kedesh, and Edrei, and the spring of Hazor, 

#### Joshua 19:38 and Iron, and Migdal-el, Horem, and Beth-anath, and Beth-shemesh; {cities ten and nine} and their towns. 

#### Joshua 19:39 This is the inheritance of the tribe of the sons of Naphtali according to their kin, and the cities and their properties. 

#### Joshua 19:40 And to the tribe of the sons of Dan according to their peoples came forth the {lot seventh}. 

#### Joshua 19:41 And {was the borders of their inheritance} Zorah, and Eshtaol, city Shemesh, 

#### Joshua 19:42 and Shaalabbin, and Ajalon, and Jethlah, 

#### Joshua 19:43 and Elon, and Timnah, and Ekron, 

#### Joshua 19:44 and Eltekeh, and Gibbethon, and Baalath, 

#### Joshua 19:45 and Jehud, and Bene-berak, and Gath-rimmon. 

#### Joshua 19:46 And towards the west of Me-jarkon and Rakkon, whose border was neighboring Japho. 

#### Joshua 19:47 And went forth the border of the sons of Dan. And {went the sons of Dan} and waged war against Leshem, and overtook it, and struck it by the mouth of the sword; and they inherited it, and they dwelt it, and they called the name Lesen, Dan, according to the name Dan their father. 

#### Joshua 19:48 This is the inheritance of the tribe of the sons of Dan, according to their kin, their cities, and their towns. 

#### Joshua 19:49 And they completed to divide by lot the land unto their borders. And {gave the sons of Israel} a lot to Joshua son of Nun among them, 

#### Joshua 19:50 by the order of the LORD. And they gave to him the city which he asked -- Timnath-serah, which is in mount Ephraim. And he built the city, and he dwelt in it. 

#### Joshua 19:51 These are the divisions which {divided by lot Eleazar the priest}, and Joshua the son of Nun, and the rulers of the families among the tribes of Israel, according to the lots in Shiloh before the LORD, by the doors of the tent of the testimony. And they went entering into the land. 

#### Joshua 20:1 And the LORD spoke to Joshua, saying, 

#### Joshua 20:2 Speak to the sons of Israel! saying, Appoint to you the cities of the places of refuge! which I spoke to you through Moses, 

#### Joshua 20:3 for a place of refuge to the manslayer, to the one striking a life unintentionally without forethought. And {shall be to you the cities} a place of refuge, and {shall not die the manslayer} by the one acting as next of kin for blood. 

#### Joshua 20:4 And he shall flee to one of these cities, and shall stay at the door of the gate of his city, and shall speak in the ears of the elders of that city concerning his words. And {shall return him the congregation} to them, and they shall appoint to him a place, and he shall dwell with them. 

#### Joshua 20:5 And when {should pursue the one acting as next of kin for blood} after him, that they shall not consign the one manslaying into his hand, for not knowing he struck his neighbor, and {was not disliking he himself} him from yesterday, and the third day before. 

#### Joshua 20:6 And he shall dwell in that city, until he should stand in front of the congregation for judgment, until {should die the priest great}, who shall be in those days. Then {shall return the man-slayer}, and shall come unto his city, and to his house, even to the city from where he fled from there. 

#### Joshua 20:7 And he separated Kadesh in Galilee, in mount Naphtali, and Shechem in mount Ephraim, and the city Arba (this is Hebron) in the mountain of Judah. 

#### Joshua 20:8 And on the other side of the Jordan, by Jericho from the east, he gave Bezer in the wilderness on the plain of the tribe of Reuben, and Ramoth in Gilead of the tribe of Gad, and Golan in the Bashan area of the tribe of Manasseh. 

#### Joshua 20:9 These were the cities selected to all sons of Israel, and to the foreigner, to the one lying near among them, to take refuge there, to any one {hitting a soul unintentionally}, that he should not die by the hand of the one acting as next of kin for blood, until whenever he should be placed before the congregation for judgment. 

#### Joshua 21:1 And came forward the chief patriarchs of the sons of Levi to Eleazar the priest, and to Joshua the son of Nun, and to the tribal chiefs of the families of the tribes of the sons of Israel. 

#### Joshua 21:2 And they spoke to them in Shiloh, in the land of Canaan, saying, The LORD gave charge by the hand of Moses to give to us cities to dwell in, and their outskirts for our cattle. 

#### Joshua 21:3 And {gave the sons of Israel} to the Levites in their inheriting by the order of the LORD these cities and their outskirts. 

#### Joshua 21:4 And {came forth the lot} to the people of Kohath, and it was to the sons of Aaron, the priests, to the Levites from the tribe of Judah, and from the tribe of Simeon, and from the tribe of Benjamin -- {by casting lots cities thirteen}. 

#### Joshua 21:5 And to the sons of Kohath, to the ones being left from out of the kin, of the tribe of Ephraim, and from the tribe of Dan, and from the half tribe of Manasseh -- {by casting lots cities ten}. 

#### Joshua 21:6 And to the sons of Gershon, from the kin of the tribe of Issachar, and from the tribe of Asher, and from the tribe of Naphtali, and from the half tribe of Manasseh in Bashan -- {by casting lots cities thirteen}. 

#### Joshua 21:7 And to the sons of Merari, according to their peoples, from the tribe of Reuben, and from the tribe of Gad, and from the tribe of Zebulun -- {by casting lots cities twelve}. 

#### Joshua 21:8 And {gave the sons of Israel} to the Levites these cities and their outskirts, in which manner the LORD gave charge to Moses by casting lots. 

#### Joshua 21:9 And he gave the tribe of the sons of Judah, and the tribe of Simeon these cities. And they were called by name. 

#### Joshua 21:10 And they became to the sons of Aaron, of the people of Kohath, of the sons of Levi; for {to these came the lot} first. 

#### Joshua 21:11 And they gave to them Kirjath-arba, mother-city of the Anak (this is Hebron) in the mountain of Judah, and the outskirts of it round about it. 

#### Joshua 21:12 But the fields of the city, and her towns Joshua gave to Caleb son of Jephunneh for his possession. 

#### Joshua 21:13 And to the sons of Aaron the priest he gave the city, the place of refuge for the one manslaying -- Hebron and the parts being separated with it, and Libnah and the parts being separated with it, 

#### Joshua 21:14 and Jattir and the parts being separated with it, and Eshtemoa and the parts being separated with it, 

#### Joshua 21:15 and Holon and the parts being separated with it, and Debir and the parts being separated with it, 

#### Joshua 21:16 and Ain and the parts being separated with it, and Juttah and the parts being separated with it, and Beth-shemesh and the parts being separated with it; {cities nine} from {two tribes these}. 

#### Joshua 21:17 And from the tribe of Benjamin, Gibeon and the parts being separated with it, and Geba and the parts being separated with it 

#### Joshua 21:18 and Anathoth and the parts being separated with it, and Almon and the parts being separated with it; {cities four}. 

#### Joshua 21:19 All the cities of the sons of Aaron of the priests -- {cities thirteen} and their outskirts. 

#### Joshua 21:20 And to the peoples of the sons of Kohath, to the Levites being left behind from the sons of Kohath. And {came the city of their borders} from the tribe of Ephraim. 

#### Joshua 21:21 And they gave to them the city of the place of refuge for the one manslaying -- Shechem and the parts being separated with it in mount Ephraim, and Gezer and the parts being separated with it, 

#### Joshua 21:22 and Kibzaim and the parts being separated with it, and Beth-horon and the parts being separated with it -- {cities four}. 

#### Joshua 21:23 And from the tribe of Dan, Eltekeh and the parts being separated with it, and Gibbethon and the parts being separated with it, 

#### Joshua 21:24 and Aijalon and the parts being separated with it, and Gath-rimmon and the parts being separated with it -- {cities four}. 

#### Joshua 21:25 And from the half tribe of Manasseh, Tanach and the parts being separated with it, and Gath-rimmon and the parts being separated with it -- {cities two}. 

#### Joshua 21:26 All {cities the ten} and the parts being separated with them to the peoples of the sons of Kohath being left behind. 

#### Joshua 21:27 And to the sons of Gershon, the relatives to the Levites, {were from the half tribe of Manasseh the cities}, the parts being separated for the ones manslaying -- Golan in the Bashan area and the parts being separated with it, and Beeshterah and the parts being separated with it -- {cities two}. 

#### Joshua 21:28 And from the tribe of Issachar, Kishon and the parts being separated with it, Dabareh and the parts being separated with it, 

#### Joshua 21:29 and Jarmuth and the parts being separated with it, and Spring of Letters and the parts being separated with it -- {cities four}. 

#### Joshua 21:30 And from out of the tribe of Asher -- Mishal and the parts being separated with it, and Abdon and the parts being separated with it, 

#### Joshua 21:31 and Helkath and the parts being separated with it, and Rehob and the parts being separated with it -- {cities four}. 

#### Joshua 21:32 And from out of the tribe of Naphtali, the cities being separated for the one manslaying -- Kedesh in Galilee and the parts being separated with it, and Hamoth-dor and the parts being separated with it, and Kartan and the parts being separated with it -- {cities three}. 

#### Joshua 21:33 All the cities of Gershon according to their peoples -- {cities thirteen} and the parts being separated with them. 

#### Joshua 21:34 And to the people of the sons of Merari, the Levites, to the ones remaining from the tribe of the sons of Zebulun -- Jokneam and the outskirts of it, and Kartah and the outskirts of it, 

#### Joshua 21:35 and Dimnah and the outskirts of it, and Nahalal and the outskirts of it -- {cities four}. 

#### Joshua 21:36 And cities of the Jordan of Jericho, from out of the tribe of Reuben, the city of the place of refuge of the one manslaying -- Bezer and the outskirts of it, and Jahazah and the outskirts of it, 

#### Joshua 21:37 and Kedemoth and the outskirts of it, and Maphaath and the outskirts of it -- {cities four}. 

#### Joshua 21:38 And from the tribe of Gad, the city of the place of refuge of the one manslaying -- Ramoth in Gilead and the outskirts of it, and Mahanaim and the outskirts of it; 

#### Joshua 21:39 and Heshbon and the outskirts of it, and Jazer and the outskirts of it -- all the cities were four. 

#### Joshua 21:40 All the cities to the sons of Merari, according to their peoples of the ones left from the tribe of Levi, and were from their borders -- {cities twelve}. 

#### Joshua 21:41 All cities of the Levites in the midst of the possessions of the sons of Israel -- forty-eight cities, 

#### Joshua 21:42 and their outskirts. Round about these cities city by city and the their outskirts round about the cities. Thus to all these cities. 

#### Joshua 21:43 And the LORD gave to Israel all the land which he swore by an oath to give to their fathers; and they inherited it, and dwelt in it. 

#### Joshua 21:44 And {rested them the LORD} round about in so far as he swore by an oath to their fathers. Not {rose up one} before them of all their enemies; {all their enemies delivered up the LORD} into their hands. 

#### Joshua 21:45 Not {failed a word} from all of the {words good} which the LORD spoke to the sons of Israel; all came to pass. 

#### Joshua 22:1 Then Joshua called together the sons of Reuben, and the sons of Gad, and the half tribe of Manasseh. 

#### Joshua 22:2 And he said to them, You have heard the whole, as much as {gave charge to you Moses the servant of the LORD}, and you heeded my voice according to all as much as I gave charge to you. 

#### Joshua 22:3 And you have not abandoned your brethren these {days many}; until the day of today you guarded the commandment of the LORD our God. 

#### Joshua 22:4 And now {rested the LORD our God} our brethren in which manner he spoke to them. Now then in returning you go forth to your houses, and to the land of your possession which {gave to you Moses the bondman of the LORD} on the other side of the Jordan. 

#### Joshua 22:5 But guard exceedingly to do the commandments and the law, which {gave charge to you Moses the servant of the LORD} -- to love the LORD your God, and to go by all his ways, to guard his commandments, and to lie near to them, and to serve him in all your thought, and of {entire soul your}. 

#### Joshua 22:6 And {blessed them Joshua}, and sent them, and they went unto their houses. 

#### Joshua 22:7 And to the halves of the tribe Moses gave a portion in the Bashan area; and to the halves Joshua gave a portion with his brethren on the other side of the Jordan towards the west. And when {sent them Joshua} unto their houses, then he blessed them saying, 

#### Joshua 22:8 With {things many} they went forth unto their houses, and with {cattle much exceedingly}, and silver, and gold, and brass, and iron tools, and clothes {much exceedingly}; and they divided the spoils of their enemies with their brethren. 

#### Joshua 22:9 And {returned and went the sons of Reuben}, and the sons of Gad, and the half tribe of Manasseh from the sons of Israel from Shiloh in the land of Canaan, to go forth into land of Gilead, into the land of their possession which they inherited it, through the order of the LORD by the hand of Moses. 

#### Joshua 22:10 And they came into Galeloth of Jordan, which is in the land of Canaan; and they built (the sons of Reuben, and the sons of Gad, and the half tribe of Manasseh) there a shrine upon the Jordan; {shrine a great} to behold. 

#### Joshua 22:11 And {heard the sons of Israel}, saying, Behold, they built (the sons of Reuben, and the sons of Gad, and the half tribe of Manasseh) a shrine upon the border of the land of Canaan, at Gilead of Jordan, on the other side of the sons of Israel. 

#### Joshua 22:12 And {heard the sons of Israel}, and {gathered together all the sons of Israel} in Shiloh, for their ascending to wage war. 

#### Joshua 22:13 And {sent the sons of Israel} to the sons of Reuben, and to the sons of Gad, and to the half tribe of Manasseh, into the land of Gilead, both Phinehas the son of Eleazar, the son of Aaron the chief priest, 

#### Joshua 22:14 and ten of the rulers of the ones with him; {ruler one} from a house of family, from all of the tribes of Israel, men rulers of the houses of the families -- they are commanders of thousands in Israel. 

#### Joshua 22:15 And they came to the sons of Reuben, and to the sons of Gad, and to the halves of the tribe of Manasseh, unto the land of Gilead; and they spoke to them, saying, 

#### Joshua 22:16 Thus says all the congregation of the LORD, What is this trespass which you trespass before the God of Israel, to turn away today from behind the LORD by building for yourselves a shrine, {defectors to become for you} today from the LORD? 

#### Joshua 22:17 Is it a small thing to you, the sin of Peor, that we were not cleansed from it unto this day, and there became the calamity in the congregation of the LORD? 

#### Joshua 22:18 And you were turned away today from the LORD, and tomorrow {upon all Israel there will be anger}. 

#### Joshua 22:19 And now, if {be small the land of your possession}, pass over into the land of the possession of the LORD! where {encamps there the tent of the LORD}; and inherit among us, and {from the LORD not defectors be}! and {from us do not separate}! on account of your building a shrine outside the altar of the LORD our God. 

#### Joshua 22:20 Behold did not Achan the son of Zara {a trespass trespass} from the offering for consumption, and upon all the congregation became anger? And this one only sinned, but not this one alone died for his sin. 

#### Joshua 22:21 And they answered (the sons of Reuben, and the sons of Gad, and the half tribe of Manasseh,) and said to the commanders of thousands of Israel, saying, 

#### Joshua 22:22 God, the {God LORD is}. And God, the LORD God himself knows, and Israel itself shall know; if {by defection we trespassed} before the LORD, may he not rescue us in this day. 

#### Joshua 22:23 And if we built {for ourselves a shrine}, so as to depart from the LORD, or so as to haul up on it a sacrifice of whole burnt-offerings, or so as to make upon it a sacrifice of deliverance, the LORD himself shall inquire. 

#### Joshua 22:24 But {because of veneration thing we did this}, saying that, Should tomorrow {say your children} to our children, saying, What is it to you and to the LORD God of Israel? 

#### Joshua 22:25 And {a border the LORD put} between us and you, the sons of Reuben and the sons of Gad -- the Jordan; and there is no {to you portion} of the LORD. And {shall separate your sons} from our sons, that they should not worship the LORD. 

#### Joshua 22:26 And we said to do thus, to build this shrine, not because of yield offerings, nor because of sacrifices, 

#### Joshua 22:27 but that {might be this testimony} between us and between you, and between our generations after us, to serve the service of the LORD before him in our yield offerings, and in our sacrifices, and in the sacrifices of our deliverances; and so that {shall not say your children} tomorrow to our children, There is no portion to you of the LORD. 

#### Joshua 22:28 And we said, If it comes to pass at some time or other, and they shall speak to us or to our generations tomorrow, then we shall say, Behold! it is a representation of the altar of the LORD which {made our fathers}. It is not for yield offerings, nor for sacrifices, but it is a testimony between you, and between us, and between our sons. 

#### Joshua 22:29 May it not be then for us to leave from the LORD, so as to turn away in today's days from the LORD, so as to build us an altar for the yield offerings, and the sacrifices, and the sacrifice of deliverance, except for the altar of the LORD our God which is before his tent. 

#### Joshua 22:30 And {heard Phinehas the priest}, and all the rulers of the congregation, and the commanders of Israel, the ones who were with him, the words which they spoke, the sons of Reuben, and the sons of Gad, and the sons of Manasseh, and it pleased them. 

#### Joshua 22:31 And {said Phinehas son of Eleazar the priest} to the sons of Reuben, and to the sons of Gad, and to the sons of Manasseh, Today we know that {is with us the LORD}, for you did not trespass before the LORD this trespass, and that you rescued the sons of Israel from out of the hand of the LORD. 

#### Joshua 22:32 And {returned Phinehas son of Eleazar the priest and the rulers} from the sons of Reuben, and from the sons of Gad, from out of Gilead unto the land of Canaan, to the sons of Israel; and they answered to them with these words. 

#### Joshua 22:33 And {was pleasing the word} to the sons of Israel; and they blessed the God of the sons of Israel. And no longer they spoke to ascend to them for war, to utterly destroy the land of the sons of Reuben and the sons of Gad which they dwelt upon it. 

#### Joshua 22:34 And he named {for Reuben and for Gad the shrine}. And they said that, It is a testimony in the midst of them, that the LORD he {their God is}. 

#### Joshua 23:1 And it came to pass after {days many}, after {rested the LORD God} Israel from all their enemies round about, and Joshua was older being advanced in days, 

#### Joshua 23:2 that Joshua called together all the sons of Israel, and their council of elders, and their rulers, and their magistrates, and their scribes, and he said to them, I grow old and advanced in days. 

#### Joshua 23:3 And you have seen all things as much as {did the LORD our God} to all these nations from in front of you; for the LORD our God, he is the one waging war for you. 

#### Joshua 23:4 Behold whatsoever I said, I cast to you nations, the ones being left to you. These lands will be for lots to your tribes. {from the Jordan All the nations} I utterly destroyed, and from the {sea great} you shall define the bounds by the descent of the sun. 

#### Joshua 23:5 And the LORD your God, he shall utterly destroy them from in front of you, and he shall utterly destroy them from your face; and you shall inherit their land, as {spoke the LORD your God} to you. 

#### Joshua 23:6 Grow strong then exceedingly! to guard and to do all things being written in the scroll of the law of Moses, that you should not turn aside from him to the right or to the left; 

#### Joshua 23:7 that you should not enter unto {nations being left these} with you, and the names of their gods you shall not name among you, and you shall not swear by an oath nor serve, nor shall you do obeisance to them. 

#### Joshua 23:8 But to the LORD your God you shall cleave, just as you did until this day. 

#### Joshua 23:9 And {shall utterly destroy them the LORD} from your face -- {nations great and strong}; and to you no one withstood before you until this day. 

#### Joshua 23:10 {man One} of you pursued a thousand. For the LORD our God, he wages war for you, just as he spoke to you. 

#### Joshua 23:11 But guard exceedingly your lives! to love the LORD your God. 

#### Joshua 23:12 For if you should turn away, and should proceed to leave behind these nations with you, and {connections by marriage you should make} with them, and mix together with them, and they with you. 

#### Joshua 23:13 With knowledge know that in no way shall {proceed the LORD your God} to utterly destroy these nations from your face. And they will be to you for snares, and for obstacles, and for nails in your heels, and for arrows in your eyes, until whenever you should destroy them from {land this good} which {gave to you the LORD your God}. 

#### Joshua 23:14 But I run today the way as also all the ones upon the earth. And you shall know in {whole heart your}, and in {whole soul your}, that {failed not word one} from all of the {words good} of which {spoke the LORD your God} concerning you; all the things being related to us -- he did not dissent from them {word one}. 

#### Joshua 23:15 And it will be in which manner {come unto you all the things good}, which {spoke the LORD your God} unto you; so the LORD will bring upon you all the {things bad}, until he should utterly destroy you from {land this good}, of which {gave to you the LORD your God}, 

#### Joshua 23:16 in your violating the covenant of the LORD your God, which he gave charge to you, and going you shall serve {gods other}, and shall do obeisance to them, and {shall be provoked to anger in rage the LORD} with you, and you shall perish quickly from the {land good} which {gave to you the LORD}. 

#### Joshua 24:1 And Joshua brought together all the tribes of Israel to Shechem, and he called together the elders of Israel, and their rulers, and their magistrates, and their scribes; and they stood before God. 

#### Joshua 24:2 And Joshua said to all the people, Thus says the LORD God of Israel, On the other side of the river {dwelled your fathers} from the beginning -- Terah the father of Abraham, and the father of Nachor; and they served {gods other}. 

#### Joshua 24:3 And I took your father Abraham from out of the other side of the river, and I guided him in all the land of Canaan, and I multiplied his seed. 

#### Joshua 24:4 And I gave to him Isaac; and I gave to Isaac Jacob and Esau; and I gave to Esau mount Seir, for an inheritance to him; and Jacob and his sons went down into Egypt. 

#### Joshua 24:5 And I sent Moses and Aaron, and he struck Egypt with the things which he did among them. 

#### Joshua 24:6 And after these things he led you, and he led your fathers from out of Egypt. And you entered into the sea, and {pursued the Egyptians} after your fathers with chariots and with horses into the {sea red}. 

#### Joshua 24:7 And we yelled to the LORD, and he put a cloud and dimness between you and between the Egyptians; and he brought upon them the sea, and it covered them; and {beheld your eyes} as much as the LORD did in the land of Egypt; and you were in the wilderness {days many}. 

#### Joshua 24:8 And he led you into the land of the Amorites dwelling on the other side of the Jordan; and they deployed against you. And {delivered them the LORD} into your hands, and you inherited their land, and you utterly destroyed them from your face. 

#### Joshua 24:9 And Balak rose up, the son of Zippor, king of Moab, and deployed against Israel. And sending, he called Balaam son of Beor to curse you. 

#### Joshua 24:10 And {did not want the LORD your God} to destroy you, and with blessings he blessed you, and rescued you from their hands. 

#### Joshua 24:11 And you passed over the Jordan and came to Jericho; and {waged war against you the ones dwelling in Jericho}, the Amorite, and the Perizzite, and the Canaanite, and the Hittite, and the Girgashite, and the Hivite, and the Jebusite; and he delivered them into your hands. 

#### Joshua 24:12 And he sent {in front of you the swarm of wasps}, and it cast them out from your presence -- the two kings of the Amorites; but not by your broadsword, nor by your bow. 

#### Joshua 24:13 And he gave to you the land upon which you did not tire by labor upon; and he gave cities which you did not build, but you settled upon them; and he gave vineyards and olive groves which you did not plant, but you shall eat from them. 

#### Joshua 24:14 And now fear the LORD, and serve him in straightness and in righteousness, and remove the {gods alien} which {served your fathers} on the other side of the river, and in Egypt, and serve to the LORD! 

#### Joshua 24:15 But if it is not pleasing to you to serve to the LORD, choose to yourselves today whom you should serve! whether to the gods of your fathers, to the ones on the other side of the river, or whether to the gods of the Amorites, in which you dwell upon their land. But I and my house, will serve to the LORD! 

#### Joshua 24:16 And responding the people said, May it not be to us to leave the LORD so as to serve {gods other}. 

#### Joshua 24:17 The LORD our God, he led us and our fathers from out of the land of Egypt, from the house of slavery, and as many as {he did to us signs these great}, and guarded us in all the way which we went by it, and among all the nations which we went through them. 

#### Joshua 24:18 And the LORD cast out all the nations, and the Amorite dwelling in the land, from our face. But also we will serve to the LORD, for this one is our God. 

#### Joshua 24:19 And Joshua said to all the people, In no way shall you be able to serve to the LORD (for he is holy, and God is jealous, this one shall not spare your violations of the law, and your sins) 

#### Joshua 24:20 when ever you should abandon the LORD, and should serve {gods alien}. And coming he shall afflict you, and shall completely consume you, because {good he did} to you. 

#### Joshua 24:21 And {said the people} to Joshua, No, but to the LORD we shall serve. 

#### Joshua 24:22 And Joshua said to the people, You are witnesses according to yourselves that {chose you yourselves} the LORD, to serve him. And they said, We are witnesses. 

#### Joshua 24:23 And now, remove the {gods alien}, the ones among you, and straighten the heart to the LORD God of Israel! 

#### Joshua 24:24 And {said the people} to Joshua, To the LORD our God we shall serve, and of his voice we shall hearken. 

#### Joshua 24:25 And Joshua ordained a covenant with the people in that day. And he gave to them the law and judgment in Shechem. 

#### Joshua 24:26 And Joshua wrote these things in a scroll of the law of God. And {took stone a great and set it Joshua} there under the terebinth tree before the LORD. 

#### Joshua 24:27 And Joshua said to all the people, Behold, this stone will be to you for a testimony; for it has heard all the things being said by the LORD, as much as he spoke to you today. And this will be in you for a testimony unto the last of the days, when ever you should lie to the LORD your God. 

#### Joshua 24:28 And Joshua sent the people each to his place. 

#### Joshua 24:29 And it came to pass after those things {died Joshua the son of Nun}, a servant of the LORD who was a hundred ten years old. 

#### Joshua 24:30 And they entombed him by the borders of his inheritance in Timmnath-serah, in mount Ephraim, from the north of the mountain of Gaash. 

#### Joshua 24:31 And Israel served to the LORD all the days of Joshua, and all the days of the elders, as many as dragged on in time after Joshua, and as many as beheld all the works of the LORD, as much as he did to Israel. 

#### Joshua 24:32 And {the bones of Joseph took up the sons of Israel} from out of Egypt, and they buried them in Shechem, in the portion of the field of which Jacob acquired from the Amorites dwelling in Shechem for a hundred ewe-lambs, and he gave it to Joseph for a portion. 

#### Joshua 24:33 And Eleazar the son of Aaron the chief priest came to an end; and he was entombed in Gabath of Phinehas his son, which he gave to him in mount Ephraim.