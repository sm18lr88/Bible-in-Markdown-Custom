#### Ruth 1:1 And it came to pass in the days in the judging of the judges. And came to pass a famine in the land. And went forth a man from Beth-lehem of Judea to sojourn in the field of Moab, he, and his wife, and {two sons his}. 

#### Ruth 1:2 And the name to the man was Elimelech, and the name to his wife was Naomi, and the name to {two sons his} -- Mahlon and Chilion, Ephrathites from Beth-lehem of Judah. And they came into the country of Moab, and were there. 

#### Ruth 1:3 And {died Elimelech the husband of Naomi}, and {were left she and two sons her}. 

#### Ruth 1:4 And they took to themselves Moabite wives; the name to the one was Orpah, and the name to the second Ruth. And they dwelt there about ten years. 

#### Ruth 1:5 And {died also indeed both Mahlon and Chilion}. And {was left the woman} of {two sons her}, and of her husband. 

#### Ruth 1:6 And she rose up, and {two daughter-in-laws her}, and they returned from out of the country of Moab; for they heard in the country of Moab that the LORD visited his people to give to them bread loaves. 

#### Ruth 1:7 And she went forth from out of the place of which she was there, and {two daughter-in-laws her} with her; and they went by journey to return to the land of Judah. 

#### Ruth 1:8 And Naomi said to {two daughters-in-law her}, Go please! Let {return each} to the house of her mother! May the LORD deal {with you mercy}, as you did with the ones having died, and with me. 

#### Ruth 1:9 May the LORD give to you that you should find rest each in the house of her husband. And she kissed them, and they lifted up their voice and wept. 

#### Ruth 1:10 And they said to her, {with you We shall return} unto your people. 

#### Ruth 1:11 And Naomi said, Return please, my daughters! Why do you go with me? Are there still to me sons in my belly, and will they be to you for husbands? 

#### Ruth 1:12 Turn back please, my daughters! Go please! for I grow old to not have a husband. For I said, Is it to me a reality to be to me a husband, and shall I give birth to sons? 

#### Ruth 1:13 Shall you wait for them until of which time they should become manly? Or, for them shall you hold up to not have a husband? No, my daughters; for it is made bitter to me exceedingly for you, that {came forth against me the hand of the LORD}. 

#### Ruth 1:14 And they lifted up their voice and wept again. And Orpah kissed her mother-in-law, and turned back to her people. But Ruth followed her. 

#### Ruth 1:15 And Naomi said to Ruth, Behold, {returned sister-in-law your} to her people, and to her gods; {turn back please also you} after your sister-in-law! 

#### Ruth 1:16 {said And Ruth}, Do not confront me to leave you or to turn behind you! For you -- where ever you should go, I shall go; and where ever you should lodge, I shall lodge. Your people shall be my people, and your God my God. 

#### Ruth 1:17 And where ever you should die, I shall die, and there I shall be entombed. Thus {do the LORD} to me! and thus may he add more. For death only shall separate between me and you. 

#### Ruth 1:18 {seeing And Naomi} that she was determined to go with her, she abated to speak to her any more. 

#### Ruth 1:19 {went And both} until their arriving in Beth-lehem. And it came to pass in their coming unto Beth-lehem, that {resounded all the city} concerning them. And they said, Is this Naomi? 

#### Ruth 1:20 And she said to them, Do not indeed call me Naomi! Call me, Bitter one! for {embittered me the worthy one} exceedingly. 

#### Ruth 1:21 I went out full, and {empty returned me the LORD}. And why do you call me Naomi, and the LORD humbled me, and the worthy one afflicted me? 

#### Ruth 1:22 And Naomi returned, and Ruth the Moabitess, her daughter-in-law, with her, to return from the country of Moab. And they came unto Beth-lehem at the beginning {harvest of barley}. 

#### Ruth 2:1 And to Naomi was a male acquaintance to her husband, and the man was mighty in strength of the kin of Elimelech; and the name to him was Boaz. 

#### Ruth 2:2 And {said Ruth the Moabitess} to Naomi, I should go indeed into the field, and gather among the ears of corn after of whom ever I should find favor in his eyes. And she said to her, Go, O daughter! 

#### Ruth 2:3 And she went. And having arrived, she collected together in the field after the ones harvesting. And she fell by chance in the portion of the field of Boaz, the one of the kin of Elimelech. 

#### Ruth 2:4 And behold, Boaz came from Beth-lehem, and he said to the ones harvesting, The LORD be with you. And they said to him, May {bless you the LORD}. 

#### Ruth 2:5 And Boaz said to his servant, to the one having been set over the ones harvesting, Whose young woman is this? 

#### Ruth 2:6 And {answered the servant attending over the ones harvesting} and said, She {servant the Moabitess is} returning with Naomi from out of the country of Moab. 

#### Ruth 2:7 And she said, I shall collect together please, and I will bring in the sheaves behind the ones harvesting. And she came and stood, from morning and until evening, she did not rest in the field a little. 

#### Ruth 2:8 And Boaz said to Ruth, Did you not hear, O daughter? You should not go to collect into {field another}, and you should not go from here; {here you join up} with my young women! 

#### Ruth 2:9 And let your eyes be unto the field where ever mine should harvest! and you should go after them. Behold, I gave charge to the servants to not touch you. And when you shall thirst, then you shall go to the vessels, and you shall drink from where {should draw water the servants}. 

#### Ruth 2:10 And she fell upon her face, and did obeisance upon the ground, and said to him, Why is it that I found favor in your eyes to recognize me, and I am a stranger? 

#### Ruth 2:11 And Boaz answered and said to her, By report it was reported to me all as much as you have done with your mother-in-law after the dying of your husband; and how you left behind your father, and your mother, and the land of your origin, and went to a people which you did not know yesterday and the third day before. 

#### Ruth 2:12 May the LORD repay your work, and may {be your wage} full from the LORD God of Israel, to whom you came to yield under his wings. 

#### Ruth 2:13 And she said, May I find favor in your eyes, O my master; for you comforted me, and because you spoke in your heart to your maidservant; and behold, I shall be as one of your maidservants. 

#### Ruth 2:14 And {said to her Boaz}, Already it is the hour to eat; draw near here! for you shall eat of my bread loaves, and dip your morsel in the vinegar. And Ruth sat by the side of the ones harvesting, and {heaped up to her Boaz} toasted grain, and she ate, and was filled, and left. 

#### Ruth 2:15 And she rose up to collect grain, and Boaz gave charge to his servants, saying, Indeed, {in the midst of the sheaves let her collect}, and do not shame her! 

#### Ruth 2:16 And indeed in setting aside, you set aside for her of the things being heaped up, and allow her! and she shall collect, and you shall not reproach her. 

#### Ruth 2:17 And she collected in the field until evening, and she beat with a rod what she collected up, and it was about an ephah of barley. 

#### Ruth 2:18 And she carried it, and entered into the city. And {saw mother-in-law her} what she collected, and Ruth brought forth to give to her what was left of what she was filled up with. 

#### Ruth 2:19 And {said to her mother-in-law her}, Where did you collect today? And where did you do it? May it be the one recognizing you a blessing. And Ruth reported to her mother-in-law where she did it. And she said, The name of the man with whom I did this today is Boaz. 

#### Ruth 2:20 {said And Naomi} to her daughter-in-law, Blessed is the LORD, for he abandoned not his mercy with the living and with the ones having died. And {said to her Naomi}, {is near to us The man}, of the ones acting as next of kin -- he is of us. 

#### Ruth 2:21 And Ruth said to her mother-in-law, And also he said to me, {with the young men of mine You cleave}! until whenever they should finish all the harvest which belongs to me 

#### Ruth 2:22 And Naomi said to Ruth her daughter-in-law, It is good, O daughter, that you went forth with his young women, and they shall not meet with you in {field another}. 

#### Ruth 2:23 And Ruth cleaved to the young women of Boaz to collect until they completed the harvest of the barley, and the harvest of the wheat. 

#### Ruth 3:1 And she stayed with her mother-in-law. And {said to her Naomi mother-in-law her}, O daughter, In no way shall I seek rest for you, that a good thing should happen to you. 

#### Ruth 3:2 And now, is not Boaz a near acquaintance to us, of whom you were with his young women? Behold, he winnows at the threshing-floor of the barley this night. 

#### Ruth 3:3 And you shall bathe, and anoint, and put your clothes upon yourself, and ascend unto the threshing-floor! You should not make yourself known to the man, until he finishes eating and drinking. 

#### Ruth 3:4 And it will be at his going to sleep, that you shall perceive the place where he sleeps there, and you shall go in, and uncover the things by his feet, and you shall go to sleep. And he shall report to you what you shall do. 

#### Ruth 3:5 {said And Ruth} to her, All as much as you should tell to me I will do. 

#### Ruth 3:6 And she went down into the threshing-floor, and she did according to all as much as {gave charge to her her mother-in-law}. 

#### Ruth 3:7 And Boaz ate, and drank, and did good to his heart; and he went to go to sleep in a portion of the pile. And she came in secret, and uncovered the things by his feet, and she went to sleep. 

#### Ruth 3:8 And it came to pass at midnight, that {was startled the man} and disturbed; and behold, a woman slept at his feet. 

#### Ruth 3:9 And he said, Who are you? And she said, I am Ruth, your maidservant; and you shall put your garment border upon your maidservant, for {a relative you are}. 

#### Ruth 3:10 And Boaz said, Being blessed are you by the LORD God, O daughter, for you did good in your mercy at the last over the first, {to not go for you} after the young men, whether poor or whether rich. 

#### Ruth 3:11 And now, O daughter, do not fear! All what ever you should say I will do for you. {know For all tribe of the people of my} that {a woman of ability are you}. 

#### Ruth 3:12 And now truly {a relative I am}; but indeed there is a relative in the land who is over me. 

#### Ruth 3:13 You lodge the night! and it will be in the morning, if he should act as next of kin for you -- good, let him act as next of kin! But if he should not want to act as next of kin for you, {shall act as next of kin for you I}. As the LORD lives, you go to sleep until morning! 

#### Ruth 3:14 And she went to sleep at his feet until morning. And she rose up before {could recognize a man} his neighbor. And Boaz said, Do not let it be known, that {has come a woman} unto the threshing-floor! 

#### Ruth 3:15 And he said to her, Bring the apron, the one upon you, and hold it! And she held it, and he measured out six measures of barley, and placed them unto her. And she entered into the city. 

#### Ruth 3:16 And Ruth entered to her mother-in-law. And she said, What is it, O daughter? And she reported to her all as much as {did for her the man}. 

#### Ruth 3:17 And she said, {six measures of barley these} he gave to me, for he said to me, You should not enter empty to your mother-in-law. 

#### Ruth 3:18 And she said, Sit down, O daughter, until you realize how {shall fall the matter}! for {should not be still the man} until whenever he should finish the matter today. 

#### Ruth 4:1 And Boaz ascended unto the gate, and sat there. And behold, the relative came near whom Boaz spoke of. And {said to him Boaz}, In turning aside, sit here in private! And he turned aside, and sat. 

#### Ruth 4:2 And Boaz took ten men from the elders of the city, and said, Sit here! And they sat. 

#### Ruth 4:3 And Boaz said to the one acting as next of kin, Concerning the portion of the field which is of our brother Elimelech, which he gave to Naomi, the one returning from out of the country of Moab, 

#### Ruth 4:4 that I said to myself, I will uncover your ear, saying, You acquire it before the ones sitting down, and before the elders of my people! If you are a acting as next of kin, then act as next of kin! But if not acting as next of kin, announce it to me! and I shall know. For there is no one besides you to act as next of kin, and I am after you. And he said, I am. I shall act as next of kin. 

#### Ruth 4:5 And Boaz said, In the day you acquire the field from the hand of Naomi, also of Ruth the Moabitess, wife of the one having died, even she {acquire you must}, so as to raise up the name of the one having died, for his inheritance. 

#### Ruth 4:6 And {said the relative}, I shall not be able to act as next of kin myself, lest at any time I ruin my right of inheritance. {act as next of kin yourself You} for my inheritance! for I shall not be able to act as next of kin. 

#### Ruth 4:7 And this was the ordinance in former times in Israel for the right of inheritance, and for the equivalent, to establish every matter. {untied A man} his sandal, and he gave it to his neighbor, to the one acting as next of kin for his right of inheritance; and this was testimony in Israel. 

#### Ruth 4:8 And {said the relative} to Boaz, You acquire to yourself my right of inheritance! And he untied his sandal and gave it to him. 

#### Ruth 4:9 And Boaz said to the elders, and to all the people, You are witnesses today that I have acquired all the things of Elimelech, and all as much as exists to Chilion and Mahlon, from the hand of Naomi. 

#### Ruth 4:10 And indeed, Ruth the Moabitess, the wife of Mahlon I have acquired for myself for wife, to raise up the name of the one having died, for his inheritance, and {shall not be utterly destroyed the name of the one having died} from among his brethren, and from the gate of his place -- you are witnesses today. 

#### Ruth 4:11 And {said all the people at the gate}, We are witnesses. And the elders said, May the LORD give your wife, the one entering into your house, to be as Rachel and as Leah, the ones who {built both} the house of Israel, and did powerfully in Ephratah, and it will be a name in Beth-lehem. 

#### Ruth 4:12 And may {become your house} as the house of Pharez, whom Tamar bore to Judah. Of your seed may {give to you the LORD of this maidservant children}. 

#### Ruth 4:13 And Boaz took Ruth, and she became to him for wife. And he entered to her. And {gave to her the LORD} conception, and she bore a son. 

#### Ruth 4:14 And {said the women} to Naomi, Blessed be the LORD who rested not to provide to you today a relative; and may he call out your name in Israel. 

#### Ruth 4:15 And he will be to you for restoring life, and to nourish your gray hair; for your daughter-in-law, the one loving you, bore him, which is good to you above seven sons. 

#### Ruth 4:16 And Naomi took the boy, and put him to her bosom, and became to him for a wet-nurse. 

#### Ruth 4:17 And {called to him the neighbor women} the name, saying, {was birthed A son} to Naomi. And they called his name Obed. This one is father of Jesse, father of David. 

#### Ruth 4:18 And these are the generations of Pharez. Pharez engendered Hezron, 

#### Ruth 4:19 and Hezron engendered Ram, and Ram engendered Amminadab, 

#### Ruth 4:20 and Aminadab engendered Nahshon, and Nahshon engendered Salmon, 

#### Ruth 4:21 and Salmon engendered Boaz, and Boaz engendered Obed, 

#### Ruth 4:22 and Obed engendered Jesse, and Jesse engendered David.