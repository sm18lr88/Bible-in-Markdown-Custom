#### 1 Chronicles 1:1 Adam, Seth, Enosh, 

#### 1 Chronicles 1:2 Kenan, Mahalalel, Jered, 

#### 1 Chronicles 1:3 Enoch, Methuselah, Lamech, 

#### 1 Chronicles 1:4 Noah, Shem, Ham, Japheth. 

#### 1 Chronicles 1:5 The sons of Japheth -- Gomer, and Magog, and Madai, and Javan, and Tubal, and Meshech, and Tiras. 

#### 1 Chronicles 1:6 And the sons of Gomer -- Ashchenaz and Riphath, and Togarmah. 

#### 1 Chronicles 1:7 And the sons of Javan -- Elishah, and Tarshish, Kittim and Dodanim. 

#### 1 Chronicles 1:8 And the sons of Ham -- Cush, and Mizraim, Put, and Canaan. 

#### 1 Chronicles 1:9 And the sons of Cush -- Seba, and Havilah, and Sabta, and Raamah, and Sabtecha. And the sons of Raama -- Sheba and Dedan. 

#### 1 Chronicles 1:10 And Cush procreated Nimrod -- this one began to be a giant on the earth. 

#### 1 Chronicles 1:11 Mizraim procreated the Ludim, the Anamim, and the Lehabim, the Naphuhim 

#### 1 Chronicles 1:12 And the Pathrusim, and the Casluhim from where {came forth from there the Philistines}, and the Caphthorim. 

#### 1 Chronicles 1:13 And Canaan procreated Sidon his firstborn, and Heth. 

#### 1 Chronicles 1:14 And the Jebusite, and the Amorite, and the Girgashite, 

#### 1 Chronicles 1:15 and the Hivite, and the Archite, and the Sinite, 

#### 1 Chronicles 1:16 and the Arvadite, and the Zemarite, and the Hamathite. 

#### 1 Chronicles 1:17 The sons of Shem -- Elam, and Asshur, and Arphaxad, and Lud, and Aram, and Uz, and Hul, and Gether, and Meshech. 

#### 1 Chronicles 1:18 And Arphaxad procreated Cainan, and Cainan procreated Shelah, and Shelah procreated Eber. 

#### 1 Chronicles 1:19 And to Eber {were procreated two sons}. The name to the one was Peleg; for in his days {was portioned the earth}. And the name to his brother was Joktan. 

#### 1 Chronicles 1:20 And Joktan procreated Almodad, and Sheleph, and Hazarmaveth, and Jerah, 

#### 1 Chronicles 1:21 and Hadoram, and Uzal, and Diklah, 

#### 1 Chronicles 1:22 and Ebal, and Abimael, and Sheba, 

#### 1 Chronicles 1:23 and Ophir, and Havilah, and Jobab. All these are sons of Joktan. 

#### 1 Chronicles 1:24 Shem, Arphaxad, Shelah, 

#### 1 Chronicles 1:25 Eber, Peleg, Reu, 

#### 1 Chronicles 1:26 Serug, Nahor, Terah, 

#### 1 Chronicles 1:27 Abram -- he was Abraham. 

#### 1 Chronicles 1:28 Sons of Abraham -- Isaac and Ishmael. 

#### 1 Chronicles 1:29 These are their genealogies. First-born of Ishmael -- Nebaioth, and Kedar, and Adbeel and Mibsam, 

#### 1 Chronicles 1:30 Mishma and Dumah, Massa, Hadad and Tema, 

#### 1 Chronicles 1:31 Jetur, Naphish, and Kedemah. These are the sons of Ishmael. 

#### 1 Chronicles 1:32 And sons of Keturah, concubine of Abraham -- and she bore Zimran, and Jokshan, and Medan and Midian, and Ishbak, and Shuah. And the sons of Jokshan -- Sheba and Dedan. 

#### 1 Chronicles 1:33 And the sons of Midian -- Ephah, and Epher, and Henoch, and Abida, and Eldaah. All these were sons of Keturah. 

#### 1 Chronicles 1:34 And Abraham procreated Isaac. The sons of Isaac -- Esau and Israel. 

#### 1 Chronicles 1:35 The sons of Esau -- Eliphaz, and Reuel, and Jeush, and Jaalam, and Korah. 

#### 1 Chronicles 1:36 The sons of Eliphaz -- Teman, and Omar, Zephi, and Gatam, Kenaz; and by Timna, and Amalek. 

#### 1 Chronicles 1:37 And the sons of Reuel -- Nahath, Zerah, Shammah, and Mizzah. 

#### 1 Chronicles 1:38 And the sons of Seir -- Lotan, and Shobal, and Zibeon, and Anah, and Dishon, and Ezer, and Dishan. 

#### 1 Chronicles 1:39 And the sons of Lotan -- Hori, and Honam; and the sister of Lotan -- Timna. 

#### 1 Chronicles 1:40 The sons of Shobal -- Alian, and Manahath, and Ebal, Shephi, and Onam. And the sons of Zibeon -- Ajah and Anah. 

#### 1 Chronicles 1:41 The sons of Anah -- Dishon. And the sons of Dishon. And the sons of Dishon -- Amram, and Eshban, and Ithran, and Cheran. 

#### 1 Chronicles 1:42 And the sons of Ezer -- Bilhan and Zavan and Jakan. The sons of Dishan -- Uz and Aran. 

#### 1 Chronicles 1:43 And these are the kings, the ones reigning in the land of Edom before {reigned a king} among the sons of Israel. Bela son of Beor, and the name of his city was Dinhabah. 

#### 1 Chronicles 1:44 And Bela died, and reigned instead of him, Jobab son of Zerah of Bozrah. 

#### 1 Chronicles 1:45 And Jobab died, and reigned instead of him Husham of the land of the Temanites. 

#### 1 Chronicles 1:46 And Husham died, and reigned instead of him, Hadad son of Bedad, the one striking Midian in the field of Moab. And the name of his city was Avith. 

#### 1 Chronicles 1:47 And Hadad died, and reigned instead of him, Samlah of Masrekah. 

#### 1 Chronicles 1:48 And Samlah died, and reigned instead of him, Shaul of Rehoboth of the river. 

#### 1 Chronicles 1:49 And Shaul died, and reigned instead of him, Baal-hanan son of Achbor. 

#### 1 Chronicles 1:50 And Baal-hanan died, and reigned instead of him, Hadad. And the name of his city was Pai. And the name of his wife was Mehetabel, daughter of Matred, daughter of Mezahab. 

#### 1 Chronicles 1:51 And Hadad died. And {were The governors of Edom} -- governor Timnah, governor Aliah, governor Jetheth, 

#### 1 Chronicles 1:52 governor Aholibamah, governor Elah, governor Pinon, 

#### 1 Chronicles 1:53 governor Kenaz, governor Teman, governor Mibzar, 

#### 1 Chronicles 1:54 governor Magdiel, governor Iram. These were the governors of Edom. 

#### 1 Chronicles 2:1 These were of the sons of Israel -- Reuben, Simeon, Levi, Judah, Issachar, Zebulun, 

#### 1 Chronicles 2:2 Dan, Joseph, Benjamin, Naphtali, Gad, and Asher. 

#### 1 Chronicles 2:3 Sons of Judah -- Er, and Onan, and Shelah. These three were born to him from the daughter of Shua the Canaanitess. And {was Er the first-born of Judah} wicked before the LORD, and he killed him. 

#### 1 Chronicles 2:4 And Tamar his daughter-in-law bore to him Pharez, and Zerah. All these sons of Judah -- five. 

#### 1 Chronicles 2:5 Sons of Pharez -- Hezron and Hamul. 

#### 1 Chronicles 2:6 And sons of Zerah -- Zimri, and Ethan, and Heman, and Calcol, and Dara, all these -- five. 

#### 1 Chronicles 2:7 And sons of Carmi -- Achar the disturber of Israel, who broke contract in the offering for consumption. 

#### 1 Chronicles 2:8 And sons of Ethan -- Azariah. 

#### 1 Chronicles 2:9 And sons of Hezron, the ones who were born to him -- Jerahmeel, and Ram, and Chelubai. 

#### 1 Chronicles 2:10 And Ram procreated Amminadab; and Amminadab procreated Nahshon, ruler of the house of Judah. 

#### 1 Chronicles 2:11 and Nahshon procreated Salma; and Salma procreated Boaz; 

#### 1 Chronicles 2:12 and Boaz procreated Obed; and Obed procreated Jesse; 

#### 1 Chronicles 2:13 and Jesse procreated his first-born Eliab, and Abinadab the second, and Shimma the third, 

#### 1 Chronicles 2:14 Nethaneel the fourth, and Raddai the fifth, 

#### 1 Chronicles 2:15 Ozem the sixth, David the seventh, 

#### 1 Chronicles 2:16 and their sisters -- Zeruiah, and Abigail. And the sons of Zeruiah -- Abishai, and Joab, and Asahel -- these three. 

#### 1 Chronicles 2:17 And Abigail bore Amasa; and the father of Amasa was Jether the Ishmeelite. 

#### 1 Chronicles 2:18 And Caleb the son of Hezron took Azubah as wife, and Jerioth; and these are her sons -- Jesher, and Shobab, and Ardon. 

#### 1 Chronicles 2:19 And Azubah died, and {took for himself Caleb} Ephrath, and she bore to him Hur. 

#### 1 Chronicles 2:20 And Hur procreated Uri. And Uri procreated Bezaleel. 

#### 1 Chronicles 2:21 And after this Hezron entered to the daughter of Machir father of Gilead, and he took her, and he {sixty years old was}. And she bore to him Segub. 

#### 1 Chronicles 2:22 And Segub procreated Jair. And there were to him twenty and three cities in the land of Gilead. 

#### 1 Chronicles 2:23 And he took Geshur and Aram the towns of Jair from them, with Kenath and her towns -- sixty cities. All these sons of Machir father of Gilead. 

#### 1 Chronicles 2:24 And after the dying of Hezron, Caleb came into Ephratah. And the wife of Hezron was Abiah, and she bore to him Ashur father of Tekoa. 

#### 1 Chronicles 2:25 And these were the sons of Jerahmeel, the first-born of Hezron -- first-born Ram, and Bunah, and Oren, and Ozem and Ahijah. 

#### 1 Chronicles 2:26 And there was {wife another} to Jerahmeel, and her name was Atarah; she is the mother of Onam. 

#### 1 Chronicles 2:27 And {were the sons of Ram}, the first-born of Jerahmeel -- Maaz, and Jamin, and Eker. 

#### 1 Chronicles 2:28 And {were the sons of Onam} -- Shammai, and Jada. And the sons of Shammai -- Nadab and Abishur. 

#### 1 Chronicles 2:29 And the name to the wife of Abishur was Abihail. And she bore to him Ahban and Molid. 

#### 1 Chronicles 2:30 And the sons of Nadab -- Seled and Appaim. And Seled died not having children. 

#### 1 Chronicles 2:31 And the sons of Appaim -- Ishi. And the sons of Ishi -- Sheshan. And the sons of Sheshan -- Ahlai. 

#### 1 Chronicles 2:32 And the sons of Jada brother of Shammai -- Jether and Jonathan; and Jether died not having children. 

#### 1 Chronicles 2:33 And the sons of Jonathan -- Peleth and Zaza. These were the sons of Jerahmeel. 

#### 1 Chronicles 2:34 And there were no sons to Sheshan, but only daughters. And to Sheshan there was an Egyptian servant, and the name to him was Jarha. 

#### 1 Chronicles 2:35 And Sheshan gave his daughter to Jarha his servant for a wife; and she bore to him Attai. 

#### 1 Chronicles 2:36 And Attai procreated Nathan, and Nathan procreated Zabad, 

#### 1 Chronicles 2:37 and Zabad procreated Ephlal, and Ephlal procreated Obed, 

#### 1 Chronicles 2:38 and Obed procreated Jehu, and Jehu procreated Azariah, 

#### 1 Chronicles 2:39 and Azariah procreated Helez, and Helez procreated Eleasah, 

#### 1 Chronicles 2:40 and Eleasah procreated Sisamai, and Sisamai procreated Shallum, 

#### 1 Chronicles 2:41 and Shallum procreated Jekamiah, Jekamiah procreated Elishama. 

#### 1 Chronicles 2:42 And the sons of Caleb brother of Jerahmeel -- Mesha his first-born, he is father of Ziph -- and the sons of Mareshah father of Hebron. 

#### 1 Chronicles 2:43 And the sons of Hebron -- Korah, and Tappua, and Rekem, and Shema. 

#### 1 Chronicles 2:44 And Shema procreated Raham father of Jorkoam. And Rekem procreated Shammai. 

#### 1 Chronicles 2:45 And the son of Shammai -- Maon. And Moan was father of Beth-zur. 

#### 1 Chronicles 2:46 And Ephah the concubine of Caleb bore Haran, and Moza, and Gazez. And Haran procreated Gazez. 

#### 1 Chronicles 2:47 And the sons of Jahdai -- Regem, and Jotham, and Gesham, and Pelet, and Ephah, and Shaaph. 

#### 1 Chronicles 2:48 And the concubine of Caleb -- Maachah bore Sheber and Tirhanah, 

#### 1 Chronicles 2:49 and she bore Shaaph father of Madmannah, and Sheva father of Machbenah, and the father of Gibea; and the daughter of Caleb was Achsa. 

#### 1 Chronicles 2:50 These were the sons of Caleb sons Hur the first-born of Ephratah -- Shobal the father of Kirjath-jearim, 

#### 1 Chronicles 2:51 Salma father of Beth-lehem, Haareph father of Beth-gader. 

#### 1 Chronicles 2:52 And these were the sons to Shobal father of Kirjath-jearim -- Haroeh, and Aisi, and Ammanith, 

#### 1 Chronicles 2:53 and Oumasphae the city of Jair. Aithalim, and Miphithim, and Esamathim, and Emasaraim. From out of these came forth the Zareathitees, and the Eshtaulites. 

#### 1 Chronicles 2:54 And the sons of Salma -- Beth-lehem and the Netophathites, Ataroth of the house of Joab, and half of the Menahethites; the Zorites. 

#### 1 Chronicles 2:55 And the families of the scribes dwelling in Jabez -- the Tirathites, Shimeathites, Suchathites, these are the Kenites, the ones coming from out of Hemath, the father of the house of Rechab. 

#### 1 Chronicles 3:1 And these were the sons of David, the ones being born to him in Hebron. The first-born was Amnon to Ahinoam the Jezreelitess. The second, Daniel, to Abigail the Carmelitess. 

#### 1 Chronicles 3:2 The third, Absalom, son of Maachah daughter of Talmai king of Geshur. The fourth, Adonijah son of Haggith. 

#### 1 Chronicles 3:3 The fifth, Shephatiah to Abital. The sixth, Ithream to Eglah his wife. 

#### 1 Chronicles 3:4 Six were born to him in Hebron, and he reigned there seven years and six months. And thirty and three years he reigned in Jerusalem. 

#### 1 Chronicles 3:5 And these were born to him in Jerusalem -- Shimea, and Shobab, and Nathan, and Solomon -- four to Bathsheba daughter of Ammiel. 

#### 1 Chronicles 3:6 And Ibhar, and Elishama, and Eliphelet, 

#### 1 Chronicles 3:7 and Nogah, and Nepheg, and Japhia, 

#### 1 Chronicles 3:8 and Elishama, and Eliada, and Eliphelet -- nine. 

#### 1 Chronicles 3:9 All these are sons of David besides the sons of the concubines, and Tamar their sister. 

#### 1 Chronicles 3:10 Sons of Solomon -- Rehoboam; Abia was his son, Asa his son, Jehoshaphat his son, 

#### 1 Chronicles 3:11 Joram his son, Ahaziah his son, Joash his son, 

#### 1 Chronicles 3:12 Amaziah his son, Azariah his son, Jotham his son, 

#### 1 Chronicles 3:13 Ahaz his son, Hezekiah his son, Manasseh his son, 

#### 1 Chronicles 3:14 Amon his son, Josiah his son. 

#### 1 Chronicles 3:15 And the sons of Josiah -- first-born Johanan, the second Jehoiakim, the third Zedekiah, the fourth Shallum. 

#### 1 Chronicles 3:16 And the sons of Jehoiakim -- Jeconiah his son, Zedekiah his son. 

#### 1 Chronicles 3:17 And the sons of Jeconiah -- Assir, Salathiel his son. 

#### 1 Chronicles 3:18 And and Melchiram, and Pedaiah, and Shenazar, and Jecamiah, and Hoshama, and Nedabiah. 

#### 1 Chronicles 3:19 And the sons of Pedaiah -- Zerubbabel, and Shimei. And the sons of Zerubbabel -- Meshullam, and Hananiah, and Shelomith their sister, 

#### 1 Chronicles 3:20 and Hashubah, and Ohel, and Berechiah, and Hasadiah, and Jushab-hesed -- five. 

#### 1 Chronicles 3:21 And the sons of Hananiah -- Pelatiah, and Jesaiah his son, Rephaiah his son, Arnan his son, Obadiah his son, Shechaniah his son. 

#### 1 Chronicles 3:22 And the sons of Shechaniah -- Shemaiah. And the sons of Shemaiah -- Hattush, and Igeal, and Bariah, and Neariah, and Shaphat -- six. 

#### 1 Chronicles 3:23 And the sons of Neariah -- Elioenai, and Hezekiah, and Azrikam -- three. 

#### 1 Chronicles 3:24 And the sons of Elioenai -- Hodaiah, and Eliashib, and Pelaiah, and Akkub, and Johanan, and Dalaiah, and Anani -- seven. 

#### 1 Chronicles 4:1 The sons of Judah -- Pharez, Hezron, and Carmi and Hur, Shobal, 

#### 1 Chronicles 4:2 and Reaiah son of Shobal procreated Jahath; and Jahath procreated Ahumai, and Lahad. These are the genealogies of Zorathites. 

#### 1 Chronicles 4:3 And these were the sons of Etam -- Jezreel, and Ishma, and Idbash; and the name of their sister -- Hazelelponi. 

#### 1 Chronicles 4:4 And Penuel was the father of Gedor, and Ezer was the father of Husha. These are the sons of Hur first-born of Ephratah father of Beth-lehem. 

#### 1 Chronicles 4:5 And to Ashur father of Tekoe were two wives -- Helah and Naarah. 

#### 1 Chronicles 4:6 And {bore to him Naarah} Ahuzam, and Hepher, and Temeni, and Haahashtari. All these were sons of Naarah. 

#### 1 Chronicles 4:7 And the sons of Helah -- Zereth, and Jezoar, and Ethnan. 

#### 1 Chronicles 4:8 And Cos engendered Anub, and Zobedah, they are the families of the brother of Aharhel, the son of Harum. 

#### 1 Chronicles 4:9 And Jabez was honorable above his brothers. And his mother called his name Jabez, saying, For I gave birth in a downfall. 

#### 1 Chronicles 4:10 And Jabez called on the God of Israel, saying, If by blessing you should bless me, and multiply my borders, and {might be hand your} with me, and you would execute knowledge to not abase me. And God brought all as much as he asked for. 

#### 1 Chronicles 4:11 And Chelub brother of Shuah engendered Mehir, this one was father of Eshton. 

#### 1 Chronicles 4:12 And Eshton engendered Beth-rapha and Paseah, and Tehinnah father of Ir-nahash. These were the men of Rechah. 

#### 1 Chronicles 4:13 And the sons of Kenez -- Othniel and Seraiah. And the sons of Othniel -- Hathath. 

#### 1 Chronicles 4:14 And Meonothai engendered Ophrah. And Seraiah engendered Joab father of Ge Charashim, for they were fabricators. 

#### 1 Chronicles 4:15 And the sons of Caleb the son of Jephunneh- Iru, Elah, and Naan. And the sons of Elah -- Kenaz. 

#### 1 Chronicles 4:16 And the sons of Jehaleleel -- Ziph, and Ziphah, and Tirah, and Asareel. 

#### 1 Chronicles 4:17 And the sons of Ezra -- Jether, and Mered, and Epher, and Jalon. And Jether engendered Miriam, and Shammai, and Ishbah the father of Eshtemoa. 

#### 1 Chronicles 4:18 And his wife Jehudijah bore to him Jered father of Gedor, and Heber father of Socho, and Jekuthiel father of Zanoah. And these are the sons of Bithiah daughter of Pharaoh, which Mered took. 

#### 1 Chronicles 4:19 And the sons of his wife -- Hodiah the sister of Naham, father of Keila the Garmite, and Eshtemoa the Maachathite. 

#### 1 Chronicles 4:20 And the sons of Shimon -- Amnon, and Rinnah, the son of Hanan, and Tilon. And the sons of Ishi -- Zoheth, the sons of Zoheth. 

#### 1 Chronicles 4:21 The sons of Shelah the son of Judah were Er the father of Lecah, and Laadah the father of Mareshah, and the generations of the families of Ephradabak to the house of Ashbea, 

#### 1 Chronicles 4:22 and Jokim, and the men of Chozeba, and Joash, and Saraph; the ones who exercised authority in Moab. And they returned to Lehem. And the words {old are}. 

#### 1 Chronicles 4:23 These are the potters, the ones dwelling in Netaim and Gadera with the king in his works. They grew in strength and dwelt there. 

#### 1 Chronicles 4:24 The sons of Simeon -- Nemuel, and Jamin, Jarib, Zerah, Shaul, 

#### 1 Chronicles 4:25 Shallum his son, Mibsam his son, Mishma his son, 

#### 1 Chronicles 4:26 The sons of Mishma -- Hamuel his son, Zacchur his son, Shimei his son. 

#### 1 Chronicles 4:27 And to Shimei {sons there were sixteen}, and {daughters six}; and to his brethren there were not {sons many}. And among all their families they multiplied not as the sons of Judah. 

#### 1 Chronicles 4:28 And they dwelt in Beer-sheba and Moladah, and Hazar-shual, 

#### 1 Chronicles 4:29 and in Bilhah, and in Ezem, and in Tolad, 

#### 1 Chronicles 4:30 and in Bethuel, and in Hormah, and in Ziklag, 

#### 1 Chronicles 4:31 and in Beth-marcaboth and Hazar-susim, and in Beth-birei, and in Shaaraim. These were their cities until the reign of king David. 

#### 1 Chronicles 4:32 And their properties were Etam, and Ain, Rimmon, and Tochen, and Ashan -- {cities five}. 

#### 1 Chronicles 4:33 And all their properties round about these cities unto Baal. This is their possession, and their distribution. 

#### 1 Chronicles 4:34 And Meshobab, and Jamlech, and Joshah the son of Amaziah, 

#### 1 Chronicles 4:35 and Joel, and Jehu son of Josibiah, son of Seraiah, son of Asiel, 

#### 1 Chronicles 4:36 and Elioenai, and Jaakobah, and Jeshohaiah, and Asaiah, and Adiel, and Jesimiel, and Benaiah, 

#### 1 Chronicles 4:37 and Ziza son of Shiphi, son of Allon, son of Jedaiah, son of Shimri, son of Shemaiah -- 

#### 1 Chronicles 4:38 these are the ones going by names of the rulers in their generations; and in the houses of their families they were multiplied into a multitude. 

#### 1 Chronicles 4:39 And they went to coming into to Gerara, unto according to east of the valley, to seek pasture for their flocks. 

#### 1 Chronicles 4:40 And they found {pasture fertile and good}, and the land broadly spaced before them, and in peace and rest; for {were of the sons of Ham the ones dwelling there before}. 

#### 1 Chronicles 4:41 And {came these written by name} in the days of Hezekiah king of Judah. And they struck their tents, and the Minaians, the ones being found there, and they devoted them to consumption until this day. And they lived there instead of them, for pasture for their animals was there. 

#### 1 Chronicles 4:42 And some of them of the sons of Simeon went forth unto mount Seir -- {men five hundred}, and Pelatiah, and Neariah, and Rephaiah, and Uzziel, the sons of Ishi, their rulers. 

#### 1 Chronicles 4:43 And they struck the vestige surviving of Amalek, and they dwelt there until this day. 

#### 1 Chronicles 5:1 And the sons of Reuben the first-born of Israel -- for he was the first-born, but in the profaning the strewn bed of his father, {was given his rights of the first-born} to the sons of Joseph, son of Israel. And he did not trace descent for rights of the first-born. 

#### 1 Chronicles 5:2 For Judah was mighty in strength among his brothers, and a leader came from him, and the rights of the firstborn was to Joseph. 

#### 1 Chronicles 5:3 The sons of Reuben first-born of Israel -- Hanoch, and Pallu, Hezron, and Carmi. 

#### 1 Chronicles 5:4 The sons of Joel -- Shemaiah his son, Gog his son, Shimei his son, 

#### 1 Chronicles 5:5 Michah his son, Reaiah his son, Baal his son, 

#### 1 Chronicles 5:6 Beerah his son, whom {resettled Tiglath-pileser king of Assyria} -- he was ruler of Reuben. 

#### 1 Chronicles 5:7 And his brethren of his fatherland in their distribution according to their generations -- the ruler Jeiel, and Zechariah, 

#### 1 Chronicles 5:8 and Bela son of Azaz, son of Shema, son of Joel, he dwelt in Aroer, even unto Nebo and Baal-meon. 

#### 1 Chronicles 5:9 And {according to the east he dwelt} unto the entrance of the wilderness of the river Euphrates; for {cattle their} multiplied in land of Gilead. 

#### 1 Chronicles 5:10 And in the days of Saul they made war with the Hagarites, and they fell by their hand, and they dwelt in their tents upon all the face of the east parts of Gilead. 

#### 1 Chronicles 5:11 and the sons of Gad dwelt over against them at the land of Bashan unto Salcah. 

#### 1 Chronicles 5:12 Joel the ruler, and Shapham the second, and Jaanai was the scribe, and Shaphat in Bashan, 

#### 1 Chronicles 5:13 and their brethren according to the houses of their families -- Michael, Meshullam, and Sheba, and Jorai, and Jachan, and Zia, and Heber -- seven. 

#### 1 Chronicles 5:14 These are the sons of Abihail son of Huri, son of Jaroah, son of Gilead, son of Michael, son of Jeshishai, son of Jahdo, son of Buz, 

#### 1 Chronicles 5:15 son of Abdiel, son of Guni, ruler of the house of the families. 

#### 1 Chronicles 5:16 And they dwelt in Gilead in Bashan, and in her towns, and in in all the places round about Sharon, unto the exit. 

#### 1 Chronicles 5:17 All the traced descent in the days of Jotham king of Judah, and in the days of Jeroboam king of Israel. 

#### 1 Chronicles 5:18 The sons of Reuben and Gad and the half tribe of Manasseh, of the sons of the forces, men lifting shield and sword, and stretching the bow, and being taught war -- forty and four thousand and seven hundred and sixty, going forth unto the battle array. 

#### 1 Chronicles 5:19 And they made war with the Hagarites, and Jeturites, and Nepishites, and Nodabeans. 

#### 1 Chronicles 5:20 And they were called to aid over them, and {were delivered up into their hand the Hagarites}, and all the ones with them; for to God they yelled in the battle, and he heeded them, for they relied upon him. 

#### 1 Chronicles 5:21 And they captured their possessions; camels -- fifty thousand, and sheep -- two hundred and fifty thousand, and donkeys -- two thousand, and lives of men -- a hundred thousand. 

#### 1 Chronicles 5:22 {slain For many fell}, because {was of God the war}. And they dwelt there instead of them until the resettlement. 

#### 1 Chronicles 5:23 And the half of the tribe of Manasseh lived in the land; from Bashan unto Baal Hermon, and Senir, and mount Hermon they were multiplied. 

#### 1 Chronicles 5:24 And these were the rulers of the house of their families -- Epher, and Ishi, and Eliel, and Azriel and Jeremiah, and Hodaviah, and Jahdiel; men mighty in strength, {men famous}, rulers according to the house of their families. 

#### 1 Chronicles 5:25 And they annulled allegiance with the God of their fathers, and they committed harlotry after the gods of the peoples of the land, which God removed from in front of them. 

#### 1 Chronicles 5:26 And {roused up the God of Israel} the spirit of Pul king of the Assyrians, and the spirit of Tiglath-Pileser king of the Assyrians. And he resettled Reuben, and the Gadites, and the half tribe of Manasseh. And he led them into Halah, and Habor, and Hara, and unto the river Gozan, unto this day. 

#### 1 Chronicles 6:1 The sons of Levi -- Gershon, Kohath, and Merari. 

#### 1 Chronicles 6:2 And the sons of Kohath -- Amram, and Izhar, Hebron, and Uzziel. 

#### 1 Chronicles 6:3 And the sons of Amram -- Aaron, and Moses, also Miriam. And the sons of Aaron -- Nadab, and Abihu, Eleazar, and Ithamar. 

#### 1 Chronicles 6:4 And Eleazar engendered Phinehas, and Phinehas engendered Abishua, 

#### 1 Chronicles 6:5 Abishua engendered Bukki, Bukki engendered Uzzi, 

#### 1 Chronicles 6:6 Uzzi engendered Zerahiah, and Zerahiah engendered Meraioth, 

#### 1 Chronicles 6:7 and Maraioth engendered Amariah, and Amariah engendered Ahitub, 

#### 1 Chronicles 6:8 and Ahitub engendered Zadok, and Zadok engendered Ahimaaz, 

#### 1 Chronicles 6:9 and Ahimaaz engendered Azariah, and Azariah engendered Johanan. 

#### 1 Chronicles 6:10 and Johanan engendered Azariah -- he is Azariah who officiated as priest in the house which Solomon built in Jerusalem. 

#### 1 Chronicles 6:11 And Azariah engendered Amariah, and Amariah engendered Ahitub, 

#### 1 Chronicles 6:12 and Ahitub engendered Zadok, and Zadok engendered Shallum, 

#### 1 Chronicles 6:13 and Shallum engendered Helkiah, and Helkiah engendered Azariah, 

#### 1 Chronicles 6:14 and Azariah engendered Seraiah, and Seraiah engendered Jehozadak, 

#### 1 Chronicles 6:15 and Jehozadak went in the carrying into captivity by the LORD of Judah and Jerusalem by the hand of Nebuchadnezzar into Babylon. 

#### 1 Chronicles 6:16 The sons of Levi -- Gershon, Kohath, and Merari. 

#### 1 Chronicles 6:17 And these are the names of the sons of Gershon -- Libni and Shimei. 

#### 1 Chronicles 6:18 And the sons of Kohath -- Amram, and Izhar, Hebron, and Uzziel. 

#### 1 Chronicles 6:19 And the sons of Merari -- Mahli, and Mushi. These are the kin of Levi according to their families. 

#### 1 Chronicles 6:20 To Gershon -- Libni his son, Jahath his son, Zimmah his son, 

#### 1 Chronicles 6:21 Joah his son, Iddo his son, Zerah his son, Jeaterai his son. 

#### 1 Chronicles 6:22 The sons of Kohath -- Amminadab his son, Korah his son, Assir his son, 

#### 1 Chronicles 6:23 Elkanah his son, Ebiasaph his son, Assir his son, 

#### 1 Chronicles 6:24 Tahath his son, Uriel his son, Uzziah his son, Shaul his son. 

#### 1 Chronicles 6:25 And the sons of Elkanah -- Amasai, and Ahimoth. 

#### 1 Chronicles 6:26 Elkanah -- Elkanah his son, Zophai his son, and Nahath his son, 

#### 1 Chronicles 6:27 Eliab his son, Jeroham his son, Elkanah his son, Samuel his son. 

#### 1 Chronicles 6:28 And the sons of Samuel -- his first-born Joel, and the second Abiah. 

#### 1 Chronicles 6:29 The sons of Merari -- Mahli, Libni his son, Shimei his son, Uzza his son, 

#### 1 Chronicles 6:30 Shimea his son, Haggiah his son, Asaiah his son. 

#### 1 Chronicles 6:31 And these are whom David ordained over the hands of the ones singing in the house of the LORD, during the resting of the ark. 

#### 1 Chronicles 6:32 And they were officiating before the protection of the tent of the testimony with ode, until the building by Solomon the house of the LORD in Jerusalem. And they stood according to their ordinance, for their ministrations. 

#### 1 Chronicles 6:33 And these are the ones standing, and their sons. From the sons of Kohath -- Heman the psalm singer, son of Joel, son of Shemuel, 

#### 1 Chronicles 6:34 son of Elkanah, son of Jeroham, son of Eliel, son of Toah, 

#### 1 Chronicles 6:35 son of Zuph, son of Elkanah, son of Mahath, son of Amasai, 

#### 1 Chronicles 6:36 son of Elkanah, son of Joel, son of Azariah, son of Zephaniah, 

#### 1 Chronicles 6:37 son of Tahath, son of Assir, son of Ebiasaph, son of Korah, 

#### 1 Chronicles 6:38 son of Izhar, son of Kohath, son of Levi, son of Israel. 

#### 1 Chronicles 6:39 And his brother Asaph, the one standing at his right. Asaph son of Berachiah, son of Shimea, 

#### 1 Chronicles 6:40 son of Michael, son of Baaseiah, son of Malchiah, 

#### 1 Chronicles 6:41 son of Ethni, son of Zerah, son of Adaiah, 

#### 1 Chronicles 6:42 son of Ethan, son of Zimmah, son of Shimei, 

#### 1 Chronicles 6:43 son of Jahath, son of Gershon, son of Levi. 

#### 1 Chronicles 6:44 And the sons of Merari their brethren at the left sides -- Ethan son of Kishi, son of Abdi, son of Malluch, 

#### 1 Chronicles 6:45 son of Hashabiah, son of Amaziah son of Helkiah 

#### 1 Chronicles 6:46 son of Amzi, son of Bani, son of Shamer, 

#### 1 Chronicles 6:47 son of Mahli, son of Mushi, son of Merari, son of Levi. 

#### 1 Chronicles 6:48 And their brethren {being appointed the Levites} for all {of servitude ministrations} of the tent of the house of God. 

#### 1 Chronicles 6:49 And Aaron and his sons were for burning incense upon the altar of the whole burnt-offerings, and upon the altar of incense, for every work of the holy of holies, and to atone for Israel, according to all as much as {gave charge Moses the servant of God}. 

#### 1 Chronicles 6:50 And these are the sons of Aaron -- Eleazar his son, Phinehas his son, Abishua his son, 

#### 1 Chronicles 6:51 Bukki his son, Uzzi his son, Zerahiah his son, 

#### 1 Chronicles 6:52 Meraioth his son, Amariah his son, Ahitub his son, 

#### 1 Chronicles 6:53 Zadok his son, Ahimaaz his son. 

#### 1 Chronicles 6:54 And these are their dwelling places, in their properties, and in their borders, to the sons of Aaron, to the kin of Kohath, for {to them were the lots}. 

#### 1 Chronicles 6:55 And they gave to them Hebron in the land of Judah, and her townships round about her. 

#### 1 Chronicles 6:56 But the field of the city, and her properties they gave to Caleb son of Jephunneh. 

#### 1 Chronicles 6:57 And to the sons of Aaron they gave the cities of places of refuge -- Hebron, and Libna and her outskirts, and Jattir, and Eshtemoa and her outskirts, 

#### 1 Chronicles 6:58 and Hilen and her outskirts, and Debir and her outskirts, 

#### 1 Chronicles 6:59 and Ashan and her outskirts, and Beth-shemesh and her outskirts. 

#### 1 Chronicles 6:60 And from out of the tribe of Benjamin -- Geba and her outskirts, and Alemeth and her outskirts, and Anathoth and her outskirts. All their cities -- thirteen cities with their kin. 

#### 1 Chronicles 6:61 And to the sons of Kohath, to the ones remaining from the kin of the tribe, from out of the half tribe of Manasseh, by lot -- {cities ten}. 

#### 1 Chronicles 6:62 And to the sons of Gershon according to their kin from the tribe of Issachar, and from the tribe of Asher, and from the tribe of Naphtali, and from the tribe of Manasseh, in Bashan -- {cities thirteen}. 

#### 1 Chronicles 6:63 And to the sons of Merari according to their kin from the tribe of Reuben, and from the tribe of Gad, and from the tribe of Zebulun, by lot -- {cities ten and two}. 

#### 1 Chronicles 6:64 And {gave the sons of Israel} to the Levites the cities and their outskirts. 

#### 1 Chronicles 6:65 And they gave them by lot and from the tribe of the sons of Judah, and from the tribe of the sons of Simeon, and from the tribe of the sons of Benjamin, these cities which they call them by name. 

#### 1 Chronicles 6:66 And to the ones from the peoples of the sons of Kohath came to pass the cities of their borders from the tribe of Ephraim. 

#### 1 Chronicles 6:67 And they gave to them the cities of the place of refuge -- Shechem and her outskirts in mount Ephraim, and Gezer and her outskirts, 

#### 1 Chronicles 6:68 and Jokmeam and her outskirts, and Beth-horon and her outskirts, 

#### 1 Chronicles 6:69 and Aijalon and her outskirts, and Gath-rimmon and her outskirts. 

#### 1 Chronicles 6:70 And from the half tribe of Manasseh -- Aner and her outskirts, and Bileam and her outskirts, to the kin of the sons of Kohath, to the ones remaining. 

#### 1 Chronicles 6:71 To the sons of Gershon, were given out from the kin of the half tribe of Manasseh -- Golan of Bashan and her outskirts, and Ashtaroth and her outskirts. 

#### 1 Chronicles 6:72 And from the tribe of Issachar -- Kedesh and her outskirts, and Daberath and her outskirts, 

#### 1 Chronicles 6:73 and Ramoth and her outskirts, and Anem and her outskirts. 

#### 1 Chronicles 6:74 And from the tribe of Asher -- Mashal and her outskirts, and Abdon and her outskirts, 

#### 1 Chronicles 6:75 and Hukok and her outskirts, and Rehob and her outskirts. 

#### 1 Chronicles 6:76 And from the tribe of Naphtali -- Kedesh in Galilee and her outskirts, and Hammon and her outskirts, and Kirjathaim and her outskirts. 

#### 1 Chronicles 6:77 And to the sons of Merari, to the ones remaining -- were given out from the tribe of Zebulun -- Rimmon and her outskirts, and Tabor and her outskirts. 

#### 1 Chronicles 6:78 And of the other side of the Jordan by Jericho, according to the east of the Jordan, were given out from the tribe of Reuben -- Bezer in the wilderness and her outskirts, and Jahzah and her outskirts, 

#### 1 Chronicles 6:79 and Kedemoth and her outskirts, and Mephaath and her outskirts. 

#### 1 Chronicles 6:80 And from the tribe of Gad -- Ramoth in Gilead and her outskirts, and Mahanaim and her outskirts, 

#### 1 Chronicles 6:81 and Heshbon and her outskirts, and Jazer and her outskirts. 

#### 1 Chronicles 7:1 And to the sons of Issachar -- Tola, and Phua, Jashub, and Shimron -- four. 

#### 1 Chronicles 7:2 And the sons of Tola -- Uzzi, and Raphaiah, and Jeriel, and Jahmai, and Jibsam, and Shemuel, rulers according to the house of their families. To Tola were mighty ones in strength according to their generations; their number in the days of David -- twenty and two thousand and six hundred. 

#### 1 Chronicles 7:3 And the sons of Uzzi -- Izrahiah; and the sons of Iezraiah -- Michael, Obadiah, and Joel, and Ishiah -- {five are rulers all these}. 

#### 1 Chronicles 7:4 And with them according to their generations, according to the house of their families, {armed bands strong} to deploy for war -- thirty and six thousand; for they multiplied wives and sons. 

#### 1 Chronicles 7:5 And their brethren among all the kin of Issachar were mighty in power -- eighty and seven thousand {their genealogy of all}. 

#### 1 Chronicles 7:6 The sons of Benjamin -- Bela, and Becher, and Jediael -- three. 

#### 1 Chronicles 7:7 And the sons of Bela -- Ezbon, and Uzzi, and Uzziel, and Jerimoth, and Iri -- five rulers of the houses of their families, strong ones in power; and their genealogy -- twenty two thousand and thirty-four. 

#### 1 Chronicles 7:8 And the sons of Becher -- Zemira, and Joash, and Eliezer, and Elioenai, and Omri, and Jerimoth, and Abiah, and Anathoth, and Alameth -- all these were sons of Becher. 

#### 1 Chronicles 7:9 And their genealogy according to their generations, rulers of the houses of their families, mighty ones of strength -- twenty thousand and two hundred. 

#### 1 Chronicles 7:10 And the sons of Jediael -- Bilhan, and the sons of Bilhan -- Jeush, and Benjamin, and Ehud, and Chenaanah, and Zethan, and Tharshish, and Ahishahar. 

#### 1 Chronicles 7:11 All these were sons of Jediael, rulers of the families, mighty ones of strength -- seventeen thousand and two hundred going forth in power to wage war. 

#### 1 Chronicles 7:12 And Shuppim, and Huppim, and the sons of Ir and Hushim, sons Aher. 

#### 1 Chronicles 7:13 The sons of Naphtali -- Jahziel, Guni, and Jezer, and Shallum, the sons of Bilhah. 

#### 1 Chronicles 7:14 The sons of Manasseh -- Ashriel whom {bore concubine his Syrian} Machir father of Gilead. 

#### 1 Chronicles 7:15 And Machir took a wife for Huppim and for Shuppim. And the name to their sister was Maachah. And the name to the second was Zelophehad. And {were born to Zelophehad daughters}. 

#### 1 Chronicles 7:16 And {bore Maachah the wife of Machir} a son, and she called his name Peresh; and the name given to his brother was Sheresh; and his sons -- Ulam and Rakem. 

#### 1 Chronicles 7:17 And the sons of Ulam -- Bedan. These are the sons of Gilead, son of Machir, son of Manasseh. 

#### 1 Chronicles 7:18 And his sister Hammoleketh bore Ishod, and Abiezer, and Mahalah. 

#### 1 Chronicles 7:19 And {were the sons of Shemida} Ahian, and Shechem, and Likhi, and Aniam. 

#### 1 Chronicles 7:20 And the sons of Ephraim -- Shuthelah, and Bered his son, and Tahath his son, Eladah his son, and Tahath his son, 

#### 1 Chronicles 7:21 and Zabad his son, and Shuthelah his son, and Ezer, and Elead. And {killed them the men of Gath born in the land}, because they went down to take their cattle. 

#### 1 Chronicles 7:22 And {mourned Ephraim their father days many}, and {came his brethren} to comfort him. 

#### 1 Chronicles 7:23 And he entered unto his wife, and she conceived and bore a son, and called his name Beriah, for bad things happened in his house, 

#### 1 Chronicles 7:24 And his daughter was Sherah. And she built Beth-horon -- the lower part, and the upper part, and Uzzen-sherah, 

#### 1 Chronicles 7:25 and Rephah his son, and Resheph his son, and Telah his son, Tahan his son, 

#### 1 Chronicles 7:26 and Laadan his son, Ammihud his son, Elishama his son, 

#### 1 Chronicles 7:27 Non his son, Jehoshuah his son. 

#### 1 Chronicles 7:28 And their possession and dwelling was Beth-el and her towns, and to the east Naaran, and to the west Gezer and her towns, and Shechem and her towns unto Gaza and her towns. 

#### 1 Chronicles 7:29 And unto the borders of the sons of Manasseh -- Beth-shean and her towns, Taanach and her towns, Magiddo and her towns, Dor and her towns. In these dwelt the sons of Joseph, son of Israel. 

#### 1 Chronicles 7:30 The sons of Asher -- Imnah, and Ishuah, and Ishuai, and Beriah, and Serah their sister. 

#### 1 Chronicles 7:31 And the sons of Beriah -- Heber and Malchiel -- he is father of Birzavith. 

#### 1 Chronicles 7:32 And Heber engendered Japhlet, and Shomer, and Hotham, and Shua their sister. 

#### 1 Chronicles 7:33 And the sons of Japhlet -- Pasach, and Bimhal, and Ashvath. These are the sons of Japhlet. 

#### 1 Chronicles 7:34 And the sons of Shamer -- Ahi, and Rohgah, and Jehubbah, and Aram. 

#### 1 Chronicles 7:35 And the sons of Helem his brother -- Zophah, and Imna, and Shelesh, and Amal. 

#### 1 Chronicles 7:36 The sons of Zophah -- Suah, and Harnepher, and Shual, and Beri, and Imrah, 

#### 1 Chronicles 7:37 Bezer, and Hod, and Shamma, and Shilshah, and Ithran, and Beera. 

#### 1 Chronicles 7:38 And the sons of Jether -- Jephunneh, and Pispah, and Ara. 

#### 1 Chronicles 7:39 And the sons of Ulla -- Arah, Haniel, and Rizia. 

#### 1 Chronicles 7:40 All these were sons of Asher, rulers of the house of the families, choice men, strong men in power, heads of the rulers of the ones tracing descent among the position in the battle, their number {men was twenty-six thousand}. 

#### 1 Chronicles 8:1 And Benjamin engendered Bela his first-born, and Ashbel the second, Aharah the third, 

#### 1 Chronicles 8:2 Nohah the fourth, and Rapha the fifth. 

#### 1 Chronicles 8:3 And {were the sons to Bela} -- Addar, and Gera, and Abihud, 

#### 1 Chronicles 8:4 and Abishua, and Naaman, and Ahoah, 

#### 1 Chronicles 8:5 and Gera, and Shephuphan, and Huram. 

#### 1 Chronicles 8:6 These are the sons of Ehud. These are rulers of the families to the ones dwelling in Geba, and they resettled them to Manahath. 

#### 1 Chronicles 8:7 And Naaman, and Ahiah, and Gera, he resettled them. And he engendered Uzza and Ahihud. 

#### 1 Chronicles 8:8 And Shaharaim engendered in the plain of Moab, after the ejecting them by him. Hushim and Baara were his wives. 

#### 1 Chronicles 8:9 And he engendered from Hodesh his wife -- Jobab, and Zibia, and Mesha, and Malcham, 

#### 1 Chronicles 8:10 and Jeuz, and Shachia, and Mirma. These were his sons, rulers of the families. 

#### 1 Chronicles 8:11 And by Hushim he engendered Abitub, and Elpaal. 

#### 1 Chronicles 8:12 And the sons of Elpaal -- Eber, and Misham, and Shamed who built Ono, and Lod and her towns; 

#### 1 Chronicles 8:13 and Beriah and Shema, these are rulers of the families of the ones dwelling in Aijalon; these drove out the ones dwelling Gath. 

#### 1 Chronicles 8:14 And their brothers Shashak and Jeremoth, 

#### 1 Chronicles 8:15 and Zebadiah, and Arad, and Ader, 

#### 1 Chronicles 8:16 and Michael, and Ispah, and Joha, sons of Beriah. 

#### 1 Chronicles 8:17 And Zebadiah, and Meshullam, and Hezeki, and Heber, 

#### 1 Chronicles 8:18 and Ishmerai, and Jezliah, and Jobab, sons of Elpaal. 

#### 1 Chronicles 8:19 And Jakim, and Zichri, and Zabdi, 

#### 1 Chronicles 8:20 and Elienai, and Zilthai, and Eliel, 

#### 1 Chronicles 8:21 and Adaiah, and Beraiah, and Shimrath, sons of Shimhi. 

#### 1 Chronicles 8:22 And Ishpan, and Heber, and Eliel, 

#### 1 Chronicles 8:23 and Abdon, and Zichri, and Hanan, 

#### 1 Chronicles 8:24 and Hananiah, and Elam, and Antothijah, 

#### 1 Chronicles 8:25 and Iphdeiah, and Penuel sons of Shashak. 

#### 1 Chronicles 8:26 And Shamsherai, and Shehariah, and Athaliah, 

#### 1 Chronicles 8:27 and Jaresiah, and Eliah, and Zichri, sons of Jeroham. 

#### 1 Chronicles 8:28 These were rulers of the families according to their generations -- chiefs; these dwelt in Jerusalem. 

#### 1 Chronicles 8:29 And in Gibeon dwelt the father of Gibeon, and the name of his wife was Maachah. 

#### 1 Chronicles 8:30 And his son the first-born was Abdon, and Zur, and Kish, and Baal, and Nadab, 

#### 1 Chronicles 8:31 and Gedor, and his brethren, and Zacher. 

#### 1 Chronicles 8:32 And Mikloth engendered Shimeah. For also these {over against their brethren dwelt} in Jerusalem, with their brethren. 

#### 1 Chronicles 8:33 And Ner engendered Kish, and Kish engendered Saul, and Saul engendered Jonathan, and Malchishua, and Abinadab, and Esh-baal. 

#### 1 Chronicles 8:34 And the son of Jonathan was Merib-baal; and Merib-baal engendered Micah. 

#### 1 Chronicles 8:35 And the sons of Michah -- Pithon, and Melech, and Tarea, and Ahaz. 

#### 1 Chronicles 8:36 And Ahaz engendered Jehoadah; and Jehoadah engendered Alemeth, and Azmaveth, and Zimri; and Zimri engendered Moza; 

#### 1 Chronicles 8:37 and Moza engendered Binea, Rapha his son, Eleasah his son, and Azel his son. 

#### 1 Chronicles 8:38 And to Azel were six sons, and these are their names -- Azrikam his first-born, and Ishmael, and Shearaiah, and Obadiah, and Hanan and Asa; all these were sons of Azel. 

#### 1 Chronicles 8:39 And the sons of Eshek his brother -- Ulam his first-born, and Jeush the second, and Eliphelet the third. 

#### 1 Chronicles 8:40 And {were the sons of Ulam men mighty} in strength, stretching the bow, and multiplying sons, and sons of the sons -- a hundred and fifty; all these the sons of Benjamin. 

#### 1 Chronicles 9:1 And all Israel traced descent; and behold, they are written upon the scroll of the kings of Israel and Judah, and they were resettled in Babylon because of their breach-of-contract which they transgressed. 

#### 1 Chronicles 9:2 And the ones dwelling prior in their possessions in their cities -- Israel, the priests, the Levites, and the ones appointed. 

#### 1 Chronicles 9:3 And in Jerusalem dwelt of the sons of Judah, and of the sons of Benjamin, and of the sons of Ephraim, and Manasseh; 

#### 1 Chronicles 9:4 Uthai son of Ammihud, son of Omri, son of Imri, son of Bani, of the sons of Pharez son of Judah. 

#### 1 Chronicles 9:5 And of the Shilonites -- Asaiah his first-born, and his sons. 

#### 1 Chronicles 9:6 And of the sons of Zerah -- Jeuel, and their brethren -- six hundred and ninety. 

#### 1 Chronicles 9:7 And of the sons of Benjamin -- Sallu son of Meshullam, son of Hodaviah, son of Hasenuah, 

#### 1 Chronicles 9:8 and Ibneiah son of Jeroham, and Elah son of Uzzi, son of Michri, and Meshullam son of Shephatiah, son of Reuel, son of Ibnijah; 

#### 1 Chronicles 9:9 and their brethren according to their generations -- nine hundred fifty-six. All the men, rulers of families, according to the house of their families. 

#### 1 Chronicles 9:10 And of the priests -- Jedaiah, and Jehoiarib, and Jachin, 

#### 1 Chronicles 9:11 and Azariah son of Hilkiah, son of Meshullam, son of Zadok, son of Meraioth, son of Ahitub, the ruler of the house of God. 

#### 1 Chronicles 9:12 And Adaiah son of Jeroham, son of Pashur, son of Malchijah, and Massai son of Adiel, son of Jahzerah, son of Meshullam, son of Meshillemith, son of Immer. 

#### 1 Chronicles 9:13 And their brethren, leaders according to the house of their families -- a thousand and seven hundred and sixty; mighty in strength in work of the service of the house of God. 

#### 1 Chronicles 9:14 And of the Levites -- Shemaiah son of Hashub, son of Azrikam, son of Hashabiah, of the sons of Merari; 

#### 1 Chronicles 9:15 and Bakbakkar, and Heresh, and Galal, and Mattaniah son of Micah, son of Zichri, son of Asaph; 

#### 1 Chronicles 9:16 and Obadiah son of Shemiah, son of Galal, son of Jeduthun, and Berechiah son of Asa, son of Elkanah, the one dwelling in the courtyards of the Netophathites. 

#### 1 Chronicles 9:17 And the gatekeepers -- Shallum, and Akkub, and Talmon, and Ahiman, and their brethren. Shallum was the ruler. 

#### 1 Chronicles 9:18 And unto here in the gate of the king according to the east, these are the gatekeepers for the camps of the sons of Levi. 

#### 1 Chronicles 9:19 And Shallum son of Kore, son of Ebiasaph, son of Korah, and his brethren according to the house of their fathers, the Korahites, over the works of the service, guarding the thresholds of the tent, and their fathers over the camp of the LORD guarding the entrance. 

#### 1 Chronicles 9:20 And Phinehas son of Eleazar being the leader was over them before the LORD. 

#### 1 Chronicles 9:21 And with these Zachariah son of Meshellemiah was gatekeeper of the door of the tent of the testimony. 

#### 1 Chronicles 9:22 All these being chosen for gatekeepers at the doorposts -- two hundred and twelve. These with their properties of their genealogy and their distribution, these were counted. And {established them David and Samuel the seer} in their trust. 

#### 1 Chronicles 9:23 And these their sons were over the gates of the house of the LORD, and the house of the tent to keep watch. 

#### 1 Chronicles 9:24 {according to the four winds were stationed The gatekeepers} -- according to the east, and according to the west, and north, and south. 

#### 1 Chronicles 9:25 And their brethren in their properties were to come for the sevenths of the times to enter for seven days from time to time after these. 

#### 1 Chronicles 9:26 For in trust of office are the four mighty ones of the gatekeepers -- they the Levites. And they were over the cubicles, and over the treasures of the house of God. 

#### 1 Chronicles 9:27 And {surrounding the house of God they shall lodge}, for upon them was their watch responsibility, and they were over the keys morning by morning, to open the doors of the temple. 

#### 1 Chronicles 9:28 And some of them were over the equipment of the ministration, for by count they carry them in, and by count they bring them forth. 

#### 1 Chronicles 9:29 And some of them were placed over the equipment, and over all {items the holy}, and over the fine flour, and the wine, and the oil, and the frankincense, and the aromatics. 

#### 1 Chronicles 9:30 And some of the sons of the priests were perfumers of the perfume with the aromatics. 

#### 1 Chronicles 9:31 And Mattithiah of the Levites -- this one was the first-born to Shallum the Korahthite -- he was in trust over the works of the sacrifice of the pan. 

#### 1 Chronicles 9:32 And Benaiah the Kohathite from their brethren was over the bread loaves of the place setting, of the one being prepared Sabbath by Sabbath. 

#### 1 Chronicles 9:33 And these are the psalm singers, rulers of the families of the Levites, in the cubicle being set in order for daily rotations, for day and night, for them to do the works. 

#### 1 Chronicles 9:34 These are rulers of the families of the Levites, according to their generations; these rulers dwelt in Jerusalem. 

#### 1 Chronicles 9:35 And in Gibeon dwelt {father of Gibeon Jehiel}, and the name to his wife was Maachah. 

#### 1 Chronicles 9:36 And his son, the first-born, was Abadon, and Zur, and Kish, and Baal, and Ner, and Nadab, 

#### 1 Chronicles 9:37 and Gedor, and his brethren, and Zechariah, and Mikloth. 

#### 1 Chronicles 9:38 And Mikloth engendered Shimeam. And these {in the midst of their brethren dwelt} in Jerusalem, with their brethren. 

#### 1 Chronicles 9:39 And Ner engendered Kish, and Kish engendered Saul, and Saul engendered Jonathan, and Malchishua, and Abinadab, and Esh-baal. 

#### 1 Chronicles 9:40 And the son of Jonathan was Merib-baal, and Merib-baal engendered Micah. 

#### 1 Chronicles 9:41 And the sons of Micah -- Pithon, and Melech, and Tahrea, and Ahaz. 

#### 1 Chronicles 9:42 And Ahaz engendered Jarah; and Jarah engendered Alemeth, and Azmaveth, and Zimri; and Zimri engendered Moza; 

#### 1 Chronicles 9:43 and Moza engendered Baana, Raphaiah his son, Eleasah his son, Azel his son. 

#### 1 Chronicles 9:44 And to Azel were six sons, and these are their names -- Azrikam his first-born, and Ishmael, and Sheariah, and Obadiah, and Hanan. These are the sons of Azel. 

#### 1 Chronicles 10:1 And the Philistines waged war against Israel; and {fled every man of Israel} from the face of the Philistines, and they fell slain in mount Gilboa. 

#### 1 Chronicles 10:2 And {pursued the Philistines} after Saul, and after his sons; and {struck the Philistines} Jonathan, and Abinadab, and Malchi-shua, sons of Saul. 

#### 1 Chronicles 10:3 And {pressed the battle} against Saul, and {found him the bowmen} with the bows, and he was in miseries and suffering pain from the bows. 

#### 1 Chronicles 10:4 And Saul said to the one carrying his weapons, Unsheathe your broadsword, and stab me with it! lest at any time {come uncircumcised these} and mock me. But {would not the one carrying his weapons}, for he feared exceedingly. And Saul took the broadsword, and fell upon it. 

#### 1 Chronicles 10:5 And {beheld the one carrying his weapons} that Saul died, and he fell also himself upon his broadsword, and died. 

#### 1 Chronicles 10:6 And Saul died, and {three sons his}; and all his house {in one accord died}. 

#### 1 Chronicles 10:7 And {beheld every man of Israel in the valley} that Israel fled, and that Saul died and his sons, and they left their cities and fled. And {came the Philistines} and dwelt in them. 

#### 1 Chronicles 10:8 And it came to pass in the next day {came the Philistines} to despoil the slain, and they found Saul and his sons having fallen on mount Gilboa. 

#### 1 Chronicles 10:9 And they stripped him, and they carried away his head, and his weapons. And {sent the Philistines} to the land round about to announce good news in the houses of their idols, and to their people. 

#### 1 Chronicles 10:10 And they put his weapons in the house of their god, and his head they pinned in the house of Dagon. 

#### 1 Chronicles 10:11 And {heard all the ones dwelling in Jabesh Gilead} all what {did the Philistines} to Saul and to his sons, and to Israel. 

#### 1 Chronicles 10:12 And {rose up from out of Gilead every man mighty}, and they came and took the body of Saul, and the bodies of his sons, and they brought them into Jabesh, and they entombed their bones under the oak in Jabesh, and they fasted seven days. 

#### 1 Chronicles 10:13 And Saul died in his lawless deeds which he acted lawlessly against the LORD, against the word of the LORD, because he did not keep it, and because he asked {by the one who delivers oracles to inquire}. 

#### 1 Chronicles 10:14 And he did not inquire in the LORD; and he killed him, and he turned the kingdom to David son of Jesse. 

#### 1 Chronicles 11:1 And {gathered together every man of Israel} to David in Hebron, saying, Behold, {of your bones and of your flesh we are}. 

#### 1 Chronicles 11:2 And indeed yesterday and indeed the third day before in Saul being king, you were the one bringing in and leading out Israel. And {said the LORD your God} to you, You tend my people Israel, and you shall be for leader over my people Israel. 

#### 1 Chronicles 11:3 And {came all the elders of Israel} to the king in Hebron. And {ordained with them king David} a covenant in Hebron before the LORD. And they anointed David for king over Israel, according to the word of the LORD through the hand of Samuel. 

#### 1 Chronicles 11:4 And {went king David and all Israel} into Jerusalem -- this is Jebus. And {were there the Jebusites}, the ones dwelling the land 

#### 1 Chronicles 11:5 And {said the ones dwelling Jebus} to David, You shall not enter here. And {was first to take David} the citadel of Zion -- this is the city of David. 

#### 1 Chronicles 11:6 And David said, Anyone beating the Jebusites at first, he will be as a ruler and as commandant. And {ascended against them Joab son of Zeruiah} at first, and he became as a ruler. 

#### 1 Chronicles 11:7 And David stayed in the citadel; because of this he called it, City of David. 

#### 1 Chronicles 11:8 And he built the city round about from the Akra and unto the circuit. And Joab procured the rest of the city. 

#### 1 Chronicles 11:9 And David went going and being magnified. And the LORD almighty was with him. 

#### 1 Chronicles 11:10 And these are the rulers of the mighty ones, the ones who were with David, the ones growing strong with him in his kingdom with all Israel, to give him reign, according to the word of the LORD over Israel. 

#### 1 Chronicles 11:11 And this is the number of the mighty ones of David -- Jashobeam son of a Hachmonite, first of the thirty; this one unsheathed his broadsword upon three hundred slain at {time one}. 

#### 1 Chronicles 11:12 And after him -- Eleazar son of Dodo the Ahohite -- this one was among the three mighty ones. 

#### 1 Chronicles 11:13 This one was with David in Pas-dammin, and the Philistines were gathered together there for war, and there was a portion of a field full of barley, and the people fled from the face of the Philistines. 

#### 1 Chronicles 11:14 And he stood in the midst of the portion and, delivered it, and he struck the Philistines. And the LORD performed {deliverance a great}. 

#### 1 Chronicles 11:15 And there went down three of the thirty rulers to the rock to David, into the cave of Adullam; and the camp of the Philistines pitched in the valley of the giants. 

#### 1 Chronicles 11:16 And David was then in the citadel, and the garrison of the Philistines was then in Beth-lehem. 

#### 1 Chronicles 11:17 And David desired, and he said, Who will give me a drink of water from the well at Beth-lehem, the one at the gate? 

#### 1 Chronicles 11:18 And {tore up the three} the camp of the Philistines, and they drew water from the well of Beth-lehem, which was at the gate, and they took it, and came to David. And {did not want David} to drink it. And he gave it as a libation to the LORD, 

#### 1 Chronicles 11:19 and he said, Kindness to me, O God, to do this thing. Shall {blood of these men I drink} with their lives, no. For with their lives they brought it, and I do not want to drink it. These things {did the three mighty men}. 

#### 1 Chronicles 11:20 And Abishai the brother of Joab, this one was ruler of the three. This one unsheathed his broadsword against three hundred slain at {time one}; this one was famous among the other three. 

#### 1 Chronicles 11:21 Of the three {above the two he was more honorable}, and he became to them as a ruler, but unto the first three he arrived not at. 

#### 1 Chronicles 11:22 And Benaiah, son of Jehoiada son {man of a mighty} (many were his works) from Kabzeel; he struck the two lion-like ones of Moab; also this one went down and struck the lion in the pit in the day of snow. 

#### 1 Chronicles 11:23 And this one struck the Egyptian man, a man {tall five cubits}; and in the hand of the Egyptian was a spear as the beam of a loom of one weaving. And {went against him Benaiah} with a rod, and removed the spear from the hand of the Egyptian, and he killed him by his spear. 

#### 1 Chronicles 11:24 These things {did Benaiah son of Jehoiada}. And to this one was a name among the three mighty ones. 

#### 1 Chronicles 11:25 {above the thirty was honored He}, but to the first three he did not arrive. And {placed him David} over his family. 

#### 1 Chronicles 11:26 And the mighty ones of power -- Asahel brother of Joab, Elhanan son of Dodo from Beth-lehem, 

#### 1 Chronicles 11:27 Shammoth the Harorite, Helez the Pelonite, 

#### 1 Chronicles 11:28 Ira son of Ikkesh the Tekoite, Abi-ezer the Antothite, 

#### 1 Chronicles 11:29 Sibbecai the Hushathite, Ilai the Ahohite, 

#### 1 Chronicles 11:30 Maharai the Netophathite, Heled son of Baanah the Netophathite, 

#### 1 Chronicles 11:31 Ithai son of Ribai of Gibeah of the sons of Benjamin, Benaiah the Pirathonite, 

#### 1 Chronicles 11:32 Hurai from Nachali Gaash, Abiel the Arbathite, 

#### 1 Chronicles 11:33 Azmaveth the Baharumite, Eliahba the Shaalbonite, 

#### 1 Chronicles 11:34 sons of Hashem the Gizonite, Jonathan son of Shage the Hararite, 

#### 1 Chronicles 11:35 Ahiam son of Sacar the Hararite, Eliphal son of Ur, 

#### 1 Chronicles 11:36 Hepher the Mecherathite, Ahijah the Pelonite, 

#### 1 Chronicles 11:37 Hezro the Carmelite, Naarai the son of Ezbai, 

#### 1 Chronicles 11:38 Joel brother of Nathan, Mibhar son of Haggeri, 

#### 1 Chronicles 11:39 Zelek the Ammonite, Naarai the Berothite, one carrying the weapons of Joab son of Zeruiah, 

#### 1 Chronicles 11:40 Ira the Ithrite, Gareb the Ithrite, 

#### 1 Chronicles 11:41 Uriah the Hittite, Zabad son of Ahlai, 

#### 1 Chronicles 11:42 Adina son of Shiza the Reubenite, ruler to Reuben, and with him thirty. 

#### 1 Chronicles 11:43 Hanan son of Maachah, and Joshaphat the Mithnite, 

#### 1 Chronicles 11:44 Uzzia the Asterathite, Shama and Jehiel sons of Hothan the Aroerite, 

#### 1 Chronicles 11:45 Jediael son of Shimri, and Joha his brother, the Tizite, 

#### 1 Chronicles 11:46 Eliel the Mahavite, and Jeribai and Joshaviah the sons of Elnaam, and Ithma the Moabite, 

#### 1 Chronicles 11:47 Eliel, and Obed, and Jasiel the Mesobaite. 

#### 1 Chronicles 12:1 And these are the ones coming to David in Ziglag, while banding together from the face of Saul son of Kish. And they are among the mighty ones helping in war, 

#### 1 Chronicles 12:2 and using the bow with the right hands and with the left hands, and slingers with stones, and with arrows, and with a bow from the brethren of Saul of Benjamin. 

#### 1 Chronicles 12:3 The ruler was Ahiezer, and Joash, the sons of Shemaah the Gibeathite, and Jeziel and Pelet sons of Azmaveth, and Berachah, and Jehu the Antothite, 

#### 1 Chronicles 12:4 and Ishmaiah the Gibeonite, mighty among the thirty, and over the thirty; Jeremiah, and Jahaziel, and Johanan, and Josabad the Gederathite; 

#### 1 Chronicles 12:5 Eluzai, and Jerimoth, and Baaliah, and Shemariah, and Shephatiah the Haruphite; 

#### 1 Chronicles 12:6 Elkanah, and Jessiah, and Azareel, and Joezer, and Jashobeam, the Korhites, 

#### 1 Chronicles 12:7 and Joelah, and Zebadiah sons of Jeroham, sons of Gedor. 

#### 1 Chronicles 12:8 And of the Gadites these separated to David into the wilderness, mighty strong men for war, deploying shield and spear, and {were as faces of lions their faces}, and they were light as does upon the mountains going quickly. 

#### 1 Chronicles 12:9 Ezer the ruler, Obadiah the second, Eliab the third, 

#### 1 Chronicles 12:10 Mishmannah the fourth, Jeremiah the fifth, 

#### 1 Chronicles 12:11 Attai the sixth, Eliel the seventh, 

#### 1 Chronicles 12:12 Johanan the eighth, Elzabad the ninth, 

#### 1 Chronicles 12:13 Jeremiah the tenth, Machbanai the eleventh. 

#### 1 Chronicles 12:14 These were of the sons of Gad, rulers of the military, one to a hundred -- the small, and the great a thousand. 

#### 1 Chronicles 12:15 These are the ones passing over the Jordan in the {month first}, and it was filled over all its bank. And they drove out all the ones dwelling in the canyons to the east, and to the west. 

#### 1 Chronicles 12:16 And there came of the sons of Benjamin and Judah to help David. 

#### 1 Chronicles 12:17 And David came forth to meet them, and he answered and said to them, If in peace you have come to me to help me, may it be to me a heart with you for uniting. But if to deliver me up to my enemies, not in truth of hand, may {see it the God of our fathers} and reprove. 

#### 1 Chronicles 12:18 And spirit clothed Amasai ruler of the thirty, and he said, Go, David son of Jesse, you and your people, in peace! Peace to you, and peace to your helpers; for {helped you your God}. And {favorably received them David}, and he placed them as rulers of the forces. 

#### 1 Chronicles 12:19 And some from Manasseh joined with David in the coming of the Philistines against Saul for war. And {did not help them David}, for in counsel it came to pass from the commandants of the Philistines, saying, With our heads he will return to his master Saul. 

#### 1 Chronicles 12:20 And they sent him away. And in {going David} to Ziklag, some joined with him from Manasseh -- Adnah, and Jozabad, and Jediael, and Michael, and Jozabad, and Elihu, and Zilthai -- chiefs of thousands of Manasseh. 

#### 1 Chronicles 12:21 And they fought along with David against the troop, for {mighty in strength were all they}, and they were leaders in the military in the force. 

#### 1 Chronicles 12:22 For at a time day by day they came to David to help him, as for {camp a great}, as the camp of God. 

#### 1 Chronicles 12:23 And these are the names of the rulers of the military, of the ones coming to David in Hebron, to turn the kingdom of Saul to him, according to the word of the LORD. 

#### 1 Chronicles 12:24 Sons of Judah, bearing an oblong shield and spear -- six thousand and eight hundred mighty ones for battle array. 

#### 1 Chronicles 12:25 Of the sons of Simeon, mighty ones in strength for battle array -- seven thousand and a hundred. 

#### 1 Chronicles 12:26 Of the sons of Levi -- four thousand and six hundred. 

#### 1 Chronicles 12:27 And Jehoiada the leader to Aaron, and with him -- three thousand and seven hundred. 

#### 1 Chronicles 12:28 And Zadok, a young man, mighty in strength, and of the house of his father were twenty and two rulers. 

#### 1 Chronicles 12:29 And from the sons of Benjamin, of the brethren of Saul -- three thousand. And yet most of them kept the guard of the house of Saul. 

#### 1 Chronicles 12:30 And of the sons of Ephraim -- twenty thousand and eight hundred mighty in strength, {men famous}, according to the houses of their families. 

#### 1 Chronicles 12:31 And of the half tribe of Manasseh -- eighteen thousand, the ones being named by name to come to give reign to David. 

#### 1 Chronicles 12:32 And of the sons of Issachar, ones perceiving with understanding concerning the times, knowing what Israel shall do in their companies -- two hundred; and all their brethren with them. 

#### 1 Chronicles 12:33 And of Zebulun going forth into battle array for war with all the weapons for warfare -- fifty thousand, to help David, nor with heart and heart. 

#### 1 Chronicles 12:34 And of Naphtali {rulers a thousand}, and with them with shields and spears -- thirty and seven thousand. 

#### 1 Chronicles 12:35 And of the Danites being deployed for war -- twenty-eight thousand and six hundred. 

#### 1 Chronicles 12:36 And of Asher ones going forth to help in war -- forty thousand. 

#### 1 Chronicles 12:37 And of the other side of the Jordan of Reuben, and the Gadites, and of the half tribe of Manasseh, all with weapons for warfare in the force -- a hundred twenty thousand. 

#### 1 Chronicles 12:38 All these men were warriors being deployed in battle array. {with soul a peaceful they came} unto Hebron to give reign to David over all Israel. And the rest of Israel {soul was one} to give reign to David. 

#### 1 Chronicles 12:39 And they were there with David {days three}, eating and drinking, for {made preparations for them their brethren}. 

#### 1 Chronicles 12:40 And the ones adjoining them, near Issachar and Zebulun and Naphtali, brought to them upon the donkeys, and upon the camels, and upon the mules, and upon the calves, foods -- flour, dried clusters of figs, dried grapes, wine, and olive oil, calves, and sheep in multitude, for gladness was in Israel. 

#### 1 Chronicles 13:1 And David consulted with the rulers and the commanders of thousands, and the commanders of hundreds -- with every leader. 

#### 1 Chronicles 13:2 And David said to all the assembly of Israel, If it seems good to you, and by the LORD our God, that he should prosper the way, then we should send to our brethren being left in all the land of Israel, and {with them the priests the Levites} which are in the cities of their possession, that they shall be gathered together to us. 

#### 1 Chronicles 13:3 And we should turn the ark of our God to us, for {not we sought it} from the days of Saul. 

#### 1 Chronicles 13:4 And {said all the assembly} to do so, for {was upright the word} in the eyes of all the people. 

#### 1 Chronicles 13:5 And David assembled all Israel, from the borders of Egypt and unto the entrance of Hamath, to carry in the ark of God from the city of Jearim. 

#### 1 Chronicles 13:6 And David ascended, and all Israel into Kirjath-jearim, which is of Judah, to lead up from there the ark of the LORD God, of the one sitting upon the cherubim, of which {is called upon his name} there. 

#### 1 Chronicles 13:7 And they placed the ark of God upon {wagon a new}, from out of the house of Abinadab. And Uzza and his brethren led the wagon. 

#### 1 Chronicles 13:8 And David and all Israel were playing before God with all their ability, and with songs, and with lutes, and with stringed instruments, and with tambourines, and with cymbals, and with trumpets. 

#### 1 Chronicles 13:9 And they came unto the threshing-floor of Chidon. And Uzza stretched out his hand to hold down the ark, for {turned it the calf}. 

#### 1 Chronicles 13:10 And the LORD was enraged in anger against Uzza, and he struck him there, on account of the stretching out of his hand upon the ark. And he died there before God. 

#### 1 Chronicles 13:11 And David was depressed, that the LORD cut a severance with Uzza. And he called that place -- Severance of Oza until this day. 

#### 1 Chronicles 13:12 And David feared God in that day, saying, How shall I carry in to myself the ark of God? 

#### 1 Chronicles 13:13 And {did not return David} the ark to himself into the city of David, but he turned it aside into the house of Obed Edom the Gittite. 

#### 1 Chronicles 13:14 And {stayed the ark of God} in the household of Obed Edom in his house {months three}. And the LORD blessed the house of Obed Edom, and all of his. 

#### 1 Chronicles 14:1 And {sent Hiram king of Tyre} messengers to David, and timber of cedars, and fabricators of walls, and fabricators of woods, to build for him a house. 

#### 1 Chronicles 14:2 And David knew that {prepared him the LORD} for king over Israel, for {grew in stature his kingdom} because of his people Israel. 

#### 1 Chronicles 14:3 And David took still more wives in Jerusalem. And were born to David again sons and daughters. 

#### 1 Chronicles 14:4 And these are their names of the ones being born to him in Jerusalem -- Shammua and Shobab, Nathan, and Solomon, 

#### 1 Chronicles 14:5 and Ibhar, and Elishua, and Elpalet, 

#### 1 Chronicles 14:6 and Nogah, and Nepheg, and Japhia, 

#### 1 Chronicles 14:7 and Elishama, and Beeliada, and Eliphalet. 

#### 1 Chronicles 14:8 And {heard the Philistines} that David was anointed king over all Israel, and {ascended all the Philistines} to seek David. And David heard, and came forth to meet them. 

#### 1 Chronicles 14:9 And the Philistines came and assembled for battle in the valley of the giants. 

#### 1 Chronicles 14:10 And David asked through God, saying, Shall I ascend against the Philistines? and will you give them into my hands? And {said to him the LORD}, Ascend! and I will give them into your hands. 

#### 1 Chronicles 14:11 And he ascended into Baal Perazim. And {struck them David} there. And David said, God cut through my enemies by my hand as a severance of water. On account of this he called the name of that place -- Severance of Baal Perazim. 

#### 1 Chronicles 14:12 And {abandoned there the Philistines} their gods. And David spoke, and they were set on fire with fire. 

#### 1 Chronicles 14:13 And {proceeded yet again the Philistines}, and assembled for battle again in the valley of the giants. 

#### 1 Chronicles 14:14 And David asked again to God. And {said to him God}, Do not go after them! turn from them, and come to them near the pear trees! 

#### 1 Chronicles 14:15 And it will be in your hearing the sound of the rumbling of them in the tips of the pear trees, then you shall enter into the battle, for {went forth God} before you to strike the camp of the Philistines. 

#### 1 Chronicles 14:16 And David did as {gave charge to him God}. And he struck the camp of the Philistines from Gibeon unto Gezer. 

#### 1 Chronicles 14:17 And {went out the name of David} in all the lands; and the LORD put the fear of him upon all the nations. 

#### 1 Chronicles 15:1 And he made for himself houses in the city of David. And he prepared a place for the ark of God, and pitched for it a tent. 

#### 1 Chronicles 15:2 Then said David, No one is to lift the ark of God except the Levites; for {chose them the LORD} to lift the ark of the LORD, and to officiate to him unto the eon. 

#### 1 Chronicles 15:3 And David gathered all Israel to Jerusalem, to bear the ark of the LORD into the place which he prepared for it. 

#### 1 Chronicles 15:4 And David gathered the sons of Aaron, and the Levites. 

#### 1 Chronicles 15:5 Of the sons of Kohath; Uriel the ruler, and his brethren -- a hundred and twenty. 

#### 1 Chronicles 15:6 Of the sons of Merari; Asiah the ruler, and his brethren -- two hundred and twenty. 

#### 1 Chronicles 15:7 Of the sons of Gershon; Joel the ruler, and his brethren -- a hundred and thirty. 

#### 1 Chronicles 15:8 Of the sons of Elizaphan; Shemaiah the ruler, and his brethren -- two hundred. 

#### 1 Chronicles 15:9 Of the sons of Hebron; Eliel the ruler, and his brethren -- eighty. 

#### 1 Chronicles 15:10 Of the sons of Uzziel; Amminadab the ruler, and his brethren -- a hundred and twelve. 

#### 1 Chronicles 15:11 And David called Zadok and Abiathar the priests, and the Levites -- Uriel, Asiah, and Joel, and Shemaiah, and Eliel, and Amminadab. 

#### 1 Chronicles 15:12 And he said to them, You are the rulers of the families of the Levites. Purify yourselves and your brethren! even to bear the ark of the LORD God of Israel, of which I prepared for it. 

#### 1 Chronicles 15:13 For {were not prior you being ready}, {cut through and the LORD our God} among us, for we did not seek him in practice. 

#### 1 Chronicles 15:14 And {purified themselves the priests and the Levites} to bring the ark of the LORD God of Israel. 

#### 1 Chronicles 15:15 And {lifted the sons of the Levites} the ark of God (as Moses gave charge by the word of the LORD according to the writing) with the bearing poles on their shoulders. 

#### 1 Chronicles 15:16 And David said to the rulers of the Levites, You shall station their brethren the psalm singers with instruments for odes, with stringed instruments, lutes, and cymbals, to sound out loud on high with the voice of gladness. 

#### 1 Chronicles 15:17 And {stationed the Levites} Heman son of Joel, and of his brethren, Asaph son Berechiah; and of the sons of Merari his brethren, Ethan son of Kushaiah. 

#### 1 Chronicles 15:18 And with them their brethren the ones second ranked -- Zechariah son of Jaaziel, and Shemiramoth, and Jehiel, and Unni, and Eliab, and Benaiah, and Maaseiah, and Mattithiah, and Elipheleh, and Mikneiah, and Obed Edom, and Jeiel, the gatekeepers. 

#### 1 Chronicles 15:19 And the singers, Heman, Asaph, and Ethan, {with cymbals of brass to cause to be heard}. 

#### 1 Chronicles 15:20 And Zachariah, and Aziel, and Shimiramoth and Jehiel, and Unni, and Eliab, and Masseiah, and Benaiah, with stringed instruments upon Alamoth. 

#### 1 Chronicles 15:21 And Mattithiah, and Elipheleh, and Mikneiah, and Obed Edom, and Jeiel, and Azaziah, with lutes with octaves growing in strength. 

#### 1 Chronicles 15:22 And Chenaniah ruler of the Levites was ruler of the odes, for he was discerning. 

#### 1 Chronicles 15:23 And Berechiah and Elkanah were gatekeepers of the ark. 

#### 1 Chronicles 15:24 And Shebaniah, and Jehoshaphat, and Nethaneel, and Amasai, and Zechariah, and Benaiah, and Eliezer the priests, were trumpeting with the trumpets before the ark of God. And Obed Edom and Jehiah were gatekeepers of the ark. 

#### 1 Chronicles 15:25 And David was, and the elders of Israel, and the commanders of thousands, the ones going to bring the ark of the covenant of the LORD from out of the house of Obed Edom in gladness. 

#### 1 Chronicles 15:26 And it came to pass in the strengthening by God, of the Levites lifting the ark of the covenant of the LORD, that they sacrificed seven calves and seven rams. 

#### 1 Chronicles 15:27 And David was being girded in a robe of fine linen, and all the Levites lifting the ark of the covenant of the LORD, and the psalm singers, and Chenaniah the ruler of the odes of the ones singing. And upon David was an ephod of fine linen. 

#### 1 Chronicles 15:28 And all Israel was leading the ark of the covenant of the LORD with a cheer, and with a sound of the ram's horn, and with trumpets, and with cymbals, sounding out loud with stringed instruments, and with lutes. 

#### 1 Chronicles 15:29 And it came to pass, and {came the ark of the covenant of the LORD} unto the city of David, and Michal the daughter of Saul leaned over through the window, and she beheld king David dancing and playing; and she treated him with contempt in her soul. 

#### 1 Chronicles 16:1 And they carried in the ark of God, and fastened it in the midst of the tent, which {pitched for it David}. And they offered whole burnt-offerings and peace offerings before God. 

#### 1 Chronicles 16:2 And David completed offering the whole burnt-offerings and the peace offerings, and he blessed the people by the name of the LORD. 

#### 1 Chronicles 16:3 And he divided unto every man of Israel, from man unto woman, to every man {bread loaf one} of a baker, and honey-bread. 

#### 1 Chronicles 16:4 And he arranged in front of the ark of the covenant of the LORD certain of the Levites officiating, and sounding out loud, even to acknowledge and to give praise to the LORD God of Israel. 

#### 1 Chronicles 16:5 Asaph the ruler, and his second Zachariah, and Jeiel, and Shemiramoth, and Jehiel, and Mattithiah, and Eliab, and Benaiah, and Obed Edom, and Jeiel with instruments, with stringed instruments and lutes; and Asaph with cymbals sounding out loud. 

#### 1 Chronicles 16:6 And Benaiah and Jahaziel the priests with the trumpets sounding continually before the ark of the covenant of God. 

#### 1 Chronicles 16:7 In that day then David arranged this psalm in the beginning of the praising the LORD by the hand of Asaph and his brethren. 

#### 1 Chronicles 16:8 Acknowledge the LORD! Call upon him by his name! Make known to the peoples his practices! 

#### 1 Chronicles 16:9 Sing to him, even sing praise to him! Describe all his wonders! what the LORD did. 

#### 1 Chronicles 16:10 Give praise in {name his holy}! You shall be glad in heart seeking his good-pleasure. 

#### 1 Chronicles 16:11 Seek the LORD, and be strong! Seek his face always! 

#### 1 Chronicles 16:12 Remember his wonders! what he did; his miracles and the judgments of his mouth. 

#### 1 Chronicles 16:13 Seed of Israel his servants; sons of Jacob his chosen. 

#### 1 Chronicles 16:14 He is the LORD our God; {are in all the earth his judgments}. 

#### 1 Chronicles 16:15 Remember {into the eon his covenant}! his word which he gave charge to a thousand generations; 

#### 1 Chronicles 16:16 which he ordained with Abraham, and his oath to Isaac. 

#### 1 Chronicles 16:17 And he established it to Jacob for an order, and to Israel {covenant for an eternal}. 

#### 1 Chronicles 16:18 Saying, To you I shall give the land of Canaan, a piece of measured out land for your inheritance, 

#### 1 Chronicles 16:19 in the being of them very few in number, as few and sojourners in it. 

#### 1 Chronicles 16:20 And they went from nation to nation, and from kingdom to {people another}. 

#### 1 Chronicles 16:21 He did not allow a man to overpower them, and he reproved {on account of them kings}, 

#### 1 Chronicles 16:22 Saying, Touch not my anointed ones! and among my prophets do not do wickedly. 

#### 1 Chronicles 16:23 Sing to the LORD all the earth! announce from day to day his deliverance! 

#### 1 Chronicles 16:24 Describe among the nations his glory; to all the peoples his wonders! 

#### 1 Chronicles 16:25 For great is the LORD, and praiseworthy exceedingly. He is fearful above all the gods. 

#### 1 Chronicles 16:26 For all the gods of the nations are idols; and the LORD {the heavens made}. 

#### 1 Chronicles 16:27 Glory and high praise are before his face; strength and boasting are in {place his holy}. 

#### 1 Chronicles 16:28 Give to the LORD, O families of the nations! Give to the LORD glory and strength! 

#### 1 Chronicles 16:29 Give to the LORD glory due his name! Take sacrifices, and enter before him! And do obeisance to the LORD in {courtyards his holy}! 

#### 1 Chronicles 16:30 Fear before his face, all the earth! for even {is set up the inhabitable world}, which shall not be shaken. 

#### 1 Chronicles 16:31 Be glad O heaven, and exult O earth! And let them say among the nations! the LORD is reigning. 

#### 1 Chronicles 16:32 {shall resonate The sea} with the fullness of it; let {exult the field}, and all the things in it! 

#### 1 Chronicles 16:33 Then {shall be glad the trees of the grove} before the face of the LORD, for he comes to judge the earth. 

#### 1 Chronicles 16:34 Make acknowledgment to the LORD for good! for {into the eon his mercy}. 

#### 1 Chronicles 16:35 And say, Deliver us, O God of our deliverance! And gather us, and rescue us from out of the nations! to praise your name, the holy one; to boast in your praises. 

#### 1 Chronicles 16:36 Blessed be the LORD God of Israel from the eon and unto the eon. And {shall say all the people}, Amen. And they gave praise to the LORD. 

#### 1 Chronicles 16:37 And was left behind there before the ark of the covenant of the LORD Asaph and his brethren, to officiate before the ark continually to the matter, that of the day to its day. 

#### 1 Chronicles 16:38 And Obed Edom and his brethren -- sixty and eight. And Obed Edom son of Jeduthun and Hosah were as gatekeepers. 

#### 1 Chronicles 16:39 And Zadok the priest, and his brethren of the priests were before the tent of the LORD in Bama, the one in Gibeon, 

#### 1 Chronicles 16:40 to offer whole burnt-offerings to the LORD upon the altar of the whole burnt-offerings continually in the morning and the evening, and according to all the things being written in the law of the LORD, as much as he gave charge unto the sons of Israel. 

#### 1 Chronicles 16:41 And with them Heman and Jeduthun, and the rest, the ones being chosen by name to praise the LORD, for {is into the eon his mercy}. 

#### 1 Chronicles 16:42 And with them Heman and Jeduthun with trumpets and cymbals to sound out loud, and instruments for the odes of God. And the sons of Jeduthun were at the gate. 

#### 1 Chronicles 16:43 And {went all the people each} to his house; and David returned to bless his house. 

#### 1 Chronicles 17:1 And it came to pass as David dwelt in his house, and David said to Nathan the prophet, Behold, I dwell in a house of cedar, and the ark of the covenant of the LORD is underneath hide coverings. 

#### 1 Chronicles 17:2 And Nathan said to David, All in your soul do! for God is with you. 

#### 1 Chronicles 17:3 And it came to pass in that night, and {came the word of God} to Nathan, 

#### 1 Chronicles 17:4 You go, and say to David my servant! Thus said the LORD, You shall not build for me a house for me to dwell in it. 

#### 1 Chronicles 17:5 for I did not dwell in a house from the day which I led up Israel until this day; for I was in a tent for protection and inside the covering. 

#### 1 Chronicles 17:6 In all the places in which I went with all Israel, did in speaking I say to any one tribe of Israel, to the ones whom I gave charge to tend my people, saying, Why did you not build for me a house of cedar? 

#### 1 Chronicles 17:7 And now, thus you shall say to my servant David, Thus says the LORD of the forces, I took you from out of the haven, from following the flocks, to be as one leading over my people Israel. 

#### 1 Chronicles 17:8 And I was with you in all the places in which you went, and I utterly destroyed all your enemies from in front of you, and I made to you a name according to the name of the great ones, of the ones upon the earth. 

#### 1 Chronicles 17:9 And I shall establish a place for my people Israel, and I will plant him, and he shall encamp by himself, and he shall not be disturbed any longer; and {shall not proceed the son of iniquity} to humble him as from the beginning. 

#### 1 Chronicles 17:10 And from days which I arranged judges over my people Israel, and I humbled all your enemies, even I will increase you, and I will build to you a house, says the LORD. 

#### 1 Chronicles 17:11 And it will be whenever {should be filled your days} to go with your fathers, that I will raise up your seed after you, who will be from your belly, and I will prepare his kingdom. 

#### 1 Chronicles 17:12 He shall build for me a house, and I shall re-erect his throne unto the eon. 

#### 1 Chronicles 17:13 I will be to him as father, and he will be to me as son. And my mercy I will not remove from him, as I removed from the ones before you. 

#### 1 Chronicles 17:14 And I will stand him in my house, and with his kingdom unto the eon. And his throne will be re-erected unto the eon. 

#### 1 Chronicles 17:15 According to all these words, and according to all this vision, so spoke Nathan to David. 

#### 1 Chronicles 17:16 And {came king David} and sat before the LORD, and said, Who am I, O LORD God, and what is my house, that you loved me unto the eon? 

#### 1 Chronicles 17:17 And these things were diminished before you, O God; and you spoke about the house of your servant from a long time, and looked upon me as {vision man's}, and raised me up high, O LORD God. 

#### 1 Chronicles 17:18 How shall {proceed yet David} to you, to glorify you -- your servant? and you {your servant know}. 

#### 1 Chronicles 17:19 O LORD, on account of your servant, and according to your heart, you did all this greatness, to make known all the great things. 

#### 1 Chronicles 17:20 O LORD, there is none likened to you, and there is no God besides you, according to all as much as we heard with our ears. 

#### 1 Chronicles 17:21 And there is no {as your people Israel nation} yet upon the earth, as {guided him God} for the ransoming a people to himself, to establish to himself {name a great and apparent}, to cast out {from in front of your people of whom you ransomed out of Egypt nations}. 

#### 1 Chronicles 17:22 And you appointed your people Israel for yourself -- a people unto the eon. And you, O LORD, became to them for God. 

#### 1 Chronicles 17:23 And now, O LORD, your word which you spoke to your servant, and concerning his house, let it be trusted unto the eon, and you do as you spoke! 

#### 1 Chronicles 17:24 And let {be trusted and be magnified your name} unto the eon! saying, The LORD almighty, the God of Israel, God to Israel; and the house of David your servant being erected before you. 

#### 1 Chronicles 17:25 For you, O LORD my God, uncovered the ear of your servant, to build him a house. Because of this {found need your servant} to pray before your face. 

#### 1 Chronicles 17:26 And now, O LORD, You are he -- God, and you spoke {concerning your servant these good things}. 

#### 1 Chronicles 17:27 And now you began to bless the house of your servant, for it to be in the eon before you. For you, O LORD, blessed; and it is blessed into the eon. 

#### 1 Chronicles 18:1 And it came to pass after these things, that David struck the Philistines, and put them to flight. And he took Gath and her towns from the hand of the Philistines. 

#### 1 Chronicles 18:2 And he struck Moab; and Moab became bondservant to David, bringing gifts. 

#### 1 Chronicles 18:3 And David struck Hadarezer king of Zobah at Hamath, in his going to establish his hand over the river Euphrates. 

#### 1 Chronicles 18:4 And David first took from him a thousand chariots, and seven thousand horses, and twenty thousand men footmen. And David disabled all the chariots, and left of them a hundred chariots. 

#### 1 Chronicles 18:5 And Syria came from out of Damascus to help Hadarezer king of Zobah. And David struck among the Syrian -- twenty and two thousand men. 

#### 1 Chronicles 18:6 And David placed a detachment in Syria near Damascus. And they were to David as servants bringing gifts. And the LORD preserved David in all wherever he went. 

#### 1 Chronicles 18:7 And David took the collars of gold things which were upon the servants of Hadarezer, and brought them into Jerusalem. 

#### 1 Chronicles 18:8 And from Tibhath, and from the chosen cities of Hadarezer, David took {brass much exceedingly}. Of it Solomon made the {sea brass}, and the columns, and the items of brass. 

#### 1 Chronicles 18:9 And {heard Tou king of Hamath} that David struck all the force of Hadarezer king of Zobah. 

#### 1 Chronicles 18:10 And he sent Hadoram his son to king David to ask him the things for peace, and to congratulate him for of which he waged war against Hadarezer, and for striking him; because {man a warlike Tou was} with Hadarezer -- and all the items of gold, and of silver, and of brass. 

#### 1 Chronicles 18:11 And these {sanctified king David} to the LORD, with the silver and the gold which he took from all the nations -- from Edom, and Moab, and from the sons of Ammon, and from the Philistines, and from Amalek. 

#### 1 Chronicles 18:12 And Abishai son of Zeruiah struck the Edomite in the valley of salts -- eighteen thousand. 

#### 1 Chronicles 18:13 And he placed in Edom a detachment of soldiers. And {were all the Edomites} servants to David. And the LORD preserved David in all wherever he went. 

#### 1 Chronicles 18:14 And David reigned over all Israel, and he was executing judgment and righteousness to all his people. 

#### 1 Chronicles 18:15 And Joab son of Zeruiah was over the military; and Jehoshaphat son of Ahilud was the recorder; 

#### 1 Chronicles 18:16 and Zadok son of Ahitub, and Abimelech son of Abiathar, were priests; and Shavsha was scribe; 

#### 1 Chronicles 18:17 and Benaiah son of Jehoiada was over the Cherethite and the Phelethite; and the sons of David were the first successors of the king. 

#### 1 Chronicles 19:1 And it came to pass after these things, that {died Nahash king of the sons of Ammon}, and {reigned Hanun his son} instead of him. 

#### 1 Chronicles 19:2 And David said, I will do an act of kindness with Hanun son of Nahash, as {performed his father with me kindness}. And David sent messengers to comfort him because of his father. And {came the servants of David} into the land of the sons of Ammon to Hanun, to comfort him. 

#### 1 Chronicles 19:3 And said the rulers of the sons of Ammon to Hanun, Is David glorifying your father in your eyes, to send to you comforters? Is it not that they may search out the city, and to spy out the land {came his servants} to you? 

#### 1 Chronicles 19:4 And Hanun took the servants of David, and he shaved them, and removed their uniforms half way unto the wrapping. And he sent them away. 

#### 1 Chronicles 19:5 And others came, and they reported to David for the men. And he sent to meet them, for {were the men} disgraced exceedingly. And {said the king}, Stay in Jericho until {rise up your beards}, and return! 

#### 1 Chronicles 19:6 And {knew the sons of Ammon} that {were put to shame the people of David}. And {sent Hanun and the sons of Ammon} a thousand talents of silver to hire for themselves of Syria of Mesopotamia, and from Syria of Maachah, and from Zobah, chariots and horsemen. 

#### 1 Chronicles 19:7 And they hired for themselves two and thirty thousand chariots, and the king of Maachah and his people. And they came and camped before Medeba. And the sons of Ammon gathered together from out of their cities, and they came to wage war. 

#### 1 Chronicles 19:8 And David heard, and he sent Joab, and all the military of the forces. 

#### 1 Chronicles 19:9 And {went forth the sons of Ammon}, and deployed for war by the gatehouse of the city. And the kings, the ones coming, camped by themselves in the plain. 

#### 1 Chronicles 19:10 And Joab beheld that it happened in their facing off to wage war before him from in front and from behind, that he chose of every young man of Israel, and he deployed before Syria. 

#### 1 Chronicles 19:11 And the rest of the people he put into the hand of Abishai his brother, and they deployed right opposite the sons of Ammon. 

#### 1 Chronicles 19:12 And he said, If Syria should strengthen over me, then you will be to me for deliverance; and if the sons of Ammon should strengthen over you, then I will deliver you. 

#### 1 Chronicles 19:13 Be manly! and we shall grow in strength for our people, and for the cities of our God; and the LORD {good in his eyes shall do}. 

#### 1 Chronicles 19:14 And Joab deployed and the people with him right opposite Syria for war; and they fled from them. 

#### 1 Chronicles 19:15 And the sons of Ammon beheld that {fled the Syrians}, and they fled even themselves from in front of Abishai, and from in front of Joab his brother. And they came into the city. And Joab went to Jerusalem. 

#### 1 Chronicles 19:16 And {saw the Syrian} that {put him to flight Israel}, and he sent messengers, and they brought the Syrian from the other side of the river. And Shophach the commander-in-chief of the force of Hadarezer was in front of them. 

#### 1 Chronicles 19:17 And it was reported to David. And he gathered together all Israel, and passed over the Jordan, and came unto them, and deployed against them. And Syria deployed right opposite David for war, and they waged war with him. 

#### 1 Chronicles 19:18 And Syria fled from in front of Israel. And David killed of the Syrian seven thousand of the chariots, and forty thousand men on foot; and Shophach the commander-in-chief of the force he killed. 

#### 1 Chronicles 19:19 And {beheld the servants of Hadarezer} that they failed from in front of Israel, and they ordained with David a peace, and they served him. And {wanted not Syria} to help the sons of Ammon any longer. 

#### 1 Chronicles 20:1 And it came to pass in the {going out year}, in the exiting of the kings for war, that Joab led all the force of the military, and ruined the place of the sons of Ammon, and came and besieged Rabbah. And David settled in Jerusalem. And Joab struck Rabbah, and razed it. 

#### 1 Chronicles 20:2 And David took the crown of their king from his head, and found the weight of it to be a talent of gold. And on it {stone a valuable}, and it was upon the head of David. And {spoils from the city he brought forth much exceedingly}. 

#### 1 Chronicles 20:3 And the people in it he led out, and he sawed through with saws, and with adz of iron, and with threshing machines. And thus David did to all the cities of the sons of Ammon. And David returned and all his people unto Jerusalem. 

#### 1 Chronicles 20:4 And it came to pass after these things, that there was still war in Gezer with the Philistines. Then {struck Sibbechai the Hushathite} Sippai of the sons of the giants, and abased him. 

#### 1 Chronicles 20:5 And came to pass yet again war with the Philistines. And {struck Elhanan son of Jair} Lahmi brother of Goliath the Gittite; and the wood of his spear was as the beam of a loom of one weaving. 

#### 1 Chronicles 20:6 And came to pass yet again a war in Gath, and there was {man an immense}, and his fingers and toes were six by six -- twenty and four; and this one was a descendant of the giants. 

#### 1 Chronicles 20:7 And he berated Israel, and {struck him Jonathan the son of Shimea brother of David}. 

#### 1 Chronicles 20:8 These were born to Rapha in Gath; all four were giants, and they fell by the hand of David, and by the hand of his servants. 

#### 1 Chronicles 21:1 And {rose up Satan} against Israel, and stirred up David to count Israel. 

#### 1 Chronicles 21:2 And {said king David} to Joab, and to the rulers of the force, Go, count Israel from Beer-sheba unto Dan, and bring it to me! and I shall know their number. 

#### 1 Chronicles 21:3 And Joab said, May the LORD add unto his people as they are a hundred foldly, and the eyes of my master the king seeing it. Are not, O my master, O king, all {to my master for bondservants}? And why does {want this my master}? so as to not become for a trespass to Israel. 

#### 1 Chronicles 21:4 But the saying of the king prevailed over Joab. And Joab went forth, and went unto all Israel, and went up unto Jerusalem. 

#### 1 Chronicles 21:5 And Joab gave the number of the numbering of the people to David. And {was all Israel} a thousand thousand and a hundred thousand men unsheathing the broadsword. And of Judah -- four hundred and seventy thousand men unsheathing the broadsword. 

#### 1 Chronicles 21:6 And Levi and Benjamin were not counted in the midst of them, for {was disgraceful the word of the king} to Joab. 

#### 1 Chronicles 21:7 And it was wicked before God concerning this thing, and he struck Israel. 

#### 1 Chronicles 21:8 And David said to God, I have sinned exceedingly, that I did this thing. And now, remove indeed the iniquity of your servant! for I acted in folly exceedingly. 

#### 1 Chronicles 21:9 And the LORD spoke to Gad, David's seer, saying, 

#### 1 Chronicles 21:10 Go and speak to David! saying, Thus says the LORD, Three things I will take up upon you; choose for yourself one of them! and I will do it unto you. 

#### 1 Chronicles 21:11 And Gad came to David, and said to him, Thus says the LORD, Choose for yourself! 

#### 1 Chronicles 21:12 Either three years of famine; or three months fleeing from the face of your enemies, with the sword of your enemies pursuing you; or three days of the broadsword of the LORD, and plague in the land, and the angel of the LORD utterly destroying among all the inheritance of Israel. And now, behold, what {should I answer to the one sending me word}? 

#### 1 Chronicles 21:13 And David said to Gad, It is narrow exceedingly, I shall fall indeed into the hands of the LORD, for {great his compassions are exceedingly}; but into the hands of men in no way should I fall. 

#### 1 Chronicles 21:14 And the LORD appointed plague in Israel. And there fell of Israel seventy thousand men. 

#### 1 Chronicles 21:15 And God sent an angel into Jerusalem to utterly destroy it. And as he was utterly destroying, the LORD beheld and repented concerning the evil. And he said to the angel, to the one utterly destroying, Let it be enough to you, spare your hand! And the angel of the LORD stood at the threshing-floor of Ornan the Jebusite. 

#### 1 Chronicles 21:16 And David lifted up his eyes, and he beheld the angel of the LORD standing between the earth and between the heaven, and his broadsword being unsheathed in his hand, being stretched out over Jerusalem. And {fell David and the elders wearing sackcloths} upon their face. 

#### 1 Chronicles 21:17 And David said to God, Did I not say to count among the people? Then I am the one sinning -- in doing evil I did evil. And these sheep, what did they do, O LORD God? Let {come your hand} against me, and against the house of my father, and not against your people for destruction! 

#### 1 Chronicles 21:18 And the angel of the LORD told Gad to say to David that he should ascend to establish an altar to the LORD at the threshing-floor of Ornan the Jebusite. 

#### 1 Chronicles 21:19 And David ascended according to the word of Gad, which he spoke in the name of the LORD. 

#### 1 Chronicles 21:20 And Ornan turned, and he beheld the king. And {four sons his} with him were being hidden. And Ornan was threshing wheat. 

#### 1 Chronicles 21:21 And David came to Ornan, and Ornan came forth from the threshing-floor. And Ornan looked up, and he saw David, and he did obeisance to David with the face upon the ground. 

#### 1 Chronicles 21:22 And David said to Ornan, Give to me the place of the threshing-floor! for I shall build upon it an altar to the LORD. {for its money's worth Give it to me}! and {shall cease the calamity} from among the people. 

#### 1 Chronicles 21:23 And Ornan said to David, Take it for yourself, and let {do my master the king} what is good before him! Behold, I have given the oxen for a whole burnt-offering, and the plow for wood, and the grain for a sacrifice -- the whole I have given. 

#### 1 Chronicles 21:24 And {said king David} to Ornan, Not so, but only by buying shall I buy of its money's worth; for in no way shall I take the things of yours to the LORD, to offer a whole burnt-offering without charge to me to the LORD. 

#### 1 Chronicles 21:25 And David gave to Ornan for his place {shekels of gold in scale-weight six hundred}. 

#### 1 Chronicles 21:26 And {built there David} an altar to the LORD. And he offered whole burnt-offerings, and a deliverance offering, and he yelled to the LORD. And he heeded him by fire from out of the heaven on the altar of the whole burnt-offering. 

#### 1 Chronicles 21:27 And the LORD spoke to the angel; and he put away his broadsword into its sheath. 

#### 1 Chronicles 21:28 In that time when David beheld that {heeded him the LORD} at the threshing-floor of Ornan the Jebusite, then he sacrificed there. 

#### 1 Chronicles 21:29 And the tent of the LORD which Moses made in the wilderness, and the altar of the whole burnt-offerings, in that time were in Bama in Gibeon. 

#### 1 Chronicles 21:30 And {was not able David} to go before it to seek God, for he hastened from the face of the broadsword of the angel of the LORD. 

#### 1 Chronicles 22:1 And David said, This is the house of the LORD God, and this is the altar for the whole burnt-offering to Israel. 

#### 1 Chronicles 22:2 And David said to gather together all the foreigners in the land of Israel. And he placed quarriers to quarry {stones planed} to build a house to the LORD. 

#### 1 Chronicles 22:3 And {iron much} for the nails of the doorways, and of the gates, and of the hinges, David prepared; and brass in multitude -- there was no counting its weight. 

#### 1 Chronicles 22:4 And {for the wood of cedars there was no number}; for {brought the Sidonians and the Tyrians} wood of cedars in multitude to David. 

#### 1 Chronicles 22:5 And David said, Solomon my son {boy is a tender}, and the house to be built to the LORD must be to magnify upward, for a name and for glory in all the earth. I shall prepare for it. And David prepared for it in multitude before his decease. 

#### 1 Chronicles 22:6 And he called Solomon his son, and gave charge to him to build the house to the LORD God of Israel. 

#### 1 Chronicles 22:7 And David said, Solomon, My child, it was upon my soul to build a house to the name of the LORD my God. 

#### 1 Chronicles 22:8 And {came unto me the word of the LORD}, saying, {blood in multitude You poured out}, and {wars great you made}; you shall not build a house to my name, for {blood much you poured out} upon the earth before me. 

#### 1 Chronicles 22:9 Behold, a son is born to you, this one will be a man of rest; and I will rest him from all his enemies round about. For Solomon is his name, and peace and rest I shall appoint over Israel in his days. 

#### 1 Chronicles 22:10 This one shall build a house to my name, and this one shall be to me as a son, and I will be to him for father, and I will prepare the throne of his kingdom in Israel unto the eon. 

#### 1 Chronicles 22:11 And now, O my son, may {be with you the LORD}; and you shall prosper, and shall build a house to the LORD your God, as he said concerning you. 

#### 1 Chronicles 22:12 Only may {give to you the LORD} wisdom and understanding, and strengthen you over Israel, to guard and to observe the law of the LORD your God. 

#### 1 Chronicles 22:13 Then the way shall prosper, if you should guard to observe the orders and the judgments which the LORD gave charge to Moses for Israel. Be manly and be strong! Fear not nor be timid! 

#### 1 Chronicles 22:14 And behold, I according to my poorness prepared for the house of the LORD -- gold {talents of a hundred thousand}, and silver {of talents of a thousand thousand}, and brass, and iron of which there is no counting the weight, for {in multitude it is}. And wood and stones I prepared. And you add unto these things! 

#### 1 Chronicles 22:15 And with you 3in 4multitude 1doing 2 the works} are craftsmen, quarriers of stones, and fabricators of wood, and every wise one for every work; 

#### 1 Chronicles 22:16 in gold and silver, in brass and in iron in which there is no number. Rise up and act and the LORD be with you! 

#### 1 Chronicles 22:17 And David gave charge to all the rulers of Israel to assist Solomon his son, saying, 

#### 1 Chronicles 22:18 Is not the LORD with you? And he will give you rest round about, for he delivered up into my hand the ones dwelling the land, and {is submitted the land} before the LORD, and before his people. 

#### 1 Chronicles 22:19 Now give your hearts and your souls to seek the LORD your God! And arise and build the sanctuary to the LORD, to your God! to carry in the ark of the covenant of the LORD, and {items the holy} of God, into the house being built to the name of the LORD. 

#### 1 Chronicles 23:1 And David was older and full of days. And {took reign Solomon his son} instead of him over Israel. 

#### 1 Chronicles 23:2 And he brought together all the rulers of Israel, and the priests, and the Levites. 

#### 1 Chronicles 23:3 And {were counted the Levites} from thirty years old and up. And {was the number of them} according to their head count of males -- thirty and eight thousand. 

#### 1 Chronicles 23:4 Of these were foremen over the works of the house of the LORD -- twenty-four thousand; and scribes and judges -- six thousand; 

#### 1 Chronicles 23:5 and four thousand gatekeepers; and four thousand praising the LORD with instruments, which made praise to the LORD. 

#### 1 Chronicles 23:6 And {divided them David} into daily rotations to the sons of Levi -- to Gershon, Kohath, and Merari. 

#### 1 Chronicles 23:7 And to the family of Gershon -- Ladan and Shimei. 

#### 1 Chronicles 23:8 The sons to Ladan -- the ruler Jehiel, and Zetham, and Joel -- three. 

#### 1 Chronicles 23:9 The sons of Shimei -- Shelomith, and Haziel, and Haran -- three. These were rulers of the families of Ladan. 

#### 1 Chronicles 23:10 And sons of Shimei -- Jahath, and Zizah, and Jeush, and Beriah. These are sons of Shimei -- four. 

#### 1 Chronicles 23:11 And Jahath was the ruler, and Zizah the second. And Jeush and Beriah did not multiply sons; and they were assigned for the house of the family for numbering as one. 

#### 1 Chronicles 23:12 The sons of Kohath -- Amram, Izhar, Hebron, Uzziel -- four. 

#### 1 Chronicles 23:13 The sons of Amram -- Aaron and Moses. And Aaron was separated to sanctify the holy of holies, he and his sons unto the eon, to burn incense before the LORD, to officiate to him, and to invoke upon his name unto the eon. 

#### 1 Chronicles 23:14 And as far as Moses the man of God, his sons were called unto the tribe of Levi. 

#### 1 Chronicles 23:15 The sons of Moses -- Gershom and Eliezer. 

#### 1 Chronicles 23:16 The sons of Gershom -- Shebuel the ruler. 

#### 1 Chronicles 23:17 And there were sons to Eliezer -- Rehabiah the ruler. But there were no {sons to Eliezer other}. And the sons of Rehabiah increased in stature. 

#### 1 Chronicles 23:18 The sons of Izhar -- Shelomith the ruler. 

#### 1 Chronicles 23:19 The sons of Hebron -- Jeriah the ruler, Amariah the second, Jahaziel the third, Jekameam the fourth. 

#### 1 Chronicles 23:20 The sons of Uzziel -- Michah the ruler, and Jesiah the second. 

#### 1 Chronicles 23:21 The sons of Merari -- Mahli and Mushi. The sons of Mahli -- Eleazar and Kish. 

#### 1 Chronicles 23:22 And Eleazar died, and there were no sons to him, but only daughters. And {took them the sons of Kish their brethren}. 

#### 1 Chronicles 23:23 The sons of Mushi -- Mahli, and Eder, and Jeremoth -- three. 

#### 1 Chronicles 23:24 These were the sons of Levi according to the houses of their families; rulers of their families according to their numbering, according to the number of their names, according to their head count, the ones doing the works of the ministration of the house of the LORD, from twenty years and up. 

#### 1 Chronicles 23:25 For David said, {rested The LORD God of Israel} his people, and encamped in Jerusalem unto the eon. 

#### 1 Chronicles 23:26 And also to the Levites it is not to lift the tent, nor any of its items for its ministration. 

#### 1 Chronicles 23:27 For in the {words of David last} was the number of the sons of Levi from twenty years and up. 

#### 1 Chronicles 23:28 For he established them for the hand of the sons of Aaron, to officiate in the house of the LORD, over the courtyards, and over the cubicles, and over the cleansing of all the holy things, and over the works of the ministration of the house of God; 

#### 1 Chronicles 23:29 and for the bread loaves of the place setting, and for the fine flour of the sacrifice offering, and for the {cakes unleavened}, and for the frying pan, and for the mixture, and for every measure; 

#### 1 Chronicles 23:30 and to stand in the morning to praise and to make acknowledgement to the LORD, and so the evening; 

#### 1 Chronicles 23:31 and upon all the offerings of whole burnt-offerings to the LORD on the Sabbaths, and on the new moons, and on the holidays, according to number, according to the ordinance upon them, always before the LORD; 

#### 1 Chronicles 23:32 and they shall guard the watches of the tent of the testimony, and the watch of the holy place, and the watches of the sons of Aaron their brethren, to officiate in the house of the LORD. 

#### 1 Chronicles 24:1 And {of the sons of Aaron the divisions}. The sons of Aaron -- Nadab, and Abihu, Eleazar, and Ithamar. 

#### 1 Chronicles 24:2 And {died Nadab and Abihu} before their father, and {sons there were no} to them. And {officiated as priest Eleazar and Ithamar the sons of Aaron}. 

#### 1 Chronicles 24:3 And {divided them David}, even Zadok of the sons of Eleazar, and Ahimelech of the sons of Ithamar according to their numbering, according to their ministration. 

#### 1 Chronicles 24:4 And {were found sons of Eleazar more} as rulers of the mighty ones than of the sons of Ithamar. And he divided them to the sons of Eleazar for rulers for the houses of the families -- sixteen. And to the sons of Ithamar according to the houses of their families -- eight. 

#### 1 Chronicles 24:5 And he divided them by lots, these with these. For they were rulers of the holies, and rulers of God among the sons of Eleazar, and among the sons of Ithamar. 

#### 1 Chronicles 24:6 And {wrote them Shemaiah son of Nethaneel the scribe from Levi} before the king, and the rulers, and Zadok of the priest, and Ahimelech son of Abiathar, and the rulers of the families of the priests and the Levites. The house of the {family one}, one to Eleazar; and the house of the {family one}, one to Ithamar. 

#### 1 Chronicles 24:7 And {came forth lot the first} to Jehoiarib; to Jedaiah the second, 

#### 1 Chronicles 24:8 to Harim the third, to Seorim the fourth, 

#### 1 Chronicles 24:9 to Malchijah the fifth, to Mijamin the sixth, 

#### 1 Chronicles 24:10 to Hakkoz the seventh, to Abijah the eighth, 

#### 1 Chronicles 24:11 to Jeshua the ninth, to Shechaniah the tenth, 

#### 1 Chronicles 24:12 to Eliashib the eleventh, to Jakim the twelfth, 

#### 1 Chronicles 24:13 to Huppah the thirteenth, to Jeshabeab the fourteenth, 

#### 1 Chronicles 24:14 to Bilgah the fifteenth, to Immer the sixteenth, 

#### 1 Chronicles 24:15 to Hezir the seventeenth, to Apses the eighteenth, 

#### 1 Chronicles 24:16 to Pethahiah the nineteenth, to Jehezekel the twentieth, 

#### 1 Chronicles 24:17 to Jachin the first and twentieth, to Gamul the second and twentieth, 

#### 1 Chronicles 24:18 to Delaiah the third and twentieth, to Maaziah the fourth and twentieth. 

#### 1 Chronicles 24:19 This is their numbering according to their ministration, to enter into the house of the LORD, according to their ordinance, by the hand of Aaron their father, as {gave charge the LORD God of Israel}. 

#### 1 Chronicles 24:20 And to the sons of Levi remaining; to the sons of Amram -- Shubael; to the sons of Shubael -- Jehdeiah; 

#### 1 Chronicles 24:21 to Rehabiah, to the sons of Rehabiah the ruler Iesshiah; 

#### 1 Chronicles 24:22 and to Izhar -- Shelomoth; to the sons of Shelomoth -- Jahath; 

#### 1 Chronicles 24:23 to the sons of Jeriah -- Amariah the second, Jahaziel the third, Jekameam the fourth; 

#### 1 Chronicles 24:24 to the sons of Uzziel -- Michah; to the sons of Michah -- Shamir. 

#### 1 Chronicles 24:25 The brother of Michah -- Isshiah; to the son of Isshiah -- Zechariah. 

#### 1 Chronicles 24:26 To the sons of Merari -- Mahli and Mushi; the sons of Jaaziah -- of Beno. 

#### 1 Chronicles 24:27 The sons of Merari to Jaaziah -- his son, Shoham, and Zaccur, and Ibri. 

#### 1 Chronicles 24:28 To Mahli -- Eleazar, and there were no sons to him. 

#### 1 Chronicles 24:29 To Kish -- the sons of Kish -- Jerahmeel. 

#### 1 Chronicles 24:30 The sons of Mushi -- Mahli, and Eder, and Jerimoth. These were the sons of the Levites according to the houses of their families. 

#### 1 Chronicles 24:31 And they took also for themselves lots as their brethren the sons of Aaron before David the king -- even Zadok, and Ahimelech, and the rulers of the families of the priests, and the Levites, patriarchs Araab as {brethren his younger}. 

#### 1 Chronicles 25:1 And {established David the king and the rulers of the force} for the works some of the sons of Asaph, and Heman, and Jeduthun, the ones declaring with lutes, and with stringed instruments, and with cymbals. And {was their number} according to the head count of men of the ones working in their service. 

#### 1 Chronicles 25:2 The sons of Asaph -- Zaccur and Joseph, and Nethaniah, and Asarelah; the sons of Asaph being next to Asaph the prophet, being next to the king. 

#### 1 Chronicles 25:3 To Jeduthun -- the sons of Jeduthun were Gedaliah, and Zeri, and Jeshaiah, and Hashabiah, and Mattithiah -- six, along with their father Jeduthun, {with the lute prophesying}, in acknowledgment and praise to the LORD. 

#### 1 Chronicles 25:4 To Heman -- the sons of Heman -- Bukkiah, and Mattaniah, and Uzziel, and Shebuel, and Jerimoth, and Hananiah, and Hanani, and Eliathah, and Giddalti, and Romamti-ezer, and Joshbekashah, and Mallothi, and Hothir, and Mahazioth. 

#### 1 Chronicles 25:5 All these were sons to Heman the seer to the king in words of God, to raise up high the horn. And God gave to Heman {sons fourteen} and {daughters three}. 

#### 1 Chronicles 25:6 All these with their father singing hymns in the house of the LORD, with cymbals, and with stringed instruments, and with lutes, for the service of the house of God, being next to the king, even Asaph and Jeduthun and Heman. 

#### 1 Chronicles 25:7 And {was number their} with their brethren, the ones being taught to sing to the LORD, every one perceiving singing -- two hundred eighty and eight. 

#### 1 Chronicles 25:8 And they threw for themselves lots for the daily rotations, according to the small and according to the great, the ones perfected and the one learning. 

#### 1 Chronicles 25:9 And {came forth lot the first} to Asaph of Joseph; Gedeliah the second, he and his brethren and his sons -- twelve. 

#### 1 Chronicles 25:10 The third to Zaccur, he, and his brethren, and his sons -- twelve. 

#### 1 Chronicles 25:11 The fourth to Izri, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:12 The fifth to Nethaniah, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:13 The sixth to Bukkiah his sons and his brethren -- twelve. 

#### 1 Chronicles 25:14 The seventh to Jesharelah, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:15 The eighth to Jeshaiah, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:16 The ninth to Mattaniah, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:17 The tenth Shimei, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:18 The eleventh to Azareel, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:19 The twelfth to Hashabiah his sons and his brethren -- twelve. 

#### 1 Chronicles 25:20 The thirteenth to Shubael, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:21 The fourteenth to Mattithiah, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:22 The fifteenth to Jeremoth, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:23 The sixteenth to Hananiah, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:24 The seventeenth to Joshbekashah, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:25 The eighteenth to Hanani, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:26 The nineteenth to Mallothi, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:27 The twentieth to Eliatha, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:28 The twentieth and first to Hothir, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:29 The twentieth and second to Giddalti, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:30 The twentieth and third to Mahazioth, his sons and his brethren -- twelve. 

#### 1 Chronicles 25:31 The twentieth and fourth to Romamti-ezer, his sons and his brethren -- twelve. 

#### 1 Chronicles 26:1 For the divisions of the gates to the of Korhites -- Meshelemiah son of Kore of the sons of Asaph. 

#### 1 Chronicles 26:2 And to Meshelemiah sons Zechariah the first-born, Jediael the second, Zebadiah the third, Jathniel the fourth, 

#### 1 Chronicles 26:3 Elam the fifth, Jehohanan the sixth, Elioenai the seventh. 

#### 1 Chronicles 26:4 And to Obed Edom sons -- Shemaiah the first-born, Jehozabad the second, Joah the third, Sacar the fourth, Nethaneel the fifth, 

#### 1 Chronicles 26:5 Ammiel the sixth, Issachar the seventh, Peulthai the eighth; for {blessed him God}. 

#### 1 Chronicles 26:6 And to Shemaiah his son were born sons, ones being ordained in the house of their father, for they were mighty in strength. 

#### 1 Chronicles 26:7 The sons of Shemaiah -- Othni, and Raphael, and Obed, and Elzabad, and his brothers were {sons mighty}, Elihu, and Semachiah. 

#### 1 Chronicles 26:8 All these were sons of Obed Edom, they and their sons, and their brethren doing mightily in the work -- sixty two to Obed Edom. 

#### 1 Chronicles 26:9 And to Meshelemiah sons and brethren, mighty men -- eighteen. 

#### 1 Chronicles 26:10 And to Hosah of the sons of Merari, the sons guarding the office, but he was not the first-born, but {made him his father} ruler. 

#### 1 Chronicles 26:11 Hilkiah the second, Tebaliah the third, Zechariah the fourth. All these sons and brethren to Hosah -- thirteen. 

#### 1 Chronicles 26:12 Among these were the divisions of the gates, to the rulers of the mighty men, in daily rotations as their brethren, to officiate in the house of the LORD. 

#### 1 Chronicles 26:13 And they threw lots for the small and for the great, according to the houses of their families, for gate by gate. 

#### 1 Chronicles 26:14 And {fell the lot of the gates towards the east} to Shelemiah. And Zechariah his son, a counselor with skillfulness -- they threw lots; and {came forth of his the lot} for the north gate. 

#### 1 Chronicles 26:15 To Obed Edom according to the south, and to his sons over against the house of collections. 

#### 1 Chronicles 26:16 To Hosah to the west with the gate of the cubicle by the road of the ascent, watch against watch. 

#### 1 Chronicles 26:17 Towards the east, the six Levites for the day, towards the north -- four for the day; towards the south and to the collections two by two for relieving; 

#### 1 Chronicles 26:18 and towards the west -- four; and at the road two by two relieving. 

#### 1 Chronicles 26:19 These are the divisions of the gatekeepers for the sons of Kore, and the sons of Merari. 

#### 1 Chronicles 26:20 And the Levites of their brethren were over the treasures of the house of the LORD, and over the treasures of the holy things. 

#### 1 Chronicles 26:21 The sons of Laadan, the sons to Gershon -- to Laadan, rulers of the families of Ladan -- to Gershon -- Jehieli. 

#### 1 Chronicles 26:22 The sons of Jehieli -- Zetham, and Joel his brother, who were over the treasures of the house of the LORD. 

#### 1 Chronicles 26:23 To Amram, and Izhar, and Hebron, and Uzziel. 

#### 1 Chronicles 26:24 And Shebuel the son of Gershom, the son of Moses, was leading over the treasures. 

#### 1 Chronicles 26:25 And to his brother Eliezer -- Rehabiah his son, and Jeshaiah his son, and Joram his son, and Zichri his son, and Shelomith his son. 

#### 1 Chronicles 26:26 He, Shelomith and his brethren were over all the treasures of the holies, which {sanctified David the king}, and the rulers of the families -- commanders of thousands, and commanders of hundreds, and chiefs of the force, 

#### 1 Chronicles 26:27 which they took from out of the cities, and from the bounty. And he sanctified of them, so as to not be late in the construction of the house of the LORD; 

#### 1 Chronicles 26:28 and upon all the holy things of God as much as was sanctified by Samuel the seer, and Saul the son of Kish, and Abner the son of Ner, and Joab the son of Zeruiah, and all being sanctified through the hand of Shelomith and his brethren. 

#### 1 Chronicles 26:29 To the Izharites -- Chenaniah and his sons were for the work of the effort of the outside over Israel, to act as scribe and to litigate. 

#### 1 Chronicles 26:30 To the Hebronites -- Hashabiah and his brethren, sons of power, a thousand and seven hundred, were the ones over the reviewing of Israel on the other side of the Jordan to the west, for every ministration of the LORD, and work of the king. 

#### 1 Chronicles 26:31 Of the Hebronites, Jerijah was the ruler of the Hebronites according to their generations, and according to their families. In the {year fortieth} of the kingship of David they were numbered, and {was found man the mighty} among them in Jazer of the Gileadite. 

#### 1 Chronicles 26:32 And his brethren {sons were mighty} -- two thousand seven hundred rulers of the families. And {placed them David the king} over the Reubenites, and Gadites, and the half tribe of Manasseh, for every matter of God, and matter of the king. 

#### 1 Chronicles 27:1 And the sons of Israel according to their number, rulers of the families, commanders of thousands, and commanders of hundreds, and scribes, the ones officiating to the king, and in every matter of the king according to their divisions for every matter entering and going forth month by month for all the months of the year -- {division one} were twenty and four thousand. 

#### 1 Chronicles 27:2 And over the {division first} of the {month first} was Jashobeam the son of Zabdiel; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:3 From the sons of Perez ruler of all the rulers of the force of the {month first}. 

#### 1 Chronicles 27:4 And over the division of the {month second} was Dodai the Ahohite, and of his division, and Mikloth was the ruler; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:5 The {ruler of the force third} for the {month third} was Benaiah the son of Jehoiada, the {priest ruling}; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:6 This Benaiah was mightier than the thirty, and over the thirty; and over his division was Ammizabad his son. 

#### 1 Chronicles 27:7 The fourth for the {month fourth} was Asahel the brother of Joab, and Zebadiah his son, and his brethren after him; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:8 The fifth for the {month fifth}, the ruler was Shamhuth the Izrahite; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:9 The sixth for the {month sixth} was Ira son of Ikkesh the Tekoite; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:10 The seventh ruler for the {month seventh} was Helez the Pelonite, from the sons of Ephraim; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:11 The eighth ruler for the {month eighth} was Sibbecai the Hushathite to the Zarhites; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:12 The ninth ruler for the {month ninth} was Abiezer the one of Anathoth of the Benjamites; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:13 The tenth ruler for the {month tenth} was Maharai the one of Netopha to the Zarhites; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:14 The eleventh ruler for the {month eleventh} was Benaiah the one of Piarathon, of the sons of Ephraim; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:15 The twelfth ruler for the {month twelfth} was Heldai the Netophathite to Othniel; and in his division were twenty and four thousand. 

#### 1 Chronicles 27:16 And over the tribes of Israel -- to Reuben leading was Eliezer son of Zichri; to Simeon was Shephatiah the son of Maachah; 

#### 1 Chronicles 27:17 to Levi was Hashabiah son Kamuel; to Aaron was Zadok; 

#### 1 Chronicles 27:18 to Judah was Elihu of the brethren of David; to Issachar was Omri the son of Michael; 

#### 1 Chronicles 27:19 to Zebulun was Ishmaiah the son of Obadiah; to Naphtali was Jerimoth the son of Azriel; 

#### 1 Chronicles 27:20 to Ephraim was Hoshea the son of Azaziah; to the half tribe of Manasseh was Joel son of Pedaiah; 

#### 1 Chronicles 27:21 to the half tribe of Manasseh of the ones in the land of Gilead was Iddo the son of Zechariah; to the sons of Benjamin was Jaasiel the son of Abner; 

#### 1 Chronicles 27:22 to Dan was Azareel the son of Jeroham. These were the patriarchs of the tribes of Israel. 

#### 1 Chronicles 27:23 And {did not take David} their number from twenty years and below, for the LORD spoke to multiply Israel as the stars of the heaven. 

#### 1 Chronicles 27:24 And Joab the son of Zeruiah began to count among the people, and he did not complete it. And {happened because of this anger against Israel}. And {was not set down in writing the number} in a scroll of the matters of the days of king David. 

#### 1 Chronicles 27:25 And over the storehouses of the king was Azmaveth the son of Adiel. And over the storehouses in the country, and in the cities, and in the towns, and in the estates, and in the towers, was Jehonathan the son of Uzziah. 

#### 1 Chronicles 27:26 And over the ones cultivating the ground of the ones being worked was Ezri the son of Chelub. 

#### 1 Chronicles 27:27 And over the vineyards was Shimei the Ramathite. And over the storehouses in the fields for the wine was Zabdi the one of Shiphmi. 

#### 1 Chronicles 27:28 And over the olive groves and over the sycamine trees in the plain was Baal-hanan the Gederite. And over the storehouses of the olive oil was Joash. 

#### 1 Chronicles 27:29 And over the oxen grazing in Sharon was Shitrai the Sharonite. And over the oxen in the canyons was Shaphat son Adlai. 

#### 1 Chronicles 27:30 And over the camels was Obil the Ishmaelite. And over the donkeys was Jehdeiah the one of Merathon. 

#### 1 Chronicles 27:31 And over the sheep was Jaziz the Hagerite. All these were rulers of the possessions of David the king. 

#### 1 Chronicles 27:32 And Jonathan the uncle of David was a counselor, {man a discerning}, and a scribe himself; and Jehiel the one of the Hachmoni was with the sons of the king. 

#### 1 Chronicles 27:33 And Ahithophel was counselor of the king. And Hushai was the foremost friend of the king. 

#### 1 Chronicles 27:34 And after Ahithophel next was Jehoiada the son of Benaiah, and Abiathar. And Joab was commander-in-chief for the king. 

#### 1 Chronicles 28:1 And David held an assembly of all the rulers of Israel, rulers of the tribes, and the rulers of the divisions of the daily rotations of the ones ministering to the king, and the rulers of the thousands, and of the hundreds, and of the keepers of the treasury, and of the ones over his possessions, and all the property of the king, and of his sons, with the eunuchs, and the mighty ones, and the warriors of the military in Jerusalem. 

#### 1 Chronicles 28:2 And {stood David the king} in the midst of the assembly, and he said, Hear me my brethren, and my people! It came to me in heart to build a house for a rest for the ark of the covenant of the LORD, and a station to be the footstool of the feet of God. And I prepared the things {for the construction needful}. 

#### 1 Chronicles 28:3 And God said, You shall not build to me a house to name my name upon it, for {a man of war you are}, and {blood you poured out}. 

#### 1 Chronicles 28:4 And {chose the LORD God of Israel} by me from out of all the house of my father to be king over Israel into the eon, and for Judah to take up the crown; and of the house of Judah, the house of my father. And among the sons of my father, in me he wanted me to become king over all Israel. 

#### 1 Chronicles 28:5 And of all my sons, for {many sons gave to me the LORD}, he chose Solomon my son to sit upon the throne of the kingdom of the LORD over Israel. 

#### 1 Chronicles 28:6 And {said to me God}, Solomon your son shall build my house, and my courtyards; for I chose in him to be to me for a son, and I will be to him for a father. 

#### 1 Chronicles 28:7 And I will set up his kingdom unto the eon, if he should be strong to do and to guard my commandments, and my judgments as in this day. 

#### 1 Chronicles 28:8 And now according to the eyes of all Israel of every assembly of the LORD, and in the ears of our God, guard and seek all the commandments of the LORD our God! that you should inherit the {land good}, and should inherit it to your sons after you unto the eon. 

#### 1 Chronicles 28:9 And now, Solomon O my son, know the God of your fathers, and serve to him with {heart a perfect} and {soul a willing}! For {of all hearts inquires diligently the LORD}, and every idea of thoughts he knows. If you should seek him, he will be found by you. And if you should leave him, he shall leave you to the end. 

#### 1 Chronicles 28:10 Behold now! for the LORD has taken you to build for him a house for a sanctuary. Be strong and act! 

#### 1 Chronicles 28:11 And David gave to Solomon his son the plan of the temple, and its houses, and its treasuries, and the upper rooms, and the {storerooms inner}, and the house of the atonement-seat, 

#### 1 Chronicles 28:12 and the plan of all which was in his spirit, and of the courtyards of the house of the LORD, and all of the cubicles round about of the places for the storehouses of the house of the LORD, and of the storehouses of the holy things; 

#### 1 Chronicles 28:13 and for the divisions of daily rotations of the priests and the Levites, and for every work of ministration of the house of the LORD, and of the storehouses of the {of ministrations items} of the service of the house of the LORD; 

#### 1 Chronicles 28:14 and for the gold and the weight of its scale-weight for all the items service by service, and to all the items of silver in weight to every item service by service; 

#### 1 Chronicles 28:15 and the weight to the lamp-stands, to the ones in gold, and to their lamps, gold in weight -- of lamp-stand by lamp-stand, and to its lamps, and to the lamp-stands. But of the gold and silver lamp-stands {of the scale-weight of money he gave to him}, and the lamp-stands he gave to him the scale-weight. 

#### 1 Chronicles 28:16 In like manner he gave the weight for the tables of the place setting, each one a table of gold; and likewise the tables made of silver, 

#### 1 Chronicles 28:17 and the meat hooks and libation bowls, and bowls of gold; and the basins of gold in weight for basin and basin; and the weight of the things of gold and of silver of each weight; 

#### 1 Chronicles 28:18 and the thing for the altar of the incenses the weight of {gold the unadulterated}. And he plainly showed to him the plan of the chariot of the cherubim, of the ones opening and spreading out the wings, and shadowing over the ark of the covenant of the LORD. 

#### 1 Chronicles 28:19 All in the writing by the hand of the LORD David gave to Solomon, according to the advantage to him for understanding of the working out of the plan. 

#### 1 Chronicles 28:20 And David said to Solomon his son, Be strong and manly, and act! Do not fear nor be terrified! for the LORD my God is with you. He will not send you away, and in no way will he abandon you until you complete every ministration of work of the house of the LORD. 

#### 1 Chronicles 28:21 And behold, the daily rotations of the priests and the Levites, are for all the ministration of the house of God, and with you in every work all eager in every voluntary thing, in wisdom according to every craft, and the rulers, and all the people for all your words. 

#### 1 Chronicles 29:1 And {said David the king} to all the assembly, Solomon my son, in whom {has taken for himself the LORD}, is young and tender, and the work is great; for {is not to man the place of abode}, but only to the LORD God. 

#### 1 Chronicles 29:2 And I according to all my power have prepared for the house of my God -- the gold for a gold thing, and the silver for a silver thing, and the brass for a brass thing, and the iron for an iron thing, and wood for a wood thing, and {stones onyx}, and fullness {stones of very costly}, and colored, and every {stone valuable}, and stones of Paros in multitude. 

#### 1 Chronicles 29:3 And still, because of my favoring to the house of my God, there is to me {which I procured gold and silver}; and behold, I give it for the house of my God, for above and outside what I prepared for the house of the holy place -- 

#### 1 Chronicles 29:4 three thousand talents of gold from Ophir, and seven thousand talents {silver of unadulterated}, to overlay by them the walls of the temple; 

#### 1 Chronicles 29:5 for the gold for the gold things, and for the silver for the silver things, and for every work by the hand of craftsmen. And who is feeling eager to fill his hands today to the LORD? 

#### 1 Chronicles 29:6 And {were eager the rulers of the families}, and the rulers of the sons of Israel, and the commanders of thousands, and commanders of hundreds, and the superintendents of the works, and the managers of the king. 

#### 1 Chronicles 29:7 And they gave for the works of the house of the LORD {of gold talents five thousand}, and {dracmas ten thousand}, and {of silver talents ten thousand}, and {of brass talents ten thousand eight thousand}, and of iron a hundred thousand talents. 

#### 1 Chronicles 29:8 And the ones who were found with stones for themselves gave to the storehouses of the house of the LORD, through the hand of Jehiel the Gershonite. 

#### 1 Chronicles 29:9 And {were glad the people} over the voluntary offering, for from {heart a full} they were volunteering to the LORD. And David the king was glad {gladness with great}. 

#### 1 Chronicles 29:10 And {blessed king David} the LORD before the assembly, saying, Blessed are you, O LORD God of Israel, our father from the eon and unto the eon. 

#### 1 Chronicles 29:11 To you, O LORD, is the greatness, and the power, and the majesty, and the victory, and the acknowledgment. For you {of all the things in heaven and upon the earth are master}. To you, O LORD, is the kingdom, and the raising in all, and in all rule. 

#### 1 Chronicles 29:12 From you are the riches and the glory. You rule all, O LORD, ruler of all sovereignty. And in your hand is strength and dominion; and in your hand to magnify, and to strengthen all. 

#### 1 Chronicles 29:13 And now, O LORD, we make acknowledgment to you, and we praise the name of your glory. 

#### 1 Chronicles 29:14 And who am I, and what is my people, that we were strong to volunteer to you thus? For {are yours all things}, and of your things we give to you. 

#### 1 Chronicles 29:15 For we are sojourners before you, and sojourners as all our fathers, and {are as shadows our days} upon the earth, and there is no waiting. 

#### 1 Chronicles 29:16 O LORD our God, to all this abundance which we prepared for you to build a house to your name -- to the holy name, {from your hand for it is}, and {yours are all things}. 

#### 1 Chronicles 29:17 And I know, O LORD, that you are the one examining hearts, and loving righteousness. And I in singleness of heart volunteered all these things. And now, your people, being found here, see with gladness, volunteering to you. 

#### 1 Chronicles 29:18 O LORD, God of Abraham, and Isaac, and Israel, of the one of our fathers, keep of them the thing shaped of the thoughts of the heart of your people into the eon! and straighten out their hearts to you! 

#### 1 Chronicles 29:19 And {Solomon to my son give heart a good}! to observe your commandments, and your testimonies, and your orders, and {unto completion to lead all}, and to build the furnishing of your house which I prepared. 

#### 1 Chronicles 29:20 And David said to all the assembly, Bless indeed the LORD our God! And {blessed all the assembly} the LORD, the God of their fathers, and bent the knees to do obeisance to the LORD, and to the king. 

#### 1 Chronicles 29:21 And David sacrificed to the LORD a sacrifice, and offered whole burnt-offerings to the LORD on the next day of the first day -- {calves of a thousand}, {rams a thousand}, {lambs a thousand}, and their libations, and sacrifices in multitude for all Israel. 

#### 1 Chronicles 29:22 And they ate and drank before the LORD in that day with {joy great}. And they gave reign for a second time for Solomon son of David. And they anointed him to the LORD as king, and Zadok for priest. 

#### 1 Chronicles 29:23 And Solomon sat upon the throne of the LORD as king instead of David his father, and he prospered. And {obeyed him all Israel}. 

#### 1 Chronicles 29:24 And the rulers, and the mighty ones, and also all the sons of king David submitted to him. 

#### 1 Chronicles 29:25 And the LORD magnified Solomon before all Israel, and put upon him glory of the kingdom of which did not happen unto any king before him over Israel. 

#### 1 Chronicles 29:26 And David son of Jesse reigned over all Israel. 

#### 1 Chronicles 29:27 And the days which he reigned over Israel -- forty years. In Hebron he reigned seven years, and in Jerusalem thirty-three years. 

#### 1 Chronicles 29:28 And he died in {old age a good}, full of days, in wealth, and glory. And {reigned Solomon his son} instead of him. 

#### 1 Chronicles 29:29 And the rest of the words of David the king, the ones former and the ones latter, behold, they are written in the words of Samuel the seer, and by the words of Nathan the prophet, and by the words of Gad the seer, 

#### 1 Chronicles 29:30 concerning all his kingship, and all his dominion, and of the events of the times of the ones spreading unto him, and unto Israel, and unto all the kingdoms of the lands.