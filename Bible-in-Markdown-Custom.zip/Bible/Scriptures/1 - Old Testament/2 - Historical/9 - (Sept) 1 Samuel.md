#### 1 Samuel 1:1 And there was {man one} from Ramathaim Zophim of mount Ephraim, and his name was Elkanah, son of Jeroham, son of Elihu, son of Tohu, son Zuph from mount Ephraim. 

#### 1 Samuel 1:2 And to this one was two wives; the name to the one was Hannah, and the name to the second was Peninnah. And there was to Peninnah a child, and to Hannah there was no child. 

#### 1 Samuel 1:3 And {ascended man that} from days to days from out of his city of Ramathaim to do obeisance and to sacrifice to the LORD of Hosts in Shiloh. And {there was} Eli and {two sons his}, Hophni and Phinehas, priests of the LORD. 

#### 1 Samuel 1:4 And came to pass a day that Elkanah sacrificed, and he gave to Peninnah his wife, and to all her sons, and to her daughters, portions. 

#### 1 Samuel 1:5 And to Hannah he gave {portion one}, for there was no child to her; except that {loved Hannah Elkanah} above Peninnah. But the LORD locked the matter concerning her womb. 

#### 1 Samuel 1:6 And {provoked her to anger her rival}, and even a provocation to anger because of the treating her with contempt, for the LORD closed up the matters concerning her womb to not give to her a child. 

#### 1 Samuel 1:7 Thus she did year by year in her ascending unto the house of the LORD; and she was depressed, and she wept, and did not eat. 

#### 1 Samuel 1:8 And {said to her Elkanah her husband}, Hannah, what is it to you that you weep? And why do you not eat? And why does {beat you your heart}? {not good Am I} to you over ten children? 

#### 1 Samuel 1:9 And Hannah rose up after their eating in Shiloh, and after drinking. And Eli the priest sat upon the chair at the doorposts of the temple of the LORD. 

#### 1 Samuel 1:10 And she was in severe pain of soul, and she prayed to the LORD, and with weeping she wept. 

#### 1 Samuel 1:11 And she vowed a vow, saying, O LORD of hosts, if looking you should look upon the humiliation of your maidservant, and should remember me, and should not forget your maidservant, and should give to your maidservant seed of a male, then I will put him before you, dedicated until the day of his death. And an iron razor shall not ascend upon his head. 

#### 1 Samuel 1:12 And it came to pass when she multiplied praying before the LORD, that Eli the priest watched her mouth. 

#### 1 Samuel 1:13 And she spoke in her heart, and her lips moved, but her voice was not heard. And {considered her Eli} to be intoxicated. 

#### 1 Samuel 1:14 And {said to her Eli}, Until when shall you be intoxicated? Remove your wine! 

#### 1 Samuel 1:15 And Hannah answered and said, No, O master, {a woman with a hard day I am}, and wine and strong drink I have not drunk, and I pour out my soul before the LORD. 

#### 1 Samuel 1:16 You should not grant your maidservant for {daughter mischievous}. For from the amount of my meditation, and from the amount of my depression, I have been stretched out until the present. 

#### 1 Samuel 1:17 And Eli answered and said to her, Go in peace! The God of Israel will give to you all your request which you asked of him. 

#### 1 Samuel 1:18 And she said, {found Your maidservant} favor in your eyes. And {went the woman} her way, and ate with her husband, and drank, and her face was not downcast any longer. 

#### 1 Samuel 1:19 And they rose early in the morning, and did obeisance to the LORD, and they went their way. And Elkanah entered unto his house in Ramah, and he knew Hannah his wife; and {remembered her the LORD}, and she conceived. 

#### 1 Samuel 1:20 And it came to pass in the time of the days, that Hannah bore a son, and she called his name Samuel, saying that, From the LORD almighty I asked him. 

#### 1 Samuel 1:21 And {ascended the man Elkanah}, and all his house, to sacrifice in Shiloh, for the sacrifice of the days, and his vows. 

#### 1 Samuel 1:22 And Hannah did not ascend with him, for she said to her husband, I will wait until the ascending of the boy, whenever I should have weaned it, and he shall appear in front of the LORD, and he shall settle there unto the eon. 

#### 1 Samuel 1:23 And {said to her Elkanah her husband}, You do the good thing in your eyes, sit until whenever you should wean it! Only may the LORD establish the thing coming forth from out of your mouth. And {sat the woman}, and nursed her son until whenever she weaned him. 

#### 1 Samuel 1:24 And she ascended with him unto Shiloh with a calf being three years old, and an ephah of fine flour, and a skin flask of wine. And she entered into the house of the LORD in Shiloh, and the boy with them. 

#### 1 Samuel 1:25 And they led him before the LORD, and they slew the calf. And {brought it Hannah the mother of the boy} to Eli. 

#### 1 Samuel 1:26 And she said, By me, O master, {should live your soul}; I am the woman standing before you with you while praying to the LORD. 

#### 1 Samuel 1:27 Over this boy I prayed, and {gave to me the LORD} my request which I asked of him. 

#### 1 Samuel 1:28 And I lend him to the LORD all the days which he should live for use by the LORD. 

#### 1 Samuel 2:1 And Hannah prayed and said, {is solidified My heart} in the LORD; {was raised high my horn} by my God; {was widened over my enemies my mouth}; for I was glad in your deliverance. 

#### 1 Samuel 2:2 For there is no one holy as the LORD; and there is no just one as our God; and there is no holy one besides you. 

#### 1 Samuel 2:3 Do not boast, and do not speak high things in superiority! Let not come forth lofty language from out of your mouth! For {is a God of knowledge the LORD}, and God is preparing his practices. 

#### 1 Samuel 2:4 The bow of the mighty is weakened, and the ones being weakened girded on power. 

#### 1 Samuel 2:5 The ones full of bread loaves are made less; and the ones hungering disregarded the land; for the sterile gave birth to seven, and the one with many in children weakened. 

#### 1 Samuel 2:6 The LORD puts to death, and he brings forth alive; he leads them down into Hades, and he leads up. 

#### 1 Samuel 2:7 The LORD makes poor, and he enriches; he humbles, and elevates. 

#### 1 Samuel 2:8 He raises up from the earth the needy, and from the dung he raises the poor to seat him with mighty ones of the people, and {a throne of glory inheriting to them}; 

#### 1 Samuel 2:9 giving the thing vowed for to the one vowing. And he blessed the years of the just; for not by strength is man able. 

#### 1 Samuel 2:10 The LORD {weak shall make his opponent}. The LORD is holy. The LORD ascended into heavens, and he thundered. He shall judge the extremities of the earth being just; and he shall give strength to our kings, and he will raise up high the horn of his anointed one. 

#### 1 Samuel 2:11 And they went forth unto Ramah unto their house. And the boy was officiating to the LORD before the face of Eli the priest. 

#### 1 Samuel 2:12 And the sons of Eli the priest {sons were mischievous}, not knowing the LORD. 

#### 1 Samuel 2:13 And the ordinance of the priest of {the people all} of the one sacrificing was this; that {came the servant of the priest} when ever {boiled the meat}, and {meat hook was a three-pronged in his hand}. 

#### 1 Samuel 2:14 And he stuck it into the {kettle great}, or into the brass caldron, or into the earthen pot; and all, what ever ascended on the meat hook {took to himself the priest}. According to thus they did to all Israel in Shiloh to the ones coming to sacrifice to the LORD. 

#### 1 Samuel 2:15 And before the burning the fat, {would come the servant of the priest}. And he said to the man sacrificing, Give meat {to roast to the priest}; for in no way shall I take meat from you cooked from out of the kettle. 

#### 1 Samuel 2:16 And if {said the man who was sacrificing}, {let there be burnt first} as is fit for the fat, and then you shall take for yourself from all what {desires your soul}. Then he said, No, but now you shall give it; and if not, I will take it forcefully. 

#### 1 Samuel 2:17 And {was the sin of the young men} great before the LORD, exceedingly, for they annulled the sacrifice of the LORD. 

#### 1 Samuel 2:18 And Samuel was officiating in the presence of the LORD, a boy being girded {ephod with a linen}. 

#### 1 Samuel 2:19 And {double garment a small made his mother} for him, and offered it to him from days unto days in her ascending with her husband, to sacrifice the sacrifice of the days. 

#### 1 Samuel 2:20 And Eli blessed Elkanah and his wife, saying, {pay to you the LORD} seed from out of this woman, for the loan which she treated the LORD. And {went forth the man} to his place. 

#### 1 Samuel 2:21 And the LORD visited Hannah, and she conceived again, and she bore yet three sons and two daughters. And {was magnified the boy Samuel} in the presence of the LORD. 

#### 1 Samuel 2:22 And Eli was an old man, exceedingly. And he heard what {did his sons} to {the sons of Israel all}, and that {went to bed his sons} with the women standing by the doors of the tent of the testimony. 

#### 1 Samuel 2:23 And he said to them, Why do you do according to these things, which I hear being spoken ill of you from the mouth of all the people of the LORD? 

#### 1 Samuel 2:24 No children, no, for it is not good, the hearing which I hear of the making the people to not serve to the LORD. 

#### 1 Samuel 2:25 If by sinning {should sin a man} against a man, then they shall pray for him to the LORD. But if {against the LORD sins a man}, who shall pray for him? But they did not hearken to the voice of their father. For willing, the LORD preferred to utterly destroy them. 

#### 1 Samuel 2:26 And the boy Samuel went on and was magnified, and was in good standing with the LORD, and with men. 

#### 1 Samuel 2:27 And {came the man of God} to Eli, and said to him, Thus says the LORD, In revealing I revealed myself to the house of your father in their being {in the land of Egypt servants to the house of Pharaoh}. 

#### 1 Samuel 2:28 And I chose the house of your father from out of all the tribes of Israel to officiate as priest to me, to ascend unto my altar, and to burn incense, and to carry an ephod before me. And I gave to the house of your father all the things {of the fire of the sacrifices} of the sons of Israel for food. 

#### 1 Samuel 2:29 Why have you looked upon my incense offering, and upon my sacrifice offering with an impudent eye, and glorified your sons above me, in them blessing themselves with the first-fruit of every sacrifice of Israel, prior of me? 

#### 1 Samuel 2:30 On account of this, thus says the LORD, the God of Israel, I said, Your house, and the house of your father shall go through before me unto the eon. And now, says the LORD, not even one will be to me, for the ones glorifying me I will glorify, and the ones treating me with contempt shall be disgraced. 

#### 1 Samuel 2:31 Behold, {come days}, and I shall utterly destroy your seed, and the seed of the house of your father. 

#### 1 Samuel 2:32 And you shall look upon {fortifications new} upon all the things which {shall do good Israel}. And there will not be an old man in your house all the days. 

#### 1 Samuel 2:33 And a man whom I should not utterly destroy among you from my altar, I will make {to fail his eyes}, and {will flow down his life}, and all the ones abounding of your house shall fall by the broadsword of men. 

#### 1 Samuel 2:34 And this is to you the sign which shall come upon {two sons these your}, on Hophni and Phinehas; in one day {shall die both}. 

#### 1 Samuel 2:35 And I will raise up for myself {priest a trustworthy} who {all the things in my heart and the things in my soul will do}. And I will build to him {house a trustworthy}, and he shall go through before my anointed one all the days. 

#### 1 Samuel 2:36 And it will be everyone being left behind among your house shall come to do obeisance to him for an obolus of silver, and for {bread loaf one}, saying, Throw me aside upon one of your priesthoods to eat bread! 

#### 1 Samuel 3:1 And the boy Samuel was officiating to the LORD before Eli the priest. And the word of the LORD was esteemed in those days, because there was no vision for giving orders. 

#### 1 Samuel 3:2 And it came to pass in that day that Eli slept in his own place, and his eyes began to be darkened, and he was not able to see. 

#### 1 Samuel 3:3 And the lamp of God was before its being extinguished, and Samuel slept in the temple of the LORD where the ark of God was. 

#### 1 Samuel 3:4 And the LORD called, Samuel Samuel. And he said, Behold, it is I. 

#### 1 Samuel 3:5 And he ran to Eli, and said, Behold, it is I, for you called me. And he said, I have not called you, return and sleep! And he returned and slept. 

#### 1 Samuel 3:6 And {added the LORD} again to call Samuel. And he went to Eli the second time, and said, Behold, it is I, for you called me. And he said, I have not called you child, return and sleep! 

#### 1 Samuel 3:7 And it was before Samuel knew God, and before the revealing the word of the LORD to him. 

#### 1 Samuel 3:8 And the LORD added again to call Samuel a third time. And he rose up and went to Eli. And said, Behold, it is I, for you have called me. And Eli discerned that the LORD has called the boy. 

#### 1 Samuel 3:9 And Eli said to Samuel, Return and sleep child! And it will be if he should call you, that you shall say, Speak, O LORD, for {hears your servant}! And Samuel went, and went to bed in his place. 

#### 1 Samuel 3:10 And the LORD came, and stood, and called him as once before, and once before that, Samuel, Samuel. And Samuel said, Speak, O LORD, for {hears your servant}! 

#### 1 Samuel 3:11 And the LORD said to Samuel, Behold, I perform my words in Israel, so that every one hearing them, it shall sound in both of his ears. 

#### 1 Samuel 3:12 In that day I rouse up against Eli. All as many things as I spoke against his house I will begin and I will complete. 

#### 1 Samuel 3:13 And I have announced to him that I punish, I, his house, unto the eon for the iniquities of his sons, in which he knew that {were speaking evil of God his sons}, and he did not admonish them. 

#### 1 Samuel 3:14 And {not thus have I} sworn by an oath to the house of Eli, Shall {be atoned the iniquity of the house of Eli} by incense or by sacrifices into the eon, no. 

#### 1 Samuel 3:15 And Samuel went to bed until morning. And he rose up early in the morning, and he opened the doors of the house of the LORD. And Samuel feared to report the vision to Eli. 

#### 1 Samuel 3:16 And Eli said to Samuel, Samuel child. And he said, Behold, it is I. 

#### 1 Samuel 3:17 And he said, What was the word being spoken to you? Do not indeed hide them from me! Thus {do to you God}, and thus add to it if you should hide from me the word. 

#### 1 Samuel 3:18 And Samuel reported to him all the words, and did not hide them from him. And Eli said, The LORD himself {the good thing before him will do}. 

#### 1 Samuel 3:19 And Samuel was magnified, and the LORD was with him. And there did not fall from all his words one upon the ground. 

#### 1 Samuel 3:20 And {knew all Israel} from Dan and unto Beer-sheba that Samuel was trustworthy for prophet to the LORD. 

#### 1 Samuel 3:21 And the LORD added again to manifest in Shiloh, for the LORD was revealed to Samuel in Shiloh according to the word of the LORD. 

#### 1 Samuel 4:1 And came to pass the word of Samuel to all Israel. And {gathered together the Philistines} for war against Israel; and Israel went forth to meet them for war. And they camped at Ebenezer. And the Philistines camped in Aphek. 

#### 1 Samuel 4:2 And {deployed the Philistines} for war against Israel. And {leaned one way the war}, and {failed the men of Israel} before the Philistines. And there was struck in the battle array in the field four thousand men. 

#### 1 Samuel 4:3 And {came the people} into the camp. And {said the elders of Israel}, Why is it so {devestated us the LORD} today before the Philistines? We should take to us the ark of the covenant of the LORD from out of Shiloh, and let it come forth in our midst! and it will deliver us from the hand of our enemies. 

#### 1 Samuel 4:4 And {sent the people} unto Shiloh, and they lifted from there the ark of covenant of the LORD of the forces, which sits upon the cherubim. And both the sons of Eli were with the ark of the covenant of God -- Hophni and Phinehas. 

#### 1 Samuel 4:5 And it came to pass as {came the ark of the covenant of the LORD} into the camp, that {shouted aloud all Israel voice with a great}, and {resounded the earth}. 

#### 1 Samuel 4:6 And {heard the Philistines} the sound of the cry. And they said, What is the sound of the cry -- this great one in the camp of the Hebrews? And they knew that the ark of the LORD comes into the camp. 

#### 1 Samuel 4:7 And {feared the Philistines}, and said, This their God comes to them into the camp. 

#### 1 Samuel 4:8 Woe to us, rescue us, O Master, today! for it happened not thus yesterday nor the third day before. Woe to us, who shall rescue us from out of the hand {gods substantial of these}? These are the gods striking Egypt in every calamity, and in the wilderness. 

#### 1 Samuel 4:9 Fortify, and become as men, O Philistines! so that you should not serve to the Hebrews, as they served us; and you shall be men and wage war against them. 

#### 1 Samuel 4:10 And {waged war against the Philistines} them; and {failed every man of Israel} before the Philistines, and {fled each} unto his tent. And there came to pass {calamity great an exceedingly}; and there fell from Israel thirty thousand from the ranks. 

#### 1 Samuel 4:11 And the ark of God was taken, and both the sons of Eli died -- Hophni and Phinehas. 

#### 1 Samuel 4:12 And there ran a man of Benjamin from out of the battle array, and he came into Shiloh on that day; and his garments were torn up, and earth was upon his head. 

#### 1 Samuel 4:13 And he came. And behold, Eli sat upon his chair by the gate watching the way, for {was his heart} receded on account of the ark of God. And the man entered into the city to report. And {yelled out whole the city}. 

#### 1 Samuel 4:14 And Eli heard the sound of the yelling, and said, What is {sound of yelling this}? And the man hastening, entered and reported to Eli. 

#### 1 Samuel 4:15 And Eli was a son ninety and eight years old, and his eyes were weighed down, and he did not see. 

#### 1 Samuel 4:16 And Eli said to the men, to the ones standing around him, What is the report of this sound? And the man hastening, came forward to Eli, and he said to him, I am the one having come from the camp, and I have fled from the battle array today. And Eli said, What is the {taking place thing} child? 

#### 1 Samuel 4:17 And {answered the servant-lad}, and said, {fled Every man of Israel} from the face of the Philistines, and {calamity a great} has happened among the people, and both of your sons have died, and the ark of God was taken. 

#### 1 Samuel 4:18 And it happened as {was mentioned the ark of God}, that he fell from the chair backwardly, being next to the gate, and {was broken back his}, and he died, for {was old the man} and heavy; and he judged Israel forty years. 

#### 1 Samuel 4:19 And his daughter-in-law, the wife of Phinehas, having conceived to give birth, when she heard the message that {was taken the ark of God}, and that {has died her father-in-law}, and her husband; that she wept and gave birth, for {turned upon her birth pangs her}. 

#### 1 Samuel 4:20 And in the time she was going to die, that {said to her the women standing beside her}, Do not fear! for {a son you have birthed}. But she did not answer, and did not comprehend in her heart. 

#### 1 Samuel 4:21 And she called the boy, Ichabod, for the ark of God, and for her father-in-law, and for her husband. 

#### 1 Samuel 4:22 And she said, {has been resettled The glory} from Israel, for {was taken the ark of God}. 

#### 1 Samuel 5:1 And the Philistines took the ark of God, and carried it from out of Ebenezer unto Ashdod. 

#### 1 Samuel 5:2 And {took the Philistines} the ark, of God and carried it into the house of Dagon, and stood it by Dagon. 

#### 1 Samuel 5:3 And {rose early the Ashdodites}, and they entered into the house of Dagon the next day. And they saw, and behold, Dagon was fallen upon his face upon the ground before the ark of God. And they raised Dagon, and they placed him upon his place. 

#### 1 Samuel 5:4 And it came to pass as they rose early in the next day in the morning, and behold, Dagon was fallen upon his face before of the ark of the LORD. And the head of Dagon, and both the traces of his hands were removed unto the front of the doorposts, and both the wrists of his hands were fallen upon the threshold. Only the spine of Dagon was left behind. 

#### 1 Samuel 5:5 On account of this, {do not mount the priests of Dagon}, nor do any enter into the house of Dagon by the threshold of the house of Dagon in Ashdod until this day; but by passing over, they pass over it. 

#### 1 Samuel 5:6 And {was oppressive the hand of the LORD} against the Ashdodites, and he tormented the Ashdodites, and he struck them in their buttock -- the one from Ashdod and their borders. 

#### 1 Samuel 5:7 And {beheld the men of Ashdod} that it was so, and they spoke saying that, {shall not settle the ark of the God of Israel} with us, for {is hard his hand} against us, and against Dagon our god. 

#### 1 Samuel 5:8 And they send and gather the satraps of the Philistines to themselves. And they say, What should we do with the ark of the God of Israel? And {say the Gathites}, Let {pass between the ranks the ark of God} to us! And {passed between the ranks the ark of the God of Israel} unto Gath. 

#### 1 Samuel 5:9 And it came to pass after it being passed through the ranks, that {came the hand of the LORD} against the city -- {disturbance great an exceedingly}; and he struck the men of the city from small unto great in their buttocks. 

#### 1 Samuel 5:10 And they sent out the ark of God unto Ekron. And it came to pass as {entered the ark of God} unto Ekron, that {yelled out the Ekronites}, saying, Why do you return the ark of the God of Israel to us, is it to put us to death and our people? 

#### 1 Samuel 5:11 And they sent, and they brought together all the satraps of the Philistines. And they said, Send out the ark of the God of Israel, and let it sit in its place, so that in no way shall we be put to death -- us and our people. 

#### 1 Samuel 5:12 For there came to pass a confusion of death in the entire city, {severe exceedingly}, as {entered the ark of the God of Israel}. And the living and the dying were struck in the buttocks. And {ascended the cry of the city} unto the heaven. 

#### 1 Samuel 6:1 And {was the ark of the LORD} in the field of the Philistines seven months. 

#### 1 Samuel 6:2 And {called the Philistines} the priests, and the clairvoyants, and their enchanters, saying, What should we do with the ark of the LORD? Make known to us by what means we shall send it unto its place! 

#### 1 Samuel 6:3 And they said, If you yourselves send the ark of the covenant of the LORD God of Israel, do not send it out empty! but by delivering it up, you give it back for the torment! and then you shall be healed, and it shall be atoned unto you, if should you not remove his hand from you? 

#### 1 Samuel 6:4 And they say, What thing for the torment shall we give for it? And they said, 

#### 1 Samuel 6:5 According to the number of the satrapies of the Philistines -- five buttocks of gold, for the fault in you, and your rulers, and to the people. And five {mice golden}, a representation of your mice, of the ones corrupting the land. And you shall give to the LORD God glory, so that he should lighten his hand from you, and from your gods, and from your land. 

#### 1 Samuel 6:6 And why do you oppress your hearts as {oppressed Egypt and Pharaoh} their hearts? Was it not when he mocked them, that they sent them, and they went forth? 

#### 1 Samuel 6:7 And now, take and make {wagon new one}, and two oxen having given birth for the first time, without the offspring, upon which {was not placed upon a yoke}! And team up the oxen on the wagon, and their offspring lead away from behind them to the house! 

#### 1 Samuel 6:8 And you shall take the ark of the LORD, and you shall put it upon the wagon; and the items of gold, deliver it for the torment! And you shall put in place a chest on part of it, and you shall send it, and it shall go forth. 

#### 1 Samuel 6:9 And you shall see if into the way of their border it shall go -- according to Beth-shemesh, if he did to us {evil great this}. And if not, then we will know that it was not his hand that touched us, but that {a coincidence this was} to us. 

#### 1 Samuel 6:10 And {did the Philistines} so. And they took two oxen, having given birth for the first time. And they teamed them up to the wagon, and their offspring they shut up at the house. 

#### 1 Samuel 6:11 And they put the ark of the LORD upon the wagon, and the place chest, and the mice of gold, and the images of their buttocks. 

#### 1 Samuel 6:12 And {straightened out the oxen} in the journey on the way to Beth-Shemesh, in a road in its going, and they labored, and they turned not aside right nor left; and the satraps of the Philistines went after them unto the borders of Beth-shemesh. 

#### 1 Samuel 6:13 And the ones in Beth-shemesh were harvesting the harvest of wheat in the valley. And they lifted their eyes, and they beheld the ark of the LORD, and they were rejoiced to meet it. 

#### 1 Samuel 6:14 And the wagon entered into the field of Joshua, the one in Beth-shemesh, and it stood there by {stone a great}. And they split the wood of the wagon, and the oxen they offered for a whole burnt-offering to the LORD. 

#### 1 Samuel 6:15 And the Levites brought the ark of the LORD, and the place chest with it, and the items of gold, and put them upon the {stone great}. And the men of Beth-shemesh offered whole burnt-offerings, and they sacrificed sacrifices to the LORD in that day. 

#### 1 Samuel 6:16 And the five satraps of the Philistines saw, and they returned to Ekron in that day. 

#### 1 Samuel 6:17 And these are the {buttocks gold} which {gave back the Philistines} for the torment to the LORD -- for Ashdod one, Gaza one, Ashkelon one, Gath one, Ekron one. 

#### 1 Samuel 6:18 And {mice gold}, according to the number of all the cities of the Philistines, of the five satraps, from the city being solidly fortified, and unto the town of the Perezzite, and unto {stone the great} of which they placed upon it the ark of the covenant of the LORD until this day in the field of Joshua, of the one of Beth-shemesh. 

#### 1 Samuel 6:19 And he struck the men of Beth-shemesh, for they beheld the ark of the LORD. And he struck among them seventy men, and fifty thousand men of the people. And {mourned the people} because the LORD struck among the people {calamity great an exceedingly}. 

#### 1 Samuel 6:20 And they said, the men, the ones from Beth-shemesh, Who shall be able to stand before the LORD, {God holy this}? And to whom shall {ascend the ark of the LORD} of us? 

#### 1 Samuel 6:21 And they sent messengers to the ones dwelling in Kirjath-jearim, saying, {returned The Philistines} the ark of the LORD, and you go down and lead it up unto you! 

#### 1 Samuel 7:1 And {came the men of Kirjath-jearim}, and they led up the ark of the covenant of the LORD. And they brought it into the house of Abinadab on the hill. And {Eleazar his son they sanctified} to guard the ark of the covenant of the LORD. 

#### 1 Samuel 7:2 And it came to pass from which day {was the ark} in Kirjath-jearim, {were multiplied the days}. And they became twenty years; and {looked all the house of Israel} after the LORD. 

#### 1 Samuel 7:3 And Samuel said to all the house of Israel, saying, If with {entire heart your} you turn to the LORD, remove the gods of the aliens from your midst, and the sacred groves, and prepare your hearts to the LORD, and serve him alone! and he will rescue you from out of the hand of the Philistines. 

#### 1 Samuel 7:4 And {removed the sons of Israel} the Baalim, and the sacred groves of Ashtaroth, and served to the LORD alone. 

#### 1 Samuel 7:5 And Samuel said, Gather all Israel unto Mizpeh! and I will pray to the LORD for you. 

#### 1 Samuel 7:6 And {gathered together the people} in Mizpeh, and drew water, and poured it out before the LORD upon the ground. And they fasted in that day, and said, We have sinned against the LORD. And Samuel adjudicated for the sons of Israel in Mizpeh. 

#### 1 Samuel 7:7 And {heard the Philistines} that {were gathered together all the sons of Israel} in Mizpeh. And {ascended the satraps of the Philistines} against Israel. and {heard the sons of Israel}, and they were fearful from the face of the Philistines. 

#### 1 Samuel 7:8 And {said the sons of Israel} to Samuel, Do not remain silent from us! to not yell to the LORD your God, that he shall deliver us from out of the hand of the Philistines. 

#### 1 Samuel 7:9 And Samuel took {lamb suckling one}, and he offered it a whole burnt-offering to the LORD with all the people. And Samuel yelled to the LORD over Israel, and {heeded him the LORD}. 

#### 1 Samuel 7:10 And Samuel was offering the whole burnt-offering. And the Philistines led forward for war against Israel. And the LORD thundered with {voice a great} in that day against the Philistines, and they were confounded, and failed before Israel. 

#### 1 Samuel 7:11 And {came forth the men of Israel} from out of Mizpeh, and they pursued the Philistines, and they struck them unto under Beth-car. 

#### 1 Samuel 7:12 And Samuel took {stone one}, and set it between Mizpeh and between the old city. And he called the name of it, Ebenezer, signifying, Stone of the Helper. And he said, Unto here {helped us the LORD}. 

#### 1 Samuel 7:13 And the LORD humbled the Philistines, and they did not proceed any longer to come unto the border of Israel. And {was the hand of the LORD} against the Philistines all the days of Samuel. 

#### 1 Samuel 7:14 And {were given back the cities} which {took the Philistines} from the sons of Israel -- from Ekron unto Gath. And the border of Israel was removed from the hand of the Philistines. And there was peace between Israel and between the Amorite. 

#### 1 Samuel 7:15 And Samuel adjudicated for Israel all the days of his life. 

#### 1 Samuel 7:16 And he went according to year by year and circled about Beth-el, and Gilgal, and Mizpeh. And he adjudicated for Israel in all these places. 

#### 1 Samuel 7:17 And his returning was unto Ramah; for {was there his house}; and he adjudicated for Israel there, and he built there an altar to the LORD. 

#### 1 Samuel 8:1 And it came to pass as Samuel grew old, that he placed his sons as magistrates in Israel. 

#### 1 Samuel 8:2 And these are the names of his sons. The first-born was Joel, and the name of the second Abiah, magistrates in Beer-sheba. 

#### 1 Samuel 8:3 And {did not go his sons} in his way. And they turned aside after the contribution, and they took bribes, and turned aside ordinances. 

#### 1 Samuel 8:4 And {gathered together the men of Israel}, and they came to Samuel into Ramah. 

#### 1 Samuel 8:5 And they said to him, Behold, you grow old, and your sons do not go in your way. And now place over us a king to adjudicate for us as all the nations! 

#### 1 Samuel 8:6 And {was wicked the matter} in the eyes of Samuel, as they said, Give to us a king to adjudicate for us! And Samuel prayed to the LORD. 

#### 1 Samuel 8:7 And the LORD said to Samuel, Hearken to the voice of the people! as whatever they should speak to you, for it is not you they treat with contempt, but only me they treat with contempt, to not reign over them. 

#### 1 Samuel 8:8 According to all the works which they did to me, from which day I led them from Egypt, and until this day; even as they abandoned me, and served other gods, so they do also to you. 

#### 1 Samuel 8:9 And now hearken to their voice! Only that in testifying you should testify to them, and you shall report to them the ordinance of the king, which shall reign over them. 

#### 1 Samuel 8:10 And Samuel spoke all the words of the LORD to the people, of the ones asking of him for a king. 

#### 1 Samuel 8:11 And he said, This will be the ordinance of the king, of the one reigning over you. Your sons he shall take and put them in his chariots and among his horsemen, and they shall run in front of his chariots. 

#### 1 Samuel 8:12 And he will appoint them for himself as commanders of thousands, and commanders of hundreds, to plow his plowing, and to harvest his harvest, and to gather the vintage of his gathering the crops, and to make items for his warfare, and items for his chariots. 

#### 1 Samuel 8:13 And your daughters he will take for perfumers, and for cooks, and for baking. 

#### 1 Samuel 8:14 And your fields, and your vineyards, and {olive groves your good} he will take and will give to his servants. 

#### 1 Samuel 8:15 And your seeds he will take a tenth, and of your vineyards, and he will give to his eunuchs, and to his servants. 

#### 1 Samuel 8:16 And your menservants, and your maidservants, and {herds your good}, and your donkeys he shall take; and he will take a tenth for his works. 

#### 1 Samuel 8:17 And {of your flocks he will take a tenth}. And you will be to him for servants. 

#### 1 Samuel 8:18 And you shall yell in that day before the face of your king, of which you chose for yourselves; and {will not heed the LORD} you in those days. 

#### 1 Samuel 8:19 And {willed not the people} to hearken to the voice of Samuel. And they said to him, Not so, but let it be that a king will be over us. 

#### 1 Samuel 8:20 And {will be also we} as all the nations. And {shall adjudicate for us king our}, and he shall go forth in front of us, and he will wage our war. 

#### 1 Samuel 8:21 And Samuel heard all the words of the people, and he spoke them into the ears of the LORD. 

#### 1 Samuel 8:22 And the LORD said to Samuel, Hearken to their voice, and let {reign unto them a king}! And Samuel said to the men of Israel, Let {run each man} to his city! 

#### 1 Samuel 9:1 And there was a man from the sons of Benjamin, and his name was Kish, son of Abiel, son of Zeror, son of Bechorath, son of Aphiah, son of a man of Benjamin, {man a mighty} in strength. 

#### 1 Samuel 9:2 And to this one was a son, and his name was Saul, a huge {man goodly}, and there was not among the sons of Israel one good above him. He was head and shoulders and {above high} over all the land. 

#### 1 Samuel 9:3 And {were lost the donkeys of Kish the father of Saul}. And Kish said to Saul his son, Take with yourself one of the servant-lads, and rise up and go and seek the donkeys! 

#### 1 Samuel 9:4 And they went through mount Ephraim. And they went through the land of Shalitha, and they did not find. And they went through the land of Shalim, and it was not. And they went through the land of Benjamin, and they did not find. 

#### 1 Samuel 9:5 And of their coming unto Zuph, and Saul said to his servant-lad with him, Come, for we should return, lest {sparing my father} concerning the donkeys, should be thoughtful concerning us. 

#### 1 Samuel 9:6 And {said to him the servant-lad}, Behold, indeed a man of God is in this city, and the man is honorable, all what ever he should speak, coming shall be at hand. And now, we should go there, so that he should report to us our way, upon which we should go upon it. 

#### 1 Samuel 9:7 And Saul said to his servant-lad with him, Yes, behold, we shall go. But what shall we carry in to the man of God, for the bread loaves have failed from out of our containers, and {much there is not} with us to carry to the man of God that exists to us? 

#### 1 Samuel 9:8 And {proceeded the servant-lad} to answer Saul, and said, Behold, there is found in my hand a fourth shekel of silver; and you shall give it to the man of God, and he shall report to us our way. 

#### 1 Samuel 9:9 And before in Israel, thus said each man in their going to ask God, Come, and we should go to the seer. For the prophet was called by the people before, The Seer. 

#### 1 Samuel 9:10 And Saul said to his servant-lad, {is good your word}. Come, for we should go. And they went into the city of which was there the man, the one of God. 

#### 1 Samuel 9:11 In their ascending the ascent of the city, and they found young women going forth to draw water. And they say to them, Is there here the seer? 

#### 1 Samuel 9:12 And {answered the young women} them, and they said, He is, behold, in front of you. Hasten! For now he comes into the city, because of the day, for a sacrifice today for the people in Bama. 

#### 1 Samuel 9:13 As soon as you enter into the city, thus you shall find him in the city, before his ascending unto Bama to eat; for in no way should {eat the people} until his entering. For this one blesses the sacrifice. And after these things {eat the strangers}. And now, ascend! for on account of the day you shall find him. 

#### 1 Samuel 9:14 And they ascend into the city. And they were entering in the midst of the city, and behold, Samuel came forth for the meeting them, to ascend unto Bama. 

#### 1 Samuel 9:15 And the LORD uncovered the ear of Samuel {day one} before {came to him Saul}, saying, 

#### 1 Samuel 9:16 At this time tomorrow I will send to you a man from the land of Benjamin, and you shall anoint him for ruler over my people Israel, and he shall deliver my people from the hand of the Philistines. For I looked upon the humiliation of my people, for {came their yelling} to me. 

#### 1 Samuel 9:17 And Samuel beheld Saul, and the LORD answered him, Behold, the man whom I said to you, This one shall rule over my people. 

#### 1 Samuel 9:18 And Saul came to Samuel in the midst of the city, and he said, Report indeed to me, of what house is the seer? 

#### 1 Samuel 9:19 And Samuel answered Saul, and said, I am he. Ascend before me unto Bama, and eat with me today! and I will send you in the morning, and all the things in your heart I will report to you. 

#### 1 Samuel 9:20 And concerning the donkeys being lost to you today for three days, you should not put your heart to them, for they are found. And what are the beautiful things of Israel? Is it not to you, and to all the house of your father? 

#### 1 Samuel 9:21 And Saul answered and said, {not a man a son of a Benjamite Am I}, of the lesser chiefdom of the tribes of Israel? And my family least of all the families of Benjamin? And why have you spoken to me concerning this thing? 

#### 1 Samuel 9:22 And Samuel took Saul and his servant-lad, and he brought them into the lodging, and set for them a place among the foremost of the ones being called -- about thirty men. 

#### 1 Samuel 9:23 And Samuel said to the cook, Give to me the portion which I gave to you, which I told you to put it by you. 

#### 1 Samuel 9:24 And {took the cook} the hind quarter, and the part upon it, and placed it before Saul. And Samuel said to Saul, Behold, the leftover; place it before you, and eat! For as a testimony it is placed for you over the people -- pull it off! And Saul ate with Samuel in that day. 

#### 1 Samuel 9:25 And he went down from Bama into the city. And they spread carpets for Saul upon the roof, and he went to bed. 

#### 1 Samuel 9:26 And it came to pass as {ascended the dawn}, that Samuel called to Saul upon the roof, saying, Rise up! and I shall send you out. And Saul rose up, and {went forth he and Samuel} unto outside. 

#### 1 Samuel 9:27 And as they were going down into the uttermost part of the city, that Samuel said to Saul, Speak to the young man, and let him go through in front of us! And you stand here today, and hear the word of God! 

#### 1 Samuel 10:1 And Samuel took the flask, of oil and poured down upon his head, and kissed him. And he said to him, Is it not that {anointed you the LORD} as ruler over his inheritance? 

#### 1 Samuel 10:2 As soon as you should go forth today from me, that you shall find two men near the burying-places of Rachel, on the borders of Benjamin, leaping greatly. And they shall say to you, {have been found the donkeys} which you went to seek. And behold, your father brushed off the matter of the donkeys, and is worried about you, saying, What should I do about my son? 

#### 1 Samuel 10:3 And you shall go forth from there, and beyond. And you shall come unto the oak of Tabor, and you shall find there three men ascending to God unto Beth-el, one taking three kids, and one taking three containers of bread loaves, and one taking a leather bag of wine. 

#### 1 Samuel 10:4 And they shall ask you the things for peace; and they shall give to you two first-fruits of bread loaves, and you shall take them from out of their hand. 

#### 1 Samuel 10:5 And after these things you shall enter unto the hill of God, of which is there the height of the Philistines. And it will take place when ever you should enter there into the city, that you will meet a company of dancers of prophets coming down from out of Bama, and in front of them a stringed instrument, and tambourine, and pipe, and lute; and they are prophesying. 

#### 1 Samuel 10:6 And {shall spring upon you spirit of the LORD}, and you shall prophesy with them, and you shall turn into {man another}. 

#### 1 Samuel 10:7 And it will be whenever {shall come these signs} upon you, do all as much as {should find your hand}, for God is with you! 

#### 1 Samuel 10:8 And you shall go down in front of me unto Gilgal. And behold, I come down to you, to offer a whole burnt-offering, and to sacrifice sacrifice offerings of peace. Seven days you shall stop until my coming to you, and to make known to you what you shall do. 

#### 1 Samuel 10:9 And it came to pass so as {turned his shoulder} to go forth from Samuel, that {converted his God} heart to another. And came to pass all these signs in that day. 

#### 1 Samuel 10:10 And he comes from there unto the hill. And behold, a company of dancers of prophets right opposite him; and {leaped upon him spirit of God}, and he prophesied in the midst of them. 

#### 1 Samuel 10:11 And came to pass all the things being made known to him yesterday and the third day before. And behold, he was in the midst of the prophets prophesying. And {said the people each} to his neighbor, What is this, the thing having happened to the son of Kish? Or is also Saul among the prophets? 

#### 1 Samuel 10:12 And {answered a certain one of them}, and said, And who is his father? On account of this it became for a parable, Might also Saul be among the prophets? 

#### 1 Samuel 10:13 And he completed prophesying, and comes to the hill. 

#### 1 Samuel 10:14 And {said to him his uncle} and to his servant-lad, Where have you gone? And he said, To seek the donkeys, and we saw that they are not around, and we entered unto Samuel. 

#### 1 Samuel 10:15 And {said the uncle} to Saul, Report indeed to me what {said to you Samuel}! 

#### 1 Samuel 10:16 And Saul said to the member of his family, By reporting he reported to me that {were found the donkeys}. But the matter of the kingdom, he did not report to him, what Samuel said. 

#### 1 Samuel 10:17 And Samuel summoned all the people to the LORD in Mizpeh. 

#### 1 Samuel 10:18 And he said to the sons of Israel, Thus said the LORD God of Israel, saying, I led Israel from out of Egypt, and I rescued you from the hand of Pharaoh king of Egypt, and from the hand of all the kingdoms of the ones afflicting you. 

#### 1 Samuel 10:19 And you today treat with contempt your God, who he himself is your deliverer from out of all your bad things, and your afflictions. And you said, But only a king you shall place over us. And now, stand before the LORD according to your tribes and according to your thousands! 

#### 1 Samuel 10:20 And Samuel led forward all the tribes of Israel, and {was chosen by lot the tribe of Benjamin}. 

#### 1 Samuel 10:21 And he led forward the tribe of Benjamin according to family, and {was chosen by lot the family of Matri}. And {was chosen by lot Saul son of Kish}. And he sought him, and he was not found. 

#### 1 Samuel 10:22 And Samuel asked again to the LORD, Shall {come still here the man}? And the LORD said, Behold, he hides among the equipment. 

#### 1 Samuel 10:23 And he ran and took him from there, and placed him in the midst of the people, and he was high above all the people -- head and shoulders and above. 

#### 1 Samuel 10:24 And Samuel said to all the people, You see whom {has chosen for himself the LORD}, that there is not one likened to him among all you? And {knew all the people}, and said, Let {live the king}! 

#### 1 Samuel 10:25 And Samuel spoke to the people the ordinance of the kingship. And he wrote in a scroll, and put it before the LORD. And Samuel sent out all the people, and {went forth each} unto his place. 

#### 1 Samuel 10:26 And Saul went forth unto his house in Gibeah. And {went the sons of power} (whom the LORD touched their hearts) with Saul. 

#### 1 Samuel 10:27 And {sons the mischievous} said, Who is {that shall deliver us this}? And they dishonored him, and did not bring him gifts. And he became one being silent. 

#### 1 Samuel 11:1 And {ascended Nahash the Ammonite}, and camped against Jabish Gilead. And {said all the men of Jabish} to Nahash the Ammonite, Ordain with us a covenant! and we will serve you. 

#### 1 Samuel 11:2 And {said to them Nahash the Ammonite}, By this I will ordain with you a covenant, in the gouging out of all of you {eye the right}, and I will make it for scorn upon all Israel. 

#### 1 Samuel 11:3 And {spoke to him the men of Jabish}, saying, Spare us seven days, and we will send messengers unto every border of Israel. And if there might not be one delivering us, then we will come forth to you. 

#### 1 Samuel 11:4 And {came the messengers} into Gibeah to Saul, and they spoke these words into the ears of the people; and {lifted up all the people} their voice, and they wept. 

#### 1 Samuel 11:5 And behold, Saul came from behind the oxen from out of the field. And Saul said, Why is it that {weep the people}? And they described to him the words of the men of Jabish. 

#### 1 Samuel 11:6 And {sprang up spirit of the LORD} upon Saul, as he heard these words, and {enraged over them his anger was exceedingly}. 

#### 1 Samuel 11:7 And he took two oxen, and dismembered them, and sent them unto every border of Israel by the hand of messengers, saying, Whosoever is not going forth after Saul and after Samuel, according to thus they shall do to his oxen. And there fell a change of state of the LORD upon the people, and they yelled as {man one}. 

#### 1 Samuel 11:8 And he numbered them in Bezek, all the men of Israel -- three hundred thousand, and the men of Judah -- thirty thousand. 

#### 1 Samuel 11:9 And he said to the messengers, to the ones coming, Thus you shall say to the men of Jabish Gilead, Tomorrow there will be deliverance to you at the warming through of the sun. And {came the messengers} into the city, and they reported to the men of Jabish, and they were glad. 

#### 1 Samuel 11:10 And {said the men of Jabish} to Nahash the Ammonite, Tomorrow we shall come forth to you, and you shall do to us what is good before you. 

#### 1 Samuel 11:11 And it came to pass with the morning, that Saul put the people into three companies, and they entered into the midst of the camp in the early morning watch, and they struck the sons of Ammon until {warmed through the day}. And it came to pass, the ones being left behind were scattered, and there was not left behind among them two together. 

#### 1 Samuel 11:12 And {said the people} to Samuel, Who is the one saying, Saul shall not reign over us? Deliver up the men! and we will kill them. 

#### 1 Samuel 11:13 And Saul said, Not shall {die any one} in this day, for today the LORD produced deliverance in Israel. 

#### 1 Samuel 11:14 And Samuel said to the people, saying, Come, we should go unto Gilgal, and we should renew there the kingdom. 

#### 1 Samuel 11:15 And {went all the people} unto Gilgal; and Samuel anointed Saul there as king before the LORD in Gilgal. And he sacrificed there sacrifice offerings and peace offerings before the LORD. And {was glad there Saul} and all the men of Israel greatly. 

#### 1 Samuel 12:1 And Samuel said to every man of Israel, Behold, I hearkened to your voice in all as many things as you said to me, and I gave reign over you a king. 

#### 1 Samuel 12:2 And now, behold, the king travels before you. And I grow old and shall sit. And behold, my sons are among you. And I, behold, I have gone before you from my youth, and until this day. 

#### 1 Samuel 12:3 Behold, I am here. You should respond against me before the LORD, and before his anointed one. Whose calf have I taken? or whose donkey have I taken? or who of you have I tyrannized over? or who have I pressured? or from out of whose hand have I taken an appeasement, or a sandal? Should you respond to me, then I will give it back to you. 

#### 1 Samuel 12:4 And they said to Samuel, You did not wrong us, and you did not tyrannize over us, and you have not taken from {hand anyone's} -- not one thing. 

#### 1 Samuel 12:5 And Samuel said to the people, The LORD is witness among you, and {is witness his anointed one} in this day, that you have not found in my hand anything. And they said, He is witness. 

#### 1 Samuel 12:6 And Samuel said to the people, saying, The LORD is witness, the one preparing Moses and Aaron, and the one leading our fathers out of Egypt. 

#### 1 Samuel 12:7 And now stand, and I will adjudicate for you before the LORD, and I will report to you all the righteousness of the LORD, which he did to you, and to your fathers, 

#### 1 Samuel 12:8 as {entered Jacob and his sons} into Egypt, and {humbled them Egypt}. And {yelled our fathers} to the LORD, and the LORD sent Moses and Aaron. And he led our fathers out of Egypt, and settled them in this place. 

#### 1 Samuel 12:9 And they forgot the LORD their God, and he gave them into the hands of Sisera commander-in-chief of Jabish, king of Hazor, and into the hands of the Philistines, and into the hands of the king of Moab; and they waged war with them. 

#### 1 Samuel 12:10 And they yelled to the LORD, and said, We sinned, for we abandoned the LORD, and we served to the Baalim, and to the sacred groves. And now rescue us from the hand of our enemies! and we will serve you. 

#### 1 Samuel 12:11 And the LORD sent Jerubbaal, and Barak, and Jephthah, and Samuel, and rescued you round about from the hand of your enemies, and you dwell secure. 

#### 1 Samuel 12:12 And you beheld that Nahash king of the sons of Ammon came upon you, and you said, No, but only that a king shall reign over us. And the LORD our God is your king. 

#### 1 Samuel 12:13 And now behold, the king whom you chose and whom you acquire. And behold, the LORD puts over you a king! 

#### 1 Samuel 12:14 If you should fear the LORD, and should serve to him, and should hearken to his voice, and should not contend with the mouth of the LORD, then you should be (even you yourselves, and the king reigning over you) going after the LORD your God. 

#### 1 Samuel 12:15 But if you should not hearken to the voice of the LORD, and should contend with the mouth of the LORD, then {will be the hand of the LORD} against you, and against your king. 

#### 1 Samuel 12:16 And now, stand and behold {thing this great} which the LORD will do in your eyes! 

#### 1 Samuel 12:17 Is it not the harvest of wheat today? I shall call upon the LORD, and he will give thundering sounds and rain. And know and behold! that great is your evil which you did before the LORD, asking for yourselves a king. 

#### 1 Samuel 12:18 And Samuel called upon the LORD; and the LORD gave sounds and rain in that day. And {feared all the people} the LORD exceedingly, and Samuel. 

#### 1 Samuel 12:19 And {said all the people} to Samuel, Pray for your servants to the LORD your God! and in no way we should die, for we added unto all our sins this evil asking for ourselves a king. 

#### 1 Samuel 12:20 And Samuel said to the people, Do not fear! You have done all this evil, except you should not turn aside from following after the LORD. And serve to the LORD with {entire heart your}! 

#### 1 Samuel 12:21 And you should not turn aside after the things being nothing, which achieve nothing, and which shall not rescue, for they are nothing. 

#### 1 Samuel 12:22 For {shall not thrust away the LORD} his people because of {name his great}; for {took the LORD} you to make for a people to himself. 

#### 1 Samuel 12:23 But to me, may it not be to sin against the LORD, to stop praying for you to the LORD. But I will manifest to you the {way good and straight}. 

#### 1 Samuel 12:24 Only fear the LORD, and serve him in truth, and with {entire heart your}! For see what he magnified with you! 

#### 1 Samuel 12:25 And if by evil you should do evil, then you and your king shall be added to your dead. 

#### 1 Samuel 13:1 {was a son a year Saul} in his taking reign, and two years he reigned in Israel. 

#### 1 Samuel 13:2 And {chose for himself Saul} three thousand men from the men of Israel. And there were with Saul two thousand in Michmash, and in the mountain of Beth-el, and a thousand were with Jonathan in Gibeah of Benjamin. And the rest of the people he sent out, each man unto his tent. 

#### 1 Samuel 13:3 And Jonathan struck the Nasib of the Philistines, the one in the hill. And {heard the Philistines}, and Saul trumped the trumpet in all the land, saying, {disregard us The servants}. 

#### 1 Samuel 13:4 And all Israel heard, saying, Saul has smitten the Nasib of the Philistines; and Israel was put to shame by the Philistines. And {ascended up the people} after Saul in Gilgal. 

#### 1 Samuel 13:5 And the Philistines gather together for war against Israel. And they ascend upon Israel for war -- thirty thousand chariots, and six thousand horsemen, and people as the sand by the edge of the sea in the multitude. And they ascend and camp in Michmash opposite according to the south of Beth-aven. 

#### 1 Samuel 13:6 And the man of Israel beheld that they were in a strait {to not lead forward for them}; and {hid the people} in the caves, and in the lairs, and in the rocks, and in the excavations, and in the pits. 

#### 1 Samuel 13:7 And the ones passing over, passed over the Jordan into the land of Gad and Gilead. And Saul still was in Gilgal, and all the people were receded after him. 

#### 1 Samuel 13:8 And he stopped seven days, according to the testimony as Samuel said. And {did not come Samuel} unto Gilgal, and {scattered his people} from him. 

#### 1 Samuel 13:9 And Saul said, Lead forward animals so that I should offer a whole burnt-offering, and peace offerings; and he offered the whole burnt-offering. 

#### 1 Samuel 13:10 And it came to pass as he completed offering the whole burnt-offering, that behold, Samuel arrived. And Saul came forth to meet him, to bless him. 

#### 1 Samuel 13:11 And Samuel said, What have you done? And Saul said, Because I saw that {scattered the people} from me, and you did not come in the testimony of the days as you set in order, and the Philistines were gathered together in Michmash, 

#### 1 Samuel 13:12 and I said, Now {shall come down the Philistines} to me in Gilgal, and the face of the LORD I beseeched not; and I took control myself and offered the whole burnt-offering. 

#### 1 Samuel 13:13 And Samuel said to Saul, It is folly to you that you kept not my commandment which {gave charge to you the LORD}. As the LORD prepared your kingdom over Israel unto the eon. 

#### 1 Samuel 13:14 And now your kingdom shall not stand with you. And the LORD shall seek for himself a man according to his heart. And the LORD shall give charge to him for ruler over his people, for you did not keep as many things as {gave charge to you the LORD}. 

#### 1 Samuel 13:15 And Samuel rose up and went forth from out of Gilgal unto the hill of Benjamin. And Saul numbered the people being found with him, about six hundred men. 

#### 1 Samuel 13:16 And Saul and Jonathan his son, and the people being found with him, stayed in Gibeah of Benjamin. And the Philistines camped in Michmash. 

#### 1 Samuel 13:17 And men came forth to destroy out of the field of the Philistines in three companies. The {company one} looking upon the way of Ophrah, towards the land of Shual. 

#### 1 Samuel 13:18 And {company one} looking upon the way of Beth-horon. And {company one} looking upon the way of Gibeah, the one looking towards Gai, the Zeboim wilderness. 

#### 1 Samuel 13:19 And a fabricator of iron was not found in all the land of Israel, for {said the Philistines}, Perhaps {will make the Hebrews} a broadsword and spear. 

#### 1 Samuel 13:20 And {went down all Israel} into the land of the Philistines, {to forge for each} his own reaping hook, and his utensil, and each his axe, and his sickle. 

#### 1 Samuel 13:21 And {was the gathering of crops} prepared to harvest. But for the items there was a charge of three shekels for the tooth, and to the axe, and to the sickle; the support camp was the same. 

#### 1 Samuel 13:22 And it came to pass in the days of the war, that there was not found broadsword and spear in the hand of all the people, of the one with Saul and Jonathan. But it was found with Saul and Jonathan his son. 

#### 1 Samuel 13:23 And {went forth from the support camp of the Philistines} the place on the other side of Michmash. 

#### 1 Samuel 14:1 And came to pass a day, that {said Jonathan the son of Saul} to the servant-lad carrying his weapons, Come, for we should pass over unto the support camp of the Philistines, the one on that other side; but {to his father he did not report}. 

#### 1 Samuel 14:2 And Saul settled upon the hill under the pomegranate, the one in Migron. And the people, the one with him, was about six hundred men. 

#### 1 Samuel 14:3 And Ahijah son of Ahitub, brother of Ichabod, son of Phinehas, son of Eli the priest of the LORD in Shiloh was carrying the ephod. And the people did not know that Jonathan was gone. 

#### 1 Samuel 14:4 And in the midst of the ford of which Jonathan sought to pass over into the support camp of the Philistines was an extremity rock from here and an extremity rock from there; the name given to the one was Bozez, and the name given to the other was Seneh. 

#### 1 Samuel 14:5 The {extremity one} from the north was going to Michmash, and the {extremity other} from the south was going to Gibeah. 

#### 1 Samuel 14:6 And Jonathan said to the servant-lad carrying his weapons, Come, and we should pass over into the support camp of these uncircumcised, if perchance the LORD may commit to us; for {is not the LORD} holding back to deliver by many or by few. 

#### 1 Samuel 14:7 And {said to him the one carrying his weapons}, You do all what ever your heart should will, turn yourself! Behold, I {with you am}. As your heart my heart. 

#### 1 Samuel 14:8 And Jonathan said, Behold, we pass over to the men, and we will roll down upon them. 

#### 1 Samuel 14:9 If thus they should say to us, Abstain there until whenever we should approach to you. Then we shall stand by ourselves, and in no way shall we ascend unto them. 

#### 1 Samuel 14:10 And If thus they should say to us, Ascend to us! then we will ascend, for {has delivered them the LORD} into our hands. This will be to us the sign. 

#### 1 Samuel 14:11 And they entered both unto the support camp of the Philistines. And {said the Philistines}, Behold, {come forth the Hebrews} from out of their burrows where they hide there. 

#### 1 Samuel 14:12 And {responded the men of the support camp} to Jonathan and to the one carrying his weapons, and they say, Ascend to us! and we will make known to you a thing. And Jonathan said to the one carrying his weapons, You ascend after me! for {has delivered them the LORD} into the hands of Israel. 

#### 1 Samuel 14:13 And Jonathan ascended upon his hands and upon his feet, and the one carrying his weapons after him. And they looked upon the person of Jonathan, and he struck among them, and the one carrying his weapons gave over after him. 

#### 1 Samuel 14:14 And came to pass the {beating first} which Jonathan struck and the one carrying his weapons, was about twenty men by arrows, and by rock slinging, and by pebbles of the plain. 

#### 1 Samuel 14:15 And came to pass a change of state in the camp, and in the field. And all the people, the one in the support camp, and the ones being utterly destroyed, {were startled even they}. And {was distraught the land}, and there took place a change of state because of the LORD. 

#### 1 Samuel 14:16 And {beheld the watchmen of Saul} in Gibeah of Benjamin. And behold, the camp was disturbed on this side and that side. 

#### 1 Samuel 14:17 And Saul said to the people with him, You number yourselves indeed, and see who has gone out from us! And they numbered. And behold, {was not found Jonathan} and the one carrying his weapons. 

#### 1 Samuel 14:18 And Saul said to Ahijah, Bring the ephod! for {was the ark of God} in that day before Israel 

#### 1 Samuel 14:19 And it came to pass as Saul spoke to the priest, that the sound in the camp of the Philistines {going louder went out}, and it multiplied. And Saul said to the priest, Gather together your hands! 

#### 1 Samuel 14:20 And Saul ascended, and all the people with him, and they came unto the battle. And behold, {was broadsword every man's} upon his neighbor, and {confusion great an exceedingly}. 

#### 1 Samuel 14:21 And the servants being yesterday and the third day before with the Philistines, the ones ascending into the camp, turned themselves also to be with Israel, of the ones with Saul and Jonathan. 

#### 1 Samuel 14:22 And every man of Israel, the ones hiding in mount Ephraim, heard that {have fled the Philistines}. And they joined together also themselves after them to battle. And the LORD delivered {in that day Israel}. And the war went through Beth-aven. And all the people being with Saul were about ten thousand men. 

#### 1 Samuel 14:23 And {was the war} dispersing into every city in mount Ephraim. 

#### 1 Samuel 14:24 And Saul knew not {ignorance through great} in that day, and he curses the people, saying, Accursed is the man who shall eat bread until evening -- so I will punish for my enemy. And not {tasted any of the people} bread, and all the land went unto Grove. 

#### 1 Samuel 14:25 And at Grove was an apiary by the face of the field. 

#### 1 Samuel 14:26 And {entered the people} into the apiary, and behold, {went forth honey}. And there was not the one turning his hand to his mouth, for {feared the people} the oath of the LORD. 

#### 1 Samuel 14:27 And Jonathan did not hear in the binding {by an oath by his father the people}. And he stretched out the tip of his staff, of the one in his hand, and he dipped it into the honeycomb of the honey, and he returned his hand to his mouth, and {looked up his eyes}. 

#### 1 Samuel 14:28 And {responded one of the people} and said, By an oath {bound your father} the people, saying, Accursed be the man who shall eat bread today; and {were faint the people}. 

#### 1 Samuel 14:29 And Jonathan knew, and said, {rids father My} the land; {behold for see my eyes} now that I tasted a little something of this honey. 

#### 1 Samuel 14:30 But that if also {ate in eating today the people} of the spoils of their enemies which they found, now even greater would have been the calamity among the Philistines. 

#### 1 Samuel 14:31 And he struck in that day of the Philistines many in Michmash, and {tired the people} exceedingly. 

#### 1 Samuel 14:32 And {advanced the people} unto the spoils. And {took the people} flocks, and herds, and offspring of oxen, and slew them upon the ground, and {ate them the people} with the blood. 

#### 1 Samuel 14:33 And they reported to Saul, saying, {sin the people} against the LORD, to eat with the blood. And Saul said, You sinned. Roll indeed to me here {stone a great}. 

#### 1 Samuel 14:34 And Saul said, Be dispersed among the people! And tell them, Bring here each his calf, and each his sheep, and slay upon this stone and eat! and in no way should they sin against the LORD to eat with the blood. And {brought all the people} each the thing in his hand in the night, and they slew there. 

#### 1 Samuel 14:35 And {built Saul} to the LORD an altar; in this Saul began to build an altar to the LORD. 

#### 1 Samuel 14:36 And Saul said, Let us go down after the Philistines this night, and we shall tear them into pieces until it should illuminate in the morning; and we should not leave behind among them a man. And they said, All that is good before you, you do! And {said the priest}, We should come forward here to God. 

#### 1 Samuel 14:37 And Saul asked God, Shall I go down after the Philistines? Shall you deliver them into the hands of Israel? And he did not answer him in that day. 

#### 1 Samuel 14:38 And Saul said, Bring here all the corners of Israel, and know and behold by whom {has taken place this sin} today! 

#### 1 Samuel 14:39 For as the LORD lives, the one delivering Israel, that if the answer be against Jonathan my son, to death he shall die. And there was no one answering of all the people. 

#### 1 Samuel 14:40 And he said to every man of Israel, You will be for one part, and I and Jonathan my son will be for one part. And {said the people} to Saul, {the good thing before you Do}! 

#### 1 Samuel 14:41 And Saul said, O LORD God of Israel, give manifestations! And Saul was chosen by lot and Jonathan, and {went forth free the people}. 

#### 1 Samuel 14:42 And Saul said, Throw the lot between me and between Jonathan my son, whomever the LORD should choose by lot let him die! And they threw lots between him and between Jonathan, and Jonathan was chosen by lot. 

#### 1 Samuel 14:43 And Saul said to Jonathan, Report to me what you have done! And {reported to him Jonathan}, saying, In tasting, I tasted with the tip of the staff, the one in my hand, a little honey; and behold, I die. 

#### 1 Samuel 14:44 And {said to him Saul}, Thus {do to me God}, and thus add yet again, that in death {shall die today Jonathan}. 

#### 1 Samuel 14:45 And {said the people} to Saul, Shall today {die to death the one executing deliverance great this in Israel}? Kindness, as lives the LORD, there shall not fall of the hair of his head upon the ground, for the mercy of God was performed in this day. And {prayed the people} for Jonathan in that day, and he did not die. 

#### 1 Samuel 14:46 And Saul ascended from going after the Philistines. And the Philistines went forth unto their place. 

#### 1 Samuel 14:47 And Saul obtained by lot to reign over Israel. And he waged war round about with all his enemies -- against Moab, and against the sons of Ammon, and against the sons of Edom, and against the kings of Zobah, and against the Philistines. Wherever he turned, he was delivered. 

#### 1 Samuel 14:48 And he acted powerfully, and he struck Amalek, and he delivered Israel from out of the hand of the ones trampling him. 

#### 1 Samuel 14:49 And {were the sons of Saul} Jonathan, and Ishui, and Melchi-shua. And the names {two daughters of his} -- the name of the first-born was Merab, and the name of the second was Michal. 

#### 1 Samuel 14:50 And the name of Saul's wife was Ahinoam daughter of Ahimaaz. And the name to his commander-in-chief was Abner son of Ner, son of a member of the family of Saul. 

#### 1 Samuel 14:51 And Kish was the father of Saul, and Ner the father of Abner son of of Abiel. 

#### 1 Samuel 14:52 And {was the war} strong against the Philistines all the days of Saul. And Saul in beholding any {man mighty}, and any man being a son of power, that he gathered them to himself. 

#### 1 Samuel 15:1 And Samuel said to Saul, {me has sent the LORD} to anoint you as king over Israel his people. And now hear the voice of the saying of the LORD! 

#### 1 Samuel 15:2 Thus said the LORD of hosts, Now I shall punish what Amalek did to Israel, when he met him in the way ascending out of Egypt. 

#### 1 Samuel 15:3 And now, go! and you shall strike Amalek, and you shall utterly destroy him, and all the things of his. And you shall devote him to consumption, and all the things of his; and in no way shall you spare over him. And you shall kill from man and unto woman, and from infant and unto one nursing; and from calf and unto sheep, and from camel and unto donkey. 

#### 1 Samuel 15:4 And Saul gave exhortation to the people. And he numbered them in Gilgal -- two hundred thousand of the ranks, and ten thousand of the men of Judah. 

#### 1 Samuel 15:5 And Saul came unto the city of Amalek, and laid in wait by the rushing stream. 

#### 1 Samuel 15:6 And Saul said to the Kenite, You go forth, and turn away from the midst of Amalek! lest I add you with him, for you executed mercy with the sons of Israel in their ascending from out of Egypt. And {turned away the Kenite} from the midst of Amalek. 

#### 1 Samuel 15:7 And Saul struck Amalek from Havilah unto Shur at the face of Egypt. 

#### 1 Samuel 15:8 And he seized Agag king of Amalek alive. And all his people he utterly destroyed by the mouth of the broadsword. 

#### 1 Samuel 15:9 And {preserved Saul and the people} Agag, and the good ones of the flocks, and of the herds, and of the foods, and of the vineyards, and all the good things; and they did not want to utterly destroy them. And every work being a disgrace, and being treated with contempt they utterly destroyed. 

#### 1 Samuel 15:10 And came to pass the word of the LORD to Samuel, saying, 

#### 1 Samuel 15:11 I have changed my mind for Saul to reign as king, for he turned away from following after me; and my words he did not give heed to. And Samuel was depressed, and yelled to the LORD the entire night. 

#### 1 Samuel 15:12 And Samuel rose early and went to meet Israel in the morning. And it was reported to Samuel, saying, Saul comes to Carmel. And behold, he has raised up to himself a hand, and turned his chariot, and went down into Gilgal. 

#### 1 Samuel 15:13 And Samuel came to Saul. And {said to him Saul}, Blessed are you to the LORD. I established all as many things as the LORD spoke. 

#### 1 Samuel 15:14 And Samuel said, And what is the sound of this flock in my ears, and the sound of the oxen of which I hear? 

#### 1 Samuel 15:15 And Saul said, From out of Amalek I brought them, which {procured the people}, the most excellent of the flocks and of the herds, so as it may be a sacrifice to the LORD your God, and the rest I utterly destroyed. 

#### 1 Samuel 15:16 And Samuel said to Saul, Spare! and I will report to you what the LORD spoke to me in the night. And he said to him, Speak! 

#### 1 Samuel 15:17 And Samuel said to Saul, Were you not small, even you, before yourself for taking the lead of the chiefdom of the tribes of Israel? And {anointed you the LORD} for king over Israel. 

#### 1 Samuel 15:18 And {sent you the LORD} on the journey. And he said to you, Go! and utterly destroy Amalek the ones sinning against me! and you shall war against them until you should have finished them. 

#### 1 Samuel 15:19 And why did you not hearken to the voice of the LORD, but advanced upon the spoils, and did the wicked thing before the LORD? 

#### 1 Samuel 15:20 And Saul said to Samuel, Because of my hearing the sound of the people, and I went in the way in which {sent me the LORD}. And I brought Agag, king of Amalek, and I utterly destroyed Amalek. 

#### 1 Samuel 15:21 And {took the people} of the spoils of the flocks and the herds, the first-fruits of the offering for consumption, to sacrifice before the LORD our God in Gilgal. 

#### 1 Samuel 15:22 And Samuel said, Does {want the LORD} whole burnt-offerings and sacrifices, as compared to hearing the voice of the LORD, no. Behold, hearkening is better than sacrifice, and heeding over the fat of rams. 

#### 1 Samuel 15:23 For sin is as an omen, {grief and miseries teraphim bring upon}. Because you treated with contempt the word of the LORD, even {treats you with contempt the LORD} to not be king over Israel. 

#### 1 Samuel 15:24 And Saul said to Samuel, I have sinned, that I violated the word of the LORD, and the saying by you; for I feared the people, and I hearkened to their voice. 

#### 1 Samuel 15:25 And now, take away indeed my sin, and return with me! and I shall do obeisance to the LORD your God. 

#### 1 Samuel 15:26 And Samuel said to Saul, I shall not return with you. For you treated with contempt the saying of the LORD, and {shall treat you with contempt the LORD} to not be king over Israel. 

#### 1 Samuel 15:27 And Samuel turned his face to go forth, and Saul took hold of the border of his doubled garment, and tore it. 

#### 1 Samuel 15:28 And {said to him Samuel}, the LORD tore your kingdom from Israel, from out of your hand today, and he shall give it to your neighbor, to the one good over you. 

#### 1 Samuel 15:29 And Israel shall be divided into two, and he shall not turn, nor shall {change his mind the holy one of Israel}, for not as a man is he to change the mind. 

#### 1 Samuel 15:30 And Saul said, I have sinned, but glorify me before the elders of my people, and before Israel, and return with me! and I will do obeisance to the LORD your God. 

#### 1 Samuel 15:31 And Samuel returned behind Saul, and he did obeisance to the LORD. 

#### 1 Samuel 15:32 And Samuel said, Bring to me Agag king of Amalek. And {came forward to him Agag} trembling. And Agag said, Is {thus bitter death}? 

#### 1 Samuel 15:33 And Samuel said to Agag, As {made childless women broadsword your}, thus {shall be made childless among women mother your}. And Samuel slew Agag in the presence of the LORD in Gilgal. 

#### 1 Samuel 15:34 And Samuel went forth unto Ramah, and Saul ascended unto his house in Gibeah. 

#### 1 Samuel 15:35 And {did not proceed Samuel} to see Saul until the day of his death, for Samuel mourned over Saul. And the LORD repented that Saul reigned over Israel. 

#### 1 Samuel 16:1 And the LORD said to Samuel, Until when do you mourn for Saul, and I treat him with contempt to not reign over Israel? Fill your horn with oil, and come! I shall send you to Jesse, unto Beth-lehem. For I have seen one among his sons to me for a king. 

#### 1 Samuel 16:2 And Samuel said, How should I go, for Saul shall hear and shall kill me? And the LORD said, Take in your hand a heifer of the oxen! And you shall say, {to sacrifice to the LORD I come}. 

#### 1 Samuel 16:3 And you shall call Jesse and his sons to the sacrifice, and I shall make known to you what you shall do. And you shall anoint to me whom ever I should tell to you. 

#### 1 Samuel 16:4 And Samuel did all as much as the LORD said. And he came unto Beth-lehem, and startled the elders of the city meeting him. And they said, {for peace Is your entrance}? 

#### 1 Samuel 16:5 And he said, Peace, {to sacrifice to the LORD I come}. Sanctify yourselves and recline with me today for the sacrifice! And he sanctified Jesse and his sons, and he called them to the sacrifice. 

#### 1 Samuel 16:6 And it came to pass in their entering, that he beheld Eliab, and said, None other than {is before the LORD his anointed}. 

#### 1 Samuel 16:7 And the LORD said to Samuel, You should not look upon his appearance, nor unto the manner of his greatness, for I treat him with contempt; for not as {shall look a man} shall God see. For man shall see on the surface, but God shall see into the heart. 

#### 1 Samuel 16:8 And Jesse called Abinadab, and he went by the face of Samuel. And he said, Nor this one the LORD chose. 

#### 1 Samuel 16:9 And Jesse caused to pass by Shammah. And he said, Nor in this one the LORD chose. 

#### 1 Samuel 16:10 And Jesse caused to pass by {seven sons his} before Samuel. And Samuel said to Jesse, {chose not The LORD} among these. 

#### 1 Samuel 16:11 And Samuel said to Jesse, Have {ceased the boys}? And Jesse said, There yet is the lesser, behold, he tends among the flock. And Samuel said to Jesse, Send and take him! for in no way shall we lie down to eat until he comes here. 

#### 1 Samuel 16:12 And he sent, and brought him. And he was ruddy with beauty of the eyes, and good to the sight. And the LORD said to Samuel, Rise up, anoint him! for this it is. 

#### 1 Samuel 16:13 And Samuel took the horn of oil, and he anointed him in the midst of his brothers. And {sprang up spirit of the LORD} upon David from that day and forward. And Samuel rose up and went forth unto Ramah. 

#### 1 Samuel 16:14 And spirit of the LORD left from Saul, and {smothered him spirit a ferocious from the LORD}. 

#### 1 Samuel 16:15 And {said the servants of Saul} to him, Behold, {spirit a ferocious} from the LORD smothers you. 

#### 1 Samuel 16:16 Let speak indeed, O lord, your servants before you! And let them seek for our lord a man knowing to strum with a lute! And it will be when the {be unto you spirit ferocious} by God, that he should strum with his lute, and {good to you it will be}. 

#### 1 Samuel 16:17 And Saul said to his servants, Look indeed for me for a man rightly skilled for strumming, and bring him to me! 

#### 1 Samuel 16:18 And answered one of his servant-lads, and said, Behold, I have seen the son of Jesse the Beth-lehemite, and he knows to strum, and the man is discerning, and a warrior, and wise in word, and the man is good to the sight, and the LORD is with him. 

#### 1 Samuel 16:19 And Saul sent messengers to Jesse, saying, Send out to me David your son, the one among your flock. 

#### 1 Samuel 16:20 And Jesse took an ass, and put upon it a homer of bread loaves, and a leather bag of wine, and {kid of the goats one}, and sent them by the hand of David his son to Saul. 

#### 1 Samuel 16:21 And David entered to Saul, and stood before him, and loved him exceedingly. And he became to him the one lifting his weapons. 

#### 1 Samuel 16:22 And Saul sent to Jesse, saying, Let {stand indeed David} before me, for he found favor in my eyes! 

#### 1 Samuel 16:23 And it came to pass in the being {from God spirit a ferocious} upon Saul, that David took the lute, and strummed with his hand. And Saul was refreshed, and it was good to him, and {abstained from him the spirit ferocious}. 

#### 1 Samuel 17:1 And {gathered together the Philistines} their camps for war, and they gathered together at Shochoh of Judea, and they camped in between Shochoh and between Azekah in Ephes-dammin. 

#### 1 Samuel 17:2 And Saul and the men of Israel gathered together, and they camped in the valley of the terebinth tree, these and these. And they deployed for war right opposite the Philistines. 

#### 1 Samuel 17:3 And the Philistines stood upon the mountain here on that side. And Israel stood upon the mountain here on this side, and the canyon was between them. 

#### 1 Samuel 17:4 And there came forth {man a mighty} from out of the battle array of the Philistines, Goliath was the name to him, from Gath. His height was four cubits and a span. 

#### 1 Samuel 17:5 And {helmet a bronze} was upon his head, and {a chest plate of chain-work he put on}. And the weight of his chest plate was five thousand shekels of brass and iron. 

#### 1 Samuel 17:6 And his leg coverings were of brass upon his legs, and a shield of brass in between his shoulders. 

#### 1 Samuel 17:7 And the shaft of his spear was as the weaver's beam of one weaving; and his lance was six hundred shekels of iron. And the one lifting his weapons went before him. 

#### 1 Samuel 17:8 And he stood and yelled out to the battle array of Israel, and said to them, Why are you come forth to deploy for battle right opposite us? {not I Am} a Philistine, and you are Hebrews of Saul? Choose for yourselves a man, and let him come down to me! 

#### 1 Samuel 17:9 And if he should be able to battle against me, and strike me, then we will be to you for servants. But if I shall overpower him, and shall strike him, you will be to us for servants, and you shall serve us. 

#### 1 Samuel 17:10 And {said the Philistine}, Behold, I berate the battle array of Israel today in this day. Give to me a man, and we will fight {one on one both}! 

#### 1 Samuel 17:11 And Saul heard, and all Israel, {sayings of the Philistine these}, and they were startled, and feared exceedingly. 

#### 1 Samuel 17:12 And David was a son {man of an Ephrathite}; this one was from Beth-lehem Judah, and the name to him was Jesse, and to him were eight sons. And the man was old in days of Saul arriving in the year. 

#### 1 Samuel 17:13 And {went the three sons of Jesse elder} after Saul unto the war. And the name of his sons, of the ones having gone unto the war -- Eliab his first-born, and the second Abinadab, and the third Shammah. 

#### 1 Samuel 17:14 And David himself was the younger, and the three, the elder went after Saul. 

#### 1 Samuel 17:15 And David departed and returned from Saul to tend the sheep of his father in Beth-lehem. 

#### 1 Samuel 17:16 And {came forward the Philistines} rising early and arriving late, and set up before Israel forty days. 

#### 1 Samuel 17:17 And Jesse said to David his son, Take indeed to your brothers the ephah of this toasted grain, and {ten bread loaves these}, and run unto the camp to your brothers. 

#### 1 Samuel 17:18 And {ten cheeses of the milk these} you shall bring to the commander of a thousand, and {your brothers you shall visit} concerning their peace; and as much as they need you shall know. 

#### 1 Samuel 17:19 And Saul, and they, and every man of Israel in the valley of the oak were warring with the Philistines. 

#### 1 Samuel 17:20 And David rose early in the morning, and he left the sheep for guard, and he took the things and departed as commanded to him by Jesse. And he came unto the battleline and the army, the one going forth unto the battle array. 

#### 1 Samuel 17:21 And they shouted for the war, and Israel deployed, and the Philistines deployed at the opposite of the battle array. 

#### 1 Samuel 17:22 And David relieved his items from himself unto the hand of the provisions officer, and he ran to the battle array, and he came and asked his brothers the things for peace. 

#### 1 Samuel 17:23 And with his speaking with them, and behold, a man in the middle ascended (the name given to him was Goliath the Philistine from Gath) from the battle array of the Philistines, and he spoke according to these words, and David heard. 

#### 1 Samuel 17:24 And every man of Israel in their seeing the man feared greatly, and fled from his face. 

#### 1 Samuel 17:25 And {said a man from Israel}, Did you see the man, this one ascending? {so as to berate Israel He ascended}. And it will be a man who ever should strike him, {shall enrich him the king} {riches in great}, and {his daughter he will give} to him, and the house of his father he will make free in Israel. 

#### 1 Samuel 17:26 And David said to the men, the ones standing with him, saying, What shall be done to the man who ever should strike that Philistine, and should remove scorn from Israel? For who is {Philistine this uncircumcised} who berates the battle array of the living God? 

#### 1 Samuel 17:27 And {said to him the people} according to this word, saying, Thus it shall be done to the man who ever should strike him. 

#### 1 Samuel 17:28 And {heard Eliab brother his older} in his speaking to the men, and {became angry with rage Eliab} with David, and said, Why is this you came down, and for why did you leave {small sheep those} in the wilderness? I know your pride, and the evil of your heart; that because of seeing the war you came down. 

#### 1 Samuel 17:29 And David said, What did I do now? {not a word Is it}? 

#### 1 Samuel 17:30 And he turned from him unto {rank another}, and he said thus. And they answered to him according to the word formerly. 

#### 1 Samuel 17:31 And they heard the words of David which he spoke, and they were announced before Saul. 

#### 1 Samuel 17:32 And David said to Saul, Let not {be downcast the heart of my master} over him! Your servant will go and do battle with this Philistine. 

#### 1 Samuel 17:33 And Saul said to David, In no way shall you be able to go against this Philistine to battle against him, for you are a boy, and he is a man of war from his youth. 

#### 1 Samuel 17:34 And David said to Saul, {tending was Your servant} for his father among the flock. And whenever {came the lion} and the bear, and it took a sheep from out of the herd, 

#### 1 Samuel 17:35 that I went forth after him, and struck him, and pulled it out of his mouth; and if he rose up against me, I held his throat and struck him, and I put him to death. 

#### 1 Samuel 17:36 And {the lion and the bear beat your servant}, and {will be Philistine this uncircumcised} as one of these who berates the battle array of the living God. 

#### 1 Samuel 17:37 And David said, The LORD who rescued me from out of the hand of the lion, and from out of the hand of the bear, he will rescue me from out of the hand {Philistine of this uncircumcised}. And Saul said to David, Go and the LORD will be with you! 

#### 1 Samuel 17:38 And Saul clothed David with his uniform, and {helmet a brass put} upon his head, and clothed him with a chest plate. 

#### 1 Samuel 17:39 And David tied on his sword upon himself. And {tired walking David} in the proceeding with them, for he was inexperienced. And David said to Saul, In no way shall I be able to go in these, for I have not tested them; and they removed them from him. 

#### 1 Samuel 17:40 And he took his rod in his hand, and chose for himself five {stones smooth} from out of the rushing stream. And he put them in the canteen of the shepherd, the one being his, for a collection. And his sling was in his hand; and he went forward to the man, the Philistine. 

#### 1 Samuel 17:41 And {went the Philistine}, going and approaching to David. And the man, the one caring the oblong shield was before him. And {looked the Philistine}. 

#### 1 Samuel 17:42 And Goliath beheld David, and he treated him with contempt, for he was a boy, and he was ruddy with beauty of eyes. 

#### 1 Samuel 17:43 And {said the Philistine} to David, {As a dog Am I} that you come with a rod and stones? And {cursed the Philistine} David by his gods. 

#### 1 Samuel 17:44 And {said the Philistine} to David, Come here to me! and I will give your flesh to the birds of heaven, and to the wild beasts of the earth. 

#### 1 Samuel 17:45 And David said to the Philistine, You come to me with a broadsword, and with a spear, and with a shield. But I come to you in the name of the LORD God of hosts, the God of the battle array of Israel, whom you berate today. 

#### 1 Samuel 17:46 And {shall shut you up the LORD} today by my hand, and I will kill you, and I will remove your head from you, and I will give your carcass and the carcasses of the camp of the Philistines in this day to the birds of the heaven, and to the wild beasts of the earth; and {shall know all the earth} that God is in Israel. 

#### 1 Samuel 17:47 And {shall know all this assembly} that it is not by the broadsword, and spear the LORD delivers; for {is of the LORD the war}, and the LORD shall deliver you into our hands. 

#### 1 Samuel 17:48 And {rose up the Philistine}, and went and approached to meet with David. And David hastened, and came forth even himself for the battle array for meeting the Philistine. 

#### 1 Samuel 17:49 And David stretched out his hand into the canteen, and he took from there {stone one}, and he slung it, and he struck the Philistine in his forehead; and {penetrated the stone} unto his forehead; and he fell upon his face upon the ground. 

#### 1 Samuel 17:50 And David powered over the Philistine with the sling, and with the stone in that day. And he struck the Philistine, and he killed him; and a broadsword was not in the hand of David. 

#### 1 Samuel 17:51 And David ran and stood over him, and he took his broadsword, and pulled it out of its sheath, and he put him to death, and he removed his head. And {beheld the Philistines} that {has died their mighty one}, and they fled. 

#### 1 Samuel 17:52 And {rose up the men of Israel and Judah}, and shouted, and pursued after the Philistines unto the entrance of Gath, and unto the gate of Ekron. And {fell the slain of the Philistines} in the way of the gates, and unto Gath, and unto Ekron. 

#### 1 Samuel 17:53 And {returned the men of Israel} turning aside going after the Philistines, and they plundered their camps. 

#### 1 Samuel 17:54 And David took the head of the Philistine, and he brought it unto Jerusalem. And his weapons he put in his tent. 

#### 1 Samuel 17:55 And as Saul saw David going forth for meeting the Philistine, he said to Abner the ruler of the force, Whose son is this young man, Abner? And Abner responded and said, {should live your soul}, O my lord king, I do not know. 

#### 1 Samuel 17:56 And the king said, You ask whose son this young man is? 

#### 1 Samuel 17:57 And as David returned having struck the Philistine, {received him Abner} and brought him in before Saul. And the head of the Philistine was in his hand. 

#### 1 Samuel 17:58 And {said to him Saul}, Whose son are you young man? And David said, A son of your servant Jesse of Beth-lehem. 

#### 1 Samuel 18:1 And it came to pass as he finished speaking to Saul, that the soul of Jonathan was bound together to the soul of David; and {loved him Jonathan} according to his own soul. 

#### 1 Samuel 18:2 And {received him Saul} in that day, and he did not allow him to return to the house of his father. 

#### 1 Samuel 18:3 And {ordained Jonathan and David} a covenant, for he loved him according to his soul. 

#### 1 Samuel 18:4 And Jonathan took off the outer garment, the one upon him, and he gave it to David, and his uniform, unto his broadsword, and the bow, and his belt. 

#### 1 Samuel 18:5 And David went forth perceiving in all what ever {sent him Saul}. And {placed him Saul} over the men of war. And he pleased in the eyes of all the people, and also even in the eyes of the manservants of Saul. 

#### 1 Samuel 18:6 And it came to pass in his entering, when David returned striking the Philistine, that {came forth the women} joining in a dance and singing, to meet Saul the king from out of all the cities of Israel, with tambourines, and with joyfulness, and with cymbals. 

#### 1 Samuel 18:7 And {took the lead the women} playing, and said, Saul struck his thousands, and David his ten thousands. 

#### 1 Samuel 18:8 And Saul was provoked to anger, and {appeared as sorry state the thing an exceeding} before Saul concerning this word. And he said, They gave to David the ten thousands, and to me they gave the thousands. And what is there to him besides the kingdom? 

#### 1 Samuel 18:9 And Saul was suspecting David from that day and beyond. 

#### 1 Samuel 18:10 And it came to pass of the next day, that {fell spirit from God a ferocious} upon Saul, and he prophesied in the midst of his house; And David strummed with his hand as according to each day; and the wooden spear was in the hand of Saul. 

#### 1 Samuel 18:11 And Saul lifted the wooden spear and said, I will strike into David and into the wall. And David turned aside from his presence twice. 

#### 1 Samuel 18:12 And Saul feared from the face of David, for the LORD was with him. And {from Saul he left}. 

#### 1 Samuel 18:13 And {removed him Saul} from himself, and placed him to himself as a commander of a thousand. And he went forth and entered before the people. 

#### 1 Samuel 18:14 And David was {in all his ways perceiving}, and the LORD was with him. 

#### 1 Samuel 18:15 And Saul beheld as he perceived exceedingly, and he was cautious of his person. 

#### 1 Samuel 18:16 And all Israel and Judah loved David, for he entered and went forth before the face of the people. 

#### 1 Samuel 18:17 And Saul said to David, Behold, my daughter, the elder, Merab. I will give her to you for a wife, only become to me for a son of power, and wage war of the battles of the LORD! And Saul said, Let not {be my hand} upon him, but let {be on him the hand of the Philistines}! 

#### 1 Samuel 18:18 And David said to Saul, Who am I, and what is the life of the kin of my father in Israel, that I shall be an in-law of the king? 

#### 1 Samuel 18:19 And it came to pass in the time of the giving Merab daughter of Saul to David, that he gave her to Adriel the Meholathite for a wife. 

#### 1 Samuel 18:20 And {loved Michal the daughter of Saul} David. And it was reported to Saul, and {was pleasing in his eyes the thing}. 

#### 1 Samuel 18:21 And Saul said, I will give her to him, and she shall be to him for an obstacle, and {shall be upon him the hand of the Philistines}. And Saul said to David a second time, You shall ally to me by marriage today. 

#### 1 Samuel 18:22 And Saul gave charge to his servants, saying, You speak in private to David, saying, Behold, {want is towards you the king's}, and all his servants love you, and thus you be allied by marriage to the king! 

#### 1 Samuel 18:23 And {spoke the servants of Saul} into the ears of David these things. And David said, {the light thing Is it} in your eyes to be allied by marriage to the king? And I am {man a humble}, and not esteemed? 

#### 1 Samuel 18:24 And {reported the servants of Saul} to him according to these words which David spoke. 

#### 1 Samuel 18:25 And Saul said, Thus shall you say to David, {does not want The king} a dowry, but only a hundred foreskins of the Philistines, to avenge against the enemies of the king. And Saul devised to put David into the hands of the Philistines. 

#### 1 Samuel 18:26 And {told the servants of Saul} to David these things. And {was straightened the word} in the eyes of David to be allied by marriage to the king. And {were not fulfilled the days}. 

#### 1 Samuel 18:27 And David rose up and went himself and his men, and he struck among the Philistines two hundred men. And he brought their foreskins, and fulfilled them to the king; and he becomes allied by marriage to the king; and {gives to him Saul} Michal his daughter for a wife. 

#### 1 Samuel 18:28 And Saul beheld and knew that the LORD was with David. And Michal his daughter and all Israel loved him. 

#### 1 Samuel 18:29 And Saul proceeded to fear from before David still. And Saul became hating David all the days. 

#### 1 Samuel 18:30 And {came forth the rulers of the Philistines}, and it came to pass from {fit expedition their}, that David perceived above all the servants of Saul. And {esteemed his name was greatly}. 

#### 1 Samuel 19:1 And Saul spoke to Jonathan his son, and to all his servants, to put David to death. 

#### 1 Samuel 19:2 And Jonathan the son of Saul took to David exceedingly. And Jonathan reported to David, saying, Saul my father seeks to put you to death; and now be on guard tomorrow morning, and hide and stay in secret! 

#### 1 Samuel 19:3 And I will come forth and stand next to my father in the field of which ever you should be there. And I will speak concerning you to my father, and I will see whatever might be, and I will report it to you. 

#### 1 Samuel 19:4 And Jonathan spoke concerning David good things to Saul his father, and said to him, {not Let sin the king} against his servant David! for he sinned not against you, and his works {proper are exceedingly}. 

#### 1 Samuel 19:5 And he put his life in his hand, and struck the Philistine. And the LORD executed {deliverance a great}. And all Israel beheld and rejoiced. And why do you sin against {blood innocent} to put to death David without charge? 

#### 1 Samuel 19:6 And Saul hearkened to the voice of Jonathan, and Saul swore by an oath, saying, As the LORD lives shall he die, no. 

#### 1 Samuel 19:7 And Jonathan called David, and reported to him all these things. And Jonathan brought David to Saul, and he was before him as he was yesterday and the third day before. 

#### 1 Samuel 19:8 And {proceeded the war} to take place, and David grew strong and waged war against the Philistines; and he struck them {beating great an exceedingly}; and they fled from his face. 

#### 1 Samuel 19:9 And {came spirit of the LORD a ferocious} upon Saul from the LORD, and he was in his house sitting, and a spear was in his hand. And David strummed with his hands. 

#### 1 Samuel 19:10 And Saul sought to strike {with a wooden spear David}. And David departed from the face of Saul, and he struck with the spear into the wall. And David withdrew and was delivered in that night. 

#### 1 Samuel 19:11 And Saul sent messengers to the house of David to guard him, so as to put him to death in the morning. And it was reported to David by Michal his wife, saying, If you shall not preserve your life this night, tomorrow you shall be put to death. 

#### 1 Samuel 19:12 And Michal let down David through the window. And he went forth, and fled, and escaped. 

#### 1 Samuel 19:13 And Michal took the statues, and put them upon the bed; and a round pillow of hair of goats she put by his head, and covered them with a cloak. 

#### 1 Samuel 19:14 And Saul sent messengers to take David. And she spoke of him to be unwell. 

#### 1 Samuel 19:15 And Saul sent messengers to see David, saying, Lead him upon the bed to me to put him to death. 

#### 1 Samuel 19:16 And {come the messengers}, and behold, the statues upon the bed, and round pillow of hair of the goats by his head. 

#### 1 Samuel 19:17 And Saul said to Michal, Why thus did you mislead me, and send out my enemy, and he came through safe? And Michal said to Saul, He said to me, Send me! for if not I shall put you to death. 

#### 1 Samuel 19:18 And David fled, and was delivered, and comes to Samuel in Ramah. And he reports to him all as much as {did to him Saul}. And {went Samuel and David} and stayed in Naioth in Ramah. 

#### 1 Samuel 19:19 And it was reported to Saul, saying, Behold, David is in Naioth in Ramah. 

#### 1 Samuel 19:20 And Saul sent messengers to take David. And coming they saw the assembly of the prophets prophesying, and Samuel stood ordained over them. And {became upon the messengers of Saul spirit of God}, and they prophesied, even they. 

#### 1 Samuel 19:21 And it was reported to Saul, and he sent {messengers other}, and they prophesied, even they. And Saul proceeded to send messengers a third time, and they prophesied -- even they. 

#### 1 Samuel 19:22 And {was enraged in anger Saul}, and went even himself unto Ramah. And he comes unto well of the threshing-floor of the one in Sechu. And he asked and said, Where are Samuel and David? And they said, Behold, in Naioth in Ramah. 

#### 1 Samuel 19:23 And he went from there into Naioth in Ramah. And there came upon him spirit of God. And he went going, and prophesied unto his coming unto Naioth in Ramah. 

#### 1 Samuel 19:24 And he took off his clothes, and he prophesied before Samuel. And he fell naked {entire day that}, and {entire night that}. Because of this they said, Is also Saul among the prophets? 

#### 1 Samuel 20:1 And David ran away from Naioth in Ramah, and he came before Jonathan. And he said, What have I done, and what is my offence, and how have I sinned before your father, that he seeks anxiously my life? 

#### 1 Samuel 20:2 And {said to him Jonathan}, Far be it to you. In no way shall you die. Behold, in no way shall {do my father} a thing, great or small, and shall not reveal it in my ear. And why shall {hide my father} from me this thing? {not is This} so. 

#### 1 Samuel 20:3 And David answered Jonathan, and he said, In perceiving, {sees your father} that I have found favor in your eyes. And he said, Let not {know this Jonathan}, lest he should prefer him! But as lives the LORD, and as lives your soul, that as I said, the space is filled up between me and between your father unto death. 

#### 1 Samuel 20:4 And Jonathan said to David, What does {desire your soul}, and what should I do for you? 

#### 1 Samuel 20:5 And David said to Jonathan, Behold indeed, it is a new moon tomorrow, and I in sitting should sit down with the king to eat. And you shall send me, and I shall be hid in the plain until afternoon. 

#### 1 Samuel 20:6 If in numbering {should number me missing your father}, then you shall say, In asking pardon {asks pardon of me David} to run unto Beth-lehem his city, for the sacrifice of the feast days is there for the entire tribe. 

#### 1 Samuel 20:7 If thus he should say, Fine, then it will be peace to your servant. And if harshly he should answer to you, know that {is completed evil} by him! 

#### 1 Samuel 20:8 And you will do mercy with your servant, for you brought your servant into a covenant of the LORD with yourself. And if there is injustice in your servant, {put me to death you}! And {unto your father why thus should you bring me}? 

#### 1 Samuel 20:9 And Jonathan said, Far be it to you; for if in knowing I should know that {is completed the evil} by my father to come against you, then would I not report it to you? 

#### 1 Samuel 20:10 And David said to Jonathan, Who shall report to me if {should answer your father} harshly? 

#### 1 Samuel 20:11 And Jonathan said to David, You go! for we should go out in the field. And they went forth both into the field. 

#### 1 Samuel 20:12 And Jonathan said to David, The LORD God of Israel knows that I will question my father according to {time a third}. And behold, if it should be good for David, then in no way shall I send to you in the field. 

#### 1 Samuel 20:13 Thus God do to Jonathan, and thus add to it, if I will not bring the evils unto you, and I will uncover your ear, and I will send you, and you will go in peace. And the LORD will be with you, as he was with my father. 

#### 1 Samuel 20:14 And if during my living you shall do {with me mercy of the LORD}, even if in death I should die, 

#### 1 Samuel 20:15 you shall not remove your mercy from my house unto the eon. And not even in the removing by the LORD of the enemies of David, each from the face of the earth, 

#### 1 Samuel 20:16 shall {be lifted away Jonathan} from the house of David, even if the LORD should require from the hands of the enemies of David. 

#### 1 Samuel 20:17 And Jonathan proceeded to swear by an oath to David, because of the loving him, for he loved the soul loving him. 

#### 1 Samuel 20:18 And {said to him Jonathan}, Tomorrow is a new moon, and overseeing {shall be watched your chair}. 

#### 1 Samuel 20:19 And you shall do it three times, and you shall watch, and you shall come into the place where you may hide there in the day of the deed, and you shall sit down by that stone. 

#### 1 Samuel 20:20 And I shall be three times in the {darts shooting}, and sending them forth to the mark. 

#### 1 Samuel 20:21 And behold, I shall send the servant-lad, saying, Come find to me the dart! If I should say to the servant-lad, Here is the dart away from you here, take it! then you come, for peace shall be to you, and there is no bad communication; as lives the LORD. 

#### 1 Samuel 20:22 But if thus I should say to the young man, Here is the dart, away from you and beyond. Go! for {sends you out the LORD}. 

#### 1 Samuel 20:23 And concerning the word which we have spoken, I and you, behold, the LORD is witness between me and you unto the eon. 

#### 1 Samuel 20:24 And David was hidden in the field. And it became a new moon, and {comes the king} unto the table to eat. 

#### 1 Samuel 20:25 And {sat the king} upon his chair as once and once before that, upon the chair by the wall. And {went beforehand by him Jonathan}, and Abner sat by the side of Saul. And {was watched the place of David}. 

#### 1 Samuel 20:26 And {did not say Saul} anything in that day, for he said, A coincidence, for he appears {not clean to be}, for he has not cleansed himself. 

#### 1 Samuel 20:27 And it came to pass in the next day of the month, the {day second}, and {was watched the place of David}. And Saul said to Jonathan his son, Why is it that he has not come, the son of Jesse, even yesterday and today unto the table? 

#### 1 Samuel 20:28 And Jonathan answered Saul, and said, {asks pardon of me David}, so as {to Beth-lehem his city to go}. 

#### 1 Samuel 20:29 And he said, Send me indeed, for {a sacrifice of the tribe we have} in the city, and {gave charge for me my brethren}. And now if I have found favor in your eyes, I will go forth indeed and see my brethren. On account of this he does not come unto the table of the king. 

#### 1 Samuel 20:30 And {was enraged in anger Saul} at Jonathan exceedingly, and said to him, O son {woman of a deserting}, {not for do you} know that you are a partner to the son of Jesse for your shame, and for the shame of uncovering your mother? 

#### 1 Samuel 20:31 For all the days which the son of Jesse lives upon the earth, you shall not be prepared, you nor your kingdom. Now then, send and take the young man! for {a son of death he is}. 

#### 1 Samuel 20:32 And Jonathan responded to Saul his father, and said, Why does he die? What has he done? 

#### 1 Samuel 20:33 And Saul lifted up the spear against Jonathan to put him to death. And Jonathan knew that {has been completed this evil} by his father to put David to death. 

#### 1 Samuel 20:34 And Jonathan jumped up from the table in anger of rage. And he did not eat bread on the second day of the month, for he was devastated for David, for {planned his father} to finish him off. 

#### 1 Samuel 20:35 And it became morning, and Jonathan came forth into the field as he gave order for the testimony to David, and {servant-lad the small} was with him. 

#### 1 Samuel 20:36 And he said to the servant-lad, You run and find for me the darts which I shall shoot! And the servant-lad ran. And he shot the arrow, and it passed by him. 

#### 1 Samuel 20:37 And {came the servant-lad} unto the place of the arrows which Jonathan shot. And Jonathan yelled out after the boy, and said, {is there the dart} away from you and beyond. 

#### 1 Samuel 20:38 And Jonathan yelled out after his servant-lad, saying, In hastening, you hasten! for you should not stand. And {gathered up the servant-lad of Jonathan} the darts, and he brought the darts to his master. 

#### 1 Samuel 20:39 And the servant-lad did not know anything, only Jonathan and David knew the thing. 

#### 1 Samuel 20:40 And Jonathan gave his weapons to his servant-lad, and said to his servant-lad, Go, enter into the city! 

#### 1 Samuel 20:41 And as {entered the city the servant-lad}, then David rose up from the chest, and fell upon his face upon the ground, and did obeisance to him three times. And {kissed each} his dear one, and {wept each} over his dear one unto {finale of a great David exceeded}. 

#### 1 Samuel 20:42 And Jonathan said to David, Go in peace! And as we swore by an oath, both of us in the name of the LORD, saying, The LORD will be witness between me and you, and between my seed and your seed, unto the eon. And David rose up and went forth. And Jonathan entered into the city. 

#### 1 Samuel 21:1 And David comes to Nob, to Ahimelech the priest. And Ahimelech is startled in the meeting David. And he said to him, Why is it that you are alone, and no one is with you? 

#### 1 Samuel 21:2 And David said to the priest Ahimelech, The king gave charge to me a thing today, and said to me, Let no one know anything concerning the matter for which I send you, and for what I have given charge to you. And to the servants I testified in the place, in the one being called -- Phalanni Alomni. 

#### 1 Samuel 21:3 And now, if there is in your hand five bread loaves, put into my hand the thing being found. 

#### 1 Samuel 21:4 And {responded the priest} to David, and said, There are no profane bread loaves in my hand, but {only bread loaves holy there are}. If {were having been kept the servants} from a woman, then they shall eat. 

#### 1 Samuel 21:5 And David answered to the priest, and said to him, Yes, even from a woman we have been at a distance from yesterday and the third day before. In my coming forth for the journey {have been all the servants} purified; but this journey is profane, for today it shall be sanctified on account of my weapons. 

#### 1 Samuel 21:6 And {gave to him Ahimelech the priest} bread loaves of the place setting, for there was no {there bread loaf}, but only bread loaves of the presence, the loaves being removed before the presence of the LORD, so as to place near {bread loaves the hot} in which day he took them. 

#### 1 Samuel 21:7 And there was a certain one there of the servants of Saul in that day, being held before the LORD, and the name to him was Doeg the Edomite, feeding the mules of Saul. 

#### 1 Samuel 21:8 And David said to Ahimelech, See if there is here under your hand a spear or broadsword! for my broadsword and my weapons I have not taken in my hand, for the matter of the king was in haste. 

#### 1 Samuel 21:9 And {said the priest}, Behold, the broadsword of Goliath the Philistine whom you struck in the valley of Ela. And it is wrapped in a cloak behind the shoulder-piece. If this you take for yourself, take! for there is none other besides it here. And David said, There is none as it, give it to me! 

#### 1 Samuel 21:10 And he gave it to him. And David rose up and fled in that day from the presence of Saul. And David came to Achish king of Gath. 

#### 1 Samuel 21:11 And {said the servants of Achish} to him, {not this Is} David the king of the land? Did not {to this one taking the lead the women joining in a dance}, saying, Saul struck his thousands, and David his ten thousands? 

#### 1 Samuel 21:12 And David put these words in his heart, and feared exceedingly before the face of Achish king of Gath. 

#### 1 Samuel 21:13 And he changed his countenance before them. And carried about with his hands, and fell upon the doors of the gateway, and his saliva flowed down upon his beard. 

#### 1 Samuel 21:14 And Achish said to his servants, Behold, you see a man overcome by convulsions! Why did you bring him to me? 

#### 1 Samuel 21:15 Or do {feel a want of ones overcome by convulsions I} that you carry him being possessed unto me? Shall this one enter into my house, no. 

#### 1 Samuel 22:1 And David went forth from there, and came through safe. And he comes to the cave of Odollam, and {hear his brethren}, and all the house of his father, and they went down to him there. 

#### 1 Samuel 22:2 And gathered together with him every one in necessity, and every debtor, and all in severe pain of the soul; and he was over them, taking the lead. And there were with him about four hundred men. 

#### 1 Samuel 22:3 And David went forth from there unto Mizpeh of Moab. And he said to the king of Moab, Let indeed my father and my mother be by you, until whenever I know what {shall do to me God}. 

#### 1 Samuel 22:4 And he appealed to the person of the king of Moab. And they dwelt with him all the days of David being in the citadel. 

#### 1 Samuel 22:5 And {said Gad the prophet} to David, Do not settle in the citadel. Go! and you shall come into the land of Judah. And David went, and came and settled in the city Hareth. 

#### 1 Samuel 22:6 And Saul heard that David was known, and the men with him. And Saul stayed on the hill by the plowed field, the one in Ramah, and the spear was in his hand, and all his servants stood beside him. 

#### 1 Samuel 22:7 And Saul said to his servants, of the ones standing beside him, Hear indeed, O sons of Benjamin! Shall truly {all to you give the son of Jesse} fields and vineyards? And {all you will he arrange} as commanders of hundreds, and commanders of thousands? 

#### 1 Samuel 22:8 For {situated together you are all} against me, and there is not one uncovering my ear, in that {ordains my son} a covenant with the son of Jesse. And there is the one toiling for me from you, and uncovering my ear. For {raised up my son} my servant against me for an enemy, as it is this day? 

#### 1 Samuel 22:9 And {answered Doeg the Edomite}, the one placed over the mules of Saul. And he said, I saw the son of Jesse coming into Nob, to Ahimelech son of Ahitub the priest. 

#### 1 Samuel 22:10 And he asked him concerning God, and {provisions he gave to him}; and the broadsword of Goliath the Philistine he gave to him. 

#### 1 Samuel 22:11 And {sent the king} to call Ahimelech son of Ahitub the priest, and all the sons of his father of the priests, of the ones in Nob. And they all came to the king. 

#### 1 Samuel 22:12 And Saul said, Hear indeed, O son of Ahitub! And he said, Behold, it is I. Speak, O master! 

#### 1 Samuel 22:13 And {said to him Saul}, Why did you agree against me, you and the son of Jesse, for you to give him bread, and a broadsword, and should ask on his account of God, to put him against me for an enemy, as he is this day? 

#### 1 Samuel 22:14 And Ahimelech answered to the king, and said, And who among all your servants is trustworthy as David, and son-in-law of the king, and one in charge of all your mobilization order, and honorable in your house? 

#### 1 Samuel 22:15 Or today have I begun to ask for him through God? By no means. Let not {impute the king} concerning {of his servant the word}, and against the entire house of my father, for {knew not your servant} in any of these things, a matter small or great. 

#### 1 Samuel 22:16 And {said king Saul}, To death Ahimelech should die, you and all the house of your father. 

#### 1 Samuel 22:17 And {said the king} to the bodyguards, to the ones standing by him, Lead forward, and put to death the priests of the LORD! for their hand is with David, for they knew that he fled, and they did not uncover my ear. And {would not the servants of the king} bear their hands to encounter against the priests of the LORD. 

#### 1 Samuel 22:18 And {said the king} to Doeg, You turn, and encounter the priests! And {turned Doeg the Edomite}, and put to death the priests of the LORD in that day -- eighty-five men, all bearing an ephod. 

#### 1 Samuel 22:19 And Nob, the city of the priests, he struck with the mouth of the broadsword, from man unto woman, from infant and unto one nursing, and from calf and donkey and sheep, he struck by the mouth of the broadsword. 

#### 1 Samuel 22:20 And {came through safe son one of Ahimelech son of Ahitub}, and the name to him was Abiathar, and he fled after David. 

#### 1 Samuel 22:21 And Abiathar reported to David that Saul put to death all the priests of the LORD. 

#### 1 Samuel 22:22 And David said to Abiathar, For I knew in that day, that Doeg the Edomite, that in reporting he would report to Saul. I am the one at fault for the lives of all the house of your father. 

#### 1 Samuel 22:23 You sit down with me! Do not fear! for where ever I seek for my life, I shall seek also {for your life a place}; for you are guarded by me. 

#### 1 Samuel 23:1 And they reported to David, saying, Behold, the Philistines wage war in Keilah, and they tear in pieces the threshing-floors. 

#### 1 Samuel 23:2 And David asked of the LORD, saying, Shall I go and strike these Philistines? And the LORD said to David, Go! and you shall strike the Philistines, and you shall deliver Keilah. 

#### 1 Samuel 23:3 And {said the men of David} to him, Behold, we here in Judea fear. And how will it be if we should go into Keilah unto the valleys of the Philistines? 

#### 1 Samuel 23:4 And David proceeded yet to ask of the LORD. And {answered him the LORD}, and said to him, Rise up and go down unto Keilah! for I deliver up the Philistines into your hands. 

#### 1 Samuel 23:5 And David went, and the men, the ones with him, unto Keilah. And he waged war against the Philistines, and they fled from his face. And he took away their cattle, and he struck them {beating with a great}. And David delivered the ones dwelling in Keilah. 

#### 1 Samuel 23:6 And it came to pass in the fleeing of Abiathar the son of Ahimelech to David in Keilah, he came down having an ephod in his hand. 

#### 1 Samuel 23:7 And it was reported to Saul that David was come to Keilah. And Saul said, {has sold him God} into my hands, for he is locked up, having entered into a city of doors and bars. 

#### 1 Samuel 23:8 And Saul exhorted all the people to go down for war to Keilah, to band together against David and his men. 

#### 1 Samuel 23:9 And David knew that {did not remain silent Saul} concerning him for evil. And David said to Abiathar the priest, Bring the ephod! 

#### 1 Samuel 23:10 And David said, O LORD, the God of Israel, in hearing hearken to your servant! for Saul seeks to come against Keilah, to utterly destroy the city on account of me. 

#### 1 Samuel 23:11 Shall it be locked up? And now, shall Saul come down as {heard your servant}, O LORD, the God of Israel? Report to your servant! And the LORD said, It shall be locked up. 

#### 1 Samuel 23:12 And David said, Shall {deliver up the ones from Keilah} me and my men into the hand of Saul? And the LORD said, They shall deliver up. 

#### 1 Samuel 23:13 And David rose up, and his men -- about eight hundred. And they went forth from Keilah, and went where ever they could go. And it was reported to Saul that David went safe from Keilah, and he spared to come forth. 

#### 1 Samuel 23:14 And David stayed in the wilderness, in the narrow passes, and settled in the mountain, in the wilderness of Ziph. And {sought him Saul} all the days. And {did not deliver him the LORD} into his hands. 

#### 1 Samuel 23:15 And David knew that Saul went forth to seek him. And David was in the wilderness Ziph in New. 

#### 1 Samuel 23:16 And {rose up Jonathan son of Saul}, and went to David in New. And he fortified his hands in the LORD. 

#### 1 Samuel 23:17 And he said to him, Do not fear! for in no way shall {find you the hand of Saul my father}. And you shall reign over Israel, and I will be to you for second. And Saul my father knows so. 

#### 1 Samuel 23:18 And {ordained both} a covenant before the LORD. And David settled in New, and Jonathan went forth to his house. 

#### 1 Samuel 23:19 And {ascended up the Ziphites} to Saul, unto the hill, saying, Behold is not David hid by us in the narrows, in New, in the hill of Hachilah, of the place at the right of Jeshimon? 

#### 1 Samuel 23:20 And now, every desire of the soul of the king, {into the descent let him go down} to us! They are being uncovered into the hands of the king. 

#### 1 Samuel 23:21 And {said to them Saul}, Being blessed are you to the LORD, for you toiled on account of me. 

#### 1 Samuel 23:22 You should go indeed and prepare yet, and know and see his place where {is his foot}, quickly, there in that place of which you said, lest at any time he should trick you! 

#### 1 Samuel 23:23 And look and know of all the places where he hides there! And return to me at ready! and I shall go with you. And it will be if he is in the land, that I shall search him out among all the thousands of Judah. 

#### 1 Samuel 23:24 And {rose up the Ziphites}, and went before Saul. And David and his men were in the wilderness of Maon, to the west at the right of Jeshimon. 

#### 1 Samuel 23:25 And Saul went and his men to seek David. And they reported to David. And he went down into the rock, the one in the wilderness of Maon. And Saul heard, and he pursued unto the wilderness of Maon after David. 

#### 1 Samuel 23:26 And Saul went, and his men by the side of this mountain, and David and his men by the other side of this mountain. And David was sheltering to go from the face of Saul. And Saul and his men camped by David and his men -- to seize them. 

#### 1 Samuel 23:27 And a messenger came to Saul saying, Hasten and come here, for the Philistines made an attack against the land. 

#### 1 Samuel 23:28 And Saul returned to not pursue after David, and he went to meet the Philistines. On account of this {is called place that}, {Rock The Portioned}. 

#### 1 Samuel 23:29 And David ascended from there and settled in the narrows of En Gedi. 

#### 1 Samuel 24:1 And it came to pass as Saul returned from going after the Philistines, that they reported to him, saying, Behold, David is in the wilderness of En Gedi. 

#### 1 Samuel 24:2 And he took with himself three thousand {men chosen} from out of all Israel, and he went to seek David and his men by the face of the trap of the hinds. 

#### 1 Samuel 24:3 And he came unto the herds of the flocks of the ones upon the way. And {was there a cave}, and Saul entered to make preparation. And David and his men were in the cave inside sitting down in it. 

#### 1 Samuel 24:4 And {said the men of David} to him, Behold, {the day this is} which the LORD spoke to you, Behold, I give your enemy into your hands; and you shall do to him as is good in your eyes. And David rose up and removed the border of the doubled garment of Saul clandestinely. 

#### 1 Samuel 24:5 And it came to pass after these things, that {struck David's heart} him, for he removed the border of his double garment. 

#### 1 Samuel 24:6 And David said to his men, By no means be it to me from the LORD if I should do this thing to my master, to the anointed one of the LORD, to bear my hand against him, for {the anointed one of the LORD this is}. 

#### 1 Samuel 24:7 And David persuaded his men by words, and he did not give in to them to rise up and to put Saul to death. And Saul rose up and went forth into the way from the cave. 

#### 1 Samuel 24:8 And David rose up after him from out of the cave. And David yelled after Saul, saying, O Master, O king. And Saul looked up to his rear. And David bowed upon his face unto the ground, and he did obeisance to him. 

#### 1 Samuel 24:9 And David said to Saul, Why do you hearken to the words of the people, saying, Behold, David seeks your life? 

#### 1 Samuel 24:10 Behold, in this day {have seen your eyes} how {delivered you the LORD} today into my hands in the cave, and I did not want to kill you, and I spared you. And I said, I will not bear my hand against my master, for {the anointed one of the LORD this one is}. 

#### 1 Samuel 24:11 And, O my father, even behold, the border of your doubled garment in my hand. I removed the border of your doubled garment, and I did not kill you. And know and behold today! that there is no evil in my hand, nor annulment, nor impiety, and I have not sinned against you. But you bind my life to take it. 

#### 1 Samuel 24:12 May the LORD judge between me and you, and may {render justice to me the LORD} because of you. But my hand will not be against you. 

#### 1 Samuel 24:13 As {says parable the ancient}, {from the lawless shall come forth Trespass}. But my hand will not be against you. 

#### 1 Samuel 24:14 And now, after whom do you go forth, O king of Israel? After whom do you pursue? After a dog having died, or after {flea one}? 

#### 1 Samuel 24:15 May the LORD be for a judge and magistrate between me and you. Yes, may the LORD behold, and may he judge my case, and may he adjudicate for me from out of your hand. 

#### 1 Samuel 24:16 And it came to pass, as David completed speaking these things to Saul, that Saul said, Is {voice this your}, son David? And Saul lifted up his voice and wept. 

#### 1 Samuel 24:17 And he said to David, You are righteous over me, for you recompensed to me good things, but I recompensed to you evils. 

#### 1 Samuel 24:18 And you have reported today what {you did to me good things}, as how {locked me the LORD} into your hands today, and you did not kill me. 

#### 1 Samuel 24:19 And that if anyone may find his enemy in affliction, and shall send him forth in {way a good}, even the LORD will recompense to him good things, as you have done today. 

#### 1 Samuel 24:20 And now, behold, I know that in reigning you shall reign, and {shall be established the kingdom of Israel} in your hand. 

#### 1 Samuel 24:21 And now swear by an oath to me according to the LORD, that you should not utterly destroy my seed after me, and you should not obliterate my name from the house of my father. 

#### 1 Samuel 24:22 And David swore by an oath to Saul. And Saul went forth unto his house. And David and his men ascended unto Messara the narrows. 

#### 1 Samuel 25:1 And Samuel died; and {gathered together all Israel}, and lamented him, and entombed him in his house in Ramah. And David rose up, and went down into the wilderness of Paran. 

#### 1 Samuel 25:2 And there was a man in Maon, and his work was in Carmel, and the man {great was exceedingly}. And to this man were {sheep three thousand}, and {goats a thousand}. And it happened during the shearing of his flock in Carmel. 

#### 1 Samuel 25:3 And the name of the man was Nabal, and the name of his wife was Abigail. And his wife had good understanding, and was good to the sight, exceedingly. And the man was recalcitrant, and wicked in practices, and the man was churlish. 

#### 1 Samuel 25:4 And David heard in the wilderness that {was shearing Nabal the Carmelite} his flock. 

#### 1 Samuel 25:5 And David sent ten servants. And he said to the servants, Ascend to Carmel, and come to Nabal, and ask him in my name the things for peace! 

#### 1 Samuel 25:6 And you shall say thus, For a season may it be for you being in health and your house, and all the things of yours being in health. 

#### 1 Samuel 25:7 And now, behold, I hear that {shear for you now your shepherds}, the ones who were with us in the wilderness, and we did not detain them, and we did not give charge to them in anything all the days of their being in Carmel. 

#### 1 Samuel 25:8 Ask of your servants! and they will tell you. Let us {find your servants} favor in your eyes! for upon {day a good} we come. Give indeed what ever {should find your hand} to your servants, and to your son David! 

#### 1 Samuel 25:9 And {come the servants of David}, and speak to Nabal according to all these things in the name of David. 

#### 1 Samuel 25:10 And Nabal jumped up and responded to the servants of David, and he said, Who is David, and who is the son of Jesse? Today {multiplying there are servants}, {withdrawing each} from the presence of his master. 

#### 1 Samuel 25:11 And shall I take my bread loaves, and my wine, and my things offered in sacrifices which I have sacrificed to the ones shearing for me the sheep, and shall I give them to men whom I do not know from what place they are? 

#### 1 Samuel 25:12 And {turned back the servants of David} unto their way. And they returned, and they came, and they announced to David according to all these words. 

#### 1 Samuel 25:13 And David said to his men, Let {tie on each man} his sword! And David even himself tied on his sword. And they ascended after David, about four hundred men, and two hundred stayed by the equipment. 

#### 1 Samuel 25:14 And {to Abigail wife of Nabal reported one of the servants}, saying, Behold, David sent messengers from out of the wilderness to bless our master, and he turned aside from them. 

#### 1 Samuel 25:15 And the men were good to us, exceedingly. And they did not detain us, nor charged to us anything all the days which we were by them, in our being in the field. 

#### 1 Samuel 25:16 {as a wall They were} for us, both day and night, all the days of our being with them and tending the flocks. 

#### 1 Samuel 25:17 And now perceive and see what you shall do! for {is completed evil} against our master, and against his house; and he is a son of pestilence, and there is no way to speak to him. 

#### 1 Samuel 25:18 And Abigail hastened, and took two hundred bread loaves, and two receptacles of wine, and five sheep prepared, and five ephahs of toasted grains, and {homer one} of dried grapes, and two hundred dried clusters of figs; and she put them upon the donkeys. 

#### 1 Samuel 25:19 And she said to her servants, You go forth in front of me! and behold, I {after you come}. But to her husband Nabal she did not report. 

#### 1 Samuel 25:20 And it came to pass of her being mounted upon the donkey, that she went down in the protection of the mountain. And behold, David and his men went down to meet her, and she met them. 

#### 1 Samuel 25:21 And David said, Perhaps it was unjust I guarded all the things of Nabal in the wilderness, and asked not to take of any of his things -- nothing. And he recompensed to me evil for good. 

#### 1 Samuel 25:22 Thus God do to the enemies to David, and thus may he add, if I leave behind of all of the ones of Nabal unto the morning of ones urinating against the wall. 

#### 1 Samuel 25:23 And Abigail saw David, and hastening she came down from the donkey, and fell before David upon her face, and did obeisance to him upon the ground. 

#### 1 Samuel 25:24 And {by his feet she fell}, and she said, On me, O my lord, be the injustice. Let {speak indeed your maidservant} into your ears, and you hear the words of your maidservant! 

#### 1 Samuel 25:25 Let not indeed {put my master} his heart against {man this pestilent}, against Nabal! For according to his name, thus is he Nabal. His name, and folly is with him. And I your maidservant did not see the servants of my master whom you sent. 

#### 1 Samuel 25:26 And now, O my lord, as the LORD lives, and as {lives your soul}, as {restrained you the LORD} to not come against {blood innocent}, and to deliver your hand for yourself. And now may {become as Nabal your enemies}, and the ones seeking {against my lord bad things}. 

#### 1 Samuel 25:27 And now receive this blessing which {has brought your maidservant} to my master! and you shall give it to the servants standing beside my master. 

#### 1 Samuel 25:28 Take away indeed the violation of your maidservant! for in doing, the LORD shall make {for my master house a trustworthy}, for {the battle for my master the LORD shall wage}, and evil shall not be found in you at any time. 

#### 1 Samuel 25:29 And if {should rise up a man} to pursue you, and seeking your life, that {will be the life of my master} bound in a bond of life by the LORD God; and the life of your enemies you shall sling as in the midst of the sling. 

#### 1 Samuel 25:30 And it shall be whenever the LORD shall do for my master, according to all {which he spoke good things} concerning you, that {shall give charge to you the LORD} for taking the lead over Israel. 

#### 1 Samuel 25:31 Then {shall not be against your this abomination and obstacle} heart, to my master, to pour out {blood innocent} without charge, and to deliver the hand of my master for himself. And the LORD shall do good to my master. And you shall remember your maidservant, {well to do} to her. 

#### 1 Samuel 25:32 And David said to Abigail, Blessed be the LORD God of Israel, who sent you {day in this} to meet me. 

#### 1 Samuel 25:33 And blessed be your manner, and blessed be you to detain me today in this, to not come for blood, and to deliver my hand from myself. 

#### 1 Samuel 25:34 Only as lives the LORD God of Israel, who detained me today of doing evil to you, that unless you hastened and came to meet me, not would there have been left behind to Nabal unto the light of the morning one urinating against the wall. 

#### 1 Samuel 25:35 And David took from her hand all which she brought to him. And he said to her, Ascend in peace to your house. See, I hearkened to your voice, and I took up your person! 

#### 1 Samuel 25:36 And Abigail came to Nabal. And behold, there was to him a banquet in his house, as the banquet of a king. And the heart of Nabal was good with him, and he was being intoxicated exceedingly. And {did not report Abigal} to Nabal the thing, great or small, until the light of the morning. 

#### 1 Samuel 25:37 And it came to pass in the morning as {sobered up from the wine Nabal}, {reported to him his wife} all these things. And {died heart his} in him, and he became as stone. 

#### 1 Samuel 25:38 And it came to pass after about ten days, that the LORD struck Nabal and he died. 

#### 1 Samuel 25:39 And David heard that Nabal died, and he said, Blessed be the LORD who judged the case of my being scorned by the hand of Nabal, and {his servant protected} from out of the hand of evils. And the evil of Nabal the LORD returned against his own head. And David sent and spoke concerning Abigail, to take her to himself for a wife. 

#### 1 Samuel 25:40 And {came the servants of David} to Abigail in Carmel. And they spoke to her, saying, David sends us to you, to take you to himself for a wife. 

#### 1 Samuel 25:41 And rising, she did obeisance upon her face upon the ground. And she said, Behold, your maidservant is for a girl to wash the feet of the servants of my master. 

#### 1 Samuel 25:42 And {hastened and rose up Abigail}, and mounted upon the donkey, and five of her young women followed her. And she went after the servants of David, and became to him for a wife. 

#### 1 Samuel 25:43 And {Ahinoam took David} of Jezreel; and both were his wives. 

#### 1 Samuel 25:44 And Saul gave Michal his daughter, the wife of David, to Phalti son of Laish, the one of Gallim. 

#### 1 Samuel 26:1 And {come the Ziphites} to the hill to Saul, saying, Behold, David is sheltered with us in the hill of Hachilah, against the face of Jeshimon. 

#### 1 Samuel 26:2 And Saul rose up, and went down unto the wilderness of Ziph, and with him three thousand {men chosen} of Israel, to seek David in the wilderness of Ziph. 

#### 1 Samuel 26:3 And Saul camped in the hill of Hachilah, against the face of Jeshimon, upon the way. And David stayed in the wilderness. And David saw that Saul comes after him into the wilderness. 

#### 1 Samuel 26:4 And David sent spies, and he knew that Saul was come prepared from there. 

#### 1 Samuel 26:5 And David rose up in private, and went into the place where {was sleeping there Saul}. And David saw the place where {went to bed there Saul}. And Abner son of Ner his commander-in-chief was there. And Saul was sleeping in the royal chariot, and the people were camping round about him. 

#### 1 Samuel 26:6 And David responded and said to Ahimelech the Hittite, and to Abishai son of Zeruiah, brother of Joab, saying, Who shall enter with me to Saul, into the camp? And Abishai said, I shall enter with you. 

#### 1 Samuel 26:7 And they enter, David and Abishai, among the people at night. And behold, Saul was sleeping a deep sleep in the royal chariot, and his spear was sticking in the ground by his head, and Abner and the people slept round about him. 

#### 1 Samuel 26:8 And Abishai said to David, the LORD locked up today your enemy into your hands. And now I shall indeed strike him with the spear into the earth once, and I should not repeat it a second time against him. 

#### 1 Samuel 26:9 And David said to Abishai, you should not utterly destroy him. For who shall bear his hand against the anointed one of the LORD, and be acquitted? 

#### 1 Samuel 26:10 And David said, As the LORD lives, that if the LORD should not smite him, or his day should come and he should die, or by battle should go down and be added to his fathers; 

#### 1 Samuel 26:11 then it is by no means to me from the LORD to bear my hand against the anointed one of the LORD. And now, take indeed the spear from before his head, and the flask of the water, and we shall go forth. 

#### 1 Samuel 26:12 And David took the spear and the flask of the water from before his head, and they went forth. And there was not one seeing, and there was not one knowing, and there was not one awakening -- all were sleeping, for a stupefaction from the LORD fell upon them. 

#### 1 Samuel 26:13 And David passed over to the other side, and stood upon the top of the mountain far off, and a long way between them. 

#### 1 Samuel 26:14 And David called the people, and he spoke to Abner son of Ner, saying, Will you not answer, Abner? And Abner answered and said, Who are you, calling me? 

#### 1 Samuel 26:15 And David said to Abner, Are {not a man you}? And who is as you in Israel? And why do you not guard your master the king? For {entered one of the people} to destroy your master the king. 

#### 1 Samuel 26:16 {is not a good thing this} which you have done. As lives the LORD, for {sons of death you are}, the ones not guarding the king, your master, the anointed one of the LORD. And now see where {is the spear of the king}, and the flask of the water, the things by his head! 

#### 1 Samuel 26:17 And Saul recognized the voice of David, and he said, {your voice Is this} son David? And David said, My voice my master; your servant, O king. 

#### 1 Samuel 26:18 And he said, Why is this {pursues my master} after his servant? For in what have I sinned? And what {was found in me offence}? 

#### 1 Samuel 26:19 And now let {hear indeed my master the king} the words of his servant! If God stirs you against me, then may {smell acceptable your sacrifice}. And if the sons of men, then let these be accursed before the LORD, for they cast me out today to not be fixed firmly in the inheritance of the LORD, saying, Go serve other gods! 

#### 1 Samuel 26:20 And now {not may fall my blood} upon the ground right opposite the face of the LORD, that {has come forth the king of Israel} to seek {flea one}, as {pursues prey the long-eared owl} in the mountains. 

#### 1 Samuel 26:21 And Saul said, I have sinned. Return, son David! for I shall not do evil against you any more, because {was valued my life} in your eyes; and today I have acted in folly, and I am ignorant {much very}. 

#### 1 Samuel 26:22 And David responded and said, Behold, the spear of the king. Let {come through indeed one of the servants} and take it! 

#### 1 Samuel 26:23 And the LORD will restore to each his righteousness and his trust; as {delivered you the LORD} today into my hands, and I did not want to bear my hand against the anointed one of the LORD. 

#### 1 Samuel 26:24 And behold, as {was magnified your life} today in this, in my eyes, so may {be magnified my life} before the LORD, and may he shelter me, and may he rescue me from out of all affliction. 

#### 1 Samuel 26:25 And Saul said to David, Being blessed are you, son David, and by performing you shall perform, and in ability you shall be able. And David went forth on his way, and Saul returned to his place. 

#### 1 Samuel 27:1 And David said in his heart, saying, Now I shall be added in {day one} into the hands of Saul; and there is no good thing to me unless I should come through safe into the land of the Philistines, and {should spare of me Saul}, seeking me in every border of Israel, and thus I shall be delivered from out of his hand. 

#### 1 Samuel 27:2 And David rose up and passed over, he and the six hundred men with him, and he went to Achish, son of Maoch, king of Gath. 

#### 1 Samuel 27:3 And David sat with Achish in Gath, he and his men, each also with his house, and David and both of his wives -- Ahinoam the Jezreelitess, and Abigail the wife of Nabal the Carmelite. 

#### 1 Samuel 27:4 And it was announced to Saul that David fled into Gath, and he did not proceed any longer to seek him. 

#### 1 Samuel 27:5 And David said to Achish, If indeed {has found your servant} favor in your eyes, give indeed to me a place in one of the cities of the ones in the country! and I shall settle there. For why {settle does your servant} in a city reigning with you? 

#### 1 Samuel 27:6 And {gave to him Achish} in that day Ziklag. Because of this Ziklag came to the king of Judea until this day. 

#### 1 Samuel 27:7 And came to pass the number of the days which David stayed in the country of the Philistines -- four months. 

#### 1 Samuel 27:8 And David ascended and his men, and they made an attack upon the Geshurites, and the Gezrites, and against the Amalekites. For {was inhabited the land} by the one from Shur and unto the land of Egypt. 

#### 1 Samuel 27:9 And he struck the land, and did not bring forth alive man or woman; and they took flocks, and herds, and donkeys, and camels, and clothes. And they returned and came to Achish. 

#### 1 Samuel 27:10 And Achish said to David, Upon whom did you attack today? And David said to Achish, To the south in Judea, and to the south of Jerahmeel, and to the south of the Kenite. 

#### 1 Samuel 27:11 And {a man and woman did not bring forth alive David} to bring unto Gath, saying, Lest they announce against us, saying, Thus David does. And thus was his ordinance all the days which David settled in the country of the Philistines. 

#### 1 Samuel 27:12 And David was trusted by Achish, saying, With shame he is being shamed by his people in Israel, and he will be my a servant into the eon. 

#### 1 Samuel 28:1 And it came to pass in those days that {were gathered together the Philistines} in their camps to come forth for war against Israel. And Achish said to David, In knowing you shall know that with me you shall go forth unto the war, you and your men. 

#### 1 Samuel 28:2 And David said to Achish, Thus now you shall know what {will do your servant}. And Achish said to David, Thus as chief of the body-guard I shall appoint you for all the days. 

#### 1 Samuel 28:3 And Samuel died, and {lamented him all Israel}, and they entombed him in Ramah, in his city. And Saul removed the ones who deliver oracles, and the diviners from the land. 

#### 1 Samuel 28:4 And {gather together the Philistines}, and come, and camp in Shunem. And Saul gathers together every man of Israel, and they camp in Gilboa. 

#### 1 Samuel 28:5 And Saul beheld the camp of the Philistines, and he was fearful, and it startled his heart exceedingly. 

#### 1 Samuel 28:6 And Saul asked through the LORD. And {did not answer to him the LORD} in dreams, nor in the manifestations, nor among the prophets. 

#### 1 Samuel 28:7 And Saul said to his servants, Seek for me a woman who delivers oracles! and I will go to her, and I will inquire by her. And {said his servants} to him, Behold, a woman who delivers oracles is in En-dor. 

#### 1 Samuel 28:8 And Saul changed appearance, and put around {garments other}, and he himself goes and two men with him. And they come to the woman by night, and he said to her, Use oracles indeed for me by the delivering an oracle, and lead up to me whom ever I should tell you! 

#### 1 Samuel 28:9 And {said the woman} to him, Behold, you know as much as Saul did, as he utterly destroyed the ones delivering up oracles, and the diviners from the land. And why do you ensnare my life to put it to death? 

#### 1 Samuel 28:10 And {swore by an oath to her Saul} according to God, saying, As lives the LORD, shall {meet up with you injustice} in this matter? No! 

#### 1 Samuel 28:12 11 And {said the woman} to Saul, Whom should I lead up to you? And he said, Lead up Samuel to me!And {beheld the woman} Samuel, and she yelled {voice with a great}. And {said the woman} to Saul, Why did you mislead me, even you are Saul? 

#### 1 Samuel 28:13 And {said to her the king}, Do not fear! Whom do you see? And {said the woman} to Saul, I see magistrates ascending from out of the earth. 

#### 1 Samuel 28:14 And he said to her, What did you perceive? And she said to him, An aged man ascending being cloaked in a double-garment. And Saul knew that this was Samuel. And he bowed upon the face upon the ground, and he did obeisance to him. 

#### 1 Samuel 28:15 And Samuel said, Why did you give trouble to me to cause me to ascend? And Saul said, I am afflicted very much, and the Philistines wage war with me, and God has left from me, and he does not heed me any longer, nor by the hand of the prophets, nor by dreams. And now I call you to make known to me what I should do. 

#### 1 Samuel 28:16 And Samuel said, Why do you ask me, and the LORD has left from you, and has taken place with your neighbor? 

#### 1 Samuel 28:17 And the LORD has done to you as he said by my hand. And the LORD will tear the kingdom from out of your hand, and will give it to your neighbor, to David. 

#### 1 Samuel 28:18 Because you hearkened not to the voice of the LORD, and you did not fill {rage of anger his} against Amalek; on account of this thing the LORD did to you thus in this day. 

#### 1 Samuel 28:19 And the LORD will deliver up Israel with you into the hands of the Philistines, and tomorrow you and your sons will be with with me. And {the camp of Israel the LORD will put} into the hands of the Philistines. 

#### 1 Samuel 28:20 And Saul hastened, and fell full stop upon the ground, and feared very much from the words of Samuel. And there was no {in him strength} any longer, for he did not eat bread all that day, and all the night. 

#### 1 Samuel 28:21 And {entered the woman} to Saul, and beheld that he hastened very much. And she said to him, Behold, {hearkened to your maidservant} your voice, and I put my life in my hand, and I hearkened to your words which you spoke to me. 

#### 1 Samuel 28:22 And now hear indeed the voice of your maidservant, for I will place before you a morsel of bread and you eat! and it will be for strength to you, that you should go in the way. 

#### 1 Samuel 28:23 And he resisted persuasion, and he did not want to eat. And they pressed him, his servants and the woman. And he hearkened to their voice, and he rose up from the ground, and he sat upon the chair. 

#### 1 Samuel 28:24 And to the woman was {calf a suckling} by the house; and she hastened and sacrificed it, and took flour and mixed it, and baked unleavened breads. 

#### 1 Samuel 28:25 And she brought it before Saul, and before his servants, and they ate. And rising up they went forth that night. 

#### 1 Samuel 29:1 And {gathered the Philistines} all their camps unto Aphek. And Israel camped in En-dor, the one in Jezreel. 

#### 1 Samuel 29:2 And the satraps of the Philistines came by the hundreds and thousands. And David and his men came near at the last with Achish. 

#### 1 Samuel 29:3 And {said the satraps of the Philistines}, Who are these traveling? And Achish said to the satraps of the Philistines, Is not this David, the servant of Saul king of Israel, who has been with me some days this second year. And I have not found in him any fault from which days he fell in with me until this day. 

#### 1 Samuel 29:4 And {were enraged over him the satraps of the Philistines}, and they say to him, Return the man! and let him return unto his people of which you placed him there, and do not let him come with us to the battle, and let him not become a plotter in the camp! And how shall he be reconciled to his master? Will it not be with the heads of those men? 

#### 1 Samuel 29:5 Is this not David, which they led in dances, saying, Saul struck his thousands, and David his ten thousands? 

#### 1 Samuel 29:6 And Achish called David, and said to him, As the LORD lives, know that you are upright and good in my eyes, and so is your exiting and your entering with me in the camp. For I did not find against you an evil from which day you came to me until this day. But in the eyes of the satraps {not good you are}. 

#### 1 Samuel 29:7 And now, return and go in peace! and in no way shall you do evil in the eyes of the satraps of the Philistines. 

#### 1 Samuel 29:8 And David said to Achish, What have I done to you? And what did you find in your servant from which day I was before you, and until this day, that in no way I should come to wage war against the enemies of my master the king? 

#### 1 Samuel 29:9 And Achish answered and said to David, I know that you are good in my eyes, as an angel of God, but the satraps of the Philistines say, He shall not come with us to war. 

#### 1 Samuel 29:10 And now, rise early in the morning, you and the servants of your master, the ones having come with you, and go to the place where I placed you there! And you rise early in the journey, and when it gives light to you then go! 

#### 1 Samuel 29:11 And David rose early, he and his men to go forth in the morning, and to guard the land of the Philistines. And the Philistines ascended to wage war against Israel. 

#### 1 Samuel 30:1 And it came to pass in the entering of David and of his men to Ziklag, on the {day third}, that Amalek made an attack upon the south, and upon Ziklag. And it struck Ziklag, and burnt it with fire. 

#### 1 Samuel 30:2 And the women, and all the ones in it, from small unto great they did not put to death, man nor woman, but they took them captive, and went forth in their way. 

#### 1 Samuel 30:3 And {came David and his men} unto the city, and, behold, it was burnt with fire; and their wives, and their sons, and their daughters, were taken captive. 

#### 1 Samuel 30:4 And {lifted David and his men} their voice, and they wept until whenever there was no strength in them to weep any longer. 

#### 1 Samuel 30:5 And both the wives of David were captured -- Ahinoam the Jezreelitess, and Abigail the wife of Nabal the Carmelite. 

#### 1 Samuel 30:6 And David was afflicted very much, for {said the people} to stone him, for {were in severe pain of soul all the people}, each over his sons, and over his daughters. And David was fortified by the LORD his God. 

#### 1 Samuel 30:7 And David said to Abiathar the priest, son of Ahimelech, Lead forward the ephod. And Abiathar led forward the ephod to David. 

#### 1 Samuel 30:8 And David asked through the LORD, saying, Shall I pursue after this troop? Shall I overtake them? And {said to him the LORD}, Pursue! for in overtaking you shall overtake them, and in rescuing you shall rescue. 

#### 1 Samuel 30:9 And David went, he and the six hundred men with him. And they come unto the rushing stream of Besor, and the extra ones stopped. 

#### 1 Samuel 30:10 And {pursued about four hundred men}, {stood and two hundred men}, who stayed on the other side of the rushing stream Besor. 

#### 1 Samuel 30:11 And they find an Egyptian man in the field, and they take him, and bring him to David, and give to him bread and he ate, and they gave {to drink him water}. 

#### 1 Samuel 30:12 And they give to him a piece of dried cluster of figs, and two dried grape clusters; and he ate, and {stood up his spirit} in him. For he had not eaten bread, and had not drank water, three days and three nights. 

#### 1 Samuel 30:13 And {said to him David}, Who are you, and from what place are you? And {said servant-lad the Egyptian}, I am a servant of a man, an Amalekite; and {left me my master} for I was unwell, today being three days. 

#### 1 Samuel 30:14 And we made an attack upon the south of the Cherethites, and upon the ones of the part of Judea, and to the south of Caleb; and Ziklag we burnt in fire. 

#### 1 Samuel 30:15 And {said to him David}, Will you lead me to this troop? And he said, If you swear by an oath indeed to me according to God to not put me to death, and not to deliver me into the hands of my master, then I will lead you to this troop. 

#### 1 Samuel 30:16 And he led him. And behold, these were dispersed upon the face of all the land, eating and drinking, and celebrating over all the {spoils great} which they took from out of the land of the Philistines, and from out of the land of Judah. 

#### 1 Samuel 30:17 And {came upon them David}, and he struck them from the morning star and until evening even of the next day. And {was not preserved of them a man}, but only four hundred boys who mounted upon camels and fled. 

#### 1 Samuel 30:18 And David removed all which {took the Amalekites}; and both his wives he rescued. 

#### 1 Samuel 30:19 And nothing was perished to them from small and unto great, and unto sons and daughters, from the spoils and unto all what they took of theirs -- all the things David returned. 

#### 1 Samuel 30:20 And David took all the flocks and the herds, and led them away before the spoils. And concerning those spoils it was said, These are the spoils of David. 

#### 1 Samuel 30:21 And David came to the two hundred men (the ones being left behind of the troop going after David) that stayed at the rushing stream of Besor. And they came forth to meet David, and to meet the people of the one with him. And David came forward unto of the people, and he asked them the greetings for peace. 

#### 1 Samuel 30:22 And {responded every man pestilent and wicked} of the men warriors going with David. And they said that, They did not pursue with us, we shall not give to them from out of the spoils which we rescued, but {each his wife and his children let take away}, and let them return! 

#### 1 Samuel 30:23 And David said, You shall not do {my brothers thus} after the delivering up of the enemy by the LORD to us, and guarded us, and the LORD delivered up the troop, the one coming upon us, into our hands. 

#### 1 Samuel 30:24 And who will heed {your words these}, for {not inferior to us they are}; for according to the portion of the one going down to war, so shall be the portion of the one staying by the equipment; according to the same they shall be portioned. 

#### 1 Samuel 30:25 And it came to pass from that day and forward, that it became for an order and for an ordinance in Israel until this day. 

#### 1 Samuel 30:26 And David came to Ziklag, and he sent to the elders of Judah, and to his neighbors of the spoils, saying, Behold, a blessing to you from the spoils of the enemies of the LORD; 

#### 1 Samuel 30:27 to the ones in Beth-el, and to the ones in Ramoth of the south, and to the ones in Jattir, 

#### 1 Samuel 30:28 and to the ones in Aroer, and to the ones in Siphmoth, and to the ones in Eshtemoa, 

#### 1 Samuel 30:29 and to the ones in Rachal, and to the ones in the cities of the Jerahmeelite, and to the ones in the cities of the Kenite; 

#### 1 Samuel 30:30 and to the ones in Hormah, and to the ones in Beer-ashan, and to the ones in Athach; 

#### 1 Samuel 30:31 and to the ones in Hebron, and into all the places which David went there, he and his men. 

#### 1 Samuel 31:1 And the Philistines waged war against Israel. And {fled the men of Israel} from the face of the Philistines, and they fell slain in mount Gilboa. 

#### 1 Samuel 31:2 And {joined up against the Philistines} Saul and his sons. And {struck down the the Philistines} Jonathan, and Abinadab, and Melchi-shua, sons of Saul. 

#### 1 Samuel 31:3 And {weighs down the battle} against Saul, and {find him the shooters}, men bowmen; and he was wounded in the spleen. 

#### 1 Samuel 31:4 And Saul said to the one carrying his weapons, Unsheathe your broadsword, and pierce me with it! lest {should come these uncircumcised} and should pierce me, and should mock against me. But {did not want to the one carrying his weapons}, for he feared exceedingly. And Saul took his broadsword, and fell upon it. 

#### 1 Samuel 31:5 And {beheld the one carrying his weapons} that Saul died, and he fell also himself upon his broadsword, and died with him. 

#### 1 Samuel 31:6 And Saul died, and {three sons his}, and the one carrying his weapons, and all his men, in that day at the same time. 

#### 1 Samuel 31:7 And {beheld the men of Israel}, the ones on the other side of the valley, and the ones on the other side of the Jordan, that {fled the men of Israel}, and that Saul died, and his sons. And they leave their cities, and flee. And {come the Philistines} and dwell in them. 

#### 1 Samuel 31:8 And it came to pass on the next day, and {come the Philistines} to strip the slain, and they find Saul and {three sons his} fallen upon the mountains of Gilboa. 

#### 1 Samuel 31:9 And they behead him, and they strip him of his weapons, and they send into the land of the Philistines round about, announcing good news to their idols, and to their people. 

#### 1 Samuel 31:10 And they presented his weapons in the Astartion. And his body they fastened down on the wall in Beth-shan. 

#### 1 Samuel 31:11 And {hear concerning the ones dwelling in Jabish Gilead} as much as {did the Philistines} to Saul. 

#### 1 Samuel 31:12 And {rose up all the men of power}. And they went the entire night, and took the body of Saul, and the body of Jonathan his son from the wall in Beth-sham. And they brought them into Jabish, and incinerated them there. 

#### 1 Samuel 31:13 And they took their bones and they entombed them by the plowed field, the one in Jabish, and they fasted seven days.