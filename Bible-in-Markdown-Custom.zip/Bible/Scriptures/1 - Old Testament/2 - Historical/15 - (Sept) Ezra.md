#### Ezra 1:1 And in the {year first} of Cyrus king of the Persians, to initiate the word of the LORD by the mouth of Jeremiah, the LORD awakened the spirit of Cyrus king of the Persians. And he exhorted by a report in all his kingdom, and indeed in writing, saying, 

#### Ezra 1:2 Thus said Cyrus the king of the Persians, All the kingdoms of the earth {gave to me the LORD God of heaven}. And he looked upon me to build to him a house in Jerusalem, the one in Judea. 

#### Ezra 1:3 Who is there among you of all his people, and {will be his God} with him? Then let him ascend unto Jerusalem in Judea! And let him build the house of the God of Israel! He is the God in Jerusalem. 

#### Ezra 1:4 And every Jew being left from all the places of which he sojourned there, {shall take up for him the men of his place} silver and gold, and with belongings, and cattle, with the voluntary offering for the house of God, the one in Jerusalem. 

#### Ezra 1:5 And rose up the rulers of the families of Judah, and Benjamin, and the priests, and the Levites -- all which God awakened their spirit to ascend to build the house of the LORD, the one in Jerusalem. 

#### Ezra 1:6 And all the ones round about them strengthened their hands with items of silver, with gold, and with belongings, and with cattle, and with gifts, besides the ones with voluntary offerings. 

#### Ezra 1:7 And king Cyrus brought forth the items of the house of the LORD which Nebuchadnezzar took from Jerusalem, and had put them in the house of his god. 

#### Ezra 1:8 And {brought them out Cyrus the king of the Persians} by the hand of Mithredath the treasurer, and he counted them out to Sheshbazzar the ruler of Judah. 

#### Ezra 1:9 And this is their number -- wine-coolers of gold -- thirty, and wine-coolers of silver -- a thousand, knives for altering -- nine and twenty, basins of gold -- thirty, 

#### Ezra 1:10 and {items made of silver double} -- four hundred and ten, and {items other} -- a thousand. 

#### Ezra 1:11 All the items of gold and of silver -- five thousand four hundred. The whole amount Sheshbazzar led up with {ascending the resettlement} out of Babylon into Jerusalem. 

#### Ezra 2:1 And these are the sons of the places, the ones ascending from the captivity of the resettlement of which {resettled Nebuchadnezzar the king of Babylon} in Babylon, and they returned unto Jerusalem and Judah, every man into his city. 

#### Ezra 2:2 The ones that came with Zerubbabel -- Jeshua, Nehemiah, Seraiah, Reelaiah, Mordecai, Bilshan, Mizpar, Bigvai, Rehum, Baanah. The number of men of the people of Israel. 

#### Ezra 2:3 Sons of Parosh -- two thousand a hundred seventy-two. 

#### Ezra 2:4 Sons of Shephatiah -- three hundred seventy-two. 

#### Ezra 2:5 Sons of Arah -- seven hundred seventy-five. 

#### Ezra 2:6 Sons of Pahath-moab to the sons of Jeshua and Joab -- two thousand eight hundred twelve. 

#### Ezra 2:7 Sons of Elam -- a thousand two hundred fifty-four. 

#### Ezra 2:8 Sons of Zattu -- nine hundred forty-five. 

#### Ezra 2:9 Sons of Zaccai -- seven hundred sixty. 

#### Ezra 2:10 Sons of Bani -- six hundred forty-two. 

#### Ezra 2:11 Sons of Bebai -- six hundred twenty-three. 

#### Ezra 2:12 Sons of Azgad -- a thousand two hundred twenty-two. 

#### Ezra 2:13 Sons of Adonikam -- six hundred sixty-six. 

#### Ezra 2:14 Sons of Bigvai -- two thousand fifty-six. 

#### Ezra 2:15 Sons of Adin -- four hundred fifty-four. 

#### Ezra 2:16 Sons of Ater to Hezekiah -- ninety-eight. 

#### Ezra 2:17 Sons of Bezai -- three hundred twenty-three. 

#### Ezra 2:18 Sons of Jorah -- a hundred twelve. 

#### Ezra 2:19 Sons of Hashum -- two hundred twenty-three. 

#### Ezra 2:20 Sons of Gibbar -- ninety-five. 

#### Ezra 2:21 Sons of Beth-lehem -- a hundred twenty-three. 

#### Ezra 2:22 Sons of Netophah -- fifty-six. 

#### Ezra 2:23 Sons Anathoth -- a hundred twenty-eight. 

#### Ezra 2:24 Sons of Azmaveth -- forty-two. 

#### Ezra 2:25 Sons of Kirjath-arim, Chephirah, and Beeroth -- seven hundred forty-three. 

#### Ezra 2:26 Sons of Ramah and Gaba -- six hundred twenty-one. 

#### Ezra 2:27 The men of Michmas -- a hundred twenty-two. 

#### Ezra 2:28 The men of Beth-el, and Ai -- two hundred twenty-three. 

#### Ezra 2:29 The sons of Nebo -- fifty-two. 

#### Ezra 2:30 The sons of Magbish -- a hundred fifty-six. 

#### Ezra 2:31 Sons of the other Elam -- a thousand two hundred fifty-four. 

#### Ezra 2:32 Sons of Harim -- three hundred twenty. 

#### Ezra 2:33 Sons of Lod, Hadid, and Ono -- seven hundred twenty-five. 

#### Ezra 2:34 Sons of Jericho -- three hundred forty-five. 

#### Ezra 2:35 Sons of Senaah -- three thousand six hundred thirty. 

#### Ezra 2:36 And the priests -- sons of Jedaiah, to the house of Jeshua -- nine hundred seventy-three. 

#### Ezra 2:37 Sons of Immer -- a thousand fifty-two. 

#### Ezra 2:38 Sons of Pashur -- a thousand two hundred forty-seven. 

#### Ezra 2:39 Sons of Harim -- a thousand seventeen. 

#### Ezra 2:40 And the Levites -- sons of Jeshua and Kadmiel, to the sons of Hodaviah -- seventy-four. 

#### Ezra 2:41 The singers -- sons of Asaph -- a hundred twenty-eight. 

#### Ezra 2:42 The sons of the gatekeepers -- sons of Shallum, sons of Ater, sons of Telmon, sons of Akkub, sons of Hatita, sons of Shobai, in all -- a hundred thirty-nine. 

#### Ezra 2:43 The Nethinim -- sons Ziha, sons Hasupha, sons of Tabaoth, 

#### Ezra 2:44 sons of Keros, sons of Siaha, sons of Padon, 

#### Ezra 2:45 sons of Lebanah, sons of Haggabah, sons of Akkub, 

#### Ezra 2:46 sons of Hagab, sons of Shalmai, sons of Hanan, 

#### Ezra 2:47 sons of Giddel, sons of Gahar, sons of Reaiah, 

#### Ezra 2:48 sons of Rezin, sons of Nekoda, sons of Gazzam, 

#### Ezra 2:49 sons of Uzza, sons of Paseah, sons of Besai, 

#### Ezra 2:50 sons of Asnah sons of Mehunim, sons of Nephusim, 

#### Ezra 2:51 sons of Bakbuk, sons of Hakupha, sons of Harhur, 

#### Ezra 2:52 sons of Bazluth, sons of Mehida, sons of Harsha, 

#### Ezra 2:53 sons of Barkos, sons of Sisera, sons of Thamah, 

#### Ezra 2:54 sons of Neziah, sons of Hatipha, 

#### Ezra 2:55 sons of the servants of Solomon -- sons of Sotai, sons of Sophereth, sons of Peruda, 

#### Ezra 2:56 sons of Jaalah, sons of Darkon, sons of Giddel, 

#### Ezra 2:57 sons of Shephatiah, sons of Hattil, sons of Pochereth, sons of Zebaim, sons of Ami. 

#### Ezra 2:58 All the Nethinim, and the sons of servants of Solomon -- three hundred ninety-two. 

#### Ezra 2:59 And these were the ones ascending from Tel-melah, Tel-harsa, Cherub, Addan, Immer, and they were not able to report the house of their family, and their seed, if {of Israel they are}. 

#### Ezra 2:60 The sons of Delaiah, sons of Tobiah, sons of Nekoda -- six hundred fifty-two. 

#### Ezra 2:61 And of the sons of the priests -- sons of Habaiah, sons of Koz, sons of Barzillai who took from the daughters of Barzillai the Gileadite a wife, and was called by their record. 

#### Ezra 2:62 These are which sought their record, the ones seeking descent, and they did not find it, and they were thrust out from the priesthood. 

#### Ezra 2:63 And Tirshatha spoke to them to not eat from the holy of the holies until {should rise up a priest} with the lights and the perfections. 

#### Ezra 2:64 And all the assembly together were as four ten thousand, two thousand, three hundred, sixty; 

#### Ezra 2:65 separate from their menservants and their maidservants; these were -- seven thousand three hundred thirty-seven; and with them male singers and female singers -- two hundred; 

#### Ezra 2:66 their horses -- seven hundred thirty-six; their mules -- two hundred forty-five; 

#### Ezra 2:67 their camels -- four hundred thirty-five; their donkeys -- six thousand seven hundred twenty. 

#### Ezra 2:68 And from the rulers of the families in their entering into the house of the LORD, the one in Jerusalem, {they were willing concerning the house of God} to establish it for its preparation. 

#### Ezra 2:69 According to their power they gave for the treasury for the work; gold drachmas -- six ten thousands and a thousand; and silver minas -- five thousand; and garments for the priests -- a hundred. 

#### Ezra 2:70 And these stayed (the priests, and the Levites, and the ones from the people, and the singers, and the gatekeepers, and the Nethinim) in their cities, and all Israel in their cities. 

#### Ezra 3:1 And {came the month seventh}, and the sons of Israel were in their cities, and {were brought together the people} as {man one} unto Jerusalem. 

#### Ezra 3:2 And {rose up Jeshua the son of Jozadak}, and his brethren the priests, and Zerubbabel the son of Shealtiel, and his brethren, and they built the altar of the God of Israel, to offer upon it whole burnt-offerings according as written in the law of Moses, the man of God. 

#### Ezra 3:3 And they prepared the altar upon its preparation place, but terror was upon them, because of the peoples of the lands. And they brought unto it the whole burnt-offerings, to the LORD in the morning, and in the evening. 

#### Ezra 3:4 And they observed the holiday of the tents, according to the thing being written, and the whole burnt-offerings day by day in number, according to the distinguishing manner of the reckoning day by day for it. 

#### Ezra 3:5 And after this {whole burnt-offering the perpetual}, and for the new moons, and for all holidays to the LORD were sanctified, and for every willing voluntary offering to the LORD. 

#### Ezra 3:6 On day one of the {month seventh} they began to offer whole burnt-offerings to the LORD. But the house of the LORD was not laid of a foundation. 

#### Ezra 3:7 And they gave money to the quarriers, and to the fabricators; and food, and drink, and olive oil to the Sidonians, and to the Tyrians, to bring forth wood of cedars from Lebanon by sea to Joppa, by the decree of Cyrus king of the Persians, concerning this. 

#### Ezra 3:8 And in the {year second} of their coming into the house of the LORD God, the one in Jerusalem, in {month the second}, {began Zerubbabel the son of Shealtiel}, and Jeshua the son of Jozadek, and the rest of their brethren, the priests, and the Levites, and all the ones coming from the captivity into Jerusalem, and they established the Levites from twenty years and up, to bring success upon the ones doing the works in the house of the LORD. 

#### Ezra 3:9 And Jeshua stood and his sons, and his brethren, Kadmiel and his sons, the sons of Judah over the ones doing the works in the house of God; the sons of Henadad, their sons and their brethren the Levites. 

#### Ezra 3:10 And {laid a foundation the ones building} to build the house of the LORD. And {stood the priests} being robed with trumpets, and the Levites, the sons of Asaph with cymbals, to praise the LORD by the hands of David king of Israel. 

#### Ezra 3:11 And they answered in praise and confession to the LORD, saying That he is good, that into the eon is his mercy upon Israel. And all the people shouted {voice a great} in the praising the LORD at the groundwork of the house of the LORD. 

#### Ezra 3:12 And many from the priests, and the Levites, and rulers of the families -- the elders, the ones who beheld the {house first} on its groundwork, and this house with their eyes, wept {sound a great}, and many with a shout with gladness to raise up high a sound. 

#### Ezra 3:13 And {not were the people} recognizing the sound of the cheering of gladness from the sound of the weeping of the people; for the people cried out {sound with a great}, and the voice was heard even from far off. 

#### Ezra 4:1 And {heard the ones afflicting Judah and Benjamin} that the sons of the resettlement were building a house to the LORD God of Israel. 

#### Ezra 4:2 And they approached to Zerubbabel, and to the rulers of the families, and said to them, We should build with you, for as you, we also inquire to your God; and to him we sacrifice from the days of Esar-haddon king of Assyria, the one bringing us here. 

#### Ezra 4:3 And {said to them Zerubbabel}, and Jeshua, and the rest of the rulers of the families of Israel, It is not for us and you to build a house to our God, for we ourselves together shall build to the LORD God of Israel, as {gave charge to us Cyrus the king of the Persians}. 

#### Ezra 4:4 And {were the people of the land} enfeebling the hands of the people of Judah, and they impeded them to build. 

#### Ezra 4:5 And they were hiring against them counselors to efface their counsel all the days of Cyrus king of the Persians, and unto the kingdom of Darius, the king of the Persians. 

#### Ezra 4:6 And in the kingdom of Ahasuerus, and in the beginning of his kingdom, they wrote a letter against the ones living in Judah and Jerusalem. 

#### Ezra 4:7 And in the days of Artaxerxes {wrote in peace Mithridath}, and Tabeel, with the rest of his fellow-servants to Artaxerxes king of the Persians. {wrote The tribute-gatherer} the writing in Syrian and being translated. 

#### Ezra 4:8 Rehum the master and Shimshai the scribe wrote {letter one} against Jerusalem to Artaxerxes the king, saying, 

#### Ezra 4:9 Thus {judges Rehum the master}, and Shimshai the scribe, and the rest of our fellow-servants, the Dinaites, Apharsathchites, Tarpelites, Apharsites, Archevites, Babylonians, Susanchites, Dehavites, Elamites, 

#### Ezra 4:10 and the rest of the of the nations whom {resettled Asnapper the great and the esteemed}, and settled them in the cities of Samaria, and the rest on the other side of the river. 

#### Ezra 4:11 This is the disposition of the letter which they sent to him -- To Artaxerxes the king. By your servants, the men on the other side of the river. 

#### Ezra 4:12 And now {be made known let it} to the king, that the Jews ascending from you to us came into Jerusalem the {city defecting and wicked}, which they are building; and the walls of it are being readied, and the foundations of it they elevated. 

#### Ezra 4:13 Now then let it be made known to the king, that if that city should be rebuilt, and the walls of it should be readied, that tributes, tolls, and customs they shall not give, and this {to kings does evil}! 

#### Ezra 4:14 And now {not as salt of the temple we salted}, and {an indecency concerning the king it is not allowed for us to behold}. On account of this we sent forth and made known to the king; 

#### Ezra 4:15 that it should be examined in the book of memoirs of your fathers; and you shall find in the book of the memorial, and shall know that that city {city is a defecting}, and one doing evil to kings; and {for places and flights for your runaway servants it is in the midst of it from the time of the eon}. On account of this, this city was made desolate. 

#### Ezra 4:16 We make known then ourselves to the king, that if that city should be built, and its walls should be readied for these things, {a part on the other side of the river there shall not be to you}. 

#### Ezra 4:17 And this then is the word which {sent the king} to Rehum the master, and Shimshai the scribe, and to the rest of their fellow-servants of the ones living in Samaria, and the rest on the other side of the river, saying, Peace. And says the king, 

#### Ezra 4:18 The tribute-gatherer whom you sent to us was called before me. 

#### Ezra 4:19 And by me was rendered a decree, and they examined and it was found that that city from days of the eon {against kings lifts itself up}, and defections and exiles take place in it. 

#### Ezra 4:20 And {kings strong} were over Jerusalem prevailing over all of the other side of the river. And {tribute and tolls both} and customs were given to them. 

#### Ezra 4:21 And now establish a decree {to cease work men for those}, so that that city shall not be built up any more! 

#### Ezra 4:22 So that of the decree {guarding you were} you not be remiss to do concerning this, lest at any time {should be multiplied an extinction of power} for an evil deed to happen to kings. 

#### Ezra 4:23 Then the tribute-gatherer of king Artaxerxes read in the presence of Rehum the master, and Shimshai the scribe, and his fellow-servants. And they went with diligence unto Jerusalem and to Judah, and they caused them to cease work with horses and a force. 

#### Ezra 4:24 Then {was idle the work of the house of God}, the one in Jerusalem. And it was idle until the second year of the kingdom of Darius king of Persia. 

#### Ezra 5:1 And {prophesied Haggai the prophet}, and Zechariah the son of Iddo, a prophecy over the Jews, of the ones in Judah and in Jerusalem in the name of the God of Israel, over them. 

#### Ezra 5:2 Then rose up Zerubbabel the son of Shealtiel, and Jeshua son of Jozadak, and they began to build the house of God, the one in Jerusalem; and with them were the prophets of God to help them. 

#### Ezra 5:3 At that same time there came upon them Tatnai chief ruler on the other side of the river, and Shethar-boznai, and their fellow-servants, and of such he said to them, Who ordained to you a decree to build this house, and {this expense to ready}? 

#### Ezra 5:4 Then they said to them, What are the names of the men building this city? 

#### Ezra 5:5 But the eyes of God became upon the captivity of Judah, and they did not cause them to cease work until the decree was carried to Darius. And then it was given to the tribute-gatherer concerning this. 

#### Ezra 5:6 The explanation by letter which was sent by Tatnai the chief ruler on the other side of the river, and Shethar-boznai, and their fellow-servants -- Apharsachites, the ones on the other side of the river, to Darius the king. 

#### Ezra 5:7 {a word They sent} to him, and thus was written in it, To Darius the king, all peace. 

#### Ezra 5:8 Let it be known to the king! that we went into Judea, the place for the house of the great God, and it is being built with the {stones choice}; and timber is inserted in the walls, and that work is fittingly done, and the way is prospering in their hands. 

#### Ezra 5:9 Then we asked those elders, and thus we said to them, Who rendered to you a decree {this house to build}, and the bestowing of this expense to ready it? 

#### Ezra 5:10 And {their names we asked of them}, to make known to you, so as to write to you the names of the men of their rulers. 

#### Ezra 5:11 And such a word they answered to us, saying to us, We are menservants of the God of the heaven and of the earth, and we are building the house which was built {before this years many}, and {king of Israel a great} built it, and readied it for them. 

#### Ezra 5:12 {from when But provoked to anger our fathers} the God of heaven, he gave them into the hands of Nebuchadnezzar king of Babylon, the Chaldean, and this house he caused to rest, and the people he resettled in Babylon. 

#### Ezra 5:13 But in {year the first} of Cyrus the king of the Babylonians, Cyrus the king rendered a decree {house of God this to build}. 

#### Ezra 5:14 And the items of the house of God, the ones of gold and silver, which Nebuchadnezzar brought forth from the house, of the one in Jerusalem, and carried them into the temple of the king, the one in Babylon -- {brought them forth Cyrus the king} from the temple, of the one in Babylon, and gave them to Sheshbazzar, to the treasurer, to the one over the treasury. 

#### Ezra 5:15 And he said to him, These items take and go! Put them in the house in Jerusalem! And the house of God -- let it be built in its place! 

#### Ezra 5:16 Then that Sheshbazzar came and put down the foundations of the house of God, the one in Jerusalem. And from then until now it is being built, and was not finished. 

#### Ezra 5:17 And now if for the king it seems good, let it be overseen in the house of the treasury of the king there in Babylon! so as to know that if from king Cyrus {was rendered a decree} to build the house of God, that one in Jerusalem. And {knowing the king} concerning this, let him send forth a reply to us! 

#### Ezra 6:1 Then Darius the king rendered a decree, and examined in the libraries, of which the treasuries were situated there in Babylon. 

#### Ezra 6:2 And there was found in Achmetha the city, in the palace of the Mede city, {chapter of a scroll one}, and this was {written in it the record}. 

#### Ezra 6:3 In {year the first} of king Cyrus, Cyrus the king rendered a decree concerning the house of God, the one in Jerusalem, saying, {the house Let} be built, and the place of which they sacrifice the sacrifices! And {the foundations set}, the height {cubits of sixty}, and the width of it {cubits sixty}, 

#### Ezra 6:4 and {layers stones of fortified three}, and {layer timbers of new one}! And the expense {out of the house of the king shall be granted}. 

#### Ezra 6:5 And the items of the house of God, the ones of gold, and the ones of silver, which Nebuchadnezzar brought forth from the house, of the one in Jerusalem, and carried into Babylon; even let them be given, and brought forth into the temple, of the one in Jerusalem, unto their place, and put them in the house of God! 

#### Ezra 6:6 Now then Tatnai commandant of the other side of the river, Shethar-boznai, and his fellow-servants the Apharsachites, the ones on the other side of the river, {far be being from there}. 

#### Ezra 6:7 And now leave alone the work of the house of God, and the ones guiding of the Jews, and the elders of the Jews! {house of God that Let them build} upon its place! 

#### Ezra 6:8 And by me was rendered a decree to do through the elders of those Jews to build {house of God that}, and from the subsistence of the king, of the tribute on the other side of the river, that carefully an expense be given to those men to not cease work! 

#### Ezra 6:9 And what ever deficiency -- both male offspring of oxen, and rams, and lambs for whole burnt-offerings to the God of the heaven, and wheat, salt, wine, olive oil, according to the word of the priests, the ones in Jerusalem, let it be given to them day by day, unalterable, what ever they should ask! 

#### Ezra 6:10 That there might be a pleasant aroma offering to the God of the heaven, and they might pray for the life of the king, and his sons. 

#### Ezra 6:11 And from me was rendered a decree, that every man who ever changes this word {shall be demolished the timber of his house}, and a stake being straight up he shall be pitched upon it, and his house will be for ravaging. 

#### Ezra 6:12 And the God of whom encamps with his name there, he shall eradicate every king and people who should stretch out his hand to change and remove from view the house of God, that one in Jerusalem. I Darius rendered the decree. Carefully let it become! 

#### Ezra 6:13 Then Tatnai the chief ruler on the other side of the river, and Shethar-boznai, and his fellow-servants, in so far as {sent Darius the king}, thus they did carefully. 

#### Ezra 6:14 And the elders of the Jews built, and prospered at the prophecy of Haggai the prophet, and Zechariah son of Iddo. And they rebuilt, and made ready by the decree of the God of Israel, and by the decree of Cyrus, and Darius, and Artaxerxes kings of Persia. 

#### Ezra 6:15 And they finished this house by {day the third} of the month Adar, which is in {year the sixth} of the kingship of Darius the king. 

#### Ezra 6:16 And they made (the sons of Israel, the priests and the Levites, and the rest of the sons of the resettlement) a holiday of rededication of the house of God with gladness. 

#### Ezra 6:17 And they offered for the holiday of rededication {house of God of this}; calves -- a hundred; rams -- two hundred; lambs -- four hundred; winter yearlings of the goats for a sin offering for all Israel -- twelve, for the number of the tribes of Israel. 

#### Ezra 6:18 And they established the priests in their divisions, and the Levites in their distributions, for service of the house of God, of the one in Jerusalem, according to the writing of the book of Moses. 

#### Ezra 6:19 And {observed the sons of the resettlement} the passover on the fourteenth of the {month first}. 

#### Ezra 6:20 For {were purified the priests and the Levites}, {as one man all were clean}. And they slew the passover for all the sons of the resettlement, and for their brethren the priests, and for themselves. 

#### Ezra 6:21 And {ate the sons of Israel} the passover -- the ones coming forth from the resettlement, and every one separating themself of the uncleanness of the nations of the land that was theirs to inquire of the LORD God of Israel. 

#### Ezra 6:22 And they observed the holiday of the unleavened breads seven days with gladness; for {gladdened them the LORD}, and turned the heart of the king of Assyria to them, to fortify their hands in the works of the house of the God of Israel. 

#### Ezra 7:1 And after these things, in the kingdom of Artaxerxes king of the Persians, there ascended Ezra the son of Seraiah, son of Azariah, son of Hilkiah, 

#### Ezra 7:2 son of Shallum, son of Zadok, son of Ahitub, 

#### Ezra 7:3 son of Amariah, son of Azariah, son of Meraioth, 

#### Ezra 7:4 son of Zerahiah, son of Uzzi, son of Bukki, 

#### Ezra 7:5 son of Abishua, son of Phinehas, son of Eleazar, son of Aaron the {priest foremost}. 

#### Ezra 7:6 This Ezra ascended from out of Babylon; and he {scribe was a quick} in the law of Moses, which {gave the LORD God of Israel}. And {gave to him the king}; for the hand of the LORD his God was upon him in all things which he sought. 

#### Ezra 7:7 And there ascended some from the sons of Israel, and from the priests, and from the Levites, and the singers, and the gatekeepers, and the Nethinim, to Jerusalem, in {year the seventh} of Artaxerxes the king. 

#### Ezra 7:8 And they came to Jerusalem in the {month fifth}, this was the {year seventh} of the king. 

#### Ezra 7:9 For on day one of the {month first} he founded the expedition from Babylon. And during the first day of the {month fifth} he came into Jerusalem, for the hand of his God was good upon him. 

#### Ezra 7:10 For Ezra prepared his heart to seek the law of the LORD, and to do and to teach in Israel the orders and judgments. 

#### Ezra 7:11 And this is the copy of the edict which {gave Artaxerxes the king} to Ezra the priest, to the scribe of the scroll of the words of the commandments of the LORD, and his orders unto Israel. 

#### Ezra 7:12 Artaxerxes king of kings, to Ezra the priest, scribe of the law of the God of heaven. Let {be initiated, the matter and the answer}. 

#### Ezra 7:13 From me was rendered a decree, that all the ones willing in my kingdom from the people of Israel, and priests, and Levites, to go to Jerusalem -- with you let them go! 

#### Ezra 7:14 In so far as from in front of the king, and {seven counselors of his}, one should be sent to look about over Judea and Jerusalem, and in the law of their God in your hand, 

#### Ezra 7:15 to carry away even {for the house of the LORD silver and gold}, which the king and the counselors were willing to give to the God of Israel, to the one {in Jerusalem inhabiting}. 

#### Ezra 7:16 And all the silver and gold, whatever you should find in every place of Babylon, let it be offered with a voluntary offering of the people, and the priests, of the ones willing to give for the house of God, the one in Jerusalem. 

#### Ezra 7:17 And every one going {this readily you arrange} by this scroll -- calves, rams, lambs, and their sacrifice offerings, and their libation offerings! And you shall offer them upon the altar of the house of your God, of the one in Jerusalem. 

#### Ezra 7:18 And if anything {with you and your brethren should seem good} with the rest of the silver and gold to do, as it pleases your God, you do it! 

#### Ezra 7:19 And the items, the ones given to you for the ministration of the house of God, you deliver before God in Jerusalem! 

#### Ezra 7:20 And for the rest of the need of the house of your God, what ever should be apparent to you to give, you shall give from {houses treasury the king's}. 

#### Ezra 7:21 I Artaxerxes the king established a decree to all the treasuries, to the ones on the other side of the river, that all what ever he should ask of you (Ezra the priest and scribe of the law of the God of heaven) readily let it become so! 

#### Ezra 7:22 Unto {of silver talents a hundred}, and unto {of wheat cors a hundred}, and unto {of wine baths a hundred}, and unto {of olive oil baths a hundred}, and salt of which the amount is not recorded. 

#### Ezra 7:23 All what is in the decree of the God of the heaven, let it become in the house of the God of the heaven! Take heed lest any make an attempt against the house of the God of the heaven! lest at any time {should happen anger} upon the kingdom of the king, and his sons. 

#### Ezra 7:24 And to you, let it be made known in respect to all the priests, and to the Levites, singers, gatekeepers, Nethinim, and ministers of the house of God! that this tribute, and toll, and impost, {do not have you} authority to assign upon them. 

#### Ezra 7:25 And you, Ezra, according to the wisdom of God, the wisdom in your hand, ordain scribes and judges! that they might judge all the people, the people on the other side of the river, to all the ones knowing the laws of your God. And to the ones not knowing you shall make it known. 

#### Ezra 7:26 And all who ever might not be observing the law of God and the law of the king diligently, judgment will be taken upon him, whether for death, whether to root him out, or to instruct, or to penalize the subsistence, or for prison to lock up. 

#### Ezra 7:27 Blessed be the LORD God of our fathers, who put it in the heart of the king thus, to glorify the house of the LORD, the one in Jerusalem. 

#### Ezra 7:28 And upon me {leaned mercy} in the eyes of the king, and his counselors, and all the rulers of the king of the mighty ones. And I was strengthened by the {hand of the LORD my God good} upon me, and I gathered from Israel rulers to ascend with me. 

#### Ezra 8:1 And these are the rulers of their families, and the genealogy of the ones ascending with me, in the kingdom of Artaxerxes the king of Babylon. 

#### Ezra 8:2 Of the sons of Phinehas -- Gershom; of the sons of Ithamar -- Daniel; of the sons of David -- Hattush; 

#### Ezra 8:3 of the sons of Shechaniah of the sons of Pharosh -- Zechariah, and {with him having traced descent the males} -- a hundred and fifty. 

#### Ezra 8:4 Of the sons Pahath-moab -- Elihoenai son of Zerahiah, and with him two hundred males. 

#### Ezra 8:5 Of the sons Shechaniah -- son Jahaziel, and with him three hundred males. 

#### Ezra 8:6 Of the sons of Adin -- Ebed son of Jonathan, and with him fifty males. 

#### Ezra 8:7 Of the sons of Elam -- Jeshaiaih son of Athaliah, and with him seventy males. 

#### Ezra 8:8 Of the sons of Shephatiah -- Zebadiah son of Michael, and with him eighty males. 

#### Ezra 8:9 Of the sons of Joab -- Obadiah son of Jehiel, and with him two hundred eighteen males. 

#### Ezra 8:10 From the sons of Shelomith -- son of Josiphiah, and with him a hundred sixty males. 

#### Ezra 8:11 From the sons of Bebai -- Zechariah son of Bebai, and with him twenty-eight males. 

#### Ezra 8:12 From the sons of Azgad -- Johanan son of Hakkatan, and with him, a hundred ten males. 

#### Ezra 8:13 Of the sons of Adonikam last, and these are the names of them -- Eliphelet, Jeiel, and Shemaiah, and with them sixty males. 

#### Ezra 8:14 Of the sons of Bigvai -- Uthai and Zabbud, and with them seventy males. 

#### Ezra 8:15 And I gathered them to the river, the one coming to Ahava; and we camped there {days three}. And I perceived among the people, and among the priests, {any from the sons of Levi there were not} found there. 

#### Ezra 8:16 And I sent to Eleazar, to Ariel, to Shemaiah, and to Elnathan, and to Jarib to Elnatham, to Nathan, to Zechariah, to Meshullam, rulers; to Joiarib, and to Elnathan, ones perceiving. 

#### Ezra 8:17 And I gave charge to them to Iddo the ruler of Casiphia of the place. And I put in their mouths words to speak to Iddo, and to their brethren of the Nethinim, of the ones with the money of the place Casiphia, to bring to us ministers and singers into the house of our God. 

#### Ezra 8:18 And they came to us as the {hand of our God good} was upon us, {man with a discerning} from the sons of Mahli, the son of Levi of Israel. And Sherebiah, and his sons, and his brethren -- eighteen. 

#### Ezra 8:19 And Hashabiah and Jeshaiah from the sons of Merari, his brethren and his sons -- twenty. 

#### Ezra 8:20 And from the Nethinim, whom David appointed and the rulers for service of the Levites -- {Nethinim two hundred twenty}; all these were named. 

#### Ezra 8:21 And I called there a fast at the river Ahava, to humble ourselves before our God, to seek by him {way a straight} for us, and for our children, and for all our property. 

#### Ezra 8:22 For I was ashamed to ask from the king for a force and horsemen to deliver us from the enemy in the way; for we said to the king, saying, The hand of our God is upon all the ones seeking him for good, and his might and his rage is upon all the ones abandoning him. 

#### Ezra 8:23 And we fasted and sought from our God concerning this; and he heeded us. 

#### Ezra 8:24 And I separated {of the rulers of the priests twelve}, to Sherebiah, to Hashabiah, and with them from their brethren -- ten. 

#### Ezra 8:25 And I set before them the silver and the gold, and the items of the first-fruit of the house of our God, which {separated in dedication the king}, and his counselors, and his rulers, and all {of Israel the ones being found}. 

#### Ezra 8:26 And I set in their hands silver -- {talents six hundred fifty}, and vessels made of silver -- a hundred, and talents of gold -- a hundred; 

#### Ezra 8:27 and {bowls of gold twenty drachmas of a thousand}, and vessels of brass, shining, good quality, diverse, desirable as gold. 

#### Ezra 8:28 And I said to them, You are holy to the LORD God, and the {vessels holy}, and the silver, and the gold are a voluntary offering to the LORD God of our fathers. 

#### Ezra 8:29 Be awake and give heed until you set them before the rulers of the priests and the Levites, and rulers of the families of Israel in Jerusalem, in the cubicles of the house of the LORD! 

#### Ezra 8:30 And {took the priests and the Levites} the weight of the silver, and the gold, and the vessels, to bring them into Jerusalem into the house of our God. 

#### Ezra 8:31 And we lifted away from the river Ahava on the twelfth of the {month first}, to come unto Jerusalem. And the hand of our God was upon us, and he rescued us from the hand of the enemy, and the warlike people along the way. 

#### Ezra 8:32 And we came into Jerusalem, and we stayed there {days three}. 

#### Ezra 8:33 And on the {day fourth} we set the silver, and the gold, and the vessels in the house of our God into the hand of Meremoth son of Uriah the priest; and with him was Eleazar son of Phinehas; and with them was Jozabad son of Jeshua, and Noadiah son of Binnui -- the Levites. 

#### Ezra 8:34 By number and by weight all were measured; and {was written down all the weight} at that time. 

#### Ezra 8:35 And the ones coming out of the captivity, sons of the sojourn, brought whole burnt-offerings to the God of Israel; calves -- twelve for all Israel, rams -- ninety-six, lambs -- seventy-seven, winter yearlings of the goats for the sin offering -- twelve; the whole amount for whole burnt-offerings to the LORD. 

#### Ezra 8:36 And they gave the mandate of the king to the administrators of the king, and chief rulers on the other side of the river; and they glorified the people, and the house of God. 

#### Ezra 9:1 And as these things were finished, {approached to me the rulers}, saying, {did not separate The people of Israel}, and the priests and the Levites, from the peoples of the lands in their abominations -- of the Canaanite, the Hittite, the Perizzite, the Jebusite, the Ammonite, the Moabite, and the Moserite, and the Amorite. 

#### Ezra 9:2 For they took of their daughters to themselves, and to their sons, and {mixed together seed the holy} among the peoples of the lands; even by the hand of the rulers and of the commandants in this breach-of-contract in rule. 

#### Ezra 9:3 And as I heard this word, I tore my garments and my undergarment, and was agitated, and plucked the hair of my head, and of my beard, and sat down for calming. 

#### Ezra 9:4 And there gathered to me everyone trembling at the word of the God of Israel concerning the breach-of-contract of the resettlement. And I was sitting calming myself until the {sacrifice evening}. 

#### Ezra 9:5 And during {sacrifice the evening} I rose up from my humiliation, and in my tearing my garments, and my undergarment, and I leaned upon my knees, and I spread forth my hands to the LORD my God. 

#### Ezra 9:6 And I said, O LORD, I am ashamed and feel shame to raise up, O my God, my face to you; for our lawlessnesses multiplied over our head, and our trespasses are magnified unto the heaven. 

#### Ezra 9:7 From the days of our fathers we are in {trespass great} until this day. And in our lawless deeds we were delivered up, and our kings, and our priests, into the hand of the kings of the nations, by broadsword, and into captivity, and in seizure, and in shame of our face, as this day. 

#### Ezra 9:8 And now as {a little was lenient to us the LORD our God}, to leave us for deliverance, and to give to us reliance in the place of his sanctuary, to enlighten our eyes, and to give {restoration to life a little} in our servitude, 

#### Ezra 9:9 for we are servants, and in our servitude {did not abandon us the LORD our God}; and he leaned {towards us mercy} before the kings of the Persians, to give us a restoring to life, for them to exalt the house of our God, and to reestablish its deserted places, and to give to us a fence in Judah and Jerusalem. 

#### Ezra 9:10 And now, what should we say, O our God, after this? For we abandoned your commandments, 

#### Ezra 9:11 the ones which you gave to us by the hand of your servants the prophets, saying, The land into which you enter there, to be an heir to it, {a land in motion is} by the removal of the peoples of the lands of their abominations, which they filled it from mouth to mouth in their uncleannesses. 

#### Ezra 9:12 And now, {your daughters do not give} to their sons, and of their daughters do not take to your sons, and do not require their peace and their good will into the eon! for you should grow in strength, and should eat the good of the land, and allot it to your sons unto the eon. 

#### Ezra 9:13 And after all the things coming upon us by our actions in the wicked things, and by {trespasses our great}, that you our God lightened of us the lawless deeds, and gave to us deliverance; 

#### Ezra 9:14 for we turned to efface your commandments, and allied by marriage to the peoples of the these lands. You should not be provoked by us unto consumption, so that there should not be one left over and preserved to us. 

#### Ezra 9:15 O LORD God of Israel, you are just, for we were left being preserved as in this day. Behold, we all are before you in our trespasses; for there is no standing before you in this. 

#### Ezra 10:1 And as Ezra prayed, and as he confessed weeping and falling before the house of God, there came together to him from Israel {assembly vast an exceedingly}, men and women and young people; for {weeping a great wept the people}. 

#### Ezra 10:2 And answered one Shechaniah son of Jehiel, from the sons of Elam, and said to Ezra, We broke contract with our God, and settled with {wives alien} from the peoples of the land. And now there is hope to Israel for this thing. 

#### Ezra 10:3 And now we should ordain a covenant with our God, to lead out all the wives and the ones being born from them, according to counsel of the LORD, and of the ones trembling in the commandments of our God. And {according to the law let it be}! 

#### Ezra 10:4 Rise up, for {concerns you the matter}, and we are with you -- strengthen and do! 

#### Ezra 10:5 And Ezra rose up, and bound by an oath the rulers of the priests, and Levites, and all Israel, to do according to this word. And they swore by an oath. 

#### Ezra 10:6 And Ezra rose up from in front of the house of God, and went into the treasury of Johanan son of Eliashib, and he lodged there; {bread he did not eat}, and {water did not drink}, for he mourned over the breach-of-contract by the resettlement. 

#### Ezra 10:7 And they carried about a report in Judah and in Jerusalem to all the sons of the resettlement, to gather together in Jerusalem, saying, 

#### Ezra 10:8 Every one who ever should not come for three days, according to the counsel of the rulers and of the elders, {shall be devoted to consumption all his substance}, and he shall be separated from the assembly of the resettlement. 

#### Ezra 10:9 And {gathered together all the men of Judah and Benjamin} in Jerusalem for the three days. And this was the {month ninth}. On the twentieth of the month {sat all the people} in the square of the house of God in trembling concerning the matter, and because of the distress. 

#### Ezra 10:10 And {rose up Ezra the priest}, and said to them, You have broken the contract, and settled with {wives alien}, to add to the trespass of Israel. 

#### Ezra 10:11 And now, give praise to the LORD God of our fathers, and do the pleasing thing before him, and draw apart from the peoples of the land, and from the {wives alien}! 

#### Ezra 10:12 And answered all the assembly {voice with a great}, and said, According to your words which you said, thus we will do. 

#### Ezra 10:13 But the people are vast, and it is the time of winter, and there is no ability to stand outside, and the work is not for {day one}, nor two; for we multiplied the wrong in this matter. 

#### Ezra 10:14 Let {stand indeed our rulers} in every assembly! and to all the ones in our cities who settled with {wives alien}, let them come at {times arranged}, and with them the elders city by city, and judges! to turn the anger of the rage of our God from us, on account of this matter. 

#### Ezra 10:15 Only Jonathan son of Asahel and Jahaziah son of Tikvah were with me; and Meshullam and Shabbethai the Levite assisted them. 

#### Ezra 10:16 And {did thus the sons of the resettlement}. And {drew apart Ezra the priest}, and the men rulers of the families of the households, and all by names, for they returned on day one of the {month tenth} to inquire of the matter. 

#### Ezra 10:17 And they finished with questioning all the men settling with {wives alien} until day one of the {month first}. 

#### Ezra 10:18 And there were found of the sons of the priests, the ones settling with {wives alien}, some of the sons of Jeshua son of Jozadak, and of his brethren Maaseiah, and Eliezer, and Jarib, and Gedaliah. 

#### Ezra 10:19 And they gave their hand in pledge to bring forth their own wives; and they gave trespass offerings -- a ram of the sheep for their trespass offering. 

#### Ezra 10:20 And of the sons of Immer -- Hanani and Zebadiah. 

#### Ezra 10:21 And of the sons of Harim -- Maaseiah, and Elijah, and Shemaiah, and Jehiel, and Uzziah. 

#### Ezra 10:22 And of the sons of Phasur -- Elioenai, Maaseiah, Ishmael, and Nathaneel, and Jozabad and Elasah. 

#### Ezra 10:23 And of the Levites -- Jozabad, and Shemei, and Kelaiah -- he is Kelita, and Pethahiah, and Judah, and Eliezer. 

#### Ezra 10:24 And of the singers -- Eliashib. And of the gatekeepers -- Shallum, and Telem, and Uri. 

#### Ezra 10:25 And of Israel, of the sons of Parosh -- Ramiah, and Jeziah, and Malchiah, and Miamin, and Eleazar, and Malchijah, and Benaiah. 

#### Ezra 10:26 And of the sons of Elam -- Mattaniah, and Zechariah, and Jehiel, and Abdi, and Jeremoth, and Eliah. 

#### Ezra 10:27 And of the sons of Zattu -- Elioenai, Eliashib, Mattaniah, and Jeremoth, and Zabad, and Aziza. 

#### Ezra 10:28 And of the sons of Bebai -- Jehohanan, and Hananiah, and Zabbai, and Athlai. 

#### Ezra 10:29 And of the sons of Bani -- Meshullam, and Malluch, and Adaiah, and Jashub, and Sheal, and Ramoth. 

#### Ezra 10:30 And of the sons Pahath-moab -- Adna, and Chelal, and Benaiah, and Maaseiah, and Matthaniah, and Bezaleel, and Binnui, and Manasseh. 

#### Ezra 10:31 And of the sons of Harim -- Eliezer, Ishijah, Malchiah, Shemaiah, Shimeon, 

#### Ezra 10:32 Benjamin, Malluch, and Shemariah. 

#### Ezra 10:33 And of the sons of Hashum -- Mattenai, Mattathah, Zabad, Eliphelet, Jeremai, Manasseh, and Shimei. 

#### Ezra 10:34 And of the sons of Bani -- Maadai, Amram, and Uel, 

#### Ezra 10:35 Benaiah, Bedeiah, Chelluh, 

#### Ezra 10:36 Vaniah, Meremoth, Eliashib, 

#### Ezra 10:37 Mattaniah, and Mattenai. 

#### Ezra 10:38 And so did the sons of Bani and the sons of Shimei, 

#### Ezra 10:39 and Shelemiah, and Nathan, and Adaiah, 

#### Ezra 10:40 and Machnadebai, and Sharai, and Shashai 

#### Ezra 10:41 Azareel, and Shelemiah, and Shemariah, 

#### Ezra 10:42 and Shallum, and Amariah, and Joseph. 

#### Ezra 10:43 From the sons of Nebo -- Jeiel, Mattithiah, Zabad, Zebina, Jadau, Joel, and Benaiah. 

#### Ezra 10:44 All these took {wives alien}; and also there are of them {of the wives in which they engendered of them sons}.