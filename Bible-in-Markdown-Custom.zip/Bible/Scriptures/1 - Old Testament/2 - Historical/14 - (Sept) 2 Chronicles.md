#### 2 Chronicles 1:1 And {grew in strength Solomon son of David} over his kingdom, and the LORD his God was with him, and magnified him in stature. 

#### 2 Chronicles 1:2 And Solomon spoke to all Israel, to the commanders of thousands, and to the commanders of hundreds, and to the judges, and to all the rulers before all Israel, to the rulers of the families. 

#### 2 Chronicles 1:3 And Solomon went out and all the assembly with him unto the high place in Gibeon, of which {was located the tent of the testimony of God}, which {made Moses the servant of the LORD} in the wilderness. 

#### 2 Chronicles 1:4 {the But ark of God David brought} from out of the city of Kirjath Jearim, for {prepared for it David}; for he pitched a tent for it in Jerusalem. 

#### 2 Chronicles 1:5 And the altar of brass which {made Bezaleel son of Uri son of Hur} was there before the tent of the LORD. And {sought by it Solomon and the assembly}. 

#### 2 Chronicles 1:6 And Solomon offered there upon the altar, the one of brass, the one before the LORD, the one in the tent of the testimony. And he offered upon it {whole burnt-offerings a thousand}. 

#### 2 Chronicles 1:7 In that night God appeared to Solomon, and he said to him, Ask what I shall give to you! 

#### 2 Chronicles 1:8 And Solomon said to God, You performed with David my father {act of kindness a great}, and gave me reign instead of him. 

#### 2 Chronicles 1:9 And now, O LORD God, let {be trustworthy your word} with David my father! For you gave me reign over a people vast as the dust of the earth. 

#### 2 Chronicles 1:10 Now {wisdom and understanding give to me}! and I shall go forth before this people and enter in. For who shall judge {people your great this}? 

#### 2 Chronicles 1:11 And God said to Solomon, Because this happened in your heart, and you did not ask wealth of things, nor glory, nor the life of the ones detesting you, and you did not ask for {days many}; but you asked for yourself wisdom and understanding, so as to judge my people, over whom I gave you to reign over it -- 

#### 2 Chronicles 1:12 the wisdom and the understanding I give to you; and wealth, and possessions, and glory I shall give to you, as did not happen likened unto you among the kings before you, and {after you it will not be thus}. 

#### 2 Chronicles 1:13 And Solomon came from Bama, of the one in Gibeon, unto Jerusalem, from the face of the tent of the testimony; and he reigned over Israel. 

#### 2 Chronicles 1:14 And Solomon brought together chariots and horsemen; and there were to him a thousand and four hundred chariots, and twelve thousand horsemen. And he left them in the cities of the chariots, and with the king in Jerusalem. 

#### 2 Chronicles 1:15 And {established the king} silver and gold in Jerusalem as the stones; and the cedars in Judea as sycamine trees, the ones in the plains in multitude. 

#### 2 Chronicles 1:16 And there was an exodus of the horses to Solomon from Egypt, and {by the value of the merchants of the king to go forth they were bought}. 

#### 2 Chronicles 1:17 And they ascended and brought from out of Egypt {chariot one} for six hundred pieces of silver, and a horse for fifty and a hundred. And thus to all the kings of the Hittites, and to the kings of Syria, {by their hands they brought them forth}. 

#### 2 Chronicles 2:1 And Solomon spoke to build the house to the name of the LORD, and a house for his kingdom. 

#### 2 Chronicles 2:2 And Solomon brought together seventy thousand men load carriers, and eighty thousand men quarrying in the mountain. And the supervisors over them -- three thousand and six hundred. 

#### 2 Chronicles 2:3 And Solomon sent to Hiram king of Tyre, saying, As you did with David my father, and sent to him cedars to build for himself a house to dwell in it, 

#### 2 Chronicles 2:4 then behold, I his son am building a house to the name of the LORD my God, to sanctify it to him, to burn before him incense of aromatics, and for a place setting to be continually before him, and to offer whole burnt-offerings continually in the morning and the evening, and on the Sabbaths, and on the new moons, and on the holidays of the LORD our God. Into the eon this is for Israel. 

#### 2 Chronicles 2:5 And the house which I build is to be great, for great is the LORD our God beyond all the gods. 

#### 2 Chronicles 2:6 And who is strong to build to him a house? For the heaven and the heaven of the heaven does not bear him. And who am I building to him a house, except to burn incense in front of him? 

#### 2 Chronicles 2:7 And now, send to me {man a wise}, and one knowing how to prepare in gold, and in silver, and in brass, and in iron, and in purple, and in scarlet, and in blue, and having knowledge to carve carved works with the wise ones, of the ones with me in Judah and in Jerusalem, which {prepared David my father}! 

#### 2 Chronicles 2:8 And send to me timbers of cedars, and of junipers, and of pines, from out of Lebanon! for I know that your servants know how to fell timbers from Lebanon. And behold, my servants shall go with your servants, 

#### 2 Chronicles 2:9 to prepare for me timbers in multitude, for the house which I build is great and glorious. 

#### 2 Chronicles 2:10 And behold, to the ones working in the felling timbers, {for foods I have given grain} as gifts to your servants of cors of wheat -- twenty thousand, and barley cors -- twenty thousand, and wine measures -- twenty thousand, and olive oil measures -- twenty thousand. 

#### 2 Chronicles 2:11 And {spoke Hiram king of Tyre} by writing, and sent to Solomon, saying, In the LORD loving his people, he put you over them for king. 

#### 2 Chronicles 2:12 And Hiram said, Blessed be the LORD God of Israel, who made the heaven and the earth, who gave to {David king son a wise}, and knowing understanding and higher knowledge, who shall build a house to the LORD, and a house for his kingdom. 

#### 2 Chronicles 2:13 And now, I have sent to you a man wise and knowing understanding -- Hiram my servant, 

#### 2 Chronicles 2:14 a son of a woman from the daughters of Dan, and his father is a Tyrian man, knowing how to prepare in gold, and in silver, and in brass, and in iron, and in stones, and woods, and to weave in purple, and in blue, and in linen, and in scarlet, and to carve carvings, and to consider every device in which ever you should give to him with your wise men, and the wise ones of my master David your father. 

#### 2 Chronicles 2:15 And now the grain, and the barley, and the olive oil, and the wine, which {spoke my master}, let him send it to his servants! 

#### 2 Chronicles 2:16 And we will fell trees from out of Lebanon, according to all your need. And we will bring them by barge upon the sea to Joppa; and you shall bring them up unto Jerusalem. 

#### 2 Chronicles 2:17 And Solomon gathered all the men of the foreigners of the ones in the land of Israel, after the count which {counted them David his father}. And were found a hundred fifty thousand and three thousand six hundred. 

#### 2 Chronicles 2:18 And he made of them seventy thousand load carriers, and eighty thousand quarriers in the mountain, and three thousand six hundred foremen over the people. 

#### 2 Chronicles 3:1 And Solomon began to build the house of the LORD in Jerusalem on mount Moriah, of which the LORD appeared to David his father, in the place which David prepared on the threshing-floor of Ornan the Jebusite. 

#### 2 Chronicles 3:2 And he began to build in the {month second}, in the {year fourth} of his kingdom. 

#### 2 Chronicles 3:3 And these Solomon began to build: the house of God -- the length of the {measurement first} {cubits was sixty}, and the breadth {cubits twenty}. 

#### 2 Chronicles 3:4 And the columned porch before the face of the house -- its length upon the face of the width of the house {cubits was twenty}, and the height {cubits was a hundred and twenty}. And he gilded it inside {gold in pure}. 

#### 2 Chronicles 3:5 And the {house great} he boarded with woods of cedars, and he gilded it {gold in pure}. And he carved upon it palms and chainwork. 

#### 2 Chronicles 3:6 And he adorned the house {stones with valuable} for glory; and the gold was gold from Parvaim. 

#### 2 Chronicles 3:7 And he gilded the house, and its walls, and the gatehouses, and the roofing, and the doorways with gold; and he carved cherubim upon the walls. 

#### 2 Chronicles 3:8 And he made the house of the holy of the holies. Its length upon the face of the width of the house {cubits was twenty}, and the breadth {cubits was twenty}. And he gilded it {gold in pure} amounting to {talents six hundred}. 

#### 2 Chronicles 3:9 And the scale-weight of the nails -- the scale-weight of the one was fifty shekels of gold. And the upper room he gilded in gold. 

#### 2 Chronicles 3:10 And he made in the house, in the holy of the holies, {cherubim two}, a work of {wood incorruptible}, and he gilded them in gold. 

#### 2 Chronicles 3:11 And the wings of the cherubim -- the length {cubits was twenty}, and to the {wing one cubits was five} touching the wall of the house. 

#### 2 Chronicles 3:12 And the {wing other cubits was five}, touching the wing of the {cherub other}. 

#### 2 Chronicles 3:13 And the wings of these cherubim being open and spread out {cubits was twenty}. And these stood upon their feet, and their faces were towards the house. 

#### 2 Chronicles 3:14 And he made the veil out of blue, and purple, and scarlet, and of linen. And he wove {in it cherubim}. 

#### 2 Chronicles 3:15 And he made in front of the house {columns two} -- {cubits thirty-five} in height, and their capitals {cubits were five}. 

#### 2 Chronicles 3:16 And he made chain-work in the dabir, and he put them upon the tops of the columns. And he made {figures of pomegranates a hundred}, and put them upon the chainwork. 

#### 2 Chronicles 3:17 And he set the columns at the front of the temple, one at the right and one at the left. And he called the name of the one at the right -- Success, and the name of the one at the left -- Strength. 

#### 2 Chronicles 4:1 And he made an altar of brass -- twenty cubits was the length, and twenty cubits the breadth, and ten cubits the height. 

#### 2 Chronicles 4:2 And he made the {sea cast} -- ten cubits the diameter, from its lip to its lip, globular round about, and five cubits was the height. And the circumference -- thirty cubits encircled it round about. 

#### 2 Chronicles 4:3 And a representation of calves was underneath it, round about encircling it; ten in a cubit encircling the sea round about; with two rows of {oxen cast} in their being cast in a furnace, 

#### 2 Chronicles 4:4 in which they made them. And standing upon twelve calves was the sea. The three were looking north, and three were looking west, and three were looking south, and three were looking towards the east. And the sea was upon them upward. And {were posteriors their} towards the inside. 

#### 2 Chronicles 4:5 And its thickness was a palm, and its lip was as a lip of a cup, having been carved of buds of a lily, having a capacity {measures of three thousand}. And he completed it. 

#### 2 Chronicles 4:6 And he made {bathing tubs ten}, and put five on the right, and five on the left, to wash in them the works of the whole burnt-offerings, and to rinse off in them. But the sea was for the washing of the priests in it. 

#### 2 Chronicles 4:7 And he made the lamp-stands of gold -- ten, according to their distinguishing manner. And he put in the temple, five on the right, and five on the left. 

#### 2 Chronicles 4:8 And he made {tables ten}, and he put them in the temple, five on the right, and five on the left. And he made {bowls of gold a hundred}. 

#### 2 Chronicles 4:9 And he made the courtyard of the priests, and the {courtyard great}, and doors for the courtyard; and their doorways were being brazed in brass. 

#### 2 Chronicles 4:10 And the sea he put at the corner of the house at the right towards the east of the part towards the south. 

#### 2 Chronicles 4:11 And Hiram made the kettles, and the meat hooks, and the censers. And Hiram completed doing all the work which he did for Solomon the king in the house of God -- 

#### 2 Chronicles 4:12 making {columns two}, and the pommels, and the capitals upon the tops of the {columns two}, and {latticed works two} to cover up the two pommels of the capitals, which are upon the tops of the columns; 

#### 2 Chronicles 4:13 and pomegranates of gold -- four hundred for the two latticed works; two kinds of pomegranates on the {latticed work one}, to cover the two bases of the capitals, which are upon the columns. 

#### 2 Chronicles 4:14 And {the bases he made} -- ten; and the bathing tubs he made upon the bases, 

#### 2 Chronicles 4:15 and the {sea one}, and the {calves twelve} underneath it, 

#### 2 Chronicles 4:16 and the kettles, and the meat hooks and bowls. And all their items which Hiram made, he brought to king Solomon in the house of the LORD -- {brass all of pure}. 

#### 2 Chronicles 4:17 In the place round about the Jordan {cast them the king} in the thick earth, between Succoth and between Zeredathah. 

#### 2 Chronicles 4:18 And Solomon made all these items in multitude, exceedingly; for {was not wanting the scale-weight of the brass}. 

#### 2 Chronicles 4:19 And Solomon made all the items of the house of the LORD, and the altar of gold, and the tables, and upon them bread loaves of the place setting. 

#### 2 Chronicles 4:20 And the lamp-stands, and the lamps for the light according to the distinguishing manner in front of the dabir, {gold of pure}. 

#### 2 Chronicles 4:21 And their lamps, and their tongs, and the bowls, and the incense pans, and the censers {gold were of pure}. 

#### 2 Chronicles 4:22 And the {door of the house inner}, which is in the holies of the holies, and the doors of the house of the temple, were in gold. 

#### 2 Chronicles 5:1 And {was completed all the work} which Solomon did in the house of the LORD; and Solomon carried in the holy things of David his father, and the silver, and the gold, and all the items; and he put them in a treasury house of the LORD. 

#### 2 Chronicles 5:2 Then Solomon held an assembly of all the elders of Israel, and all the rulers of the tribes, rulers of the families of the sons of Israel in Jerusalem, to bring the ark of the covenant of the LORD from out of the city of David -- this is Zion. 

#### 2 Chronicles 5:3 And {was assembled unto the king every man of Israel} in the holiday -- this the {month seventh}. 

#### 2 Chronicles 5:4 And {came all the elders of Israel}, and {took all the Levites} the ark. 

#### 2 Chronicles 5:5 And they brought the ark, and the tent of the testimony, and all the {items holy}, the ones in the tent; and {brought it the priests and the Levites}. 

#### 2 Chronicles 5:6 And king Solomon, and all the gathering of Israel, and the ones being assembled unto him before the ark were sacrificing calves and sheep, which shall not be counted nor considered because of the multitude. 

#### 2 Chronicles 5:7 And {carried in the priests} the ark of the covenant of the LORD into its place, into the dabir of the house, into the holies of the holies, underneath the wings of the cherubim. 

#### 2 Chronicles 5:8 And {were the cherubim} being opened and spread out of their wings over the place of the ark. And {covered the cherubim} the ark, and over its bearing poles on top. 

#### 2 Chronicles 5:9 And {projected the bearing poles}, and {were seen the tips of the bearing poles} from the ark of the holies in front of the dabir, and they were not seen outside. And they were there until this day. 

#### 2 Chronicles 5:10 Nothing was in the ark except the two tablets which Moses stationed at Horeb, which the LORD ordained with the sons of Israel in their coming forth from out of the land of Egypt. 

#### 2 Chronicles 5:11 And it came to pass in the coming forth of the priests from out of the holy places, (for all the priests being found were sanctified, for they were not then set in order according to daily rotation) 

#### 2 Chronicles 5:12 and the Levites, the psalm singers, all with the sons of Asaph, of Heman, to Jeduthun, and to their sons, and to their brethren of the ones putting on apparels of fine linen, with cymbals, and with stringed instruments, and with lutes, were standing over against the altar, and with them {priests a hundred and twenty} trumpeting with the trumpets. 

#### 2 Chronicles 5:13 And there was one sound in the trumpeting, and in the singing along with stringed instruments, and in the sounding out loud {voice with one} to praise and to make acknowledgement to the LORD. And as they raised up high the voice with the trumpets, and with cymbals, and with instruments for the odes, that they said, Make acknowledgment to the LORD for he is good, for into the eon is his mercy! And the house was filled up of the cloud and of the glory of the LORD. 

#### 2 Chronicles 5:14 And {were not able the priests} to stand to officiate before the face of the cloud, for {filled up the glory of the LORD} the house of God. 

#### 2 Chronicles 6:1 Then Solomon said, The LORD spoke to encamp in dimness. 

#### 2 Chronicles 6:2 And I have built a house to your name holy to you, and prepared to encamp into the eons. 

#### 2 Chronicles 6:3 And {turned the king} his face, and he blessed all the assembly of Israel. And all the assembly of Israel stood by. 

#### 2 Chronicles 6:4 And he said, Blessed be the LORD God of Israel, who spoke by his mouth to David my father, and by his hands he fulfilled, saying, 

#### 2 Chronicles 6:5 From the day which I led my people from out of the land of Egypt, I did not choose a city from all the tribes of Israel to build a house {to be for my name} there, and I did not choose a man to be for leader over my people Israel. 

#### 2 Chronicles 6:6 And I chose Jerusalem {to be for my name} there, and I chose David to be above my people Israel. 

#### 2 Chronicles 6:7 And it came upon the heart of David my father to build a house to the name of the LORD God of Israel. 

#### 2 Chronicles 6:8 And the LORD said to David my father, Because it was upon your heart to build a house to my name, {well you do}, for it was upon your heart. 

#### 2 Chronicles 6:9 Except you shall not build to me a house, for your son who comes forth from out of your loin, he shall build the house to my name. 

#### 2 Chronicles 6:10 And the LORD established the word which he spoke. And I became instead of David my father, and I sit upon the throne of Israel, as the LORD said, and I built the house to the name of the LORD God of Israel. 

#### 2 Chronicles 6:11 And I put there the ark, in which {is located the covenant of the LORD}, which he ordained with Israel. 

#### 2 Chronicles 6:12 And he stood before the altar of the LORD, before all the assembly of Israel, and he opened and spread out his hands. 

#### 2 Chronicles 6:13 For Solomon made {platform a brass}, and he put it in the midst of the courtyard of the temple -- five cubits was its length, and five cubits was its breadth, and three cubits was its height. And he stood upon it, and he bent upon his knees before all the assembly of Israel, and he opened and spread out his hands into the heaven. 

#### 2 Chronicles 6:14 And he said, O LORD God of Israel, there is no {likened to you God} in heaven, nor upon the earth, keeping the covenant, and showing mercy to your children, to the ones going before you with all their heart, 

#### 2 Chronicles 6:15 which you kept with your servant David my father, which you spoke to him; and you spoke by your mouth, and by your hands you fulfilled it, as this day. 

#### 2 Chronicles 6:16 And now, O LORD the God of Israel, keep with your servant David, my father, what you spoke to him, saying, There shall not fail to you a man from before my face sitting upon the throne of Israel, if only {should guard your sons} their way to go by my law, as you went before me. 

#### 2 Chronicles 6:17 And now, O LORD God of Israel, let be trustworthy indeed your saying, which you spoke to your manservant David. 

#### 2 Chronicles 6:18 For shall {truly dwells God} with men upon the earth? If the heaven and the heaven of the heaven is not sufficient to you; then what is this house which I built? 

#### 2 Chronicles 6:19 And should you look upon the prayer of your manservant, and upon his supplication, O LORD my God, to heed the supplication and the prayer, which your manservant prayed before you today; 

#### 2 Chronicles 6:20 {to be for your eyes} open unto this house day and night, in this place which you said to call upon your name there; to hear the prayer which {prayed your manservant} in this place. 

#### 2 Chronicles 6:21 Then shall you hear the supplication of your manservant, and of your people Israel, in what ever they should pray to this place. And you shall hear from the place of your dwelling -- from the heaven; and you shall hear and shall be propitious. 

#### 2 Chronicles 6:22 If {should sin a man} against his neighbor, and he takes upon him an oath to cause him to make an oath, and he should come and make an oath against the altar in this house; 

#### 2 Chronicles 6:23 then you shall listen from out of the heaven, and shall act, and shall judge your servants, to recompense to the lawless one, and to recompense his ways upon his head; and to do justice to the just, to recompense to him according to his righteousness. 

#### 2 Chronicles 6:24 And if {should be devastated your people Israel} before an enemy, if they should sin against you, and should turn, and should acknowledge your name, and should pray, and should beseech before you in this house; 

#### 2 Chronicles 6:25 then you shall listen from the heaven, and you should be propitious to the sins of your people Israel, and shall return them into the land which you gave to them and to their fathers. 

#### 2 Chronicles 6:26 And in the holding together the heaven, and there is no rain, because they sinned against you, and they pray to this place, and confess to your name, and from their sins they shall turn, because you shall humble them; 

#### 2 Chronicles 6:27 then you shall listen from heaven, and shall be propitious to the sins of your servants, and your people Israel, that you shall make manifest to them the {way good}, in which they shall go by it. And you shall put rain upon your land, which you gave to your people for an inheritance. 

#### 2 Chronicles 6:28 If famine happens upon the land, if plague happens -- wind-blown blight, jaundice; {locust and grasshopper if there should be}; and if {should afflict it its enemies} in the land against its cities, according to every calamity and every misery; 

#### 2 Chronicles 6:29 then every prayer, and all supplication, whichever should be by any man, and all your people Israel, if {should know a man} his infection and his infirmity, and should open and spread out his hands to this house; 

#### 2 Chronicles 6:30 then you shall listen from the heaven, from {prepared home your}, and you shall atone, and shall give to a man according to his ways, as you should know his heart; (for you most only know the heart of the sons of men.) 

#### 2 Chronicles 6:31 So that they should fear you, to go in all your ways, all the days which they should live upon the face of the land, of which you gave to our fathers. 

#### 2 Chronicles 6:32 And also every alien who is not of your people Israel, and he should come from out of a land far off because of {name your great}, and {hand your fortified}, and {arm your high}; and should come and should pray in this place; 

#### 2 Chronicles 6:33 then you shall listen from out of the heaven, from {prepared home your}, and you shall do according to all as much as {should have called upon you the alien}; so that {should know all the peoples of the earth} your name, and to fear you, as your people Israel, and to know that your name is called upon in this house which I built. 

#### 2 Chronicles 6:34 And if {should go forth your people} for war against its enemies, in the way which you shall send them, and they should pray to you towards the way of this city which you chose, towards it and the house which I built to your name; 

#### 2 Chronicles 6:35 then you shall hear {from out of the heaven their prayer and their supplication}, and shall do them justice. 

#### 2 Chronicles 6:36 For they shall sin against you, (for there is not a man who shall not sin,) and if enraged over them, and you should deliver them before the face of the enemies, and {shall take them captive the ones capturing} into a land far or near; 

#### 2 Chronicles 6:37 and they should turn their heart in the land of which they were taken captive there, and they shall turn and should beseech you in the land of their captivity, saying, We sinned, we acted lawlessly, and we acted impiously; 

#### 2 Chronicles 6:38 and they should turn towards you with all their heart, and with all their soul in the land of their being taken captive, of which they took them captive there, and they should pray in the way of their land, of which you gave to their fathers, and of the city of which you chose, and the house of which I built to your name; 

#### 2 Chronicles 6:39 then you shall hear from the heaven, from {prepared home your}, of their prayer and their supplication, and you shall make their case, and you shall be propitious to the people sinning against you. 

#### 2 Chronicles 6:40 And now, O LORD God, let {be indeed your eyes} open, and your ears attentive to the supplication of this place! 

#### 2 Chronicles 6:41 And now, rise up O LORD God in your rest, you and the ark of your strength! Your priests, O LORD God, shall clothe themselves in deliverance, and your sacred ones shall be glad in good things. 

#### 2 Chronicles 6:42 O LORD God, you should not turn the face of your anointed one. Remember the mercies of David your servant! 

#### 2 Chronicles 7:1 Then Solomon said, The LORD spoke to encamp in dimness. 

#### 2 Chronicles 7:2 And I have built a house to your name holy to you, and prepared to encamp into the eons. 

#### 2 Chronicles 7:3 And {turned the king} his face, and he blessed all the assembly of Israel. And all the assembly of Israel stood by. 

#### 2 Chronicles 7:4 And he said, Blessed be the LORD God of Israel, who spoke by his mouth to David my father, and by his hands he fulfilled, saying, 

#### 2 Chronicles 7:5 From the day which I led my people from out of the land of Egypt, I did not choose a city from all the tribes of Israel to build a house {to be for my name} there, and I did not choose a man to be for leader over my people Israel. 

#### 2 Chronicles 7:6 And I chose Jerusalem {to be for my name} there, and I chose David to be above my people Israel. 

#### 2 Chronicles 7:7 And it came upon the heart of David my father to build a house to the name of the LORD God of Israel. 

#### 2 Chronicles 7:8 And the LORD said to David my father, Because it was upon your heart to build a house to my name, {well you do}, for it was upon your heart. 

#### 2 Chronicles 7:9 Except you shall not build to me a house, for your son who comes forth from out of your loin, he shall build the house to my name. 

#### 2 Chronicles 7:10 And the LORD established the word which he spoke. And I became instead of David my father, and I sit upon the throne of Israel, as the LORD said, and I built the house to the name of the LORD God of Israel. 

#### 2 Chronicles 7:11 And I put there the ark, in which {is located the covenant of the LORD}, which he ordained with Israel. 

#### 2 Chronicles 7:12 And he stood before the altar of the LORD, before all the assembly of Israel, and he opened and spread out his hands. 

#### 2 Chronicles 7:13 For Solomon made {platform a brass}, and he put it in the midst of the courtyard of the temple -- five cubits was its length, and five cubits was its breadth, and three cubits was its height. And he stood upon it, and he bent upon his knees before all the assembly of Israel, and he opened and spread out his hands into the heaven. 

#### 2 Chronicles 7:14 And he said, O LORD God of Israel, there is no {likened to you God} in heaven, nor upon the earth, keeping the covenant, and showing mercy to your children, to the ones going before you with all their heart, 

#### 2 Chronicles 7:15 which you kept with your servant David my father, which you spoke to him; and you spoke by your mouth, and by your hands you fulfilled it, as this day. 

#### 2 Chronicles 7:16 And now, O LORD the God of Israel, keep with your servant David, my father, what you spoke to him, saying, There shall not fail to you a man from before my face sitting upon the throne of Israel, if only {should guard your sons} their way to go by my law, as you went before me. 

#### 2 Chronicles 7:17 And now, O LORD God of Israel, let be trustworthy indeed your saying, which you spoke to your manservant David. 

#### 2 Chronicles 7:18 For shall {truly dwells God} with men upon the earth? If the heaven and the heaven of the heaven is not sufficient to you; then what is this house which I built? 

#### 2 Chronicles 7:19 And should you look upon the prayer of your manservant, and upon his supplication, O LORD my God, to heed the supplication and the prayer, which your manservant prayed before you today; 

#### 2 Chronicles 7:20 {to be for your eyes} open unto this house day and night, in this place which you said to call upon your name there; to hear the prayer which {prayed your manservant} in this place. 

#### 2 Chronicles 7:21 Then shall you hear the supplication of your manservant, and of your people Israel, in what ever they should pray to this place. And you shall hear from the place of your dwelling -- from the heaven; and you shall hear and shall be propitious. 

#### 2 Chronicles 7:22 If {should sin a man} against his neighbor, and he takes upon him an oath to cause him to make an oath, and he should come and make an oath against the altar in this house; 

#### 2 Chronicles 7:23 then you shall listen from out of the heaven, and shall act, and shall judge your servants, to recompense to the lawless one, and to recompense his ways upon his head; and to do justice to the just, to recompense to him according to his righteousness. 

#### 2 Chronicles 7:24 And if {should be devastated your people Israel} before an enemy, if they should sin against you, and should turn, and should acknowledge your name, and should pray, and should beseech before you in this house; 

#### 2 Chronicles 7:25 then you shall listen from the heaven, and you should be propitious to the sins of your people Israel, and shall return them into the land which you gave to them and to their fathers. 

#### 2 Chronicles 7:26 And in the holding together the heaven, and there is no rain, because they sinned against you, and they pray to this place, and confess to your name, and from their sins they shall turn, because you shall humble them; 

#### 2 Chronicles 7:27 then you shall listen from heaven, and shall be propitious to the sins of your servants, and your people Israel, that you shall make manifest to them the {way good}, in which they shall go by it. And you shall put rain upon your land, which you gave to your people for an inheritance. 

#### 2 Chronicles 7:28 If famine happens upon the land, if plague happens -- wind-blown blight, jaundice; {locust and grasshopper if there should be}; and if {should afflict it its enemies} in the land against its cities, according to every calamity and every misery; 

#### 2 Chronicles 7:29 then every prayer, and all supplication, whichever should be by any man, and all your people Israel, if {should know a man} his infection and his infirmity, and should open and spread out his hands to this house; 

#### 2 Chronicles 7:30 then you shall listen from the heaven, from {prepared home your}, and you shall atone, and shall give to a man according to his ways, as you should know his heart; (for you most only know the heart of the sons of men.) 

#### 2 Chronicles 7:31 So that they should fear you, to go in all your ways, all the days which they should live upon the face of the land, of which you gave to our fathers. 

#### 2 Chronicles 7:32 And also every alien who is not of your people Israel, and he should come from out of a land far off because of {name your great}, and {hand your fortified}, and {arm your high}; and should come and should pray in this place; 

#### 2 Chronicles 7:33 then you shall listen from out of the heaven, from {prepared home your}, and you shall do according to all as much as {should have called upon you the alien}; so that {should know all the peoples of the earth} your name, and to fear you, as your people Israel, and to know that your name is called upon in this house which I built. 

#### 2 Chronicles 7:34 And if {should go forth your people} for war against its enemies, in the way which you shall send them, and they should pray to you towards the way of this city which you chose, towards it and the house which I built to your name; 

#### 2 Chronicles 7:35 then you shall hear {from out of the heaven their prayer and their supplication}, and shall do them justice. 

#### 2 Chronicles 7:36 For they shall sin against you, (for there is not a man who shall not sin,) and if enraged over them, and you should deliver them before the face of the enemies, and {shall take them captive the ones capturing} into a land far or near; 

#### 2 Chronicles 7:37 and they should turn their heart in the land of which they were taken captive there, and they shall turn and should beseech you in the land of their captivity, saying, We sinned, we acted lawlessly, and we acted impiously; 

#### 2 Chronicles 7:38 and they should turn towards you with all their heart, and with all their soul in the land of their being taken captive, of which they took them captive there, and they should pray in the way of their land, of which you gave to their fathers, and of the city of which you chose, and the house of which I built to your name; 

#### 2 Chronicles 7:39 then you shall hear from the heaven, from {prepared home your}, of their prayer and their supplication, and you shall make their case, and you shall be propitious to the people sinning against you. 

#### 2 Chronicles 7:40 And now, O LORD God, let {be indeed your eyes} open, and your ears attentive to the supplication of this place! 

#### 2 Chronicles 7:41 And now, rise up O LORD God in your rest, you and the ark of your strength! Your priests, O LORD God, shall clothe themselves in deliverance, and your sacred ones shall be glad in good things. 

#### 2 Chronicles 7:42 O LORD God, you should not turn the face of your anointed one. Remember the mercies of David your servant! 

#### 2 Chronicles 8:1 And it came to pass after twenty years, in which Solomon built the house of the LORD, and his house, 

#### 2 Chronicles 8:2 and the cities which Hiram gave to Solomon, {built them up Solomon}, and settled there the sons of Israel. 

#### 2 Chronicles 8:3 And Solomon came into Hamath Zobah, and prevailed over it. 

#### 2 Chronicles 8:4 And he built Tadmor in the wilderness, and all the {cities fortified} which he built in Hamath. 

#### 2 Chronicles 8:5 And he built {Beth-horon upper}, and {Beth-horon lower}, {cities fortified} with walls, gates, and bars; 

#### 2 Chronicles 8:6 and Baalath, and all the {cities fortified} which were unto Solomon, and all the cities of the chariots, and the cities of the horsemen, and as much as Solomon desired according to the desire to build in Jerusalem, and in Lebanon, and in all the land of his authority. 

#### 2 Chronicles 8:7 All the people left behind from the Hittite, and the Amorite, and the Perizzite, and the Hivite, and the Jebusite, who are not of Israel, 

#### 2 Chronicles 8:8 but were of their sons being left behind after them in the land of which {did not utterly destroy the sons of Israel}, and {led them Solomon} into tribute until this day. 

#### 2 Chronicles 8:9 And {any of the sons of Israel did not appoint Solomon} as servants for all his works in his kingdom, for they were men warriors, and rulers, and mighty men, and rulers of his chariots, and of his horsemen. 

#### 2 Chronicles 8:10 And these rulers of the superintendents of king Solomon were fifty and two hundred directing works among the people. 

#### 2 Chronicles 8:11 And {the daughter of Pharaoh Solomon led} from the city of David into the house which he built for her. For he said, {shall not dwell My wife} in the city of David the king of Israel, for it is holy, because {entered there the ark of the LORD}. 

#### 2 Chronicles 8:12 Then Solomon offered whole burnt-offerings to the LORD upon the altar of the LORD, which he built before the temple, 

#### 2 Chronicles 8:13 according to the reckoning, day by day, to offer according to the commandments of Moses, on the Sabbaths, and at the months, and in the holidays, three times during the year -- in the holiday of the unleavened breads, and in the holiday of the period of sevens, and in the holiday of the tents. 

#### 2 Chronicles 8:14 And he established, according to the ordinance of David his father, the divisions of the priests according to their ministrations, and of the Levites over their watches, to praise and to officiate before the priests, according to the reckoning -- day by day; and of the gatekeepers in their divisions -- for gate by gate; for thus was the commandment of David the man of God. 

#### 2 Chronicles 8:15 They did not go by without heeding the commandments of the king, concerning the priests and the Levites, in any matter, and in the treasures. 

#### 2 Chronicles 8:16 And {was prepared all the work of Solomon} from which day {foundation was laid the house} of the LORD, and until of which time it was finished, until of which time Solomon finished the house of the LORD. 

#### 2 Chronicles 8:17 Then Solomon set out unto Ezion-geber, and unto Eloth, the one by the sea in the land of Edom. 

#### 2 Chronicles 8:18 And Hiram sent by the hand of his servants boats, and servants knowing the sea. And they set out with the servants of Solomon to Ophir, and they took from there four hundred and fifty talents of gold, and they brought them to king Solomon. 

#### 2 Chronicles 9:1 And the queen of Sheba heard the name Solomon, and she came to test him with enigmas, unto Jerusalem, with {force heavy an exceedingly}, and camels carrying aromatics, and gold in multitude, and {stone valuable}. And she came to Solomon, and she spoke to him all as much as was in her soul. 

#### 2 Chronicles 9:2 And {announced to her Solomon} all her words, and not {went by a word} from Solomon which he did not report to her. 

#### 2 Chronicles 9:3 And {beheld the queen of Sheba} the wisdom of Solomon, and the house which he built, 

#### 2 Chronicles 9:4 and the foods of his tables, and the form of his servants, and the station of his ministers, and their garments, and his wine servers, and their uniform, and the whole burnt-offerings which he offered in the house of the LORD; and there was no {in her any longer breath}. 

#### 2 Chronicles 9:5 And she said to the king, {is true The word} which I heard in my land concerning your words, and concerning your wisdom. 

#### 2 Chronicles 9:6 And I did not trust in the words until of which time I came and beheld with my eyes. And behold, {was not reported to me the half} of the magnitude of your wisdom being added over the hearing which I heard. 

#### 2 Chronicles 9:7 Blessed are your men, blessed are {your servants these}, the ones standing beside you always, and hearing your wisdom. 

#### 2 Chronicles 9:8 May {be the LORD your God} for a blessing, who wanted by you to put you upon his throne for a king to your God; in that {loved the LORD your God} Israel, to establish it into the eon, and he put you over them as king, to execute equity and righteousness. 

#### 2 Chronicles 9:9 And she gave to the king a hundred twenty talents of gold, and aromatics in {multitude very great}, and {stone valuable}. And there was not any according to those aromatics which {gave the queen of Sheba} to king Solomon. 

#### 2 Chronicles 9:10 And the servants of Hiram, and the servants of Solomon brought gold to Solomon from out of Ophir, and wood of pines, and {stone valuable}. 

#### 2 Chronicles 9:11 And {made the king} {from the wood of pines ascents} for the house of the LORD, and for the house of the king, and harps and stringed instruments for the singers. And there was not seen such as these before in the land of Judah. 

#### 2 Chronicles 9:12 And king Solomon gave to the queen of Sheba all her wants, which she asked for, outside of all what she brought to king Solomon. And she returned unto her land. 

#### 2 Chronicles 9:13 And was the weight of the gold being brought to Solomon in {year one} -- six hundred and sixty-six talents of gold, 

#### 2 Chronicles 9:14 besides {the men arranging and trading what} brought. And all the kings of Arabia, and the satraps of the land brought gold and silver to king Solomon. 

#### 2 Chronicles 9:15 And {made king Solomon} two hundred shields {gold hammered out}, with six hundred weights {gold of pure} being used upon {shield the one}. 

#### 2 Chronicles 9:16 And three hundred shields of hammered out gold of three hundred weights of gold bore upon {shield each}. And {put them the king} in the house of the forest of Lebanon. 

#### 2 Chronicles 9:17 And {made the king throne ivory of tusks a great}, and he gilded it {gold in unadulterated}. 

#### 2 Chronicles 9:18 And there were six stairs to the throne being bonded with gold, and {a footstool he placed under in gold} the throne, and armrest angles on this side and on that side upon {of the throne the chair}, and two lions standing by the armrest angles. 

#### 2 Chronicles 9:19 And twelve lions standing there upon the six stairs on this side and on that side; there was not such in any kingdom. 

#### 2 Chronicles 9:20 And all the items of king Solomon were gold, and all the items of the house of the forest of Lebanon {with gold were overtaken}. {was not Silver} considered {in the days of Solomon as anything}. 

#### 2 Chronicles 9:21 For ships belonging to the king went to Tarshish with the servants of Hiram. Once in three years {came boats} from Tarshish to the king being full of gold, and silver, and tusks of ivory, and apes. 

#### 2 Chronicles 9:22 And Solomon was magnified above all the kings of the earth, even in riches and wisdom. 

#### 2 Chronicles 9:23 And all the kings of the earth sought the face of Solomon to hear his wisdom, of which God put in his heart. 

#### 2 Chronicles 9:24 And they brought, each one his gifts -- items made of silver, and items of gold, and clothes, weapons, balsam, and spices, horses, and mules, accordingly year by year. 

#### 2 Chronicles 9:25 And there were to Solomon four thousand female horses for chariots, and twelve thousand horsemen. And he stationed them in the cities of the chariots, and with the king in Jerusalem. 

#### 2 Chronicles 9:26 And he was leader of all the kings from the river and unto the land of the Philistines, and unto the border of Egypt. 

#### 2 Chronicles 9:27 And {made the king} silver in Jerusalem as stones, and he made the cedars as the sycamine trees, the ones in the plain in multitude. 

#### 2 Chronicles 9:28 And the delivery of the horses from out of Egypt to Solomon even was from all the lands. 

#### 2 Chronicles 9:29 And the rest of the words of Solomon, the first and the last, behold are not these written by the words of Nathan the prophet, and by the words of Ahijah the Shilonite, and in the visions of Iddo the seer concerning Jeroboam the son of Nebat? 

#### 2 Chronicles 9:30 And Solomon reigned in Jerusalem over all Israel forty years. 

#### 2 Chronicles 9:31 And Solomon slept with his fathers, and they entombed him in the city of David his father. And {reigned Rehoboam his son} instead of him. 

#### 2 Chronicles 10:1 And Rehoboam came unto Shechem, for unto Shechem came all Israel to give reign to him. 

#### 2 Chronicles 10:2 And it came to pass when {heard Jeroboam son of Nebat}, (for he was in Egypt, as he fled from the face of Solomon the king, and Jeroboam dwelt in Egypt,) that Jeroboam returned from out of Egypt. 

#### 2 Chronicles 10:3 And they sent and called him. And Jeroboam came, and all the assembly of Israel, and they spoke to Rehoboam, saying, 

#### 2 Chronicles 10:4 Your father hardened our yoke; and now, you lighten from the {servitude of your father hard}, and from {yoke his heavy} which he put upon us! and we will serve to you. 

#### 2 Chronicles 10:5 And he said to them, Go until three days, and then come to me! And {went forth the people}. 

#### 2 Chronicles 10:6 And {brought together king Rehoboam} the elders of the ones standing before Solomon his father during his life, saying, How do you counsel to answer {to this people a word}? 

#### 2 Chronicles 10:7 And they spoke to him, saying, If in today you should be for good to this people, and you should please them, and should speak to them {words good}, then they will be to you for servants all the days. 

#### 2 Chronicles 10:8 And he forsook the counsel of the elders, the ones advising to him, and he was advised by the young men of the ones being brought up with him, of the ones standing before him. 

#### 2 Chronicles 10:9 And he said to them, What {do you counsel that I shall answer word} to this people who spoke to me, saying, Spare us from the yoke of which {put your father} upon us? 

#### 2 Chronicles 10:10 And {said to him the young men having been brought up with him}, saying, Thus shall you speak to the people, to the one speaking to you, saying, Your father oppressed our yoke, and you now lighten from our yoke! Thus you shall say to them, {small finger My} is thicker than the loin of my father. 

#### 2 Chronicles 10:11 And now my father inserted to you {yoke a heavy}, but I will add upon your yoke. My father corrected you with whips, but I will correct you with scorpions. 

#### 2 Chronicles 10:12 And Jeroboam came and all the people to Rehoboam on the {day third}, as {said the king}, saying, Return to me on the {day third}! 

#### 2 Chronicles 10:13 And {answered them the king} hard; and {abandoned king Rehoboam} the counsel of the elders. 

#### 2 Chronicles 10:14 And he spoke to them according to the counsel of the younger men, saying, My father oppressed your yoke, and I will add upon it. My father corrected you with whips, and I will correct you with scorpions. 

#### 2 Chronicles 10:15 And {did not hearken to the king} the people. For he was converted from God, that the LORD should establish his word, which he spoke by the hand of Ahijah the Shilonite concerning Jeroboam son of Nebat. 

#### 2 Chronicles 10:16 And all Israel saw that {did not hearken the king} to them. And {answered the people} to the king, saying, What is our portion with David, and the inheritance with the son of Jesse? Run to your tents, O Israel! Now look to your own house, David! And {went all Israel} to its tents. 

#### 2 Chronicles 10:17 And as far as the men of Israel dwelling in the cities of Judah, {reigned over them Rehoboam}. 

#### 2 Chronicles 10:18 And {sent Rehoboam the king} Hadoram, the one over the tribute. And {stoned him the sons of Israel} with stones, and he died. And king Rehoboam hastened to ascend into the chariot to flee unto Jerusalem. 

#### 2 Chronicles 10:19 And Israel annulled allegiance to the house of David until this day. 

#### 2 Chronicles 11:1 And Rehoboam came into Jerusalem, and he held an assembly of Judah and Benjamin -- a hundred eighty thousand young men for making war, to wage war against Israel, to return the kingdom to Rehoboam. 

#### 2 Chronicles 11:2 And came to pass the word of the LORD to Shemaiah the man of God, saying, 

#### 2 Chronicles 11:3 Say to Rehoboam the son of Solomon, king of Judah, and to all Israel, the one with Judah and Benjamin, saying! 

#### 2 Chronicles 11:4 Thus says the LORD, You shall not ascend, and you shall not wage war against your brethren. Let {return each} to his house! for {from me took place this thing}. And they heeded the word of the LORD, and they turned to not go against Jeroboam. 

#### 2 Chronicles 11:5 And Rehoboam dwelt in Jerusalem, and he built {cities walled} in Judea. 

#### 2 Chronicles 11:6 And he rebuilt Beth-lehem and Etam and Tekoa, 

#### 2 Chronicles 11:7 and Beth-zur, and Shoco, and Adullam, 

#### 2 Chronicles 11:8 and Gath, and Mareshah, and Ziph, 

#### 2 Chronicles 11:9 and Adoraim, and Lachish, and Azekah, 

#### 2 Chronicles 11:10 and Zorah, and Aijalon, and Hebron, which are {of Judah and Benjamin cities walled}. 

#### 2 Chronicles 11:11 And he fortified them with walls, and he appointed in them leaders, and provisions of foods, and olive oil and wine; 

#### 2 Chronicles 11:12 accordingly city by city with shields and spears. And he strengthened them in magnitude exceedingly, and {were his Judah and Benjamin}. 

#### 2 Chronicles 11:13 And the priests and the Levites who were in all Israel, came together to him from out of all the borders. 

#### 2 Chronicles 11:14 For {left behind the Levites} their tents, the ones of their possession, and they went to Judah unto Jerusalem, for {cast them out Jeroboam and his sons} to not officiate to the LORD. 

#### 2 Chronicles 11:15 And he placed for himself priests of the high places, and for the idols, and for the vain things, and for the calves which Jeroboam made. 

#### 2 Chronicles 11:16 And he cast them out from the tribes of Israel, the ones who gave their heart to seek the LORD God of Israel. And they came into Jerusalem to sacrifice to the LORD, to the God of their fathers. 

#### 2 Chronicles 11:17 And they strengthened the kingdom of Judah, and they strengthened Rehoboam son of Solomon for {years three}; for he went by way of David and Solomon for {years three}. 

#### 2 Chronicles 11:18 And {took to himself Rehoboam} for a wife Mahalath daughter of Jerimoth son of David, and Abihail daughter of Eliab son of Jesse. 

#### 2 Chronicles 11:19 And she bore to him sons -- Jeush, and Shamariah, and Zaham. 

#### 2 Chronicles 11:20 And after these he took Maachah to himself, the daughter of Absalom; and she bore to him Abijah, and Attai, and Ziza, and Shelomith. 

#### 2 Chronicles 11:21 And Rehoboam loved Maacha daughter of Absalom above all his wives and the concubines; for {wives eighteen he had}, and {concubines sixty}. And he engendered twenty and eight sons, and {daughters sixty}. 

#### 2 Chronicles 11:22 And Rehoboam ordained Abijah the son of Maacha as ruler, and for leader among his brethren, for he considered to give him reign. 

#### 2 Chronicles 11:23 And he grew above all his sons, in all the borders of Judah and Benjamin, and in the {cities fortified}; and he gave to them {of provisions multitude a vast}; and he asked for a multitude of wives. 

#### 2 Chronicles 12:1 And it came to pass as {was prepared the kingdom of Rehoboam}, and as he was secure, he abandoned the law of the LORD, and all Israel with him. 

#### 2 Chronicles 12:2 And it came to pass in the {year fifth} of the kingdom of Rehoboam, {ascended Shishak king of Egypt} up against Jerusalem, (for they sinned before the LORD), 

#### 2 Chronicles 12:3 with a thousand and two hundred chariots, and sixty thousand horsemen, and there was no count of the multitude coming with him out of Egypt -- Lubim, Sukkiim, and Ethiopians. 

#### 2 Chronicles 12:4 And they secured the {cities fortified} which were in Judah, and they came to Jerusalem. 

#### 2 Chronicles 12:5 And Shemaiah the prophet came to Rehoboam, and to the rulers of Judah, the ones gathering together in Jerusalem from the face of Shishak. And he said to them, Thus said the LORD, You abandoned me, and I shall abandon you into the hand of Shishak. 

#### 2 Chronicles 12:6 And {were shamed the rulers of Israel and the king}, and they said, {is just the LORD}. 

#### 2 Chronicles 12:7 And when the LORD saw that they were ashamed, {came the word of the LORD} to Shemaiah, saying, They felt shame, I shall not utterly ruin them, but I will appoint them as small for deliverance, and in no way shall {be dripped my rage} over Jerusalem by the hand of Shishak, 

#### 2 Chronicles 12:8 for they will be to him for servants, and they shall know my servitude, and the servitude of the kingdom of the land. 

#### 2 Chronicles 12:9 And {ascended Shishak king of Egypt} against Jerusalem, and he took the treasures of the ones in the house of the LORD, and the treasures of the ones in the house of the king -- he took all, and he took the shields of gold which Solomon made. 

#### 2 Chronicles 12:10 And {made king Rehoboam} shields of brass instead of them, and placed them unto the hands of the rulers, of the ones being bodyguards, of the ones guarding the gatehouse of the king. 

#### 2 Chronicles 12:11 And it came to pass when it was fit in the entering by the king into the house of the LORD, there went in also the bodyguards and they took the shields, and then restored them unto the place of the bodyguards. 

#### 2 Chronicles 12:12 And in his feeling ashamed, {was turned from him the anger of the LORD}, and not unto corruption unto the end, for in Judah there were {matters good}. 

#### 2 Chronicles 12:13 And {grew strong king Rehoboam} in Jerusalem, and reigned. {a son of forty and one years old was Rehoboam} in his taking reign. And seventeen years he reigned in Jerusalem, in the city which the LORD chose to name his name there, from out of all the tribes of the sons of Israel. And the name to his mother was Naammah the Ammonitess. 

#### 2 Chronicles 12:14 And he acted wickedly, for he did not straighten out his heart to seek after the LORD. 

#### 2 Chronicles 12:15 And the words of Rehoboam, the first and last, {not behold are they} written in the words of Shemaiah the prophet, and Iddo the seer to trace descent and his actions. And Rehoboam waged war and Jeroboam all the days. 

#### 2 Chronicles 12:16 And Rehoboam slept with his fathers, and was entombed in the city of David. And {reigned Abijah his son} instead of him. 

#### 2 Chronicles 13:1 In the eighteenth year of the kingdom of Jeroboam, Abijah took reign over Judah. 

#### 2 Chronicles 13:2 Three years he reigned in Jerusalem. And the name of his mother was Michaiah daughter of Uriel of Gibeah. And there was war between Abijah and between Jeroboam. 

#### 2 Chronicles 13:3 And Abijah deployed for the war with a force of warriors of power -- four hundred thousand {men chosen}. And Jeroboam deployed against him for war with eight hundred thousand {men chosen}, mighty warriors of power. 

#### 2 Chronicles 13:4 And Abijah rose up from mount Zemaraim, which is in mount Ephraim, and said, Hear me, Jeroboam and all Israel! 

#### 2 Chronicles 13:5 Is it not to you to know that the LORD God of Israel appointed the kingdom to David over Israel into the eon, and to his sons for a covenant of salt? 

#### 2 Chronicles 13:6 And {rose up Jeroboam son of Nebat}, the servant of Solomon son of David, and revolted from his master. 

#### 2 Chronicles 13:7 And there gathered together with him {men mischievous}, sons of lawbreakers, and they grew in strength against Rehoboam son of Solomon, and Rehoboam was younger and timid in heart, and he did not fortify against their face. 

#### 2 Chronicles 13:8 And now you speak to oppose against the face of the kingdom of the LORD in the hand of the sons of David, and you are {multitude a vast}, and with you calves of gold which {made for you Jeroboam} as gods. 

#### 2 Chronicles 13:9 Or did you not cast out the priests of the LORD, the sons of Aaron, and the Levites; and you made to yourselves priests from the people of the land? Even every one approaching filling his hand with a calf, an offspring of the herd, and {rams seven}, and he becomes as a priest to the one not being God. 

#### 2 Chronicles 13:10 And we {the LORD our God did not abandon}. And his priests officiate to the LORD, the sons of Aaron and the Levites in their daily rotations. 

#### 2 Chronicles 13:11 And they burn to the LORD whole burnt-offerings morning by morning, and evening to evening, and they have the incense composition, and place settings of bread loaves upon the {table pure}, and the {lamp-stand gold}, and its lamps to light evening by evening. For we guard the watch of the LORD, the God of our fathers; but you abandoned him. 

#### 2 Chronicles 13:12 And behold, with us as head is the LORD, and his priests, and the {trumpets signal} to signify against you. Sons of Israel, you should not wage war against the LORD God of your fathers; for your ways shall not be prospered. 

#### 2 Chronicles 13:13 And Jeroboam circled an ambush to come from behind them. And they were in front of Judah, and the ambush was from the places behind. 

#### 2 Chronicles 13:14 And Judah turned, and behold, the battle was against them from the places in front and from the places posterior. And they yelled to the LORD, and the priests trumped the trumpets. 

#### 2 Chronicles 13:15 And {shouted the men of Judah}. And it happened when {shouted the men of Judah}, that the LORD struck Jeroboam and Israel before Abijah and Judah. 

#### 2 Chronicles 13:16 And {fled the sons of Israel} from the face of Judah, and {delivered them the LORD} into their hands. 

#### 2 Chronicles 13:17 And {struck them Abijah and his people calamity with a great}. And there fell slain of Israel -- five hundred thousand {men mighty}. 

#### 2 Chronicles 13:18 And {were abased the sons of Israel} in that day, and {grew strong the sons of Judah}, for they hoped upon the LORD the God of their fathers. 

#### 2 Chronicles 13:19 And Abijah pursued after Jeroboam, and first took from him the cities of Beth-el and her towns, and Jeshanah and her towns, and Ephrain and her towns. 

#### 2 Chronicles 13:20 And {did not have strength Jeroboam} any more during all the days of Abijah. And {struck him the LORD}, and he died. 

#### 2 Chronicles 13:21 And Abijah grew strong, and took for himself {wives fourteen}, and engendered twenty and two sons, and sixteen daughters. 

#### 2 Chronicles 13:22 And the rest of the words of Abijah, and his actions, and his words, are written upon the scroll in the inquiry of Iddo the prophet. 

#### 2 Chronicles 14:1 And Abijah slept with his fathers, and they entombed him in the city of David. And {took reign Asa his son} instead of him. In the days of Asa {was quiet the land of Judah} for ten years. 

#### 2 Chronicles 14:2 And he did the good and the upright thing before the LORD his God. 

#### 2 Chronicles 14:3 And he removed the altars of the aliens, and the high places, and he broke the monuments, and cut down the sacred groves. 

#### 2 Chronicles 14:4 And he spoke to Judah, to seek after the LORD God of their fathers, and to observe the law and the commandments. 

#### 2 Chronicles 14:5 And he removed from all of the cities of Judah the altars and the idols; and {was at peace the kingdom} before him. 

#### 2 Chronicles 14:6 And he built {cities walled} in the land of Judah; for there was peace in the land, and there was no war to him in these years, for {gave rest to him the LORD}. 

#### 2 Chronicles 14:7 And he said to Judah, We should build these cities, and we should make walls, and towers, and gates, and bars, in which land we dominate, for as we sought the LORD our God, he sought us, and rested us round about. And they built and prospered. 

#### 2 Chronicles 14:8 And there was to Asa a force of armor-bearers lifting shields and spears in Judah -- three hundred thousand. And in Benjamin men armed with small shields, and bowmen -- two hundred and eighty thousand, all these were warriors of power. 

#### 2 Chronicles 14:9 And {came forth against them Zarai the Ethiopian} in a force with a thousand thousand, and with {chariots three hundred}; and he came unto Mareshah. 

#### 2 Chronicles 14:10 And Asa came forth to meet against him, and he deployed for war in the ravine to the north of Mareshah. 

#### 2 Chronicles 14:11 And Asa yelled to the LORD his God, and said, O LORD, it is not impossible for you to deliver by many or by few. Help us, O LORD our God, for upon you we yield, and in your name we came against {multitude this vast}. O LORD our God. You are the God. Let not {prevail against you man}! 

#### 2 Chronicles 14:12 And the LORD struck the Ethiopians before Asa, and before Judah, and the Ethiopians fled. 

#### 2 Chronicles 14:13 And {pursued them Asa} and his people unto Gerar. And {fell the Ethiopians} so as to not be in procurement of safety for themselves; for they were defeated before the LORD, and before his force. And they despoiled {spoils many}. 

#### 2 Chronicles 14:14 And they knocked down their towns round about Gerar; for there became a change of state of the LORD upon them. And they plundered all their cities; for many spoils came to them. 

#### 2 Chronicles 14:15 And indeed the tents of the cattle they cut down, and they took {sheep many} and camels, and returned to Jerusalem. 

#### 2 Chronicles 15:1 And Azariah son of Oded -- {came upon him spirit of God}. 

#### 2 Chronicles 15:2 And he went forth for meeting with Asa. And he said to him, Hear me Asa, and all Judah and Benjamin! The LORD is with you in your being with him. And if you seek after him, he shall be found by you. And if you should abandon him, he will abandon you. 

#### 2 Chronicles 15:3 For {days passed many} to Israel without the true God, and no priest to plainly show things, and with no law. 

#### 2 Chronicles 15:4 And he shall turn them in affliction unto the LORD the God of Israel, and they shall seek him, and he shall be found by them. 

#### 2 Chronicles 15:5 And in {times those} there is no peace to the one going forth, and to the one entering, for much astonishment was upon all the ones dwelling places. 

#### 2 Chronicles 15:6 And {shall wage war nation} against nation, and city against city, for God startled them in every affliction. 

#### 2 Chronicles 15:7 And you, be strong and do not loosen your hands! for there is a wage for your work. 

#### 2 Chronicles 15:8 And in Asa hearing of these words, and the prophecy of Oded the prophet, that he prevailed, and cast out the loathsome things of all the land of Judah and Benjamin, and from the cities which he took control of from Jeroboam, from the mountains of Ephraim. And he dedicated the altar of the LORD, which was in front of the temple of the LORD. 

#### 2 Chronicles 15:9 And he assembled Judah and Benjamin, and the foreigners sojourning with him from out of Ephraim, and from out of Manasseh, and from out of Simeon; for {were added to him from Israel many} in their seeing that the LORD God himself was with him. 

#### 2 Chronicles 15:10 And they gathered in Jerusalem in the {month third}, in the {year fifteenth} of the kingdom of Asa. 

#### 2 Chronicles 15:11 And they sacrificed to the LORD in that day from the spoils which they brought {calves of seven hundred} and {sheep seven thousand}. 

#### 2 Chronicles 15:12 And they went into a covenant to seek the LORD God of their fathers with {entire heart their}, and with {entire soul their}. 

#### 2 Chronicles 15:13 And all who ever did not seek after the LORD God of Israel shall die, from younger unto older, from man unto woman. 

#### 2 Chronicles 15:14 And they swore by an oath to the LORD with {voice a great}, and with shouting, and with trumpets, and with horns. 

#### 2 Chronicles 15:15 And {was glad on account of the oath all Judah}; for from {entire soul their} they swore by an oath, and with all their volition they sought him; and he was found by them. And the LORD gave rest to them round about. 

#### 2 Chronicles 15:16 And {Maachah the mother Asa of the king removed} to not be officiating to Ashtoreth; and he cut in pieces the idol, and incinerated it at the rushing stream Kidron. 

#### 2 Chronicles 15:17 Except the high places were not removed, for they existed in Israel. Only the heart of Asa was perfect all his days. 

#### 2 Chronicles 15:18 And he carried in the holy things of his father, and his own holy things into the house of God -- silver and gold and vessels. 

#### 2 Chronicles 15:19 And war was not with him until the thirtieth and fifth year of the kingdom of Asa. 

#### 2 Chronicles 16:1 And in the {year thirtieth and sixth} of the kingdom of Asa, {ascended Baasha king of Israel} against Judah. And he built Ramah to not give an exit nor entrance to Asa king of Judah. 

#### 2 Chronicles 16:2 And Asa took silver and gold from out of the treasuries of the house of the LORD, and from the house of the king, and he sent to the son of Hadad king of Syria, the one dwelling in Damascus, saying, 

#### 2 Chronicles 16:3 Ordain a covenant between me and between you, and between my father and between your father! Behold, I have sent to you gold and silver. Come, and efface your covenant with Baasha king of Israel! and he shall go forth from me. 

#### 2 Chronicles 16:4 And {hearkened to the son of Hadad} king Asa, and sent the rulers of his force against the cities of Israel. And he struck Ijon, and Dan, and Abel-maim, and all the places round about Naphtali. 

#### 2 Chronicles 16:5 And it happened when Baasha heard, that he left off to no longer build Ramah, and he rested his work. 

#### 2 Chronicles 16:6 And king Asa took all Judah; and he lifted away all the stones of Ramah, and its timbers which Baasha built with; and he built with them Geba and Mizpah. 

#### 2 Chronicles 16:7 And in that time {came Hanani the prophet} to Asa king of Judah, and said to him; Because you relied upon the king of Syria, and {did not rely you} upon the LORD your God, on account of this {came through safe the force of the king of Syria} from your hand. 

#### 2 Chronicles 16:8 {not the Ethiopians and Lubim Were force a vast}, and of courage for chariots and horsemen in multitude, exceedingly? And in your relying upon the LORD, he delivered them into your hands. 

#### 2 Chronicles 16:9 For the eyes of the LORD look in all the earth to strengthen with every heart perfect towards him. You have known about this; from now on {will be with you war}. 

#### 2 Chronicles 16:10 And Asa was enraged with the prophet, and he placed him in the house of the prison, for he was angry over this. And Asa laid waste among the people at that time. 

#### 2 Chronicles 16:11 And behold, the words of Asa, the first and the last, are written upon the scroll of the kings of Judah and Israel. 

#### 2 Chronicles 16:12 And Asa was infirm in the {year thirtieth and ninth} of his kingdom in his feet, until {was higher his infirmity}. And in his infirmity he did not seek the LORD, but the physicians. 

#### 2 Chronicles 16:13 And Asa slept with his fathers, and he came to an end in the fortieth and first year of his kingdom. 

#### 2 Chronicles 16:14 And they entombed him in the tomb in which he dug for himself in the city of David. And they rested him upon the bed, and they filled it of aromatics, and types {perfumes of scented}. And they made for him {funeral a great}, and they kindled him {burning a great} -- unto exceedingly. 

#### 2 Chronicles 17:1 And {reigned Jehoshaphat his son} instead of him. And Jehoshaphat strengthened against Israel. 

#### 2 Chronicles 17:2 And he put a force in all the {cities of Judah fortified}, and he put leaders in the land of Judah, and in the cities of Ephraim, which {first took Asa his father}. 

#### 2 Chronicles 17:3 And the LORD was with Jehoshaphat, for he went in {ways of David his father the first}; and he did not seek after the idols, 

#### 2 Chronicles 17:4 but {the LORD God of his father he sought after}, and by his commandments he went, and not according to the works of Israel. 

#### 2 Chronicles 17:5 And the LORD straightened the kingdom in his hand; and {gave all Judah} gifts to Jehoshaphat, and there became to him {riches and glory much}. 

#### 2 Chronicles 17:6 And {was raised up high his heart} in the ways of the LORD. And again he removed the high places and the sacred groves from the land of Judah. 

#### 2 Chronicles 17:7 And in the {year third} of his kingship, he sent his leaders, and the sons of the mighty ones -- Obadiah, and Zechariah, and Nethaneel, and Michaiah to teach in the cities of Judah. 

#### 2 Chronicles 17:8 And with them the Levites -- Shemaiah, and Nethaniah, and Zebadiah, and Asahel, and Shemiramoth, and Jehonathan, and Adonijah, and Tobijah, and Tob-adonijah the Levites; and with them Elishama and Jehoram, the priests. 

#### 2 Chronicles 17:9 And they taught in Judah, and with them was the book of the law of the LORD. And they went through in the cities of Judah and taught the people. 

#### 2 Chronicles 17:10 And there came to pass a change of state of the LORD upon all the kingdoms of the land round about Judah, and they did not wage war against Jehoshaphat. 

#### 2 Chronicles 17:11 And from the Philistines they brought to Jehoshaphat gifts and silver. And also the Arabians brought to him rams of the flocks -- seven thousand seven hundred; he-goats -- seven thousand seven hundred. 

#### 2 Chronicles 17:12 And Jehoshaphat was going in greatness unto height, and he built {in Judah places of abode}, and {cities fortified}. 

#### 2 Chronicles 17:13 And {works many} were taking place by him in Judah. And {men warriors mighty} being strong were in Jerusalem. 

#### 2 Chronicles 17:14 And this is the number of them according to the houses of their families. And to Judah as commanders of thousands -- Adnah the ruler, and with him {sons mighty} of power -- three hundred thousand. 

#### 2 Chronicles 17:15 And after him Johahnan the ruler, and with him two hundred eighty thousand. 

#### 2 Chronicles 17:16 And after him, Amasiah the son of Zichri, the one feeling eager to the LORD; and with him two hundred thousand mighty men of power. 

#### 2 Chronicles 17:17 And from Benjamin the mighty man of power Eliada, and with him bowmen and men armed with small shields -- two hundred thousand. 

#### 2 Chronicles 17:18 And after him was Jehozabad, and with him a hundred eighty thousand mighty men of war. 

#### 2 Chronicles 17:19 These were the ones officiating to the king, outside of the ones whom {put the king} in the {cities fortified} in all Judea. 

#### 2 Chronicles 18:1 And there came to Jehoshaphat still {riches and glory much}. And he was allied by marriage with the house of Ahab. 

#### 2 Chronicles 18:2 And he went down at the end of years to Ahab in Samaria. And {sacrificed to him Ahab} sheep and calves in abundance, and to the people with him; and he persuaded him to go up with him unto Ramoth Gilead. 

#### 2 Chronicles 18:3 And {said Ahab king of Israel} to Jehoshaphat king of Judah, Will you go with me to Ramoth of Gilead? And he said to him, As you, so also I; and as your people, also my people; even with you for war. 

#### 2 Chronicles 18:4 And Jehoshaphat said to the king of Israel, Let us seek indeed today the word of the LORD! 

#### 2 Chronicles 18:5 And {gathered the king of Israel} the prophets -- four hundred men. And he said to them, Shall I go to Ramoth Gilead for war, or should I wait? And they said, Ascend! and God shall give them into the hands of the king. 

#### 2 Chronicles 18:6 And Jehoshaphat said, Is there not here a prophet of the LORD yet, that we shall seek anxiously by him? 

#### 2 Chronicles 18:7 And {said the the king of Israel} to Jehoshaphat, There is {man one} to seek the LORD through him, and I detest him; for he is not prophesying {concerning me for good things}, for all his days are for bad things. He is Michaiah son of Imla. And Jehoshaphat said, Let not {speak the king} thus! 

#### 2 Chronicles 18:8 And {called the king of Israel eunuch one}, and said, Quickly call Michaiah son of Imla! 

#### 2 Chronicles 18:9 And the king of Israel and Jehoshaphat king of Judah were sitting each upon his throne, being clothed with robes; they sat down in the broad space at the door of Samaria, and all the prophets were prophesying before them. 

#### 2 Chronicles 18:10 And {made for himself Zedekiah son of Chenaanah} horns of iron, and he said, Thus says the LORD; With these you shall gore the Syrian until whenever he should be finished off entirely. 

#### 2 Chronicles 18:11 And all the prophets prophesied thus, saying, Ascend unto Ramoth Gilead! and you shall prosper in the way, and the LORD will give it into the hands of the king. 

#### 2 Chronicles 18:12 And the messenger, the one going to call Michaiah, spoke to him, saying, Behold, {spoke the prophets with mouth one good things} concerning the king. And let {be indeed your words} as one of them! and you shall speak good things. 

#### 2 Chronicles 18:13 And Michaiah said, As the LORD lives, that what ever God should say to me, it I shall speak. 

#### 2 Chronicles 18:14 And he came to the king. And {said to him the king}, Michaiah, Shall I go to Ramoth Gilead for war, or should I wait? And he said, Ascend! and your way shall prosper, and they shall be given into your hands. 

#### 2 Chronicles 18:15 And {said to him the king}, How often shall I bind you by an oath that you should not speak to me except the truth in the name of the LORD? 

#### 2 Chronicles 18:16 And Michaiah said, I see Israel all being scattered in the mountains, as sheep in which there is no shepherd. And the LORD said, {have no leader These}. Let them {return each} to his house in peace. 

#### 2 Chronicles 18:17 And {said the king of Israel} to Jehoshaphat, Did I not say to you that he would not prophesy for my good things, but only bad things? 

#### 2 Chronicles 18:18 And Michaiah said, It is not so. Hear the word of the LORD! I beheld the LORD sitting upon his throne, and all the force of the heaven stood beside at his right and at his left. 

#### 2 Chronicles 18:19 And the LORD said, Who shall deceive Ahab king of Israel, that he shall ascend, and shall fall in Ramoth Gilead? And this one spoke thus, and this other one spoke thus. 

#### 2 Chronicles 18:20 And came forth the spirit, and stood in the presence of the LORD, and said, I shall deceive him. And the LORD said, By what means? 

#### 2 Chronicles 18:21 And he said, I shall go forth, and I will be {spirit a lying} in the mouth of all his prophets. And he said, You shall deceive, and shall prevail. Go forth, and do so! 

#### 2 Chronicles 18:22 And now, behold, the LORD put {spirit a lying} in the mouths of all {your prophets these}, and the LORD spoke against you for bad things. 

#### 2 Chronicles 18:23 And {approached Zedekiah son of Chenaanah} and struck Michaiah upon the jaw, and said to him, By what way passed the spirit of the LORD from me to speak to you? 

#### 2 Chronicles 18:24 And Michaiah said, Behold, you shall see in that day in which you shall enter closet by closet to hide. 

#### 2 Chronicles 18:25 And {said the king of Israel}, Take Michaiah and return him to Amon the ruler of the city, and to Joash the son of the king. 

#### 2 Chronicles 18:26 And you shall say, Thus says the king, Put this one into {house a prison}, and let him eat bread of affliction and water of affliction! until my return in peace. 

#### 2 Chronicles 18:27 And Michaiah said, If by returning, you should return in peace, {did not speak the LORD} by me. And he said, Hearken all peoples! 

#### 2 Chronicles 18:28 And {ascended the king of Israel and Jehoshaphat king of Judah} to Ramoth Gilead. 

#### 2 Chronicles 18:29 And {said the king of Israel} to Jehoshaphat, I shall cover up and enter into the battle; but you put on my clothes! And {covered up the king of Israel}, and entered into the battle. 

#### 2 Chronicles 18:30 And the king of Syria gave charge to the heads of the chariots, to the ones with him, saying, Do not wage war with the small and the great, but the king of Israel only. 

#### 2 Chronicles 18:31 And it came to pass as {saw the ones in charge of the chariots} Jehoshaphat, that they said, {the king of Israel It is}. And they encircled him to do battle. And Jehoshaphat yelled, and the LORD delivered him, and {turned them God} from him. 

#### 2 Chronicles 18:32 And it came to pass as {saw the ones in charge of the chariots} that it was not the king of Israel, that they turned from him. 

#### 2 Chronicles 18:33 And a man stretched tight a bow skillfully and struck the king of Israel between the lungs, and between the chest plate. And he said to the charioteer, Turn your hand, and lead me from the battle! for I am wounded. 

#### 2 Chronicles 18:34 And {turned the battle} in that day. And the king of Israel was set upon the chariot right opposite Syria until evening, and he died in the going down of the sun. 

#### 2 Chronicles 19:1 And {returned Jehoshaphat king of Judah} to his house in peace into Jerusalem. 

#### 2 Chronicles 19:2 And came forth to meet him Jehu the son of Hanani the prophet. And he said to king Jehoshaphat, Shall {a sinner you help}, or {one being detested by the LORD do you befriend}, no. Because of this {took place against you the anger of the LORD}. 

#### 2 Chronicles 19:3 But {words good} were found in you, for you removed the sacred groves from the land of Judah, and straightened out your heart to seek after the LORD. 

#### 2 Chronicles 19:4 And Jehoshaphat dwelt in Jerusalem. And again he went forth to the people from Beer-sheba unto mount Ephraim, and turned them unto the LORD the God of their fathers. 

#### 2 Chronicles 19:5 And he placed judges in all the cities of Judah, the fortified ones, in city by city. 

#### 2 Chronicles 19:6 And he said to the judges, Know what you do, for not unto man do you judge, but to the LORD, and with you are the words of judgment. 

#### 2 Chronicles 19:7 And now, let {be the fear of the LORD} upon you, and guard and act! for {is not with the LORD our God injustice}, nor admiring a face, nor taking bribes. 

#### 2 Chronicles 19:8 And indeed in Jerusalem Jehoshaphat placed of the Levites, and of the priests, and of the patriarchs of Israel, for the judgment of the LORD, and to judge the ones dwelling in Jerusalem. 

#### 2 Chronicles 19:9 And he gave charge to them, saying, Thus you shall do in the fear of the LORD, in truth, and with a full heart. 

#### 2 Chronicles 19:10 Every man with a judgment coming unto you of your brethren dwelling in their cities, whether between blood for blood, and between the order and commandment, and for ordinances and judgments, that you shall warn them, that they shall not sin against the LORD, that there will not be anger against you, and against your brethren -- thus you shall do, and you shall not sin. 

#### 2 Chronicles 19:11 And behold, Amariah the {priest leading} over you is for every matter of the LORD; and Zebadiah son of Ishmael is the leader in the house of Judah for every word of the king. And the scribes, the Levites, are before you. Be strong and act! and the LORD will be with the good. 

#### 2 Chronicles 20:1 And after these things came the sons of Moab, and the sons of Ammon, and with them ones of the Ammonites against Jehoshaphat for war. 

#### 2 Chronicles 20:2 And they came and reported to Jehoshaphat, saying, {comes against you multitude a vast} from the other side of the sea, from Syria; and behold, they are in Hazazon-tamar -- this is En-gedi. 

#### 2 Chronicles 20:3 And Jehoshaphat feared and put his face to seek after the LORD. And he proclaimed a fast in all Judah. 

#### 2 Chronicles 20:4 And Judah gathered to seek after the LORD; and they came from all the cities of Judah to seek the LORD. 

#### 2 Chronicles 20:5 And Jehoshaphat rose up in the assembly of Judah in Jerusalem, in the house of the LORD, in front of the {courtyard new}, 

#### 2 Chronicles 20:6 and he said, O LORD God of our fathers, {you not are} God in heaven? And do you not dominate all the kingdoms of the nations? And is not in your hand strength and dominion, and there is no one {against you to oppose}? 

#### 2 Chronicles 20:7 {you not Are} our God, the one utterly destroying the ones dwelling this land from in front of your people Israel, and gave it to the seed of Abraham, to your friend into the eon? 

#### 2 Chronicles 20:8 And they dwell in it, and built to you in it a sanctuary to your name, saying, 

#### 2 Chronicles 20:9 If {should come against us evils} -- the broadsword, judgment, plague, famine, we will stand before this house, and before you, (for your name is called upon in this house,) and we will yell to you from our affliction, and you shall hear and shall deliver. 

#### 2 Chronicles 20:10 And now, behold, the sons of Ammon, and Moab, and mount Seir, in which you did not grant Israel to go through them, in their coming forth from out of the land of Egypt, for they turned aside from them, and they did not utterly destroy them -- 

#### 2 Chronicles 20:11 and behold, they make an attempt against us, to come and to cast us from our inheritance, of which you have given to us. 

#### 2 Chronicles 20:12 O LORD our God, will you not judge them? For there is not to us strength to oppose against {multitude this vast} coming against us. And we do not know what we should do, but {are unto you our eyes}. 

#### 2 Chronicles 20:13 And all Judah stood before the LORD, and their children, and their wives, and their sons. 

#### 2 Chronicles 20:14 And Jahaziel the son of Zechariah, son of Benaiah, son of Jeiel, son of Mattaniah the Levite of the sons of Asaph -- came upon him spirit of the LORD in the assembly. 

#### 2 Chronicles 20:15 And he said, Hearken all Judah, and the ones dwelling in Jerusalem, and king Jehoshaphat! Thus says the LORD to you, Do not fear nor be terrified from the face {multitude vast of this}! for {not to you is the battle array}, but to God. 

#### 2 Chronicles 20:16 Tomorrow go down against them! Behold, they ascend according to the ascent of Ziz; and you shall find them at the tip of the river of the wilderness of Jeruel. 

#### 2 Chronicles 20:17 {not for you It is} to wage war in this. Stand, and perceive, and see the deliverance of the LORD with you, O Judah, and Jerusalem! Do not fear nor be terrified tomorrow coming forth for meeting them! for the LORD is with you. 

#### 2 Chronicles 20:18 And Jehoshaphat bowed upon his face upon the earth; and all Judah and the ones dwelling Jerusalem fell before the LORD, to do obeisance to the LORD. 

#### 2 Chronicles 20:19 And {rose up the Levites} from the sons of Kohath, and from the sons of the of Korahites, to give praise to the LORD, to the God of Israel with {voice a great} unto the height. 

#### 2 Chronicles 20:20 And they rose early in the morning, and they went forth into the wilderness of Tekoa. But in their going forth, Jehoshaphat stood and yelled, and said, Hear me, O Judah, and O ones dwelling in Jerusalem! Entrust in the LORD your God! and you will be entrusted. Entrust in his prophet! and your way will be prosperous. 

#### 2 Chronicles 20:21 And being advised with the people, and he stationed psalm singers and ones praising the LORD, to acknowledge and to praise in the holy, in the going forth before the force. And they said, Give acknowledgment to the LORD, for into the eon is his mercy! 

#### 2 Chronicles 20:22 And when they began the praise and the acknowledgment, the LORD appointed an ambush {to wage war for the sons of Ammon} against Moab and mount Seir of the ones coming forth against Judah; and they put them to flight. 

#### 2 Chronicles 20:23 And there rose up the sons of Ammon and Moab against the ones dwelling in mount Seir, to utterly destroy and to obliterate them. And as they finished off the ones dwelling in Seir, they rose up against one another, and {took a man} his neighbor for hurt. 

#### 2 Chronicles 20:24 And Judah came upon the height in the wilderness, and looked. And they beheld the multitude, and behold, all were dead having fallen upon the ground; there was not one surviving. 

#### 2 Chronicles 20:25 And Jehoshaphat came forth, and his people, to despoil their spoils. And they found {cattle much}, and belongings, and spoils, and {items desirable}. And they despoiled for themselves. And they were {days three} plundering the spoils, for there was much. 

#### 2 Chronicles 20:26 And on the {day fourth} they assembled in the Valley of the Blessing; for there they blessed the LORD. On account of this they call the name of that place, Valley of Blessing, until this day. 

#### 2 Chronicles 20:27 And {returned every man of Judah} to Jerusalem, and Jehoshaphat the one leading them returned to Jerusalem in {gladness great}, for {gladdened them the LORD} from their enemies. 

#### 2 Chronicles 20:28 And they entered into Jerusalem with stringed instruments, and lutes, and with trumpets into the house of the LORD. 

#### 2 Chronicles 20:29 And came to pass a change of state of the LORD upon all the kingdoms of the earth, in their hearing that the LORD waged war with the ones being opponents of Israel. 

#### 2 Chronicles 20:30 And {had peace the kingdom of Jehoshaphat}, and {rested him his God} round about. 

#### 2 Chronicles 20:31 And Jehoshaphat reigned over Judah, being thirty-five years old in his taking reign, and twenty and five years he reigned in Jerusalem. And the name of his mother was Azubah daughter of Shilhi. 

#### 2 Chronicles 20:32 And he went in the ways of Asa his father. And he did not turn aside from them, to do upright before the LORD. 

#### 2 Chronicles 20:33 Only the high places he did not remove, and still the people did not straighten out their heart to the LORD God of their fathers. 

#### 2 Chronicles 20:34 And the rest of the words of Jehoshaphat, the first and the last, behold, they are written in the words of Jehu the son of Hanani, which he wrote down upon a scroll of the kings of Israel. 

#### 2 Chronicles 20:35 And after these things, {participated Jehoshaphat king of Judah} with Ahaziah king of Israel. And he acted lawlessly to do. 

#### 2 Chronicles 20:36 And he participated with him to make boats even to go to Tarshish. And he made boats in Ezion Gaber. 

#### 2 Chronicles 20:37 And {prophesied Eliezer the son of Dodavah from Mareshah} against Jehoshaphat, saying, As you participated with Ahaziah, the LORD cut through your works, and {were broken your boats}, and they were not able to go into Tarshish. 

#### 2 Chronicles 21:1 And Jehoshaphat slept with his fathers, and he was entombed with his fathers in the city of David. And {reigned Jehoram his son} instead of him. 

#### 2 Chronicles 21:2 And to him were brothers, sons of Jehoshaphat -- Azariah, and Jehiel, and Zechariah, and Michael, and Shephatiah; all these were sons of Jehoshaphat king of Judah. 

#### 2 Chronicles 21:3 And {gave to them their father gifts many} -- silver, and gold, and shields, with cities being walled in Judah. But the kingdom he gave to Jehoram, for he was the first-born. 

#### 2 Chronicles 21:4 And Jehoram rose over the kingdom of his father, and was strengthened, and he killed all his brothers by the broadsword, and indeed some of the rulers of Israel. 

#### 2 Chronicles 21:5 His being thirty and two years old was Jehoram in his reigning, and eight years he reigned in Jerusalem. 

#### 2 Chronicles 21:6 And he went in the way of the kings of Israel, as did the house of Ahab, for a daughter of Ahab was to him for a wife. And he did the wicked thing before the LORD. 

#### 2 Chronicles 21:7 And {did not want the LORD} to utterly destroy the house of David on account of the covenant which he ordained with David, and as he said to him, to give him a lamp and to his sons all the days. 

#### 2 Chronicles 21:8 In those days Edom revolted from under the hand of Judah, and they gave {reign over themselves a king}. 

#### 2 Chronicles 21:9 And Jehoram set out with his rulers, and all his chariots, and all the cavalry, the one with him. And it came to pass that he arose by night and struck Edom, the one encircling him, and the rulers of the chariots. 

#### 2 Chronicles 21:10 And Edom revolted from the hand of Judah until this day. Then Libnah revolted in that time from under his hand, for he abandoned the LORD God of his fathers. 

#### 2 Chronicles 21:11 Moreover he made the high places in the cities of Judah, and fornicated the ones dwelling in Jerusalem, and led Judah astray. 

#### 2 Chronicles 21:12 And there came to him in writing words by Elijah the prophet, saying, Thus says the LORD, the God of David your father, Because you did not go in the way of Jehoshaphat your father, and in the ways of Asa king of Judah, 

#### 2 Chronicles 21:13 and went in the ways of the king of Israel, and fornicated Judah, and the ones dwelling in Jerusalem, as {fornicated the house of Ahab}, and also your brothers, sons of your father, the good ones over you, you killed. 

#### 2 Chronicles 21:14 Behold, the LORD shall strike you {calamity with a great} among your people, and among your sons, and among your wives, and among all your belongings; 

#### 2 Chronicles 21:15 and you shall be in {sicknesses severe} in disease of your bellies, until of which time {should come forth your innards} from the sickness of days by days. 

#### 2 Chronicles 21:16 And the LORD roused {against Jehoram the Philistines}, and the Arabians, and the ones adjoining the Ethiopians. 

#### 2 Chronicles 21:17 And they ascended against Judah, and overpowered it, and captured all the possessions which they found in the house of the king, and the houses of his sons, and his daughters. And there was not left to him a son except Jehoahaz the youngest of his sons. 

#### 2 Chronicles 21:18 And after all these things {struck him the LORD} in his belly with a sickness in which there is no healing. 

#### 2 Chronicles 21:19 And it happened from days unto days, and as {came his time} in {days two}, there came forth his innards with his belly in his sickness. And he died in {sicknesses severe}, and {did not make to him his people a funeral}, nor a burning according to the burning of his fathers. 

#### 2 Chronicles 21:20 He was thirty and two years old in his reigning, and eight years he reigned in Jerusalem. And he went in not high praise. And they entombed him in the city of David, and not in the tombs of the kings. 

#### 2 Chronicles 22:1 And {gave reign the ones dwelling in Jerusalem} to Ahaziah his son, the youngest, instead of him; for all the elder sons were killed by the ones coming upon them -- the band of robbers, the Arabians. And {reigned Ahaziah son of Jehoram king of Judah}. 

#### 2 Chronicles 22:2 {was a son being forty and two years old Ahaziah} in his reigning, and {year one he reigned} in Jerusalem. And the name of his mother was Athaliah daughter of Omri. 

#### 2 Chronicles 22:3 And also he went in the ways of the house of Ahab, for his mother was his counselor to sin. 

#### 2 Chronicles 22:4 And he did the wicked thing in the eyes of the LORD, as the house of Ahab; for they were to him counselors after the dying of his father to utterly destroy him. 

#### 2 Chronicles 22:5 And {by their counsels he went}. And he went with Jehoram son of Ahab king of Israel for war against Hazael king of Syria in Ramoth Gilead. And {struck the bowmen} Jehoram. 

#### 2 Chronicles 22:6 And Jehoram returned to be treated medically in Jezreel from the wounds which {struck him the Syrians} in Ramoth, in his warring against Hazael king of Syria. And Ahaziah son of Jehoram, king of Judah went down to see Jehoram son of Ahab in Jezreel, for he was infirm. 

#### 2 Chronicles 22:7 And by God came the final event of Ahaziah in his coming to Jehoram. And in his coming, Jehoram went forth with him against Jehu son of Nimshi, the anointed of the LORD, whom {anointed him the LORD} to utterly destroy the house of Ahab. 

#### 2 Chronicles 22:8 And it came to pass in {taking vengeance Jehu} on the house of Ahab, that he found the rulers of Judah, and the brothers of Ahaziah, the ones officiating to Ahaziah, and he killed them. 

#### 2 Chronicles 22:9 And Jehu told them to seek Ahaziah. And they overtook him in his being treated medically in Samaria, and they led him to Jehu, and he killed him. And they entombed him, for they said, He is a son of Jehoshaphat who sought the LORD with {entire heart his}. And there was not anyone in the house of Ahaziah prevailing with power over the kingdom. 

#### 2 Chronicles 22:10 And Athaliah the mother of Ahaziah saw that {died her son}, and she rose up and destroyed all the seed of the kingdom in the house of Judah. 

#### 2 Chronicles 22:11 But {took Jehoshabeath the daughter of the king} Joash son of Ahaziah, and stole him from the midst of the sons of the king, of the ones being put to death. And she put him and his nourishment in the storeroom of the beds. And {hid him the daughter of king Jehoram}, Jehoshabeath the sister of Ahaziah the wife of Jehoiada the priest. And she hid him from the face of Athaliah, and she did not kill him. 

#### 2 Chronicles 22:12 And he was being hid with her in the house of God six years. And Athaliah reigned over the land. 

#### 2 Chronicles 23:1 And in the {year seventh} Jehoiada determined, and {took the commanders of hundreds} Azariah son of Jehoram, and Ishmael son of Jehohanan, and Azariah son of Obed, and Maaseiah son of Adaiah, and Elishaphat son of Zichri, with him in covenant. 

#### 2 Chronicles 23:2 And they encircled Judah, and gathered the Levites from out of all the cities of Judah, and the rulers of the families of Israel, and they came to Jerusalem. 

#### 2 Chronicles 23:3 And {ordained all the assembly} a covenant in the house of God with the king. And he said to them, Behold, the son of the king, let him reign! as the LORD spoke concerning the house of David. 

#### 2 Chronicles 23:4 And now this is the word what you shall do. The third of you {enter on the Sabbath of the priests and of the Levites}, and go unto the gates of the entrances; 

#### 2 Chronicles 23:5 and the third unto the house of the king; and the third unto the gate the one in the middle! And all the people will be in the courtyards of the house of the LORD. 

#### 2 Chronicles 23:6 And let no one enter into the house of the LORD, except the priests and the Levites, and the ones officiating to the Levites! They shall enter, for they are holy. And all the people let guard the watches of the LORD! 

#### 2 Chronicles 23:7 And {shall encircle the Levites} the king round about, each man and his weapon in his hand, and the one entering into the house shall die. And they will be with the king for his entering and exiting. 

#### 2 Chronicles 23:8 And {did the Levites and all Judah} according to all as much as {gave charge Jehoiada the priest}. And {took each man} his men entering on the Sabbath, unto exiting of the Sabbath, for {did not rest up Jehoiada the priest} the daily rotations. 

#### 2 Chronicles 23:9 And {gave Jehoiada the priest} the commanders of hundreds orders, and the swords, and the large shields, and the small shields which was of king David in the house of God. 

#### 2 Chronicles 23:10 And he stationed all the people, each with his weapons, from the protrusion of the house at the right, unto the protrusion of the house at the left by the altar, and at the house by the king round about. 

#### 2 Chronicles 23:11 And he led out the son of the king, and put upon him the crown, and the testimony, and they made him to reign. And {anointed him Jehoiada the priest and his sons}, and they said, Let {live the king}! 

#### 2 Chronicles 23:12 And Athaliah heard the sound of the people, of the ones running, and acknowledging, and praising the king. And she entered to the king, into the house of the LORD. 

#### 2 Chronicles 23:13 And she beheld, and behold, the king stood at his station, and at the entrance were the rulers and the trumpets. And the rulers were around the king. And all the people of the land were being glad and trumpeting with the trumpets, and the ones singing with the instruments of the odes, the singers and ones singing praise. And Athaliah tore her robe, and yelled and said, Conspiracy, conspiracy. 

#### 2 Chronicles 23:14 And came forth Jehoiada the priest, and he gave charge to the commanders of hundreds, and to the chiefs of the force. And said to them, Lead her outside of the house, and go forth after her, and let her die by the sword! For {said the priest}, Let her not die in the house of the LORD! 

#### 2 Chronicles 23:15 And they placed {upon her hands}, and she went through the gate of the horsemen of the house of the king, and they put her to death there. 

#### 2 Chronicles 23:16 And Jehoiada ordained a covenant between he and between the people, and between the king, to be for a people to the LORD. 

#### 2 Chronicles 23:17 And {entered all the people of the land} into the house of Baal, and tore it down, and his altars; and his images they ground fine; and {Mattan the priest of Baal they put to death} before his altars. 

#### 2 Chronicles 23:18 And {committed Jehoiada the priest} the works of the house of the LORD in the hand of the priests and Levites. And he reestablished the daily rotations of the priests and the Levites, as David separated for the house of the LORD, to offer to the LORD whole burnt-offerings, as is written in the law of Moses, with gladness and with odes by the hand of David. 

#### 2 Chronicles 23:19 And {stood the gatekeepers} at the gates of the house of the LORD, that there shall not enter {unclean in anything}. 

#### 2 Chronicles 23:20 And he took the patriarchs, and the mighty ones, and the rulers of the people, and all the people of the land, and they conducted the king into the the house of the LORD; and he entered through the inner gate into the house of the king. And they sat the king upon the throne of the kingdom. 

#### 2 Chronicles 23:21 And {were glad all the people of the land}, and the city was still. And Athaliah they put to death by the sword. 

#### 2 Chronicles 24:1 {was years old seven Joash} in his taking reign, and forty years he reigned in Jerusalem. And the name of his mother was Zibeah from Beer-sheba. 

#### 2 Chronicles 24:2 And Joash did the upright thing before the LORD all the days of Jehoiada the priest. 

#### 2 Chronicles 24:3 And Jehoiada took two wives to himself, and he engendered sons and daughters. 

#### 2 Chronicles 24:4 And it came to pass after these things, that it came upon the heart of Joash to repair the house of the LORD. 

#### 2 Chronicles 24:5 And he gathered the priests and the Levites, and he said to them, Go forth into the cities of Judah, and gather from all Israel money to repair the house of the LORD your God until fit, year by year! And hasten to speak! And {hastened not the Levites}. 

#### 2 Chronicles 24:6 And {called the king} Jehoiada the ruler, and he said to him, Why did you not require concerning the Levites, so as to carry in from Judah and Jerusalem the adjudged concern by Moses the man of God, for the assembly of Israel in the tent of the testimony? 

#### 2 Chronicles 24:7 For Athaliah was lawless, and her sons tore down the house of God; and also all the holy things of the house of the LORD they appointed to the Baals. 

#### 2 Chronicles 24:8 And {said the king}, Let there be a container, and let it be put at the gate of the house of the LORD outside! 

#### 2 Chronicles 24:9 And let them proclaim in Judah and in Jerusalem, to carry in to the LORD as {said Moses the servant of God} unto Israel in the wilderness. 

#### 2 Chronicles 24:10 And {were glad all the rulers} and all the people; and they carried in, and cast into the container, until of which it was filled. 

#### 2 Chronicles 24:11 And it came to pass in the time to bring in the container to the superintendents of the king by the hand of the Levites, that when they beheld that {was superabundant the money}, that {came the scribe of the king}, and the superintendent of the great priest; and they emptied out the container, and they lifted and placed it upon its place. Thus they did day by day, and they gathered {money much}. 

#### 2 Chronicles 24:12 And {gave it the king and Jehoiada the priest} to the ones doing the works for the work of the house of the LORD. And they hired quarriers and fabricators to repair the house of the LORD, and braziers of iron and of brass to strengthen the house of the LORD. 

#### 2 Chronicles 24:13 And {did so the ones doing the works}, and there ascended the length of the works by their hands. And they reestablished the house of the LORD in its position, and they strengthened it. 

#### 2 Chronicles 24:14 And as they completed, they brought to the king and to Jehoiada the rest of the money, and they made with it items for the house of the LORD, items for the ministry, and of the whole burnt-offerings, and incense pans, and {vessels gold and silver}. And they offered whole burnt-offerings in the house of the LORD continually all the days of Jehoiada. 

#### 2 Chronicles 24:15 And Jehoiada grew old, and was full of days. And he came to an end {a son being} a hundred and thirty years at his coming to an end. 

#### 2 Chronicles 24:16 And they entombed him in the city of David with the kings, for he did goodness with Israel, and with God, and his house. 

#### 2 Chronicles 24:17 And it came to pass after the decease of Jehoiada, {entered the rulers of Judah} and did obeisance to the king. Then {heeded the king} them. 

#### 2 Chronicles 24:18 And they abandoned the house of the LORD the God of their fathers, and they served to Ashtoreth and the idols. And there came anger against Judah and against Jerusalem in their trespass. 

#### 2 Chronicles 24:19 And he sent to them prophets to turn them to the LORD. And they testified to them, and they hearkened not. 

#### 2 Chronicles 24:20 And spirit of God was put on Zechariah the son of Jehoiada the priest, and he rose above the people, and said to them, Thus says the LORD, Why do you pass by the commandments of the LORD, and your way shall not prosper? For you abandoned the LORD, and he shall abandon you. 

#### 2 Chronicles 24:21 And they assailed against him, and stoned him with stones by command of Joash the king in the courtyard of the house of the LORD. 

#### 2 Chronicles 24:22 And {did not remember Joash the king} the mercy of which {performed Jehoiada his father} with him, and he put {to death his son}. And as he died, he said, The LORD behold even to judge! 

#### 2 Chronicles 24:23 And it came to pass at the completion of the year, {ascended against him the force of Syria}, and came against Judah, and against Jerusalem, and they utterly destroyed all the rulers of the people from among the people; and all their spoils they sent to the king of Damascus. 

#### 2 Chronicles 24:24 For {with a few men came the force of Syria}, but God delivered up into their hands {force vast an exceedingly}, for they abandoned the LORD the God of their fathers. And with Joash they executed judgments. 

#### 2 Chronicles 24:25 And after their going forth from him, in abandoning him with {infirmities great}, that {assailed against him his servants} because of the blood of the sons of Jehoiada the priest; and they killed him upon his bed, and he died. And they entombed him in the city of David, but they did not entomb him in the tomb of the kings. 

#### 2 Chronicles 24:26 And the ones assailing against him -- Zabad son of Shimeath the Ammonitess, and Jehozabad son of Shimrith the Moabitess. 

#### 2 Chronicles 24:27 And his sons, and the greatest concerns about him, and the groundwork of the house of God, and the rest, behold, it is written upon the writing of the scroll of the kings. And {reigned Amaziah his son} instead of him. 

#### 2 Chronicles 25:1 A son being twenty and five years old was Amaziah in his taking reign. And twenty and nine years he reigned in Jerusalem. And the name of his mother was Jehoaddan of Jerusalem. 

#### 2 Chronicles 25:2 And he did the upright thing before the LORD, but not with {heart a full}. 

#### 2 Chronicles 25:3 And it came to pass as {was placed the kingdom} in his hand, that he killed his servants -- the ones murdering {the king his father}. 

#### 2 Chronicles 25:4 And their sons were not killed according to the covenant of the law of the LORD, as is written in the law of Moses, as the LORD gave charge, saying, {shall not die fathers} for the children, and the sons shall not die for the fathers, but only each for his own sin shall die. 

#### 2 Chronicles 25:5 And Amaziah gathered the house of Judah, and he established them according to the houses of their families for commanders of thousands, and commanders of hundreds, in all Judah and Benjamin. And he numbered them from twenty years old and up. And he found of them three hundred thousand mighty ones going forth for war, mighty ones holding spear and shield. 

#### 2 Chronicles 25:6 And he hired from Israel a hundred thousand mighty ones in strength for a hundred talents of silver. 

#### 2 Chronicles 25:7 And the man of God came to him, saying, O king, let not {go with you the force of Israel}! for {is not the LORD} with Israel -- of any of the sons of Ephraim. 

#### 2 Chronicles 25:8 For if you should undertake to grow strong by these in the battle, the LORD will put you to flight before the enemies, for there is strength to the LORD to help, and to put to flight. 

#### 2 Chronicles 25:9 And Amaziah said to the man of God, And what shall I do with the hundred talents which I gave to the force of Israel? And {said the man of God}, It is with the LORD to give to you more of these. 

#### 2 Chronicles 25:10 And Amaziah parted the force coming to him from Ephraim, to go forth to their place. And they were enraged in their anger exceedingly over Judah, and returned to their places in an anger of rage. 

#### 2 Chronicles 25:11 And Amaziah grew strong, and took to himself his people, and went into the valley of salts, and struck there the sons of Seir -- ten thousand. 

#### 2 Chronicles 25:12 And {ten thousand took alive the sons of Judah}, and they brought them upon the tip of the precipice, and flung them from the tip of the precipice, and all were torn to pieces. 

#### 2 Chronicles 25:13 And the sons of the force, whom Amaziah returned so as to not go with him to war, assailed against the cities of Judah from Samaria and unto Beth-horon. And they struck among them three thousand, and despoiled {spoils many}. 

#### 2 Chronicles 25:14 And it came to pass after the coming of Amaziah, having struck the Edomite, that he brought to them the gods of the sons of Seir, and he set them up to himself as gods; and {before them he did obeisance}, and sacrificed to them. 

#### 2 Chronicles 25:15 And {came the anger of the LORD} against Amaziah, and he sent to him a prophet, and he said to him, Why did you seek the gods of the people, the ones which did not rescue their own people from your hand? 

#### 2 Chronicles 25:16 And it came to pass in the speaking to him by him, that he said to him, Have {counselor of the king I appointed you}? Take heed to it! that they should not strike you. And {kept silent the prophet}, and said, I know that {consulted the LORD} to utterly destroy you, for he did this, and you did not heed my advice. 

#### 2 Chronicles 25:17 And {consulted Amaziah king of Judah}, and sent to Joash son of Jehoahaz, son of Jehu, king of Israel, saying, Come, for we should see each other's faces. 

#### 2 Chronicles 25:18 And {sent Joash king of Israel} to Amaziah king of Judah, saying, The thorn-bush in Lebanon sent to the cedar in Lebanon, saying, Give your daughter to my son for a wife; but, behold, {shall come the wild beasts of the field in Lebanon}, and {came the wild beasts}, and they trampled the thorn-bush. 

#### 2 Chronicles 25:19 You said, Behold, I struck Edom; and {lifts you up heart your heavy}. Now be seated in your house, for why do you unite in evil, and you shall fall, and Judah with you? 

#### 2 Chronicles 25:20 But {hearkened not Amaziah}, for by the LORD it was to deliver him into the hands of Joash, for he inquired of the gods of the Edomites. 

#### 2 Chronicles 25:21 And {ascended Joash the king of Israel}. And they saw one another, he and Amaziah king of Judah, in Beth-shemesh, which is of Judah. 

#### 2 Chronicles 25:22 And Judah was put to flight before the face of Israel; and {fled each} unto his tent. 

#### 2 Chronicles 25:23 And Amaziah king of Judah was overtaken by Joash king of Israel in Beth-shemesh, and he brought him to Jerusalem, and he tore down from of the wall of Jerusalem, from the gate of Ephraim unto the gate of the corner -- four hundred cubits. 

#### 2 Chronicles 25:24 And all the gold, and the silver, and all the items being found in the house of the LORD, and the things with Obed Edom, and the treasures of the house of the king, and of the things of the sons of the alliances he took, and he returned to Samaria. 

#### 2 Chronicles 25:25 And {lived Amaziah the son of Joash king of Judah} after the dying of Joash the son of Jehoahaz king of Israel {years for fifteen}. 

#### 2 Chronicles 25:26 And the rest of the words of Amaziah, the first and the last, behold are they not written upon the scroll of the kings of Judah and Israel? 

#### 2 Chronicles 25:27 And at the time when Amaziah departed from the LORD, they made an attempt against him in a conspiracy in Jerusalem, and he fled unto Lachish; but they sent after him unto Lachish, and they killed him there. 

#### 2 Chronicles 25:28 And they took him upon the horses, and entombed him with his fathers in the city of David. 

#### 2 Chronicles 26:1 And {took all the people of the land} Uzziah, and he was a son sixteen years old, and they gave him reign in place of his father Amaziah. 

#### 2 Chronicles 26:2 He built Eloth; he returned it to Judah after {slept the king} with his fathers. 

#### 2 Chronicles 26:3 {was a son being sixteen years old Uzziah} in his taking reign. And fifty and two years he reigned in Jerusalem. And the name of his mother was Jecoliah, from Jerusalem. 

#### 2 Chronicles 26:4 And he did upright before the LORD, according to all as much as {did Amaziah his father}. 

#### 2 Chronicles 26:5 And he was seeking after the LORD in the days of Zechariah, the one perceiving in a vision of God. And in the days in which he sought after the LORD, {prospered him the LORD God}. 

#### 2 Chronicles 26:6 And he went forth and waged war against the Philistines, and tore down the walls of Gath, and the walls of Jabneh, and the walls of Ashdod. And he built cities in Ashdod, and among the Philistines. 

#### 2 Chronicles 26:7 And {strengthened him the LORD} against the Philistines, and against the Arabians, the ones dwelling upon the rock, and against the Mehunim. 

#### 2 Chronicles 26:8 And {gave the Mehunim} gifts to Uzziah. And {was his name} famous unto the entrance of Egypt, for he strengthened himself even higher. 

#### 2 Chronicles 26:9 And Uzziah built towers in Jerusalem, both at the gate of the corner, and at the gate of the ravine, and at the corners; and he strengthened them. 

#### 2 Chronicles 26:10 And he built towers in the wilderness, and quarried {wells many}; for {cattle much} existed to him in Sephela and in the plain -- farmers and vine dressers in the mountains and in Carmel; for he was fond of husbandry. 

#### 2 Chronicles 26:11 And there existed to Uzziah a force to make war, and for going forth into battle array. And the count of the numbering of them was through the hand of Jeiel the scribe, and Maaseiah the judge, and through the hand of Hananiah, the substitute for the king. 

#### 2 Chronicles 26:12 All the number of the rulers of the families of the mighty ones for war -- two thousand six hundred. 

#### 2 Chronicles 26:13 And with them a force for warfare -- three hundred thousand and seven thousand and five hundred. These are the ones preparing for war in a force of strength, to help the king over the opponents. 

#### 2 Chronicles 26:14 And {made preparations for them Uzziah}, giving to all the force shields, and spears, and helmets, and chest plates, and bows, and slings for stones. 

#### 2 Chronicles 26:15 And he made in Jerusalem machines being constructed for devices to be upon the towers, and upon the corners, to throw arrows and {stones great}. And {was heard about apparatus their} unto a distance, for he was wonderfully helped until of which time he grew strong. 

#### 2 Chronicles 26:16 And as he grew strong {was raised up his heart} to corrupt. And he transgressed against the LORD his God, and he entered into the temple of the LORD to burn incense upon the altar of the of incenses. 

#### 2 Chronicles 26:17 And {entered after him Azariah the priest}, and with him eighty priests of the LORD -- sons of power. 

#### 2 Chronicles 26:18 And they stood by against Uzziah the king, and they said to him, It is not for you, Uzziah, to burn incense to the LORD, but only to the priests, to the sons of Aaron, to the ones having been sanctified to burn incense. Go forth from the sanctuary! for you departed from the LORD, for {will not be to you this} for glory from the LORD God. 

#### 2 Chronicles 26:19 And Uzziah was enraged. And in his hand was the incense pan to burn incense in the temple. And in his being enraged against the priests, that leprosy rose on his forehead before the priests in the house of the LORD upon the altar of the incenses. 

#### 2 Chronicles 26:20 And {turned unto him Azariah the priest foremost}, and the priests, and behold, he was leprous in the forehead. And they hastened him from there, for even he himself hastened to come forth, for {reproved him the LORD}. 

#### 2 Chronicles 26:21 And Uzziah the king was leprous until the day of his decease. And {in a house for the sick he settled}, being leprous, for he was severed from the house of the LORD. And Jotham his son was over his kingdom, to judge the people of the land. 

#### 2 Chronicles 26:22 And the rest of the words of Uzziah, the first and the last, are written by Isaiah son of Amoz the prophet. 

#### 2 Chronicles 26:23 And Uzziah slept with his fathers, and they entombed him with his fathers in the field of the burial place of the kings, for they said, He is leprous. And {reigned Jotham his son} instead of him. 

#### 2 Chronicles 27:1 {was a son twenty and five years old Jotham} in his taking reign, and sixteen years he reigned in Jerusalem. And the name to his mother was Jerousha, daughter of Zadok. 

#### 2 Chronicles 27:2 And he did the upright thing before the LORD, according to all which {did Uzziah his father}. Only into the temple of the LORD he did not enter, and yet the people corrupted themselves. 

#### 2 Chronicles 27:3 He built the gate of the house of the LORD, the high one. And in the wall of Ophel he built much. 

#### 2 Chronicles 27:4 And {cities he built} in the mountains of Judah; and in the forests he built palaces and towers. 

#### 2 Chronicles 27:5 And he did combat against the king of the sons of Ammon, and he prevailed against him. And {gave to him the sons of Ammon} each year a hundred talents of silver, and ten thousand cors of wheat, and {of barley ten thousand}. These {brought to him the king of the sons of Ammon} each year, and in the {year second}, and the third. 

#### 2 Chronicles 27:6 And Jotham grew strong, for he prepared his ways before the LORD his God. 

#### 2 Chronicles 27:7 And the rest of the words of Jotham, and the war, and his actions, behold they are written upon the scroll of the kings of Judah and Israel. 

#### 2 Chronicles 27:8 {a son twenty and five years old was Jotham} in his taking reign, and sixteen years he reigned in Jerusalem. 

#### 2 Chronicles 27:9 And Jotham slept with his fathers, and they entombed him in the city of David. And {reigned Ahaz his son} instead of him. 

#### 2 Chronicles 28:1 {a son twenty and five years old Ahaz was} in his taking reign, and sixteen years he reigned in Jerusalem. And He did not do the upright thing before the LORD as David his father. 

#### 2 Chronicles 28:2 And he went according to the ways of the kings of Israel, for {carved images he made} to the Baals. 

#### 2 Chronicles 28:3 And he sacrificed in the ravine of the Son of Hinnom, and led through his children in fire, according to the abominations of the nations which the LORD removed from the face of the sons of Israel. 

#### 2 Chronicles 28:4 And he burned incense upon the high places, and upon the roofs, and underneath every tree of the woods. 

#### 2 Chronicles 28:5 And {delivered him the LORD his God} into the hand of the king of Syria. And he struck among him, and he captured for captivity many of them, and led them unto Damascus. And also into the hands of the king of Israel he delivered him, and he struck in him {calamity a great}. 

#### 2 Chronicles 28:6 And {killed Pekah son of Remaliah king of Israel} in Judah in one day a hundred and twenty thousand {men mighty} of strength, because they left the LORD the God of their fathers. 

#### 2 Chronicles 28:7 And {killed Zechri the mighty man of Ephraim} Maaseiah the son of the king, and Azrikam the leader of his house, and Elkanah the second of the king. 

#### 2 Chronicles 28:8 And {took captive the sons of Israel} of their brethren two hundred thousand women, and sons, and daughters; and {spoils many they despoiled} of them, and they brought the spoils to Samaria. 

#### 2 Chronicles 28:9 And {was there the prophet of the LORD} -- Oded was the name to him. And he came forth to meet the force of the ones coming to Samaria. And he said to them, Behold, the anger of the LORD the God of your fathers is upon Judah, and he delivered them into your hands. But you killed among them in anger, and {unto the heavens it came}. 

#### 2 Chronicles 28:10 And now {the sons of Judah and Jerusalem you speak to acquire} for menservants and maidservants! {not Behold I am} with you to testify to the LORD your God, the trespasses are with you against the LORD your God. 

#### 2 Chronicles 28:11 And now hear me and return the captivity which you captured from your brethren! for the anger of the rage of the LORD is upon you. 

#### 2 Chronicles 28:12 And {rose up the rulers of the sons of Ephraim} (Azariah the son of Johanan, and Berechiah the son of Meshillemoth, and Jehizkiah the son of Shallum, and Amasa the son of Hadlai) unto the ones coming from the war. 

#### 2 Chronicles 28:13 And they said to them, In no way should you bring the captivity here to us, for in trespassing {against the LORD upon us you speak} to add upon our sins, and upon our ignorance, for {is great our sin}, and the anger of the rage of the LORD is upon Israel. 

#### 2 Chronicles 28:14 And {released the warriors} the captivity and the spoils before the rulers and all the assembly. 

#### 2 Chronicles 28:15 And {rose up men} who were called by name, and they took hold of the captivity. And all the naked they covered from the spoils, and clothed them, and tied sandals upon them, and gave to them to eat and to drink, and to anoint. And they assisted them by beasts of burden for all the infirm. And they placed them in Jericho, the city of palms, with their brethren. And they returned to Samaria. 

#### 2 Chronicles 28:16 In that time {sent king Ahaz} to the king of Assyria to give help to him. 

#### 2 Chronicles 28:17 And in this the Edomites attacked and struck in Judah, and they took captive a captivity. 

#### 2 Chronicles 28:18 And the Philistines attacked against the cities of the plain, and of the south of Judah, and they took Beth-shemesh, and Ajalon, and Gederoth, and Shocho and her towns, and Timnah and her towns, and Gimzo and her towns. And they dwelt there. 

#### 2 Chronicles 28:19 For the LORD humbled Judah because of Ahaz king of Judah, because he uncovered nakedness in Judah, and he revolted in a defection from the LORD. 

#### 2 Chronicles 28:20 And {came against him Tiglath-pileser king of Assyria}, and afflicted him. 

#### 2 Chronicles 28:21 And Ahaz took the things in the house of the LORD, and the things in the house of the king, and of the rulers, and gave to the king of Assyria; but {not for a help to him he was}, 

#### 2 Chronicles 28:22 but only to afflict him. And he proceeded to leave from the LORD, and {said king Ahaz}, 

#### 2 Chronicles 28:23 I will inquire of the gods of Damascus, the ones beating me. And he said, Because the gods of the king of Syria strengthens them, therefore I shall sacrifice to them, and they will assist me. And they became to him as an impediment, and to all Israel. 

#### 2 Chronicles 28:24 And Ahaz removed the items of the house of the LORD, and he cut them in pieces, and locked the doors of the house of the LORD. And he made for himself altars in every corner in Jerusalem, 

#### 2 Chronicles 28:25 and in every city; and in a city of Judah he made high places to burn incense to alien gods. And he provoked to anger the LORD God of his fathers. 

#### 2 Chronicles 28:26 And the rest of his words, and his actions, the first and last, behold, they are written upon the scroll of the kings of Judah and Israel. 

#### 2 Chronicles 28:27 And Ahaz slept with his fathers, and they entombed him in the city of David; for they did not bring him into the tombs of the kings of Israel. And {reigned Hezekiah his son} instead of him. 

#### 2 Chronicles 29:1 {was a son being twenty and five years old Hezekiah} in his taking reign, and twenty nine years he reigned in Jerusalem. And the name to his mother was Abijah, daughter of Zechariah. 

#### 2 Chronicles 29:2 And he did the upright thing before the LORD according to all as much as {did David his father}. 

#### 2 Chronicles 29:3 And it came to pass as he was established over his kingdom, in the {month first}, he opened the doors of the house of the LORD, and he repaired them. 

#### 2 Chronicles 29:4 And he brought in the priests and the Levites, and he stood them in the side, the one towards the east. 

#### 2 Chronicles 29:5 And he said to them, Hear me, O Levites! Now sanctify yourselves, and sanctify the house of the LORD the God of your fathers, and cast out the uncleanness from the holies! 

#### 2 Chronicles 29:6 For {revolted our fathers}, and they did the evil thing before the LORD our God; and they abandoned him, and turned their face from the tent of the LORD; and they gave him the back of the neck. 

#### 2 Chronicles 29:7 And they locked the doors of the temple, and they extinguished the lamps, and {incense they did not burn}, and the whole burnt-offerings they did not offer in the holy place to the God of Israel. 

#### 2 Chronicles 29:8 And {was provoked to anger the LORD} over Judah and Jerusalem. And he appointed them for an astonishment, and for extinction, and for a hissing, as you see with your eyes. 

#### 2 Chronicles 29:9 And behold, {fell our fathers} by the sword, and our sons, and our daughters, and our wives went into captivity in a land not of their own. 

#### 2 Chronicles 29:10 Because of this it became upon my heart to ordain a covenant to the LORD God of Israel, and he shall turn from us the anger of his rage. 

#### 2 Chronicles 29:11 And now, you should not stop to act, for by you the LORD has taken you up to stand before him to officiate to him, and to be his ministers, and ones burning incense. 

#### 2 Chronicles 29:12 And {rose up the Levites}, Mahath the son of Amasai, and Joel the son of Azariah, of the sons of Kohath; and from the sons of Merari, Kish the son of Abdi, and Azariah the son of Jehalelel; and from the sons of Gershon -- Joah the son of Zimmah, and Eden the son of Joah; 

#### 2 Chronicles 29:13 and of the sons of Elizaphan -- Shimri and Jeiel; and of the sons of Asaph -- Zechariah and Mattaniah; 

#### 2 Chronicles 29:14 and of the sons of Heman -- Jehiel and Shimei; and of the sons of Jeduthun -- Shemaiah and Uzziel. 

#### 2 Chronicles 29:15 And they gathered their brethren, and purified themselves according to the commandment of the king, by order of the LORD, to cleanse the house of the LORD. 

#### 2 Chronicles 29:16 And {entered the priests} inside, into the house of the LORD to purify it, and they cast out all the uncleanness they found in the house of the LORD in the courtyard of the house of the LORD. And {received the Levites} to bring it forth unto the rushing stream Kidron outside. 

#### 2 Chronicles 29:17 And they began on day one of the {month first} to sanctify, and on the {day eighth} of the month they entered into the temple of the LORD; and they sanctified the house of the LORD in {days eight}, and on the {day sixteenth} of the {month first} they completed. 

#### 2 Chronicles 29:18 And they entered inside to Hezekiah the king. And they said, We purified all the things in the house of the LORD, and the altar of the whole burnt-offering, and its utensils, and the table of the place setting, and all its utensils. 

#### 2 Chronicles 29:19 And all the utensils which {defiled king Ahaz} during his kingdom, in his defection, we prepared and sanctified. And behold, it is before the altar of the LORD. 

#### 2 Chronicles 29:20 And {rose early Hezekiah the king}, and he brought together the rulers of the city. And he ascended into the house of the LORD. 

#### 2 Chronicles 29:21 And he led up seven calves, and seven rams, and seven lambs, and seven winter yearlings of goats for a sin offering, for the kingdom, and for the holy things, and for Judah. And he told the sons of Aaron the priests, to offer unto the altar of the LORD. 

#### 2 Chronicles 29:22 And they sacrificed the calves, and {took the priests} the blood, and poured upon the altar. And they sacrificed the rams, and poured upon the altar the blood. And they sacrificed the lambs, and they poured the blood upon the altar. 

#### 2 Chronicles 29:23 And they brought the winter yearlings of the ones for a sin offering before the king and the assembly; and they placed their hands upon them. 

#### 2 Chronicles 29:24 And {sacrificed them the priests}, and atoned of their blood against the altar, and they atoned for all Israel; for {said the king}, for all Israel is the whole burnt-offering, and the ones for a sin offering. 

#### 2 Chronicles 29:25 And he stationed the Levites in the house of the LORD with cymbals, and with stringed instruments, and with lutes, according to the commandment of David the king, and Gad the seer to the king, and Nathan the prophet. For by the commandment of the LORD the order was in the hand of his prophets. 

#### 2 Chronicles 29:26 And {stood the Levites} with instruments of David, and the priests with trumpets. 

#### 2 Chronicles 29:27 And Hezekiah spoke to offer the whole burnt-offering upon the altar. And in the beginning of offering the whole burnt-offering, they began to sing to the LORD, and the trumpets with the instruments of David the king of Israel. 

#### 2 Chronicles 29:28 And all the assembly did obeisance, and the psalm singers were singing, and the trumpets trumpeting, until of which time {was completed the whole burnt-offering}. 

#### 2 Chronicles 29:29 And as they completed offering, {bent the king}, and all the ones being found with him, and they did obeisance. 

#### 2 Chronicles 29:30 And {spoke Hezekiah the king and the rulers} to the Levites for them to praise the LORD by the words of David, and of Asaph the prophet. And they sang praise with gladness, and they fell and did obeisance. 

#### 2 Chronicles 29:31 And Hezekiah answered and said, Now you filled your hands to the LORD, come forward and bring sacrifices of praise into the house of the LORD! And {brought the assembly} sacrifices and praise into the house of the LORD, and all eager in heart brought whole burnt-offerings. 

#### 2 Chronicles 29:32 And {was the number of the whole burnt-offerings which offered the assembly} -- {calves seventy}, {rams a hundred}, {lambs two hundred}; {for a whole burnt-offering to the LORD all these}. 

#### 2 Chronicles 29:33 And the ones having been sanctified -- {calves six hundred}, {sheep three thousand}. 

#### 2 Chronicles 29:34 But the priests were few, and not able to flay the whole burnt-offering; and assisting them were the Levites, until of which time {was completed the work}, and until of which time {sanctified themselves the other priests}; for the Levites more eagerly sanctified themselves than the priests. 

#### 2 Chronicles 29:35 And the whole burnt-offering was abundant with the fats of the one consecrated of the deliverance offering, and the libations of the whole burnt-offering. And {was set up the work in the house of the LORD}. 

#### 2 Chronicles 29:36 And {were glad Hezekiah and all the people}, because God prepared the people; for {suddenly happened the matter}. 

#### 2 Chronicles 30:1 And Hezekiah sent unto all Israel and Judah, and {letters he wrote} unto Ephraim and Manasseh to come into the house of the LORD in Jerusalem, to observe the passover to the LORD God of Israel. 

#### 2 Chronicles 30:2 And {planned the king}, and the rulers, and all the assembly in Jerusalem to observe the passover in the {month second}, 

#### 2 Chronicles 30:3 {not for they were} able to observe it in that time, for the priests were not sanctified enough, and the people were not gathered in Jerusalem. 

#### 2 Chronicles 30:4 And {was pleasing the matter} before the king, and before the assembly. 

#### 2 Chronicles 30:5 And they established a communication to go through by proclamation in all Israel, from Beer-sheba unto Dan, to come and to observe the passover to the LORD God of Israel in Jerusalem. For the multitude did not do according to the scripture. 

#### 2 Chronicles 30:6 And {went the ones running} with the letters from the king and from the rulers, into all Israel and Judah, according to the order of the king, saying, Sons of Israel, return to the LORD God of Abraham, and Isaac, and Jacob! and he will return to the ones having escaped, surviving from the hand of the king of Assyria. 

#### 2 Chronicles 30:7 And do not be as your fathers and your brethren! the ones who revolted from the LORD God of their fathers, and he delivered them into desolation, as you see. 

#### 2 Chronicles 30:8 And do not harden your necks as your fathers! Give glory to the LORD God, and enter into his sanctuary! which he sanctified into the eon. And serve to the LORD your God! and he will turn from you the rage of his anger. 

#### 2 Chronicles 30:9 For in your turning to the LORD, your brethren and your children will be shown compassions before all the ones taking them captive, and he will return them to this land; for merciful and pitying is the LORD our God, and he will not turn his face from us, if we should return to him. 

#### 2 Chronicles 30:10 And {were the runners} traveling city by city in mount Ephraim and Manasseh, and unto Zebulun. And they became as victims of ones ridiculing them and deriding them. 

#### 2 Chronicles 30:11 But men from Asher, and Manasseh, and from Zebulun felt shame, and they came unto Jerusalem. 

#### 2 Chronicles 30:12 And in Judah {came the hand of God} to give them {heart one} to come and to do according to the order of the king and of the rulers, by the word of the LORD. 

#### 2 Chronicles 30:13 And {gathered in Jerusalem people many} to observe the holiday of the unleavened breads in the {month second} -- {assembly vast an exceedingly}. 

#### 2 Chronicles 30:14 And they rose up and demolished the altars in Jerusalem; and all in which they burned incense to the lying idols they tore down and tossed into the rushing stream Kidron. 

#### 2 Chronicles 30:15 And they sacrificed the passover on the fourteenth of the {month second}. And the priests and the Levites felt shame, and they sanctified themselves, and they offered whole burnt-offerings in the house of the LORD. 

#### 2 Chronicles 30:16 And they stood at their station according to their responsibility, according to the commandment of Moses the man of God. And the priests received the blood from out of the hand of the Levites. 

#### 2 Chronicles 30:17 For a multitude of the assembly was not purified. And the Levites were to sacrifice the passover to all not able to be purified to the LORD. 

#### 2 Chronicles 30:18 For the vast part of the people from Ephraim, and Manasseh, and Issachar, and Zebulun, were not purified; but even they ate the passover not according to the scripture. And Hezekiah prayed for them, saying, The LORD, the good God atone for all! 

#### 2 Chronicles 30:19 {the heart even straightening out} for them to inquire of the LORD God of their fathers, even not purified as according to the purity of the holy things. 

#### 2 Chronicles 30:20 And the LORD heeded Hezekiah, and healed the people. 

#### 2 Chronicles 30:21 And {observed the sons of Israel being found in Jerusalem} the holiday of the unleavened breads seven days with {gladness great}. And they sang praise to the LORD day by day, even the priests and the Levites with instruments of strength to the LORD. 

#### 2 Chronicles 30:22 And Hezekiah spoke unto the heart of all of the Levites, and of the ones perceiving {understanding with good} in the LORD. And they completed the holiday of the unleavened breads in seven days, sacrificing a sacrifice of deliverance, and making acknowledgment to the LORD God of their fathers. 

#### 2 Chronicles 30:23 And {counseled all the assembly} to observe {seven days another}. And they observed another seven days with gladness. 

#### 2 Chronicles 30:24 For Hezekiah the king of Judah dedicated to all the assembly a thousand calves, and seven thousand sheep. And the rulers dedicated for the people {calves a thousand}, and {sheep ten thousand}, and were sanctified of the priests in multitude. 

#### 2 Chronicles 30:25 And {was glad all the assembly of Judah}, and the priests, and the Levites, and all the assembly coming from Israel, and the foreigners coming from the land of Israel, and the ones dwelling Judah. 

#### 2 Chronicles 30:26 And there was {gladness great} in Jerusalem, for from the days of Solomon son of David king of Israel there was not such a holiday in Jerusalem. 

#### 2 Chronicles 30:27 And {rose up the priests the Levites} and blessed the people, and {was heeded their voice}, and {came their prayer} into {home his sacred} in the heaven. 

#### 2 Chronicles 31:1 And as {were completed all these things}, {went forth all Israel}, the ones being found in the cities of Judah, and they broke the monuments, and knocked down the sacred groves, and tore down the high places, and demolished the altars from all Judea, and Benjamin, and from Ephraim, and from Manasseh, unto completion. And {returned all Israel} each unto his inheritance, and unto their cities. 

#### 2 Chronicles 31:2 And Hezekiah ordered the daily rotations of the priests and of the Levites, and the daily rotations of each according to his ministration, to the priests and to the Levites, for the whole burnt-offering, and for the sacrifice of deliverance, and to praise, and to acknowledge, and to officiate at the gates in the courtyards of the house of the LORD. 

#### 2 Chronicles 31:3 And the portion of the king from his possessions were appointed for the whole burnt-offerings -- the early morning and the dusk, and for the whole burnt-offerings of the Sabbaths, and for the new moons, and for the holidays, the ones being written in the law of the LORD. 

#### 2 Chronicles 31:4 And he spoke to the people, to the ones dwelling in Jerusalem, to give the portion of the priests and the Levites, so that they should grow strong in the ministry of the house of the LORD. 

#### 2 Chronicles 31:5 And as he assigned the word, {were superabundant the sons of Israel} in first-fruit of grain, and wine, and olive oil, and honey, and every offspring of the field. And {a tenth of all in multitude brought the sons of Israel and Judah}. 

#### 2 Chronicles 31:6 And the ones dwelling in the cities of Judah also themselves brought a tenth of the calves, and sheep, and a tenth of the goats. And they sanctified to the LORD their God. And they carried in and put heaps upon heaps. 

#### 2 Chronicles 31:7 In the {month third} {began the heaps} to be founded; and in the {month seventh} they were completed. 

#### 2 Chronicles 31:8 And {came Hezekiah and the rulers} and saw the heaps, and they blessed the LORD, and his people Israel. 

#### 2 Chronicles 31:9 And Hezekiah inquired of the priests and of the Levites concerning the heaps. 

#### 2 Chronicles 31:10 And {spoke to him Azariah the priest the ruler of the house of Zadok}, and he said, From of which time {began the first-fruit} to be brought into the house of the LORD, we ate and drank, and we left behind unto in abundance. For the LORD blessed his people, and we left behind still this multitude. 

#### 2 Chronicles 31:11 And Hezekiah spoke to prepare cubicles in the house of the LORD; and they prepared. 

#### 2 Chronicles 31:12 And they carried in there the first-fruits, and the tenth parts in trust. And over them for supervisor was Cononiah the Levite, and Shimei his brother relieving, 

#### 2 Chronicles 31:13 and Jehiel, and Azaziah, and Nahath, and Asahel, and Jerimoth, and Jozabad, and Eliel, and Ismachiah, and Mahath, and Benaiah being placed by Cononiah and Shimei his brother, as {assigned Hezekiah the king}, and Azariah the leader of the house of the LORD. 

#### 2 Chronicles 31:14 And Kore the son of Imnah the Levite, the gatekeeper according to the east, was over the gifts, to give the first-fruits of the LORD, and the holy things of the holies, 

#### 2 Chronicles 31:15 through the hand of Eden and Miniamin, and Jeshua, and Shemaiah, and Amariah, and Shecaniah, in the cities through the hand of the priests in trust, to give to their brethren according to the daily rotations, according to the great and the small; 

#### 2 Chronicles 31:16 outside of the genealogy of the males from three years and up, to all entering into the house of the LORD, for a reckoning of days in its day, for ministration of daily rotation of their arrangement. 

#### 2 Chronicles 31:17 This is the distribution of the priests according to the houses of their families; and the Levites in their daily rotations from twenty years and up, in arrangement, 

#### 2 Chronicles 31:18 in classification, in all genealogy of their sons, and their daughters, in the entire multitude, (for in trust they sanctified the holy,) 

#### 2 Chronicles 31:19 and to the sons of Aaron, to the ones officiating as priests in the country areas, and in their cities, in every city, and a city where men who were named by name to give a portion to every male among the priests, and to every one being counted among the Levites. 

#### 2 Chronicles 31:20 And {did thus Hezekiah} in all Judah, and he did the good and the upright, and the true before the LORD his God. 

#### 2 Chronicles 31:21 And in every work in which he began in the work in the house of the LORD, and in the law, and in the orders, he sought after his God from {entire soul his}. And he acted, and his way prospered. 

#### 2 Chronicles 32:1 And after these words, and this truth, came Sennacherib king of the Assyrians. And he came unto Judah, and he camped about the {cities walled}, and he spoke at first to take them. 

#### 2 Chronicles 32:2 And Hezekiah beheld that Sennacherib comes, and his face was to wage war against Jerusalem. 

#### 2 Chronicles 32:3 And he consulted with his elders, and the mighty ones to obstruct the waters of the springs which was outside the city, and they vigorously assisted him. 

#### 2 Chronicles 32:4 And he brought together {people many}, and they obstructed the waters of the springs, and the rushing stream separating through the city, saying, Should {come the king of the Assyrians} and find {water much}, and grow strong? 

#### 2 Chronicles 32:5 And Hezekiah strengthened himself, and built up every wall having been razed, and towers, and {outside wall around another}. And he strengthened the elevation of the city of David, and carefully prepared {weapons many}. 

#### 2 Chronicles 32:6 And he put rulers of war over the people. And they were brought together to him upon the square of the gate of the city. And he spoke unto their heart, saying, 

#### 2 Chronicles 32:7 Be strong and be manly! fear not, nor be terrified from the face of the king of Assyria, nor from the face of any of the nations with him! for with us are more over the ones with him. 

#### 2 Chronicles 32:8 With him are arms of flesh, {with us but} is the LORD our God, to deliver and to wage our war. And {relied with confidence the people} upon the words of Hezekiah king of Judah. 

#### 2 Chronicles 32:9 And after these things {sent Sennacherib king of the Assyrians} his servants unto Jerusalem. And he was by Lachish, and all his military with him. And he sent to Hezekiah king of Judah, and to all Judah in Jerusalem, saying, 

#### 2 Chronicles 32:10 Thus says Sennacherib king of the Assyrians, Upon whom do you rely, that you settle in the stronghold in Jerusalem? 

#### 2 Chronicles 32:11 Has not Hezekiah deceived you to deliver you into death, and into hunger, and into thirst, saying, The LORD our God shall deliver us from the hand of the king of Assyria? 

#### 2 Chronicles 32:12 {not this Is} Hezekiah who removed his altars, and his high places, and said to Judah, and to the ones dwelling in Jerusalem, saying, Before this altar you shall do obeisance, and upon it you shall burn incense? 

#### 2 Chronicles 32:13 Do you not know what {did I and my fathers} to all the peoples of the places. In being able, were {able the gods of the nations of all the earth} to deliver their people from my hand? 

#### 2 Chronicles 32:14 Who among all the gods of these nations, which {utterly destroyed my fathers}, is the one who is able to rescue his people from my hand, that {shall be able your God} to deliver you from out of my hand? 

#### 2 Chronicles 32:15 And now, let not {deceive you Hezekiah}, and not persuade you to do according to these things, and do not trust him; for in no way was {able a god of any nation and kingdom} to deliver his people from out of my hand, and from out of the hand of my fathers. For {your God in no way shall} deliver you from out of my hand. 

#### 2 Chronicles 32:16 And still {spoke his servants} against the LORD God, and against Hezekiah his servant. 

#### 2 Chronicles 32:17 And {a scroll he wrote} to berate the LORD God of Israel. And he said concerning him, saying, As the gods of the nations of the earth did not rescue their people from my hand, so in no way shall {rescue the God of Hezekiah} his people from out of my hand. 

#### 2 Chronicles 32:18 And they yelled with {voice a great} in Jewish unto the people of Jerusalem upon the wall, to make them afraid of them, and to tear them down, so as to first take the city. 

#### 2 Chronicles 32:19 And he spoke against the God of Jerusalem, as also against the gods of the peoples of the land -- the works of the hands of men. 

#### 2 Chronicles 32:20 And {prayed Hezekiah the king}, and Isaiah son of Amoz the prophet concerning these things, and they yelled unto the heaven. 

#### 2 Chronicles 32:21 And the LORD sent an angel, and he obliterated every mighty warrior, and ruler, and commandant in the camp of the king of Assyria. And he returned with shame of face into his land. And he entered into the house of his god, and some of the ones coming forth from his belly overthrew him by the broadsword. 

#### 2 Chronicles 32:22 And the LORD delivered Hezekiah and the ones dwelling in Jerusalem from the hand of Sennacherib king of Assyria, and from the hand of all, and rested them round about. 

#### 2 Chronicles 32:23 And many brought gifts to the LORD in Jerusalem, and presents to Hezekiah king of Judah. And he was elevated in the eyes of all the nations after these things. 

#### 2 Chronicles 32:24 In those days Hezekiah became ill unto death, and he prayed to the LORD. And he heeded him, and {a sign gave to him}. 

#### 2 Chronicles 32:25 And {rendered not according to the recompense which he recompensed to him Hezekiah}; but he exalted his heart. And {came upon him wrath}, and upon Judah, and Jerusalem. 

#### 2 Chronicles 32:26 And Hezekiah was humbled from the haughtiness of his heart, he and the ones dwelling in Jerusalem. And {did not come upon them the wrath of the LORD} in the days of Hezekiah. 

#### 2 Chronicles 32:27 And there came to Hezekiah riches and glory -- {much exceedingly}. And {treasuries he made himself} of silver, and of gold, and {stone of valuable}, and for aromatics; and {armories he made}, and {for all the items of the desirable things storehouses}; 

#### 2 Chronicles 32:28 and cities for the produce of the grain, and wine, and olive oil; and stables for every beast, and havens for the flocks. 

#### 2 Chronicles 32:29 And {cities he made} for himself, and possessions of sheep and oxen in abundance; for {gave to him the LORD belongings vast exceedingly}. 

#### 2 Chronicles 32:30 Hezekiah himself obstructed the delivery of the water of Gihon -- the upper part, and he straightened it below to the west of the city of David. And the way of Hezekiah was prospered in all his works. 

#### 2 Chronicles 32:31 And thus in the matters concerning the ambassadors of the rulers of the ones from Babylon being sent to him, to inquire of him of the miracle which took place in the land, that {abandoned him the LORD}, to test him, to know the things in his heart. 

#### 2 Chronicles 32:32 And the rest of the words of Hezekiah, and his mercies, behold, they are written in the prophecy of Isaiah son of Amoz the prophet, and upon the scroll of the kings of Judah and Israel. 

#### 2 Chronicles 32:33 And Hezekiah slept with his fathers. And they entombed him in the ascent of the burying-places of the sons of David. And glory and honor they gave to him in his death, even all Judah, and the ones dwelling in Jerusalem. And {reigned Manasseh his son} instead of him. 

#### 2 Chronicles 33:1 {was a son being twelve years old Manasseh} in his taking reign, and fifty-five years he reigned in Jerusalem. 

#### 2 Chronicles 33:2 And he acted wickedly before the LORD according to all the abominations of the nations which the LORD removed from in front of the sons of Israel. 

#### 2 Chronicles 33:3 And he returned and built the high places which {tore down Hezekiah his father}. And he set up altars to the Baals, and he made sacred groves, and he did obeisance to all the military of the heaven, and he served to them. 

#### 2 Chronicles 33:4 And he built altars in the house of the LORD, in which the LORD said, {in Jerusalem will be My name} into the eon. 

#### 2 Chronicles 33:5 And he built altars to all the military of the heaven in the two courtyards of the house of the LORD. 

#### 2 Chronicles 33:6 And he led his children in fire in the ground of the Son of Hinnom. And he prognosticated, and foretold, and administered potions, and established ones who deliver oracles, and enchanters. And he multiplied to act wickedly before the LORD, to provoke him to anger. 

#### 2 Chronicles 33:7 And he put the carved and the molten image, which he made, in the house of God, in which God said to David and to Solomon his son, In this house, and in Jerusalem, which I chose from out of all the tribes of Israel, I will put my name there into the eon; 

#### 2 Chronicles 33:8 and I shall not proceed to shake the foot of Israel from the land of which I gave to their fathers, if only they guard to do all things which I gave charge to them, according to all the law, and the orders, and the judgments given by the hand of Moses. 

#### 2 Chronicles 33:9 And Manasseh misled Judah and the ones dwelling in Jerusalem, to act wickedly above all the nations which the LORD removed from in front of the sons of Israel. 

#### 2 Chronicles 33:10 And the LORD spoke with Manasseh, and unto his people, and they did not listen. 

#### 2 Chronicles 33:11 And the LORD led upon them the rulers of the force of the king of Assyria. And they overtook Manasseh in bonds, and they tied him in shackles, and they led him into Babylon. 

#### 2 Chronicles 33:12 And as he was afflicted, he sought the face of the LORD his God, and was humbled exceedingly from in front of the God of his fathers. 

#### 2 Chronicles 33:13 And he prayed to him, and he heeded him, and he heeded his yelling, and he returned him unto Jerusalem over his kingdom. And Manasseh knew that the LORD -- he is God. 

#### 2 Chronicles 33:14 And after these things, he built a wall outside the city of David, from the southwest of Gihon, by the rushing stream going forth by the {gate fishing} -- a circuit to the Ophel, and he raised it high exceedingly. And he placed rulers of the force in all the {cities walled} in Judah. 

#### 2 Chronicles 33:15 And he removed the gods of the aliens, and the carved image from out of the house of the LORD, and all the altars which he built on the mountain of the house of the LORD, and in Jerusalem; and he cast them outside the city. 

#### 2 Chronicles 33:16 And he set up the altar of the LORD, and he sacrificed upon it a sacrifice of deliverance offering and a praise offering, and he told Judah to serve to the LORD, to the God of Israel. 

#### 2 Chronicles 33:17 Only still the people {upon the high places sacrificed}, except to the LORD their God. 

#### 2 Chronicles 33:18 And the rest of the words of Manasseh, and his prayer to God, and the words of the seers, of the ones speaking to him in the name of the LORD God of Israel, behold, they are upon the words of the kings of Israel. 

#### 2 Chronicles 33:19 And his prayer, and as God heeded him, and all his sins, and his defections, and the places upon which he built on them the high places, and established there sacred groves, and carved images, before he returned, behold, they are written by the words of the seers. 

#### 2 Chronicles 33:20 And Manasseh slept with his fathers, and they entombed him in the garden of his house. And {reigned Amon his son} instead of him. 

#### 2 Chronicles 33:21 {was a son being twenty and two years old Amon} in his taking reign, and two years he reigned in Jerusalem. 

#### 2 Chronicles 33:22 And he did the wicked thing before the LORD as did Manasseh his father. And to all the idols which {made Manasseh his father}, Amon sacrificed and served to them. 

#### 2 Chronicles 33:23 And he was not humbled before the LORD as {was humbled Manasseh his father}; for his son Amon multiplied in trespassing. 

#### 2 Chronicles 33:24 And {attacked him his servants}, and struck him in his house. 

#### 2 Chronicles 33:25 But {struck the people of the land} the ones attacking against king Amon. And {gave reign to the people of the land} Josiah his son instead of him. 

#### 2 Chronicles 34:1 {was a son being eight years old Josiah} in his taking reign, and thirty and one year he reigned in Jerusalem. 

#### 2 Chronicles 34:2 And he did the upright thing before the LORD, and he went in the ways of David his father, and he did not turn aside right nor left. 

#### 2 Chronicles 34:3 And in the eighth year of his kingdom (and he was still a boy) he began to seek the LORD God of David his father. And in the twelfth year of his kingdom he began to cleanse Judah and Jerusalem of the high places, and of the sacred groves, and of the shrines, and of the carved images, and of the molten images. 

#### 2 Chronicles 34:4 And he razed the things before his face -- altars, the ones to the Baals; and the high places, the ones above them. And he cut down the sacred groves, and the carved images. And the molten images he broke and ground fine, and tossed their dust upon the face of the tombs of the ones sacrificing to them. 

#### 2 Chronicles 34:5 And the bones of the priests he incinerated upon their altars, and he cleansed Judah and Jerusalem, 

#### 2 Chronicles 34:6 and among the cities of Manasseh, and Ephraim, and Simeon, and Naphtali, and the places round about them. 

#### 2 Chronicles 34:7 And he tore down the altars, and the sacred groves; and the idols he cut in fine pieces, and all the high places he cut in pieces from all the land of Israel, and he returned to Jerusalem. 

#### 2 Chronicles 34:8 And in the eighteenth year of his kingdom, when he urged {to be cleansed the land and the house}, he sent Shaphan son of Azaliah, and Maaseiah ruler of the city, and Joah son of Joahaz the recorder, to fortify the house of the LORD his God. 

#### 2 Chronicles 34:9 And they came to Helkiah the {priest great}, and they gave the money that was carried into the house of God, which {gathered the Levites guarding the gate} by the hand of Manasseh and Ephraim, and of the rulers, and of all the rest in Israel, and of all Judah and Benjamin, and of the ones living in Jerusalem. 

#### 2 Chronicles 34:10 And they put it into the hand of the ones doing the works, of the ones placed in the house of the LORD. And they gave it to the ones doing the works in the house of the LORD to repair and to strengthen the house. 

#### 2 Chronicles 34:11 And they gave it to the fabricators and to the builders to buy {stones quadrangular}, and wood for beams to roof the houses which {utterly destroyed the kings of Judah}. 

#### 2 Chronicles 34:12 And the men were doing in trust the things over the works. And over them overseers were established -- Jahath and Obadiah the Levites, of the sons of Merari; and Zechariah and Meshullam, of the sons of Kohath -- to oversee; and all other Levites, and all perceiving to play with instruments of odes, 

#### 2 Chronicles 34:13 and over the load carriers, and knowers concerning all of the ones doing the works in effort; and others of the Levites -- scribes and judges and gatekeepers. 

#### 2 Chronicles 34:14 And in their bringing forth the money coming in as income into the house of the LORD, {found Helkiah the priest} the scroll of the law of the LORD, the one by the hand of Moses. 

#### 2 Chronicles 34:15 And Helkiah responded and said to Shaphan the scribe, {the scroll of the law I found} in the house of the LORD. And Helkiah gave the scroll to Shaphan. 

#### 2 Chronicles 34:16 And Shaphan carried the scroll to the king, and he gave yet to the king a word, saying, All the money was rendered into the hand of your servants of the ones doing the work. 

#### 2 Chronicles 34:17 And they cast in a furnace the silver found in the house of the LORD, and they put it into the hand of the overseers, and into the hand of the ones doing the work. 

#### 2 Chronicles 34:18 And {reported Shaphan the scribe} to the king, saying, {a scroll gave to me Helkiah the priest}. And {read it Shaphan} before the king. 

#### 2 Chronicles 34:19 And it came to pass as {heard the king} the words of the law, that he tore his garments. 

#### 2 Chronicles 34:20 And {gave charge the king} to Helkiah, and to Ahikam son of Shaphan, and to Abdon son of Micah, and to Shaphan the scribe, and to Asaiah servant of the king, saying, 

#### 2 Chronicles 34:21 Go, seek the LORD for me, and for all the ones left in Israel and Judah, concerning the words of the scroll of the one being found! for great is the rage of the LORD which burns away against us, because {did not listen our fathers} concerning the word of the LORD, to do according to all the things being written in this scroll. 

#### 2 Chronicles 34:22 And Helkiah went, and the ones who told the king, to Huldah the prophetess, wife of Shallum, son of Tikvath, son of Hazrah the keeper of the cloaks; and she dwelt in Jerusalem in the second section. And they spoke to her according to these things. 

#### 2 Chronicles 34:23 And she said to them, Thus said the LORD God of Israel, Say to the man, to the one sending you to me, 

#### 2 Chronicles 34:24 Thus says the LORD, Behold, I bring evils upon this place, and upon the ones dwelling in it, of all the words being written in the scroll being read before the king of Judah. 

#### 2 Chronicles 34:25 Because they abandoned me, and burnt incense {gods to alien}, that they should provoke me to anger by all the works of their hands. And {was burned my rage} against this place, and it will not be extinguished. 

#### 2 Chronicles 34:26 And concerning the king of Judah, the one sending you to seek the LORD, Thus shall you say to him, Thus says the LORD God of Israel, Of the words which you heard, 

#### 2 Chronicles 34:27 and because {feels shame your heart}, and you humbled yourself in front of me in your hearing my words against this place, and against the ones dwelling in it; and you were humbled before me, and tore your garments, and wept before me; even I heard, says the LORD. 

#### 2 Chronicles 34:28 Behold, I add you to your fathers, and you shall be added to your grave in peace. And {shall not see your eyes} all the evils which I bring upon this place, and upon the ones dwelling it. And they brought back {to the king the word}. 

#### 2 Chronicles 34:29 And {sent the king} and brought together the elders of Judah and Jerusalem. 

#### 2 Chronicles 34:30 And {ascended the king} into the house of the LORD, and all Judah, and the ones dwelling in Jerusalem, and the priests, and the Levites, and all the people from small unto great. And he read in their ears all the words of the scroll of the covenant being found in the house of the LORD. 

#### 2 Chronicles 34:31 And {stood the king} upon the column, and he ordained a covenant before the LORD, to go before the LORD, to guard his commandments, and his testimonies, and his orders, with the entire heart, and with the entire soul, so as to observe the words of the covenant having been written upon this scroll. 

#### 2 Chronicles 34:32 And he established all the ones being found in Jerusalem, and in Judah, and Benjamin. And {did the ones dwelling in Jerusalem} according to the covenant of the LORD God of their fathers. 

#### 2 Chronicles 34:33 And Josiah removed all the abominations from out of all the land, which was of the sons of Israel. And he made all the ones being found in Jerusalem and in Israel serve to the LORD their God all his days. He did not turn aside from following after the LORD God of his fathers. 

#### 2 Chronicles 35:1 And Josiah observed the passover in Jerusalem to the LORD his God. And he sacrificed the passover on the fourteenth of the {month first}. 

#### 2 Chronicles 35:2 And he stationed the priests at their watches, and he strengthened them for the works of the house of the LORD. 

#### 2 Chronicles 35:3 And he spoke to the Levites, to the mighty ones in all Israel, to sanctify themselves to the LORD, and to put the {ark holy} in the house of the LORD. And they put the {ark holy} in the house which {built Solomon son of David the king of Israel}. And {said the king}, It is not for you to lift {upon your shoulders anything}. Now then, you officiate to the LORD your God, and to his people Israel! 

#### 2 Chronicles 35:4 And be prepared according to the houses of your families, and according to your daily rotations, according to the writing of David king of Israel, and by the hand of Solomon his son! 

#### 2 Chronicles 35:5 And stand in the house according to the divisions of the houses of your families, of your brethren, the sons of the people, and the portion of the house of the family to the Levites! 

#### 2 Chronicles 35:6 And sacrifice the passover, and {the holy things prepare} for your brethren! to observe according to the word of the LORD by the hand of Moses. 

#### 2 Chronicles 35:7 And Josiah dedicated for the sons of the people -- sheep, and lambs, and kids from the sons of the goats, all for the passover, to everyone being found -- in number thirty thousand, and {calves three thousand}. These were of the substance of the king. 

#### 2 Chronicles 35:8 And his rulers dedicated to the people, and to the priests, and to the Levites; and Helkiah and Zechariah and Jeiel the rulers of the house of God gave to the priests for the passover -- sheeps and lambs and kids -- two thousand and six hundred, and {calves three hundred}. 

#### 2 Chronicles 35:9 And Conaniah, and Shemaiah, and Nethaneel his brother, and Hashabiah, and Jehiel, and Jozabad, rulers of the Levites, dedicated to the Levites for the passover -- {sheep five thousand}, and {calves five hundred}. 

#### 2 Chronicles 35:10 And {was set up the ministration}, and {stood the priests} at their station, and the Levites in their divisions, according to the commandment of the king. 

#### 2 Chronicles 35:11 And they sacrificed the passover. And {poured the priests} the blood from out of their hand, and the Levites flayed. 

#### 2 Chronicles 35:12 And they prepared the whole burnt-offering, to deliver them according to the division, according to the houses of the families to the sons of the people, to offer to the LORD, as it is written in the book of Moses. And so it was into the morning. 

#### 2 Chronicles 35:13 And they roasted the passover in fire according to the ordinance. And the holy pieces they boiled in the brass cauldrons, and in the kettles. And the way prospered, and they ran it to all the sons of the people. 

#### 2 Chronicles 35:14 And after this they prepared for themselves, and for the priests (for the priests, the sons of Aaron, in offering of the whole burnt-offerings and of the fat,) until night. And the Levites prepared for themselves, and for their brethren the sons of Aaron. 

#### 2 Chronicles 35:15 And the psalm singers, the sons of Asaph were at their station, according to the commands of David, and Asaph, and Heman, and Jeduthun of the prophets of the king; and the rulers, and the gatekeepers, were stationed gate by gate; it was not for them to move from their ministration, for their brethren the Levites prepared for them. 

#### 2 Chronicles 35:16 And {was set up all the ministration of the LORD} in that day, to observe the passover, and to offer the whole burnt-offerings upon the altar of the LORD, according to the command of king Josiah. 

#### 2 Chronicles 35:17 And {observed the sons of Israel being found present} the passover at that time, and the holiday of the unleavened breads seven days. 

#### 2 Chronicles 35:18 And there was not a passover likened to it in Israel from the days of Samuel the prophet; for all kings of Israel did not do the passover which Josiah did, and the priests, and the Levites, and all Judah and Israel, the ones being found, and the ones dwelling in Jerusalem, to the LORD. 

#### 2 Chronicles 35:19 In the eighteenth year of the kingdom of Josiah {was observed this passover}. 

#### 2 Chronicles 35:20 And after all these things which Josiah prepared for the house, {ascended up Pharaoh Necho king of Egypt} against the king of the Assyrians at the river Euphrates, to wage war against him at Carchemish. And {went king Josiah} to meet against him. 

#### 2 Chronicles 35:21 And he sent to him messengers, saying, What is it to me and to you, O king of Judah? {not against you I come} today to make war, but only against the place of my war; and God told me to hasten. You take heed of the God, of the one with me, lest he ruin you. 

#### 2 Chronicles 35:22 And {did not turn Josiah} his face from him, but he fortified himself to wage war against him. And he did not hearken concerning the words of Pharaoh Necho by the mouth of God. And he came to wage war in the plain of Megiddo. 

#### 2 Chronicles 35:23 And {shot the bowmen} unto king Josiah. And {said the king} to his servants, Lead me out! for I am in pain exceedingly. 

#### 2 Chronicles 35:24 And {led him his servants} from the chariot, and hauled him upon the {chariot second} which was his; and they led him to Jerusalem, and he died, and he was entombed with his fathers. And all Judah and Jerusalem mourned over Josiah. 

#### 2 Chronicles 35:25 And Jeremiah lamented over Josiah. And {spoke all the rulers and the ones in control} a lamentation over Josiah spoken until today. And they appointed it as an order unto Israel, and behold, it is written in the lamentations. 

#### 2 Chronicles 35:26 And {were the rest of the words of Josiah and his hope} being written in the law of the LORD. 

#### 2 Chronicles 35:27 And his words, the first and the last, behold, they are written upon the scroll of the kings of Israel and Judah. 

#### 2 Chronicles 36:1 And {took the people of the land} Jehoahaz son of Josiah, and they anointed him, and placed him as king instead of his father in Jerusalem. 

#### 2 Chronicles 36:2 {was a son being twenty and three years old Jehoahaz} in his taking reign, and three months he reigned in Jerusalem. 

#### 2 Chronicles 36:3 And {removed him the king of Egypt} to not give reign to him in Jerusalem, and put a tribute upon the land of a hundred talents of silver, and a talent of gold. 

#### 2 Chronicles 36:4 And {placed the king of Egypt} Eliakim son of Josiah as king over Judah and Jerusalem, and converted his name to Jehoiakim. And {Jehoahaz his brother took Pharaoh Necho}, and brought him to Egypt. 

#### 2 Chronicles 36:5 {was a son being twenty and five years old Jehoiakim} in his taking reign. And eleven years he reigned in Jerusalem. And he acted wickedly before the LORD. 

#### 2 Chronicles 36:6 And {ascended against him Nebuchadnezzar king of Babylon}, and bound him in brass shackles, and took him into Babylon. 

#### 2 Chronicles 36:7 And part of the items of the house of the LORD he carried away unto Babylon, and he put them in his temple in Babylon. 

#### 2 Chronicles 36:8 And the rest of the words of Jehoiakim, and all which he did, behold, these are written in the scroll of the words of the days of the kings of Israel and of Judah. And {reigned Jehoiachin his son} instead of him. 

#### 2 Chronicles 36:9 {was a son being eight years old Jehoiachin} in his taking reign. And three months and ten days he reigned in Jerusalem. And he acted wickedly in the presence of the LORD. 

#### 2 Chronicles 36:10 And at the turn of the year {sent king Nebuchadnezzar} and brought him unto Babylon, with the {items desirable} of the house of the LORD. And {reigned Zedekiah the brother of his father} over Judah and Jerusalem. 

#### 2 Chronicles 36:11 {years old twenty one was a son being Zedekiah} in his taking reign, and eleven years he reigned in Jerusalem. 

#### 2 Chronicles 36:12 And he did the wicked thing before the LORD his God. And he did not feel shame from in front of Jeremiah the prophet, and from the mouth of the LORD, 

#### 2 Chronicles 36:13 in the {the things with king Nebuchadnezzar annulling}, in which he bound him by an oath according to God. And he hardened his neck, and {his heart he strengthened} to not return to the LORD God of Israel. 

#### 2 Chronicles 36:14 And all the honorable men of Judah, and the priests, and the people of the land multiplied to disregard good, to do wickedness according to the abominations of the nations; and they defiled the house of the LORD in Jerusalem. 

#### 2 Chronicles 36:15 And {sent the LORD God of their fathers} to them by the hand of his prophets, ones rising up early, even sending his messengers, for he was sparing his people, and his sanctuary. 

#### 2 Chronicles 36:16 And they were sneering at his messengers, and treating with contempt his words, and mocking among his prophets, until {ascended the rage of the LORD} among his people until there was no cure. 

#### 2 Chronicles 36:17 And he led against them the king of the Chaldeans, and he killed their young men by the broadsword in the house of his sanctuary. And he did not spare the young men. And their virgins he did not show mercy on, and their elders he took away -- whole he delivered up into their hands. 

#### 2 Chronicles 36:18 And all the items of the house of God, the great and the small, and the treasures of the house of the LORD, and all the treasures of the king, and of the great men. The whole he carried unto Babylon. 

#### 2 Chronicles 36:19 And he burnt the house of the LORD, and razed the wall of Jerusalem. And its palaces he burnt by fire, and every {item beautiful} he appointed for extinction. 

#### 2 Chronicles 36:20 And he resettled the remaining ones in Babylon. And they were for him and his sons for manservants until the kingdom of the Medes, 

#### 2 Chronicles 36:21 to fulfill the word of the LORD through the mouth of Jeremiah, until {favorably receives the land} its Sabbaths; by observing the Sabbath all the days of its desolation, to observe the Sabbath in the fulfillment {years of seventy}. 

#### 2 Chronicles 36:22 {year In the first} of Cyrus king of the Persians, after the fulfillment of the saying of the LORD through the mouth of Jeremiah, the LORD awakened the spirit of Cyrus king of the Persians. And he exhorted to proclaim in all his kingdom in writing, saying, 

#### 2 Chronicles 36:23 Thus says Cyrus king of the Persians, to all the kingdoms of the earth, {gave to me The LORD God of the heaven}; and he gave charge to me to build to him a house in Jerusalem in Judea. Who is there of you of all his people? The LORD his God will be with him -- let him ascend!