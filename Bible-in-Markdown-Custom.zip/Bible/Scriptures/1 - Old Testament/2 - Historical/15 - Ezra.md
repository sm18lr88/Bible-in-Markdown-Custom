#### Ezra 1:1  In the first year of Cyrus king of Persia, that the word of the LORD by the mouth of Jeremiah might be fulfilled, the LORD stirred up the spirit of Cyrus king of Persia, so that he made a proclamation throughout all his kingdom and also put it in writing:
#### Ezra 1:2  “Thus says Cyrus king of Persia: The LORD, the God of heaven, has given me all the kingdoms of the earth, and he has charged me to build him a house at Jerusalem, which is in Judah.
#### Ezra 1:3  Whoever is among you of all his people, may his God be with him, and let him go up to Jerusalem, which is in Judah, and rebuild the house of the LORD, the God of Israel—he is the God who is in Jerusalem.
#### Ezra 1:4  And let each survivor, in whatever place he sojourns, be assisted by the men of his place with silver and gold, with goods and with beasts, besides freewill offerings for the house of God that is in Jerusalem.”
#### Ezra 1:5  Then rose up the heads of the fathers' houses of Judah and Benjamin, and the priests and the Levites, everyone whose spirit God had stirred to go up to rebuild the house of the LORD that is in Jerusalem.
#### Ezra 1:6  And all who were about them aided them with vessels of silver, with gold, with goods, with beasts, and with costly wares, besides all that was freely offered.
#### Ezra 1:7  Cyrus the king also brought out the vessels of the house of the LORD that Nebuchadnezzar had carried away from Jerusalem and placed in the house of his gods.
#### Ezra 1:8  Cyrus king of Persia brought these out in the charge of Mithredath the treasurer, who counted them out to Sheshbazzar the prince of Judah.
#### Ezra 1:9  And this was the number of them: 30 basins of gold, 1,000 basins of silver, 29 censers,
#### Ezra 1:10  30 bowls of gold, 410 bowls of silver, and 1,000 other vessels;
#### Ezra 1:11  all the vessels of gold and of silver were 5,400. All these did Sheshbazzar bring up, when the exiles were brought up from Babylonia to Jerusalem.
#### Ezra 2:1  Now these were the people of the province who came up out of the captivity of those exiles whom Nebuchadnezzar the king of Babylon had carried captive to Babylonia. They returned to Jerusalem and Judah, each to his own town.
#### Ezra 2:2  They came with Zerubbabel, Jeshua, Nehemiah, Seraiah, Reelaiah, Mordecai, Bilshan, Mispar, Bigvai, Rehum, and Baanah. The number of the men of the people of Israel:
#### Ezra 2:3  the sons of Parosh, 2,172.
#### Ezra 2:4  The sons of Shephatiah, 372.
#### Ezra 2:5  The sons of Arah, 775.
#### Ezra 2:6  The sons of Pahath-moab, namely the sons of Jeshua and Joab, 2,812.
#### Ezra 2:7  The sons of Elam, 1,254.
#### Ezra 2:8  The sons of Zattu, 945.
#### Ezra 2:9  The sons of Zaccai, 760.
#### Ezra 2:10  The sons of Bani, 642.
#### Ezra 2:11  The sons of Bebai, 623.
#### Ezra 2:12  The sons of Azgad, 1,222.
#### Ezra 2:13  The sons of Adonikam, 666.
#### Ezra 2:14  The sons of Bigvai, 2,056.
#### Ezra 2:15  The sons of Adin, 454.
#### Ezra 2:16  The sons of Ater, namely of Hezekiah, 98.
#### Ezra 2:17  The sons of Bezai, 323.
#### Ezra 2:18  The sons of Jorah, 112.
#### Ezra 2:19  The sons of Hashum, 223.
#### Ezra 2:20  The sons of Gibbar, 95.
#### Ezra 2:21  The sons of Bethlehem, 123.
#### Ezra 2:22  The men of Netophah, 56.
#### Ezra 2:23  The men of Anathoth, 128.
#### Ezra 2:24  The sons of Azmaveth, 42.
#### Ezra 2:25  The sons of Kiriath-arim, Chephirah, and Beeroth, 743.
#### Ezra 2:26  The sons of Ramah and Geba, 621.
#### Ezra 2:27  The men of Michmas, 122.
#### Ezra 2:28  The men of Bethel and Ai, 223.
#### Ezra 2:29  The sons of Nebo, 52.
#### Ezra 2:30  The sons of Magbish, 156.
#### Ezra 2:31  The sons of the other Elam, 1,254.
#### Ezra 2:32  The sons of Harim, 320.
#### Ezra 2:33  The sons of Lod, Hadid, and Ono, 725.
#### Ezra 2:34  The sons of Jericho, 345.
#### Ezra 2:35  The sons of Senaah, 3,630.
#### Ezra 2:36  The priests: the sons of Jedaiah, of the house of Jeshua, 973.
#### Ezra 2:37  The sons of Immer, 1,052.
#### Ezra 2:38  The sons of Pashhur, 1,247.
#### Ezra 2:39  The sons of Harim, 1,017.
#### Ezra 2:40  The Levites: the sons of Jeshua and Kadmiel, of the sons of Hodaviah, 74.
#### Ezra 2:41  The singers: the sons of Asaph, 128.
#### Ezra 2:42  The sons of the gatekeepers: the sons of Shallum, the sons of Ater, the sons of Talmon, the sons of Akkub, the sons of Hatita, and the sons of Shobai, in all 139.
#### Ezra 2:43  The temple servants: the sons of Ziha, the sons of Hasupha, the sons of Tabbaoth,
#### Ezra 2:44  the sons of Keros, the sons of Siaha, the sons of Padon,
#### Ezra 2:45  the sons of Lebanah, the sons of Hagabah, the sons of Akkub,
#### Ezra 2:46  the sons of Hagab, the sons of Shamlai, the sons of Hanan,
#### Ezra 2:47  the sons of Giddel, the sons of Gahar, the sons of Reaiah,
#### Ezra 2:48  the sons of Rezin, the sons of Nekoda, the sons of Gazzam,
#### Ezra 2:49  the sons of Uzza, the sons of Paseah, the sons of Besai,
#### Ezra 2:50  the sons of Asnah, the sons of Meunim, the sons of Nephisim,
#### Ezra 2:51  the sons of Bakbuk, the sons of Hakupha, the sons of Harhur,
#### Ezra 2:52  the sons of Bazluth, the sons of Mehida, the sons of Harsha,
#### Ezra 2:53  the sons of Barkos, the sons of Sisera, the sons of Temah,
#### Ezra 2:54  the sons of Neziah, and the sons of Hatipha.
#### Ezra 2:55  The sons of Solomon's servants: the sons of Sotai, the sons of Hassophereth, the sons of Peruda,
#### Ezra 2:56  the sons of Jaalah, the sons of Darkon, the sons of Giddel,
#### Ezra 2:57  the sons of Shephatiah, the sons of Hattil, the sons of Pochereth-hazzebaim, and the sons of Ami.
#### Ezra 2:58  All the temple servants and the sons of Solomon's servants were 392.
#### Ezra 2:59  The following were those who came up from Tel-melah, Tel-harsha, Cherub, Addan, and Immer, though they could not prove their fathers' houses or their descent, whether they belonged to Israel:
#### Ezra 2:60  the sons of Delaiah, the sons of Tobiah, and the sons of Nekoda, 652.
#### Ezra 2:61  Also, of the sons of the priests: the sons of Habaiah, the sons of Hakkoz, and the sons of Barzillai (who had taken a wife from the daughters of Barzillai the Gileadite, and was called by their name).
#### Ezra 2:62  These sought their registration among those enrolled in the genealogies, but they were not found there, and so they were excluded from the priesthood as unclean.
#### Ezra 2:63  The governor told them that they were not to partake of the most holy food, until there should be a priest to consult Urim and Thummim.
#### Ezra 2:64  The whole assembly together was 42,360,
#### Ezra 2:65  besides their male and female servants, of whom there were 7,337, and they had 200 male and female singers.
#### Ezra 2:66  Their horses were 736, their mules were 245,
#### Ezra 2:67  their camels were 435, and their donkeys were 6,720.
#### Ezra 2:68  Some of the heads of families, when they came to the house of the LORD that is in Jerusalem, made freewill offerings for the house of God, to erect it on its site.
#### Ezra 2:69  According to their ability they gave to the treasury of the work 61,000 darics of gold, 5,000 minas of silver, and 100 priests' garments.
#### Ezra 2:70  Now the priests, the Levites, some of the people, the singers, the gatekeepers, and the temple servants lived in their towns, and all the rest of Israel in their towns.
#### Ezra 3:1  When the seventh month came, and the children of Israel were in the towns, the people gathered as one man to Jerusalem.
#### Ezra 3:2  Then arose Jeshua the son of Jozadak, with his fellow priests, and Zerubbabel the son of Shealtiel with his kinsmen, and they built the altar of the God of Israel, to offer burnt offerings on it, as it is written in the Law of Moses the man of God.
#### Ezra 3:3  They set the altar in its place, for fear was on them because of the peoples of the lands, and they offered burnt offerings on it to the LORD, burnt offerings morning and evening.
#### Ezra 3:4  And they kept the Feast of Booths, as it is written, and offered the daily burnt offerings by number according to the rule, as each day required,
#### Ezra 3:5  and after that the regular burnt offerings, the offerings at the new moon and at all the appointed feasts of the LORD, and the offerings of everyone who made a freewill offering to the LORD.
#### Ezra 3:6  From the first day of the seventh month they began to offer burnt offerings to the LORD. But the foundation of the temple of the LORD was not yet laid.
#### Ezra 3:7  So they gave money to the masons and the carpenters, and food, drink, and oil to the Sidonians and the Tyrians to bring cedar trees from Lebanon to the sea, to Joppa, according to the grant that they had from Cyrus king of Persia.
#### Ezra 3:8  Now in the second year after their coming to the house of God at Jerusalem, in the second month, Zerubbabel the son of Shealtiel and Jeshua the son of Jozadak made a beginning, together with the rest of their kinsmen, the priests and the Levites and all who had come to Jerusalem from the captivity. They appointed the Levites, from twenty years old and upward, to supervise the work of the house of the LORD.
#### Ezra 3:9  And Jeshua with his sons and his brothers, and Kadmiel and his sons, the sons of Judah, together supervised the workmen in the house of God, along with the sons of Henadad and the Levites, their sons and brothers.
#### Ezra 3:10  And when the builders laid the foundation of the temple of the LORD, the priests in their vestments came forward with trumpets, and the Levites, the sons of Asaph, with cymbals, to praise the LORD, according to the directions of David king of Israel.
#### Ezra 3:11  And they sang responsively, praising and giving thanks to the LORD, “For he is good, for his steadfast love endures forever toward Israel.” And all the people shouted with a great shout when they praised the LORD, because the foundation of the house of the LORD was laid.
#### Ezra 3:12  But many of the priests and Levites and heads of fathers' houses, old men who had seen the first house, wept with a loud voice when they saw the foundation of this house being laid, though many shouted aloud for joy,
#### Ezra 3:13  so that the people could not distinguish the sound of the joyful shout from the sound of the people's weeping, for the people shouted with a great shout, and the sound was heard far away.
#### Ezra 4:1  Now when the adversaries of Judah and Benjamin heard that the returned exiles were building a temple to the LORD, the God of Israel,
#### Ezra 4:2  they approached Zerubbabel and the heads of fathers' houses and said to them, “Let us build with you, for we worship your God as you do, and we have been sacrificing to him ever since the days of Esarhaddon king of Assyria who brought us here.”
#### Ezra 4:3  But Zerubbabel, Jeshua, and the rest of the heads of fathers' houses in Israel said to them, “You have nothing to do with us in building a house to our God; but we alone will build to the LORD, the God of Israel, as King Cyrus the king of Persia has commanded us.”
#### Ezra 4:4  Then the people of the land discouraged the people of Judah and made them afraid to build
#### Ezra 4:5  and bribed counselors against them to frustrate their purpose, all the days of Cyrus king of Persia, even until the reign of Darius king of Persia.
#### Ezra 4:6  And in the reign of Ahasuerus, in the beginning of his reign, they wrote an accusation against the inhabitants of Judah and Jerusalem.
#### Ezra 4:7  In the days of Artaxerxes, Bishlam and Mithredath and Tabeel and the rest of their associates wrote to Artaxerxes king of Persia. The letter was written in Aramaic and translated.
#### Ezra 4:8  Rehum the commander and Shimshai the scribe wrote a letter against Jerusalem to Artaxerxes the king as follows:
#### Ezra 4:9  Rehum the commander, Shimshai the scribe, and the rest of their associates, the judges, the governors, the officials, the Persians, the men of Erech, the Babylonians, the men of Susa, that is, the Elamites,
#### Ezra 4:10  and the rest of the nations whom the great and noble Osnappar deported and settled in the cities of Samaria and in the rest of the province Beyond the River.
#### Ezra 4:11  (This is a copy of the letter that they sent.) “To Artaxerxes the king: Your servants, the men of the province Beyond the River, send greeting. And now
#### Ezra 4:12  be it known to the king that the Jews who came up from you to us have gone to Jerusalem. They are rebuilding that rebellious and wicked city. They are finishing the walls and repairing the foundations.
#### Ezra 4:13  Now be it known to the king that if this city is rebuilt and the walls finished, they will not pay tribute, custom, or toll, and the royal revenue will be impaired.
#### Ezra 4:14  Now because we eat the salt of the palace and it is not fitting for us to witness the king's dishonor, therefore we send and inform the king,
#### Ezra 4:15  in order that search may be made in the book of the records of your fathers. You will find in the book of the records and learn that this city is a rebellious city, hurtful to kings and provinces, and that sedition was stirred up in it from of old. That was why this city was laid waste.
#### Ezra 4:16  We make known to the king that if this city is rebuilt and its walls finished, you will then have no possession in the province Beyond the River.”
#### Ezra 4:17  The king sent an answer: “To Rehum the commander and Shimshai the scribe and the rest of their associates who live in Samaria and in the rest of the province Beyond the River, greeting. And now
#### Ezra 4:18  the letter that you sent to us has been plainly read before me.
#### Ezra 4:19  And I made a decree, and search has been made, and it has been found that this city from of old has risen against kings, and that rebellion and sedition have been made in it.
#### Ezra 4:20  And mighty kings have been over Jerusalem, who ruled over the whole province Beyond the River, to whom tribute, custom, and toll were paid.
#### Ezra 4:21  Therefore make a decree that these men be made to cease, and that this city be not rebuilt, until a decree is made by me.
#### Ezra 4:22  And take care not to be slack in this matter. Why should damage grow to the hurt of the king?”
#### Ezra 4:23  Then, when the copy of King Artaxerxes' letter was read before Rehum and Shimshai the scribe and their associates, they went in haste to the Jews at Jerusalem and by force and power made them cease.
#### Ezra 4:24  Then the work on the house of God that is in Jerusalem stopped, and it ceased until the second year of the reign of Darius king of Persia.
#### Ezra 5:1  Now the prophets, Haggai and Zechariah the son of Iddo, prophesied to the Jews who were in Judah and Jerusalem, in the name of the God of Israel who was over them.
#### Ezra 5:2  Then Zerubbabel the son of Shealtiel and Jeshua the son of Jozadak arose and began to rebuild the house of God that is in Jerusalem, and the prophets of God were with them, supporting them.
#### Ezra 5:3  At the same time Tattenai the governor of the province Beyond the River and Shethar-bozenai and their associates came to them and spoke to them thus: “Who gave you a decree to build this house and to finish this structure?”
#### Ezra 5:4  They also asked them this: “What are the names of the men who are building this building?”
#### Ezra 5:5  But the eye of their God was on the elders of the Jews, and they did not stop them until the report should reach Darius and then an answer be returned by letter concerning it.
#### Ezra 5:6  This is a copy of the letter that Tattenai the governor of the province Beyond the River and Shethar-bozenai and his associates, the governors who were in the province Beyond the River, sent to Darius the king.
#### Ezra 5:7  They sent him a report, in which was written as follows: “To Darius the king, all peace.
#### Ezra 5:8  Be it known to the king that we went to the province of Judah, to the house of the great God. It is being built with huge stones, and timber is laid in the walls. This work goes on diligently and prospers in their hands.
#### Ezra 5:9  Then we asked those elders and spoke to them thus: ‘Who gave you a decree to build this house and to finish this structure?’
#### Ezra 5:10  We also asked them their names, for your information, that we might write down the names of their leaders.
#### Ezra 5:11  And this was their reply to us: ‘We are the servants of the God of heaven and earth, and we are rebuilding the house that was built many years ago, which a great king of Israel built and finished.
#### Ezra 5:12  But because our fathers had angered the God of heaven, he gave them into the hand of Nebuchadnezzar king of Babylon, the Chaldean, who destroyed this house and carried away the people to Babylonia.
#### Ezra 5:13  However, in the first year of Cyrus king of Babylon, Cyrus the king made a decree that this house of God should be rebuilt.
#### Ezra 5:14  And the gold and silver vessels of the house of God, which Nebuchadnezzar had taken out of the temple that was in Jerusalem and brought into the temple of Babylon, these Cyrus the king took out of the temple of Babylon, and they were delivered to one whose name was Sheshbazzar, whom he had made governor;
#### Ezra 5:15  and he said to him, “Take these vessels, go and put them in the temple that is in Jerusalem, and let the house of God be rebuilt on its site.”
#### Ezra 5:16  Then this Sheshbazzar came and laid the foundations of the house of God that is in Jerusalem, and from that time until now it has been in building, and it is not yet finished.’
#### Ezra 5:17  Therefore, if it seems good to the king, let search be made in the royal archives there in Babylon, to see whether a decree was issued by Cyrus the king for the rebuilding of this house of God in Jerusalem. And let the king send us his pleasure in this matter.”
#### Ezra 6:1  Then Darius the king made a decree, and search was made in Babylonia, in the house of the archives where the documents were stored.
#### Ezra 6:2  And in Ecbatana, the citadel that is in the province of Media, a scroll was found on which this was written: “A record.
#### Ezra 6:3  In the first year of Cyrus the king, Cyrus the king issued a decree: Concerning the house of God at Jerusalem, let the house be rebuilt, the place where sacrifices were offered, and let its foundations be retained. Its height shall be sixty cubits and its breadth sixty cubits,
#### Ezra 6:4  with three layers of great stones and one layer of timber. Let the cost be paid from the royal treasury.
#### Ezra 6:5  And also let the gold and silver vessels of the house of God, which Nebuchadnezzar took out of the temple that is in Jerusalem and brought to Babylon, be restored and brought back to the temple that is in Jerusalem, each to its place. You shall put them in the house of God.”
#### Ezra 6:6  “Now therefore, Tattenai, governor of the province Beyond the River, Shethar-bozenai, and your associates the governors who are in the province Beyond the River, keep away.
#### Ezra 6:7  Let the work on this house of God alone. Let the governor of the Jews and the elders of the Jews rebuild this house of God on its site.
#### Ezra 6:8  Moreover, I make a decree regarding what you shall do for these elders of the Jews for the rebuilding of this house of God. The cost is to be paid to these men in full and without delay from the royal revenue, the tribute of the province from Beyond the River.
#### Ezra 6:9  And whatever is needed—bulls, rams, or sheep for burnt offerings to the God of heaven, wheat, salt, wine, or oil, as the priests at Jerusalem require—let that be given to them day by day without fail,
#### Ezra 6:10  that they may offer pleasing sacrifices to the God of heaven and pray for the life of the king and his sons.
#### Ezra 6:11  Also I make a decree that if anyone alters this edict, a beam shall be pulled out of his house, and he shall be impaled on it, and his house shall be made a dunghill.
#### Ezra 6:12  May the God who has caused his name to dwell there overthrow any king or people who shall put out a hand to alter this, or to destroy this house of God that is in Jerusalem. I Darius make a decree; let it be done with all diligence.”
#### Ezra 6:13  Then, according to the word sent by Darius the king, Tattenai, the governor of the province Beyond the River, Shethar-bozenai, and their associates did with all diligence what Darius the king had ordered.
#### Ezra 6:14  And the elders of the Jews built and prospered through the prophesying of Haggai the prophet and Zechariah the son of Iddo. They finished their building by decree of the God of Israel and by decree of Cyrus and Darius and Artaxerxes king of Persia;
#### Ezra 6:15  and this house was finished on the third day of the month of Adar, in the sixth year of the reign of Darius the king.
#### Ezra 6:16  And the people of Israel, the priests and the Levites, and the rest of the returned exiles, celebrated the dedication of this house of God with joy.
#### Ezra 6:17  They offered at the dedication of this house of God 100 bulls, 200 rams, 400 lambs, and as a sin offering for all Israel 12 male goats, according to the number of the tribes of Israel.
#### Ezra 6:18  And they set the priests in their divisions and the Levites in their divisions, for the service of God at Jerusalem, as it is written in the Book of Moses.
#### Ezra 6:19  On the fourteenth day of the first month, the returned exiles kept the Passover.
#### Ezra 6:20  For the priests and the Levites had purified themselves together; all of them were clean. So they slaughtered the Passover lamb for all the returned exiles, for their fellow priests, and for themselves.
#### Ezra 6:21  It was eaten by the people of Israel who had returned from exile, and also by every one who had joined them and separated himself from the uncleanness of the peoples of the land to worship the LORD, the God of Israel.
#### Ezra 6:22  And they kept the Feast of Unleavened Bread seven days with joy, for the LORD had made them joyful and had turned the heart of the king of Assyria to them, so that he aided them in the work of the house of God, the God of Israel.
#### Ezra 7:1  Now after this, in the reign of Artaxerxes king of Persia, Ezra the son of Seraiah, son of Azariah, son of Hilkiah,
#### Ezra 7:2  son of Shallum, son of Zadok, son of Ahitub,
#### Ezra 7:3  son of Amariah, son of Azariah, son of Meraioth,
#### Ezra 7:4  son of Zerahiah, son of Uzzi, son of Bukki,
#### Ezra 7:5  son of Abishua, son of Phinehas, son of Eleazar, son of Aaron the chief priest—
#### Ezra 7:6  this Ezra went up from Babylonia. He was a scribe skilled in the Law of Moses that the LORD, the God of Israel, had given, and the king granted him all that he asked, for the hand of the LORD his God was on him.
#### Ezra 7:7  And there went up also to Jerusalem, in the seventh year of Artaxerxes the king, some of the people of Israel, and some of the priests and Levites, the singers and gatekeepers, and the temple servants.
#### Ezra 7:8  And Ezra came to Jerusalem in the fifth month, which was in the seventh year of the king.
#### Ezra 7:9  For on the first day of the first month he began to go up from Babylonia, and on the first day of the fifth month he came to Jerusalem, for the good hand of his God was on him.
#### Ezra 7:10  For Ezra had set his heart to study the Law of the LORD, and to do it and to teach his statutes and rules in Israel.
#### Ezra 7:11  This is a copy of the letter that King Artaxerxes gave to Ezra the priest, the scribe, a man learned in matters of the commandments of the LORD and his statutes for Israel:
#### Ezra 7:12  “Artaxerxes, king of kings, to Ezra the priest, the scribe of the Law of the God of heaven. Peace. And now
#### Ezra 7:13  I make a decree that anyone of the people of Israel or their priests or Levites in my kingdom, who freely offers to go to Jerusalem, may go with you.
#### Ezra 7:14  For you are sent by the king and his seven counselors to make inquiries about Judah and Jerusalem according to the Law of your God, which is in your hand,
#### Ezra 7:15  and also to carry the silver and gold that the king and his counselors have freely offered to the God of Israel, whose dwelling is in Jerusalem,
#### Ezra 7:16  with all the silver and gold that you shall find in the whole province of Babylonia, and with the freewill offerings of the people and the priests, vowed willingly for the house of their God that is in Jerusalem.
#### Ezra 7:17  With this money, then, you shall with all diligence buy bulls, rams, and lambs, with their grain offerings and their drink offerings, and you shall offer them on the altar of the house of your God that is in Jerusalem.
#### Ezra 7:18  Whatever seems good to you and your brothers to do with the rest of the silver and gold, you may do, according to the will of your God.
#### Ezra 7:19  The vessels that have been given you for the service of the house of your God, you shall deliver before the God of Jerusalem.
#### Ezra 7:20  And whatever else is required for the house of your God, which it falls to you to provide, you may provide it out of the king's treasury.
#### Ezra 7:21  “And I, Artaxerxes the king, make a decree to all the treasurers in the province Beyond the River: Whatever Ezra the priest, the scribe of the Law of the God of heaven, requires of you, let it be done with all diligence,
#### Ezra 7:22  up to 100 talents of silver, 100 cors of wheat, 100 baths of wine, 100 baths of oil, and salt without prescribing how much.
#### Ezra 7:23  Whatever is decreed by the God of heaven, let it be done in full for the house of the God of heaven, lest his wrath be against the realm of the king and his sons.
#### Ezra 7:24  We also notify you that it shall not be lawful to impose tribute, custom, or toll on anyone of the priests, the Levites, the singers, the doorkeepers, the temple servants, or other servants of this house of God.
#### Ezra 7:25  “And you, Ezra, according to the wisdom of your God that is in your hand, appoint magistrates and judges who may judge all the people in the province Beyond the River, all such as know the laws of your God. And those who do not know them, you shall teach.
#### Ezra 7:26  Whoever will not obey the law of your God and the law of the king, let judgment be strictly executed on him, whether for death or for banishment or for confiscation of his goods or for imprisonment.”
#### Ezra 7:27  Blessed be the LORD, the God of our fathers, who put such a thing as this into the heart of the king, to beautify the house of the LORD that is in Jerusalem,
#### Ezra 7:28  and who extended to me his steadfast love before the king and his counselors, and before all the king's mighty officers. I took courage, for the hand of the LORD my God was on me, and I gathered leading men from Israel to go up with me.
#### Ezra 8:1  These are the heads of their fathers' houses, and this is the genealogy of those who went up with me from Babylonia, in the reign of Artaxerxes the king:
#### Ezra 8:2  Of the sons of Phinehas, Gershom. Of the sons of Ithamar, Daniel. Of the sons of David, Hattush.
#### Ezra 8:3  Of the sons of Shecaniah, who was of the sons of Parosh, Zechariah, with whom were registered 150 men.
#### Ezra 8:4  Of the sons of Pahath-moab, Eliehoenai the son of Zerahiah, and with him 200 men.
#### Ezra 8:5  Of the sons of Zattu, Shecaniah the son of Jahaziel, and with him 300 men.
#### Ezra 8:6  Of the sons of Adin, Ebed the son of Jonathan, and with him 50 men.
#### Ezra 8:7  Of the sons of Elam, Jeshaiah the son of Athaliah, and with him 70 men.
#### Ezra 8:8  Of the sons of Shephatiah, Zebadiah the son of Michael, and with him 80 men.
#### Ezra 8:9  Of the sons of Joab, Obadiah the son of Jehiel, and with him 218 men.
#### Ezra 8:10  Of the sons of Bani, Shelomith the son of Josiphiah, and with him 160 men.
#### Ezra 8:11  Of the sons of Bebai, Zechariah, the son of Bebai, and with him 28 men.
#### Ezra 8:12  Of the sons of Azgad, Johanan the son of Hakkatan, and with him 110 men.
#### Ezra 8:13  Of the sons of Adonikam, those who came later, their names being Eliphelet, Jeuel, and Shemaiah, and with them 60 men.
#### Ezra 8:14  Of the sons of Bigvai, Uthai and Zaccur, and with them 70 men.
#### Ezra 8:15  I gathered them to the river that runs to Ahava, and there we camped three days. As I reviewed the people and the priests, I found there none of the sons of Levi.
#### Ezra 8:16  Then I sent for Eliezer, Ariel, Shemaiah, Elnathan, Jarib, Elnathan, Nathan, Zechariah, and Meshullam, leading men, and for Joiarib and Elnathan, who were men of insight,
#### Ezra 8:17  and sent them to Iddo, the leading man at the place Casiphia, telling them what to say to Iddo and his brothers and the temple servants at the place Casiphia, namely, to send us ministers for the house of our God.
#### Ezra 8:18  And by the good hand of our God on us, they brought us a man of discretion, of the sons of Mahli the son of Levi, son of Israel, namely Sherebiah with his sons and kinsmen, 18;
#### Ezra 8:19  also Hashabiah, and with him Jeshaiah of the sons of Merari, with his kinsmen and their sons, 20;
#### Ezra 8:20  besides 220 of the temple servants, whom David and his officials had set apart to attend the Levites. These were all mentioned by name.
#### Ezra 8:21  Then I proclaimed a fast there, at the river Ahava, that we might humble ourselves before our God, to seek from him a safe journey for ourselves, our children, and all our goods.
#### Ezra 8:22  For I was ashamed to ask the king for a band of soldiers and horsemen to protect us against the enemy on our way, since we had told the king, “The hand of our God is for good on all who seek him, and the power of his wrath is against all who forsake him.”
#### Ezra 8:23  So we fasted and implored our God for this, and he listened to our entreaty.
#### Ezra 8:24  Then I set apart twelve of the leading priests: Sherebiah, Hashabiah, and ten of their kinsmen with them.
#### Ezra 8:25  And I weighed out to them the silver and the gold and the vessels, the offering for the house of our God that the king and his counselors and his lords and all Israel there present had offered.
#### Ezra 8:26  I weighed out into their hand 650 talents of silver, and silver vessels worth 200 talents, and 100 talents of gold,
#### Ezra 8:27  20 bowls of gold worth 1,000 darics, and two vessels of fine bright bronze as precious as gold.
#### Ezra 8:28  And I said to them, “You are holy to the LORD, and the vessels are holy, and the silver and the gold are a freewill offering to the LORD, the God of your fathers.
#### Ezra 8:29  Guard them and keep them until you weigh them before the chief priests and the Levites and the heads of fathers' houses in Israel at Jerusalem, within the chambers of the house of the LORD.”
#### Ezra 8:30  So the priests and the Levites took over the weight of the silver and the gold and the vessels, to bring them to Jerusalem, to the house of our God.
#### Ezra 8:31  Then we departed from the river Ahava on the twelfth day of the first month, to go to Jerusalem. The hand of our God was on us, and he delivered us from the hand of the enemy and from ambushes by the way.
#### Ezra 8:32  We came to Jerusalem, and there we remained three days.
#### Ezra 8:33  On the fourth day, within the house of our God, the silver and the gold and the vessels were weighed into the hands of Meremoth the priest, son of Uriah, and with him was Eleazar the son of Phinehas, and with them were the Levites, Jozabad the son of Jeshua and Noadiah the son of Binnui.
#### Ezra 8:34  The whole was counted and weighed, and the weight of everything was recorded.
#### Ezra 8:35  At that time those who had come from captivity, the returned exiles, offered burnt offerings to the God of Israel, twelve bulls for all Israel, ninety-six rams, seventy-seven lambs, and as a sin offering twelve male goats. All this was a burnt offering to the LORD.
#### Ezra 8:36  They also delivered the king's commissions to the king's satraps and to the governors of the province Beyond the River, and they aided the people and the house of God.
#### Ezra 9:1  After these things had been done, the officials approached me and said, “The people of Israel and the priests and the Levites have not separated themselves from the peoples of the lands with their abominations, from the Canaanites, the Hittites, the Perizzites, the Jebusites, the Ammonites, the Moabites, the Egyptians, and the Amorites.
#### Ezra 9:2  For they have taken some of their daughters to be wives for themselves and for their sons, so that the holy race has mixed itself with the peoples of the lands. And in this faithlessness the hand of the officials and chief men has been foremost.”
#### Ezra 9:3  As soon as I heard this, I tore my garment and my cloak and pulled hair from my head and beard and sat appalled.
#### Ezra 9:4  Then all who trembled at the words of the God of Israel, because of the faithlessness of the returned exiles, gathered around me while I sat appalled until the evening sacrifice.
#### Ezra 9:5  And at the evening sacrifice I rose from my fasting, with my garment and my cloak torn, and fell upon my knees and spread out my hands to the LORD my God,
#### Ezra 9:6  saying: “O my God, I am ashamed and blush to lift my face to you, my God, for our iniquities have risen higher than our heads, and our guilt has mounted up to the heavens.
#### Ezra 9:7  From the days of our fathers to this day we have been in great guilt. And for our iniquities we, our kings, and our priests have been given into the hand of the kings of the lands, to the sword, to captivity, to plundering, and to utter shame, as it is today.
#### Ezra 9:8  But now for a brief moment favor has been shown by the LORD our God, to leave us a remnant and to give us a secure hold within his holy place, that our God may brighten our eyes and grant us a little reviving in our slavery.
#### Ezra 9:9  For we are slaves. Yet our God has not forsaken us in our slavery, but has extended to us his steadfast love before the kings of Persia, to grant us some reviving to set up the house of our God, to repair its ruins, and to give us protection in Judea and Jerusalem.
#### Ezra 9:10  “And now, O our God, what shall we say after this? For we have forsaken your commandments,
#### Ezra 9:11  which you commanded by your servants the prophets, saying, ‘The land that you are entering, to take possession of it, is a land impure with the impurity of the peoples of the lands, with their abominations that have filled it from end to end with their uncleanness.
#### Ezra 9:12  Therefore do not give your daughters to their sons, neither take their daughters for your sons, and never seek their peace or prosperity, that you may be strong and eat the good of the land and leave it for an inheritance to your children forever.’
#### Ezra 9:13  And after all that has come upon us for our evil deeds and for our great guilt, seeing that you, our God, have punished us less than our iniquities deserved and have given us such a remnant as this,
#### Ezra 9:14  shall we break your commandments again and intermarry with the peoples who practice these abominations? Would you not be angry with us until you consumed us, so that there should be no remnant, nor any to escape?
#### Ezra 9:15  O LORD, the God of Israel, you are just, for we are left a remnant that has escaped, as it is today. Behold, we are before you in our guilt, for none can stand before you because of this.”
#### Ezra 10:1  While Ezra prayed and made confession, weeping and casting himself down before the house of God, a very great assembly of men, women, and children, gathered to him out of Israel, for the people wept bitterly.
#### Ezra 10:2  And Shecaniah the son of Jehiel, of the sons of Elam, addressed Ezra: “We have broken faith with our God and have married foreign women from the peoples of the land, but even now there is hope for Israel in spite of this.
#### Ezra 10:3  Therefore let us make a covenant with our God to put away all these wives and their children, according to the counsel of my lord and of those who tremble at the commandment of our God, and let it be done according to the Law.
#### Ezra 10:4  Arise, for it is your task, and we are with you; be strong and do it.”
#### Ezra 10:5  Then Ezra arose and made the leading priests and Levites and all Israel take an oath that they would do as had been said. So they took the oath.
#### Ezra 10:6  Then Ezra withdrew from before the house of God and went to the chamber of Jehohanan the son of Eliashib, where he spent the night, neither eating bread nor drinking water, for he was mourning over the faithlessness of the exiles.
#### Ezra 10:7  And a proclamation was made throughout Judah and Jerusalem to all the returned exiles that they should assemble at Jerusalem,
#### Ezra 10:8  and that if anyone did not come within three days, by order of the officials and the elders all his property should be forfeited, and he himself banned from the congregation of the exiles.
#### Ezra 10:9  Then all the men of Judah and Benjamin assembled at Jerusalem within the three days. It was the ninth month, on the twentieth day of the month. And all the people sat in the open square before the house of God, trembling because of this matter and because of the heavy rain.
#### Ezra 10:10  And Ezra the priest stood up and said to them, “You have broken faith and married foreign women, and so increased the guilt of Israel.
#### Ezra 10:11  Now then make confession to the LORD, the God of your fathers and do his will. Separate yourselves from the peoples of the land and from the foreign wives.”
#### Ezra 10:12  Then all the assembly answered with a loud voice, “It is so; we must do as you have said.
#### Ezra 10:13  But the people are many, and it is a time of heavy rain; we cannot stand in the open. Nor is this a task for one day or for two, for we have greatly transgressed in this matter.
#### Ezra 10:14  Let our officials stand for the whole assembly. Let all in our cities who have taken foreign wives come at appointed times, and with them the elders and judges of every city, until the fierce wrath of our God over this matter is turned away from us.”
#### Ezra 10:15  Only Jonathan the son of Asahel and Jahzeiah the son of Tikvah opposed this, and Meshullam and Shabbethai the Levite supported them.
#### Ezra 10:16  Then the returned exiles did so. Ezra the priest selected men, heads of fathers' houses, according to their fathers' houses, each of them designated by name. On the first day of the tenth month they sat down to examine the matter;
#### Ezra 10:17  and by the first day of the first month they had come to the end of all the men who had married foreign women.
#### Ezra 10:18  Now there were found some of the sons of the priests who had married foreign women: Maaseiah, Eliezer, Jarib, and Gedaliah, some of the sons of Jeshua the son of Jozadak and his brothers.
#### Ezra 10:19  They pledged themselves to put away their wives, and their guilt offering was a ram of the flock for their guilt.
#### Ezra 10:20  Of the sons of Immer: Hanani and Zebadiah.
#### Ezra 10:21  Of the sons of Harim: Maaseiah, Elijah, Shemaiah, Jehiel, and Uzziah.
#### Ezra 10:22  Of the sons of Pashhur: Elioenai, Maaseiah, Ishmael, Nethanel, Jozabad, and Elasah.
#### Ezra 10:23  Of the Levites: Jozabad, Shimei, Kelaiah (that is, Kelita), Pethahiah, Judah, and Eliezer.
#### Ezra 10:24  Of the singers: Eliashib. Of the gatekeepers: Shallum, Telem, and Uri.
#### Ezra 10:25  And of Israel: of the sons of Parosh: Ramiah, Izziah, Malchijah, Mijamin, Eleazar, Hashabiah, and Benaiah.
#### Ezra 10:26  Of the sons of Elam: Mattaniah, Zechariah, Jehiel, Abdi, Jeremoth, and Elijah.
#### Ezra 10:27  Of the sons of Zattu: Elioenai, Eliashib, Mattaniah, Jeremoth, Zabad, and Aziza.
#### Ezra 10:28  Of the sons of Bebai were Jehohanan, Hananiah, Zabbai, and Athlai.
#### Ezra 10:29  Of the sons of Bani were Meshullam, Malluch, Adaiah, Jashub, Sheal, and Jeremoth.
#### Ezra 10:30  Of the sons of Pahath-moab: Adna, Chelal, Benaiah, Maaseiah, Mattaniah, Bezalel, Binnui, and Manasseh.
#### Ezra 10:31  Of the sons of Harim: Eliezer, Isshijah, Malchijah, Shemaiah, Shimeon,
#### Ezra 10:32  Benjamin, Malluch, and Shemariah.
#### Ezra 10:33  Of the sons of Hashum: Mattenai, Mattattah, Zabad, Eliphelet, Jeremai, Manasseh, and Shimei.
#### Ezra 10:34  Of the sons of Bani: Maadai, Amram, Uel,
#### Ezra 10:35  Benaiah, Bedeiah, Cheluhi,
#### Ezra 10:36  Vaniah, Meremoth, Eliashib,
#### Ezra 10:37  Mattaniah, Mattenai, Jaasu.
#### Ezra 10:38  Of the sons of Binnui: Shimei,
#### Ezra 10:39  Shelemiah, Nathan, Adaiah,
#### Ezra 10:40  Machnadebai, Shashai, Sharai,
#### Ezra 10:41  Azarel, Shelemiah, Shemariah,
#### Ezra 10:42  Shallum, Amariah, and Joseph.
#### Ezra 10:43  Of the sons of Nebo: Jeiel, Mattithiah, Zabad, Zebina, Jaddai, Joel, and Benaiah.
#### Ezra 10:44  All these had married foreign women, and some of the women had even borne children.
