#### Numbers 1:1 And the LORD spoke to Moses in the wilderness of Sinai, in the tent of the testimony, on day one of the {month second year of the second} of their coming forth from out of the land of Egypt, saying, 

#### Numbers 1:2 Take the sum of all the congregation of the sons of Israel according to their kin, and houses of their patrimony, according to the number of their names; every male according to their head count. 

#### Numbers 1:3 From twenty years and up, all going forth in the force of Israel, you number them with their force -- you and Aaron! 

#### Numbers 1:4 And with you there will be each one {according to the tribe of each of the rulers}, {according to the houses of their patrimony they shall be}. 

#### Numbers 1:5 And these are the names of the men who shall stand with you of the ones of Reuben -- Elizur son of Shedeur. 

#### Numbers 1:6 Of the ones of Simeon- Shelumiel son of Zurishaddai. 

#### Numbers 1:7 Of the ones of Judah -- Nashon son of Amminadab. 

#### Numbers 1:8 Of the ones of Issachar -- Nethaneel son of Zuar. 

#### Numbers 1:9 The ones of Zebulun -- Eliab son of Helon. 

#### Numbers 1:10 Of the sons of Joseph, of the ones of Ephraim -- Elishama son of Ammihud. Of the ones of Manasseh -- Gamaliel son of Pedahzur. 

#### Numbers 1:11 Of the ones of Benjamin -- Abidan son of Gideoni. 

#### Numbers 1:12 Of the ones of Dan -- Ahiezer son of Ammishaddai. 

#### Numbers 1:13 Of the ones of Asher -- Pagiel son of Ocran. 

#### Numbers 1:14 Of the ones of Gad -- Eliasaph son of Reuel. 

#### Numbers 1:15 Of the ones of Naphtali -- Ahira son of Enan. 

#### Numbers 1:16 These are the selected ones of the congregation, rulers of the tribes according to their patrimony; {commanders of thousands in Israel they are}. 

#### Numbers 1:17 And {took Moses and Aaron} these men, of the ones being called by name. 

#### Numbers 1:18 And all the congregation gathered on day one of the month, of the second year. and they were numbered according to their origins, according to their patrimony, according to the number of their names from twenty years old and up, every male according to their head count. 

#### Numbers 1:19 In which manner the LORD gave orders to Moses, and they were numbered in the wilderness of Sinai. 

#### Numbers 1:20 And there were to the sons of Reuben, first-born of Israel, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, according to their head count, every male from twenty years and up, every one going forth in the force, 

#### Numbers 1:21 the numbering of them from out of the tribe of Reuben -- six and forty thousand and five hundred. 

#### Numbers 1:22 To the sons of Simeon, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, according to their head count, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:23 their numbering from the tribe of Simeon -- nine and fifty thousand and three hundred. 

#### Numbers 1:24 To the sons of Gad, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:25 their numbering from out of the tribe of Gad -- five and forty thousand and six hundred and fifty. 

#### Numbers 1:26 To the sons of Judah, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:27 their numbering from the tribe of Judah -- four and seventy thousand and six hundred. 

#### Numbers 1:28 To the sons of Issachar, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:29 their numbering from the tribe of Issachar -- four and fifty thousand and four hundred. 

#### Numbers 1:30 To the sons of Zebulun, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:31 their numbering from the tribe of Zebulun -- seven and fifty thousand and four hundred. 

#### Numbers 1:32 To the sons of Joseph, the sons of Ephraim, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:33 their numbering from the tribe of Ephraim -- forty thousand and five hundred. 

#### Numbers 1:34 To the sons of Manasseh, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:35 their numbering from the tribe of Manasseh -- two and thirty thousand and five hundred. 

#### Numbers 1:36 To the sons of Benjamin, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:37 their numbering from the tribe of Benjamin -- five and thirty thousand and four hundred. 

#### Numbers 1:38 To the sons of Dan, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:39 their numbering from the tribe of Dan -- two and sixty thousand and seven hundred. 

#### Numbers 1:40 To the sons of Asher, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:41 their numbering from the tribe of Asher -- one and forty thousand and five hundred. 

#### Numbers 1:42 To the sons of Naphtali, according to their kin, according to their peoples, according to the houses of their patrimony, according to the number of their names, all males from twenty years and up, every one going forth in the force, 

#### Numbers 1:43 their numbering from the tribe of Naphtali -- three and fifty thousand and four hundred. 

#### Numbers 1:44 This is the numbering which Moses numbered, and Aaron, and the rulers of Israel -- twelve men, {man one} according to tribe; {one according to tribe of the houses of their patrimony there was}. 

#### Numbers 1:45 And came to pass all the numbering of the sons of Israel with their force, from twenty years and up, all the ones going forth to deploy in Israel -- 

#### Numbers 1:46 six hundred thousand and three thousand and five hundred and fifty. 

#### Numbers 1:47 But the Levites from the tribes of their patrimony were not considered together among the sons of Israel. 

#### Numbers 1:48 And the LORD spoke to Moses, saying, 

#### Numbers 1:49 Know that! {the tribe of Levi you shall not consider}, and their number you shall not take in the midst of the sons of Israel. 

#### Numbers 1:50 And you set the Levites over the tent of the testimony, and over all the items of it, and over all as much as is in it! They shall lift the tent, and all the items for it. And they shall officiate in it, and {round about the tent they shall camp}. 

#### Numbers 1:51 And in the lifting away the tent, {shall lower it the Levites}. And in the pitching the tent, they shall raise it up. And the foreigner going in it, let him die! 

#### Numbers 1:52 And {shall camp the sons of Israel}, every man in his own order, and every man according to his own governing authority, with their force. 

#### Numbers 1:53 But the Levites -- let them camp opposite round about the tent of the testimony, and there shall not be sin among the sons of Israel. And {shall guard the Levites themselves} the watch of the tent of the testimony. 

#### Numbers 1:54 And {did the sons of Israel} according to all as much as the LORD gave charge to Moses and Aaron -- thus they did. 

#### Numbers 2:1 And the LORD spoke to Moses and Aaron, saying, 

#### Numbers 2:2 Each man having according to his order, according to the signals, according to the houses of their patrimony, let {camp the sons of Israel} opposite -- round about the tent of the testimony {shall camp the sons of Israel}. 

#### Numbers 2:3 And the ones camping first according to the east, in order, was the camp of Judah with their force. And the ruler of the sons of Judah was Nashon son of Amminadab. 

#### Numbers 2:4 Of his force the ones being numbered -- four and seventy thousand and six hundred. 

#### Numbers 2:5 And the ones camping being next was the tribe of Issachar. And the ruler of the sons of Issachar was Nethaneel son of Zuar. 

#### Numbers 2:6 Of his force being numbered -- four and fifty thousand and four hundred. 

#### Numbers 2:7 And the ones camping being next to him was the tribe of Zebulun. And the ruler of the sons of Zebulun was Eliab son of Helon. 

#### Numbers 2:8 Of his force being numbered -- seven and fifty thousand and four hundred. 

#### Numbers 2:9 All the ones being numbering from the camp of Judah were a hundred eighty thousand and six thousand and four hundred; with their force first they shall lift away. 

#### Numbers 2:10 The order of the camp of Reuben towards the south with their forces, and the ruler of the sons of Reuben was Elizur son of Shedeur. 

#### Numbers 2:11 Of his forces being numbered -- six and forty thousand and five hundred. 

#### Numbers 2:12 And the ones camping being next to him was the tribe of Simeon. And the ruler of the sons of Simeon was Shelumiel son of Zurishaddai. 

#### Numbers 2:13 Of his force being numbered -- nine and fifty thousand and three hundred. 

#### Numbers 2:14 And the ones camping being next to him was the tribe of Gad. And the ruler of the sons of Gad was Eliasaph son of Reuel. 

#### Numbers 2:15 And of his force being numbered -- five and forty thousand and six hundred and fifty. 

#### Numbers 2:16 All the ones being numbered of the camp of Reuben were a hundred and fifty and one thousand and four hundred and fifty, with their force. And {second they shall lift away}. 

#### Numbers 2:17 And {shall lift away the tent of the testimony} and the camp of the Levites between the camps; as they pitched so also they shall lift away, each next according to their governing. 

#### Numbers 2:18 The order of the camp of Ephraim towards the west, with their force. And the ruler of the sons of Ephraim was Elishama son of Ammihud. 

#### Numbers 2:19 Of his force being numbered -- forty thousand and five hundred. 

#### Numbers 2:20 And the ones camping being next to him was the tribe of Manasseh. And the ruler of the sons of Manasseh was Gamaliel son of Pedahzur. 

#### Numbers 2:21 Of his force being numbered -- two and thirty thousand and two hundred. 

#### Numbers 2:22 And the ones camping being next to him was the tribe of Benjamin. And the ruler of the sons of Benjamin was Abidan son of Gideoni. 

#### Numbers 2:23 Of his force being numbered -- five and thirty thousand and four hundred. 

#### Numbers 2:24 All the ones being numbered of the camp of Ephraim -- a hundred thousand and eight thousand and a hundred; with their force {third they shall lift away}. 

#### Numbers 2:25 The order of the camp of Dan towards the north with their force, and the ruler of the sons of Dan was Ahiezer son of Ammishaddai. 

#### Numbers 2:26 Of his force being numbered -- two and sixty thousand and seven hundred. 

#### Numbers 2:27 And the ones camping being next to him was the tribe of Asher. And the ruler of the sons of Asher was Pagiel son of Ocran. 

#### Numbers 2:28 Of his force being numbered -- one and forty thousand and five hundred. 

#### Numbers 2:29 And the ones camping being next to him was the tribe of Naphtali. And the ruler of the sons of Naphtali was Ahira son of Enan. 

#### Numbers 2:30 Of his force being numbered -- three and fifty thousand and four hundred. 

#### Numbers 2:31 All the ones being numbered of the camp of Dan -- a hundred and fifty-seven thousand and six hundred; {last they shall lift away} according to their order. 

#### Numbers 2:32 This is the numbering of the sons of Israel according to the houses of their patrimony. All the numbering of the camps with their forces -- six hundred thousand and three thousand and five hundred and fifty. 

#### Numbers 2:33 But the Levites were not considered with the sons of Israel as the LORD gave charge to Moses. 

#### Numbers 2:34 And {did the sons of Israel} according to all what the LORD gave orders to Moses; thus they camped according to their order, and thus they lifted away each being next to the other according to their peoples, according to the houses of their patrimony. 

#### Numbers 3:1 And these are the origins of Aaron and Moses in which day the LORD spoke to Moses on mount Sinai. 

#### Numbers 3:2 And these are the names of the sons of Aaron -- first-born Nadab, and Abihu, Eleazar, and Ithamar. 

#### Numbers 3:3 These are the names of the sons of Aaron, the priests, the ones being anointed whom were perfected of their hands to officiate as priest. 

#### Numbers 3:4 And {came to an end Nadab and Abihu} before the LORD, of their offering {fire alien} before the LORD in the wilderness of Sinai, and {children there were no} to them. And {officiated as priest Eleazar and Ithamar} with Aaron their father. 

#### Numbers 3:5 And the LORD spoke to Moses, saying, 

#### Numbers 3:6 Take the tribe of Levi! And you shall set them before Aaron the priest, and they shall officiate to him, 

#### Numbers 3:7 and they shall guard his watches, and the watches of the sons of Israel before the tent of the testimony, to work the works of the tent. 

#### Numbers 3:8 And they shall guard all the items of the tent of the testimony, and the watches of the sons of Israel, according to all the works of the tent. 

#### Numbers 3:9 And you shall give the Levites to Aaron your brother, and to his sons to the priests for a gift being given; these to me are from the sons of Israel. 

#### Numbers 3:10 And Aaron and his sons you shall place over the tent of the testimony, and they shall guard their priesthood. And the foreigner touching shall die. 

#### Numbers 3:11 And the LORD spoke to Moses, saying, 

#### Numbers 3:12 And behold, I have taken the Levites from the midst of the sons of Israel, in place of every first-born male opening wide the womb of the sons of Israel; {their ransoms they shall be}, and {will be mine the Levites}. 

#### Numbers 3:13 {is mine For every first-born}. In which day I struck all the first-born in the land of Egypt, I sanctified to myself every first-born in Israel; from man unto beast they shall be mine. I am the LORD. 

#### Numbers 3:14 And the LORD spoke to Moses in the wilderness of Sinai, saying, 

#### Numbers 3:15 Number the sons of Levi according to the houses of their patrimony, according to their kin! Every male from a month and up you number them! 

#### Numbers 3:16 And {numbered them Moses and Aaron} because of the voice of the LORD in which manner {gave orders to them the LORD}. 

#### Numbers 3:17 And these were the sons of Levi by their names -- Gershon, Kohath, and Merari. 

#### Numbers 3:18 And these are the names of the sons of Gershon according to their peoples -- Libni and Shimei. 

#### Numbers 3:19 And the sons of Kohath according to their peoples -- Amram, and Izehar, Hebron, and Uzziel. 

#### Numbers 3:20 And the sons of Merari according to their peoples -- Mahli, and Mushi. These are the peoples of the Levites according to the houses of their patrimony. 

#### Numbers 3:21 To Gershon was the people of Libni, and the people of Shemei; these are the peoples of Gershon -- 

#### Numbers 3:22 their numbering according to the number of every male from a month and up in their numbering -- seven thousand and five hundred. 

#### Numbers 3:23 And the sons of Gershon {behind the tent shall camp} towards the west. 

#### Numbers 3:24 And the ruler of the household of the family of the people of Gershon was Elisaph son of Lael. 

#### Numbers 3:25 And the watch of the sons of Gershon was in the tent of the testimony -- the tent, and the covering, and the overcovering of the door of the tent of the testimony, 

#### Numbers 3:26 and the shrouds of the courtyard, and the veil of the gate of the courtyard, of the one being at the tent, and the remainder of all its works. 

#### Numbers 3:27 To Kohath was {division of people for Amram one}, and {division of people for Izehar one}, and {division of people for Hebron one}, and {division of people for Uzziel one}. These are the peoples of Kohath according to number. 

#### Numbers 3:28 Every male from a month and up -- eight thousand and six hundred, guarding the watches of the holy place. 

#### Numbers 3:29 The peoples of the sons of Kohath shall camp by the side of the tent towards the south. 

#### Numbers 3:30 And the ruler of the house of the patrimony of the peoples of Kohath was Elizaphan son of Uzziel. 

#### Numbers 3:31 And their watch is the ark, and the table, and the lamp-stand, and the altars, and the items of the holy place, as many as they officiate with them, and the overcovering, and all their works. 

#### Numbers 3:32 And the ruler, the one over the rulers of the Levites was Eleazar the son of Aaron the priest being placed, to guard the watches of the holy places. 

#### Numbers 3:33 To Merari was the people Mahli, and the people Mushi. These are the peoples of Merari. 

#### Numbers 3:34 Their numbering according to the number of every male, from a month and up -- six thousand and two hundred. 

#### Numbers 3:35 And the ruler of the house of the patrimony of the people of Merari was Zuriel son of Abihail. By the side of the tent they shall camp towards the north. 

#### Numbers 3:36 The numbering of the watch of the sons of Merari is the tips of the tent, and their bars, and their posts, and their bases, and all their items, and their works, 

#### Numbers 3:37 and the posts of the courtyard round about, and their bases, and their stanchions, and their ropes. 

#### Numbers 3:38 The ones camping according to the front of the tent of the testimony, from the east was Moses and Aaron and his sons, guarding the watches of the holy place, for the watches of the sons of Israel; and the foreigner approaching shall die. 

#### Numbers 3:39 All the numbering of the Levites, whom {numbered Moses and Aaron} through the voice of the LORD, according to their peoples, every male from a month and up -- two and twenty thousand. 

#### Numbers 3:40 And the LORD said to Moses, saying, Number every first-born male of the sons of Israel, from a month and up, and take their number by name! 

#### Numbers 3:41 And you shall take the Levites for me, I am the LORD, in place of all the first-born of the sons of Israel; and the cattle of the Levites in place of all the first-born among the cattle of the sons of Israel. 

#### Numbers 3:42 And Moses numbered in which manner the LORD gave charge to him -- every first-born among the sons of Israel. 

#### Numbers 3:43 And were all the first-born males, by number, and by name, from a month and up, from their numbering -- two and twenty thousand and three and seventy and two hundred. 

#### Numbers 3:44 And the LORD spoke to Moses, saying, 

#### Numbers 3:45 Take the Levites in place of all the first-born sons of Israel, and the cattle of the Levites in place of their cattle! And {will be mine the Levites}. I am the LORD. 

#### Numbers 3:46 And for the ransoms of three and seventy and two hundred -- the ones abounding over the Levites, from the first-born of the sons of Israel, 

#### Numbers 3:47 you shall take five shekels per head; according to the double-drachma of the holy place you shall take them; twenty oboli was the shekel. 

#### Numbers 3:48 And you shall give the money to Aaron and his sons, the ransoms of the ones abounding to them. 

#### Numbers 3:49 And Moses took the money, the ransoms for the ones abounding for the ransoming of the Levites. 

#### Numbers 3:50 From the first-born of the sons of Israel he took the money -- a thousand three hundred sixty-five shekels, according to the shekel of the holy place. 

#### Numbers 3:51 And Moses gave the money, the ransoms for the ones abounding, to Aaron and to his sons, by the voice of the LORD, in which manner the LORD gave charge to Moses. 

#### Numbers 4:1 And the LORD spoke to Moses and Aaron, saying, 

#### Numbers 4:2 Take the total sum of the sons of Kohath from the midst of the sons of Levi, according to their peoples, according to the houses of their patrimony! 

#### Numbers 4:3 from twenty and five years and up unto fifty years, every one entering to officiate to do all the works in the tent of the testimony. 

#### Numbers 4:4 And these are the works of the sons of Kohath in the tent of the testimony, a holy of the holies. 

#### Numbers 4:5 And Aaron shall enter and his sons, whenever {should lift away the camp}. And they shall lower the veil, the one overshadowing, and they shall cover with it the ark of the testimony. 

#### Numbers 4:6 And they shall place upon it {overcovering a skin} of blue. And they shall put upon it a garment entirely of blue from above. And they shall insert the bearing poles. 

#### Numbers 4:7 And upon the table, the one being situated for the loaves, they shall put upon it a garment entirely of purple, and the saucers, and the incense pans, and the cups, and the libation bowls in which you offer a libation; and the {bread loaves continual upon it shall be}. 

#### Numbers 4:8 And they shall put upon it {garment a scarlet}, and shall cover it with a covering made of a skin of blue. And they shall insert the bearing poles in it. 

#### Numbers 4:9 And they shall take the cloak of blue, and they shall cover the lamp-stand, the one giving light, and its lamps, and its tongs, and its oil funnels, and all the receptacles for its oil, as many things as they officiate with them. 

#### Numbers 4:10 And they shall put it, and all the items for it, into a covering made of skin of blue. And they shall place it upon bearing poles. 

#### Numbers 4:11 And upon the {altar golden} they shall place a garment of blue, and they shall cover it with a covering made of a skin of blue. And they shall insert the bearing poles of it. 

#### Numbers 4:12 And they shall take all the items of the ministry, as many as they officiate with them in the holy places, and they shall put them into a garment of blue. And shall cover them with a covering made of a skin of blue. And they shall place them upon bearing poles. 

#### Numbers 4:13 And {the lid they shall place} upon the altar, and they shall cover over it with a garment entirely of purple. 

#### Numbers 4:14 And they shall place upon it all its items as many as to officiate with them, and the censers, and the meat hooks, and the bowls, and the lid, and all the items of the altar. And they shall put upon it a covering made of skin of blue. And they shall insert the bearing poles of it. 

#### Numbers 4:15 And {shall complete Aaron and his sons} covering the holy things, and all the {items holy} in the lifting away the camp. And after these things {shall enter the sons of Kohath} to lift. And they shall not touch of the holy things, that they should not die. These things {shall lift the sons of Kohath} in the tent of the testimony, 

#### Numbers 4:16 {is overseer of Eleazar son of Aaron the priest} the oil for the light, and the incense of the composition, and the sacrifice by day, and the oil for the anointing -- the overseeing entirely of the tent and as much as is in it in the holy place, and in all the works. 

#### Numbers 4:17 And the LORD spoke to Moses and Aaron, saying, 

#### Numbers 4:18 Do not annihilate the tribe of the people of Kohath from out of the midst of the Levites. 

#### Numbers 4:19 But do this to them, and they shall live, and in no way shall die, in their going forth to the holy of holies. {Aaron and his sons Let} enter! and they shall place themselves each in his office. 

#### Numbers 4:20 And in no way shall they enter to see suddenly the holy place, for they shall die. 

#### Numbers 4:21 And the LORD spoke to Moses, saying, 

#### Numbers 4:22 Take the sum of the sons of Gershon, and these according to the houses of their patrimony, according to their peoples, 

#### Numbers 4:23 from five and twenty years and up unto fifty years -- you number them! every one entering to officiate, and to do his work in the tent of the testimony. 

#### Numbers 4:24 This is the ministration of the people of Gershon, to officiate and to lift. 

#### Numbers 4:25 And they shall lift the hide coverings of the tent, and the tent of the testimony, and its covering, and the overcovering of blue -- the one being upon it from above, and the overcovering of the door of the tent of the testimony. 

#### Numbers 4:26 And the shrouds of the courtyard, and the overcovering of the door of the courtyard, as many as are upon the tent, and upon the altar, and their extras, and all the items of their ministries. And as many as they officiate with them they shall prepare. 

#### Numbers 4:27 By the mouth of Aaron and his sons shall be the ministration of the sons of Gershon, according to all their ministrations, and according to all their works. And you shall number them by names, and all the works by them. 

#### Numbers 4:28 This is the ministration of the sons of Gershon in the tent of the testimony, and their watch by the hand of Ithamar the son of Aaron the priest. 

#### Numbers 4:29 The sons of Merari according to their peoples, according to the houses of their patrimony, you number them! 

#### Numbers 4:30 From five and twenty years and up unto fifty years number them! every one entering to officiate the works of the tent of the testimony. 

#### Numbers 4:31 And these are the injunctions for the things lifted by them, according to all their works in the tent of the testimony -- the tips of the tent, and its bars, and its posts, and its bases, 

#### Numbers 4:32 and the posts of the courtyard round about, and their bases, and the posts for the veil of the gate of the courtyard, and their bases, and their stanchions, and their ropes, and all their items, and all the things of their ministrations; {by names you shall number them}, and all the items of the watch of the things being lifted by them. 

#### Numbers 4:33 This is the ministration of the people of the sons of Merari, in all their works, in the tent of the testimony, by the hand of Ithamar the son of Aaron the priest. 

#### Numbers 4:34 And Moses {numbered and Aaron and the rulers of Israel} the sons of Kohath, according to their peoples, according to the houses of their patrimony, 

#### Numbers 4:35 from five and twenty years and up unto fifty years, every one entering to officiate and to do the works in the tent of the testimony. 

#### Numbers 4:36 And {was their numbering} according to their peoples -- two thousand seven hundred fifty. 

#### Numbers 4:37 This is the numbering of the people of Kohath, every one officiating in the tent of the testimony, as {numbered Moses and Aaron} by the voice of the LORD by the hand of Moses. 

#### Numbers 4:38 And {were numbered the sons of Gershon} according to their peoples, according to the houses of their patrimony, 

#### Numbers 4:39 from five and twenty years and up unto fifty years; every one entering to officiate and to do the works in the tent of the testimony. 

#### Numbers 4:40 And {was their numbering} according to their peoples, according to the house of their patrimony -- two thousand six hundred thirty. 

#### Numbers 4:41 This is the numbering of the people of the sons of Gershon, every one officiating in the tent of the testimony, which {numbered Moses and Aaron} by the voice of the LORD by the hand of Moses. 

#### Numbers 4:42 And were numbered also the people of the sons of Merari according to their peoples, according to the houses of their patrimony, 

#### Numbers 4:43 from five and twenty years and up unto fifty years, every one entering to officiate and to do for the works of the tent of the testimony. 

#### Numbers 4:44 And {was their numbering} according to their peoples, according to the houses of their patrimony -- three thousand and two hundred. 

#### Numbers 4:45 This is the numbering of the people of the sons of Merari which {numbered Moses and Aaron} by the voice of the LORD by the hand of Moses. 

#### Numbers 4:46 All the ones being numbered, whom Moses numbered, and Aaron, and the rulers of Israel of the Levites, according to their peoples, and according to the houses of their patrimony, 

#### Numbers 4:47 from five and twenty years and up, unto fifty years; every one entering to the works of the works, and the works of the things being lifted in the tent of the testimony. 

#### Numbers 4:48 And {were the ones being numbered}, eight thousand five hundred eighty. 

#### Numbers 4:49 By the voice of the LORD he numbered them, by the hand of Moses; man for man, over their works, and over what they lifted themselves. And they were numbered in which manner the LORD gave orders to Moses. 

#### Numbers 5:1 And the LORD spoke to Moses, saying, 

#### Numbers 5:2 Assign to the sons of Israel, and let them send out from the camp every leper, and every one having gonorrhea, and every one unclean from a dead soul! 

#### Numbers 5:3 from male unto female you send them outside the camp! for in no way shall they defile their camp in which I occupy among them. 

#### Numbers 5:4 And {did thus the sons of Israel}. And they sent them outside the camp as the LORD said to Moses -- thus {did the sons of Israel}. 

#### Numbers 5:5 And the LORD spoke to Moses, saying, 

#### Numbers 5:6 Speak to the sons of Israel! saying, A man or woman, who ever should commit of all the sins of mankind, and ignoring should ignore, and {should trespass that soul}, 

#### Numbers 5:7 he should declare openly the sin which he did, and shall give for the trespass offering the total sum, and the fifth part of it he shall add unto it, and shall give back to whomever he trespassed against him. 

#### Numbers 5:8 But if there might not be to the man acting as next of kin, so as to give to him satisfaction for the trespass offering, let the trespass offering, the one being given be to the LORD -- {for the priest it shall be}, besides the ram of the atonement, by which he shall atone with it for him. 

#### Numbers 5:9 And every first-fruit of all the things having been sanctified among the sons of Israel, as many as they should offer to the LORD, {for the priest himself will be}. 

#### Numbers 5:10 And the things of each man having been sanctified it will be his; and a man, who ever should give anything to the priest, to him it will be his. 

#### Numbers 5:11 And the LORD spoke to Moses, saying, 

#### Numbers 5:12 Speak to the sons of Israel! and you shall say to them, The man, a man if {should violate his wife}, and in overlooking should ignore him, 

#### Numbers 5:13 and anyone should go to bed with her in the marriage-bed of semen, and it should be unaware from the eyes of her husband, and she should hide it, and herself should be defiled, and {witness there should be no} against her, and she should not be conceived; 

#### Numbers 5:14 and there should come upon him a spirit of jealousy, and he should be jealous of his wife, and she be defiled; or there should come upon him a spirit of jealousy and he should be jealous of his wife, and she should not be defiled; 

#### Numbers 5:15 then {shall lead the man} his wife to the priest, and he shall bring the gift for her, the tenth of the ephah of flour of barley; he shall not pour upon it olive oil, nor shall he place upon it frankincense; for it is a sacrifice for jealousy, a sacrifice of memorial, calling to mind sin. 

#### Numbers 5:16 And {shall bring her the priest}, and stand her before the LORD. 

#### Numbers 5:17 And {shall take the priest water clean living} in {receptacle an earthenware}, and some of the earth being upon the floor of the tent of the testimony; and taking it, the priest shall put it into the water. 

#### Numbers 5:18 And {shall stand the priest} the woman before the LORD, and he shall uncover the head of the woman, and he shall give unto her hands the sacrifice of memorial, the sacrifice of jealousy; but in the hand of the priest will be the water of rebuke, the one accursing this. 

#### Numbers 5:19 And {shall adjure her the priest}, and he shall say to the woman, If no one has gone to bed with you, if you have not violated to be defiled being under {husband your own}, be innocent from {by the water of rebuke this accursing}! 

#### Numbers 5:20 But if {you violated being married}, or were defiled, and any gave of his marriage-bed with you, besides your husband; 

#### Numbers 5:21 then {shall bind the priest} the woman by the oaths of this imprecation. And {shall say the priest} to the woman, May {appoint you the LORD} to a curse and solemn affirmation in the midst of your people, in the LORD giving of your thigh to miscarry, and your belly to bloat; 

#### Numbers 5:22 and {shall enter water this accursing} into your belly to bloat pregnant and to miscarry by your thigh. And {shall say the woman}, May it be. May it be. 

#### Numbers 5:23 And {shall write the priest} these imprecations on a scroll, and shall wipe them away in the water of the rebuke of the accursing. 

#### Numbers 5:24 And he shall give to drink to the woman the water of the rebuke of the accursing; and shall enter into her the water of the rebuke of the accursing. 

#### Numbers 5:25 And {shall take the priest} from out of the hand of the woman the sacrifice of jealousy, and shall place the sacrifice before the LORD. And he shall bring her unto the altar. 

#### Numbers 5:26 And {shall grab the priest} from the sacrifice as a memorial of it, and he shall offer it upon the altar; and after these things he will cause {to drink the woman} the water. 

#### Numbers 5:27 And it shall be if she should be defiled, and in forgetfulness {should be unaware her husband}, then shall enter into her the water of rebuke of accursing, and {shall bloat the belly}, and {shall miscarry her thigh}. And {will be the woman} for a curse to her people. 

#### Numbers 5:28 But if {should not be defiled the woman}, and should be clean, then she will be innocent, and shall produce offspring of semen. 

#### Numbers 5:29 This is the law of the jealousy in which ever {should violate a woman being married} and should be defiled; 

#### Numbers 5:30 or a man who ever should have {come upon him a spirit of jealousy}, and should be jealous of his wife, and should stand his wife before the LORD, then {shall do to her the priest} all this law. 

#### Numbers 5:31 And {will be innocent the man} from sin. And that woman shall take the sin on herself. 

#### Numbers 6:1 And the LORD spoke to Moses, saying, 

#### Numbers 6:2 Speak to the sons of Israel! And you shall say to them, A man or woman, who ever should greatly vow a vow to purify oneself in purity to the LORD, 

#### Numbers 6:3 from wine and liquor he shall be pure, and strong drink from out of wine; and strong drink from out of liquor he shall not drink; and as many things as are manufactured from out of the grape he shall not drink; and {grape fresh} and dried grape he shall not eat. 

#### Numbers 6:4 All the days of his vow, from all as many things as come from the grapevine, wine, from dregs unto grape-stone, he shall not eat. 

#### Numbers 6:5 All the days of the vow of his purification a razor shall not come upon his head, until whenever {should be fulfilled the days}, as many as he made a vow to the LORD. He shall be holy, maintaining the lock of hair on his head. 

#### Numbers 6:6 All the days of the vow to the LORD {unto any soul coming to an end he shall not enter}. 

#### Numbers 6:7 Unto father and unto mother, and to brother, and to sister, he shall not be defiled by them in their dying; for {vow of God his} is upon him, upon his head. 

#### Numbers 6:8 All the days of his vow will be holy to the LORD. 

#### Numbers 6:9 And if anyone {to death should die} near him suddenly, immediately {shall be defiled the head of his vow}; and he shall shave his head in which day he should be cleansed; the {day seventh} he shall be shaved. 

#### Numbers 6:10 And the {day eighth} he shall bring two turtle-doves, or two young pigeons to the priest at the doors of the tent of the testimony. 

#### Numbers 6:11 And {shall offer the priest} one for a sin offering, and one for a whole burnt-offering; and {shall atone for him the priest}, for of which he sinned concerning touching the dead soul, and he shall sanctify his head in that day, 

#### Numbers 6:12 in which he was sanctified to the LORD, all the days of the vow. And he shall lead forward a lamb of a year old for a trespass offering. And the {days former} shall not be reckoned, for {was defiled the head of his vow}. 

#### Numbers 6:13 And this is the law of the making a vow; in which ever day he shall have fulfilled the days of his vow, he shall bring himself by the doors of the tent of the testimony, 

#### Numbers 6:14 and shall lead his gift to the LORD -- {he-lamb of a year old unblemished one} for a whole burnt-offering, and {ewe-lamb of a year old one unblemished} for a sin offering, and {ram one unblemished} for a deliverance offering; 

#### Numbers 6:15 and a bin of unleavened fine flour breads being prepared in olive oil, and {pancakes unleavened} being anointed in olive oil, and their sacrifice, and their libation. 

#### Numbers 6:16 And {shall bring them the priest} before the LORD, and shall offer the sacrifice for his sin offering, and his whole burnt-offering. 

#### Numbers 6:17 And with the ram he shall make a sacrifice of deliverance to the LORD with the bin of unleavened breads. And {shall offer the priest} his sacrifice offering, and his libation. 

#### Numbers 6:18 And {shall shave the one making a vow} by the doors of the tent of the testimony the head of his vow; and he shall place the hair upon the fire, the one which is upon the sacrifice of the deliverance offering. 

#### Numbers 6:19 And {shall take the priest} the shoulder cooked from the ram, and {bread one unleavened} from the bin, and {pancake unleavened one}; and he shall place them upon the hands of the one making a vow, after his shaving of his head. 

#### Numbers 6:20 And {shall offer them the priest} as an increase offering before the LORD; it shall be a holy portion to the priest beside the breast of the increase offering, and beside the shoulder of the cut-away portion offering. And after this {shall drink the one making a vow} wine. 

#### Numbers 6:21 This is the law of the one making a vow; who ever should make a vow to the LORD of his gift to the LORD, concerning the vow, separate from what ever {should find his hand} according to ability of his vow, of what ever he should have vowed according to the law of his purity. 

#### Numbers 6:22 And the LORD spoke to Moses, saying, 

#### Numbers 6:23 Speak to Aaron and his sons! saying, Thus you shall bless the sons of Israel, saying to them, 

#### Numbers 6:24 May {bless you The LORD}, and keep you. 

#### Numbers 6:25 May the LORD shine his face upon you, and show mercy on you. 

#### Numbers 6:26 May the LORD lift up his face upon you, and give you peace. 

#### Numbers 6:27 And they shall place my name upon the sons of Israel, and I will bless them. 

#### Numbers 7:1 And it came to pass in the day in which Moses completed so as to raise up the tent, and he anointed it, and sanctified it, and all the items of it, and the altar, and all the items of it; and he anointed them and sanctified them. 

#### Numbers 7:2 And {brought gifts the rulers of Israel}, rulers of the houses of their patrimony, these are the rulers of the tribes, these are the ones standing by the overseeing. 

#### Numbers 7:3 And they brought their gifts before the LORD, six wagons covered, and twelve oxen; a wagon from two rulers, and a calf from each. And they brought them before the tent. 

#### Numbers 7:4 And the LORD said to Moses, saying, 

#### Numbers 7:5 Take from them! and they will be for the works of the ministry of the tent of the testimony. And you shall give them to the Levites, each according to his ministration. 

#### Numbers 7:6 And Moses, taking the wagons and the oxen, he gave them to the Levites. 

#### Numbers 7:7 The two wagons, and the four oxen he gave to the sons of Gershon for their ministrations. 

#### Numbers 7:8 And the four wagons and the eight oxen he gave to the sons of Merari for their ministrations, by Ithamar son of Aaron the priest. 

#### Numbers 7:9 And to the sons of Kohath he gave not, for {the ministrations of the holy things they have}; {upon their shoulders they shall lift them}. 

#### Numbers 7:10 And {brought gifts the rulers} for the dedication of the altar in the day in which he anointed it, and {brought the rulers} their gifts before the altar. 

#### Numbers 7:11 And the LORD said to Moses, {ruler One} for each day, a ruler per day shall bring his gift for the dedication of the altar. 

#### Numbers 7:12 And was the one bringing on the {day first} of his gift -- Nahshon son of Amminadab, ruler of the tribe of Judah. 

#### Numbers 7:13 And he brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:14 {incense pan one} of ten weights of gold, full of incense; 

#### Numbers 7:15 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:16 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:17 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Nahshon son of Amminadab. 

#### Numbers 7:18 The {day second} there brought Nethaneel, son of Zuar, the ruler of the tribe of Issachar. 

#### Numbers 7:19 And he brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:20 {incense pan one} of ten weights of gold full of incense, 

#### Numbers 7:21 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:22 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:23 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Nethaneel son of Zuar. 

#### Numbers 7:24 The {day third} the ruler of the sons of Zebulun, Eliab son of Helon 

#### Numbers 7:25 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:26 {incense pan one} of ten weights of gold, full of incense; 

#### Numbers 7:27 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:28 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:29 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Eliab son of Helon. 

#### Numbers 7:30 The {day fourth} the ruler of the sons of Reuben, Elizur son of Shedeur 

#### Numbers 7:31 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight; {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:32 {incense pan one} of ten weights of gold, full of incense, 

#### Numbers 7:33 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:34 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:35 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Elizur son of Shedeur. 

#### Numbers 7:36 The {day fifth} the ruler of the sons of Simeon, Shelumiel son of Zurishaddai 

#### Numbers 7:37 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:38 {incense pan one} of ten weights of gold, full of incense; 

#### Numbers 7:39 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:40 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:41 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Shelumiel son of Zurishaddai. 

#### Numbers 7:42 The {day sixth} the ruler of the sons of Gad, Eliasaph son of Reuel 

#### Numbers 7:43 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:44 {incense pan one} of ten weights of gold full of incense; 

#### Numbers 7:45 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:46 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:47 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Eliasaph son of Reuel. 

#### Numbers 7:48 The {day seventh} the ruler of the sons of Ephraim, Elishama son of Ammihud 

#### Numbers 7:49 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:50 {incense pan one}, ten weights of gold full of incense; 

#### Numbers 7:51 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:52 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:53 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Elishama son of Ammihud. 

#### Numbers 7:54 The {day eighth} the ruler of the sons of Manasseh, Gamaliel son of Pedahzur 

#### Numbers 7:55 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight; {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:56 {incense pan one} of ten weights of gold full of incense; 

#### Numbers 7:57 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:58 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:59 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Gamaliel son of Pedahzur. 

#### Numbers 7:60 The {day ninth} the ruler of the sons of Benjamin, Abidan son of Gideoni 

#### Numbers 7:61 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:62 {incense pan one} of ten weights of gold full of incense; 

#### Numbers 7:63 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:64 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:65 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Abidan son of Gideoni. 

#### Numbers 7:66 The {day tenth} the ruler of the sons of Dan, Ahiezer son of Ammishaddai 

#### Numbers 7:67 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:68 {incense pan one} of ten weights of gold full of incense; 

#### Numbers 7:69 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:70 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:71 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Ahiezer son of Ammishaddai. 

#### Numbers 7:72 The {day eleventh} the ruler of the sons of Asher, Pagiel son of Ocran 

#### Numbers 7:73 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:74 {incense pan one} of ten weights of gold full of incense; 

#### Numbers 7:75 {calf one} from the oxen, {ram one}, {he-lamb of a year old one} for a whole burnt-offering; 

#### Numbers 7:76 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:77 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five} {ewe-lambs of a year old five}; this is the gift of Pagiel son Ocran. 

#### Numbers 7:78 The {day twelfth} the ruler of the sons of Naphtali, Ahira son of Enan 

#### Numbers 7:79 brought his gift; {saucer silver one}, thirty and a hundred was its scale-weight, {bowl one silver} of seventy shekels, according to the {shekel holy}, both full of fine flour being prepared in olive oil for a sacrifice offering; 

#### Numbers 7:80 {incense pan one} of ten weights of gold full of incense, 

#### Numbers 7:81 {calf one} from the oxen, {ram one}, {he-lamb one} of a year old for a whole burnt-offering; 

#### Numbers 7:82 and {winter yearling from the goats one} for a sin offering; 

#### Numbers 7:83 and for a sacrifice of deliverance, {heifers two}, {rams five}, {he-goats five}, {ewe-lambs of a year old five}; this is the gift of Ahira son of Enan. 

#### Numbers 7:84 This is the dedication of the altar in which day he anointed it, by the rulers of the sons of Israel; {saucers silver twelve}, {bowls silver twelve}, {incense pans gold twelve}, 

#### Numbers 7:85 thirty and a hundred shekels to the {saucer one}, and seventy shekels to the {bowl one}; all the silver of the items -- two thousand and four hundred shekels, the shekels according to the {shekel holy}. 

#### Numbers 7:86 {incense pans gold Twelve} full of incense; all the gold of the incense pans was twenty and a hundred weights of gold. 

#### Numbers 7:87 All the livestock, for the whole burnt-offering -- {calves twelve}, {rams twelve}, {he-lambs of a year old twelve}, and their sacrifices, and their libations, and {winter yearlings from the goats twelve} for a sin offering. 

#### Numbers 7:88 All the livestock for a sacrifice of deliverance -- {heifers twenty-four}, {rams sixty}, {he-goats sixty}, {ewe-lambs sixty of a year old unblemished}. This is the dedication of the altar after his anointing. 

#### Numbers 7:89 In Moses' entering into the tent of the testimony to speak to him, he heard the voice of the LORD speaking to him from above the atonement-seat, which is upon the ark of the testimony, between the two cherubim -- and he spoke to him. 

#### Numbers 8:1 And the LORD spoke to Moses, saying, 

#### Numbers 8:2 Speak to Aaron! And you shall say to him, Whenever you should place the lamps by rank, {in front of the lamp-stand shall give light the seven lamps}. 

#### Numbers 8:3 And {did so Aaron}; in front of the lamp-stand he lit up its lamps as the LORD gave orders to Moses. 

#### Numbers 8:4 And this is the apparatus of the lamp-stand; {is solid gold, its stem}, and its lilies are solid entirely, according to the form which the LORD showed Moses -- thus he made the lamp-stand. 

#### Numbers 8:5 And the LORD spoke to Moses, saying, 

#### Numbers 8:6 Take the Levites from the midst of the sons of Israel, and you shall purify them. 

#### Numbers 8:7 And thus you shall do to them for their purification -- you shall sprinkle about them water of purification, and {shall come a razor} upon the whole of their body. And you shall wash their garments, and they shall be clean. 

#### Numbers 8:8 And they shall take {calf one} from the oxen, and of this a sacrifice offering of fine flour being prepared in olive oil. And a calf of a year old from the oxen you shall take for a sin offering. 

#### Numbers 8:9 And you shall lead forward the Levites before the tent of the testimony. And you shall bring together all the congregation of the sons of Israel. 

#### Numbers 8:10 And you shall lead forward the Levites before the LORD, and {shall place the sons of Israel} their hands upon the Levites. 

#### Numbers 8:11 And Aaron shall separate the Levites for a gift before the LORD from the sons of Israel. And they shall be so as to work the works of the LORD. 

#### Numbers 8:12 And the Levites shall place the hands upon the heads of the calves. And you shall offer the one for a sin offering, and the one for a whole burnt-offering to the LORD to atone for them. 

#### Numbers 8:13 And you shall stand the Levites before Aaron, and before his sons; and you shall give them back as a gift to the LORD. 

#### Numbers 8:14 And you shall draw apart the Levites from the midst of the sons of Israel, and they shall be mine. 

#### Numbers 8:15 And after these things {shall enter the Levites} to work the works of the tent of the testimony. And you shall cleanse them, and render them before the LORD. 

#### Numbers 8:16 For as a gift these are being given back to me; they are from out of the midst of the sons of Israel, in place of the ones opening wide every womb of all first-born of the sons of Israel; I have taken them to myself. 

#### Numbers 8:17 For {is mine every first-born among the sons of Israel}, from man unto beast; in which day I struck every first-born in the land of Egypt, I sanctified them to myself. 

#### Numbers 8:18 And I took the Levites instead of every first-born among the sons of Israel. 

#### Numbers 8:19 And I gave back the Levites as a gift, recompensing Aaron and to his sons from out of the midst of the sons of Israel, to work the works of the sons of Israel in the tent of the testimony, and to atone for the sons of Israel; and that {shall not be among the sons of Israel a calamity} whenever drawing near to the holy things. 

#### Numbers 8:20 And {did so Moses and Aaron}, and all the congregation of the sons of Israel, to the Levites as the LORD gave charge to Moses concerning the Levites -- thus {did to them the sons of Israel}. 

#### Numbers 8:21 And {purified themselves the Levites}, and washed their garments. And {gave them Aaron} as a gift before the LORD. And {made atonement for them Aaron} to purify them. 

#### Numbers 8:22 And after this {entered the Levites} to officiate their ministration in the tent of the testimony before Aaron, and before his sons. As the LORD gave orders to Moses for the Levite, so they did to them. 

#### Numbers 8:23 And the LORD spoke to Moses, saying, 

#### Numbers 8:24 This is the thing for the Levites from five and twenty years and up. They shall enter to minister a ministration in works in the tent of the testimony. 

#### Numbers 8:25 And from fifty years old he shall leave from the ministration, and shall not work any longer. 

#### Numbers 8:26 And he shall officiate with his brethren in the tent of the testimony, to guard the watches; {the works but he shall not work} -- so shall you do to the Levites in their watches. 

#### Numbers 9:1 And the LORD spoke to Moses in the wilderness of Sinai, in the {year second} of their coming forth from out of the land of Egypt, in the {month first}, saying, 

#### Numbers 9:2 Speak! And let {prepare the sons of Israel} the passover according to its season! 

#### Numbers 9:3 On the fourteenth day of the {month first} towards evening you shall observe it; according to its time, according to its law, and according to the interpretation given for it you shall observe it. 

#### Numbers 9:4 And Moses spoke to the sons of Israel, to observe the passover, 

#### Numbers 9:5 commencing on the fourteenth day of the month in the wilderness of Sinai. As the LORD gave orders to Moses, thus {did the sons of Israel}. 

#### Numbers 9:6 And {came men}, the ones who were unclean by reason of touching a dead soul of a man, and they were not able to observe the passover in that day. And they came forward before Moses and Aaron on that day. 

#### Numbers 9:7 And {said those men} to them, We are unclean by reason of the dead soul of a man. Are we then lacking so as to bring the gift to the LORD according to its time in the midst of the sons of Israel? 

#### Numbers 9:8 And {said to them Moses}, Stand there and I will hear what the LORD gives charge concerning you. 

#### Numbers 9:9 And the LORD spoke to Moses, saying, 

#### Numbers 9:10 Speak to the sons of Israel! saying, A man, a man who ever becomes unclean by reason of a dead soul of a man, or on a journey far from you, even among your generations, he shall observe the passover to the LORD. 

#### Numbers 9:11 In the {month second}, on the fourteenth day towards evening, they shall prepare it; upon unleavened breads and bitter herbs they shall eat it. 

#### Numbers 9:12 They shall not leave behind any of it into the morning, and {a bone they shall not break} of it. According to the law of the passover they shall observe it. 

#### Numbers 9:13 And the man who ever might be clean, and {on a journey far away is not}, and should lack to observe the passovers, {shall be utterly destroyed that soul} from its people, because the gift to the LORD he did not offer according to its time; {his sin shall take that man}. 

#### Numbers 9:14 But if {should come forward to you a foreigner} in your land, and would observe the passover to the LORD, then according to the law of the passover, and according to its arrangement, thus he shall observe it. {law one There will be} to you, both to the foreigner, and to the native born of the land. 

#### Numbers 9:15 And in the day which {was set up the tent} {covered the cloud} the tent -- the house of the testimony. And in the evening there was upon the tent as a form of fire until morning. 

#### Numbers 9:16 So it was always. The cloud covered it by day, and the form of fire by the night. 

#### Numbers 9:17 And when {ascended the cloud} from the tent, then after this {departed the sons of Israel}. And in the place where ever {stopped the cloud}, there {camped the sons of Israel}. 

#### Numbers 9:18 By order of the LORD {shall camp the sons of Israel}, and by order of the LORD they shall depart. All the days in which {shadowed the cloud} over the tent, {shall camp the sons of Israel}. 

#### Numbers 9:19 And whenever {should be dragged the cloud} upon the tent {days for many}, that {shall guard the sons of Israel} the watch of the LORD, and in no way shall they lift away. 

#### Numbers 9:20 And it shall be whenever {should become the cloud of days a number} upon the tent; by the voice of the LORD they shall camp, and by order of the LORD they shall depart. 

#### Numbers 9:21 And it shall be whenever {should be present the cloud} from evening until morning, and {should ascend the cloud} in the morning, then they shall depart by day or night, 

#### Numbers 9:22 or {a month of days when being more than} of the cloud shadowing upon it, {shall camp the sons of Israel}, and in no way shall they depart. 

#### Numbers 9:23 For by order of the LORD they shall depart. {the watch of the LORD They guarded} by order of the LORD by the hand of Moses. 

#### Numbers 10:1 And the LORD spoke to Moses, saying, 

#### Numbers 10:2 Make for yourself two trumpets of silver! A hammered work you shall make them, and they will be for you to call the congregation, and to lift away the camps. 

#### Numbers 10:3 And you shall trump with them, and bring together all the congregation unto the door of the tent of the testimony. 

#### Numbers 10:4 But if {with one sound they should trump}, then shall come forward to you all the rulers of the heads of Israel. 

#### Numbers 10:5 And you shall trump a signal, and shall lift away the camps camping according to the east. 

#### Numbers 10:6 And you shall trump for a signal a second time, and shall lift away the camps camping according to the south. And you shall trump {signal a third}, and shall lift away the camps camping by the west. And you shall trump {signal a fourth}, and shall lift away the camps camping towards the north. {a signal You shall trump} at their departure. 

#### Numbers 10:7 And whenever you should bring together the congregation, you shall trump, but not a signal. 

#### Numbers 10:8 And the sons of Aaron the priests shall trump with the trumpets; and it will be to you {law an eternal} unto your generations. 

#### Numbers 10:9 But if you should go forth to war in your land against the opponents opposing you, then you shall signify with the trumpets; and you will be called to mind before the LORD your God, and you shall be preserved from your enemies. 

#### Numbers 10:10 And in the days of your gladness, and in your holidays, and in your new moons, you shall trump with the trumpets at the whole burnt-offerings, and at the sacrifices of your deliverance offerings. And it shall be to you for a remembrance before your God. I am the LORD your God. 

#### Numbers 10:11 And it came to pass in the {year second}, in the {month second}, the twentieth of the month, {ascended the cloud} from the tent of the testimony. 

#### Numbers 10:12 And {lifted away the sons of Israel} with their chattel in the wilderness of Sinai. And {stopped the cloud} in the wilderness of Paran. 

#### Numbers 10:13 And {lifted away the first ranks} by the voice of the LORD by the hand of Moses. 

#### Numbers 10:14 And they lifted away in order, the camp of the sons of Judah first with their force. And over their force was Nahshon son of Amminadab. 

#### Numbers 10:15 And over the force of the tribe of the sons of Issachar was Nethaneel son of Zuar. 

#### Numbers 10:16 And over the force of the tribe of the sons of Zebulun was Eliab son of Helon. 

#### Numbers 10:17 And they shall lower the tent, and {shall lift away the sons of Gershon}, and the sons of Merari, the ones carrying the tent. 

#### Numbers 10:18 And lifted away in order the camp of Reuben with their force. And over their force was Elizur son of Shedeur. 

#### Numbers 10:19 And over the force of the tribe of the sons of Simeon was Shelumiel son of Zurishaddai. 

#### Numbers 10:20 And over the force of the tribe of the sons of Gad was Eliasaph the son of Reuel. 

#### Numbers 10:21 And {shall lift away the sons of Kohath} carrying the holy things. And they shall set up the tent until when they should arrive. 

#### Numbers 10:22 And shall lift away in order the camp of Ephraim with their force. And over his force was Elishama son of Ammihud. 

#### Numbers 10:23 And over the force of the tribe of the sons of Manasseh was Gamaliel the son of Pedahzur. 

#### Numbers 10:24 And over the force of the tribe of the sons of Benjamin was Abidan the son of Gideoni. 

#### Numbers 10:25 And shall lift away in order the camp of the sons of Dan last of all the camps with their force. And over their force was Ahiezer the son of Ammishaddai. 

#### Numbers 10:26 And over the force of the tribe of the sons of Asher was Pagiel son of Ocran. 

#### Numbers 10:27 And over the force of the tribe of the sons of Naphtali was Ahira son of Enan. 

#### Numbers 10:28 These are the militaries of the sons of Israel. And they lifted away with their force. 

#### Numbers 10:29 And Moses said to Hobab son of Raguel the Midianite father-in-law of Moses, We are lifting away unto the place which the LORD said, This I will give to you. Come with us and {good for you we will do}, for the LORD spoke good concerning Israel. 

#### Numbers 10:30 And he said to him, I shall not go; but unto my land, and unto my family I will go. 

#### Numbers 10:31 And he said, You should not abandon us, because you were with us in the wilderness, and you will be among us as an ambassador. 

#### Numbers 10:32 And it shall be if you should go with us, that it shall be the good things that whatever as many as the LORD shall do good for us, also {good for you we shall do}. 

#### Numbers 10:33 And they lifted away from the mountain of the LORD, a journey of three days. And the ark of covenant of the LORD went forth in front of them, a journey of three days, to survey themselves a rest. 

#### Numbers 10:34 And the cloud of the LORD came to pass shadowing over them by day in their lifting away from out of the camp. 

#### Numbers 10:35 And it came to pass in the lifting away the ark, that Moses said, Awaken! O LORD, and let {be dispersed your enemies}! and let flee all the ones detesting you! 

#### Numbers 10:36 And in the resting, he said, Turn! O LORD, thousands of myriads in Israel. 

#### Numbers 11:1 And {were the people} grumbling wickedly before the LORD. And the LORD heard, and he became enraged in anger; and there burned among them a fire by the LORD, and it devoured a certain part of the camp. 

#### Numbers 11:2 And {cried out the people} to Moses. And Moses made a vow to the LORD, and {abated the fire}. 

#### Numbers 11:3 And he called the name of that place, Combustion, for {burned among them fire by the LORD}. 

#### Numbers 11:4 And the intermixed people among them desired with a great desire. And being seated, they wept along with the sons of Israel. And they said, Who will feed us meats? 

#### Numbers 11:5 We remember the fishes which we ate in Egypt without charge, and the cucumbers, and the melons, and the leeks, and the onions, and the garlics. 

#### Numbers 11:6 But now our soul is dried up; there is nothing except for the manna to our eyes. 

#### Numbers 11:7 And the manna is as seed, it is as of coriander, and the appearance of it is the appearance of ice. 

#### Numbers 11:8 And {traveled around the people} and collected together, and ground it with the millstone, and ground with the hand mill, and boiled it in the earthen pot, and made it into a cake baked in hot ashes. And {was the satisfaction from eating it} as the taste of pastry made with olive oil. 

#### Numbers 11:9 And whenever {came down the dew} upon the camp at night, {came down the manna} upon it. 

#### Numbers 11:10 And Moses heard their weeping, according to their peoples, each at his door. And {was enraged in anger the LORD} exceedingly; and before Moses it was wicked. 

#### Numbers 11:11 And Moses said to the LORD, Why do you afflict your attendant? And why have I not found favor before you to place the thrust of this people upon me? 

#### Numbers 11:12 Have I {in the womb conceived} all this people, or have I given birth to them? that you say to me, Take them into your bosom as {lifts a wet-nurse} the one being nursed, unto the land which you swore by an oath to their fathers? 

#### Numbers 11:13 From what place is it to me {meats to give} to all this people? for they weep upon me, saying, Give to us meats that we may eat! 

#### Numbers 11:14 {shall not be able I} alone to bring this people, for {heavy for me is this matter}. 

#### Numbers 11:15 But if so you do to me, kill me with my removal, if I have found favor with you, that I should not see my ill-treatment. 

#### Numbers 11:16 And the LORD said to Moses, Bring together to me seventy men from the elders of Israel! whom you yourself know. These are elders of the people, and their scribes. And you shall lead them to the tent of the testimony, and they shall stand there with you. 

#### Numbers 11:17 And I shall go down and speak there with you. And I will remove of the spirit upon you, and I will place it upon them, and they shall aid with you the thrust of the people, and {shall not bring them you} alone. 

#### Numbers 11:18 And to the people you shall say, Purify yourselves for tomorrow! and you shall eat meats, for you wept before the LORD, saying, Who shall feed us meats? for {good to us it was} being in Egypt. And the LORD shall give to you meats and you shall eat. 

#### Numbers 11:19 {not day for one You shall eat}, nor two, nor five days, nor ten days, nor twenty days, 

#### Numbers 11:20 {for a month of days you shall eat}, until whenever it should come forth from out of your nostrils; and it shall be to you for a cholera, that you resisted the LORD who is among you, and you wept before him, saying, What did we do to come out of Egypt? 

#### Numbers 11:21 And Moses said, six hundred thousand footmen are the people in which I am among them. And you said, {meats I will give them}, and they shall eat for a month of days. 

#### Numbers 11:22 Shall sheep and oxen be slain for them, and will it suffice to them? or shall all the fish of the sea be brought to them, and will it suffice to them? 

#### Numbers 11:23 And the LORD said to Moses, Shall the hand of the LORD not be enough? Already you shall know if {shall overtake you my word} or not. 

#### Numbers 11:24 And Moses came forth, and he spoke to the people the sayings of the LORD. And he brought together seventy men from the elders of the people, and he stood them round about the tent. 

#### Numbers 11:25 And the LORD came down in a cloud, and he spoke to him, and he lifted from the spirit, of the one upon him, and he placed it upon the seventy men of the elders. And as {rested spirit} upon them, that they prophesied, and no longer proceeded. 

#### Numbers 11:26 And were left behind two men in the camp; the name of the one was Eldad, and the name of the second was Medad; and {rested upon them the spirit}, and these were of the ones delineated, and came not to the tent; and they prophesied in the camp. 

#### Numbers 11:27 And {ran up a young man} to report to Moses, and said, saying, Eldad and Medad are prophesying in the camp. 

#### Numbers 11:28 And answering Joshua the son of Nun, the one standing beside Moses, his chosen one, said, O my master Moses, restrain them! 

#### Numbers 11:29 And Moses said to him, Are you zealous for me? and O how it would be given all the people of the LORD were prophets, whenever the LORD should put his spirit upon them. 

#### Numbers 11:30 And Moses went forth into the camp, he and the elders of Israel. 

#### Numbers 11:31 And a wind went forth from the LORD, and carried over mother-quail from the sea, and it put them upon the camp, {journey a days} here on this side, and {journey a days} here on that side, round about the camp, about two cubits from the earth. 

#### Numbers 11:32 And {rose up the people entire day that}, and the entire night, and the entire {day next}; and they gathered together the mother-quail -- the one {a few gathering} was ten cors. And they cooled themselves in a time of refreshing round about the camp. 

#### Numbers 11:33 The meats still was in their teeth before the dissipating. And the LORD was enraged in wrath at the people. And the LORD struck the people {calamity great an exceedingly}. 

#### Numbers 11:34 And {was called the name of that place}, Tombs of Desire. For there they entombed the {people craving}. 

#### Numbers 11:35 From Tombs of the Desire {lifted away the people} unto Hazeroth; and {existed the people} in Hazeroth. 

#### Numbers 12:1 And {spoke Miriam and Aaron} against Moses, because of the Ethiopian wife, whom Moses took, for {an Ethiopian woman he took}. 

#### Numbers 12:2 And they said, Has {only to Moses spoken the LORD}? Did he not also speak to us? And the LORD heard. 

#### Numbers 12:3 And the man Moses was {gentle exceedingly} above all the men of the ones being upon the earth. 

#### Numbers 12:4 And the LORD said immediately to Moses, and Aaron, and Miriam, Come forth you the three into the tent of the testimony! 

#### Numbers 12:5 And came forth the three into the tent of the testimony. And the LORD came down in a column of cloud, and it stood at the door of the tent of the testimony. And {were called Aaron and Miriam}, and {came forth both}. 

#### Numbers 12:6 And he said to them, Hear my words. If there should be a prophet among you to the LORD, {in a vision to him I will be made known}, and in sleep I will speak to him. 

#### Numbers 12:7 Not so my attendant Moses; in {entire house my} he is trustworthy. 

#### Numbers 12:8 Mouth to mouth I will speak to him in sight, and not through enigmas; even {the glory of the LORD he saw}. And why were you not afraid to speak ill against my attendant Moses? 

#### Numbers 12:9 And anger of rage of the LORD was upon them, and they went forth. 

#### Numbers 12:10 And the cloud left from the tent. And behold, Miriam became leprous as snow. And Aaron looked upon Miriam, and behold, she was leprous. 

#### Numbers 12:11 And Aaron said to Moses, I beseech you, O my master, you should not join sin to us, for we knew not that we sinned. 

#### Numbers 12:12 Do not let her become as equal to death, as a miscarriage going forth from a womb of his mother, and it eats up half of her flesh. 

#### Numbers 12:13 And Moses yelled out to the LORD, saying, O God, I beseech you to heal her. 

#### Numbers 12:14 And the LORD said to Moses, If her father in spitting, spat into her face, would she not feel shame? Seven days she shall be separated outside the camp, and after this she shall enter. 

#### Numbers 12:15 And Miriam was separated outside the camp seven days; and the people did not lift away until Miriam was cleansed. 

#### Numbers 12:16 And after these things {lifted away the people} from Hazeroth, and they camped in the wilderness of Paran. 

#### Numbers 13:1 And the LORD spoke to Moses, saying, 

#### Numbers 13:2 Send for yourself men, and let them survey the land of the Canaanites! which I give to the sons of Israel for a possession. {man One} per tribe; according to the peoples of their patrimony you shall send them, all being chiefs of them. 

#### Numbers 13:3 And {sent them Moses} from the wilderness of Paran, by the voice of the LORD. All {men were chiefs of the sons of Israel these}. 

#### Numbers 13:4 And these are their names. Of the tribe of Reuben was Shammua son of Zaccur. 

#### Numbers 13:5 Of the tribe of Simeon was Shaphat son of Hori. 

#### Numbers 13:6 Of the tribe of Judah was Caleb son of Jephunneh. 

#### Numbers 13:7 Of the tribe of Issachar was Igal son of Joseph. 

#### Numbers 13:8 Of the tribe of Ephraim was Oshea son of Nun. 

#### Numbers 13:9 Of the tribe of Benjamin was Palti son of Raphu. 

#### Numbers 13:10 Of the tribe of Zebulun was Gaddiel son of Sodi. 

#### Numbers 13:11 Of the tribe of Joseph of the sons of Manasseh was Gaddi son of Susi. 

#### Numbers 13:12 Of the tribe of Dan was Ammiel son of Gamalli. 

#### Numbers 13:13 Of the tribe of Asher was Sethur son of Michael. 

#### Numbers 13:14 Of the tribe of Naphtali was Nahbi son of Vophsi. 

#### Numbers 13:15 Of the tribe of Gad was Geuel son of Machi. 

#### Numbers 13:16 These are the names of the men which Moses sent to survey the land. And Moses named Oshea son of Nun -- Joshua. 

#### Numbers 13:17 And {sent them Moses} to survey the land of Canaan. And he said to them, Ascend in this wilderness! And you shall ascend into the mountain. 

#### Numbers 13:18 And you will behold the land, what it is, and the people lying in wait upon it, if they are strong or weak; or if they are few, or many. 

#### Numbers 13:19 And what the land is like in which these lie in wait upon it, if it is good, or wicked; and what the cities in which these dwell in them, if in walled or in unwalled. 

#### Numbers 13:20 And what the land is like, if plentiful or being neglected; if there is in it trees or not. And attending to constantly you shall take from the fruits of the land. And the days were days in spring, forerunners of the grape. 

#### Numbers 13:21 And ascending they surveyed the land from the wilderness of Zin until Rehob, entering Hamath. 

#### Numbers 13:22 And they ascended by the wilderness, and came unto Hebron; and there was Ahiman, and Sheshai, and Talmai, the families of Anak; and Hebron {seven years was built} before Tanin of Egypt. 

#### Numbers 13:23 And they came unto the Ravine of the Cluster. And they beat from there a vine branch and {cluster of the grape one} from it; and they lifted it upon bearing poles, and some from the pomegranates, and the fig-trees. 

#### Numbers 13:24 And that place they named Ravine of the Cluster, on account of the cluster of grapes which {beat from there the sons of Israel}. 

#### Numbers 13:25 And they returned from there {surveying the land after} forty days. 

#### Numbers 13:26 And having gone, they came to Moses and Aaron, and to all the congregation of the sons of Israel, to the wilderness of Paran Kadesh. And they answered to them a word, and to all the congregation. And they showed the fruit of the land. 

#### Numbers 13:27 And they described to him, and they said, We came into the land unto which you sent us, a land flowing milk and honey. And this is its fruit. 

#### Numbers 13:28 Only that {is bold the nation dwelling the land}, and the {cities fortified}, being walled, are great -- very much so. And the generation of Anak we saw there. 

#### Numbers 13:29 And Amalek dwells in the land, in the land to the south; and the Hittite, and the Hivite, and the Jebusite, and the Amorite dwell in the mountainous area; and the Canaanite dwell by the sea, and by the Jordan river. 

#### Numbers 13:30 And Caleb quelled the people before Moses, and said to him, Not so, but ascending we will ascend, and we shall inherit it; for by might we shall be able to prevail against them. 

#### Numbers 13:31 And the men, the ones going up with him said, We are not ascending; for in no way should we be able to ascend to that nation, for {stronger than us it is rather}. 

#### Numbers 13:32 And they brought an astonishment of the land of which they surveyed it to the sons of Israel, saying, The land which we went in it to survey -- {a land devouring the ones dwelling upon it it is}; and all the people whom we see in it {men are exceedingly tall}. 

#### Numbers 13:33 And there we saw the giants; and we were {in the presence of them as locusts}; yes, even so we were in the presence of them. 

#### Numbers 14:1 And taking up, all the congregation gave a sound, and {wept the people entire night that}. 

#### Numbers 14:2 And they complained over Moses and Aaron -- all the sons of Israel. And {said to them all the congregation}, Ought that we should die in the land of Egypt, than {in this wilderness we should die}. 

#### Numbers 14:3 And why did the LORD bring us into this land to fall in war? Our wives and children will be for ravaging. Now then {best for us it is} to return to Egypt. 

#### Numbers 14:4 And {said the other} to the other, We should appoint a chief, and we should return unto Egypt. 

#### Numbers 14:5 And {fell Moses and Aaron} upon their face before all the congregation of the sons of Israel. 

#### Numbers 14:6 And Joshua the son of Nun, and Caleb the son of Jephunneh, of the ones surveying the land, tore their cloaks. 

#### Numbers 14:7 And they said to all the congregation of the sons of Israel, saying, The land which we surveyed it, it is good exceedingly exceedingly. 

#### Numbers 14:8 If {selected us the LORD}, he will bring us into this land, and he will give it to us; a land which is flowing milk and honey. 

#### Numbers 14:9 But from the LORD do not {defectors become}; And you, do not fear the people of the land! for {a thing devoured for us they are}. {has left for the time} from them, and the LORD is among us; do not fear them! 

#### Numbers 14:10 And {said all the congregation} to stone them with stones. And the glory of the LORD appeared in the cloud upon the tent of the testimony among all the sons of Israel. 

#### Numbers 14:11 And the LORD said to Moses, For how long does {provoke me this people}? And for how long do they not trust me, for all the signs which I did among them? 

#### Numbers 14:12 I will strike them in death, and I will destroy them, and I will make you into {nation a great and populous} rather than this one. 

#### Numbers 14:13 And Moses said to the LORD, And Egypt shall hear that you led {by your strength people this} from them, 

#### Numbers 14:14 but also all the ones dwelling upon this land have heard, that you are the LORD among this people, who eyes to eyes you behold, O LORD, and your cloud stands over them, and in a column of cloud you go in front of them by the day, and in a column of fire by the night. 

#### Numbers 14:15 And shall you obliterate this people as {man one}? and {shall say the nations}, as many as heard your name, saying, 

#### Numbers 14:16 Because the {was not able LORD} to bring this people into the land which he swore by an oath to them, he prostrated them in the wilderness. 

#### Numbers 14:17 And now, raise up high your strength, O LORD, in which manner you said, saying, 

#### Numbers 14:18 The LORD is lenient, and full of mercy, and true, removing lawless deeds, and iniquities, and sins; but by cleansing he shall not cleanse the liable, repaying the sins of the fathers upon the children unto the third and fourth generation. 

#### Numbers 14:19 Dismiss the sin of this people according to {great mercy your}, just as kindness happened to them from Egypt until the present. 

#### Numbers 14:20 And the LORD said, {kind to them I am} according to your word; 

#### Numbers 14:21 but as I live, that {will fill the glory of the LORD} all the earth. 

#### Numbers 14:22 For all the men seeing my glory, and the signs which I did in Egypt, and in this wilderness, and test me this tenth time, and are not listening to my voice, 

#### Numbers 14:23 assuredly they shall not see the land which I swore by an oath to their fathers; but only their children who are with me here, as many as have not known good or evil, every young one inexperienced, to these I will give the land. But all the ones provoking me shall not see it. 

#### Numbers 14:24 But my servant Caleb, for {is spirit another} in him, and he followed after me, I will bring him into the land into which you enter there, and his seed shall inherit it. 

#### Numbers 14:25 But Amalek and the Canaanites dwell in the valley. Tomorrow you should turn and depart into the wilderness way {sea of the red}. 

#### Numbers 14:26 And the LORD said to Moses and Aaron, saying, 

#### Numbers 14:27 For how long shall I endure {congregation this wicked}, in which they grumble before me? The grumbling of the sons of Israel, which they grumble concerning you, I have heard. 

#### Numbers 14:28 Say to them, as I live, says the LORD, assuredly in which manner you spoke into my ears, so I will do for you. 

#### Numbers 14:29 In this wilderness {shall fall your carcasses}, even all overseeing you, and the ones being counted of you from twenty years old and up, as many as grumbled against me. 

#### Numbers 14:30 Shall you enter into the land upon which I stretched out my hand to encamp you upon it, no. But only Caleb, son of Jephunneh, and Joshua the son of Nun, 

#### Numbers 14:31 and the children who you said, {for ravaging to be}, I will bring them into the land which you abstained from it. 

#### Numbers 14:32 And your carcasses will fall in this wilderness. 

#### Numbers 14:33 But your sons will be fed in the wilderness forty years. And they shall bear your harlotry, until whenever {should be consumed your carcasses} in the wilderness. 

#### Numbers 14:34 According to the number of the days, as many as you surveyed the land -- forty days; a day for the year you will take for your sins -- forty years; and you shall know the rage of my anger. 

#### Numbers 14:35 I the LORD spoke. Assuredly thus I will do {congregation to this wicked}, to the one rising up together against me. In this wilderness they shall be completely consumed, and there they shall die. 

#### Numbers 14:36 And the men whom Moses sent to survey the land, and coming, complained concerning this to the congregation, to bring forth {words bad} concerning the land, 

#### Numbers 14:37 and they died, the men avowing bad things concerning the land in the calamity before the LORD. 

#### Numbers 14:38 And Joshua son of Nun, and Caleb son of Jephunneh lived of those men, of the ones going to survey the land. 

#### Numbers 14:39 And Moses spoke these words to all the sons of Israel; and {mourned the people} exceedingly. 

#### Numbers 14:40 And rising early in the morning, they ascended into the top of the mountain, saying, Behold, we shall ascend unto the place which the LORD spoke, for we sinned. 

#### Numbers 14:41 And Moses said, Why do you violate the word of the LORD? it will not be prosperous for you. 

#### Numbers 14:42 Do not ascend, {not for is the LORD} with you. And you shall fall before the face of your enemies. 

#### Numbers 14:43 For Amalek and the Canaanite are there in front of you, and you shall fall by the sword, because you were turned resisting the persuasion by the LORD, and {will not be the LORD} with you. 

#### Numbers 14:44 And forcing through, they ascended upon the top of the mountain. But the ark of the covenant of the LORD, and Moses did not move from out of the midst of the camp. 

#### Numbers 14:45 And {came down Amalekite}, and the Canaanite lying in wait in that mountain, and they routed them, and they slew them unto Hormah. 

#### Numbers 15:1 And the LORD spoke to Moses, saying, 

#### Numbers 15:2 Speak to the sons of Israel, and say to them, Whenever you should enter into the land of your dwelling, which I give to you, 

#### Numbers 15:3 and you shall offer yield offerings to the LORD, or a whole burnt-offering, or sacrifice offering to magnify a vow, or concerning a voluntary offering, or in your holiday feasts, you shall offer a scent of pleasant aroma to the LORD, either from the oxen or from the sheep. 

#### Numbers 15:4 That {shall bring the one offering} his gift to the LORD being a sacrifice of fine flour -- the tenth of the ephah, being prepared in olive oil, in a fourth of the hin. 

#### Numbers 15:5 And wine for a libation offering, the fourth of the hin, you shall offer upon the whole burnt-offering, or upon the sacrifice offering to the {lamb one}. 

#### Numbers 15:6 And for the ram, whenever you offer it for a whole burnt-offering or for a sacrifice offering, you shall prepare a sacrifice of fine flour -- two tenths being prepared in olive oil, the third of the hin. 

#### Numbers 15:7 And wine for a libation, the third of the hin, you shall offer for a scent of pleasant aroma to the LORD. 

#### Numbers 15:8 But if from the oxen you should offer for a whole burnt-offering, or for a sacrifice offering to magnify a vow, or for a deliverance offering to the LORD, 

#### Numbers 15:9 then he shall bring with the calf for a sacrifice offering of fine flour, three tenths being prepared in olive oil, a half of the hin. 

#### Numbers 15:10 And the wine for a libation, the half of the hin -- a yield offering scent of pleasant aroma to the LORD. 

#### Numbers 15:11 Thus you shall offer for the {calf one}, or the {ram one}, or the {lamb one} from the sheep, or a kid of the goats. 

#### Numbers 15:12 According to the number which ever you should offer, so you shall do to the one, according to their number. 

#### Numbers 15:13 Every native born shall offer thus, such as to bring yield offerings for a scent of pleasant aroma to the LORD. 

#### Numbers 15:14 And if a foreigner among you should unite in your land, or who ever was born to you among your generations, and he shall offer a yield offering scent of pleasant aroma to the LORD, in which manner you do yourselves -- so shall {offer the congregation} to the LORD. 

#### Numbers 15:15 {law One} will be to you and to the foreigners lying near to you, {law an eternal} unto your generations. As you, also the foreigner will be before the LORD. 

#### Numbers 15:16 {law one There shall be}, and {ordinance one there shall be} to you and to the foreigner lying near to you. 

#### Numbers 15:17 And the LORD spoke to Moses, saying, 

#### Numbers 15:18 Speak to the sons of Israel! And you shall say to them, In your entering into the land, into which I bring you there, 

#### Numbers 15:19 that it will be whenever you yourselves should eat from the bread loaves of the land, you shall remove a cut-away portion as a separation offering to the LORD, a first-fruit of your batch of dough. 

#### Numbers 15:20 {bread You shall separate} as a cut-away portion to him. As a cut-away portion from the threshing-floor, thus shall you remove it. 

#### Numbers 15:21 As first-fruit of your batch, even you shall give it to the LORD as cut-away portion for your generations. 

#### Numbers 15:22 And whenever you should miss entirely, and should not observe all these commandments which the LORD spoke to Moses; 

#### Numbers 15:23 as the LORD gave orders for you by the hand of Moses, from the day of which the LORD gave orders to you and beyond unto your generations; 

#### Numbers 15:24 that it shall be if from the eyes of the congregation it should happen unintentionally, then {shall offer all the congregation} {calf one} from the oxen, unblemished, for a whole burnt-offering, for a scent of pleasant aroma to the LORD, and this sacrifice offering, and its libation, according to its arrangement, and {winter yearling from out of the goats one} for a sin offering. 

#### Numbers 15:25 And {shall make atonement the priest} for all the congregation of the sons of Israel, and it shall be forgiven them, for it is unintentional. And they brought their gift, a yield offering to the LORD for their sins, before the LORD for their unintentional sins. 

#### Numbers 15:26 And {it shall be forgiven to all the congregation of the sons of Israel}, and to the foreigner lying near to you, for to all the people it is unintentional. 

#### Numbers 15:27 And if {soul one} should sin unintentionally, he shall lead forward one goat of a year old for a sin offering. 

#### Numbers 15:28 And {shall atone the priest} for the soul of the one acting unintentionally, and sinning unintentionally before the LORD, to atone for him, and to forgive him. 

#### Numbers 15:29 To the native inhabitant among the sons of Israel, and to the foreigner lying near to them, {law one there shall be} to them, who ever should do it unintentionally. 

#### Numbers 15:30 And the soul who shall do a thing by hand through pride -- of the native born, or of the foreigners -- {God this one provokes}, and {shall be utterly destroyed that soul} from out of its people, 

#### Numbers 15:31 for the word of the LORD he treated as worthless, and his commandments he effaced; by obliteration {shall be obliterated that soul}; his sin be on him. 

#### Numbers 15:32 And {were the sons of Israel} in the wilderness, and they found a man collecting together wood on the day of the Sabbath. 

#### Numbers 15:33 And {led him forward the ones finding him collecting wood} to Moses and Aaron, and to all the congregation of the sons of Israel. 

#### Numbers 15:34 And they put him under guard, {not for they did} interpret what they should do with him. 

#### Numbers 15:35 And the LORD spoke to Moses, saying, Unto death put to death the man! You shall stone him with stones -- all the congregation outside the camp. 

#### Numbers 15:36 And {led him all the congregation} outside the camp; and they stoned him, as the LORD gave orders to Moses. 

#### Numbers 15:37 And the LORD spoke to Moses, saying, 

#### Numbers 15:38 Speak to the sons of Israel! And you shall say to them, and let them make for themselves decorative hems upon the borders of their cloaks throughout their generations. And you shall place upon the decorative hems of the borders yarn of blue. 

#### Numbers 15:39 And it will be to you in the decorative hems, that as you shall see them, then {shall be remembered all the commandments of the LORD}. And you shall do them, and you shall not turn aside after your own considerations, and after your eyes in which you fornicate after them, 

#### Numbers 15:40 so that you should remember and should do all my commandments. And you shall be holy to your God. 

#### Numbers 15:41 I am the LORD your God, the one leading you from out of the land of Egypt, to be your God. I am the LORD your God. 

#### Numbers 16:1 And Korah spoke, the son of Izhar, son of Kohath son of Levi; and Dathan and Abiram sons of Eliab, and On son of Peleth son of Reuben. 

#### Numbers 16:2 And they rose up before Moses, and men of the sons of Israel -- fifty and two hundred, chiefs of the congregation, summoned counselors, and {men famous}. 

#### Numbers 16:3 They stood together against Moses and Aaron. And said to them, Let this suffice to you, that all the congregation are all holy -- and {is among them the LORD}; and why do you stand against the congregation of the LORD? 

#### Numbers 16:4 And hearing, Moses fell upon his face. 

#### Numbers 16:5 And he spoke to Korah and to all the congregation, saying, {has visited and knows God} the ones being his; and the ones holy he led to himself; and whom he chose not for himself, he led not to himself. 

#### Numbers 16:6 This you do! You take to yourselves censers, Korah and all his gathering! 

#### Numbers 16:7 And put {upon them fire}! And put upon them incense before the LORD tomorrow! And it will be the man who ever the LORD should choose, this one shall be holy. Let it be suitable to you sons of Levi! 

#### Numbers 16:8 And Moses said to Korah, Listen to me sons of Levi! 

#### Numbers 16:9 {a small thing Is this} for you, that {separated you God} from the congregation of Israel, and led you to himself to officiate the ministrations of the tent of the LORD, and to stand before the congregation to serve to them? 

#### Numbers 16:10 And he led you, and all your brethren of the sons of Levi with you, and do you seek to officiate as priest also? 

#### Numbers 16:11 Thus you and all your gathering are gathering together against God. And {Aaron who is} that you complain against him? 

#### Numbers 16:12 And Moses sent to call Dathan and Abiram, sons of Eliab. And they said, We do not ascend to you. 

#### Numbers 16:13 Is this a small thing that you led us from a land flowing milk and honey, to kill us in the wilderness, that you rule us, and be a ruler, 

#### Numbers 16:14 and into a land flowing milk and honey you brought us, and you gave to us a lot of inheritance of field and vineyards? {the eyes of those men Would you have cut out}? We do not ascend. 

#### Numbers 16:15 And Moses was weighed down exceedingly. And he said to the LORD, Do not take heed to their sacrifice, {not the desire of any one of them I have taken}, nor inflicted evil on any one of them. 

#### Numbers 16:16 And Moses said to Korah, Sanctify your congregation, and come prepared before the LORD, you and they, and Aaron tomorrow! 

#### Numbers 16:17 And let {take each} his censer! and you shall put {upon them incense}, and {shall bring before the LORD each} his censer, fifty and two hundred censers; and you and Aaron each shall bring his censer. 

#### Numbers 16:18 And {took each} his own censer, and they put upon them fire, and they put upon them incense. And stood by the doors of the tent of testimony Moses and Aaron. 

#### Numbers 16:19 And {rose up together against them Korah}, the whole of his congregation, by the door of the tent of the testimony. And appeared the glory of the LORD to all the congregation. 

#### Numbers 16:20 And the LORD spoke to Moses and Aaron, saying, 

#### Numbers 16:21 Sever yourselves from the midst of this congregation! and I will completely consume them at once. 

#### Numbers 16:22 And they fell upon their face. And they said, The God, the God of the spirits and of all flesh, if {man one} sinned, shall there be upon all the congregation the anger of the LORD? 

#### Numbers 16:23 And the LORD said to Moses, saying, 

#### Numbers 16:24 Speak to the congregation! saying, Withdraw round about from the congregation of Korah, and Dathan, and Abiram! 

#### Numbers 16:25 And Moses rose up, and went to Dathan and Abiram. And went with him all the elders of Israel. 

#### Numbers 16:26 And he spoke to the congregation, saying, Sever from the tents {men recalcitrant of these}, and do not touch of all as much as is to them. You should not be destroyed together in all their sin. 

#### Numbers 16:27 And {left from the tent of Korah both Dathan and Abiram} round about. And Dathan and Abiram came forth and stood by the doors of their tents, and their wives, and their children, and their belongings. 

#### Numbers 16:28 And Moses said, By this you shall know that the LORD sent me to execute all these works, that they are not of myself. 

#### Numbers 16:29 If by the common death of all men these shall die; or if according to the review of all men the visit of death shall be theirs -- {has not then the LORD} sent me. 

#### Numbers 16:30 But if by a visible manifestation the LORD shall show, and {opening the earth} its mouth shall swallow them, and their houses, and their tents, and all as much as is theirs, and they shall go down alive into Hades, then you shall know that {provoked these men} the LORD. 

#### Numbers 16:31 And as he ceased speaking all these words, {was torn the earth} underneath them. 

#### Numbers 16:32 And {was opened the earth}, and it swallowed them, and their houses, and all the men of the ones being with Korah, and all their cattle. 

#### Numbers 16:33 And these went down, and all as many as is to them, alive into Hades; and {covered them the earth}, and they were destroyed from out of the midst of the congregation. 

#### Numbers 16:34 And all Israel round about them fled from their sound, saying, Lest at any time {shall swallow us the earth}. 

#### Numbers 16:35 And fire came forth from the LORD, and it devoured the fifty and two hundred men of the ones offering the incense. 

#### Numbers 16:36 And the LORD spoke to Moses, saying, 

#### Numbers 16:37 Speak to Eleazar the son of Aaron the priest, Do away with the censers from the midst of the ones having been incinerated, and {fire alien sow this} there! 

#### Numbers 16:38 For they sanctified the censers of these sinners by their lives. And make them into scales hammered out for adornment to the altar! for they were brought near before the LORD, and were sanctified. And they became for a sign to the sons of Israel. 

#### Numbers 16:39 And {took Eleazar son of Aaron the priest} the censers of brass, as many as {brought near the men having been incinerated}; and they added them as an adornment to the altar, 

#### Numbers 16:40 as a memorial for the sons of Israel, how that not {come forward should anyone foreign who not is} of the seed of Aaron, to place incense before the LORD; so that he shall not be as Korah, and the ones conspiring with him, as the LORD spoke by the hand of Moses to him. 

#### Numbers 16:41 And {grumbled the sons of Israel} the next day against Moses and Aaron, saying, You have killed the people of the LORD. 

#### Numbers 16:42 And it came to pass in the gathering together the congregation against Moses and Aaron, that they advanced against the tent of the testimony; and thus {covered it the cloud}, and there appeared the glory of the LORD. 

#### Numbers 16:43 And {entered Moses and Aaron} by the front of the tent of the testimony. 

#### Numbers 16:44 And the LORD spoke to Moses, saying, 

#### Numbers 16:45 Withdraw from the midst of this congregation, and I shall completely consume them at once. And they fell upon their face. 

#### Numbers 16:46 And Moses said to Aaron, Take the censer, and place upon it fire from the altar, and put upon it incense, and carry it quickly into the congregation, and make atonement for them! {came forth For anger} from the face of the LORD; it has begun to devastate the people. 

#### Numbers 16:47 And Aaron took just as {spoke to him Moses}; and he ran into the congregation, for already had commenced the devastation among the people. And he put the incense, and he made atonement for the people. 

#### Numbers 16:48 And he stood between the ones having died and the ones living, and {abated the devastation}. 

#### Numbers 16:49 And {were the ones having died in the devastation} fourteen thousand and seven hundred, apart from the ones having died because of Korah. 

#### Numbers 16:50 And Aaron returned to Moses at the door of the tent of the testimony, and {abated the devastation}. 

#### Numbers 17:1 And the LORD spoke to Moses, saying, 

#### Numbers 17:2 Speak to the sons of Israel! And take from them a rod! a rod according to the houses of the patrimony, from all their rulers, according to the houses of their patrimony -- twelve rods. And for each {the name inscribe} upon his rod! 

#### Numbers 17:3 And the name of Aaron you shall inscribe upon the rod of Levi. For it is {rod one} according to the tribe of the house of their patrimony. 

#### Numbers 17:4 And you shall put them in the tent of the testimony, over against the testimony, in which I will be made known to you there. 

#### Numbers 17:5 And it shall be the man who ever I should choose him, his rod shall sprout forth. And I will remove from you the grumbling of the sons of Israel, as much as they grumble against you. 

#### Numbers 17:6 And Moses spoke to the sons of Israel; and {gave to him all the rulers} their rod -- to the {ruler one} {rod one}, according to the ruler, according to the houses of their patrimony -- twelve rods. And the rod of Aaron was in the midst of their rods. 

#### Numbers 17:7 And Moses put aside the rods before the LORD in the tent of the testimony. 

#### Numbers 17:8 And it came to pass in the next day, that Moses entered into the tent of the testimony; and behold, {sprouted the rod of Aaron} for the house of Levi; and it brought forth a bud, and it blossomed a flower, and sprouted walnuts. 

#### Numbers 17:9 And Moses brought forth all the rods from in front of the LORD to all the sons of Israel. And they saw, and {took each} his rod. 

#### Numbers 17:10 And the LORD said to Moses, Put aside the rod of Aaron before the testimony! for preservation for a sign to the sons of the unhearing. And let cease their grumbling of me! so in no way they shall die. 

#### Numbers 17:11 And {did Moses and Aaron} as the LORD gave orders to Moses -- so they did. 

#### Numbers 17:12 And {said the sons of Israel} to Moses, saying, Behold, we have been completely consumed, we have been destroyed, we all have been uselessly consumed, 

#### Numbers 17:13 every one touching the tent of the LORD dies. Until completion should we die? 

#### Numbers 18:1 And the LORD said to Aaron, You and your sons, and the house of your father with you shall take the sins associated with the holies; and you and your sons with you shall take the sins associated with your priesthood. 

#### Numbers 18:2 And your brethren the tribe of Levi, the people of your father, you lead them to yourself, and let them be added to you, and let them officiate to you! even you and your sons with you before the tent of the testimony. 

#### Numbers 18:3 And they shall guard your watches, and the watches of the tent; except for the items of the holies and for the altar they shall not draw near, so that they shall not die, even these and you. 

#### Numbers 18:4 And they shall be added to you, and shall guard the watches of the tent of the testimony, concerning all the ministrations of the tent. And the foreigner shall not draw near to you. 

#### Numbers 18:5 And you shall guard the watches of the holy places, and the watches of the altar. And there shall not be yet rage among the sons of Israel. 

#### Numbers 18:6 And behold, I have taken your brethren the Levites from the midst of the sons of Israel as a gift being given to the LORD, to officiate the ministrations of the tent of the testimony. 

#### Numbers 18:7 And you and your sons after you shall observe your priesthood according to every manner of the altar, and the thing within the veil; and you shall officiate the ministrations as a gift of your priesthood. And the foreigner going to it shall die. 

#### Numbers 18:8 And the LORD spoke to Aaron, And behold, I give to you the preservation of my first-fruits of all the things having been sanctified by the sons of Israel. To you I give them as an honor, and to your sons {law for an eternal}. 

#### Numbers 18:9 And let this be to you from the {having been sanctified holy things} of the yield offerings, from all their gifts, and from all their sacrifices, and from all their trespass offerings, and from all their sin offerings! as many as they give back to me of all of the holy things, it shall be to you and to your sons. 

#### Numbers 18:10 In the holy of the holies, you eat them! Let every male eat them! They shall be holy to you. 

#### Numbers 18:11 And this will be to you of the first-fruits of their gifts, from all the increase offerings of the sons of Israel. To you I have given them, and to your sons, and to your daughters after you -- {law an eternal}. Every clean person in your house shall eat them. 

#### Numbers 18:12 Every first-fruit of olive oil, and every first-fruit of wine, and {of grain of their first-fruit}, as many things as they should give to the LORD, to you I have given them. 

#### Numbers 18:13 {the first produce All}, as many things as are in their land, as many things as they should bring to the LORD, it will be yours; every clean person in your house shall eat them. 

#### Numbers 18:14 Every thing being devoted to consumption by the sons of Israel shall be to you. 

#### Numbers 18:15 And every thing opening wide the womb of all flesh, as many things as they offer to the LORD, from man unto beast, it will be to you; only with ransoms you shall ransom the first-born of men; and the first-born of the {cattle unclean} you shall ransom. 

#### Numbers 18:16 And the ransoming of him from a month old -- the price is five shekels, according to the {shekel holy} -- twenty oboli they are worth. 

#### Numbers 18:17 Except the first-born of calves, and the first-born of sheep, and the first-born of goats you shall not ransom, {holy they are}. And their blood you shall pour upon the altar, and the fat you shall offer as a yield offering for a scent of pleasant aroma to the LORD. 

#### Numbers 18:18 And the meats will be yours, as also the breast of the increase offering. And accordingly the {shoulder right} will be yours. 

#### Numbers 18:19 Every cut-away portion of the holy things, as many things as {should remove the sons of Israel} to the LORD, to you I have given, and to your sons, and to your daughters after you -- {law an eternal}. {covenant of salt It is an eternal} before the LORD to you and to your seed after you. 

#### Numbers 18:20 And the LORD spoke to Aaron, In their land you shall not be an heir, and a portion shall not be to you among them; for I am your portion and your inheritance in the midst of the sons of Israel. 

#### Numbers 18:21 And to the sons of Levi, behold, I have given every tenth part in Israel by lot for their ministrations, as much as they shall officiate the ministration in the tent of the testimony. 

#### Numbers 18:22 And {shall not come forward still the sons of Israel} into the tent of the testimony, so as to take on sin causing death. 

#### Numbers 18:23 And {shall officiate the Levite himself} the ministration of the tent of the testimony; and they shall take their sins. {law It is an eternal} into their generations. And in the midst of the sons of Israel they shall not be an heir of an inheritance, 

#### Numbers 18:24 for the tenth parts of the sons of Israel, as many things as they should separate to the LORD, a cut-away portion I give to the Levites by lot. On account of this I have said to them, Among the midst of the sons of Israel they shall not be an heir of a lot. 

#### Numbers 18:25 And the LORD spoke to Moses, saying, 

#### Numbers 18:26 And to the Levites you shall speak, and you shall say to them, If you should take from the sons of Israel the tenth part, which I have given to you from them for a lot, then you shall remove to yourselves from it a cut-away portion to the LORD, a tenth of the tenth part. 

#### Numbers 18:27 And {shall be considered for you your cut-away portions} as grain from the threshing-floor, and as a cut-away portion from the wine-vat. 

#### Numbers 18:28 So you shall remove, even you yourselves, from all the cut-away portions of the LORD, from all your tenth parts; as many things as you should take from the sons of Israel; and you shall give of them a cut-away portion to the LORD, through Aaron the priest. 

#### Numbers 18:29 From all your gifts you shall remove a cut-away portion to the LORD, from all the first-fruits having been sanctified of it. 

#### Numbers 18:30 And you shall say to them, Whenever you should remove the first-fruit from it, then shall it be considered the Levites as produce from the threshing-floor, and as produce from the wine-vat. 

#### Numbers 18:31 And you shall eat it in any place, you and your households; for {the wage this to you is} for your ministrations of the things in the tent of the testimony. 

#### Numbers 18:32 And you shall not take {because of it sin}, in that you should remove the first-fruit from it. And the holy things of the sons of Israel you shall not profane, that you should not die. 

#### Numbers 19:1 And the LORD spoke to Moses and Aaron, saying, 

#### Numbers 19:2 This is a distinction of the law, as many things as the LORD ordered, saying, Speak to the sons of Israel! And let them take to you {heifer reddish an unblemished}! which {is not on it a blemish}, and which {was not put upon it a yoke}. 

#### Numbers 19:3 And you shall give it to Eleazar the priest; and they shall lead it outside the camp, and they shall slay her before him. 

#### Numbers 19:4 And Eleazar shall take of her blood, and he shall sprinkle it before the front of the tent of the testimony of her blood seven times. 

#### Numbers 19:5 And you shall incinerate her before him, and her skin, and her meats, and her blood with her dung shall be incinerated. 

#### Numbers 19:6 And {shall take the priest} wood of cedar, and hyssop, and scarlet; and they shall put them in the midst of the burning of the heifer. 

#### Numbers 19:7 And {shall wash his garments the priest}, and bathe his body in water; and after these things he shall enter into the camp, and {shall be unclean the priest} until evening. 

#### Numbers 19:8 And the one incinerating her shall wash his garments in water, and shall bathe his body in water, and shall be unclean until evening. 

#### Numbers 19:9 And {shall gather together man a clean} the ashes of the heifer, and shall put them aside outside the camp in {place a clean}. And it shall be for the congregation of the sons of Israel for preservation. {water of sprinkling It is a purification}. 

#### Numbers 19:10 And the one gathering the ashes of the heifer shall wash his garments, and will be unclean until evening. And it will be to the sons of Israel, and to the foreigners lying nearby in the midst of you {law an eternal}. 

#### Numbers 19:11 The one touching {having died any departed soul of a man} will be unclean seven days. 

#### Numbers 19:12 This one shall be purified on the {day third} and the {day seventh}, and he will be clean. But if he should not be purified on the {day third}, and on the {day seventh}, he will not be clean. 

#### Numbers 19:13 Every one touching the one having died of the departed soul of a man, if he should die, and the other should not have been purified, the tent of the LORD is defiled; and {shall be obliterated that soul} from Israel, for water of sprinkling was not sprinkled about upon him; he is unclean; {still uncleanness his with him is}. 

#### Numbers 19:14 And this is the law. A man, if he should die in a house, every one entering into the house, and as many as are in the house, will be unclean seven days. 

#### Numbers 19:15 And every item being open, as many as have not {with a bond been bound} upon it is unclean. 

#### Numbers 19:16 And all who ever should touch upon the face of the plain one slain, or a dead corpse, or of a bone of mankind, or tomb, for seven days he will be unclean. 

#### Numbers 19:17 And they shall take for the unclean some of the ashes of the thing having been incinerated for the purification, and shall pour out upon it {water living} into a utensil. 

#### Numbers 19:18 And {shall take hyssop and shall dip it into the water man a clean}, and sprinkle about upon the house, and upon the utensils, and upon the souls, as many as might be there, and upon the one touching the bone of mankind, or of the slain, or of the one having died, or of the tomb. 

#### Numbers 19:19 And {shall sprinkle about the clean man} upon the unclean on the {day third}, and on the {day seventh}; and he shall be purified on the {day seventh}; and he shall wash his garments, and he shall bathe in water, and he will be unclean until evening. 

#### Numbers 19:20 And a man who ever should be defiled, and shall not be purified, {shall be utterly destroyed soul that} from the midst of the congregation, for the holy things of the LORD he defiled, for the water of sprinkling was not sprinkled about upon him; he is unclean. 

#### Numbers 19:21 And it shall be to you {law an eternal}. And the one sprinkling about the water of sprinkling, he shall wash his garments; and the one touching the water of sprinkling, he will be unclean until evening. 

#### Numbers 19:22 And anything what ever should be touched by him (the one being unclean) shall be unclean until evening. 

#### Numbers 20:1 And {came of the sons of Israel all the congregation} into the wilderness of Zin, in the {month first}; and {stayed the people} in Kadesh. And {came to an end there Miriam}, and she was entombed there. 

#### Numbers 20:2 And there was no water for the congregation, and they gathered themselves against Moses and Aaron. 

#### Numbers 20:3 And {reviled the people} against Moses, saying, Ought we died in the destruction of our brothers before the LORD. 

#### Numbers 20:4 And why did you lead the congregation of the LORD into this wilderness, to kill us, and our cattle? 

#### Numbers 20:5 And why is this you led us from Egypt to come unto {place this bad}? A place which you cannot sow, nor is there fig-trees, nor grapevines, nor pomegranates, nor is there water to drink. 

#### Numbers 20:6 And {came Moses and Aaron} from in front of the congregation, unto the door of the tent of the testimony, and they fell upon their face. And {appeared the glory of the LORD} to them. 

#### Numbers 20:7 And the LORD spoke to Moses, saying, 

#### Numbers 20:8 Take the rod, and call an assembly of the congregation, you and Aaron your brother! And speak to the rock before them! and it shall give of its waters; and you shall bring forth to them water from out of the rock, and you shall give to drink the congregation and their cattle. 

#### Numbers 20:9 And Moses took the rod before the LORD, as the LORD gave orders to him. 

#### Numbers 20:10 And {held an assembly Moses and Aaron} of the congregation before the rock. And he said to them, Hear me! O ones resisting persuasion; must {from out of this rock we bring forth to you water}? 

#### Numbers 20:11 And Moses lifting his hand, struck the rock with the rod twice, and came forth {water much}, and {drank the congregation}, and their cattle. 

#### Numbers 20:12 And the LORD said to Moses and Aaron, Because you did not trust in me to sanctify me before the sons of Israel, because of this {shall not bring you yourselves} this congregation into the land which I have given to them. 

#### Numbers 20:13 This is the water of dispute, for {were reviled the sons of Israel} before the LORD, and he was sanctified among them. 

#### Numbers 20:14 And Moses sent messengers from Kadesh to the king of Edom, saying, Thus says your brother Israel, You have knowledge of all the trouble finding us, 

#### Numbers 20:15 and how {went down our fathers} into Egypt, and we sojourned in Egypt {days many}, and {inflicted evil on us the Egyptians} and our fathers. 

#### Numbers 20:16 And we yelled out to the LORD, and the LORD listened to our voice. And sending an angel, he led us from out of Egypt. And now we are in Kadesh, a city of a part of your borders. 

#### Numbers 20:17 We shall go through your land. We will not go through the fields, nor through the vineyards, nor shall we drink water from out of your cistern. {way by the royal We shall go}. We shall not turn aside to the right nor left, until whenever we should have gone by your borders. 

#### Numbers 20:18 And {said to him Edom}, You shall not go through mine, and if otherwise, in war I shall come forth to meet with you. 

#### Numbers 20:19 And {say to him the sons of Israel}, {by the mountain We shall go}. And if {of your water we drink}, both I and my cattle, I will give the value of it to you. But the thing is nothing, {by the mountain we shall go}. 

#### Numbers 20:20 And he said, You shall not go through of mine. And Edom came forth to meet with him with {multitude a heavy}, and with {hand a strong}. 

#### Numbers 20:21 And {did not want Edom} to give permission to Israel to go through his borders. And Israel turned aside from him. 

#### Numbers 20:22 And they departed from Kadesh. And {came the sons of Israel}, all the congregation, unto Hor the mountain. 

#### Numbers 20:23 And the LORD said to Moses and Aaron in Hor, in the mountain, upon the borders of the land of Edom, saying, 

#### Numbers 20:24 Let Aaron be added to his people, for in no way should he enter into the land which I have given to the sons of Israel, because you provoked me at the Water of Dispute. 

#### Numbers 20:25 Take Aaron and Eleazar his son, and haul them unto Hor the mountain! 

#### Numbers 20:26 And take off of Aaron his apparel, and put it on Eleazar his son! And Aaron, having been added to his people, let him die there! 

#### Numbers 20:27 And Moses did as the LORD gave orders to him, and he hauled them unto Hor the mountain before all the congregation. 

#### Numbers 20:28 And Moses stripped off Aaron his garments, and he put them on Eleazar his son. And Aaron died upon the top of the mountain. And {came down Moses and Eleazar} from the mountain. 

#### Numbers 20:29 And {saw all the congregation} that Aaron was loosed, and {wept for Aaron thirty days all the house of Israel}. 

#### Numbers 21:1 And {heard the Canaanite king Arad}, the one dwelling by the wilderness, that Israel came by the way to Atharin; and he waged war against Israel, and they carried away captive some of them into captivity. 

#### Numbers 21:2 And Israel vowed a vow to the LORD, and said, If you should deliver up to me this people under my hand, I will devote him to consumption and his cities. 

#### Numbers 21:3 And the LORD listened to the voice of Israel, and he delivered up the Canaanite unto his hand, and he devoted him to consumption, and his cities. And they called the name of that place, Anathema. 

#### Numbers 21:4 And departing from Hor the mountain, by way unto the {sea red}, they encircled the land of Edom, and {became faint-hearted the people} in the way. 

#### Numbers 21:5 And {spoke ill the people} against God, and against Moses, saying, Why did you lead us out of Egypt to kill us in the wilderness? For there is no bread nor water; and our soul loathes in {bread this empty}. 

#### Numbers 21:6 And the LORD sent to the people the serpents, the ones causing death; and they bit the people, and {died people many} of the sons of Israel. 

#### Numbers 21:7 And {came the people} to Moses, saying that, We sinned, for we spoke ill against the LORD, and against you; make a vow then to the LORD that he remove from us the serpent! And Moses made a vow for the people. 

#### Numbers 21:8 And the LORD said to Moses, Make to yourself a serpent of brass, and put it upon a sign. And all having been bitten, beholding it, shall live. 

#### Numbers 21:9 And Moses made a serpent of brass, and set it upon a sign. And it came to pass whenever {bit a serpent} a man, and he looked upon the serpent of brass, that he lived. 

#### Numbers 21:10 And {departed the sons of Israel}, and they camped in Oboth. 

#### Numbers 21:11 And lifting away from Oboth, they camped in Ije-abarim in the wilderness, which is against the face of Moab according to the east of the sun. 

#### Numbers 21:12 From there they departed and camped at the Ravine of Zared. 

#### Numbers 21:13 From there departing they camped in the other side of Arnon, in the wilderness protruding from the borders of the Amorites. {is For Arnon} the boundary of Moab between Moab and the Amorite. 

#### Numbers 21:14 On account of this it says in the {scroll war} of the LORD, Zoob set ablaze, and the rushing streams of Arnon. 

#### Numbers 21:15 And {the rushing streams he established} to settle Ar, and it lies near to the boundaries of Moab. 

#### Numbers 21:16 And from there they came to The Well. This is the well which the LORD said to Moses, Gather together the people, and I will give to them water. 

#### Numbers 21:17 Then Israel sang this song at The Well, Take the lead to him, O Well; 

#### Numbers 21:18 {dug it rulers}; {quarried kings of nations} in their kingdoms, in their dominating. And from Well they went unto Mattanah. 

#### Numbers 21:19 And from Mattanah to Nahaliel. And from Nahaliel to Bamoth. And from Bamoth to Janen which is in the plain of Moab, seen from the top of the dressing of the stone -- the place looking down at the face of the wilderness. 

#### Numbers 21:20 And Israel sent ambassadors to Sihon king of the Amorites, saying, 

#### Numbers 21:21 We shall go through your land; we will not turn aside, neither into a field, nor into a vineyard; 

#### Numbers 21:22 nor shall we drink water from out of your well. {way the royal We will go by}, until whenever we pass by your borders. 

#### Numbers 21:23 And {did not give permission Sihon} to Israel to go through his borders. And Sihon gathered together all his people, and came forth to deploy against Israel in the wilderness. And he came unto Jahaz, and deployed against Israel. 

#### Numbers 21:24 And {struck him Israel} with a carnage of the sword; and they dominated his land from Arnon unto Jabbok, unto the sons of Ammon. For Jazer {the boundaries of the sons of Ammon is}. 

#### Numbers 21:25 And Israel took all these cities, and Israel dwelt in all the cities of the Amorites, in Heshbon, and in all the ones falling in with it. 

#### Numbers 21:26 {is For Heshbon} the city of Sihon the king of the Amorites. And this one waged war against the king of Moab formerly. And they took all his land from his hand unto Arnon. 

#### Numbers 21:27 On account of this {say the ones speaking enigmas}, Come into Heshbon, for {should have been built and should have been carefully prepared the city of Sihon}; 

#### Numbers 21:28 for fire came forth from out of Heshbon, a flame from out of the city of Sihon, and it devoured unto Moab, and swallowed down the monuments of Arnon. 

#### Numbers 21:29 Woe to you Moab. You are destroyed people of Chemosh. {were rendered over Their sons} to be preserved, and their daughters captives to the king of the Amorites -- Sihon. 

#### Numbers 21:30 And their seed shall perish -- Heshbon unto Dibon. And their women still burn a fire over Moab. 

#### Numbers 21:31 And Israel dwelt in all the cities of the Amorites. 

#### Numbers 21:32 And Moses sent to survey Jaazer, and they overtook it, and her towns, and they cast out the Amorite dwelling there. 

#### Numbers 21:33 And having turned they ascended the way unto Bashan. And came forth Og king of Bashan to meet with them, and all his people for war in Edrei. 

#### Numbers 21:34 And the LORD said to Moses, Do not fear him, for into your hands I have delivered him, and all his people, and all his land; and you shall do to him as you did to Sihon king of the Amorites, who dwelt in Heshbon. 

#### Numbers 21:35 And he struck him and his sons, and all his people, until there was not any of his being left behind for taking alive; and they inherited his land. 

#### Numbers 22:1 And departing, the sons of Israel camped upon the descent of Moab by the Jordan near Jericho. 

#### Numbers 22:2 And {was seeing Balak son of Zippor} all as many things as Israel did to the Amorites. 

#### Numbers 22:3 And Moab feared the people exceedingly, for they were many. And Moab loathed of the face of the sons of Israel. 

#### Numbers 22:4 And Moab said to the council of elders of Midian, Now {shall lick up this congregation} all the ones round about us, as {licks up the calf} the green grass from the plain. And Balak son of Zippor {king of Moab was} at that time. 

#### Numbers 22:5 And he sent ambassadors to Balaam son of Beor, to Pethor, which is upon the river of the land of the sons of his people, to call him, saying, Behold, a people have come forth from out of Egypt. And behold, it covers up the appearance of the earth, and this people lie in wait next to me. 

#### Numbers 22:6 And now come, curse for me this people! for {stronger than me it is}. If we should be able to strike at them, then I will cast them from out of the land. For I know that whom ever you should bless, they are blessed; and whom ever you should curse, they are cursed. 

#### Numbers 22:7 And {went the council of elders of Moab}, and the council of elders of Midian, with the oracles in their hands. And they came to Balaam, and they spoke to him the words of Balak. 

#### Numbers 22:8 And he said to them, You rest up here the night, and I will answer you the things which ever the LORD should speak to me! And {stayed the rulers of Moab} with Balaam. 

#### Numbers 22:9 And God came to Balaam, and he said to him, What do these men want with you? 

#### Numbers 22:10 And Balaam said to God, Balak son of Zippor king of Moab sent them to me, saying, 

#### Numbers 22:11 Behold, a people come forth from out of Egypt, and covered the appearance of the earth, and now come curse it for me! if it is so I shall be able to strike it, and I will cast it out. 

#### Numbers 22:12 And God said to Balaam, You shall not go with them, nor shall you curse the people; for they are blessed. 

#### Numbers 22:13 And Balaam rising in the morning, said to the rulers of Balak, You run to your land, {does not allow me the LORD} to go with you. 

#### Numbers 22:14 And rising, the rulers of Moab came to Balak. And they said, {does not want Balaam} to go with us. 

#### Numbers 22:15 And {added again Balak} to send {rulers many}, and ones more important than these. 

#### Numbers 22:16 And they came to Balaam, and they say to him, Thus says Balak the son of Zippor, I deem you worthy, you should not be reluctant to come to me, 

#### Numbers 22:17 for highly valued I will esteem you, and as many things as you should say to me I will do for you. Now come, accurse for me this people! 

#### Numbers 22:18 And Balaam answered and said to the rulers of Balak, If {shall give to me Balak full house his} of silver and gold, I shall not be able to violate the word of the LORD God, to do it small or great. 

#### Numbers 22:19 And now remain behind here, even you this night! and I will know what the LORD shall add to speak to me. 

#### Numbers 22:20 And God came to Balaam at night, and said to him, If {calling you are at hand these men}, rising up you follow them, but the saying which ever I speak to you, this you observe! 

#### Numbers 22:21 And Balaam rising in the morning, saddled his donkey, and went with the rulers of Moab. 

#### Numbers 22:22 And {was provoked to anger in rage God} that he himself went. And {rose up the angel of God} in the way to stand in the way as an adversary against him. And he mounted upon his donkey, and {two servants his} with him. 

#### Numbers 22:23 And {seeing the donkey} the angel of God opposing it in the way, and the broadsword being unsheathed in his hand, that {turned aside the donkey} from the way, and went into the plain. And he struck the donkey to straighten it in the way. 

#### Numbers 22:24 And {stood the angel of God} in the furrows of the grapevines, a barrier here on this side and a barrier here on that side. 

#### Numbers 22:25 And {seeing the donkey} the angel of God, pressed herself against the wall, and it squeezed the foot of Balaam to the wall, and he added again to crack the whip on her. 

#### Numbers 22:26 And {proceeded the angel of God} going forth. And he stood in {place a narrow} for which there was no turning aside right or left. 

#### Numbers 22:27 And {seeing the donkey} the angel of God, sat down underneath Balaam. And Balaam became enraged, and beat the donkey with the rod. 

#### Numbers 22:28 And God opened the mouth of the donkey, and she says to Balaam, What did I do to you that you have hit me this third time? 

#### Numbers 22:29 And Balaam said to the donkey that, You have mocked me, and if I had a sword in my hand, already I would have stabbed you. 

#### Numbers 22:30 And {says the donkey} to Balaam, Am I not your donkey, upon which you mounted from your youth, until today's day? Have {to neglect by overlooking I acted} you thus? And he said, No! 

#### Numbers 22:31 {uncovered And God} the eyes of Balaam, and he sees the angel of the LORD opposing him in the way, and the sword being unsheathed in his hand. And bowing he did obeisance on his face. 

#### Numbers 22:32 And {said to him the angel of God}, Why do you strike your donkey this third time? Now behold, I came forth to distract you, for {was not fair your way} before me. 

#### Numbers 22:33 And seeing me, the donkey turned aside from me this third time; and unless she turned aside from me, now then you indeed I would have killed, {her and then I would have preserved}. 

#### Numbers 22:34 And Balaam said to the angel of the LORD, I have sinned, for I did not have knowledge that you opposed me in the way to meet with me. And now, unless it not be sufficient to you, I shall return. 

#### Numbers 22:35 And {said the angel of God} to Balaam, You go with the men! Except the word which ever I should say to you, this you shall guard to speak. And Balaam went with the rulers of Balak. 

#### Numbers 22:36 And Balak hearing that Balaam had came, came forth to meet him in a city of Moab, which is upon the borders of Arnon, which is of the parts of the borders. 

#### Numbers 22:37 And Balak said to Balaam, Did I not send to you to call you? Why have you not come to me? Really, shall I not be able to esteem you? 

#### Numbers 22:38 And Balaam said to Balak, Behold, I come to you now. Am I able to speak anything? The word which ever God should put into my mouth, this I will speak. 

#### Numbers 22:39 And Balaam went with Balak. And they came to Cities of Properties. 

#### Numbers 22:40 And Balak sacrificed sheep and calves, and sent to Balaam and to the rulers, to the ones with him. 

#### Numbers 22:41 And it became morning, and Balak taking Balaam transported him unto the stele of Baal, and showed to him from there a certain part of the people. 

#### Numbers 23:1 And Balaam said to Balak, Build for me here seven shrines, and prepare for me here seven calves, and seven rams! 

#### Numbers 23:2 And Balak did in which manner {said to him Balaam}. And he offered a calf and ram upon the shrine. 

#### Numbers 23:3 And Balaam said to Balak, You stand beside your sacrifice! and I shall go and see if {me shall appear God to meet with}. And the saying which ever he shall show to me I shall announce to you. And he went straight. 

#### Numbers 23:4 And God appeared to Balaam. And {said to him Balaam}, The seven shrines I prepared, and I brought a calf and ram unto the shrine. 

#### Numbers 23:5 And God put a word into the mouth of Balaam, and he said, Turning towards Balak thus you shall speak. 

#### Numbers 23:6 And he returned to him, and thus he stood over his whole burnt-offerings, and all the rulers of Moab with him. 

#### Numbers 23:7 And taking up his parable, he said, From out of Mesopotamia {fetched me Balak king of Moab}, out of the mountains of the east, saying, Come curse for me Jacob! and, Come accurse to me Israel! 

#### Numbers 23:8 How shall I curse whom {does not curse the LORD}? And how shall I imprecate maledictions upon whom {does not imprecate maledictions upon God}? 

#### Numbers 23:9 For from the top of mountains I shall see him; and from hills I shall pay attention to him. Behold, a people {alone shall dwell}, and among nations they shall not be reckoned together. 

#### Numbers 23:10 Who determined exactly the seed of Jacob, and who shall count out peoples of Israel? May {die my soul} among souls of the just, and may {become my seed} as the seed of this. 

#### Numbers 23:11 And Balak said to Balaam, What have you done to me? For a curse for my enemies I have called you, and behold, you have blessed a blessing. 

#### Numbers 23:12 And Balaam said to Balak, Is it not as many things as God should put in my mouth this I will guard to speak? 

#### Numbers 23:13 And {said to him Balak}, Come yet with me to {place another} of which you shall not see it from there, but only a certain part of it shall you see, {all but in no way should you see}, and you curse it for me from there! 

#### Numbers 23:14 And he took him into a field -- a height upon the top of a place for dressing stone; and he built there seven shrines, and brought a calf and ram unto the shrine. 

#### Numbers 23:15 And Balaam said to Balak, Stand beside your sacrifice! and I shall go to ask God. 

#### Numbers 23:16 And God met with Balaam, and he put a word into his mouth. And said, Return to Balak! and thus you shall speak. 

#### Numbers 23:17 And he returned to him. And thus he was standing beside his whole burnt-offering, and the rulers of Moab with him. And {said to him Balak}, What said the LORD? 

#### Numbers 23:18 And taking up his parable, he said, Rise up, O Balak, and hear! Give ear, O witness son of Zippor! 

#### Numbers 23:19 {is not as a man God} to waver, nor as a son of man to be threatened. He in speaking, shall he not do? Shall he speak, and not adhere to? 

#### Numbers 23:20 Behold, {to bless I have taken to myself}. I will bless and in no way shall I turn back. 

#### Numbers 23:21 There shall not be trouble in Jacob, nor shall {appear misery} in Israel. The LORD his God is with him, the honorable ones of the rulers are with him. 

#### Numbers 23:22 God was the one leading him out of Egypt; as the glory of his unicorn. 

#### Numbers 23:23 {no For there is} omen in Jacob, nor divination in Israel. In time it shall be told to Jacob and to Israel what {shall complete God}. 

#### Numbers 23:24 Behold, the people as a cub shall raise up, and as a lion it shall prance; It shall not go to sleep until it shall eat game, and the blood of the slain it shall drink. 

#### Numbers 23:25 And Balak said to Balaam, Neither in curses shall you curse him, nor blessings shall you bless him. 

#### Numbers 23:26 And Balaam answering said to Balak, Did I not speak to you, saying, The word which ever God should speak, this I will do? 

#### Numbers 23:27 And Balak said to Balaam, Come, I should take you unto {place another}, if it should please God, and curse him for me from there! 

#### Numbers 23:28 And Balak took Balaam upon the top of Peor, the part extending into the wilderness. 

#### Numbers 23:29 And Balaam said to Balak, Build for me here seven shrines, and prepare for me here seven calves, and seven rams! 

#### Numbers 23:30 And Balak did just as {said to him Balaam}, and he bore a calf and a ram unto the shrine. 

#### Numbers 24:1 And Balaam seeing that it is good before the LORD to bless Israel, he did not go according to the accustomed way to meet with the ones with omens; and he turned back his face to the wilderness. 

#### Numbers 24:2 And Balaam lifting up his eyes, looks down on Israel encamped by tribes. And {became spirit of God} upon him. 

#### Numbers 24:3 And taking up his parable, he said, Says Balaam son of Beor. Says the man {true seeing}. 

#### Numbers 24:4 Says the one hearing oracles of God, who {a vision of God saw} in sleep; uncovering his eyes. 

#### Numbers 24:5 How good are your houses, O Jacob, your tents, O Israel. 

#### Numbers 24:6 As groves shadowing, as parks near a river, and as tents which the LORD pitched, as cedars by waters. 

#### Numbers 24:7 {came forth A man} from out of his seed, and he shall dominate {nations many}. And {shall be raised up high Gog his kingdom}, and {shall be increased his kingdom}. 

#### Numbers 24:8 God guided him from out of Egypt; as the glory of a unicorn to him. He shall eat the nations of his enemies, and {of their thickness he will extract the marrow}, and with his arrows he shall shoot an enemy. 

#### Numbers 24:9 Lying down he rested as a lion, and as a cub who shall raise him? The ones blessing you, they are blessed; and the ones cursing you, they are cursed. 

#### Numbers 24:10 And Balak was enraged at Balaam, and he struck together his hands. And Balak said to Balaam, To imprecate maledictions upon my enemy I have called you, and behold, blessing you blessed this third time. 

#### Numbers 24:11 Now then, flee unto your place! I said I will esteem you, but now {deprived you the LORD} of the glory. 

#### Numbers 24:12 And Balaam said to Balak, Did I not also {to your messengers whom you sent to me speak}, saying, 

#### Numbers 24:13 If {to me should give Balak full his house} of silver and gold, I shall not be able to violate the word of the LORD, to do it good or bad by myself. As many things as {should say to me God}, these things I shall speak. 

#### Numbers 24:14 And now, behold, I run to my place. Come, I will advise you what {will do this people} with your people in the last of the days. 

#### Numbers 24:15 And taking up his parable, he said, Says Balaam son of Beor. Says the man {true seeing}, 

#### Numbers 24:16 In hearing oracles of God, having knowledge of higher knowledge by the highest, and {a vision of God seeing} in sleep, uncovering his eyes. 

#### Numbers 24:17 I will show to him, but not now. I bless, and he does not approach. {will arise A star} from out of Jacob, and {shall rise up a man} from out of Israel, and he shall devastate the heads of Moab, and he shall despoil all of the sons of Sheth. 

#### Numbers 24:18 And Edom shall be an inheritance, and {shall be an inheritance Esau his enemy}. And Israel acted in strength. 

#### Numbers 24:19 And one shall be awakened from out of Jacob, and shall destroy the one escaping from the city. 

#### Numbers 24:20 And having seen Amalek, and taking up his parable, he said, The head of nations is Amalek, and his seed shall perish. 

#### Numbers 24:21 And having seen the Kenite, and taking up his parable, he said, {is strong Your dwelling}, and if you should put {in a rock your nest}, 

#### Numbers 24:22 and if it be to Beor a nest of astuteness, the Assyrians shall capture you. 

#### Numbers 24:23 And taking up his parable, he said, Oh, Oh, who shall live whenever {should appoint these things God}? 

#### Numbers 24:24 And one shall come forth from out of the hands of the Chittim, and they shall afflict Assyria, and they shall afflict Hebrews, and they with one accord shall perish. 

#### Numbers 24:25 And Balaam rising up went forth returning unto his place. And Balak went forth to his own. 

#### Numbers 25:1 And Israel rested up in Shittim, and {profaned the people} to fornicate with the daughters of Moab. 

#### Numbers 25:2 And they called them unto the sacrifices of their idols, and {ate the people} of their sacrifices, and they did obeisance to their idols. 

#### Numbers 25:3 And Israel was initiated to Baal-peor; and {was provoked to anger in rage the LORD} with Israel. 

#### Numbers 25:4 And the LORD said to Moses, Take all the heads of the people, and make an example of them for the LORD over against the sun! and {shall turn away the anger of the rage of the LORD} from Israel. 

#### Numbers 25:5 And Moses said to the tribes of Israel, Let {kill each} the one of his family being initiated to Baal-Peor! 

#### Numbers 25:6 And behold, a man of the sons of Israel coming, led forward his brother to the Midianitish woman before Moses, and before all the congregation of the sons of Israel. And they were weeping by the door of the tent of the testimony. 

#### Numbers 25:7 And seeing, Phinehas son of Eleazar, son of Aaron the priest, rose up from the midst of the congregation, and taking a spear in his hand, 

#### Numbers 25:8 he entered after the Israelitish man into the furnace, and he pierced both the Israelitish man, and the woman through her womb; and {ceased the calamity} from the sons of Israel. 

#### Numbers 25:9 And {were the ones having died by the calamity} four and twenty thousand. 

#### Numbers 25:10 And the LORD spoke to Moses, saying, 

#### Numbers 25:11 Phinehas, the son of Eleazar, son of Aaron the priest, caused {to cease my rage} from the sons of Israel, in my being jealous in the zeal for them; and I did not completely consume the sons of Israel in my zeal. 

#### Numbers 25:12 Thus say! Behold, I make with him my covenant of peace; 

#### Numbers 25:13 and it will be to him and to his seed after him a covenant {priesthood of an eternal}, because he was jealous for his God, and he atoned for the sons of Israel. 

#### Numbers 25:14 And the name of the Israelitish man being struck, who was stricken with the Midianitish woman, was Zimri son of Salu, ruler of the house of the family of Simeon. 

#### Numbers 25:15 And the name of the Midianitish woman being struck, was Cozbi, daughter of Zur, a ruler of the nation of Ommoth; {of the house of the family it is} of the ones of Midian. 

#### Numbers 25:16 And the LORD spoke to Moses, saying, Speak to the sons of Israel! saying, 

#### Numbers 25:17 Hate the Midianites, and strike them! 

#### Numbers 25:18 For {are hating you they with deceit}, with as many things they used deceit against you through Peor, even through Cozbi, daughter of the ruler of Midian, their sister, the one being struck in the day of the calamity on account of Peor. 

#### Numbers 26:1 And it came to pass after the calamity, and the LORD spoke to Moses, and to Eleazar the priest, saying, 

#### Numbers 26:2 Take the sum of all the congregation of the sons of Israel, from twenty years and up, according to the houses of their patrimony! every one going forth to deploy among Israel. 

#### Numbers 26:3 And {spoke Moses and Eleazar the priest} with them in the wilderness of Moab at the Jordan by Jericho, saying, 

#### Numbers 26:4 This is the numbering from twenty years and up, in which manner the LORD gave orders to Moses. And the sons of Israel, the ones coming forth out of Egypt -- 

#### Numbers 26:5 and Reuben, was first-born of Israel. And the sons of Reuben -- Hanoch, the people of the of Hanochites; of Pallu, the people of the Palluites; 

#### Numbers 26:6 to Hezron; the people of the Hezronites; to Carmi, the people of the of Carmites. 

#### Numbers 26:7 These are the peoples of Reuben. And {was the number of them} three and forty thousand and seven hundred and thirty. 

#### Numbers 26:8 And the sons of Pallu -- Eliab; 

#### Numbers 26:9 and the sons of Eliab -- Namuel, and Dathan, and Abiram; these are the ones summoned of the congregation. These are the ones rising up together against Moses and Aaron in the gathering of Korah, in the conspiring against the LORD. 

#### Numbers 26:10 And {opening the earth} its mouth swallowed them and Korah in the death of his congregation, when {devoured the fire} the fifty and two hundred. And they were made as a sign. 

#### Numbers 26:11 But the sons of Korah did not die. 

#### Numbers 26:12 And the sons of Simeon the people of the sons of Simeon; to Nemuel, the people the Nemuelites; to Jamin, the people the Jaminites; to Jachin, the people the Jachinites; 

#### Numbers 26:13 to Zerah, the people the Zerahites; to Shaul the people the Shaulites. 

#### Numbers 26:14 These are the peoples of Simeon by their numbering -- two and twenty thousand and two hundred. 

#### Numbers 26:15 The sons of Gad according to their peoples -- to Zephon, the people the Zephonites; to Haggi, the people the Haggites; to Shuni, the people the Shunites; 

#### Numbers 26:16 to Ozni, the people the Oznites; to Eri, the people the Erites; 

#### Numbers 26:17 to Arod, the people the Arodites; to Areli, the people the Arelites. 

#### Numbers 26:18 These are the peoples of the sons of Gad by their numbering -- forty thousand and five hundred. 

#### Numbers 26:19 Sons of Judah -- Er and Onan, Shelah, and Pharez and Zara; and {died Er and Onan} in the land of Canaan. 

#### Numbers 26:20 And {were the sons of Judah} according to their peoples -- to Shelah, the people the Shelanites; to Pharez, the people the Pharzites; to Zerah, the people the Zerhites. 

#### Numbers 26:21 And {were the sons of Pharez} -- to Hezron, the people the Hezronites; to to Hamul, the people the Hamulites. 

#### Numbers 26:22 These are the peoples to Judah, according to their numbering -- six and seventy thousand and five hundred. 

#### Numbers 26:23 And the sons of Issachar according to their peoples -- to Tola, the people the Tolaites; to Pua, the people the Punites; 

#### Numbers 26:24 to Jashub, the people the Jashubites; to Shimron, the people the Shimronites. 

#### Numbers 26:25 These are the peoples of Issachar by their numbering -- four and sixty thousand and three hundred. 

#### Numbers 26:26 Sons of Zebulun according to their peoples -- to Sered, the people the Seredites; to Elon, the people the Elonites; to Jahleel, the people the Jahleelites. 

#### Numbers 26:27 These are the peoples of Zebulun by their numbering -- sixty thousand and five hundred. 

#### Numbers 26:28 Sons of Joseph according to their peoples -- Manasseh and Ephraim. 

#### Numbers 26:29 Sons of Manasseh -- to Machir, the people the Machirites; and Machir procreated Gilead; to Gilead, the people the Gileadites; 

#### Numbers 26:30 And these are sons of Gilead -- to Jeezer, the people the Jeezerites; to Helek, the people the Helekites; 

#### Numbers 26:31 to Asriel, the people the Asrielites; to Shechem the people the Shechemites; 

#### Numbers 26:32 to Shemida, the people the Shemidaites; and to Hepher, the people the Hepherites. 

#### Numbers 26:33 And to Zelophehad son of Hepher there were no sons to him, only daughters. And these are the names of the daughters of Zelophehad -- Mahlah and Noah, and Hoglah, and Milcah, and Tizrah. 

#### Numbers 26:34 These are the peoples of Manasseh by their numbering -- two and fifty thousand and seven hundred. 

#### Numbers 26:35 These are the sons of Ephraim -- to Shuthelah, the people the Shuthelahites; to Becher, the people the Becherites; to Tahan, the people the Tahanites. 

#### Numbers 26:36 These are the sons of Shuthelah -- to Eran, the people the Eranites. 

#### Numbers 26:37 These are the peoples of Ephraim by their numbering -- two and thirty thousand and five hundred. These are the peoples of the sons of Joseph according to their peoples. 

#### Numbers 26:38 Sons of Benjamin according to their peoples -- to Bela, the people the Belaites; to Ashbel, the people the Ashbelites; to Ahiram, the people the Ahiramites; 

#### Numbers 26:39 to Shupham the people the Shuphamites; to Shupham, the people the Shuphamites. 

#### Numbers 26:40 And were the sons of Bela -- Ard and Naaman. To Ard, the people the Ardites; to Naaman, the people the Naamites. 

#### Numbers 26:41 These are the sons of Benjamin according to their peoples by their numbering -- five and forty thousand and six hundred. 

#### Numbers 26:42 And the sons of Dan according to their peoples -- to Shuham, the people the Shuhamites. These are the peoples of Dan according to their peoples. 

#### Numbers 26:43 All the peoples of Shuham according to their overseeing -- four and sixty thousand and four hundred. 

#### Numbers 26:44 Sons of Asher according to their peoples -- to Jimna, the people the Jimnites; to Jesui, the people the Jesuites; to Beriah, the people the Beriites; 

#### Numbers 26:45 to Heber, the people the Heberites; to Malchiel, the people the Malchielites. 

#### Numbers 26:46 And the name of the daughter of Asher -- Sarah. 

#### Numbers 26:47 These are the peoples of Asher by their numbering -- three and fifty thousand and four hundred. 

#### Numbers 26:48 The sons of Naphtali according to their peoples -- to Jahzeel, the people the Jahzeelites; to Guni, the people the Gunites; 

#### Numbers 26:49 to Jezer, the people the Jezerites; to Shillem, the people the Shillemites. 

#### Numbers 26:50 These are the peoples of Naphtali by their numbering -- five and forty thousand and four hundred. 

#### Numbers 26:51 This is the numbering of the sons of Israel -- six hundred thousand and a thousand and seven hundred and thirty. 

#### Numbers 26:52 And the LORD spoke to Moses, saying, 

#### Numbers 26:53 To these {shall be portioned the land} to inherit by the number of names. 

#### Numbers 26:54 To the many {will be superabundant the inheritance}, and to the less {will be less their inheritance}. To each as they are numbered {shall be given their inheritance}. 

#### Numbers 26:55 By lots {shall be portioned the land} by the names; according to the tribes of their patrimony they shall inherit. 

#### Numbers 26:56 By the lot you shall portion their inheritance between the many and few. 

#### Numbers 26:57 And the sons of Levi according to their peoples -- to Gershon, the people the Gershonites; to Kohath, the people the Kohathites; to Merari, the people the Merarites. 

#### Numbers 26:58 These are the peoples of the sons of Levi; the people -- the Libinites; the people -- the Hebronites; the people -- the Mahlites; the people -- the Mushites; and the people -- the Korathites; and Kohath procreated Amram. 

#### Numbers 26:59 And the name of his wife was Jochebed, daughter of Levi, who bore these to Levi in Egypt. And she bore to Amram -- Aaron and Moses and Miriam their sister. 

#### Numbers 26:60 And was born to Aaron both Nadab, and Abihu, and Eleazar, and Ithamar. 

#### Numbers 26:61 And {died Nadab and Abihu} in their offering {fire alien} before the LORD in the wilderness of Sinai. 

#### Numbers 26:62 And there were of their numbering -- three and twenty thousand, every male from a month and up. {not For they were} considered together in the midst of the sons of Israel, for {was not given to them a lot} in the midst of the sons of Israel. 

#### Numbers 26:63 And this numbering was by Moses and Eleazar the priest, the ones who numbered the sons of Israel in the wilderness of Moab, at the Jordan by Jericho. 

#### Numbers 26:64 And among these there was not a man of the ones being numbered by Moses and Aaron whom they numbered being of the sons of Israel in the wilderness of Sinai. 

#### Numbers 26:65 For the LORD said to them, By death they shall die in the wilderness, and there shall not be left behind of them not even one, except Caleb the son of Jephunneh, and Joshua the son of Nun. 

#### Numbers 27:1 And there came forward the daughters of Zelophehad, son of Hepher, son of Gilead, son of Machir of the people of Manasseh, of the sons of Joseph; and these are their names -- Mahlah, and Noah, and Hoglah, and Milcah, and Tizrah. 

#### Numbers 27:2 And standing before Moses, and before Eleazar the priest, and before the rulers, and before all the congregation at the door of the tent of the testimony, they say, 

#### Numbers 27:3 Our father died in the wilderness, and he was not in the midst of the congregation of the ones rising up together against the LORD in the congregation of Korah; for because of his sin he died. And {sons no there were} born to him. Let {not be wiped away the name of our father} from the midst of his people! for there is not a son to him. Give to us a possession in the midst of the brothers of our father! 

#### Numbers 27:4 And Moses brought their case before the LORD. 

#### Numbers 27:5 And the LORD spoke to Moses, saying, 

#### Numbers 27:6 Rightly the daughters of Zelophehad have spoken. A gift you shall give to them for possession of an inheritance in the midst of the brothers of their father; and you shall put the lot of their father among them. 

#### Numbers 27:7 And to the sons of Israel you shall speak, saying, 

#### Numbers 27:8 A man if he should die, and {a son there might not be} to him, you shall invest his inheritance to his daughter. 

#### Numbers 27:9 And if there might not be a daughter to him, you shall give his inheritance to his brother. 

#### Numbers 27:10 And if there should not be brothers to him, you shall give his inheritance to the brother of his father. 

#### Numbers 27:11 And if there might not be brothers of his father, you shall give his inheritance to the member of the family, to the one nearest him of his tribe, to inherit the things of his. And this will be to the sons of Israel, an ordinance of equity, as the LORD gave orders to Moses. 

#### Numbers 27:12 And the LORD said to Moses, Ascend into the mountain, the one on the other side of the Jordan, this mount Nebo, and see the land of Canaan which I give to the sons of Israel for a possession! 

#### Numbers 27:13 And you shall see it, and you shall be added to your people, even you, as {was added Aaron your brother} in Or the mountain; 

#### Numbers 27:14 because you both violated my word in the wilderness of Zin, when {rushed headlong against the congregation} the sanctifying me; you did not sanctify me at the water before them -- this is The Water of Dispute -- Kadesh, in the wilderness of Zin. 

#### Numbers 27:15 And Moses said to the LORD, 

#### Numbers 27:16 Let {watch the LORD God of the spirits and all flesh} for a man to be over this congregation, 

#### Numbers 27:17 who shall go forth before their face, and who shall enter before their face, and who shall lead them, and who shall bring them; that {shall not be the congregation of the LORD} as a sheep in which there is no shepherd. 

#### Numbers 27:18 And the LORD spoke to Moses, saying, Take to yourself Joshua son of Nun! a man who has spirit in him. And you shall place your hands upon him. 

#### Numbers 27:19 And you shall set him before Eleazar the priest, and before all the congregation, and you shall give charge to him before them, 

#### Numbers 27:20 And you shall put your glory upon him, so that {should hearken to him the sons of Israel}. 

#### Numbers 27:21 And before Eleazar the priest he shall stand, and they shall ask him the equity of the manifestations before the LORD. By his mouth they shall go forth, and by his mouth they shall enter, he and all the sons of Israel with one accord, and all the congregation. 

#### Numbers 27:22 And Moses did as {gave charge to him the LORD}. And taking Joshua, he stood him before Eleazar the priest, and before all the congregation. 

#### Numbers 27:23 And he placed his hands upon him, and he stood him just as the LORD gave orders to Moses. 

#### Numbers 28:1 And the LORD spoke to Moses, saying, 

#### Numbers 28:2 Give charge to the sons of Israel! And you shall say to them, saying, My gifts, my presents, my yield offerings for a scent of pleasant aroma you shall observe to bring near to me in my holidays. 

#### Numbers 28:3 And you shall say to them, These are the yield offerings which you shall lead to the LORD -- he-lambs of a year old, unblemished, two a day for a whole burnt-offering perpetually. 

#### Numbers 28:4 The {lamb one} you shall offer in the morning, and the {lamb second} you shall offer towards evening. 

#### Numbers 28:5 And you shall offer the tenth of the ephah of fine flour for a sacrifice offering being prepared in olive oil the fourth part of the hin. 

#### Numbers 28:6 It is a {whole burnt-offering perpetual}, the one taking place in mount Sinai, for a scent of pleasant aroma to the LORD. 

#### Numbers 28:7 And its libation -- the fourth part of the hin to the {lamb one}. In the holy place you shall offer a libation offering of liquor to the LORD. 

#### Numbers 28:8 And the {lamb second} you shall offer towards evening according to its sacrifice offering; and according to its libation you shall offer it for a scent of pleasant aroma to the LORD. 

#### Numbers 28:9 And in the day of the Sabbaths you shall lead forward two lambs of a year old, unblemished; and two tenths of fine flour being prepared in olive oil for a sacrifice offering and its libation; 

#### Numbers 28:10 a whole burnt-offering of the Sabbaths on the Sabbaths, besides the {whole burnt-offering continual} and its libation. 

#### Numbers 28:11 And in the new moons you shall lead a whole burnt-offering to the LORD, {calves of the oxen two}, and {ram one}, {lambs of a year old seven unblemished}. 

#### Numbers 28:12 Three tenths of fine flour being prepared in olive oil for the {calf one}, and two tenths of fine flour being prepared in olive oil for the {ram one}. 

#### Numbers 28:13 And a tenth of fine flour being prepared in olive oil for the {lamb one} -- a sacrifice scent of pleasant aroma, a yield offering to the LORD. 

#### Numbers 28:14 To their libation {the half of the hin of wine will be} for the {calf one}, and the third of the hin of wine will be for the {ram one}, and the fourth of the hin {will be for the lamb one of wine}. This is the whole burnt-offering, month by month throughout the months of the year. 

#### Numbers 28:15 And a young he-goat from the goats -- one for a sin offering to the LORD, beside the {whole burnt-offering continual}; you shall offer it and its libation. 

#### Numbers 28:16 And in the {month first}, the fourteenth day of the month, is a passover to the LORD. 

#### Numbers 28:17 And the fifteenth day of the month, this is a holiday; seven days {unleavened breads you shall eat}. 

#### Numbers 28:18 And the {day first} {summoning a holy will be} to you. All work which is servile you shall not do. 

#### Numbers 28:19 And you shall bring whole burnt-offerings, a yield offering to the LORD, {calves of the oxen two}, {ram one}, {lambs of a year old seven}; {unblemished they shall be} to you. 

#### Numbers 28:20 And their sacrifice offering shall be of fine flour being prepared in olive oil, three tenths for the {calf one}, and two tenths for the {ram one}. 

#### Numbers 28:21 {a tenth tithe You shall offer} for the {lamb one}, for the seven lambs, 

#### Numbers 28:22 and a young he-goat from the goats -- one for a sin offering to atone for you, 

#### Numbers 28:23 besides the {whole burnt-offering continual} of the early morning which is {whole burnt-offering a perpetual}. 

#### Numbers 28:24 These according to these manners you shall offer per day for the seven days as a gift yield offering scent of pleasant aroma to the LORD; with the {whole burnt-offering continual} you shall offer its libation. 

#### Numbers 28:25 And {day the seventh calling a holy will be} to you; all {work servile} you shall not do on it. 

#### Numbers 28:26 And the day of the new produce, whenever you should bring {sacrifice a new produce to the LORD of the period of sevens}, {summoning a holy it will be} to you. All {work servile} you shall not do. 

#### Numbers 28:27 And you shall bring whole burnt-offerings for a scent of pleasant aroma to the LORD -- {calves of the oxen two}, {ram one}, seven lambs of a year old unblemished. 

#### Numbers 28:28 Their sacrifice offering shall be of fine flour being prepared in olive oil, three tenths for the {calf one}, and two tenths for the {ram one}, 

#### Numbers 28:29 a tenth tithe to the {lamb one}, for the seven lambs, 

#### Numbers 28:30 and {young he-goat from the goats one} for a sin offering, to atone for you; 

#### Numbers 28:31 besides the {whole burnt-offering continual}. And their sacrifice offering you shall offer to me; {unblemished they shall be} to you, and their libations. 

#### Numbers 29:1 And the {month seventh}, day one of the month, {summoning a holy will be} to you; all {work servile} you shall not do; a day of signal it will be to you. 

#### Numbers 29:2 And you shall offer whole burnt-offerings for a scent of pleasant aroma to the LORD -- {calf one} of the oxen, {ram one}, {lambs of a year old seven unblemished}. 

#### Numbers 29:3 Their sacrifice offering of fine flour being prepared in olive oil -- three tenths for the {calf one}, and two tenths for the {ram one}. 

#### Numbers 29:4 A tenth tithe to the {lamb one} for the seven lambs. 

#### Numbers 29:5 And a young he-goat from the goats -- one for a sin offering, to atone for you; 

#### Numbers 29:6 besides the whole burnt-offerings of the new moon, and their sacrifice offerings, and their libations, and the {whole burnt-offering continual}, and their sacrifice offerings, and their libations according to their interpretation for a scent of pleasant aroma to the LORD. 

#### Numbers 29:7 And the tenth of this month {summoning a holy there shall be} to you. And you shall afflict your souls, and all work you shall not do. 

#### Numbers 29:8 And you shall bring whole burnt-offerings for a scent of pleasant aroma yield offering to the LORD -- {calf of the oxen one}, {ram one}, {lambs of a year old seven}; they shall be unblemished to you. 

#### Numbers 29:9 Their sacrifice offering shall be of fine flour being prepared in olive oil; three tenths to the {calf one}, and two tenths to the {ram one}. 

#### Numbers 29:10 A tenth tithe to the {lamb one}, for the seven lambs. 

#### Numbers 29:11 And {young he-goat from the goats one} for a sin offering to atone for you; besides the one for the sin offering of the atonement, and the {whole burnt-offering continual}, its sacrifice offering, and its libation according to the interpretation, a yield offering to the LORD. 

#### Numbers 29:12 And the fifteenth day {month seventh of this} {summoning a holy will be} to you; all {work servile} you shall not do; and you shall solemnize it as a holiday to the LORD for seven days. 

#### Numbers 29:13 And you shall bring whole burnt-offerings, a yield offering for a scent of pleasant aroma to the LORD. On the {day first} -- {calves of the oxen three and ten}, {rams two}, {lambs of a year old fourteen}; they shall be unblemished. 

#### Numbers 29:14 Their sacrifice offerings shall be of fine flour being prepared in olive oil -- three tenths to the {calf one} for the thirteen calves; and two tenths to the {ram one} for the two rams; 

#### Numbers 29:15 and a tenth tithe to the {lamb one} for the four and ten lambs. 

#### Numbers 29:16 And {young he-goat of the goats one} for a sin offering, besides the {whole burnt-offering continual}, their sacrifice offerings, and their libations. 

#### Numbers 29:17 And the {day second} -- {calves twelve} of oxen, {rams two}, {lambs of a year old four and ten unblemished}, 

#### Numbers 29:18 their sacrifice offering, and their libation for the calves, and for the rams, and for the lambs according to their number, according to their interpretation, 

#### Numbers 29:19 and a young he-goat of the goats -- one for a sin offering; besides the {whole burnt-offering continual}, their sacrifice offerings, and their libations. 

#### Numbers 29:20 The {day third} -- {calves eleven}, {rams two}, {lambs of a year old four and ten unblemished}, 

#### Numbers 29:21 their sacrifice offering, and their libation for the calves, and for the rams, and for the lambs, according to their number, according to their interpretation, 

#### Numbers 29:22 and a young he-goat of the goats -- one for a sin offering; besides the {whole burnt-offering continual}, their sacrifice offerings, and their libations. 

#### Numbers 29:23 The {day fourth} -- {calves ten}, {rams two}, {lambs of a year old four and ten unblemished}, 

#### Numbers 29:24 their sacrifice offerings, and their libations for the calves, and for the rams, and for the lambs, according to their number, according to their interpretation, 

#### Numbers 29:25 and a young he-goat of the goats -- one for a sin offering, besides the {whole burnt-offering continual}, their sacrifice offerings, and their libations. 

#### Numbers 29:26 The {day fifth} -- {calves nine}, {rams two}, {lambs of a year old four and ten unblemished}, 

#### Numbers 29:27 their sacrifice offerings, and their libations for the calves, and for the rams, and for the lambs, according to their number, according to their interpretation, 

#### Numbers 29:28 and a young he-goat of the goats -- one for a sin offering, besides the {whole burnt-offering continual}, their sacrifice offerings and their libations. 

#### Numbers 29:29 The {day sixth} -- {calves eight}, {rams two}, {lambs of a year old fourteen unblemished}, 

#### Numbers 29:30 their sacrifice offerings, and their libations for the calves, and for the rams, and for the lambs, according to their number, according to their interpretation, 

#### Numbers 29:31 and a young he-goat of the goats -- one for a sin offering, besides the {whole burnt-offering continual}, their sacrifice offerings, and their libations. 

#### Numbers 29:32 The {day seventh} -- {calves seven}, {rams two}, {lambs of a year old fourteen unblemished}, 

#### Numbers 29:33 and their sacrifice offerings, and their libations for the calves, and for the rams, and for the lambs, according to their number, according to their interpretation, 

#### Numbers 29:34 and a young he-goat of the goats -- one for a sin offering, besides the {whole burnt-offering continual}, their sacrifice offerings, and their libations. 

#### Numbers 29:35 And the {day eighth} will be a holiday recess to you. All {work servile} you shall not do on it. 

#### Numbers 29:36 And you shall lead forward whole burnt-offerings for a scent of pleasant aroma, yield offerings to the LORD -- {calf one}, {ram one}, {lambs of a year old seven unblemished}, 

#### Numbers 29:37 and their sacrifice offerings, and their libations for the calf, and for the ram, and for the lambs, according to their number, according to their interpretation, 

#### Numbers 29:38 and a young he-goat of the goats, one for a sin offering, besides the {whole burnt-offering continual}, their sacrifice offerings, and their libations. 

#### Numbers 29:39 These things you shall do to the LORD in your holidays, besides your vows, and your voluntary offerings, and your whole burnt-offerings, and your sacrifice offerings, and your libations, and your deliverance offerings. 

#### Numbers 29:40 And Moses spoke to the sons of Israel concerning all as many things as the LORD gave charge to Moses. 

#### Numbers 30:1 And Moses spoke to the rulers of the tribes of the sons of Israel, saying, This is the saying which the LORD ordered. 

#### Numbers 30:2 A man, a man who ever should vow a vow to the LORD, or should swear by an oath, or should confirm a set of limits upon his life, he shall not profane his word; all as many things as should come forth from out of his mouth he shall do. 

#### Numbers 30:3 And if {should vow a woman} a vow to the LORD, or confirm a set of limits in the house of her father in her youth; 

#### Numbers 30:4 and {should hear her father} her vows, and her sets of limits which she confirmed on her life, and {should remain silent her father}, then shall stand all the matters of her vows, and all the sets of limits which she confirmed on her life she shall abide by. 

#### Numbers 30:5 But if in shaking his head in dissent {should dissent her father} in which ever day he should hear her vows, and her sets of limits which she confirmed on her life, then they shall not stand; and the LORD shall clear her for {shook his head in dissent her father}. 

#### Numbers 30:6 But if in coming to pass she should become a man's wife, and her vows be upon her, according to the distinction from her lips as many things as she confirmed on her life; 

#### Numbers 30:7 and {should hear her husband}, and should remain silent concerning her in which ever day he should hear, then thus shall stand all her vows; and her sets of limits which she confirmed on her life shall stand. 

#### Numbers 30:8 But if in shaking his head in dissent {should dissent her husband} in which ever day he should hear all her vows, and her sets of limits which she confirmed on her life, they shall not abide, for her husband shook his head in dissent concerning her, and the LORD shall clear her. 

#### Numbers 30:9 And a vow of a widow, and a woman being cast out, as many things as she should make a vow on her life, shall abide to her. 

#### Numbers 30:10 But if in the house of her husband her vow be, or the set of limits on her life with an oath, 

#### Numbers 30:11 and {should hear her husband}, and remain silent concerning her, and should not shake his head in dissent concerning her, then shall stand all her vows; and all her sets of limits which she confirmed on her life shall stand concerning her. 

#### Numbers 30:12 But if in removing {should remove them her husband}, in which ever day he should hear, all as many things as should come forth from out of her lips concerning her vows, and concerning the sets of limits on her life; it shall not remain to her, her husband removed them, and the LORD cleared her. 

#### Numbers 30:13 Every vow and every {oath binding} to afflict her soul, her husband shall set for her, and her husband shall remove for her. 

#### Numbers 30:14 But if in keeping silent he should remain silent at her day by day, then {shall stand to her all her vows}; and the sets of limits upon her shall stand to her, for he kept silent at her in the day in which he heard. 

#### Numbers 30:15 But if removing {should remove them her husband} after the day which he heard them, then he shall take the sin unto himself. 

#### Numbers 30:16 These are the ordinances, as many as the LORD gave charge to Moses between a husband and between his wife, and between a father and daughter in youth in the house of her father. 

#### Numbers 31:1 And the LORD spoke to Moses, saying, 

#### Numbers 31:2 Let {avenge with punishment the sons of Israel} on the Midianites; and at the last you shall be added to your people. 

#### Numbers 31:3 And Moses spoke to the people saying, Completely arm your men, and deploy before the LORD against Midian, to render punishment by the LORD on Midian. 

#### Numbers 31:4 A thousand from a tribe; even a thousand from a tribe from all of the tribes of the sons of Israel you send to deploy! 

#### Numbers 31:5 And they counted out from the thousands of Israel, a thousand from a tribe. Twelve thousand being armed in battle array. 

#### Numbers 31:6 And {sent them Moses}, a thousand from out of a tribe; even a thousand from out of a tribe with their force. And Phinehas son of Eleazar son of Aaron the priest; and the {items holy} and the trumpets were in their hands for the signals. 

#### Numbers 31:7 And they deployed against Midian as the LORD gave charge to Moses. And they killed every male. 

#### Numbers 31:8 And {the kings of Midian they killed} together with their slain -- Evi, and Rekem, and Zur, and Hur, and Reba, five kings of Midian; and Balaam son of Beor they killed by the broadsword with their slain. 

#### Numbers 31:9 And they despoiled the women of Midian, and their belongings, and their cattle, and all the things procured by them; and {their force they despoiled}. 

#### Numbers 31:10 And all their cities, the ones in their dwellings, and their properties they burned by fire. 

#### Numbers 31:11 And they took all the plunder, and all their spoils -- from man unto beast. 

#### Numbers 31:12 And they brought to Moses, and to Eleazar the priest, and to all the sons of Israel, the captivity, and the spoils, and the plunder, into the camp in the wilderness of Moab which is upon the Jordan by Jericho. 

#### Numbers 31:13 And Moses came forth, and Eleazar the priest, and all the rulers of the congregation to meet with them outside the camp. 

#### Numbers 31:14 And Moses was provoked to anger with the overseers of the force -- commanders of thousands, and commanders of hundreds, the ones coming from the battle array of the war. 

#### Numbers 31:15 And {said to them Moses}, why did you take alive every female? 

#### Numbers 31:16 For these were the occasion to the sons of Israel by the word of Balaam of their leaving and overlooking the word of the LORD, because of Peor, and came to pass the calamity in the congregation of the LORD. 

#### Numbers 31:17 And now kill every male among all the chattel! And every woman who knew the marriage-bed of a man kill! 

#### Numbers 31:18 And all the chattel of the women who have not known the marriage-bed of a man, take them alive! 

#### Numbers 31:19 And you camp outside the camp seven days, every one doing away with a soul! And all having touched the one being pierced shall be purified in the third day, and in the {day seventh} you and your captivity. 

#### Numbers 31:20 And every wrap-around garment, and every item made of skin, and every work of goat skin, and every {item wooden}, you shall purify. 

#### Numbers 31:21 And {said Eleazar the priest} to the men of the force of the ones coming from the battle array of the war, This is the ordinance of the law which the LORD gave orders to Moses. 

#### Numbers 31:22 Besides the gold, and the silver, and brass, and iron, and lead, and tin, 

#### Numbers 31:23 every thing which shall go through in fire shall be led through in fire, and shall be clean, but only with the water of purification shall it be purified. And all as many as should not travel through fire, shall go through water. 

#### Numbers 31:24 And you shall wash the garments on the {day seventh}, and you shall be clean. And after this you shall enter into the camp. 

#### Numbers 31:25 And the LORD spoke to Moses, saying, 

#### Numbers 31:26 Take the total sum of the spoils of the captivity, from man unto beast, you and Eleazar the priest, and the rulers of the patrimony of the congregation! 

#### Numbers 31:27 And you shall divide the spoils between the warriors of the ones going forth into the battle array, and between the whole congregation. 

#### Numbers 31:28 And you shall offer up the tax to the LORD from the men of the warriors, of the ones going forth into the battle array, one soul from five hundred of the people, and from the cattle, and from the oxen, and from the sheep, and from the donkeys; 

#### Numbers 31:29 from their half you shall take. And you shall give to Eleazar the priest the first-fruits for the LORD. 

#### Numbers 31:30 And from the half of the ones of the sons of Israel, you shall take one from fifty, from the people, and from the oxen, and from the sheep, and from the donkeys, and from all the cattle. And you shall give them to the Levites, to the ones guarding the watches in the tent of the LORD. 

#### Numbers 31:31 And {did Moses and Eleazar the priest} as the LORD gave orders to Moses. 

#### Numbers 31:32 And came to pass the surplus of the plunder which {despoiled men the warrior} from the sheep -- six hundred thousand and seventy thousand and five thousand; 

#### Numbers 31:33 and oxen -- two and seventy thousand; 

#### Numbers 31:34 and donkeys -- one and sixty thousand. 

#### Numbers 31:35 And the souls of people from the women who did not know the marriage-bed of a male, all souls -- two and thirty thousand. 

#### Numbers 31:36 And came to pass the half portion of the ones going forth into the war, of the number of the sheep -- three hundred thousand and thirty thousand and seven thousand and five hundred. 

#### Numbers 31:37 And came to pass the tax to the LORD of the sheep -- six hundred and seventy five; 

#### Numbers 31:38 and oxen -- six and thirty thousand; and their tax to the LORD -- two and seventy; 

#### Numbers 31:39 and donkeys -- thirty thousand and five hundred; and their tax to the LORD -- one and sixty. 

#### Numbers 31:40 And the souls of people -- six and ten thousand; and their tax to the LORD -- two and thirty souls. 

#### Numbers 31:41 And Moses gave the tax to the LORD, the cut-away portion of God, to Eleazar the priest as the LORD gave orders to Moses, 

#### Numbers 31:42 of the half of the sons of Israel whom Moses divided from the {men warrior}. 

#### Numbers 31:43 And came to pass the half from the congregation, of the sheep -- three hundred thousand and thirty thousand and seven thousand and five hundred; 

#### Numbers 31:44 and oxen -- six and thirty thousand; 

#### Numbers 31:45 donkeys -- thirty thousand and five hundred; 

#### Numbers 31:46 and souls of peoples -- six and ten thousand. 

#### Numbers 31:47 And Moses took from the half of the sons of Israel, the one from every fifty of the people, and of the cattle; and he gave them to the Levites guarding the watches of the tent of the LORD, in which manner the LORD gave orders to Moses. 

#### Numbers 31:48 And there came forward to Moses all the ones placed as the commanders of the force -- commanders of thousands, and commanders of hundreds. And they said to Moses, 

#### Numbers 31:49 Your servants have taken the total sum of the {men warrior}, of the ones with us, and not dissented of them not even one. 

#### Numbers 31:50 And we have brought the gift to the LORD, every man who found an item of gold, and armlet, and bracelet, and ring, and right armband, and wreath, to atone for us before the LORD. 

#### Numbers 31:51 And {took Moses and Eleazar the priest} the gold from them, every item being worked. 

#### Numbers 31:52 And came to pass all the gold for the cut-away portion which they removed to the LORD -- sixteen thousand and seven hundred and fifty shekels from the commanders of thousands, and from the commanders of hundreds. 

#### Numbers 31:53 And the {men warrior} despoiled each unto himself. 

#### Numbers 31:54 And {took Moses and Eleazar the priest} the gold from the commanders of a thousand, and from the commanders of hundreds, and carried them into the tent of the testimony, a memorial of the sons of Israel before the LORD. 

#### Numbers 32:1 And {of cattle a multitude there was} to the sons of Reuben, and to the sons of Gad, {multitude great an exceedingly}. And they saw the place of Jazer, and the place of Gilead; and {was the place} a place of cattle. 

#### Numbers 32:2 And {coming forward the sons of Reuben}, and the sons of Gad, said to Moses, and to Eleazar the priest, and to the rulers of the congregation, saying, 

#### Numbers 32:3 Ataroth and Dibon and Jazer and Nimrah and Heshbon and Elealeh and Shebam and Nebo and Beon, 

#### Numbers 32:4 the land which the LORD delivered up before the sons of Israel, {land for grazing cattle is}, and your servants {on cattle subsist}. 

#### Numbers 32:5 And they said, If we find favor before you, give this land to your servants for a possession, and do not cause us to pass over the Jordan! 

#### Numbers 32:6 And Moses said to the sons of Gad, and to the sons of Reuben, {your brethren Shall} go to war and you sit here? 

#### Numbers 32:7 And why do you turn aside the thoughts of the sons of Israel to not pass over into the land which the LORD gives to them? 

#### Numbers 32:8 Did not {do thus your fathers} when I sent them from out of Kadesh Barnea to study the land? 

#### Numbers 32:9 And they ascended the Ravine of the Cluster, and studied the land, and separated the heart of the sons of Israel, so as to not enter into the land which {gave to them the LORD}. 

#### Numbers 32:10 And {was provoked to anger in rage the LORD} in that day, and swore by an oath, saying, 

#### Numbers 32:11 Shall {see these men} (the men ascending from Egypt, from twenty years old and up, the ones having knowledge of the good and the bad) the land which I swore by an oath to Abraham, and Isaac, and Jacob, no. For they did not follow together after me, 

#### Numbers 32:12 except Caleb son of Jephunneh, the one being set apart, and Joshua the son of Nun, for he followed after the LORD. 

#### Numbers 32:13 And {was provoked to anger in rage the LORD} over Israel; and he staggered them in the wilderness forty years, until {was completely consumed all the generation doing evil before the LORD}. 

#### Numbers 32:14 Behold, you rose up in place of your fathers, a confederation of men of sinners to add still unto the rage of the anger of the LORD against Israel, 

#### Numbers 32:15 that you shall turn away from him to add still to leave him in the wilderness, and shall act lawlessly against {entire congregation this}. 

#### Numbers 32:16 And they came forward to him, and said, Properties for flocks we shall build here for our cattle, and cities for our chattel. 

#### Numbers 32:17 And we, arming ourselves, will be an advance guard in front of the sons of Israel, until when we should lead them into their own place. And {shall dwell our belongings} in cities being walled, because of the ones dwelling in the land. 

#### Numbers 32:18 In no way should we return to our dwellings, until whenever {should divide the sons of Israel each} into his inheritance. 

#### Numbers 32:19 And no longer shall we be heir with them from the other side of the Jordan, and beyond; because we receive our lots on the other side of the Jordan eastwards. 

#### Numbers 32:20 And {said to them Moses}, If you should do according to this thing, if you should completely arm before the LORD for war, 

#### Numbers 32:21 and {shall go over you yourselves all armed with large shields the Jordan} before the LORD, until {shall be obliterated his enemy} from his face, 

#### Numbers 32:22 and {shall be dominated the land} before the LORD, then after these things you shall return, and you will be innocent before the LORD, and from Israel. And {shall be this land} to you for a possession before the LORD. 

#### Numbers 32:23 But if you should not do so, you shall sin before the LORD; and you shall know your sin, whenever {should overtake you bad things}. 

#### Numbers 32:24 And thus you shall build to yourselves for them cities for your belongings, and properties for your cattle; and the thing going forth from out of your mouth you shall do. 

#### Numbers 32:25 And {spoke the sons of Reuben and the the sons of Gad} to Moses, saying, Your servants shall do as our master gives charge. 

#### Numbers 32:26 Our belongings, and our women, and our possessions, and all our cattle will be there in the cities of Gilead. 

#### Numbers 32:27 And your servants shall all go over, being armed and being arrayed before the LORD for war, in which manner the master says. 

#### Numbers 32:28 And {stood together with them Moses}, with Eleazar the priest, and Joshua son of Nun, and the rulers of the patrimony of the tribes of the sons of Israel. 

#### Numbers 32:29 And {said to them Moses}, If {should pass over the sons of Reuben and the sons of Gad} {with you the Jordan}, every one being armed for war before the LORD, and you should dominate the land before you, then you shall give to them the land of Gilead for a possession. 

#### Numbers 32:30 But if they should not pass over being armed with you for war before the LORD, then you shall cause {to pass over with their belongings them}, and their women, and their cattle in front of you into the land of Canaan; and they shall inherit together with you in the land of Canaan. 

#### Numbers 32:31 And {answered the sons of Reuben and the sons of Gad}, saying, As much as the LORD says to his attendants, so we shall do. 

#### Numbers 32:32 We will pass over being armed before the LORD into the land of Canaan. And you shall give our possession on the other side of the Jordan. 

#### Numbers 32:33 And {gave to them Moses}, to the sons of Gad, and to the sons of Reuben, and to the half tribe of Manasseh of the sons of Joseph, the kingdom of Sihon king of the Amorites, and the kingdom of Og king of Bashan, the land and the cities with its boundaries -- the cities of the land round about. 

#### Numbers 32:34 And {built the sons of Gad} Dibon, and Ataroth, and Aroer, 

#### Numbers 32:35 and Shophan, and Jaazer. And they raised them up, 

#### Numbers 32:36 and Beth-nimrah, and Beth-haran -- {cities fortified}, and properties of flocks. 

#### Numbers 32:37 And the sons of Reuben built Heshbon, and Elealeh, and Kirjathaim, 

#### Numbers 32:38 and Nebo and Baal-meon, being surrounded with walls, and Shibmah. And they named by their names the names of the cities which they built. 

#### Numbers 32:39 And {went a son of Machir son of Manasseh} into Gilead, and took it, and destroyed the Amorite dwelling in it. 

#### Numbers 32:40 And Moses gave Gilead to Machir son of Manasseh; and he dwelt there. 

#### Numbers 32:41 And Jair the son of Manasseh went, and he took their properties, and named them Properties of Jair. 

#### Numbers 32:42 And Nobah went and took Kenath, and her towns, and named them Nobah, after his name. 

#### Numbers 33:1 And these are the posts of the sons of Israel, as they came forth from the land of Egypt with their force by the hand of Moses and Aaron. 

#### Numbers 33:2 And Moses wrote the things of their departures, and the things of their stages through the word of the LORD. And these are the stages of their goings. 

#### Numbers 33:3 Departing from out of Rameses in the {month first}, the fifteenth day of the {month first}; the next day of the passover {came forth the sons of Israel} with {hand a high} before all the Egyptians. 

#### Numbers 33:4 And the Egyptians buried of theirs the ones having died, all of as many as the LORD struck, all the first-born in the land of Egypt. And among their gods {executed punishment the LORD}. 

#### Numbers 33:5 {departing And the sons of Israel} out of Rameses camped in Soccoth. 

#### Numbers 33:6 And departing from Soccoth, and they camped in Etham, which is a part of the wilderness. 

#### Numbers 33:7 And departing from Etham, and they camped at the mouth of Hiroth, which is before Baal-zephon; and they camped before Migdol. 

#### Numbers 33:8 And departing before Hiroth, and they passed over between the sea into the wilderness. And they went a journey three days through the wilderness themselves, and they camped in Bitterness. 

#### Numbers 33:9 And departing from Bitterness, and they came to Elim. And in Elim were twelve springs of waters, and seventy trunks of palm trees; and they camped there by the water. 

#### Numbers 33:10 And departing from Elim, and they camped by {sea the red}. 

#### Numbers 33:11 And departing from {sea the red}, and they camped in the wilderness of Zin. 

#### Numbers 33:12 And departing from the wilderness of Zin, and they camped in Dophkah. 

#### Numbers 33:13 And departing from Dophkah, and they camped in Alush. 

#### Numbers 33:14 And departing from Alush, and they camped in Rephidim, and there was no water there for the people to drink. 

#### Numbers 33:15 And departing from Rephidim, and they camped in the wilderness of Sinai. 

#### Numbers 33:16 And departing from the wilderness of Sinai, and they camped at Tombs of the Desire. 

#### Numbers 33:17 And departing from Tombs of the Desire, and they camped in Hazeroth. 

#### Numbers 33:18 And departing from Hazeroth, and they camped in Rithmah. 

#### Numbers 33:19 And departing from Rithmah, and they camped in Rimmon Parez. 

#### Numbers 33:20 And departing from Rimmon Parez, and they camped in Libnah. 

#### Numbers 33:21 And departing from Libnah, and they camped in Rissah. 

#### Numbers 33:22 And departing from Rissah, and they camped in Kehelathah. 

#### Numbers 33:23 And departing from Kehelathah, and they camped in Shapher. 

#### Numbers 33:24 And departing from Shapher, and they camped in Haradah. 

#### Numbers 33:25 And departing from Haradah, and they camped in Makheloth. 

#### Numbers 33:26 And departing from Makheloth, and they camped in Tahath. 

#### Numbers 33:27 And departing from Tahath, and they camped in Tarah. 

#### Numbers 33:28 And departing from Tarah, and they camped in Mithcah. 

#### Numbers 33:29 And departing from Mithcah, and they camped in Hashmonah. 

#### Numbers 33:30 And departing from Hashmonah, and they camped in Moseroth. 

#### Numbers 33:31 And departing from Moseroth, and they camped in Bene-jaakan. 

#### Numbers 33:32 And departing from Bene-jaakan, and they camped in the mountain of Hagidgad. 

#### Numbers 33:33 And departing from the mountain of Hagidgad, and they camped in Jobathah. 

#### Numbers 33:34 And departing from Jobathah, and they camped in Ebronah. 

#### Numbers 33:35 And departing from Ebronah, and they camped in Ezion Gaber. 

#### Numbers 33:36 And departing from Ezion Gaber, and they camped in the wilderness of Zin; and departing from the wilderness of Zin, it is Kadesh. 

#### Numbers 33:37 And departing from Kadesh, and they camped in Hor the mountain neighboring the land of Edom. 

#### Numbers 33:38 And {ascended Aaron the priest} into the mountain by order of the LORD, and he died there in the fortieth year of the exodus of the sons of Israel from out of the land of Egypt, in the {month fifth}, day one of the month. 

#### Numbers 33:39 And Aaron was three and twenty and a hundred years old when he died on Hor the mountain. 

#### Numbers 33:40 And {heard of it the Canaanite king Arad}; and this one dwelt in the land of Canaan, when {entered the sons of Israel}. 

#### Numbers 33:41 And departing from Hor the mountain, and they camped in Zalmonah. 

#### Numbers 33:42 And departing from Zalmonah, and they camped in Punon. 

#### Numbers 33:43 And departing from Punon, and they camped in Oboth. 

#### Numbers 33:44 And departing from Oboth, and they camped in Gai on the other side upon the boundaries of Moab. 

#### Numbers 33:45 And departing from Gai, and they camped in Dibon Gad. 

#### Numbers 33:46 And departing from Dibon Gad, and they camped in Almon Diblathaim. 

#### Numbers 33:47 And departing from Almon Diblathaim, and they camped upon the mountains of Abarim, before Nebo. 

#### Numbers 33:48 And departing from the mountains of Abarim, and they camped upon the descent of Moab, at the Jordan by Jericho. 

#### Numbers 33:49 And they camped by the Jordan between Jesimoth unto Abel-shittim by the descent of Moab. 

#### Numbers 33:50 And the LORD spoke to Moses near the descent of Moab by the Jordan near Jericho, saying, 

#### Numbers 33:51 Speak to the sons of Israel! and you shall say to them, You pass over the Jordan into the land of Canaan! 

#### Numbers 33:52 And you shall destroy all the ones dwelling in the land before your face; and you shall lift away their sacred heights; and all {idols their molten} -- you shall destroy them; and all their sacred monuments you shall lift away. 

#### Numbers 33:53 And you shall destroy the ones dwelling the land, and you shall dwell in it. For to you I have given their land by lot. 

#### Numbers 33:54 And you shall inherit the land by lot, according to your tribes. To the many you shall multiply their possession, and to the lesser you shall give less for their possession. To what ever part {should come forth by lot his name}, there his possession will be; according to the tribes of your patrimony you shall inherit. 

#### Numbers 33:55 And if you should not destroy the ones dwelling upon the land from your face, then it shall be whom ever you should leave behind of them, shall be barbs in your eyes, and arrows in your sides; and they shall be an enemy to you upon the land upon which you dwell. 

#### Numbers 33:56 And it will be in so far as I had determined to do to them, I shall do to you. 

#### Numbers 34:1 And the LORD spoke to Moses, saying, 

#### Numbers 34:2 Give charge to the sons of Israel! And you shall say to them, You enter into the land of Canaan! this will be to you for an inheritance -- the land of Canaan with its boundaries. 

#### Numbers 34:3 And it shall be to you the side towards the south from the wilderness of Zin unto being next to Edom. And it shall be to you the boundaries towards the south from the part of the {sea salty} from the east, 

#### Numbers 34:4 and {shall encircle you the borders} from the south to the ascending of Akrabbim, and shall go by Ennak. And {will be its outer reaches} towards the south -- Kadesh Barnea. And it shall come forth unto the property of Addar, and shall go by Azmon. 

#### Numbers 34:5 And it shall encircle the borders from Azmon to the rushing stream of Egypt, and {will be the outer reaches} the sea. 

#### Numbers 34:6 And the boundaries of the west will be to you -- the {sea great} shall define the bounds. This will be to you the boundaries of the west. 

#### Numbers 34:7 And this will be to you the boundaries towards the north. From the {sea great} you shall measure them to yourselves by the mountain. 

#### Numbers 34:8 And from mount Hor you shall measure for yourselves entering into Hamath. And {will be the outer reaches of it} the borders of Zedad. 

#### Numbers 34:9 And {shall go forth the borders} to Ziphron, and {will be its outer reaches} Hazer-enan. This will be to you the borders from the north. 

#### Numbers 34:10 And you shall measure out to you yourselves the borders of the east from Hazar-enan to Shepham. 

#### Numbers 34:11 And {shall go down the borders} from Shepham to Riblah, from the east by the springs. And {shall go down the borders} from Beel by the back of the sea of Chinnereth by the east. 

#### Numbers 34:12 And {shall go down the borders} upon the Jordan, and {will be the outer reaches sea the salty}. This shall be to you the land and its borders round about. 

#### Numbers 34:13 And Moses gave charge to the sons of Israel, saying, This is the land which you shall inherit it by lot, in which manner the LORD gave orders to give it to the nine tribes, and the half tribe of Manasseh. 

#### Numbers 34:14 For {received it the tribe of the sons of Reuben} according to the houses of their patrimony, and the tribe of the sons of Gad according to the houses of their patrimony, and the half tribe of Manasseh took their lots. 

#### Numbers 34:15 Two tribes and a half tribe took their lots on the other side of the Jordan by Jericho from the south towards the east. 

#### Numbers 34:16 And the LORD spoke to Moses, saying, 

#### Numbers 34:17 These are the names of the men, the one who shall allot for you the land -- Eleazar the priest, and Joshua the son of Nun. 

#### Numbers 34:18 And {ruler one} from out of a tribe you shall take to allot for you the land. 

#### Numbers 34:19 And these are the names of the men of the tribe of Judah -- Caleb son of Jephunneh. 

#### Numbers 34:20 Of the tribe of Simeon -- Shemuel son of Amminhud. 

#### Numbers 34:21 Of the tribe of Benjamin -- Elidad son of Chislon. 

#### Numbers 34:22 Of the tribe of Dan -- ruler Bukki son of Jogli. 

#### Numbers 34:23 Of the sons of Joseph, of the tribe of the sons of Manasseh -- ruler Hanniel son of Ephod. 

#### Numbers 34:24 The tribe of the sons of Ephraim -- ruler Kemuel son of Shiphtan. 

#### Numbers 34:25 Of the tribe of Zebulun -- ruler Elizaphan son of Parnach. 

#### Numbers 34:26 Of the tribe of the sons of Issachar -- ruler Paltiel son of Azzan. 

#### Numbers 34:27 Of the tribe of the sons of Asher -- ruler Ahihud son of Shelomi. 

#### Numbers 34:28 Of the tribe of Naphtali -- ruler Pedahel son of Ammihud. 

#### Numbers 34:29 These are the ones whom the LORD gave charge to divide the inheritance to the sons of Israel in the land of Canaan. 

#### Numbers 35:1 And the LORD spoke to Moses upon the descent of Moab, by the Jordan, across from Jericho, saying, 

#### Numbers 35:2 Give orders to the sons of Israel! and they shall give to the Levites from the lots of their possession cities to dwell in; and the outskirts of the cities round about them you shall give to the Levites. 

#### Numbers 35:3 And {shall be the cities} to dwell in. And their separation offerings of lands will be for their cattle and all their four-footed animals. 

#### Numbers 35:4 And the lands falling in with the cities, which you shall give to the Levites, shall be from the wall of the city and outside -- a thousand cubits round about. 

#### Numbers 35:5 And you shall measure outside the city -- the side the one towards the east -- two thousand cubits; and the side the one towards the south -- two thousand cubits; and the side the one towards the west -- two thousand cubits; and the side the one towards the north -- two thousand cubits; and the city between this will be for you, and the adjoining areas of the cities. 

#### Numbers 35:6 And the cities which you shall give to the Levites are the six cities of the places of refuge, which you shall give {to flee there for the one man-slaying}; and in addition to these, forty two cities. 

#### Numbers 35:7 All the cities which you shall give to the Levites are forty and eight cities, these and their outskirts. 

#### Numbers 35:8 And the cities which you shall give from the possession of the sons of Israel, from the ones having many will be many; and from the ones having less will be less; each according to his inheritance which they shall allot, they shall give from the cities to the Levites. 

#### Numbers 35:9 And the LORD spoke to Moses, saying, 

#### Numbers 35:10 Speak to the sons of Israel! and you shall say to them, You are passing over the Jordan into the land of Canaan. 

#### Numbers 35:11 And you shall draw apart to you for them cities for them; {places of refuge they will be} to you {to flee there for the man-slayer}; any one striking a soul unintentionally. 

#### Numbers 35:12 And they will be cities for you as places of refuge from the one acting as next of kin for blood, that in no way should {die the one man-slaying} until whenever he should stand before the congregation for judgment. 

#### Numbers 35:13 And the cities which you shall appoint -- the six cities -- {places of refuge will be} for you. 

#### Numbers 35:14 Three cities you shall appoint on the other side of the Jordan, and three cities you shall appoint in the land of Canaan. 

#### Numbers 35:15 A place of refuge they will be to the sons of Israel. And to the foreigner and to the sojourner among you {will be these cities} for a place of refuge to flee there to all striking a soul unintentionally. 

#### Numbers 35:16 And if by an item of iron one should strike him, and he should come to an end -- that one is a murderer -- unto death let {be put to death the murderer}! 

#### Numbers 35:17 And if by a stone from the hand in which one should die by it, then the one who should strike him, even he should die, he is a murderer -- unto death let {be put to death the murderer}! 

#### Numbers 35:18 And if by an item of wood from his hand of which one should die, as he should strike him, and one should die, he is a murderer -- unto death {shall die the murderer}! 

#### Numbers 35:19 The one acting as next of kin for blood, this one shall kill the one man-slaying; whenever he meets him, this one shall kill him. 

#### Numbers 35:20 And if through hatred he should thrust him through or should cast upon him any item by ambush, and he should die, 

#### Numbers 35:21 or through vehement anger he strikes him by the hand, and he should die -- to death let {be put to death the one striking}, he is a murderer! The one acting as next of kin for blood shall kill the one man-slaying in the meeting up with him. 

#### Numbers 35:22 But if suddenly, {not by hatred he should thrust him through}, or cast upon him any item, not from ambush, 

#### Numbers 35:23 or any stone in which he shall die by it, not knowing, and he should fall upon him, and he should die, but he {not his enemy was}, nor seeking to do evil against him; 

#### Numbers 35:24 then {shall judge the congregation} between the one striking and between the one acting as next of kin for blood, according to these cases. 

#### Numbers 35:25 And {shall rescue the congregation} the one man-slaying from the one acting as next of kin for blood; and {shall restore him the congregation} into the city of his place of refuge, of which he took refuge; and he shall dwell there until whenever {should die the priest great}, whom they anointed him {oil with the holy}. 

#### Numbers 35:26 But if by an exit {should come forth from the one man-slaying} the borders of the city in which he took refuge there, 

#### Numbers 35:27 and {should find him the one acting as next of kin for blood} outside the borders of the city of his refuge, and {should slaughter the one acting as next of kin for blood} the one man-slaying, {not liable is he}? 

#### Numbers 35:28 For in the city of his refuge let him dwell until {should die priest the great}! And after the dying of the {priest great} {will be able to return the one man-slaying} unto the land of his possession. 

#### Numbers 35:29 And these things will be to you for an ordinance of judgment unto your generations in all your dwellings. 

#### Numbers 35:30 Every one striking a soul, with witnesses, you shall slaughter the one man-slaying; and {witness one} shall not witness for a soul to die. 

#### Numbers 35:31 And you shall not take ransoms for a soul from the one murdering -- the {liable one being} is to be done away with, for unto death he shall be put to death. 

#### Numbers 35:32 And you shall not take ransoms for the one fleeing into a city of the places of refuge, to again dwell in the land, until whenever {should die the priest great}. 

#### Numbers 35:33 And in no way should you pollute with murder the land upon which you dwell upon it; for this blood pollutes {by murder the land}, and {shall not be atoned the land} from the blood having been poured out upon it, but it shall be upon the blood of the one pouring it out. 

#### Numbers 35:34 And you shall not defile the land upon which you dwell upon it, of which I should encamp among you. For I am the LORD encamping in the midst of the sons of Israel. 

#### Numbers 36:1 And came forward the rulers of the fathers' side of the tribes of the sons of Gilead, son of Machir, son of Manasseh, from the tribe of the sons of Joseph, and they spoke before Moses, and before Eleazar the priest, and before the rulers of the houses of the patrimony of the sons of Israel. 

#### Numbers 36:2 And they said, {to our master The LORD gave charge} to give the land of inheritance by lot to the sons of Israel; and {to the master the LORD gave orders} to give the inheritance of Zelophehad our brother to his daughters. 

#### Numbers 36:3 And they will be to one of the tribes of the sons of Israel for wives; and {shall be removed their lot} from the possession of our fathers, and shall be added for an inheritance of the tribe in which ever they should become wives; and from the lot of our inheritance it shall be removed. 

#### Numbers 36:4 And if there should be the release of the sons of Israel, then {shall be added their inheritance} unto the inheritance of the tribe in which ever {become wives the women}; and from the inheritance of the tribe of our family {shall be removed their inheritance}. 

#### Numbers 36:5 And Moses gave charge to the sons of Israel, through the order of the LORD, saying, Thus to the tribe of the sons of Israel, say, 

#### Numbers 36:6 This is the saying which the LORD ordered to the daughters of Zelophehad, saying, Of whom ever it is pleasing before them let them be wives, only from the people of their father let them be wives! 

#### Numbers 36:7 And {shall not be moved around the inheritance to the sons of Israel} from tribe to tribe, that each in the inheritance of the tribe of his family {shall cleave to the sons of Israel}. 

#### Numbers 36:8 And every daughter acting as next of kin of an inheritance from the tribes of the sons of Israel, {to one of the ones from out of the people of her father they shall be wives}, that {should be acting as next of kin the sons of Israel}, each in the inheritance of his father. 

#### Numbers 36:9 And {shall not be moved around the lot} from one tribe to {tribe another}, but each unto his inheritance shall {cleave to the sons of Israel}. 

#### Numbers 36:10 In which manner the LORD ordered Moses, thus {did the daughters of Zelophehad}. 

#### Numbers 36:11 And it came to pass Mahlah, Tizrah, and Hoglah, and Milchah, and Noah, daughters of Zelophehad to their cousins 

#### Numbers 36:12 of the people of Manasseh of the sons of Joseph they became wives. And {came their inheritance} to the tribe of the people of their father. 

#### Numbers 36:13 These are the commandments, and the ordinances, and the judgments, which the LORD gave charge by the hand of Moses to the sons of Israel at the descent of Moab near the Jordan by Jericho.