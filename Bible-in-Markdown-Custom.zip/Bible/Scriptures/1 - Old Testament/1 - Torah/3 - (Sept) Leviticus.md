#### Leviticus 1:1 And he called Moses, and the LORD spoke to him from out of the tent of the testimony, saying, 

#### Leviticus 1:2 Speak to the sons of Israel! And you shall say to them, A man of you, if he should bring gift offerings to the LORD from the cattle, and from the oxen, and from the sheep -- you shall bring your gift offerings thus. 

#### Leviticus 1:3 If {be a whole burnt-offering his gift offering] of the oxen, {male as an unblemished he shall bring it] to the door of the tent of the testimony. He shall bring it as acceptable before the LORD. 

#### Leviticus 1:4 And he shall place his hand upon the head of the yield offering acceptable to him, to atone for him. 

#### Leviticus 1:5 And they shall slay the calf before the LORD, and {shall bring the sons of Aaron the priests] the blood, and they shall pour the blood upon the altar round about the one at the doors of the tent of the testimony. 

#### Leviticus 1:6 And flaying the whole burnt-offering, they shall dismember it by limbs. 

#### Leviticus 1:7 And {shall put the sons of Aaron the priests] fire upon the altar. And they shall pile wood upon the fire. 

#### Leviticus 1:8 And {shall pile up the sons of Aaron the priests] the pieces, and the head, and the fat upon the wood upon the fire being upon the altar. 

#### Leviticus 1:9 But the intestines and the feet they shall wash in water. And {shall place the priest] the whole amount upon the altar -- {a yield offering it is] sacrifice scent of pleasant aroma to the LORD. 

#### Leviticus 1:10 And if {is from the sheep his gift offering] to the LORD, or also from the lambs, and of the kids for a whole burnt-offering, {male an unblemished he shall bring] for it. And he shall place his hand upon its head. 

#### Leviticus 1:11 And they shall slay it by the side of the altar, towards the north before the LORD. And {shall pour the sons of Aaron the priests] the blood of it upon the altar round about. 

#### Leviticus 1:12 And they shall divide it by limbs, and the head, and its fat. And {shall pile the priests] them upon the wood upon the fire upon the altar. 

#### Leviticus 1:13 And the intestines, and the feet they shall wash in water. And {shall bring the priest] the whole amount, and shall place them upon the altar -- it is a yield offering sacrifice scent of pleasant aroma to the LORD. 

#### Leviticus 1:14 But if from the birds {yield offering he should bring his gift] to the LORD, then he shall bring {from the turtle-doves or from the pigeons his gift], 

#### Leviticus 1:15 and {shall bring it the priest] to the altar, and shall pluck off its head, and {shall place it the priest] upon the altar, and he shall wring out the blood to the base of the altar. 

#### Leviticus 1:16 And he shall remove the crop with the feathers, and cast them by the altar according to the east, into the place of the ashes. 

#### Leviticus 1:17 And he shall break it from the wings, and shall not divide it. And {shall place it the priest] upon the altar upon the wood upon the fire -- {a yield offering it is] sacrifice scent of pleasant aroma to the LORD. 

#### Leviticus 2:1 And if a soul should bring a gift offering sacrifice to the LORD, {fine flour shall be his gift offering]. And he shall pour upon it olive oil. And he shall place upon it frankincense -- it is a sacrifice. 

#### Leviticus 2:2 And he shall bring it to the sons of Aaron of the priests. And grabbing of it full by the handful of the fine flour with the olive oil and all its frankincense, that {shall place the priest] its memorial portion upon the altar -- a sacrifice scent of pleasant aroma to the LORD. 

#### Leviticus 2:3 And the remainder of the sacrifice shall be for Aaron and his sons; it is a holy of the holies of the sacrifices of the LORD. 

#### Leviticus 2:4 And if he should bring a gift offering sacrifice being baked in an oven, it shall be of fine flour, {breads of unleavened] being mixed up with olive oil, or {pancakes unleavened breads] being smeared all over in olive oil. 

#### Leviticus 2:5 And if a sacrifice from the frying pan is your gift offering, {fine flour mixed up with olive oil unleavened breads it shall be]. 

#### Leviticus 2:6 And you shall break them into pieces, and you shall pour upon them olive oil -- it is a sacrifice to the LORD. 

#### Leviticus 2:7 And if {sacrifice be from the grate your gift offering], {fine flour with olive oil it shall be made of]. 

#### Leviticus 2:8 And you shall bring the sacrifice, what ever he should have made of these, to the LORD. And you shall bring it to the priest. And in drawing near to the altar, 

#### Leviticus 2:9 {shall remove the priest] from the sacrifice the memorial portion of it. And {shall place it the priest] upon the altar -- a yield offering scent of pleasant aroma to the LORD. 

#### Leviticus 2:10 And the amount being left behind from the sacrifice shall be for Aaron and his sons, a holy of the holies of the yield offerings of the LORD. 

#### Leviticus 2:11 Every sacrifice which ever you should bring to the LORD, you shall not make leavened; for all yeast, and all honey you shall not offer of it, to yield to the LORD a gift offering. 

#### Leviticus 2:12 Of first-fruit -- you shall bring them to the LORD, but upon the altar they shall not be brought up for a scent of pleasant aroma to the LORD. 

#### Leviticus 2:13 And every gift offering of your sacrifice {with salt shall be salted]. You shall not discontinue salt from the covenant of the LORD with your sacrifices; {upon all your gift offering you shall offer salt]. 

#### Leviticus 2:14 And if you should bring a sacrifice of first produce to the LORD, it shall be new parched {green wheat ground] to the LORD. And thus shall you bring the sacrifice of the first produce. 

#### Leviticus 2:15 And you shall pour upon it olive oil. And you shall put upon it frankincense. It is a sacrifice offering. 

#### Leviticus 2:16 And {shall offer the priest] the memorial portion of it from the green wheat with the olive oil, and all its frankincense -- it is a yield offering to the LORD. 

#### Leviticus 3:1 And if {be a sacrifice of deliverance his gift offering] to the LORD, and if then from his oxen he should bring it; if indeed a male, and if indeed a female, {unblemished he shall bring it] before the LORD. 

#### Leviticus 3:2 And he shall place his hands upon the head of the gift offering, and he shall slay it by the doors of the tent of the testimony, and {shall pour the sons of Aaron the priests] the blood upon the altar of the whole burnt-offerings round about. 

#### Leviticus 3:3 And they shall bring, for the sacrifice of deliverance a yield offering to the LORD -- and the fat covering up the belly, and all the fat upon the belly, 

#### Leviticus 3:4 and the two kidneys, and the fat upon them, the part upon the thighs; and the lobe, the one upon the liver with the kidneys, he shall remove. 

#### Leviticus 3:5 And {shall offer them the sons of Aaron the priests] upon the altar, upon the whole burnt-offerings, upon the wood upon the fire -- a yield offering scent of pleasant aroma to the LORD. 

#### Leviticus 3:6 And if {is of the sheep his gift offering sacrifice of deliverance to the LORD], {male or female as an unblemished he shall bring it]. 

#### Leviticus 3:7 If {a lamb he should bring] for his gift offering, he shall bring it before the LORD. 

#### Leviticus 3:8 And he shall place hands upon the head of his gift offering, and shall slay it by the doors of the tent of the testimony. And {shall pour the sons of Aaron the priests] the blood upon the altar round about. 

#### Leviticus 3:9 And he shall bring from the sacrifice of deliverance a yield offering to the LORD -- the fat and the loin, unblemished with the flank he shall remove it, and all the fat covering up the belly, and all the fat upon the belly, 

#### Leviticus 3:10 and both the kidneys, and the fat upon them, and the fat upon the thighs, and the lobe upon the liver, with the kidneys being removed. 

#### Leviticus 3:11 {shall offer it And the priest] upon the altar -- a scent of pleasant aroma yield offering to the LORD. 

#### Leviticus 3:12 And if {is from the goats his gift offering], then he shall bring it before the LORD. 

#### Leviticus 3:13 And he shall place hands upon the head of it. And they shall slay it before the LORD by the doors of the tent of the testimony. And {shall pour the sons of Aaron the priests] the blood upon the altar round about. 

#### Leviticus 3:14 And he shall offer of it a yield offering to the LORD -- even the fat covering up the belly, and all the fat upon the belly, 

#### Leviticus 3:15 and the two kidneys, and all the fat upon them, the fat upon the thighs; and the lobe upon the liver with the kidneys he shall remove. 

#### Leviticus 3:16 And {shall offer it the priest] upon the altar -- a yield offering scent of pleasant aroma to the LORD. All fat belongs to the LORD, 

#### Leviticus 3:17 an {law everlasting] unto your generations, in every dwelling of yours -- all fat and all blood you shall not eat. 

#### Leviticus 4:1 And the LORD spoke to Moses, saying, 

#### Leviticus 4:2 Speak to the sons of Israel! saying, If a soul should sin unintentionally from all of the orders of the LORD, of which things he must not be doing, and he should do any one of them; 

#### Leviticus 4:3 if then the {chief priest anointed] should sin to cause the people to sin, then he shall bring for his sin of which he sinned {calf of the oxen an unblemished] to the LORD for the sin. 

#### Leviticus 4:4 And he shall bring the calf by the door of the tent of the testimony before the LORD. And he shall place his hand upon the head of the calf before the LORD, and he shall slay the calf in the presence of the LORD. 

#### Leviticus 4:5 And {taking the priest anointed having perfected the hands] from the blood of the calf, even shall carry it into the tent of the testimony, 

#### Leviticus 4:6 and {shall dip the priest] the finger into the blood, and shall sprinkle on from the blood seven times with the finger before the LORD at the {veil holy]. 

#### Leviticus 4:7 And {shall put the priest] of the blood of the calf upon the horns of the altar of incense of the composition before the LORD, which is in the tent of the testimony. And {all the blood of the calf he shall pour] by the base of the altar of the yield offering, which is by the doors of the tent of the testimony. 

#### Leviticus 4:8 And all the fat of the calf, of the one of the sin offering, and he shall remove from it the fat covering up the entrails, and all the fat upon the entrails, 

#### Leviticus 4:9 and the two kidneys, and the fat upon them, by the thighs; and the lobe upon the liver with the kidneys he shall remove it, 

#### Leviticus 4:10 in which manner he removes from the calf of the sacrifice of the deliverance offering. And {shall offer it the priest] upon the altar of the yield offering. 

#### Leviticus 4:11 And the skin of the calf, and all of its flesh, with the head, and the extremities, and the belly, and the dung. 

#### Leviticus 4:12 even they shall bring forth the entire calf outside the camp into {place a clean] where they shall pour out the ashes. And they shall incinerate it upon wood with fire; {upon the outpouring of the ashes it shall be burnt]. 

#### Leviticus 4:13 And if all the congregation of Israel should not know, it being unintentionally done, and {should be unaware the thing] from the eyes of the congregation, and they should do one trespass from all of the commandments of the LORD which should not be done, and they should trespass, 

#### Leviticus 4:14 and {should be made known to them the sin] which they sinned by it; then {shall bring the congregation] a calf from out of the oxen, unblemished, for the sin offering; and he shall bring it by the doors of the tent of the testimony. 

#### Leviticus 4:15 And {shall place the elders of the congregation] their hands upon the head of the calf before the LORD. And they shall slay the calf before the LORD. 

#### Leviticus 4:16 And {shall carry the priest anointed] some of the blood of the calf into the tent of the testimony. 

#### Leviticus 4:17 And {shall dip the priest] his finger into the blood of the calf, and shall sprinkle it seven times before the LORD in front of the {veil holy]. 

#### Leviticus 4:18 And some of the blood {shall place the priest] upon the horns of the altar of the incenses of the composition, which is before the LORD, which is in the tent of the testimony. And {all the blood he shall pour out] before the base of the altar of the yield offering, of the one being before the door of the tent of the testimony. 

#### Leviticus 4:19 And {all of its fat he shall remove] from it, and he shall offer it upon the altar. 

#### Leviticus 4:20 And he shall offer the calf, in which manner he did the calf for the sin offering -- so it shall be done. And {shall atone for them the priest], and {shall be forgiven them the sin]. 

#### Leviticus 4:21 And they shall bring forth the {calf complete] outside the camp. And they shall incinerate the calf, in which manner they incinerated the calf formerly -- {a sin offering for the congregation it is]. 

#### Leviticus 4:22 And if the ruler should sin, and should commit one trespass of all of the commandments of the LORD his God which he shall not do unintentionally, and should sin and should trespass, 

#### Leviticus 4:23 and {should be known to him the sin by which he sinned by it], then he shall bring his gift offering of a young he-goat from the goats -- a male unblemished. 

#### Leviticus 4:24 And he shall place his hand upon the head of the young he-goat, and they shall slay it in the place of which they slay the whole burnt-offerings before the LORD -- {a sin offering it is]. 

#### Leviticus 4:25 And {shall place the priest] some of the blood of the one of the sin offering, with the finger, upon the horns of the altar of the whole burnt-offerings. And {all of its blood he shall pour out] by the base of the altar of the whole burnt-offerings. 

#### Leviticus 4:26 And {all of its fat he shall offer] upon the altar, as the fat sacrifice of deliverance. And {shall atone for him the priest] of his sin, and it shall be forgiven him. 

#### Leviticus 4:27 And if {soul one] should sin unintentionally from among the people of the land, in the committing one trespass from all of the commandments of the LORD, which should not be done, and he should trespass, 

#### Leviticus 4:28 and {should be made known to him the sin] which he sinned by it, then he shall bring the gift offering -- {yearling of the goats female an unblemished he shall offer] for the sin which he sinned. 

#### Leviticus 4:29 And he shall place his hand upon the head of his sin offering; and they shall slay the yearling, the one of the sin offering, in the place where they slay the whole burnt-offerings. 

#### Leviticus 4:30 And {shall take the priest] some of its blood with his finger, and shall put it upon the horns of the altar of the whole burnt-offerings. And all of its blood he shall pour out by the base of the altar. 

#### Leviticus 4:31 And all the fat he shall remove in which manner he removed the fat from the sacrifice of deliverance. And {shall offer it the priest] upon the altar for a scent of pleasant aroma to the LORD. And {shall atone for him the priest], and it shall be forgiven him. 

#### Leviticus 4:32 And if {a sheep he should bring] for his gift for the sin offering, {female as an unblemished he shall bring it]. 

#### Leviticus 4:33 And he shall place his hand upon the head of the one for the sin offering. And they shall slay it for a sin offering in the place of which they slay the whole burnt-offerings. 

#### Leviticus 4:34 And {taking the priest] some of the blood of the one for the sin offering with his finger, he shall place it upon the horns of the altar of the whole offering. And all of its blood he shall pour out by the base of the altar of the whole burnt-offering. 

#### Leviticus 4:35 And all of its fat he shall remove in which manner {was removed the fat of the sheep from the sacrifice of deliverance]. And {shall place it the priest] upon the altar, upon the whole burnt-offerings of the LORD. And {shall atone for him the priest], for the sin of which he sinned, and it shall be forgiven him. 

#### Leviticus 5:1 And if a soul should sin, and should hear a voice of conjuring, and witness this, or see, or be fully conscious of it, if he should not report it, he takes responsibility for his sin. 

#### Leviticus 5:2 That soul which ever should touch any thing unclean, or decaying flesh, or {taken by wild beasts that which is unclean], or of the decaying flesh of abominations of the unclean, or of the decaying flesh {cattle of unclean], 

#### Leviticus 5:3 or should touch of the uncleanness of a man, of any of his uncleanness -- what ever touching he should be defiled, and he be unaware of it, but after this he should know even he should have trespassed. 

#### Leviticus 5:4 The soul, in what ever he should swear by an oath, drawing apart his lips to do evil or {well to do] according to all as much as {who should draw apart the man] according to an oath, and should be unaware of it, and this one should know and should sin any one of these things -- 

#### Leviticus 5:5 then he shall declare openly the sin for which he has sinned by it. 

#### Leviticus 5:6 And he shall bring for which he trespassed against the LORD, for the sin of which he sinned, a female from the sheep, a ewe-lamb or a yearling of the goats for a sin offering. And {shall atone for him the priest] for the sin which he sinned, and {will be forgiven him the sin]. 

#### Leviticus 5:7 And if {is not strong his hand] to be fit for bringing the sheep, he shall bring for his sin offering of which he sinned, two turtle-doves, or two young pigeons to the LORD; one for a sin offering, and one for a whole burnt-offering. 

#### Leviticus 5:8 And he shall bring them to the priest. And {shall bring the priest] the one for the {sin offering prior]. And {shall pluck off the priest] its head from the neck, and shall not divide it. 

#### Leviticus 5:9 And he shall sprinkle from the blood of the one for the sin offering upon the wall of the altar; but the rest of the blood he shall drop upon the base of the altar -- {an offering on account of sin for it is]. 

#### Leviticus 5:10 And the second one he shall offer for a whole offering as is fit. And {shall atone for him the priest] for his sin which he sinned, and it shall be forgiven him. 

#### Leviticus 5:11 And if {should not find his hand] a pair of turtle-doves, or two young pigeons, then he shall bring his gift for which he sinned -- the tenth of the ephah of fine flour for a sin offering. He shall not pour upon it olive oil, nor place upon it frankincense, for {on account of sin it is an offering]. 

#### Leviticus 5:12 And he shall bring it to the priest. And {grabbing the priest] from it a full handful of his, {the memorial portion of it shall place] upon the altar, upon the whole burnt-offerings to the LORD -- {a sin offering it is]. 

#### Leviticus 5:13 And {shall atone for him the priest] for his sin which he sinned against one of these things -- and it shall be forgiven him. And the remaining will be for the priest as a sacrifice of the fine flour. 

#### Leviticus 5:14 And the LORD spoke to Moses, saying, 

#### Leviticus 5:15 The soul who ever should be unaware himself with forgetfulness, and should sin unintentionally of the holy things of the LORD, then he shall bring for his trespass offering to the LORD {ram an unblemished] of the flocks, of the value of silver of shekels, in the shekel in the holy place, for what he trespassed. 

#### Leviticus 5:16 And what ever he sinned, {from the holy things he shall pay], and the fifth part he shall add to it. And he shall give it to the priest. And the priest shall atone for him by the ram of the trespass offering. And it shall be forgiven him. 

#### Leviticus 5:17 And the soul who ever should sin, and should commit one trespass from all of the commandments of the LORD, which {not must he] do, and does not know, and should trespass, and should take the guilt for his sin; 

#### Leviticus 5:18 then he shall bring {ram an unblemished] from out of the flocks, the value of silver for the trespass offering to the priest. And {shall atone for him the priest] for his ignorance of which he was ignorant of, and he did not know. And it will be forgiven him, 

#### Leviticus 5:19 for he trespassed a trespass -- it is a trespass offering before the LORD. 

#### Leviticus 6:1 And the LORD spoke to Moses, saying, 

#### Leviticus 6:2 The soul which ever should sin, and by ignoring should ignore the commandments of the LORD, and should lie concerning the neighbor in a matter of trust, or concerning fellowship, or concerning seizure, or he wronged {in any way the neighbor], 

#### Leviticus 6:3 or he found something lost and should lie concerning it, and should swear by an oath unjustly concerning any one of all which ever {should do a man], so as to sin by these. 

#### Leviticus 6:4 Then it shall be when ever he should sin, and trespass, that he should give back the seized thing which he seized by force, or the offence which he wronged, or the trust which was placed in him, or the loss which he found of every thing, of which he swore by an oath concerning it unjustly; and he shall pay it, the total sum, and his fifth part shall be added upon it -- whatever is his he shall give back in the day he should be reproved. 

#### Leviticus 6:5 And {for his trespass offering he shall bring] to the LORD, {ram an unblemished] from the flocks, the value for what he trespassed. 

#### Leviticus 6:6 And {shall atone for him the priest] before the LORD. And he shall be forgiven for any one of all which he did, and trespassed by it. 

#### Leviticus 6:7 And the LORD spoke to Moses, saying, 

#### Leviticus 6:8 Give charge to Aaron and his sons! saying, 

#### Leviticus 6:9 This is the law of the bringing the whole burnt-offering. This is the bringing the whole burnt-offering upon its burning upon the altar the entire night until morning; and the fire of the altar shall burn upon it, and shall not be extinguished. 

#### Leviticus 6:10 And {shall put on the priest inner garment a flaxen linen], and {pants flaxen linen he shall put on] on his body. And he shall remove the incinerated remains, which ever {should have consumed the fire] of the whole burnt-offering of the altar. And he shall place it next to the altar. 

#### Leviticus 6:11 And he shall take off his apparel, and shall put on {apparel other]. And he shall bring forth the incinerated remains outside the camp unto {place a clean]. 

#### Leviticus 6:12 And the fire upon the altar shall be kept burning upon it, it shall not be extinguished. And {shall burn upon it the priest wood] in the morning by morning; and he shall pile upon it the whole burnt-offering. And he shall place upon it the fat of the deliverance offering. 

#### Leviticus 6:13 And fire shall always burn upon the altar; it shall not be extinguished. 

#### Leviticus 6:14 This is the law of the sacrifice offering which {shall bring it the sons of Aaron] before the LORD, before the altar. 

#### Leviticus 6:15 And he shall remove from it a handful of fine flour of the sacrifice offering with its olive oil, and with all its frankincense being upon the sacrifice. And he shall offer up upon the altar a yield offering scent of pleasant aroma, a memorial of it to the LORD. 

#### Leviticus 6:16 And the remainder of it Aaron shall eat and his sons. {unleavened It shall be eaten] in {place a holy]; in the courtyard of the tent of the testimony they shall eat it. 

#### Leviticus 6:17 It shall not be baked being leavened. {it as a portion I have given] to them of the yield offerings of the LORD. {a holy of holies It is], as the one for the sin offering, and as the one for the trespass offering. 

#### Leviticus 6:18 Every male of the priests shall eat it -- {law an eternal] unto your generations of the yield offerings of the LORD. All who ever should touch them shall be sanctified. 

#### Leviticus 6:19 And the LORD spoke to Moses, saying, 

#### Leviticus 6:20 This is the gift offering of Aaron and his sons which they shall bring to the LORD in the day which ever you shall anoint him -- the tenth of the ephah of fine flour for a sacrifice offering always, half of it in the morning, and half of it at dusk. 

#### Leviticus 6:21 {upon a frying pan with olive oil You shall prepare it]. {being mixed up He shall bring it], kneaded, as a sacrifice of pieces; he shall bring a sacrifice for a scent of pleasant aroma to the LORD. 

#### Leviticus 6:22 And the {priest anointed] in place of him from his sons will prepare it. It is {law an eternal] to the LORD -- all shall be completed. 

#### Leviticus 6:23 And every sacrifice offering of a priest shall be wholly burnt, and it shall not be eaten. 

#### Leviticus 6:24 And the LORD spoke to Moses, saying, 

#### Leviticus 6:25 Speak to Aaron and to his sons, saying, This is the law of the sin offering. In the place where they slay the whole burnt-offerings, they shall slay also the one for the sin offering before the LORD -- {a holy of holies it is]. 

#### Leviticus 6:26 The priest offering it, he shall eat it in {place a holy]; he shall eat it in the courtyard of the tent of the testimony. 

#### Leviticus 6:27 Every one touching of its meats shall be sanctified. And to whom ever should be sprinkled upon of its blood, upon the cloak -- the one who should be sprinkled upon by it shall be washed in {place a holy]. 

#### Leviticus 6:28 And {item an earthenware] of what ever should have been boiled in it, it shall be broken. And if {in an item of brass it should have been boiled], he shall scour it, and wash it out in water. 

#### Leviticus 6:29 Every male among the priests shall eat it; {a holy of holies it is] to the LORD. 

#### Leviticus 6:30 And all the meats concerning the sin offering, what ever might be carried in of their blood into the tent of the testimony to atone in the holy place, shall not be eaten; {in fire it shall be incinerated]. 

#### Leviticus 7:1 And this is the law of the ram for the trespass offering -- {a holy of holies it is]. 

#### Leviticus 7:2 In the place of which they slay the whole burnt-offering, they shall slay the ram of the trespass offering before the LORD. And {the blood he shall pour] upon the base of the altar round about. 

#### Leviticus 7:3 And all the fat of it he shall offer of it, and the loin, and the fat covering up the entrails, and all the fat upon the entrails, 

#### Leviticus 7:4 and the two kidneys, and the fat upon them by the thighs, and the lobe upon the liver, with the kidneys, he shall remove them. 

#### Leviticus 7:5 And {shall offer them the priest] upon the altar of the yield offering to the LORD; {for a trespass offering it is]. 

#### Leviticus 7:6 Every male of the priests shall eat them; in {place the holy] they shall eat -- {a holy of holies it is]. 

#### Leviticus 7:7 As the one concerning the sin offering, so also the trespass offering -- {law there is one] for them. The priest, whoever shall atone for it, it shall be to him. 

#### Leviticus 7:8 And the priest bringing the whole burnt-offering of a man, the skin of the whole burnt-offering which he offers will be his. 

#### Leviticus 7:9 And every sacrifice offering which should be prepared in the oven, and all which shall be prepared upon a grate or upon a frying pan, of the priest offering it, it shall be his. 

#### Leviticus 7:10 And every sacrifice offering being prepared in olive oil, and not being prepared with olive oil -- all of it {for the sons of Aaron will be], to each equally. 

#### Leviticus 7:11 This is the law of the sacrifice of deliverance which they shall bring to the LORD. 

#### Leviticus 7:12 If indeed for praise a man should offer it, then he shall bring upon the sacrifice of praise {breads unleavened] made of fine flour, being prepared in olive oil, and {pancakes unleavened] being smeared all over with olive oil, and fine flour being mixed with olive oil. 

#### Leviticus 7:13 With {breads leavened] he shall offer his gift with a sacrifice of praise of his deliverance. 

#### Leviticus 7:14 And he shall bring from his offering one portion from all his gift offerings, a cut-away portion to the LORD; for the priest who is pouring on the blood of the deliverance offering, it will be his. 

#### Leviticus 7:15 And the meats of the sacrifice of praise of deliverance, it will be his. And in the day it is presented, it shall be eaten. They shall not leave behind of it into the morning. 

#### Leviticus 7:16 And if {a vow it should be], {the voluntary offering he should sacrifice], the one of his gift offering; in which ever day he should bring his sacrifice, it shall be eaten and in the next morning. 

#### Leviticus 7:17 And the thing being left from the meats of the sacrifice until {day the third in fire shall be incinerated]. 

#### Leviticus 7:18 And if in eating he should eat from the meats of the {day third], it shall not be accepted to the one offering it; it shall not be imputed to him -- it is a defilement, and the soul who should eat of it, {the sin he shall bear]. 

#### Leviticus 7:19 And meats, whatever as much as touch any unclean thing, shall not be eaten; {in fire it shall be incinerated]. Every one clean shall eat clean meats. 

#### Leviticus 7:20 And the soul which ever should eat from the meats of the sacrifice of the deliverance, which is to the LORD, then his uncleanness is upon him, {shall be destroyed that soul] from its people. 

#### Leviticus 7:21 And the soul which ever should touch any thing unclean, or from an uncleanness of man, or of the four-footed creatures of the unclean, or any abomination of an unclean thing, and should eat from the meats of the sacrifice of the peace offerings which is for the LORD, {shall be destroyed that soul] from its people. 

#### Leviticus 7:22 And the LORD spoke to Moses, saying, 

#### Leviticus 7:23 Speak to the sons of Israel! saying, All fat of oxen and sheep and goats you shall not eat! 

#### Leviticus 7:24 And the fat of decaying flesh, and that taken by wild beasts shall be appointed for all work, but for food it shall not be eaten. 

#### Leviticus 7:25 Every one eating fat off the cattle, of which he will bring from them as a yield offering to the LORD, {shall be destroyed that soul] from its people. 

#### Leviticus 7:26 All blood you shall not eat in all of your house, of either the cattle or of the birds. 

#### Leviticus 7:27 Every soul which ever should eat blood, {shall be destroyed that soul] from its people. 

#### Leviticus 7:28 And the LORD spoke to Moses, saying, 

#### Leviticus 7:29 And to the sons of Israel you shall speak, saying, The one offering a sacrifice of his peace offerings to the LORD, he shall bring his gift to the LORD of the sacrifice of his deliverance offering. 

#### Leviticus 7:30 His own hands shall bring the yield offerings to the LORD; the fat upon the breast, and the lobe, the one upon the liver, he shall bring them so as to place a gift before the LORD. 

#### Leviticus 7:31 And {shall offer the priest] the fat upon the altar. And {shall be the breast] Aaron's and his sons. 

#### Leviticus 7:32 And the {shoulder right] you shall give as a cut-away portion to the priest from the sacrifices of your deliverance offering. 

#### Leviticus 7:33 The one offering the blood of the deliverance offering, and the fat, of the sons of Aaron -- to him will be the {shoulder right] for a portion. 

#### Leviticus 7:34 For the breast of the increase offering and the shoulder of the cut-away portion I have taken from the sons of Israel from the sacrifices of your deliverance offering, and I gave them to Aaron to the priest and to his sons, {law an eternal] for the sons of Israel. 

#### Leviticus 7:35 This is the anointing of Aaron, and the anointing of his sons, of their portion of the yield offerings of the LORD, in which day he brought them to officiate as priest to the LORD; 

#### Leviticus 7:36 in so far as the LORD gave charge to give to them in which day he anointed them from the sons of Israel, {law an eternal] unto their generations. 

#### Leviticus 7:37 This is the law of the whole burnt-offerings, and of sacrifice, and for a sin offering, and of the trespass offering, and of the consecration, and of the sacrifice of deliverance offering, 

#### Leviticus 7:38 in which manner the LORD gave charge to Moses on mount Sinai, in which day he gave charge to the sons of Israel to bring their gift offerings before the LORD in the wilderness of Sinai. 

#### Leviticus 8:1 And the LORD spoke to Moses, saying, 

#### Leviticus 8:2 Take Aaron and his sons, and the apparels, and the olive oil for the anointing, and the calf for the sin offering, and the two rams, and the bin of the unleavened breads! 

#### Leviticus 8:3 And let all the congregation hold an assembly at the door of the tent of the testimony! 

#### Leviticus 8:4 And Moses did in which manner {ordered him the LORD]. And he held an assembly of the congregation at the door of the tent of the testimony. 

#### Leviticus 8:5 And Moses said to the congregation, This is the word which the LORD gave charge to do. 

#### Leviticus 8:6 And Moses led forward Aaron, and his sons, and bathed them in water. 

#### Leviticus 8:7 And he put on him the inner garment, and tied {around him the belt], and put on him the undergarment, and placed upon him the shoulder-piece, and tied it together on him, according to the making of the shoulder-piece, and fastened it to him. 

#### Leviticus 8:8 And he placed upon him the oracle; and he placed upon the oracle the Manifestation and the Truth. 

#### Leviticus 8:9 And he placed the mitre upon his head. And he placed {upon the mitre down in front of him panel the golden], for the {consecrating holy], in which manner the LORD gave orders to Moses. 

#### Leviticus 8:10 And Moses took from the oil of the anointing, 

#### Leviticus 8:11 and he sprinkled from it upon the altar seven times. And he anointed the altar, and sanctified it, and all its utensils, and the bathing tub, and its base. And he sanctified them, and he anointed the tent, and all its items, and he sanctified it. 

#### Leviticus 8:12 And Moses poured of the oil of the anointing upon the head of Aaron. And he anointed him, and sanctified him. 

#### Leviticus 8:13 And Moses led forward the sons of Aaron; and he put on them inner garments, and tied around them belts, and put on them turbans, just as the LORD gave orders to Moses. 

#### Leviticus 8:14 And Moses brought the calf, the one for the sin offering. And {placed Aaron and his sons] their hands upon the head of the calf, of the one for the sin offering. 

#### Leviticus 8:15 And he slew it. And Moses took of the blood, and put it upon the horns of the altar round about with his finger; and he cleansed the altar. And the blood he poured out upon the base of the altar; and he sanctified it, to atone upon it. 

#### Leviticus 8:16 And Moses took all the fat upon the entrails, and the lobe upon the liver, and both of the kidneys, and the fat upon them; and Moses offered them upon the altar. 

#### Leviticus 8:17 And the calf and its hide, and its meats, and its dung he incinerated in fire outside the camp, in which manner the LORD gave orders to Moses. 

#### Leviticus 8:18 And Moses brought the ram, the one for a whole burnt-offering. And {placed Aaron and his sons] their hands upon the head of the ram. 

#### Leviticus 8:19 And Moses slew the ram. And Moses poured the blood upon the altar round about. 

#### Leviticus 8:20 And {the ram he dressed] according to its limbs. And Moses offered up the head, and the limbs, and the fat; 

#### Leviticus 8:21 and the belly and the feet he washed in water. And Moses offered up the entire ram upon the altar. {a whole burnt-offering It is] for a scent of pleasant aroma; {a yield offering it is] to the LORD, just as the LORD gave charge to Moses. 

#### Leviticus 8:22 And Moses brought the {ram second], the ram of consecration. And {placed Aaron and his sons] their hands upon the head of the ram. 

#### Leviticus 8:23 And he slew it. And Moses took some of its blood, and placed it upon the lobe of the {ear of Aaron right], and upon the thumb {hand of his right], and upon the big toe {foot of his right]. 

#### Leviticus 8:24 And Moses brought the sons of Aaron. And Moses put some of the blood upon the lobe {ear of their right], and upon the thumb {hand of their right], and upon the big toe {foot of their right]. And Moses poured the blood upon the altar round about. 

#### Leviticus 8:25 And he took the fat, and the loin, and the fat upon the belly, and the lobe of the liver, and the two kidneys, and the fat upon them, and the {shoulder right]. 

#### Leviticus 8:26 And from the bin of the consecration being before the LORD, he took {bread loaf one unleavened], and {bread loaf made of olive oil one], and {pancake one], and he placed them upon the fat and upon the {shoulder right]. 

#### Leviticus 8:27 And he put all these in the hands of Aaron, and upon the hands of his sons. And he offered them as a cut-away portion before the LORD. 

#### Leviticus 8:28 And Moses took from their hands, and he offered them upon the altar, upon the whole burnt-offering of the consecration, which is a scent of pleasant aroma; {a yield offering it is] to the LORD. 

#### Leviticus 8:29 And Moses taking the breast, removed it for an increase offering before the LORD, from the ram of the consecration; and it became Moses' portion, as the LORD gave charge to Moses. 

#### Leviticus 8:30 And Moses took of the oil of the anointing, and of the blood upon the altar; and he sprinkled it upon Aaron, and upon his apparels, and upon his sons, and upon the apparels of his sons. And he sanctified Aaron and his apparels, and his sons, and the apparels of his sons with him. 

#### Leviticus 8:31 And Moses said to Aaron and his sons, Boil the meats by the gate of the tent of the testimony in {place the holy]! And there you shall eat them, and the bread loaves, of the ones in the bin of the consecration, in which manner it was ordered to me, saying, Aaron and his sons shall eat them. 

#### Leviticus 8:32 And the amount being left behind of the meats and the bread loaves {in fire shall be incinerated]. 

#### Leviticus 8:33 And from the door of the tent of the testimony you shall not come forth for seven days, until the days of fullness, the days of your consecration; for seven days he will perfect your hands, 

#### Leviticus 8:34 just as he did in this day, in which the LORD gave charge to do, so as to atone for you. 

#### Leviticus 8:35 And upon the door of the tent of the testimony you shall sit seven days -- day and night; and you shall guard the injunctions of the LORD, and you shall not die. For thus {gave charge to me the LORD]. 

#### Leviticus 8:36 And {observed Aaron and his sons] all the words which the LORD gave orders by the hand of Moses. 

#### Leviticus 9:1 And it came to pass on the {day eighth], Moses called Aaron, and his sons, and the council of elders of Israel. 

#### Leviticus 9:2 And Moses said to Aaron, Take to yourself a young calf from the oxen for a sin offering, and a ram for a whole burnt-offering, unblemished, and offer them before the LORD! 

#### Leviticus 9:3 And to the council of elders of Israel you shall speak, saying, Take a young he-goat from out of the goats, one for a sin offering, and a young calf, and a lamb of a year old for a whole offering, unblemished; 

#### Leviticus 9:4 and a calf, and a ram for a sacrifice of deliverance offering, before the LORD; and fine flour being mixed up with olive oil! For today the LORD will appear among you. 

#### Leviticus 9:5 And they took as Moses gave charge before the tent of the testimony. And came forward all the congregation, and they stood before the LORD. 

#### Leviticus 9:6 And Moses said, This is the saying which the LORD gave orders, do it! And {will appear among you the glory of the LORD]. 

#### Leviticus 9:7 And Moses said to Aaron, Come forward to the altar, and offer the thing for your sin offering, and your whole burnt-offering! And atone for yourself, and for your house! And offer the gift offering of the people, and atone for them! just as the LORD gave charge to Moses. 

#### Leviticus 9:8 And Aaron came forward to the altar, and he slew the calf, the one for his sin offering. 

#### Leviticus 9:9 And {brought the sons of Aaron] the blood to him. And he dipped his finger into the blood, and put it upon the horns of the altar. And the blood he poured upon the base of the altar. 

#### Leviticus 9:10 And the fat, and the kidneys, and the lobe of the liver of the one for the sin offering he offered upon the altar, in which manner the LORD gave charge to Moses. 

#### Leviticus 9:11 And the meats, and the hide he incinerated by fire outside the camp. 

#### Leviticus 9:12 And he slew the whole burnt-offering. And {brought the sons of Aaron] the blood to him. And he poured it upon the altar round about. 

#### Leviticus 9:13 And the whole burnt-offering -- they brought it by limbs, and head; and he placed them upon the altar. 

#### Leviticus 9:14 And he washed the belly and the feet in water. And they placed the whole burnt-offering upon the altar. 

#### Leviticus 9:15 And they brought the gift of the people. And he took the young he-goat, the one for the sin offering of the people, and he slew it, and cleansed it, as also the first. 

#### Leviticus 9:16 And he brought the whole burnt-offering, and offered it as fitting. 

#### Leviticus 9:17 And he brought the sacrifice offering, and he filled the hand of it. And placed it upon the altar separate from the {whole burnt-offering early morning]. 

#### Leviticus 9:18 And he slew the calf and the ram for the sacrifice of the deliverance offering of the one of the people. And {brought the sons of Aaron] the blood to him. And he poured it upon the altar round about, 

#### Leviticus 9:19 and the fat, the fat from the calf, and from the {of the ram loin], and the fat covering up the belly, and the two kidneys, and the fat upon them, and the lobe upon the liver. 

#### Leviticus 9:20 And he placed the fat upon the breasts. And he offered the fat upon the altar. 

#### Leviticus 9:21 And the breast and the {shoulder right] Aaron removed as a cut-away portion before the LORD, in which manner he gave orders to Moses. 

#### Leviticus 9:22 And Aaron lifting hands upon the people, he blessed them. And he came down after offering the thing for the sin offering, and the things of whole burnt-offerings, and the things of the deliverance offering. 

#### Leviticus 9:23 And {entered Moses and Aaron] into the tent of the testimony. And coming forth they blessed the people. And {appeared the glory of the LORD] to all the people. 

#### Leviticus 9:24 And {came forth fire] from the LORD, and it devoured the things upon the altar, both the whole burnt-offerings and the fat. And {saw all the people], and were amazed. And they fell upon their face. 

#### Leviticus 10:1 And {taking the two sons of Aaron Nadab and Abihu each] his censer, they placed upon them fire, and put upon them incense, and offered before the LORD {fire an alien], which {assigned not the LORD] to them. 

#### Leviticus 10:2 And came forth fire from the LORD, and it devoured them, and they died before the LORD. 

#### Leviticus 10:3 And Moses said to Aaron, This is what the LORD spoke, saying, Among the ones approaching to me I will be sanctified, and in all the congregation I will be glorified. And Aaron was vexed. 

#### Leviticus 10:4 And Moses called Mishael and Elzaphan, sons of Uzziel brother of the father of Aaron, and said to them, Come forward and lift your brethren from before the holies outside of the camp. 

#### Leviticus 10:5 And they came forward, and lifted them by their garments outside of the camp, in which manner Moses said. 

#### Leviticus 10:6 And Moses said to Aaron, and Eleazar and Ithamar his sons being left behind, Your heads shall not be without a turban, and your cloaks you shall not tear, that you should not die, and {upon all the congregation be rage]. But your brethren, all the house of Israel, shall weep for the combustion, which {set on fire the LORD]. 

#### Leviticus 10:7 And from the door of the tent of the testimony you shall not go forth, that you should not die. {the oil For] of the anointing of the LORD {upon you is]. And they did according to the saying of Moses. 

#### Leviticus 10:8 And the LORD spoke to Aaron, saying, 

#### Leviticus 10:9 Wine and liquor you are not to drink, you and your sons with you, when ever you should enter into the tent of the testimony, or in your going to the altar, that no way you should die -- it is {law an eternal] unto your generations; 

#### Leviticus 10:10 to distinguish between the holy things and the profane, and between the unclean and the clean, 

#### Leviticus 10:11 and to instruct the sons of Israel all together the laws which the LORD spoke to them through the hand of Moses. 

#### Leviticus 10:12 And Moses spoke to Aaron, and to Eleazar and Ithamar, the sons of his being left, You take the sacrifice offering being left from the yield offerings of the LORD, and eat unleavened breads by the altar! For {a holy of holies it is]. 

#### Leviticus 10:13 And you shall eat it in {place the holy]. {a law For to you it is], and a law to your sons -- this from the yield offerings of the LORD. For thus it has been given charge to me. 

#### Leviticus 10:14 And the breast of the separation offering, and the shoulder of the cut-away portion you shall eat in {place the holy], you, and your sons, and your house with you -- a law to you, and a law to your sons it was given of the sacrifices of the deliverance offerings of the sons of Israel. 

#### Leviticus 10:15 The shoulder of the cut-away portion and the breast of the separation offering upon the yield offerings of the fats, they shall bring as a separation offering to separate before the LORD. And it will be to you, and to your sons, and to your daughters with you, {law an eternal]; in which manner the LORD gave orders to Moses. 

#### Leviticus 10:16 And {the young he-goat for the sin offering seeking] Moses sought after. But thus it had been set on fire. And Moses was enraged at Eleazar and Ithamar the sons of Aaron, the ones being left, saying, 

#### Leviticus 10:17 Why did you not eat the thing for the sin offering in {place the holy]? For because {a holy of holies it is]. This he gave to you to eat, that you should remove the sin of the congregation, and should atone for them before the LORD. 

#### Leviticus 10:18 For not was brought from the blood of it into the holy place. In person inside you shall eat it in {place the holy], in which manner it was ordered to me. 

#### Leviticus 10:19 And Aaron spoke to Moses, saying, If today they have brought the things for their sin offering, and the things of their whole burnt-offerings before the LORD, and has come to pass to me such things, and I shall eat the thing -- for the sin offering today, shall it be pleasing to the LORD? 

#### Leviticus 10:20 And Moses heard it, and it pleased him. 

#### Leviticus 11:1 And the LORD spoke to Moses and Aaron, saying, 

#### Leviticus 11:2 Speak to the sons of Israel! saying, These are the animals which you shall eat from out of all of the animals of the ones upon the earth. 

#### Leviticus 11:3 Every animal being cloven hoof, and cloven-footed, clawing with two claws, and taken up chewing the cud among the animals, these you shall eat. 

#### Leviticus 11:4 Except from these you shall not eat -- of the ones taking up chewing the cud, and of the ones not being cloven of the hoofs, and clawing cloven-footed -- the camel, for {takes up chewing the cud this one], and the hoof is not cloven; this one is unclean to you. 

#### Leviticus 11:5 And the hare, for {takes up chewing the cud this one], and its hoof is not cloven; this one is unclean to you. 

#### Leviticus 11:6 And the hyrax, for {does not take up chewing the cud this one], and the hoof is not cloven; this one is unclean to you. 

#### Leviticus 11:7 And the pig, for {is cloven of hoof this one], and claws with the claw of the hoof, but this one takes not up chewing the cud; this one is unclean to you. 

#### Leviticus 11:8 Of their meats you shall not eat, and of the meats of their decaying flesh you shall not touch; these are unclean to you. 

#### Leviticus 11:9 And these you shall eat out of all the ones in the waters -- all as many as there are fins to them and scales in the waters, and in the seas, and in the rushing streams -- these you shall eat. 

#### Leviticus 11:10 And all as many as there are not fins to them, nor scales, being in the waters, and in the seas, and in the rushing streams, of all which bubble the waters, and from every soul living in the water, it is an abomination. 

#### Leviticus 11:11 And they shall be abominations to you; {of their meats you shall not eat]. And their decaying flesh you shall abhor. 

#### Leviticus 11:12 And all as many as there are not fins to them, nor scales of the ones in the waters -- {an abomination this is] to you. 

#### Leviticus 11:13 And these you shall abhor from the winged creatures, and they shall not be eaten, it is an abomination -- the eagle, and the griffin, and the osprey, 

#### Leviticus 11:14 and the vulture, and kite, and the ones likened to it. And all the crows, and the ones likened to it. 

#### Leviticus 11:15 And the ostrich, and owl, and gull, and the ones likened to it. 

#### Leviticus 11:16 And hawk, and the ones likened to it. 

#### Leviticus 11:17 And long-eared owl, and cormorant, and ibis, 

#### Leviticus 11:18 and the purple-legged stork, and pelican, and swan, 

#### Leviticus 11:19 and heron, and curlew, and the ones likened to it. And hoopoe, and bat, 

#### Leviticus 11:20 and all the crawling things of the winged creatures which go upon fours, it is an abomination to you. 

#### Leviticus 11:21 But these you shall eat from the crawling things of the winged creatures which go upon fours -- the ones which have legs upward from their feet to spring up with them upon the earth. 

#### Leviticus 11:22 And you shall eat these from them -- the grasshopper, and the ones likened to it; and the hopping locust, and the ones likened to it; and crawling locust, and the ones likened to it; and the locust, and the ones likened to it. 

#### Leviticus 11:23 And every crawling thing of the winged creatures which are of four feet -- it is an abomination to you. 

#### Leviticus 11:24 And by these you shall be defiled -- every one touching their decaying flesh will be unclean until evening. 

#### Leviticus 11:25 And every one lifting their decaying flesh shall wash their garments, and shall be unclean until evening. 

#### Leviticus 11:26 And among all the animals which are cloven hoof, and with cloven-footed claws, and of chewing the cud does not chew the cud -- {unclean they shall be] to you; every one touching their decaying flesh will be unclean until evening. 

#### Leviticus 11:27 And every one which goes upon his hands among all the wild beasts, which go upon fours, it is unclean to you. Every one touching of their decaying flesh will be unclean until evening. 

#### Leviticus 11:28 And the one lifting of their decaying flesh, he shall wash his garments, and he will be unclean until evening. {unclean These shall be] to you. 

#### Leviticus 11:29 And these are unclean to you of the crawling things, of the ones crawling upon the earth -- the weasel, and the mouse, and the {crocodile dry land], and the ones likened to it. 

#### Leviticus 11:30 The field-mouse, and chameleon, and newt, and lizard, and mole -- 

#### Leviticus 11:31 these are unclean to you from out of all the crawling things of the ones crawling upon the earth; every one touching their decaying flesh will be unclean until evening. 

#### Leviticus 11:32 And all upon what ever should fall upon it, upon their ones having died, shall be unclean from every {item wooden], or garment, or skin, or a sackcloth. Every item in which ever {should be done work] by it {into water shall be dipped], and it shall be unclean until evening -- and then it will be clean. 

#### Leviticus 11:33 And every {item earthenware] into what ever should fall in from them inside, as much as should be inside, it shall be unclean, and it shall be broken. 

#### Leviticus 11:34 And every food eaten, into what ever should come upon it water from such a container, will be unclean to you. And every beverage which is drunk in any such receptacle, it shall be unclean. 

#### Leviticus 11:35 And all upon what ever should fall from their decaying flesh upon it, it shall be unclean -- ovens and pots with feet shall be demolished; {unclean these are], and they shall be unclean to you. 

#### Leviticus 11:36 Except springs of waters, or a well, or a gathering of water, it will be clean; but the one touching their decaying flesh, it shall be unclean. 

#### Leviticus 11:37 And if anything should fall from their decaying flesh upon any seed fit for sowing, which shall be sown, it shall be clean. 

#### Leviticus 11:38 But if {should be poured water] upon any seed, and {should fall their decaying flesh] upon it, it is unclean to you. 

#### Leviticus 11:39 And if one should die of the animals, which {is allowed for you to eat, this one], the one touching of their decaying flesh, he will be unclean until evening. 

#### Leviticus 11:40 And the one eating from their decaying flesh, he shall wash his garments, and shall be unclean until evening. And the one lifting of their decaying flesh, he shall wash his garments, and he shall bathe in water, and he shall be unclean until evening. 

#### Leviticus 11:41 And every crawling thing which crawls upon the earth, {is an abomination this] to you, you shall not eat. 

#### Leviticus 11:42 And all going upon the belly, and all going upon fours always, which is numerous in feet among all the crawling things crawling upon the earth -- you shall not eat it, for {an abomination to you it is]. 

#### Leviticus 11:43 And no way shall you abhor your souls among all the crawling things crawling upon the earth, and you shall not be defiled by these, and {not unclean you shall be] by these. 

#### Leviticus 11:44 For I am the LORD your God. And you shall be sanctified, and you shall be holy. For {holy am I the LORD your God]. And you shall not defile your souls among all the crawling things moving upon the earth. 

#### Leviticus 11:45 For I am the LORD, the one leading you from out of the land of Egypt, to be your God. And you shall be holy, for {holy am I the LORD]. 

#### Leviticus 11:46 This is the law for the animals, and the winged creatures, and all life moving in the water, and all life crawling upon the earth; 

#### Leviticus 11:47 to distinguish between the unclean and between the clean; and between the ones bringing forth alive of the ones being eaten, and between the ones bringing forth alive the ones not being eaten. 

#### Leviticus 12:1 And the LORD spoke to Moses, saying, 

#### Leviticus 12:2 Speak to the sons of Israel! and you shall say to them, saying, A woman whoever should conceive, and should give birth to a male, she shall be unclean seven days; according to the days of the separation of her menstruation she shall be unclean. 

#### Leviticus 12:3 And the {day eighth] she shall circumcise the flesh of his foreskin. 

#### Leviticus 12:4 And thirty and three days she shall sit in the blood of her cleansing; anything holy she shall not touch, and {into the sanctuary she shall not enter], until whenever {should have been fulfilled the days of her cleansing]. 

#### Leviticus 12:5 But if {a female she should give birth to], then she will be unclean twice seven days, according to her menstruation; and sixty days and six she shall be seated in {blood her unclean]. 

#### Leviticus 12:6 And whenever {should be fulfilled the days of her cleansing] for a son or for a daughter, she shall bring a lamb of a year old for a whole burnt-offering, and a young pigeon, or turtle-dove for a sin offering to the door of the tent of the testimony to the priest. 

#### Leviticus 12:7 And he shall bring it before the LORD. And {shall atone for her the priest], and he shall cleanse her from the spring of her blood. This is the law for the giving birth to a male or female. 

#### Leviticus 12:8 But if {does not find her hand] enough for a lamb, then she shall take two turtle-doves, or two young pigeons -- one for a whole burnt-offering, and one for a sin offering; and {shall atone for her the priest], and she shall be cleansed. 

#### Leviticus 13:1 And the LORD spoke to Moses and Aaron, saying, 

#### Leviticus 13:2 {man If any] should have in the skin of his flesh a discoloration {spot radiant], and {takes place in the skin of his flesh an infection of leprosy], he shall be led to Aaron the priest, or one of his sons of the priests. 

#### Leviticus 13:3 And {shall look at the priest] the infection in the skin of his flesh, and if the hair in the infection should turn white, and the appearance of the infection be deep under the skin of his flesh, {an infection of leprosy it is]; and {shall look the priest], and shall declare him defiled. 

#### Leviticus 13:4 And if the radiant spot should be white in the skin of his flesh, and {deep should not be its appearance] below the skin, and its hair did not turn white, but it is faint, then {shall separate the priest] the infection for seven days; 

#### Leviticus 13:5 and {shall look at the priest] the infection on the {day seventh]; and behold, if the infection abides before him, and {did not degenerate if the infection] in the skin, then {shall separate him the priest] seven days the second time. 

#### Leviticus 13:6 And {shall look at the priest] him on the {day seventh] the second time. And behold, {is faint if the infection], {did not degenerate and the infection] in the skin, then {will cleanse him the priest] -- {a spot for it is]. And washing his garments he will be clean. 

#### Leviticus 13:7 But if in turning, {degenerates the spot] in the skin after {looking at him the priest] to cleanse him, then he shall appear the second time to the priest. 

#### Leviticus 13:8 And {shall look at him the priest], and behold, {degenerated if the spot] in the skin, then {shall declare him defiled the priest] -- it is leprosy. 

#### Leviticus 13:9 And {an infection of leprosy if] happens in a man, then he shall come to the priest, 

#### Leviticus 13:10 and {shall look the priest], and behold, {discoloration if it is a white] in the skin, and if it turned the hair white, and some of the healthy flesh be living in the discoloration -- 

#### Leviticus 13:11 {a leprosy becoming old it is] in the skin of his flesh, and {shall declare him defiled the priest], and shall separate him, for he is unclean. 

#### Leviticus 13:12 But if blooming {shall break out leprosy] in the skin, and {shall cover the leprosy] all the skin with the infection, from head unto his feet, according to the whole vision of the priest; 

#### Leviticus 13:13 then {shall look the priest], and behold, {covers if the leprosy] all the skin of his flesh, then he shall cleanse the infection, for all turned white -- it is clean. 

#### Leviticus 13:14 And in what ever day should appear to him {flesh living], he shall be declared defiled. 

#### Leviticus 13:15 And {shall look at the priest] the {flesh healthy], and {shall prove him defiled flesh the healthy]; for it is unclean, it is leprosy. 

#### Leviticus 13:16 But if {should restore flesh the healthy] and turn white, then he shall come to the priest, 

#### Leviticus 13:17 and {shall see him the priest], and behold, {turned the infection] to the white, then {shall declare him cleansed the priest] by the infection -- he is clean. 

#### Leviticus 13:18 And if flesh should have {in his skin a lesion], and should heal, 

#### Leviticus 13:19 and there should become in the place of the lesion, {discoloration a white], or radiant being whitened, or being reddish, and it should be looked at by the priest; 

#### Leviticus 13:20 then {shall look the priest], and behold, if the appearance be deeper under the skin, and its hair turns into white, then {shall declare him defiled the priest], for it is leprosy, {in the lesion it broke out]. 

#### Leviticus 13:21 But if {should look at him the priest], and behold, there is no {on it hair white], and {deep it should not be] under the skin of the flesh, and it should be faint, then {shall separate him the priest] seven days. 

#### Leviticus 13:22 But if in a diffusion it should have diffused in the skin, then {shall declare him defiled the priest]; {an infection of leprosy it is]; {in the lesion it broke out]. 

#### Leviticus 13:23 And if in its place {should abide the radiance], and should not diffuse, {a discoloration of the lesion it is], and {shall cleanse him the priest]. 

#### Leviticus 13:24 And if flesh should become {in his skin inflammation a fiery], and there should be in his skin the healing of the inflammation, shining forth radiant white, becoming somewhat reddish or very white; 

#### Leviticus 13:25 then {shall look at him the priest], and behold, {is turned if the hair] white in the shining forth, and the appearance of it is deep under the skin, it is leprosy; {in the inflammation it broke out], and {shall declare him defiled the priest]; {an infection of leprosy it is]. 

#### Leviticus 13:26 But if {should look at him the priest], and behold, there is not in the shining forth {hair a white], and {deep it should not be] under the skin, but it is faint, then {shall separate him the priest] seven days. 

#### Leviticus 13:27 And {shall look at him the priest] in the {day seventh]. But if the diffusion should diffuse in the skin, then {shall declare him defiled the priest]; {an infection of leprosy it is]; {in the lesion it broke out]. 

#### Leviticus 13:28 But if {in its place should stay the shining forth], and should not be diffused in the skin, but it should be faint, {a discoloration of an inflammation it is], and {should declare him cleansed the priest]; for {an effect of an inflammation it is]. 

#### Leviticus 13:29 And a man or a woman, in whom ever has in themselves an infection of leprosy in the head or in the beard; 

#### Leviticus 13:30 then {shall look at the priest] the infection. And behold, if its appearance be imbedded under the skin, {in it and hair a yellowish thin], then {shall declare him defiled the priest]; it is an outbreak, {a leprosy of the head or a leprosy of the beard it is]. 

#### Leviticus 13:31 And if {should look at the priest] the infection of the outbreak, and behold, {is not the appearance] imbedded under the skin, and the hair {yellowish is not] in it, then {shall separate the priest] the infection of the outbreak seven days. 

#### Leviticus 13:32 And {shall look at the priest] the infection on the {day seventh]. And behold, {should not be diffused if the outbreak], and {hair yellowish no there is] in it, and the appearance of the outbreak is not hollow under the skin; 

#### Leviticus 13:33 then {shall be shaven the skin], but the outbreak shall not be shaven; and {shall separate the priest] the outbreak seven days for the second time. 

#### Leviticus 13:34 And {shall look at the priest] the outbreak on the {day seventh]; and behold, {should not be diffused if the outbreak] in the skin after the shaving of it, and the appearance of the outbreak is not hollow under the skin, then {shall cleanse him the priest]; and washing his garments, he will be clean. 

#### Leviticus 13:35 But if the diffusion should be diffused in the outbreak in the skin after cleansing it, 

#### Leviticus 13:36 then {shall look at him the priest], and behold, {should be diffused if the outbreak] in the skin, {shall not examine the priest] concerning the hair being yellowish -- he is unclean. 

#### Leviticus 13:37 But if before him {should abide in its place the outbreak], and {hair a black] should rise in it, {is healed the outbreak] -- he is clean, and {shall declare him cleansed the priest]. 

#### Leviticus 13:38 And a man or woman, in whom ever should have in the skin of his flesh shinings shining forth being white, 

#### Leviticus 13:39 then {shall look the priest]; and behold, in the skin of his flesh shinings shining forth being white, it is a psoriasis, it broke out in the skin, he is clean. 

#### Leviticus 13:40 And if any one be loose of hair then his head is only bald; he is clean. 

#### Leviticus 13:41 But if {by his face is loose of hair his head], he is forehead bald; he is clean. 

#### Leviticus 13:42 But if there becomes in his baldness, or in his being forehead bald {infection a white] or reddening, {leprosy blossoming it is] in his baldness, or in his forehead baldness. 

#### Leviticus 13:43 And {shall look at him the priest]. And behold, if the appearance of the infection be white or reddish in the his baldness, or in his being forehead bald as the form of leprosy in the skin of his flesh, 

#### Leviticus 13:44 {man a leprous he is], he is unclean; in defilement {shall declare him defiled the priest] -- in his head is his infection. 

#### Leviticus 13:45 And the leper in whom is the infection, his garments shall be disabled, and his head uncovered, and concerning his mouth let him put something around it! And {unclean he shall call himself] 

#### Leviticus 13:46 all the days, as many as {might be upon him the infection] -- being unclean, he shall be unclean; being separated he shall sit down outside of his camp, it will be to him a place for pastime. 

#### Leviticus 13:47 And a garment which ever should have in it an infection of leprosy in {garment a woolen], or in a garment made of hemp, 

#### Leviticus 13:48 or in the warp, or in the woof, or in the flaxen linens, or in the woolen threads, or in a skin, or in any workmanship of skin, 

#### Leviticus 13:49 and {should become the infection] greenish or reddish in the skin, or in the garment, or in the warp, or in the woof, or in any item of workmanship of skin, {an infection of leprosy it is]; and he shall show it to the priest. 

#### Leviticus 13:50 And {shall look at the priest] the infection; and {shall separate the priest] the infection seven days. 

#### Leviticus 13:51 And he shall look at the infection on the {day seventh]. But if {should diffuse the infection] in the garment, or in the warp, or in the woof, or in the skin, according to all as much as might be made with the skins in the work, {leprosy it is permanent]; {infection it is an unclean]. 

#### Leviticus 13:52 He shall incinerate the garment, or the warp, or the woof which is in the woolen garments, or in the flaxen linens, or in every item made of skin, in which ever there might be in it the infection; for {leprosy it is a permanent]; by fire it shall be incinerated. 

#### Leviticus 13:53 But if {should look the priest], and {should not be diffused the infection] in the garment, or in the warp, or in the woof, or in any item made of skin; 

#### Leviticus 13:54 then {shall order the priest], and one shall wash that upon which ever there might be {upon it an infection]; and {shall separate the priest] the infection seven days for the second time. 

#### Leviticus 13:55 And {shall look the priest] after the washing the infection; and thus {in no way should turn the infection] of its appearance, and the infection did not diffuse, it is unclean; in fire you shall incinerate it; it is fixed firm in the garment, or in the warp, or in the woof. 

#### Leviticus 13:56 And if {should look the priest], and {should be faint the infection] after washing it, he shall rip it from the garment, or from the warp, or from the woof, or from the skin. 

#### Leviticus 13:57 And if it should appear still in the garment, or in the warp, or in the woof, or in any item made of skin, {leprosy breaking forth it is]; by fire you shall incinerate {in that which is the infection]. 

#### Leviticus 13:58 And the garment, or the warp, or the woof, or any item made of skin which shall be washed, and {leaves from it the infection], that it shall be washed the second time, and it shall be clean. 

#### Leviticus 13:59 This is the law of an infection of leprosy of a garment of wool, or made of hemp, or warp, or woof, or any item made of skin, in the declaring it cleansed or defiled. 

#### Leviticus 14:1 And the LORD spoke to Moses, saying, 

#### Leviticus 14:2 This is the law of the leper. In what ever day he should have been cleansed, and shall be brought to the priest; 

#### Leviticus 14:3 that {shall come forth the priest] outside the camp. And {shall look the priest], and behold, {has been healed if the infection] of the leprosy from the leper, 

#### Leviticus 14:4 then {shall assign the priest], and they shall take for the one being cleansed two {small birds living clean], and wood of cedar, and twined scarlet, and hyssop. 

#### Leviticus 14:5 And {shall assign the priest], and they shall slay the {small bird one] into {receptacle an earthenware] over {water living]. 

#### Leviticus 14:6 And as for the small bird, the one living, he shall take it, and the wood of cedar, and the spun scarlet, and the hyssop; and he shall dip them and the small bird that is living into the blood of the small bird being slain over {water living]. 

#### Leviticus 14:7 And he shall sprinkle it about upon the one being cleansed of the leprosy seven times, and he will be clean. And he shall send out the small {bird living] into the plain. 

#### Leviticus 14:8 And {shall wash the man being cleansed] his garments, and he shall shave all his hair, and shall bathe in water, and shall be clean. And after these things he shall enter into the camp, and shall spend time outside of his house seven days. 

#### Leviticus 14:9 And it will be on the {day seventh], he shall shave all of his hair, the hair of his head, and the beard, and the brows; even all his hair he shall shave. And he shall wash his garments, and shall bathe his body in water, and he shall be clean. 

#### Leviticus 14:10 And on the {day eighth] he shall take two lambs, unblemished, of a year old, and {sheep one], unblemished of a year old, and three tenths of fine flour for a sacrifice offering, being mixed in olive oil, and {small cup of olive oil one]. 

#### Leviticus 14:11 And {shall stand the priest that cleanses] the man for the cleansing, and these offerings before the LORD, at the door of the tent of the testimony. 

#### Leviticus 14:12 And {shall take the priest] the {lamb one], and bring it for the trespass offering, and the small cup of olive oil; and he shall separate them as a separation offering before the LORD. 

#### Leviticus 14:13 And he shall slay the lamb in the place where they slay the whole burnt-offerings, and the ones for a sin offering, in {place the holy]. For it is the one for a sin offering; as the one of the trespass offering is for the priest -- {a holy of holies it is]. 

#### Leviticus 14:14 And {shall take the priest] from the blood, of the one of the trespass offering, and {shall place it the priest] upon the lobe of the ear of the one being cleansed -- the right, and upon the thumb of his hand -- the right, and upon the big toe of his foot -- the right. 

#### Leviticus 14:15 And {taking the priest] from the small cup of the olive oil, he shall pour upon the {hand of the priest left]. 

#### Leviticus 14:16 And {shall dip the priest] {finger his right] from the olive oil being in {hand his left]. And he shall sprinkle from the olive oil with his finger seven times before the LORD. 

#### Leviticus 14:17 And the left behind olive oil being in his hand, {shall place the priest] upon the lobe of the {ear of the one being cleansed right], and upon the thumb of his hand -- the right, and upon the big toe of his foot -- the right, upon the place of the blood of the trespass offering. 

#### Leviticus 14:18 And the left over olive oil that is upon the hand of the priest, {shall place it the priest] upon the head of the one being cleansed, and {shall atone for him the priest] before the LORD. 

#### Leviticus 14:19 And {shall offer the priest] the thing for the sin offering, and {shall atone the priest] for the one being cleansed of his sin. And after this {shall slay the priest] the whole burnt-offering. 

#### Leviticus 14:20 And {shall offer the priest] the whole burnt-offering, and the sacrifice upon the altar before the LORD; and {shall atone for him the priest], and he shall be cleansed. 

#### Leviticus 14:21 And if he should be in need, and his hand should not find what is needed, he shall take {lamb one] for what he trespassed for a cut-away portion, so as to atone for him, and a tenth of fine flour being mixed in olive oil for a sacrifice, and {small cup of olive oil one], 

#### Leviticus 14:22 and two turtle-doves, or two young pigeons, as much as {found his hand]. And {shall be the one] for a sin offering, and the one for a whole burnt-offering. 

#### Leviticus 14:23 And he shall bring them on the {day eighth], for his cleansing, to the priest, unto the door of the tent of the testimony before the LORD. 

#### Leviticus 14:24 And {shall take the priest] the lamb of the trespass offering, and the small cup of the olive oil, and he shall place them for an increase offering before the LORD. 

#### Leviticus 14:25 And he shall slay the lamb, the one for the trespass offering; and {shall take the priest] from the blood of the one for the trespass offering, and shall place it upon the lobe of the ear of the one being cleansed -- the right, and upon the thumb of his hand -- the right, and upon the big toe of his foot -- the right. 

#### Leviticus 14:26 And of the olive oil {shall pour the priest] upon his hand -- the left. 

#### Leviticus 14:27 And {shall sprinkle the priest] with his finger -- the right from the olive oil, the oil in his hand -- the left, seven times before the LORD. 

#### Leviticus 14:28 And {shall put the priest] of the olive oil being in his hand upon the lobe of the ear of the one being cleansed -- the right, and upon the thumb of his hand -- the right, and upon the big toe of his foot -- the right, on the place of the blood of the trespass offering. 

#### Leviticus 14:29 And the left over olive oil, being in the hand of the priest, he shall place upon the head of the one being cleansed, and {shall atone for him the priest] before the LORD. 

#### Leviticus 14:30 And he shall offer one from the turtle-doves, or from the young ones of the pigeons, in so far as {found his hand], 

#### Leviticus 14:31 the one for a sin offering, and the one for a whole burnt-offering with the sacrifice offering. And {shall atone the priest] for the one being cleansed before the LORD. 

#### Leviticus 14:32 This is the law for him in whom is found the infection of the leprosy, and not finding means in his hand enough for his cleansing. 

#### Leviticus 14:33 And the LORD spoke to Moses and Aaron, saying, 

#### Leviticus 14:34 When ever you should enter into the land of the Canaanites, which I give to you for a possession, and I put an infection of leprosy in the houses of the land procured by you; 

#### Leviticus 14:35 then {shall come one from the house] and shall announce to the priest, saying, Something as an infection has appeared to me in the house. 

#### Leviticus 14:36 And {will assign the priest] to pack up the house before the {enters priest] to look at the infection, that no way {unclean should become] as much as might be in the house. And after these things {shall enter the priest] to study the house. 

#### Leviticus 14:37 And he shall look at the infection. And behold, if the infection is in the walls of the house, with a cavity being greenish or being reddish, and their appearance deep in the walls. 

#### Leviticus 14:38 And {coming forth the priest] from out of the house, at the door of the house, and then {shall separate the priest] the house seven days. 

#### Leviticus 14:39 And {shall come back again the priest] on the {day seventh], and he shall look at the house. And behold, if {was diffused the infection] in the walls of the house, 

#### Leviticus 14:40 then {shall assign the priest], and they shall take out the stones in which is the infection, and they shall cast them outside the city, into {place an unclean]. 

#### Leviticus 14:41 And {the house they shall scrape] from inside round about, and shall pour out the dust of the scraping outside the city into {place an unclean]. 

#### Leviticus 14:42 And they shall take stones being scraped of another, and they shall substitute for the stones, and {dust for plaster other] they shall take, and they shall plaster the house. 

#### Leviticus 14:43 But if {should come again the infection], and should rise up in the house after the taking away of the stones, and after the scraping the house, and after the plastering, 

#### Leviticus 14:44 then {shall enter the priest] and he shall look. If {be dispersed the infection in the house], {leprosy it is a permanent] in the house -- it is unclean. 

#### Leviticus 14:45 And they shall demolish the house, and its wood, and its stones; and all the plaster dust of the house they shall bring forth outside the city unto {place an unclean]. 

#### Leviticus 14:46 And the one entering into the house all the days which it is being separated will be unclean until evening. 

#### Leviticus 14:47 And the one going to bed in the house shall wash his garments, and will be unclean until evening. And the one eating in the house, he shall wash his garments. 

#### Leviticus 14:48 And if coming, {should enter the priest] and look, and behold, {is not dispersed the infection] in the house after the plastering the house, that {shall declare cleansed the priest the house], for {is healed the infection]. 

#### Leviticus 14:49 And he shall take to purify the house, two small {birds living], and wood of cedar, and twined scarlet, and hyssop. 

#### Leviticus 14:50 And he shall slay the {small bird one] into {utensil an earthenware] over {water living]. 

#### Leviticus 14:51 And he shall take the wood of cedar, and the twined scarlet, and the hyssop, and the {small bird living]; and he shall dip them into the blood of the small bird having been slain over {water living]; and he shall sprinkle about with them upon the house seven times. 

#### Leviticus 14:52 And he shall purify the house with the blood of the small bird, and with the {water living], and with the {small bird living], and with the wood of cedar, and with the hyssop, and with the twined scarlet. 

#### Leviticus 14:53 And he shall send out the {small bird living] outside the city into the plain. And he shall atone for the house, and it will be clean. 

#### Leviticus 14:54 This is the law for every infection of leprosy, and outbreak, 

#### Leviticus 14:55 and the leprosy of a garment, and house, 

#### Leviticus 14:56 and discoloration, and spot, and shining; 

#### Leviticus 14:57 to describe the day unclean, and the day it shall be cleansed. This is the law of the leprosy. 

#### Leviticus 15:1 And the LORD spoke to Moses and Aaron, saying, 

#### Leviticus 15:2 Speak to the sons of Israel! And you shall say to them, The man, a man in whom ever should have a flow from out of his body, his flow is unclean. 

#### Leviticus 15:3 And this is the law of his uncleanness. Flowing semen from out of his body, from out of the flow, in which {concocted his body], {is through this flow his uncleanness] in him. 

#### Leviticus 15:4 Every bed upon which ever he should go to bed upon it, the one having a seminal emission, it is unclean; and every item upon which ever he should sit upon it, the one having a seminal emission, it is unclean. 

#### Leviticus 15:5 And a man who ever should touch his bed, shall wash his garments, and shall bathe in water, and shall be unclean until evening. 

#### Leviticus 15:6 And the one sitting down upon the item, upon what ever {should sit upon it the one having a seminal emission], he shall wash his garments, and shall bathe in water, and he will be unclean until evening. 

#### Leviticus 15:7 And the one touching the flesh of the one having a seminal emission, he shall wash his garments, and shall bathe in water, and he will be unclean until evening. 

#### Leviticus 15:8 And if {should salivate the one having a seminal emission] upon one that is clean, that person shall wash his garments, and shall bathe in water, and he will be unclean until evening. 

#### Leviticus 15:9 And every saddle upon which {should mount upon it the one having a seminal emission], it will be unclean until evening. 

#### Leviticus 15:10 And every one touching from all as much as might be underneath him, he will be unclean until evening. And the one lifting them, he shall wash his garments, and shall bathe in water, and will be unclean until evening. 

#### Leviticus 15:11 And of as many as should touch the one having a seminal emission, and his hands have not been washed in water, he shall wash his garments, and shall bathe in water, and he will be unclean until evening. 

#### Leviticus 15:12 And {item an earthenware] of which ever {should have touched the one having a seminal emission], it shall be broken. And every {item wooden] shall be washed in water, and it will be clean. 

#### Leviticus 15:13 And if {should be cleansed the one having a seminal emission] from his flow, then he shall count out to himself seven days for his cleansing; and he shall wash his garments, and shall bathe his body {water in living], and he will be clean. 

#### Leviticus 15:14 And on the {day eighth] he shall take to himself two turtle-doves, or two young pigeons, and he shall bring them before the LORD, to the doors of the tent of the testimony, and he shall give them to the priest. 

#### Leviticus 15:15 And {shall offer them the priest] -- one for a sin offering, and one for a whole burnt-offering. And {shall atone for him the priest] before the LORD for his flow. 

#### Leviticus 15:16 And a man who should come forth from his marriage-bed of issuing semen, shall bathe in water all his body, and he will be unclean until evening. 

#### Leviticus 15:17 And every garment, and every skin, upon which ever might be upon it of the marriage-bed of semen, that it shall be washed in water, and will be unclean until evening. 

#### Leviticus 15:18 And a wife, if {should have gone to bed a husband] with her in a marriage-bed of semen, that they shall bathe in water, and they will be unclean until evening. 

#### Leviticus 15:19 And a woman whoever might be flowing blood, when {shall be flow her] in her body, seven days she will be in her menstruation; every one touching her will be unclean until evening. 

#### Leviticus 15:20 And everything upon what ever she should lay herself upon it, in her menstruation, it will be unclean; and everything upon what ever she should sit herself upon it, it will be unclean. 

#### Leviticus 15:21 And all who ever should touch her bed, he shall wash his garments, and shall bathe in water, and will be unclean until evening. 

#### Leviticus 15:22 And every one touching any item upon which ever she should sit upon it, he shall wash his garments, and shall bathe in water, and shall be unclean until evening. 

#### Leviticus 15:23 And if {in her bed being], or upon the item of which ever she should sit upon it, in its touching her, it shall be unclean until evening. 

#### Leviticus 15:24 And if {in her bed should bed down any one] with her, and {should be her uncleanness] upon him, he shall be unclean seven days. And every bed upon which ever he should go to bed upon it, it shall be unclean. 

#### Leviticus 15:25 And a woman if she should flow a flow of blood {days many], not in the time of her menstruation; if also it should flow after her menstruation, all the days of the flow of her uncleanness shall be just as the days of her menstruation -- she shall be unclean. 

#### Leviticus 15:26 And every bed upon of which ever she should go to bed upon it all the days of her flow, {as the bed of her menstruation it will be to her]. And every item upon which ever she should sit upon it, it shall be unclean, according to the uncleanness of her menstruation. 

#### Leviticus 15:27 And every man touching her, he shall be unclean, and shall wash his garments, and he shall bathe in water, and he shall be unclean until evening. 

#### Leviticus 15:28 But if she should be cleansed from her flow, then she shall count out to herself seven days, and after this she shall be cleansed. 

#### Leviticus 15:29 And the {day eighth] she shall take for herself two turtle-doves, or two young pigeons, and she shall bring them to the priest to the door of the tent of the testimony. 

#### Leviticus 15:30 And {shall offer the priest] the one for a sin offering, and the one for a whole burnt-offering. And {shall atone for her the priest] before the LORD of the flow of her uncleanness. 

#### Leviticus 15:31 And {be reverent you shall make the sons of Israel] because of their uncleannesses. And they shall not die on account of their uncleanness, in their defiling my tent, the one among them. 

#### Leviticus 15:32 This is the law of the one having a seminal emission. Even if one should come forth from his marriage-bed of semen, so as to be defiled by it, 

#### Leviticus 15:33 and the one hemorrhaging in her menstruation, and the one having a seminal emission in his flow to the male or the female, and to the husband if he should go to bed with one sitting apart. 

#### Leviticus 16:1 And the LORD spoke to Moses after the coming to an end of the two sons of Aaron in their offering {fire alien] before the LORD, and they came to an end. 

#### Leviticus 16:2 And the LORD said to Moses, Speak to Aaron your brother! that he enters not at any hour into the holy place inside the veil, at the front of the atonement-seat which is upon the ark of the testimony, that he shall not die. For in a cloud I will appear upon the atonement-seat. 

#### Leviticus 16:3 Thus Aaron shall enter into the holy place with a calf of the oxen for a sin offering, and a ram for a whole burnt-offering. 

#### Leviticus 16:4 And {an inner garment of flaxen linen having been sanctified he shall put on], and {pants flaxen linen] will be upon his flesh, and {belt a flaxen linen] shall be tied around, and {turban a flaxen linen] shall be placed -- {garments the holy they are]. And he shall bathe in water all his body. And he shall put them on. 

#### Leviticus 16:5 And from the congregation of the sons of Israel he shall take two young he-goats of the goats for a sin offering, and {ram one] for a whole burnt-offering. 

#### Leviticus 16:6 And Aaron shall bring the calf, the one for a sin offering, the one for himself, and he shall atone for himself and his house. 

#### Leviticus 16:7 And he shall take the two young he-goats, and present them before the LORD by the door of the tent of the testimony. 

#### Leviticus 16:8 And Aaron shall place {upon the two young he-goats lots]; {lot one] to the LORD, and {lot one] to the scapegoat. 

#### Leviticus 16:9 And Aaron shall bring the young he-goat, upon which came unto it the lot to the LORD. And he shall offer it for a sin offering. 

#### Leviticus 16:10 And the young he-goat, upon which {came unto it the lot of the scapegoat], he shall set it living before the LORD, so as to atone for him, so as to send him out as the scapegoat, and to let him go into the wilderness. 

#### Leviticus 16:11 And Aaron shall bring the calf, the one for the sin offering, the one for himself; and he shall atone for himself, and his house. And he shall slay the calf, the one for the sin offering, the one for himself. 

#### Leviticus 16:12 And he shall take the censer full of coals of fire from the altar, of the one before the LORD, and he shall fill his hands {incense composition of fine], and he shall carry it inside the veil. 

#### Leviticus 16:13 And he shall place the incense upon the fire before the LORD. And {shall cover the vapor of the incense] the atonement-seat, the one upon the testimonies, and he shall not die. 

#### Leviticus 16:14 And he shall take some of the blood of the calf, and he shall sprinkle with his finger on the atonement-seat, according to the east; in front of the atonement-seat he shall sprinkle seven times of the blood with his finger. 

#### Leviticus 16:15 And he shall slay the young he-goat, (the one for a sin offering, the one for the people) before the LORD. And he shall carry its blood inside the veil. And he shall offer its blood in which manner he offered the blood of the calf. And he shall sprinkle its blood on the atonement-seat, in front of the atonement-seat. 

#### Leviticus 16:16 And he shall atone the holy place of the uncleannesses of the sons of Israel, and of their offences for all their sins. And thus he shall do to the tent of the testimony, to the one created among them in the midst of their uncleanness. 

#### Leviticus 16:17 And every man shall not be in the tent of the testimony, of his entering to atone in the holy place, until whenever he should come forth. And he shall atone for himself, and his house, and for all the congregation of Israel. 

#### Leviticus 16:18 And he shall come forth unto the altar, the one before the LORD, and he shall atone upon it. And he shall take from the blood of the calf, and from the blood of the young he-goat, and he shall place it upon the horns of the altar round about. 

#### Leviticus 16:19 And he shall sprinkle upon it some of the blood with his finger seven times; and he shall cleanse it, and shall sanctify it from the uncleannesses of the sons of Israel. 

#### Leviticus 16:20 And he shall complete making atonement for the holy place, and the tent of the testimony, and the altar; and {for the priests he shall make a cleansing]. And he shall bring the {young he-goat living]. 

#### Leviticus 16:21 And Aaron shall place {two hands his] upon the head of the {young he-goat living]; and he shall declare openly over it all the lawless deeds of the sons of Israel, and all their iniquities, and all their sins. And he shall place them upon the head of the {young he-goat living], and he shall send it out by the hand {man of a prepared] into the wilderness. 

#### Leviticus 16:22 And {shall take the young he-goat] upon himself their lawlessnesses into a land untrodden. And he shall send out the young he-goat into the wilderness. 

#### Leviticus 16:23 And Aaron shall enter into the tent of the testimony, and shall take off the {apparel flaxen linen] which he put on of his entering into the holy place. And he shall put it aside there. 

#### Leviticus 16:24 And he shall bathe his body in water in {place the holy]. And shall put on his apparel, and coming forth shall offer his whole burnt-offering, and the whole offering of the people; and he shall atone for himself, and for his house, and for the people as for the priests. 

#### Leviticus 16:25 And the fat for the sin offerings he shall offer upon the altar. 

#### Leviticus 16:26 And the one sending out the young he-goat, the one having been drawn apart for release, shall wash his garments and shall bathe his body in water, and after these things he shall enter into the camp. 

#### Leviticus 16:27 And the calf, the one for the sin offering, and the young he-goat, the one for the sin offering which their blood was carried to atone in the holy place, they shall bring them outside the camp, and they shall incinerate them in fire, and their skins, and their meats, and their dung. 

#### Leviticus 16:28 And the one incinerating them shall wash his garments, and shall bathe his body in water, and after these things he shall enter into the camp. 

#### Leviticus 16:29 And this shall be to you {law an eternal]. In the {month seventh] the tenth of the month humble your souls! And {any work you shall not do] -- the native born and the foreigner joining up with you. 

#### Leviticus 16:30 For in this day he shall atone for you, to cleanse you from all your sins before the LORD, and you shall be cleansed. 

#### Leviticus 16:31 A Sabbath of Sabbaths it shall be to you. And you shall humble your souls -- {law an eternal]. 

#### Leviticus 16:32 And he shall make atonement -- the priest whom ever they should anoint him, and whom ever shall perfect his hands to officiate as priest after his father; and he shall put on the {apparel flaxen linen] -- {apparel holy]. 

#### Leviticus 16:33 And he shall atone the holy of the holy; and the tent of the testimony and the altar he shall atone; and for the priests and for all the congregation he shall atone. 

#### Leviticus 16:34 And this will be to you {law an eternal] to atone for the sons of Israel from all their sins. Once of the year you shall do as the LORD gave orders to Moses. 

#### Leviticus 17:1 And the LORD spoke to Moses, saying, 

#### Leviticus 17:2 Speak to Aaron and to his sons, and to all the sons of Israel! And you shall say to them this saying which the LORD gives charge, saying, 

#### Leviticus 17:3 The man, a man of the sons of Israel, who ever should slay a calf or a sheep or a goat in the camp, and who ever should slay outside the camp, 

#### Leviticus 17:4 and {to the door of the tent of the testimony should not bring it], so as to bring a gift to the LORD before the tent of the LORD; blood shall be imputed to that man, for blood was poured out. {shall be utterly destroyed That soul] from its people, 

#### Leviticus 17:5 so that {should bring the sons of Israel] their sacrifices, as many as they should slay in the plains, and shall bring them to the LORD at the door of the tent of the testimony, to the priest. And they shall sacrifice {as a sacrifice of deliverance to the LORD them]. 

#### Leviticus 17:6 And {shall pour the priest] the blood upon the altar, before the LORD, by the door of the tent of the testimony. And he shall offer the fat for a scent of pleasant aroma to the LORD. 

#### Leviticus 17:7 And they shall not sacrifice still their sacrifices to the vain gods in which they fornicate after them; {law it will be an eternal] to you unto your generations. 

#### Leviticus 17:8 And you shall say to them, The man, a man from the sons of Israel, and from the foreigners of the ones lying nearby among you, who ever should offer a whole burnt-offering or sacrifice, 

#### Leviticus 17:9 and at the door of the tent of the testimony should not bring anything to offer it to the LORD, {shall be utterly destroyed that man] from his people. 

#### Leviticus 17:10 And the man, a man of the sons of Israel, or of the foreigners of the ones lying nearby among you, who ever should eat any blood, that I will set my face against the soul eating the blood, and I will destroy it from out of its people. 

#### Leviticus 17:11 For the life of all flesh {its blood is]. And I gave it to you upon the altar to atone for your souls. For its blood {for the soul shall atone]. 

#### Leviticus 17:12 On account of this I have said to the sons of Israel, Every soul of you shall not eat blood; and the foreigner lying near by to you shall not eat blood. 

#### Leviticus 17:13 And the man, a man of the sons of Israel, or of the foreigners lying near to you, who ever shall hunt a hunt for a wild beast or birds, which is to be eaten, he shall pour out its blood, and cover it in the ground. 

#### Leviticus 17:14 For the life of all flesh {its blood is], and I said to the sons of Israel, The blood of all flesh you shall not eat, for life of all flesh {its blood is]. Every one eating it shall be utterly destroyed. 

#### Leviticus 17:15 And every soul who should eat decaying flesh, or flesh taken by wild beasts, among the native born, or by the foreigners, shall wash his garments, and shall bathe in water, and will be unclean until evening; then he will be clean. 

#### Leviticus 17:16 But if he should not wash his garments, and {his body should not bathe] in water, then he shall take the violation of the law himself. 

#### Leviticus 18:1 And the LORD spoke to Moses, saying, 

#### Leviticus 18:2 Speak to the sons of Israel! And you shall say to them, I am the LORD your God. 

#### Leviticus 18:3 According to the practices of the land of Egypt, in which you sojourned in it, you shall not do. And according to the practices of the land of Canaan, into which I bring you there, you shall not do. And their laws you shall not go by. 

#### Leviticus 18:4 My judgments you shall execute, and my orders you shall keep, and you shall go by them. I am the LORD your God. 

#### Leviticus 18:5 And you shall keep all my orders, and all my judgments, and you shall observe them; by which {observing them a man] shall live by them. I am the LORD your God. 

#### Leviticus 18:6 The man, a man {to any family member of his flesh shall not draw near] to uncover their indecency. I am the LORD. 

#### Leviticus 18:7 The indecency of your father, and the indecency of your mother you shall not uncover, {mother for your she is]. Her indecency you shall not uncover. 

#### Leviticus 18:8 The indecency of a wife of your father you shall not uncover, {indecency your father's it is]. 

#### Leviticus 18:9 The indecency of your sister of your father or of your mother, natural or being procreated outside, you shall not uncover their indecency. 

#### Leviticus 18:10 The indecency of a daughter of your son or a daughter of your daughter you shall not uncover their indecency, for {your indecency it is]. 

#### Leviticus 18:11 The indecency of the daughter {wife of your father's] you shall not uncover, {of the same father your sister she is], you shall not uncover her indecency. 

#### Leviticus 18:12 The indecency {sister of your father's] you shall not uncover, {a member of the family for of your father she is]. 

#### Leviticus 18:13 The indecency {sister of your mother's] you shall not uncover, {a member of the family for of your mother she is]. 

#### Leviticus 18:14 The indecency of the brother of your father you shall not uncover, and to his wife you shall not enter, {relative for your she is]. 

#### Leviticus 18:15 The indecency of your daughter-in-law you shall not uncover, {wife for your son's she is], you shall not uncover her indecency. 

#### Leviticus 18:16 The indecency {wife of your brother's] you shall not uncover, {indecency your brother's it is]. 

#### Leviticus 18:17 The indecency of a woman and her daughter you shall not uncover; the daughter of her son and the daughter of her daughter you shall not take to uncover their indecency, {members of your family they are]; it is an act of impiety. 

#### Leviticus 18:18 {a wife in addition to her sister You shall not take] as a rival, to uncover her indecency instead of her, {yet living while she is]. 

#### Leviticus 18:19 And to a wife in separation of her uncleanness you shall not enter, to uncover her indecency. 

#### Leviticus 18:20 And to the wife of your neighbor you shall not give the marriage-bed of your semen, to be thoroughly defiled with her. 

#### Leviticus 18:21 And of your semen you shall not give to serve a ruler, and you shall not profane the {name holy]. I am the LORD. 

#### Leviticus 18:22 And with a man you shall not go to bed in a marriage-bed in the feminine way; {an abomination for it is]. 

#### Leviticus 18:23 And with any four-footed creature, you shall not give your marriage-bed for a discharge of semen to be thoroughly defiled with it. And a woman shall not set herself with any four-footed creature to breed; {detestable for it is]. 

#### Leviticus 18:24 Do not defile yourselves in any of these; {in all for] these {were defiled the nations], which I eject before your face. 

#### Leviticus 18:25 And {was thoroughly defiled the land]; and I recompensed injustice to them because of it, and {is loathed the land] with the ones lying in wait upon it. 

#### Leviticus 18:26 And you shall guard all my laws, and my orders, and {shall not do any of these abominations the native inhabitant and the uniting foreigner with you]. 

#### Leviticus 18:27 For all these abominations {committed the men of the land] -- the ones being prior of you, and {was defiled the land]. 

#### Leviticus 18:28 And lest {should loathe you the land] in your defiling it, in which manner it loathed the nations before you, 

#### Leviticus 18:29 for all who ever should do of all these abominations shall be utterly destroyed -- the souls doing them, from out of the midst of their people. 

#### Leviticus 18:30 And you shall keep my orders, so that you should not do of any of the laws of the ones being abhorred, which happened before you. And you shall not be defiled among them, for I am the LORD your God. 

#### Leviticus 19:1 And the LORD spoke to Moses, saying, 

#### Leviticus 19:2 Speak to all the congregation of the sons of Israel! And you shall say to them, You shall be holy, for {am holy I the LORD your God]. 

#### Leviticus 19:3 Let each one {his father and his mother fear]! And my Sabbaths you shall keep. I am the LORD your God. 

#### Leviticus 19:4 You shall not follow after idols, and {gods molten you shall not make to yourselves]. I am the LORD your God. 

#### Leviticus 19:5 And if you should sacrifice a sacrifice of deliverance to the LORD, {acceptable for yourselves you shall sacrifice]. 

#### Leviticus 19:6 In which ever day you should sacrifice, it shall be eaten, and in the next morning. And if any should be left behind until {day the third] {by fire it shall be incinerated]. 

#### Leviticus 19:7 And if food should be eaten the {day third] it is unfit, you shall not accept it. 

#### Leviticus 19:8 And the one eating it {the sin shall take], for the holy things of the LORD he profaned. And {shall be utterly destroyed the souls eating it] from their people. 

#### Leviticus 19:9 And {reaping of your] the harvest of your land, you shall not complete your harvest of your field to completely reap it. And the parts falling away of your harvest you shall not collect together. 

#### Leviticus 19:10 And your vineyard; you shall not glean the vintage, nor the grape-stones of your vineyard shall you collect together; to the poor and to the foreigner you shall leave behind for them. I am the LORD your God. 

#### Leviticus 19:11 You shall not steal, and you shall not lie, nor shall you extort each his neighbor. 

#### Leviticus 19:12 And you shall not swear by an oath {my name upon] unjustly. And you shall not profane the {name holy] of your God. I am the LORD your God. 

#### Leviticus 19:13 You shall not wrong your neighbor. And you shall not seize by force. And {shall not go to bed the wages of your hireling] with you until morning. 

#### Leviticus 19:14 You shall not wickedly speak to a mute, and before the blind you shall not put an obstacle. And you shall fear the LORD your God. I am the LORD your God. 

#### Leviticus 19:15 You shall not act unjustly in a judgment. You shall not take favor on the face of the poor, nor marvel before the face of a mighty one. With righteousness you shall judge your neighbor. 

#### Leviticus 19:16 You shall not go by treachery among your nation. You shall not rise up together for blood of your neighbor. I am the LORD your God. 

#### Leviticus 19:17 You shall not detest your brother in your mind. With rebuke you shall reprove your neighbor, and you shall not take {on account of him sin]. 

#### Leviticus 19:18 And {shall not avenge your hand]. And you shall not be infuriated at the sons of your people. And you shall love your neighbor as yourself. I am the LORD your God. 

#### Leviticus 19:19 My law you shall keep. Your cattle you shall not mate unequally yoked. And in your vineyard you shall not scatter abroad diverse seed. And a garment of two materials being woven commingled you shall not put upon yourself. 

#### Leviticus 19:20 And if any man should go to bed with a woman in the marriage-bed of semen, and she is a domestic servant being guarded for a man, and to her ransoms have not been ransomed, or freedom was not given to her; an overseeing will be to them; they shall not die, for she was not set free. 

#### Leviticus 19:21 And he shall bring his trespass offering to the LORD by the door of the tent of the testimony -- a ram for a trespass offering. 

#### Leviticus 19:22 And {shall atone for him the priest] with the ram of the trespass offering before the LORD for his sin of which he sinned; and {shall be forgiven him the sin] which he sinned. 

#### Leviticus 19:23 And whenever you should enter into the land which the LORD your God gives to you, and you should plant any {tree eatable], then you shall purge away its uncleanness. Its fruit for three years will be impure to you, it shall not be eaten. 

#### Leviticus 19:24 And the {year fourth will be all of its fruit] holy, praiseworthy to the LORD. 

#### Leviticus 19:25 And in the {year fifth] you shall eat of its fruit; {is an addition to you its produce]. I am the LORD your God. 

#### Leviticus 19:26 Eat not upon the mountains! And you shall not foretell, nor use augury. 

#### Leviticus 19:27 You shall not make a lock of hair consecrated to an idol from out of the hair of your head, nor shall you corrupt the appearance of your beards. 

#### Leviticus 19:28 And {cuts you shall not make] for a dead soul on your body; and letter marks you shall not make upon you. I am the LORD your God. 

#### Leviticus 19:29 You shall not profane your daughter to fornicate her. And you shall not fornicate the land, and {be filled the land] of lawlessness. 

#### Leviticus 19:30 My Sabbaths you shall keep, and of my holy things you shall fear. I am the LORD. 

#### Leviticus 19:31 You shall not follow after ones who deliver oracles, and to the enchanters you shall not cleave to be thoroughly defiled by them. I am the LORD your God. 

#### Leviticus 19:32 At the face of a gray one you shall rise up, and you shall esteem the face of an older one; and you shall fear your God. I am the LORD your God. 

#### Leviticus 19:33 And if any {should come forward to you foreigner in your land], you shall not afflict him. 

#### Leviticus 19:34 {as the native born among you shall be The foreigner approaching to you]. And you shall love him as yourself, for {foreigners you became] in the land of Egypt. I am the LORD your God. 

#### Leviticus 19:35 You shall not act unjustly in an equity with measures, and with weights, and with yoke balance scales. 

#### Leviticus 19:36 {yoke balance scales Just], and {dry measure weights just], and {coos liquid measure a just] shall be to you. I am the LORD your God, the one leading you from out of the land of Egypt. 

#### Leviticus 19:37 And you shall keep all my laws, and all my orders, and you shall do them. I am the LORD. 

#### Leviticus 20:1 And the LORD spoke to Moses, saying, 

#### Leviticus 20:2 And to the sons of Israel, you shall speak, saying, If any from the sons of Israel, or of the ones being foreigners in Israel, who ever should give his semen to a chief god, to death let him be put to death! The nation, the people upon the land shall stone him with stones. 

#### Leviticus 20:3 And I will set my face against that man, and I will destroy him from out of his people. For of his semen he gave to a chief god, that he should defile my holy place, and should profane the name -- the one having been sanctified to me. 

#### Leviticus 20:4 And if in disdain {should overlook the native-born of the land] with their eyes of that man, in his giving his semen to a chief god, to not kill him, 

#### Leviticus 20:5 then I shall set my face against that man, and his kin, and I will destroy him, and all the ones consenting with him, so as for them to fornicate with the ruling gods of their people. 

#### Leviticus 20:6 And a soul who ever should follow after ones who deliver oracles or enchanters, so as to fornicate after them, I will set my face against that soul, and I will destroy it from out of its people. 

#### Leviticus 20:7 And you shall be sanctified, and you shall be holy, for {am holy I the LORD your God]. 

#### Leviticus 20:8 And you shall keep my orders, and you shall do them. I am the LORD, the one sanctifying you. 

#### Leviticus 20:9 The man, a man who ever {wickedly should speak] of his father or his mother, unto death let him be put to death! {of his father or of his mother wickedly he spoke], he shall be liable 

#### Leviticus 20:10 And a man, a man who ever should commit adultery {wife with a man's], or who ever should commit adultery with a wife of his neighbor, to death let them be put to death! the man committing adultery and the woman committing adultery. 

#### Leviticus 20:11 And if anyone should have bedded with the wife of his father, {the indecency of his father to uncover], to death let them be put to death! both are liable. 

#### Leviticus 20:12 And if anyone should have bedded with his daughter-in-law, unto death let them be put to death! both were impious, they are liable. 

#### Leviticus 20:13 And who ever should have bedded with a male as the marriage-bed of a woman, {an abomination did both]; to death let them be put to death! they are liable. 

#### Leviticus 20:14 Who ever should take a woman and her mother, {a violation of the law it is]; in fire they shall incinerate him and them, and there shall not be a violation of the law among you. 

#### Leviticus 20:15 And who ever should give over to his laying with a four-footed creature, to death let him be put to death! and the four-footed creature you shall kill. 

#### Leviticus 20:16 And a woman, whoever should come forward to any beast to breed herself by it, you shall kill the woman and the beast -- unto death let them be put to death! they are liable. 

#### Leviticus 20:17 Who ever should take his sister of his father, or of his mother, and should look at her indecency, and she should look at his indecency, it is scornful, they shall be utterly destroyed before the sons of their race, for the indecency of his sister he uncovered -- his sin he shall receive. 

#### Leviticus 20:18 And a man who ever should go to bed with a woman sitting apart, and shall uncover her indecency, {her flow he uncovered], and she uncovered the flow of her blood; {shall be utterly destroyed both] from their generation. 

#### Leviticus 20:19 And the indecency {sister of your father's] and {sister your mother's] you shall not uncover, {the for family intimacy he uncovered]; {their sin they shall carry]. 

#### Leviticus 20:20 And who ever should have gone to bed with his relative, {the indecency of his kin he uncovered]; {childless they shall die]. 

#### Leviticus 20:21 And a man who ever should take the wife of his brother, it is uncleanness; {indecency his brother's he uncovered] -- {childless they shall die]. 

#### Leviticus 20:22 And you shall keep all my orders, and all my judgments; and you shall do them, then no way should {loathe you the land], into which I bring you there to dwell upon it. 

#### Leviticus 20:23 And do not go in the laws of the nations! which I eject from you; for all these things they did, and I abhor them. 

#### Leviticus 20:24 And I said to you, You shall inherit their land. And I will give it to you for a possession; a land flowing milk and honey. I am the LORD your God who separated you from all the nations. 

#### Leviticus 20:25 And you shall separate yourselves between the cattle of the clean and unclean; and between the winged creatures of the clean, and the unclean. And you shall not make abhorrent your souls among the cattle, and among the winged creatures, and among all the reptiles of the earth, which I separated to you for uncleanness. 

#### Leviticus 20:26 And you will be holy to me, for I am holy, the LORD your God, the one separating you from all the nations, to be mine. 

#### Leviticus 20:27 And a man or woman who ever of them should become a deliverer of oracles or enchanter, to death let them be put to death -- both! By stones stone them! they are liable. 

#### Leviticus 21:1 And the LORD said to Moses, saying, Speak to the priests, to the sons of Aaron! And you shall say to them, that among their dead souls they shall not defile themselves among their nation; 

#### Leviticus 21:2 but only among the members of the family near them -- for father, and for mother, and for sons, and for daughters, and for brother, 

#### Leviticus 21:3 and for {sister his virgin] being near to him, the sister not being espoused to a man; for these he shall not defile himself 

#### Leviticus 21:4 suddenly among his people by profaning himself. 

#### Leviticus 21:5 And to baldness you shall not shave your head for the dead; and the appearance of the beard they shall not shave; and upon their flesh they shall not mutilate by cuts. 

#### Leviticus 21:6 They shall be holy to their God, and they shall not profane the name of their God. {the For sacrifices of the LORD as gifts to their God they offer], and they shall be holy. 

#### Leviticus 21:7 A woman harlot and being profaned they shall not take; and a woman being cast out from her husband they shall not take; for he is holy to the LORD his God. 

#### Leviticus 21:8 And you shall sanctify him; for the gifts of the LORD your God this one offers -- he shall be holy. For {am holy I the LORD], the one sanctifying them. 

#### Leviticus 21:9 And a daughter of a man being a priest, if she should be profaned to fornicate, {the name of her father she profanes]; with fire she shall be incinerated. 

#### Leviticus 21:10 And the {priest great] from among his brethren, of the one having {poured upon his head the oil of the anointing], and {having been perfected his hands] to put on the garments -- the head shall not be without a turban, and the garments he shall not tear up; 

#### Leviticus 21:11 and {unto any soul coming to an end he shall not enter]; {by his father nor by his mother he shall not be defiled]. 

#### Leviticus 21:12 And from out of the holies he shall not come forth; and he shall not profane the thing having been sanctified of his God, for the holy {oil anointing] of his God is upon him. I am the LORD. 

#### Leviticus 21:13 This one {woman a virgin from his family shall take]. 

#### Leviticus 21:14 But a widow, and one being cast out and being profaned, and a harlot -- these he shall not take; but only a virgin from out of his people shall he take for a wife. 

#### Leviticus 21:15 And he shall not profane his semen among his people. I am the LORD God, the one sanctifying him. 

#### Leviticus 21:16 And the LORD spoke to Moses, saying, 

#### Leviticus 21:17 Speak to Aaron, saying, A man from your kind, throughout your generations, to any if there might be on him a blemish, shall not come forward to offer the gifts of his God. 

#### Leviticus 21:18 Any man in which ever might be in him a blemish, shall not come forward -- {man a blind], or lame, or splitmouth, or with mutilated ears, 

#### Leviticus 21:19 or a man in which might be in him a broken hand, or a broken foot, 

#### Leviticus 21:20 or humpback, or peeling, or hairless of the eyes, or a man in which ever might be in him {mange a wild], or scabbed, or having one testicle. 

#### Leviticus 21:21 Every man in which there is on him a blemish from the seed of Aaron the priest, shall not approach to offer the sacrifices to the LORD, that has a blemish on him; {the gifts of his God he shall not come forward to bring]. 

#### Leviticus 21:22 The holy of the holies, and of the holy things he shall eat. 

#### Leviticus 21:23 Except to the veil he shall not come forward, and to the altar he shall not approach, for {a blemish he has], and he shall not profane the holy things of his God, for I the LORD, am the one sanctifying them. 

#### Leviticus 21:24 And Moses spoke to Aaron and his sons, and to all of the sons of Israel. 

#### Leviticus 22:1 And the LORD spoke to Moses, saying, 

#### Leviticus 22:2 Speak to Aaron and to his sons! And let them take heed concerning the holy things of the sons of Israel! and they shall not profane {name my holy], as much as they sanctify to me. I am the LORD. 

#### Leviticus 22:3 Say to them! Unto your generations every man who ever should come forward from all your seed to the holy things, as much as indeed {should sanctify the sons of Israel] to the LORD, and his uncleanness is upon him, they shall utterly destroy that soul from me. I am the LORD. 

#### Leviticus 22:4 And the man of the seed of Aaron of the priest, that this one being leprous or having gonorrhea, {of the holy things shall not eat], until whenever he should be cleansed. And the one touching any uncleanness of soul, or a man in whom ever should come forth from out of his marriage-bed of semen, 

#### Leviticus 22:5 or who ever should touch any {reptile unclean], which should defile him, or come upon a man in which he shall defile him according to any of his uncleanness; 

#### Leviticus 22:6 the soul who ever should touch them will be unclean until evening; he shall not eat from the holy things if he should not have bathed his body in water. 

#### Leviticus 22:7 And {should go down when the sun], then he will be clean, and then he shall eat from the holy things, for {bread it is his]. 

#### Leviticus 22:8 Decaying flesh and that taken by wild beasts he shall not eat, to be defiled by it. I am the LORD. 

#### Leviticus 22:9 And they shall guard my injunctions, that they should not take {on account of them sin], and should die because of them, if they shall profane them. I am the LORD, the one sanctifying them. 

#### Leviticus 22:10 And all of another race shall not eat the holy things; a sojourner with a priest, or a hireling shall not eat the holy things. 

#### Leviticus 22:11 And if a priest should acquire a soul procured with silver, he shall eat of his bread loaf; and his native-born servants, even these shall eat of his bread loaf. 

#### Leviticus 22:12 And a daughter of a man a priest, if she should become the wife of a man of another race, she {of the first-fruits of the holy things shall not eat]. 

#### Leviticus 22:13 And the daughter of a priest, if she becomes a widow or being cast out, and seed might not be in her, and she should return unto the house of her father, as in her youth; from the bread loaves of her father she shall eat. And all of another race shall not eat of them. 

#### Leviticus 22:14 And a man who ever should eat holy things according to ignorance; then he shall add his fifth part unto it, and shall give to the priest the holy thing. 

#### Leviticus 22:15 And they shall not profane the holy things of the sons of Israel, which they offer to the LORD, 

#### Leviticus 22:16 that they shall bring upon themselves lawlessness of the trespass in their eating their holy things; for I am the LORD, the one sanctifying them. 

#### Leviticus 22:17 And the LORD spoke to Moses, saying, 

#### Leviticus 22:18 Speak to Aaron and his sons, and to all the congregation of the sons of Israel! And you shall say to them, The man, a man from the sons of Israel, or of the foreigners lying near them among Israel, who ever should offer his gifts according to every acknowledgment offering of theirs, or according to every choice offering of theirs, as much as they should offer to the LORD for a whole burnt-offering, 

#### Leviticus 22:19 what is acceptable unto you is {male an unblemished] of the herds, and of the sheep, and of the goats. 

#### Leviticus 22:20 Of all as many as you have with a blemish among them you shall not bring to the LORD, for {not accepted it shall be] for you. 

#### Leviticus 22:21 And a man who ever should offer a sacrifice of deliverance to the LORD, while setting apart a vow, or according to a choice offering, or in your holiday feasts, out of the herds or of the sheep, it shall be unblemished for acceptance. {any blemish There shall not be] upon it. 

#### Leviticus 22:22 Blind, or broken, or with the tongue cut out, or troubled with warts, or chronic mange, or {scabs having] -- they shall not bring these to the LORD; and for a yield offering you shall not give of them upon the altar to the LORD. 

#### Leviticus 22:23 And a calf or a sheep with mutilated ears, or tailless, {for slaughter you shall make them] to yourself, but for your vow it shall not be taken. 

#### Leviticus 22:24 Crushed testicles, or being squeezed out, or emasculated, or drawn away -- you shall not bring them to the LORD, even upon your land you shall not offer them. 

#### Leviticus 22:25 And from out of the hand of a son of another race you shall not offer the gifts of your God of all these things. For there is corruption in them, a blemish in them; {shall not be received these] to you. 

#### Leviticus 22:26 And the LORD spoke to Moses, saying, 

#### Leviticus 22:27 A calf, or a sheep, or a goat, when ever it is born, then it shall be seven days under its mother; but the {day eighth] and beyond it shall be accepted for gift offerings, a yield offering to the LORD. 

#### Leviticus 22:28 And a calf and a sheep -- it and its offspring you shall not slay in {day one]. 

#### Leviticus 22:29 And if you should sacrifice a sacrifice vow of joyfulness to the LORD, {acceptable to you you shall sacrifice it]; 

#### Leviticus 22:30 in that day it shall be eaten; you shall not leave of the meats into the morning. I am the LORD. 

#### Leviticus 22:31 And you shall keep my commandments, and you shall observe them. I am the LORD. 

#### Leviticus 22:32 And you shall not profane {name my holy]; and I shall be sanctified in the midst of the sons of Israel. I am the LORD, the one sanctifying you, 

#### Leviticus 22:33 the one leading you from out of the land of Egypt, so as to be your God. I am the LORD. 

#### Leviticus 23:1 And the LORD spoke to Moses, saying, 

#### Leviticus 23:2 Speak to the sons of Israel! And you shall say to them, The holiday feasts of the LORD which you shall call them {convocations for holy] -- these are my holiday feasts. 

#### Leviticus 23:3 Six days you shall do work, but the {day seventh] is a Sabbath rest, {convocation a holy] to the LORD. All work you shall not do, it is a Sabbath to the LORD in all your house. 

#### Leviticus 23:4 These are the holiday feasts to the LORD, {convocations holy], which you shall call them in their seasons. 

#### Leviticus 23:5 In the first month, on the fourteenth day of the month, between the evenings is a passover to the LORD. 

#### Leviticus 23:6 And on the fifteenth day of this month is the holiday feast of the unleavened breads to the LORD. Seven days you shall eat unleavened breads. 

#### Leviticus 23:7 And the {day first convocation a holy will be] to you; {any work servile you shall not do]. 

#### Leviticus 23:8 And you shall bring a whole burnt-offering to the LORD seven days. And the {day seventh convocation a holy will be] to you. {any work servile You shall not do]. 

#### Leviticus 23:9 And the LORD spoke to Moses, saying, 

#### Leviticus 23:10 Speak to the sons of Israel! And you shall say to them, Whenever you should enter into the land which I give to you, and should harvest its harvest, that you shall bring the sheaf first-fruit of your harvest to the priest. 

#### Leviticus 23:11 And he shall offer the sheaf before the LORD accepted for you. On the next day of the first {shall offer it the priest]. 

#### Leviticus 23:12 And you shall offer on the day in which ever you should bring the sheaf -- a sheep unblemished of a year old for a whole burnt-offering to the LORD. 

#### Leviticus 23:13 And with its sacrifice two tenths of fine flour being prepared in olive oil, a sacrifice to the LORD for a scent of pleasant aroma to the LORD; and its libation -- the fourth of the hin of wine. 

#### Leviticus 23:14 And bread and {parched green wheat new] you shall not eat until {same day this], until whenever you should offer the gifts to your God -- {law an eternal] unto your generations in every dwelling of yours. 

#### Leviticus 23:15 And you shall count to yourselves from the next day of the Sabbaths, from the day which ever you should bring the sheaf of the increase offering, seven {periods of seven entire]; 

#### Leviticus 23:16 until the next day of the last period of seven you shall count fifty days, and you shall bring {sacrifice offering a new] to the LORD. 

#### Leviticus 23:17 From your houses you shall bring bread loaves, an increase offering; {two bread loaves of two tenths of fine flour they shall be], {being leaven baked] of the first produce to the LORD. 

#### Leviticus 23:18 And you shall bring with the bread loaves seven {lambs unblemished] of a year old, and {calf one] of the herd, and {rams two unblemished]. And they shall be a whole burnt-offering to the LORD, and their sacrifice offerings, and their libations, a sacrifice scent of pleasant aroma to the LORD. 

#### Leviticus 23:19 And they shall offer a young he-goat from out of the goats -- one for a sin offering, and two lambs of a year old for a sacrifice of deliverance offering with the bread loaves of the first produce. 

#### Leviticus 23:20 And {shall place them the priest] with the bread loaves of the first produce increase offering before the LORD, with the two lambs. They shall be holy to the LORD -- to the priest bringing them, to him it will be. 

#### Leviticus 23:21 And you shall call this day a convocation, it shall be holy to you. {any work servile You shall not do] on it. {law It is an eternal] unto your generations in all your house. 

#### Leviticus 23:22 And whenever you shall harvest the harvest of your land, you shall not complete the remainder of the harvest of your field in your harvesting. And the fall away portions of your harvest you shall not collect together -- for the poor and for the foreigner you shall leave them. I am the LORD your God. 

#### Leviticus 23:23 And the LORD spoke to Moses, saying, 

#### Leviticus 23:24 Speak to the sons of Israel, saying! The {month seventh], day one of the month will be to you a rest, a memorial of trumpets, {convocation a holy] to the LORD. 

#### Leviticus 23:25 {any work servile You shall not do], and you shall bring a whole burnt-offering to the LORD. 

#### Leviticus 23:26 And the LORD spoke to Moses, saying, 

#### Leviticus 23:27 Also on the tenth {month of this seventh] is a day of making an atonement, {convocation a holy it will be] to you. And you shall humble your souls, and you shall bring a whole burnt-offering to the LORD. 

#### Leviticus 23:28 All work you shall not do in it, in this day; {is for a day of making an atonement this to you]; to atone for you before the LORD your God. 

#### Leviticus 23:29 Every soul who shall not be humbled in it, in this day, shall be utterly destroyed from among its people. 

#### Leviticus 23:30 And every soul which shall do work in it, in this day, {shall be destroyed that soul] from among its people. 

#### Leviticus 23:31 All work you shall not do; {law it is an eternal] unto your generations in all your houses. 

#### Leviticus 23:32 A Sabbath of Sabbaths it will be to you. And you shall humble your souls from the ninth of the month. From evening to evening you shall observe the Sabbath of your Sabbaths. 

#### Leviticus 23:33 And the LORD spoke to Moses, saying, 

#### Leviticus 23:34 Speak to the sons of Israel! saying, The fifteenth of the {month seventh], this is a holiday of tents seven days to the LORD. 

#### Leviticus 23:35 And the {day first convocation a holy shall be] to you; {any work servile you shall not do]. 

#### Leviticus 23:36 Seven days you shall bring the whole burnt-offerings to the LORD, and the {day eighth convocation a holy will be] to you. And you shall bring a whole burnt-offering to the LORD, it is a holiday recess. {any work servile You shall not do]. 

#### Leviticus 23:37 These are holiday feasts to the LORD which you shall call them {convocations holy], so as to bring a yield offering to the LORD, whole burnt-offerings, and their sacrifices, and libation offerings; the thing according to day by day; 

#### Leviticus 23:38 besides the Sabbaths of the LORD, and besides your gifts, and besides all your vows, and besides all your voluntary offerings, which ever you shall give to the LORD. 

#### Leviticus 23:39 And on the fifteenth day {month of this seventh], whenever you should complete gathering the produce of the land, you shall solemnize a holiday to the LORD for seven days; on the {day first] a rest, and on the {day eighth] a rest. 

#### Leviticus 23:40 And you shall take to yourselves on the {day first] {fruit of the tree beautiful], and palm branches of palm trees, and tender branches {tree of a bushy], and willows, and {of the chaste tree tender branches] by the rushing stream; and you shall be glad before the LORD your God seven days. 

#### Leviticus 23:41 And you shall solemnize {a holiday it] -- the holiday to the LORD seven days of the year; {law an eternal] unto your generations. In the {month seventh] you shall solemnize {a holiday it]. 

#### Leviticus 23:42 In tents you shall dwell for seven days. All the native born in Israel shall dwell in tents, 

#### Leviticus 23:43 so that {should see your generations] that in tents I settled the sons of Israel, in my leading them from the land of Egypt. I am the LORD your God. 

#### Leviticus 23:44 And Moses told the holidays of the LORD to the sons of Israel. 

#### Leviticus 24:1 And the LORD spoke to Moses, saying, 

#### Leviticus 24:2 Give charge to the sons of Israel! And let them take to you {oil olive], pure, being beaten for light! to burn in a lamp continually, 

#### Leviticus 24:3 from outside the veil, in the tent of the testimony. {shall burn it Aaron and his sons] from evening until morning before the LORD perpetually -- {law an eternal] unto your generations. 

#### Leviticus 24:4 Upon the {lamp-stand pure] you shall burn the lamps before the LORD until into the morning. 

#### Leviticus 24:5 And you shall take fine flour, and you shall make for it twelve bread loaves; two tenths parts will be {bread loaf for the one]. 

#### Leviticus 24:6 And you shall place them two places; six bread loaves to the one place upon the {table pure] before the LORD. 

#### Leviticus 24:7 And you shall place upon the place {frankincense pure] and salt; and they will be the bread loaves for remembrance being situated before the LORD. 

#### Leviticus 24:8 On the day of the Sabbaths you shall put them before the LORD always before the sons of Israel -- {covenant an eternal]. 

#### Leviticus 24:9 And it will be for Aaron and to his sons. And they shall eat them in {place the holy], {is for a holy of holies this] to him from the things being sacrificed to the LORD -- {law an eternal]. 

#### Leviticus 24:10 And {went forth a son of an Israelitish woman], and he was a son of an Egyptian man among the sons of Israel. And they did combat in the camp -- the one of the Israelitish woman and the {man Israelite]. 

#### Leviticus 24:11 And {named the son of the woman Israelitish] the name -- he cursed. And they led him to Moses. And the name of his mother was Shelomith, daughter of Dibri of the tribe of Dan. 

#### Leviticus 24:12 And they put him in prison, to litigate over him because of the order of the LORD. 

#### Leviticus 24:13 And the LORD spoke to Moses, saying, 

#### Leviticus 24:14 Lead the one cursing outside the camp, and {shall place all the ones hearing] their hands upon his head, and {shall stone him all the congregation]. 

#### Leviticus 24:15 And to the sons of Israel speak! And you shall say to them, A man, a man if he should curse God, {the sin that one shall take]. 

#### Leviticus 24:16 {the one naming And] the name of the LORD, to death let him be put to death! {with stones Let stone him all the congregation]. Whether a foreigner, or whether native born in his naming the name of the LORD, let him come to an end. 

#### Leviticus 24:17 And the man who ever should strike the life of a man, and he should die, to death let him be put to death! 

#### Leviticus 24:18 And who ever should strike cattle, and it should die, let him pay life for life! 

#### Leviticus 24:19 And if any shall give a blemish to his neighbor, as he did to him, likewise he shall act against him. 

#### Leviticus 24:20 A break for a break, eye for eye, tooth for tooth; in so far as he should give a blemish to a man, so it shall be given to him. 

#### Leviticus 24:21 Who ever should strike a man, and he should die, to death let him be put to death! 

#### Leviticus 24:22 Justice will be one to the foreigner, and to the native inhabitant; for I am the LORD your God. 

#### Leviticus 24:23 And Moses spoke to the sons of Israel, and they led the one cursing outside the camp, and they stoned him with stones. And the sons of Israel did just as the LORD gave orders to Moses. 

#### Leviticus 25:1 And the LORD spoke to Moses on mount Sinai, saying, 

#### Leviticus 25:2 Speak to the sons of Israel! And you shall say to them, Whenever you should enter into the land which I give to you, then {shall rest the land] a Sabbath to the LORD. 

#### Leviticus 25:3 Six years you shall sow your field, and six years you shall trim your grapevine, and you shall bring together its fruit. 

#### Leviticus 25:4 But the {year seventh a Sabbath rest will be] in the land -- a Sabbath to the LORD. {your field You shall not sow] and {your grapevine you shall not trim], 

#### Leviticus 25:5 and the {by itself produce ascending] in your field you shall not reap up, and the grape of your sanctification you shall not gather in the vintage; a year's rest will be for the land. 

#### Leviticus 25:6 And {will be the Sabbath of the land] foods to you, and to your children, and to your maidservant, and to your hireling, and to the sojourner lying near to you, 

#### Leviticus 25:7 and to your cattle, and to the beasts in your land {shall be all of its produce] for food. 

#### Leviticus 25:8 And you shall count out to yourself seven rests of years, seven years seven times. And they will be to you seven periods of seven of years, nine and forty years. 

#### Leviticus 25:9 And you shall declare by trumpet sound in all your land, in the {month seventh], the tenth of the month. In the day of making an atonement -- you shall declare by trumpet in all your land. 

#### Leviticus 25:10 And you shall sanctify the year -- the fiftieth year; and you shall proclaim forth a release upon the land to all the ones dwelling it. A year of release {indication its will be] to you. And you shall go forth each to his possession, and {each to his family you shall go forth]. 

#### Leviticus 25:11 {of release This indication], the year, the fiftieth year will be to you. You shall not sow, nor in any way shall you reap the produce {self ascending by its]; and you shall not gather the vintage, the things having been sanctified of it. 

#### Leviticus 25:12 For {of release an indication it is]; it shall be holy to you. From the fields you shall eat its produce. 

#### Leviticus 25:13 In the year of the release, the indication of it, {shall return back each] unto his possession. 

#### Leviticus 25:14 And if you should render a sale to your neighbor, or if you should acquire by your neighbor, let not {afflict a man] his neighbor! 

#### Leviticus 25:15 According to the number of years after the indication shall you acquire land from your neighbor, and according to the number of years left of the produce shall he sell to you. 

#### Leviticus 25:16 In so far as there might be many of the years, he shall multiply the value of his possession; and in so far as there might be less of the years, he shall lessen the value of his possession; for by number of the produce years left shall he sell to you. 

#### Leviticus 25:17 Let not {afflict a man] his neighbor! And you shall fear the LORD your God. I am the LORD your God. 

#### Leviticus 25:18 And you shall observe all my ordinances, and all my judgments. And you shall keep, and you shall observe them. And you shall dwell upon the land complying. 

#### Leviticus 25:19 And {shall give the land] its resources, and you shall eat in fullness, and you shall dwell complying upon it. 

#### Leviticus 25:20 And if you should say, What shall we eat in {year this seventh] if we do not sow, and we do not gather in our produce? 

#### Leviticus 25:21 Then I will send my blessing to you in the {year sixth], and the land shall produce its produce for the three years. 

#### Leviticus 25:22 And you shall sow the {year eighth], and you shall eat of the {produce old] until the {year ninth]. Until whenever {should come its produce], you shall eat old produce of the old. 

#### Leviticus 25:23 And the land shall not be sold for security; {mine for is the earth], because {foreigners and sojourners you are] before me. 

#### Leviticus 25:24 And according to all the land of your possession {ransoms you shall give] for the land. 

#### Leviticus 25:25 But if {should be in need your brother with you], and should have sold part of his possession, and {should come the one acting as next of kin being near to him], then he shall ransom the sale of his brother. 

#### Leviticus 25:26 But if there might not be any acting as next of kin, and later he should be well-provided in the hand, and he should find himself fit for his ransoms, 

#### Leviticus 25:27 then he shall reckon the years of his sale, and shall give back the superior amount to the man to whom he sold it, and he shall return back to his possession. 

#### Leviticus 25:28 But if {should not be well-provided his hand] with the thing fit so as to repay him, then {will be his sale property] to the one acquiring it until the year of the release; and it shall go forth in the release; then he shall go return to his possession. 

#### Leviticus 25:29 But if any should sell a house inhabited in a city being walled, then there shall be the ransoming of it, until the time should be fulfilled, a year of days will be the time of ransoming of it. 

#### Leviticus 25:30 But if it should not be ransomed until {should be fulfilled year the entire], {shall be validated the house being in the city having a wall] firmly to the one acquiring it, unto his generations, and it shall not go forth in the release. 

#### Leviticus 25:31 But the houses, the ones in properties, ones in which there is not among them a wall round about, {belonging to the field of the land they shall be considered] -- ransomable always they shall be. And in the release they shall go forth. 

#### Leviticus 25:32 And the cities of the Levites, the houses of the cities in their possession, {ransomable always shall be] to the Levites. 

#### Leviticus 25:33 And what ever should be ransomed by of the Levites, then {shall go forth the sale of houses of the city of their possession] unto the release. For the houses of the cities of the Levites -- this is their possession in the midst of the sons of Israel. 

#### Leviticus 25:34 And the fields, the ones being separated in their cities shall not be sold, for {possession eternal this their is]. 

#### Leviticus 25:35 And if {should be in need your brother who is with you], and he shall be powerless in the hands with you; you shall take hold of him, {as a foreigner and a sojourner and he shall live with you]. 

#### Leviticus 25:36 You shall not take {from him interest], nor for an amount. And you shall fear your God, and {shall live your brother] with you. 

#### Leviticus 25:37 Your money you shall not give to him with interest due; and with usury you shall not give to him of your foods. 

#### Leviticus 25:38 I am the LORD your God, the one leading you from out of the land of Egypt, to give to you the land of Canaan, so as to be your God. 

#### Leviticus 25:39 And if {should be humbled your brother] by you, and should be sold to you, he shall not serve you in the slavery of a servant. 

#### Leviticus 25:40 {as a hireling or a sojourner He shall be] to you until the year of the release -- thus he shall work for you; 

#### Leviticus 25:41 and he shall go forth in the release from you himself, and his children with him. And he shall go unto his family; unto the possession of his father he shall run. 

#### Leviticus 25:42 Because {my servants these are] whom I led out of the land of Egypt. They shall not be sold in a sale of a domestic servant. 

#### Leviticus 25:43 You shall not violently strain him in his trouble, and you shall fear your God. 

#### Leviticus 25:44 And a boy and a girl, as many as should be to you from the nations, as many as {round about you there are] -- from them you shall acquire a manservant and a maidservant. 

#### Leviticus 25:45 And from the sons of the sojourners being among you -- from these you shall acquire, and from their relatives of the ones with you; as many as happen to be in your land, let them be to you for a possession! 

#### Leviticus 25:46 And you shall divide them to your children after you. And they shall be to you possessions unto the eon. But of your brethren of the sons of Israel, each concerning his brother shall not violently strain him in his troubles. 

#### Leviticus 25:47 And if wealth should find in the hand of the foreigner or the sojourner living by you, and {being in distress your brother] should be sold to the foreigner or to the sojourner living by you, or to {by birth a foreigner]; 

#### Leviticus 25:48 after his being sold, there shall be a ransoming to him -- one of his brethren shall ransom him. 

#### Leviticus 25:49 A brother of his father, or a son {brother of his father's] shall ransom him; or one of the members of the family of his flesh of his tribe shall ransom him. And if being well-provided in his hands, he shall ransom himself. 

#### Leviticus 25:50 And he shall reckon together with the one acquiring him from the year of which he sold himself to him until the year of the release. And {will be the money of his sale] as the day of a hireling. Year to year he will be with him. 

#### Leviticus 25:51 And if to any {many surplus years there might be], for these he shall render his ransoms of the money of his sale. 

#### Leviticus 25:52 And if few should be left behind of the years to the year of the release, then he shall reckon to him according to his years, and shall render his ransoms. 

#### Leviticus 25:53 As a hireling, year to year he shall be with him. You shall not violently strain him in his trouble before you. 

#### Leviticus 25:54 And if he should not pay ransom according to these things, then he shall go forth in the year of the release; he and his children with him. 

#### Leviticus 25:55 For to me the sons of Israel are servants; {of my children these are], whom I led from out of the land of Egypt. I am the LORD your God. 

#### Leviticus 26:1 You shall not make to yourselves a handmade thing, nor a carving, nor {a monument shall you raise up] to yourselves; nor a stone exemplar shall you stand in your land to do obeisance to it. I am the LORD your God. 

#### Leviticus 26:2 My Sabbaths you shall keep, and of my holy things you shall fear. I am the LORD. 

#### Leviticus 26:3 If in my orders you should go, and my commandments you should keep, and should do them, 

#### Leviticus 26:4 then I will give the rain to you in its season, and to the land I will give its produce, and the trees of the fields will give back their fruit. 

#### Leviticus 26:5 And {shall overtake among you the threshing] the gathering of the crops; and the gathering of the crops shall overtake the sowing; and you shall eat your bread unto fullness. And you shall dwell with safety upon your land. 

#### Leviticus 26:6 And I will put peace in your land, and you shall go to bed, and there will not be among you one frightening. And I will destroy {wild beasts the ferocious] from your land, and war shall not go through your land. 

#### Leviticus 26:7 And you shall pursue your enemies, and they shall fall before you in carnage. 

#### Leviticus 26:8 And there shall pursue from out of you five after a hundred, and a hundred of you shall pursue tens of thousands; and {shall fall your enemies] before you by sword. 

#### Leviticus 26:9 And I will look upon you, and I will increase you, and I will multiply you, and I will establish my covenant with you. 

#### Leviticus 26:10 And you shall eat even the old of the old, and {the old in front of the new you shall bring forth]. 

#### Leviticus 26:11 And I will put my tent among you, and {shall not abhor my soul] you. 

#### Leviticus 26:12 And I will walk about among you; and I will be your God, and you shall be to me for a people. 

#### Leviticus 26:13 I am the LORD your God, the one leading you from out of the land of Egypt, where you were slaves. And I broke the bond of your yoke, and led you out in an open manner. 

#### Leviticus 26:14 And if you should not obey me, nor should observe {my orders these], 

#### Leviticus 26:15 but should resist them, and {my judgments you should loathe] in your soul, so as for you to not observe all my commandments, so as for you to efface my covenant, 

#### Leviticus 26:16 then I will do thus to you; and I will to set upon you perplexity, and also the mange, and jaundice, inflaming of your eyes, and of your life wasting away. And you shall sow ineffectually of your seeds, and {shall eat them your opponents]. 

#### Leviticus 26:17 And I will set my face against you, and you shall fall before your enemies; and {shall pursue you the ones detesting you], and you shall flee with no one pursuing you. 

#### Leviticus 26:18 And if in this you should not obey me, then I will add to correct you with strokes seven times for your sins, 

#### Leviticus 26:19 and I will break the insolence of your pride, and I will establish your heaven as iron, and your land as brass, 

#### Leviticus 26:20 and {shall be in vain your strength]. And {shall not give the earth] of your sowing it, and the tree of the field shall not give its fruit. 

#### Leviticus 26:21 And if after these things you should go sideways, and should not want to obey me, I will add to you {calamities seven] according to your sins. 

#### Leviticus 26:22 And I will send upon you the {beasts wild] of the land; and they shall eat you, and shall completely consume your cattle; and {very few I will make you]; and {shall be made desolate your ways]. 

#### Leviticus 26:23 And if over these things you should not be corrected, but should go to me sideways, 

#### Leviticus 26:24 I will go also with you in rage sideways, and I will strike you also seven times for your sins. 

#### Leviticus 26:25 And I will bring upon you a sword, avenging punishment of covenant. And you shall take refuge in your cities, and I will send out plague upon you; and you shall be delivered up into the hands of the enemies. 

#### Leviticus 26:26 In your being afflicted there will be scarcity of bread loaves. {shall bake Ten women] your bread loaves in {oven one], and they shall give back the bread loaves to you by weight; and you shall eat, and no way shall you be filled. 

#### Leviticus 26:27 And if upon this you do not obey me, but should go to me sideways, 

#### Leviticus 26:28 then I myself shall go with you in rage sideways, and I will correct you, even I, seven times according to your sins. 

#### Leviticus 26:29 And you shall eat the flesh of your sons; and the flesh of your daughters you shall eat. 

#### Leviticus 26:30 And I will make desolate your monuments, and I will utterly destroy {wooden images made by hands your]. And I will put your carcasses upon the carcasses of your idols. And {will loathe my soul] in you. 

#### Leviticus 26:31 And I will establish your cities as desolate, and I will make quite desolate your holy places; and no way shall I smell the scents of your sacrifices. 

#### Leviticus 26:32 And I will make quite desolate, even I, your land. And {shall wonder over it your enemies dwelling in it]. 

#### Leviticus 26:33 And I will disseminate you into the nations; and {will completely consume you coming upon you the sword]; and {will be your land] desolate, and your cities will be desolate places. 

#### Leviticus 26:34 Then {will favor the land] its Sabbaths all the days of its desolation, and you will be in the land of your enemies. Then {shall observe the Sabbath the land], and will favor its Sabbaths. 

#### Leviticus 26:35 All the days of its desolation it shall observe the Sabbath, in which it did not observe the Sabbath in your Sabbaths, when you dwelt it. 

#### Leviticus 26:36 And to the ones being left behind of you, I will bring timidity into their heart in the land of their enemies. And {will pursue them the sound of a leaf being brought along], and they shall flee as fleeing from war, and they shall fall with no one pursuing. 

#### Leviticus 26:37 And {will neglect the brother] his brother as in war, but no one running them down. And you will not be able to oppose your enemies. 

#### Leviticus 26:38 And you shall perish among the nations, and {will devour you the land of your enemies]. 

#### Leviticus 26:39 And the ones being left behind from you shall be corrupted on account of their sins, and on account of the sins of their fathers. In the land of their enemies they shall be melted away. 

#### Leviticus 26:40 And they shall declare openly their sins, and the sins of their fathers; for they violated and overlooked me, and that they went before me sideways. 

#### Leviticus 26:41 And I went with them in rage sideways, and I will destroy them in the land of their enemies. Then {shall have felt shame heart their uncircumcised], and then they shall think well on their sins. 

#### Leviticus 26:42 And I shall remember the covenant of Jacob, and the covenant of Isaac; and the covenant of Abraham I shall remember; and the land I shall remember. 

#### Leviticus 26:43 And the land shall be abandoned of them. Then {shall favorably receive the land] her Sabbaths, in her being made desolate because of them. And they shall accept the things of their own lawlessness, because {my judgments they overlooked], and {my orders they loathed] in their soul. 

#### Leviticus 26:44 And thus, they being in the land of their enemies, I did not overlook them, nor loathed in them so as to completely consume them for effacing my covenant, the one with them. For I am the LORD their God. 

#### Leviticus 26:45 And I will remember their covenant, the former one, when I led them out of the land of Egypt, from out of the house of slavery before the nations, to be their God. I am the LORD. 

#### Leviticus 26:46 These are the judgments, and the orders, and the law, which the LORD made between himself and between the sons of Israel on mount Sinai by the hand of Moses. 

#### Leviticus 27:1 And the LORD spoke to Moses, saying, 

#### Leviticus 27:2 Speak to the sons of Israel! And you shall say unto them, A man who ever should vow a vow for a value of his life to the LORD, 

#### Leviticus 27:3 it will be the value of a male from twenty years unto sixty years old -- {will be his value] fifty double-drachmas of silver by the {weight holy]. 

#### Leviticus 27:4 And the female will be the price of thirty double-drachmas. 

#### Leviticus 27:5 And if from five years old unto twenty years old, {shall be the value of the male] twenty double-drachmas, and the female ten double-drachmas. 

#### Leviticus 27:6 And from a month unto five years old, {shall be the value of the male] five double-drachmas of silver, and the female three double-drachmas of silver. 

#### Leviticus 27:7 And if from sixty years old and up, if indeed {a male it might be], {shall be his value] fifteen double-drachmas of silver; for the female ten double-drachmas. 

#### Leviticus 27:8 And if {of low estate he might be] for a value, he shall be stood before the priest, and {shall value him the priest], just as {is able to afford the hand of the one making a vow] -- thus {shall value him the priest]. 

#### Leviticus 27:9 And if it be from the cattle of the ones being offered of them as a gift to the LORD, who ever should give of these to the LORD, it shall be holy. 

#### Leviticus 27:10 He shall not change it good for bad, nor bad for good. And if by bartering he should barter it cattle for cattle, {shall be it and the thing bartered] holy. 

#### Leviticus 27:11 And if any {beast unclean], of which none are offered of them as a gift to the LORD, he shall set the beast before the priest, 

#### Leviticus 27:12 and {shall value it the priest], between good and between bad. And as far as {valuing it the priest], so it will stand. 

#### Leviticus 27:13 And if the one ransoming should ransom it, he shall add the fifth part to the value of it. 

#### Leviticus 27:14 And a man, who ever should sanctify his house holy to the LORD, then {shall value it the priest] between good and between bad; what ever {shall value it the priest], so it shall stand. 

#### Leviticus 27:15 And if the one sanctifying it should redeem his house, he shall add unto it the fifth part of the money for the value, and it shall be his. 

#### Leviticus 27:16 And if {from the field of his possession should sanctify a man] to the LORD, then {shall be the value] according to its sowing -- a cor of barley equals fifty double-drachmas of silver. 

#### Leviticus 27:17 And if from the year of the release he should sanctify his field, according to his value it shall stand. 

#### Leviticus 27:18 But if {last after the release he should sanctify his field], {shall count in addition to it the priest] the money for the years remaining, until unto the next year of the release, and it shall be deducted from his valuation. 

#### Leviticus 27:19 And if {should ransom the field the one sanctifying] it, he shall add the fifth part of the money to the value of it, and it will be his. 

#### Leviticus 27:20 And if he should not ransom the field, and should give back the field {man to another], no longer shall he ransom it. 

#### Leviticus 27:21 But {will be the field coming forth from the release] holy to the LORD, as the land being separated; to the priest it will be his possession. 

#### Leviticus 27:22 And if from the field of which he acquired, which is not from the field of his possession, that he should sanctify to the LORD, 

#### Leviticus 27:23 the priest shall impute to him the full value from the year of the release, and he shall render the value in that day as holy to the LORD. 

#### Leviticus 27:24 And in the year of the release, he shall give back the field to the man from whom he acquired it, of whom was in possession of the land. 

#### Leviticus 27:25 And all value will be {weights by holy] -- twenty oboli will be the double-drachma. 

#### Leviticus 27:26 And every first-born which ever should be born among your cattle will be to the LORD. And {shall consecrate it no one]. If also a calf, if also a sheep, {to the LORD it is]. 

#### Leviticus 27:27 And if of the four-footed creatures of the unclean he should barter for the value of it, then he shall add his fifth part to it, and it will be his. But if he should not ransom it, it shall be sold according to its valuation. 

#### Leviticus 27:28 And every offering for consumption which ever {should present a man] to the LORD of all as much as is to him, from man unto beast, and from a field of his possession, he shall not sell it, nor ransom it; every offering for consumption {a holy of holies will be] to the LORD. 

#### Leviticus 27:29 And all, what ever should be presented from men, it shall not be ransomed, but to death it shall be put to death. 

#### Leviticus 27:30 Every tenth of the land, from the seed of the land, and from the fruit of the wood to the LORD, it is holy to the LORD. 

#### Leviticus 27:31 And if ransoming {should ransom a man] of his tenth, his fifth part he shall add to it, and it will be his. 

#### Leviticus 27:32 And every tenth of oxen, and sheep, and all which should go through in the number by the rod measure, the tenth will be holy to the LORD. 

#### Leviticus 27:33 You shall not barter it good for bad, nor bad for good. And if in bartering you should barter it, it shall be and its barter holy, it shall not be ransomed. 

#### Leviticus 27:34 These are the commandments which the LORD gave charge to Moses for the sons of Israel on mount Sinai.