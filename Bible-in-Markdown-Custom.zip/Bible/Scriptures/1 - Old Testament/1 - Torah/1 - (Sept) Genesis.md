#### Genesis 1:1 In the beginning God made the heaven and the earth. 

#### Genesis 1:2 But the earth was unseen and unready, and darkness was upon the abyss, and spirit of God bore upon the water. 

#### Genesis 1:3 And God said, Let there be light! And there was light. 

#### Genesis 1:4 And God beheld the light that it was good. And God parted between the light and between the darkness. 

#### Genesis 1:5 And God called the light, Day, and the darkness he called, Night; and there was evening and there was morning, day one. 

#### Genesis 1:6 And God said, Let there be a firmament in the midst of the water, and let it be for parting between water and water! 

#### Genesis 1:7 And God made the firmament, and God parted between the water which was underneath the firmament, and between the water above the firmament. 

#### Genesis 1:8 And God called the firmament, Heaven. And God beheld that it was good; and there was evening and there was morning, {day the second}. 

#### Genesis 1:9 And God said, Let {come together the water underneath the heaven} into {gathering one}, and let {appear the dry land}! And it was so. And {gathered together the water underneath the heaven} into their gatherings, and {appeared the dry land}. 

#### Genesis 1:10 And God called the dry land, Earth; and the collections of the waters he called, Seas. And God beheld that it was good. 

#### Genesis 1:11 And God said, Let {grow the earth} pasturage of grass sowing seed according to type, and according to likeness, and {tree the fruitful} producing fruit which the seed of it is in it, according to type upon the earth! And it was so. 

#### Genesis 1:12 And {brought forth the earth} pasturage of grass sowing seed, according to type, and according to likeness; and {tree the fruitful} producing fruit which the seed of it is in it, according to type upon the earth. 

#### Genesis 1:13 And God beheld that it was good. And there was evening and there was morning, {day the third}. 

#### Genesis 1:14 And God said, Let there be luminaries in the firmament of the heaven for giving light upon the earth, to part between the day and between the night! And let them be for signs, and for times, and for days, and for years! 

#### Genesis 1:15 And let them be for giving light in the firmament of the heaven, so as to shine upon the earth! And it was so. 

#### Genesis 1:16 And God made the two {luminaries great}; the {luminary greater} for beginnings of the day, and the {luminary lesser} for beginnings of the night, and the stars. 

#### Genesis 1:17 And {put them God} in the firmament of the heaven, so as to shine upon the earth, 

#### Genesis 1:18 and to begin the day and the night, and to part between the light and between the darkness. And God beheld that it was good. 

#### Genesis 1:19 And there was evening and there was morning, {day the fourth}. 

#### Genesis 1:20 And God said, Let {bring forth the waters} reptiles {lives of living}, and {winged creatures flying} upon the earth below the firmament of the heaven! And it was so. 

#### Genesis 1:21 And God made the {whales great}, and every life of living creatures of reptiles which {brought forth the waters} according to their types; and every {winged creature feathered} according to type. And God beheld that it was good. 

#### Genesis 1:22 And {blessed them God}, saying, Grow and multiply, and fill the waters in the seas! And {the winged creatures let} be multiplied upon the earth! 

#### Genesis 1:23 And there was evening and there was morning, {day the fifth}. 

#### Genesis 1:24 And God said, Let {bring forth the earth life living} according to its type -- four-footed, and reptiles, and wild beasts of the earth according to type! And it was so. 

#### Genesis 1:25 And God made the wild beasts of the earth according to type, and the cattle according to their type, and all the reptiles of the earth according to type. And God beheld that it was good. 

#### Genesis 1:26 And God said, Let us make man according to {image our}, and according to likeness! And let them control the fishes of the sea, and the winged creatures of the heaven, and the cattle, and all the earth, and all the reptiles of the ones crawling upon the earth! 

#### Genesis 1:27 And God made man. According to the image of God he made him. Male and female he made them. 

#### Genesis 1:28 And {blessed them God}, saying, Grow and multiply, and fill the earth, and dominate it! And control the fishes of the sea, and the winged creatures of the heaven, and all the cattle, and all of the earth, and all of the reptiles of the ones crawling upon the earth! 

#### Genesis 1:29 And God said, Behold, I have given to you every grass fit for sowing a sowing of seed which is upon the earth, and every tree which has in itself a fruit seed fit for sowing; to you it will be for food, 

#### Genesis 1:30 and to all the wild beasts of the earth, and to all the winged creatures of the heaven, and to every reptile crawling upon the earth, which has in itself breath of life, even every {grass green} for food. And it was so. 

#### Genesis 1:31 And God beheld all as much as he made. And behold, it was {good exceedingly}. And there was evening and there was morning, {day the sixth}. 

#### Genesis 2:1 And {were completed the heaven and the earth}, and all the cosmos of them. 

#### Genesis 2:2 And God completed in the {day sixth} his works which he did. And he rested on the {day seventh} from all his works which he did. 

#### Genesis 2:3 And God blessed the {day seventh}, and sanctified it; for in it he rested from all his works -- which God began to do. 

#### Genesis 2:4 This is the book of the origin of heaven and earth, when it became, in the day {made God} the heaven and the earth, 

#### Genesis 2:5 and every green field before it existed upon the earth, and all grass of the field before its rising, {did not for rain the LORD God} upon the earth, and {man no there was} to work it. 

#### Genesis 2:6 But a spring ascended from out of the earth, and it watered all the face of the earth. 

#### Genesis 2:7 And God shaped the man, {dust taking} from the earth. And he breathed into his face breath of life, and {became man} a {soul living}. 

#### Genesis 2:8 And God planted paradise in Eden according to the east, and he put there the man whom he shaped. 

#### Genesis 2:9 And {caused to rise up God} yet from the earth every {tree beautiful} to the sight, and good for food, and the tree of life in the midst of the paradise, and the tree, the one to know knowing good and evil. 

#### Genesis 2:10 And a river goes forth from Eden to water the paradise; from there it separates into four sources. 

#### Genesis 2:11 The name to the one is Phison. This is the one encircling all the land of Havilah -- {there where is the gold}. 

#### Genesis 2:12 And the gold of that land is good, and there is the carbuncle and the {stone leek colored}. 

#### Genesis 2:13 And the name to the {river second} is Gihon. This is the one encircling all the land of Ethiopia. 

#### Genesis 2:14 And the {river third} is the Tigris. This is the one going forth over against the Assyrians. And the {river fourth} is the Euphrates. 

#### Genesis 2:15 And {took the LORD God} the man whom he shaped, and put him in the paradise to work it and to guard. 

#### Genesis 2:16 And {gave charge the LORD God} to Adam, saying, From all of a tree of the one in the paradise {food you shall eat}, 

#### Genesis 2:17 but from the tree of the knowing good and evil, you shall not eat from it; but in whatever day you should eat from it, to death you shall die. 

#### Genesis 2:18 And {said the LORD God}, It is not good {to be for the man} alone, let us make for him a helper according to him! 

#### Genesis 2:19 And God shaped yet from out of the earth all the wild beasts of the field, and all the winged creatures of the heaven. And he led them to Adam, to behold what he would call them. And all what ever {called it Adam} -- {life the living}, this was the name to it. 

#### Genesis 2:20 And Adam called names to all the cattle, and to all the winged creatures of the heaven, and to all the wild beasts of the field; but to Adam there was not found a helper likened to him. 

#### Genesis 2:21 And {put the LORD God} a change of state over Adam, and he slept. And he took one of his ribs, and supplied flesh against it. 

#### Genesis 2:22 And {built the LORD God} the rib which he took from Adam into a woman. And he led her to Adam. 

#### Genesis 2:23 And Adam said, This now is bone from my bones, and flesh from my flesh; she shall be called woman, for from the man she was taken. 

#### Genesis 2:24 Because of this {shall leave man} his father and mother, and shall cleave to his wife, and {shall be the two} for {flesh one}. 

#### Genesis 2:25 And {were the two} naked, both Adam and his wife. And they were not ashamed. 

#### Genesis 3:1 But the serpent was most skilled of all the wild beasts, of the ones upon the earth whom {made the LORD God}. And {said the serpent} to the woman, For why said God, No way should you eat from all of a tree of the paradise? 

#### Genesis 3:2 And {said the woman}, From fruit of the tree of the paradise we shall eat; 

#### Genesis 3:3 but from the fruit of the tree which is in the middle of the paradise, God said, Eat not from it, nor touch it! that you should not die. 

#### Genesis 3:4 And {said the serpent} to the woman, Not to death will you die. 

#### Genesis 3:5 {knows For God} that in which ever day you should eat of it, {will be opened wide your eyes}, and you will be as gods, knowing good and evil. 

#### Genesis 3:6 And {beheld the woman} that {is good the tree} for food, and that it is pleasing to the eyes to behold, and is beautiful for contemplating. And having taken the fruit of it, she ate, and she gave also to her husband with her, and they ate. 

#### Genesis 3:7 And {were opened wide the eyes of the two}, and they knew that they were naked. And they sewed leaves of a fig-tree, and made to themselves loincloths. 

#### Genesis 3:8 And they heard the voice of the LORD God walking in the paradise at dusk. And {hid both Adam and his wife} from the face of the LORD God in the midst of the tree of the paradise. 

#### Genesis 3:9 And God called Adam, and said to him, Adam, Where are you? 

#### Genesis 3:10 And he said to him, {your voice I heard} while walking in the paradise, and I feared, for I am naked, and I hid. 

#### Genesis 3:11 And {said to him God}, Who announced to you that you are naked, unless from the tree of which I gave charge to you, saying, This alone you are not to eat from it -- you ate. 

#### Genesis 3:12 And Adam said, The woman whom you gave to be with me, she gave to me from the tree, and I ate. 

#### Genesis 3:13 And {said the LORD God} to the woman, What is this you did? And {said the woman}, The serpent deceived me, and I ate. 

#### Genesis 3:14 And {said the LORD God} to the serpent, Because you did this, accursed are you from all the cattle, and from all the wild beasts of the ones upon the earth. Upon your breast and belly you shall go, and earth you shall eat all the days of your life. 

#### Genesis 3:15 And {hatred I will put} between you and between the woman; and between your seed and between her seed. He will give heed to your head, and you will give heed to his heel. 

#### Genesis 3:16 And to the woman he said, In multiplying I will multiply your distresses, and your moanings. In distresses you will bear children, and to your husband your submission, and he will dominate you. 

#### Genesis 3:17 And to Adam he said, Because you hearkened to the voice of your wife, and ate from the tree of which I gave charge to you, saying, This alone you are not to eat from it -- and you ate; accursed is the land among your works; in distresses you will eat it all the days of your life. 

#### Genesis 3:18 Thorn-bushes and thistles will rise to you, and you will eat the grass of the field. 

#### Genesis 3:19 By sweat of your face you will eat your bread, until the returning you into the earth from out of which you were taken. For earth you are and unto earth you will go. 

#### Genesis 3:20 And Adam called the name of his wife, Zoe, for she was mother of all the living. 

#### Genesis 3:21 And {made the LORD God} to Adam and his wife garments of skins, and he clothed them. 

#### Genesis 3:22 And God said, Behold, Adam has become as one of us, to know good and evil. And now, lest at any time he might stretch out the hand, and should take from the tree of life, and should eat, and will live into the eon -- 

#### Genesis 3:23 that {ejected him the LORD God} from the paradise of the delicacy, to work the earth from which he was taken. 

#### Genesis 3:24 And he cast out Adam, and settled him before the paradise of the delicacy, and ordered the cherubim, and the flaming {broadsword turning}, to guard the way of the tree of life. 

#### Genesis 4:1 And Adam knew Eve his wife. And conceiving, she bore Cain, and said, I acquired a man through God. 

#### Genesis 4:2 And she added to bear his brother, Abel. And Abel became a shepherd of sheep, but Cain was working the land. 

#### Genesis 4:3 And it came to pass after some days, Cain brought from the fruits of the land a sacrifice to the LORD. 

#### Genesis 4:4 And Abel brought also himself from the first-born of his sheep, and from his fatlings. And God looked upon Abel and upon his gifts. 

#### Genesis 4:5 But upon Cain and upon his sacrifices, he did not take heed. And Cain fretted exceedingly, and became downcast in the face. 

#### Genesis 4:6 And {said the LORD God} to Cain, Why {dejected are you}, and why is {downcast your face}? 

#### Genesis 4:7 If not rightly you brought, {rightly but not} divided, you sinned? Be still, to you shall be his submission, and you will control him! 

#### Genesis 4:8 And Cain said to Abel his brother, Let us go into the plain. And it came to pass in their being in the plain, Cain rose up against Abel his brother, and killed him. 

#### Genesis 4:9 And {said the LORD God} to Cain, Where is Abel your brother? And he said, I do not know, {not the keeper of my brother I am}. 

#### Genesis 4:10 And the LORD said, What did you do? The voice of the blood of your brother yells to me from the ground. 

#### Genesis 4:11 And now, accursed are you from the earth which gaped wide her mouth to take the blood of your brother from your hand. 

#### Genesis 4:12 When you work the ground, and it does not add {her strength to give} to you; then in moaning and trembling you will be upon the earth. 

#### Genesis 4:13 And Cain said to the LORD, {is too great My fault} to forgive me. 

#### Genesis 4:14 If you cast me today from the face of the earth, and from your face, I will hide, and I will be moaning and trembling upon the earth; and it will be all the ones finding me will kill me. 

#### Genesis 4:15 And {said to him the LORD God}, Not so, all killing Cain {seven times by punishing will be disabled}. And {put the LORD God} a sign to Cain {to not do away with him for all finding him}. 

#### Genesis 4:16 {went forth And Cain} from the face of God, and he lived in the land of Nod, over against Eden. 

#### Genesis 4:17 And Cain knew his wife. And she, conceiving, bore Enoch. And he was building a city, and he named the city after the name of his son Enoch. 

#### Genesis 4:18 {was born And to Enoch} Irad; and Irad procreated Mehujael; and Mehujael procreated Methusael; and Methusaela procreated Lamech. 

#### Genesis 4:19 And {took to himself Lamech} two wives; the name to the one was Adah, and the name to the second was Zillah. 

#### Genesis 4:20 And Adah bore Jabel, this one was father of the ones living in tents, grazing cattle. 

#### Genesis 4:21 And the name to his brother was Jubal, this one was the one introducing the psaltery and the harp. 

#### Genesis 4:22 But Zillah also herself bore Tubal-cain, and he was a hammer-smith brazier of brass and of iron. And the sister of Tubal-cain was Naamah. 

#### Genesis 4:23 {said And Lamech} to his own wives, Adah and Zillah, Hear my voice, O wives of Lamech! Give ear to my words! for {a man I killed} for giving a wound to me, and a young man for giving a stripe to me. 

#### Genesis 4:24 For {seven times punishment} is for Cain, but for Lamech, seventy times seven. 

#### Genesis 4:25 {knew And Adam} Eve his wife. And conceiving, she bore a son, and named his name Seth, saying, {raised up For to me God seed another} instead of Abel, whom Cain killed. 

#### Genesis 4:26 And to Seth was born a son. And he named his name Enos; this one hoped to call upon the name of the LORD God. 

#### Genesis 5:1 This is the book of the origin of men in which day God made Adam. According to the image of God he made him. 

#### Genesis 5:2 Male and female he made them, and he blessed them. And he named his name Adam, in which day he made them. 

#### Genesis 5:3 {lived And Adam} thirty and two hundred years. And he procreated a son according to his shape, and according to his image; and he named his name, Seth. 

#### Genesis 5:4 And came to pass the days of Adam which he lived after his procreating Seth, {years seven hundred}, and he procreated sons and daughters. 

#### Genesis 5:5 And came to pass all the days of Adam which he lived, thirty and nine hundred years, and he died. 

#### Genesis 5:6 {lived And Seth} five and two hundred years, and he procreated Enos. 

#### Genesis 5:7 And Seth lived after his procreating Enos, seven years and seven hundred; and he procreated sons and daughters. 

#### Genesis 5:8 And came to pass all the days of Seth, twelve and nine hundred years, and he died. 

#### Genesis 5:9 And Enos lived {years a hundred ninety}, and he procreated Cainan. 

#### Genesis 5:10 And Enos lived after his procreating Cainan, fifteen years and seven hundred, and he procreated sons and daughters. 

#### Genesis 5:11 And came to pass all the days of Enos, five years and nine hundred, and he died. 

#### Genesis 5:12 And Cainan lived seventy and a hundred years, and he procreated Mahalaleel. 

#### Genesis 5:13 And Cainan lived after his procreating Mahalaleel, forty and seven hundred years, and he procreated sons and daughters. 

#### Genesis 5:14 And came to pass all the days of Cainan, ten years and nine hundred, and he died. 

#### Genesis 5:15 And Mahalaleel lived five and sixty and a hundred years, and he procreated Jared. 

#### Genesis 5:16 And Mahalaleel lived after his procreating Jared, {years thirty and seven hundred}, and he procreated sons and daughters. 

#### Genesis 5:17 And came to pass all the days of Mahalaleel {years five and ninety and eight hundred}, and he died. 

#### Genesis 5:18 And Jared lived two and sixty years and a hundred, and he procreated Enoch. 

#### Genesis 5:19 And Jared lived after his procreating Enoch, eight hundred years, and he procreated sons and daughters. 

#### Genesis 5:20 And came to pass all the days of Jared, two and sixty and nine hundred years, and he died. 

#### Genesis 5:21 And Enoch lived five and sixty and a hundred years, and he procreated Methuselah. 

#### Genesis 5:22 {was well-pleasing And Enoch} to God. And Enoch lived after his procreating Methuseleh, two hundred years, and he procreated sons and daughters. 

#### Genesis 5:23 And came to pass all the days of Enoch, five and sixty and three hundred years. 

#### Genesis 5:24 And Enoch was well-pleasing to God. And he was not found, for {transposed him God}. 

#### Genesis 5:25 And Methuselah lived seven and eighty and a hundred years, and he procreated Lamech. 

#### Genesis 5:26 And Methuselah lived after his procreating Lamech, two and eighty and seven hundred years, and he procreated sons and daughters. 

#### Genesis 5:27 And came to pass all the days of Methuselah which he lived, nine and sixty and nine hundred years, and he died. 

#### Genesis 5:28 And Lamech lived eight and eighty and a hundred years, and he procreated a son. 

#### Genesis 5:29 And he named his name, Noah, saying, This one will rest us from our works, and from the distresses of our hands, and from the earth of which {cursed the LORD God}. 

#### Genesis 5:30 And Lamech lived after his procreating Noah, five hundred and sixty and five years, and he procreated sons and daughters. 

#### Genesis 5:31 And came to pass all the days of Lamech, seven hundred and fifty three years, and he died. 

#### Genesis 5:32 And Noah was {years old five hundred} and he procreated three sons, Shem, Ham, and Japheth. 

#### Genesis 6:1 And it came to pass when {began men many} to become upon the earth, and daughters were born to them. 

#### Genesis 6:2 {were beholding And the sons of God} the daughters of men, that they are good, that they took to themselves women from all of whom they chose. 

#### Genesis 6:3 And {said the LORD God}, No way should {stay my spirit} with these men, on account of their being flesh; {will be and their days} a hundred twenty years. 

#### Genesis 6:4 And the giants were upon the earth in those days. And after that, {continually entered the sons of God} to the daughters of men, and procreated for themselves. Those were the giants, the ones from the eon, the {men renowned}. 

#### Genesis 6:5 {beholding And the LORD God} that {were multiplying the evils of men} upon the earth, and all that man considered in his heart was diligently upon the wicked things all the days, 

#### Genesis 6:6 and God pondered that he made the man upon the earth, and he considered it. 

#### Genesis 6:7 And {said God}, I will wipe away the man, whom I made, from the face of the earth; from man unto beast, and from the reptiles unto the winged creatures of the heaven; for I repented that I made them. 

#### Genesis 6:8 But Noah found favor before the LORD God. 

#### Genesis 6:9 And these are the origins of Noah. Noah {man was a just} being perfect in his generation; {to God was well-pleasing Noah}. 

#### Genesis 6:10 {procreated And Noah} three sons, Shem, Ham, Japheth. 

#### Genesis 6:11 {was corrupt But the earth} before God, and {was filled the earth} with iniquity. 

#### Genesis 6:12 And {beheld the LORD God} the earth, and it was being corrupted, for {corrupted all flesh} his way upon the earth. 

#### Genesis 6:13 And {said the LORD God} to Noah, Time for every man comes before me; for {is filled the earth} with iniquity by means of them. And behold, I lay them waste, and the earth. 

#### Genesis 6:14 Make then for yourself an ark from {wood four-cornered}! Nested compartments you shall make among the ark, and you shall apply asphalt to it -- from inside and from outside with the asphalt. 

#### Genesis 6:15 And so you shall make the ark -- three hundred cubits the length of the ark, and fifty cubits the width, and thirty cubits the height of it. 

#### Genesis 6:16 By an assembling, you shall make the ark; and by a cubit you shall complete it from above; but the door of the ark you shall make from out of the side. {with ground second stories and third stories You shall make it}. 

#### Genesis 6:17 And I, behold, I bring the flood of water upon the earth to lay waste all flesh in which is a breath of life underneath the heaven. And as much as might be upon the earth shall come to an end. 

#### Genesis 6:18 And I will establish my covenant with you. And you shall enter into the ark, you and your sons, and your wife, and the wives of your sons with you. 

#### Genesis 6:19 And from all the cattle, and from all the reptiles, and from all the wild beasts, and from all flesh, two by two from all you shall bring into the ark, that you may maintain them with yourself -- male and female they shall be. 

#### Genesis 6:20 From all the fowl according to type, and from all the cattle according to type, and from all the reptiles crawling upon the earth according to their type; two by two from all shall enter to you, to be maintained with you, male and female. 

#### Genesis 6:21 But you shall take to yourself from all of the foods which you shall eat, and you shall bring them together to yourself, and it shall be to you and to them to eat. 

#### Genesis 6:22 And Noah did all as much as {gave charge to him the LORD God} -- so he did. 

#### Genesis 7:1 And {said the LORD God} to Noah, Enter, you and all your house into the ark! for I beheld you as just before me among this generation. 

#### Genesis 7:2 And of the {cattle clean}, bring in for yourself seven by seven, male and female! but from the cattle of the ones not clean, two by two, male and female. 

#### Genesis 7:3 And from the winged creatures of the heaven, of the clean, seven by seven, male and female; and from all the winged creatures of the ones not clean, two by two, male and female, to maintain seed upon all the earth. 

#### Genesis 7:4 For yet {days seven} I will bring rain upon the earth forty days and forty nights. And I will wipe away every height which I made from the face of all the earth. 

#### Genesis 7:5 And Noah did all as much as {gave charge to him the LORD God}. 

#### Genesis 7:6 And Noah was {years old six hundred}, and the flood of the water came upon the earth. 

#### Genesis 7:7 {entered And Noah}, and his sons, and his wife, and the wives of his sons with him, into the ark, because of the water of the flood. 

#### Genesis 7:8 And from the winged creatures of the clean, and from the winged creatures of the ones not clean, and from the cattle of the ones clean, and from the cattle of the ones not clean, and from the wild beasts, and from all of the ones crawling upon the earth, 

#### Genesis 7:9 two by two they entered with Noah into the ark, male and female, as {gave charge to him God}. 

#### Genesis 7:10 And it came to pass after the seven days, and the water of the flood came upon the earth. 

#### Genesis 7:11 In the six hundredth year in the life of Noah, the second month, seventh and twentieth of the month, in this day, {tore all the springs of the abyss}, and the torrents of the heaven were opened. 

#### Genesis 7:12 And {was rain} upon the earth forty days and forty nights. 

#### Genesis 7:13 In this day entered Noah, Shem, Ham, Japheth, the sons of Noah, and the wife of Noah, and the three wives of his sons with him into the ark. 

#### Genesis 7:14 And all the wild beasts according to type, and all the cattle according to type, and every reptile moving upon the earth, according to type, and every winged creature according to type, 

#### Genesis 7:15 they entered with Noah, into the ark, two by two, male and female, from all flesh in which there is a breath of life. 

#### Genesis 7:16 And the ones entering, male and female, from all flesh, entered as God gave charge to Noah. And {locked the LORD God} the ark from outside of it. 

#### Genesis 7:17 And came to pass the flood forty days and forty nights. And {multiplied the water} and lifted up the ark, and raised it up high from the earth. 

#### Genesis 7:18 And {prevailed the water} and multiplied exceedingly upon the earth. And {was borne the ark} upon the water. 

#### Genesis 7:19 But the water prevailed exceedingly exceedingly upon the earth, and covered all the {mountains high} which were underneath the heaven. 

#### Genesis 7:20 Fifteen cubits above was {raised the water}, and it covered over all the {mountains high}. 

#### Genesis 7:21 And there died all flesh moving upon the earth of the winged creatures, and of the cattle, and from wild beasts, and every reptile moving upon the earth, and every man, 

#### Genesis 7:22 and all as much as have the breath of life, and all which was upon the dry land died. 

#### Genesis 7:23 And he wiped away every height which was upon the face of all the earth, from man unto beast, and reptiles, and the winged creatures of the heaven; and they were wiped away from the earth; and he left behind only Noah and the ones with him in the ark. 

#### Genesis 7:24 And {was raised up high the water} from the earth {days a hundred fifty}. 

#### Genesis 8:1 And God called to mind Noah, and all of the wild beasts, and all of the cattle, and all of the winged creatures, and all of the crawling things, as much as was with him in the ark. And God brought a wind upon the earth, and {abated the water}. 

#### Genesis 8:2 And were revealed the springs of the abyss and the torrents of the heaven. And {was constrained the rain} from the heaven. 

#### Genesis 8:3 And {gave way the water} going from the earth; and {was lessened the water} after fifty and a hundred days. 

#### Genesis 8:4 And {settled the ark} in the seventh month, the seventh and twentieth of the month, upon the mountains of Ararat. 

#### Genesis 8:5 And the water going forth lessened unto the tenth month. In the first of the month, {appeared the heads of the mountains}. 

#### Genesis 8:6 And it came to pass after forty days, Noah opened the window of the ark which he made. And he sent forth the crow to see if {abated the water}. 

#### Genesis 8:7 And going forth it returned not until the drying of the water from the earth. 

#### Genesis 8:8 And he sent the dove after it to see if {abated the water} from the earth. 

#### Genesis 8:9 And {no finding the dove} rest for her feet, returned to him into the ark, for water was upon all the face of the earth. And stretching out the hand, he took her to himself, and he brought her into the ark. 

#### Genesis 8:10 And waiting still {days seven another}, again he sent out the dove from the ark. 

#### Genesis 8:11 And {returned to him the dove}; and she had {leaf of an olive a twig} in her mouth; and Noah knew that {abated the water} from the earth. 

#### Genesis 8:12 And waiting still {days seven another}; again he sent out the dove; and she proceeded not to return to him again. 

#### Genesis 8:13 And it came to pass in the one and six hundredth year in the life of Noah, the first month, day one of the month, {subsided the water} from the earth. And Noah uncovered the roof of the ark which he made. And he beheld that {subsided the water} from the face of the earth. 

#### Genesis 8:14 And in the {month second}, seventh and twentieth of the month, {was dried the earth}. 

#### Genesis 8:15 And {said the LORD God} to Noah, saying, 

#### Genesis 8:16 Come forth from out of the ark, you and your wife, and your sons, and the wives of your sons with you! 

#### Genesis 8:17 And all flesh from winged creatures unto cattle, and every reptile moving upon the earth, lead out with yourself! And grow and multiply upon the earth! 

#### Genesis 8:18 And Noah came forth, and his wife, and his sons, and the wives of his sons with him. 

#### Genesis 8:19 And all the wild beasts, and all the cattle, and every winged creature, and every reptile moving upon the earth, according to their type, came forth from the ark. 

#### Genesis 8:20 And Noah built an altar to the LORD. And he took from all the {cattle clean}, and from all the {winged creatures clean}, and offered them for a whole burnt-offering upon the altar. 

#### Genesis 8:21 And the LORD smelled the scent of pleasant aroma. And {said the LORD God}, In considering, I will not add yet to curse the earth on account of the works of men, for {clings the thought of man} upon the wicked things from his youth. I will not add then still to strike all {flesh living} as I did. 

#### Genesis 8:22 All the days of the earth, seed and harvest, chilliness and sweltering heat, summer and spring, day and night, will not be caused to cease. 

#### Genesis 9:1 And God blessed Noah, and his sons, and said to them, Grow and multiply, and fill the earth, and dominate it! 

#### Genesis 9:2 And the fear of you and trembling will be upon all the wild beasts of the earth, upon all the winged creatures of the heaven, and upon all the things moving upon the earth, and upon all the fishes of the sea. Under your hands I have given them to you. 

#### Genesis 9:3 And every reptile which is living shall be to you for food; as {vegetation of grass I have given to you all}. 

#### Genesis 9:4 Except {meat with the blood of life you shall not eat}. 

#### Genesis 9:5 For even your blood -- of the blood of your lives at the hand of all the wild beasts I shall require it, and from the hand of a man's brother I shall require it. 

#### Genesis 9:6 The one shedding blood of a man, in return his blood shall be shed; for in the image of God I made the man. 

#### Genesis 9:7 But you grow, and multiply, and fill the earth, and multiply upon the earth! 

#### Genesis 9:8 And God said to Noah, and to his sons, saying, 

#### Genesis 9:9 Behold, I raise up my covenant to you, and to your seed after you, 

#### Genesis 9:10 and every {soul living} after you, from fowls and from cattle, and with all the wild beasts of the earth, as many as are with you, from all the ones coming forth from out of the ark. 

#### Genesis 9:11 And I will establish my covenant with you, and {will not die all flesh} any longer from the water of the flood; and there shall not be any longer a flood of water to lay waste all the earth. 

#### Genesis 9:12 And God said to Noah, This is the sign of the covenant which I execute between me and you, and between every {soul living}, as many as are with you for {generations eternal}. 

#### Genesis 9:13 {my bow I put} in the cloud, and it will be for a sign of covenant between me and the earth. 

#### Genesis 9:14 And it will be in my collecting together the clouds upon the earth, {will be seen the bow} in the cloud. 

#### Genesis 9:15 And I will remember my covenant which is between me and you, and between every {soul living} among all flesh. And there will not be any longer the water for a flood so as to wipe away all flesh. 

#### Genesis 9:16 And {will be my bow} in the cloud; and I will see it to remember {covenant the eternal} between me and the earth, and between {soul the living} which is in all flesh upon the earth. 

#### Genesis 9:17 And God said to Noah, This is the sign of the covenant of which I ordained between me and between all flesh which is upon the earth. 

#### Genesis 9:18 And these were the sons of Noah, the ones coming forth from the ark, Shem, Ham, Japheth. And Ham was father of Canaan. 

#### Genesis 9:19 These three are the sons of Noah. From these, men were disseminated upon all the earth. 

#### Genesis 9:20 And {began Noah the man} to be a farmer of the land. And he planted a vineyard, 

#### Genesis 9:21 and drank from the wine, and became intoxicated, and became naked in his house. 

#### Genesis 9:22 And {looked at Ham the father of Canaan} the nakedness of his father; and going forth, he announced it {two brothers to his} outside. 

#### Genesis 9:23 And {taking Shem and Japheth} the cloak, placed it upon {two backs their}, and went backwards, and they covered up the nakedness of their father; and their face was backwards, and {the nakedness of their father they did not look at}. 

#### Genesis 9:24 {sobered up And Noah} from the wine, and knew as much as {did to him son his younger}. 

#### Genesis 9:25 And he said, Accursed be Canaan -- a child, {a domestic servant he will be} to his brothers. 

#### Genesis 9:26 And he said, Blessed be the LORD God of Shem, and Canaan will be {servant domestic his}. 

#### Genesis 9:27 May God widen to Japheth, and let him dwell in the tents of Shem, and let Canaan become their servant. 

#### Genesis 9:28 {lived And Noah} after the flood three hundred fifty years. 

#### Genesis 9:29 And {were all the days of Noah} nine hundred fifty years, and he died. 

#### Genesis 10:1 And these are the generations of the sons of Noah -- Shem, Ham, Japheth. And were born to them sons after the flood. 

#### Genesis 10:2 The sons of Japheth -- Gomer, and Magog, and Madai, and Javan, and Tubal, and Meshech, and Tiras. 

#### Genesis 10:3 And the sons of Gomer -- Ashkenaz, and Riphath, and Togarmah. 

#### Genesis 10:4 And the sons of Javan -- Elisha, and Tarshish, Kittim, Dodanim. 

#### Genesis 10:5 From out of these were separated islands of the nations in their land, each according to tongue, among their tribes, and among their nations. 

#### Genesis 10:6 And the sons of Ham -- Cush, and Mizraim, Phut, and Canaan. 

#### Genesis 10:7 And the sons of Cush -- Seba and Havilah, and Sabtah, and Raamah, and Sabtechah. And the sons of Raamah - Sheba and Dedan. 

#### Genesis 10:8 And Cush procreated Nimrod. This one began to be a giant upon the earth. 

#### Genesis 10:9 This one was a giant hunter with hounds before the LORD God. On account of this they shall say, As Nimrod a giant hunter with hounds before the LORD. 

#### Genesis 10:10 And came to pass the beginning of his kingdom -- Babel, and Erech, and Accad, and Calneh, in the land of Shinar. 

#### Genesis 10:11 From out of that land came forth Assyria. And he built Nineveh, also in the midst of Calah -- 

#### Genesis 10:12 this is the {city great}. 

#### Genesis 10:13 And Mizraim procreated the Ludim, and the Naphtuhim, and the Anamim, and the Lehabim, 

#### Genesis 10:14 and the Pathrusim and the Casluhim, from where came forth the Philistines, and the Caphtorim. 

#### Genesis 10:15 And Canaan procreated Sidon the first-born, 

#### Genesis 10:16 and the Hittite, and the Jebusite, and the Amorite, and the Girgasite, and the Hivite, and the Arkite, 

#### Genesis 10:17 and the Sinite, 

#### Genesis 10:18 the Arvadite, and the Zemarite, and the Hamathite, and after these were scattered the tribes of the Canaanites. 

#### Genesis 10:19 And {were the boundaries of the Canaanites} from Sidon unto the coming into Gerar and Gaza, unto the coming unto Sodom and Gomorrah, Admah and Zeboim, unto Lasha. 

#### Genesis 10:20 These are the sons of Ham among their tribes, according to their languages, among their regions, and among their nations. 

#### Genesis 10:21 And to Shem was born, even to him, the father of all the sons of Eber, brother of Japheth the greater. 

#### Genesis 10:22 Sons of Shem -- Elam, and Asshur, and Arphaxad, and Lud, and Aram, and Cainan. 

#### Genesis 10:23 And the sons of Aram -- Uz, and Hul, and Gether, and Mash. 

#### Genesis 10:24 And Arphaxad procreated Cainan; and Cainan procreated Salah; and Salah procreated Eber. 

#### Genesis 10:25 And to Eber were born two sons, the name given to the one was Peleg; for in his days {was divided into parts the earth}; and the name of his brother was Joktan. 

#### Genesis 10:26 And Joktan procreated Almodad, and Sheleph, and Hazarmaveth, and Jerah 

#### Genesis 10:27 and Hadoram, and Uzal, and Diklah, 

#### Genesis 10:28 and Obal and Abimael Sheba, 

#### Genesis 10:29 and Ophir, and Havilah, and Jobab. All these were sons of Joktan. 

#### Genesis 10:30 And {was their dwelling} from Mesha unto the coming into Sephar, a mountain of the east. 

#### Genesis 10:31 These are the sons of Shem among their tribes, according to their languages, among their regions, and among their nations. 

#### Genesis 10:32 These are the tribes of the sons of Noah, according to their generations, according to their nations. From these were scattered islands of the nations upon the earth after the flood. 

#### Genesis 11:1 And {was all the earth lip one}, and {voice one} to all. 

#### Genesis 11:2 And it came to pass in their moving from the east, they found a plain in the land of Shinar, and they dwelt there. 

#### Genesis 11:3 And {said a man} to his neighbor, Come let us make bricks, and let us bake them in fire. And {became to them the brick} as stone, and asphalt was their mortar. 

#### Genesis 11:4 And they said, Come let us build to ourselves a city and tower of which the top will be unto the heaven. And let us make to ourselves a name before the being scattered upon the face of all the earth. 

#### Genesis 11:5 And the LORD went down to look at the city and the tower, which {built the sons of men}. 

#### Genesis 11:6 And the LORD said, Behold, there is {kind one} and {lip one} for all, and this they began to do. The things now shall not fail from them, all as much as they might attempt to do. 

#### Genesis 11:7 Come, and going down, let us confound their language, that they should not {hearken to each} the voice of the neighbor. 

#### Genesis 11:8 And the LORD scattered them from there upon the face of all the earth; and they ceased building the city and the tower. 

#### Genesis 11:9 On account of this {was called the name of it} Confusion, because there the LORD confounded the lips of all the earth, and from there {scattered them the LORD} upon the face of all the earth. 

#### Genesis 11:10 And these are the generations of Shem. And Shem was a hundred years old when he procreated Arphaxad, the second year after the flood. 

#### Genesis 11:11 And Shem lived after his procreating Arphaxad, five and thirty and three-hundred years, and he procreated sons and daughters, and he died. 

#### Genesis 11:12 And Arphaxad lived a hundred thirty five years, and he procreated Cainan. 

#### Genesis 11:13 And Arphaxad lived after his procreating Cainan, {years three hundred thirty}, and he procreated sons and daughters, and he died. And Cainan lived a hundred and thirty years, and he procreated Salah. And Cainan lived after his procreating Salah, {years three hundred thirty}, and he procreated sons and daughters, and he died. 

#### Genesis 11:14 And Salah lived a hundred thirty years, and he procreated Eber. 

#### Genesis 11:15 And Salah lived after his procreating Eber, three hundred thirty years, and he procreated sons and daughters, and he died. 

#### Genesis 11:16 And Eber lived a hundred thirty four years, and he procreated Peleg. 

#### Genesis 11:17 And Eber lived after his procreating Peleg, {years three hundred seventy}, and he procreated sons and daughters, and he died. 

#### Genesis 11:18 And Peleg lived thirty and a hundred years, and he procreated Reu. 

#### Genesis 11:19 And Peleg lived after his procreating Reu, nine and two hundred years, and he procreated sons and daughters, and he died. 

#### Genesis 11:20 And Reu lived a hundred thirty and two years. and he procreated Serug. 

#### Genesis 11:21 And Reu lived after his procreating Serug two hundred seven years, and he procreated sons and daughters, and he died. 

#### Genesis 11:22 And Serug lived a hundred thirty years, and he procreated Nahor. 

#### Genesis 11:23 And Serug lived after his procreating Nahor, {years two hundred}, and he procreated sons and daughters, and he died. 

#### Genesis 11:24 And Nahor lived {years seventy nine}, and he procreated Terah. 

#### Genesis 11:25 And Nahor lived after his procreating Terah, {years a hundred twenty-nine}, and he procreated sons and daughters, and he died. 

#### Genesis 11:26 And Terah lived seventy years and he procreated Abram and Nahor and Haran. 

#### Genesis 11:27 And these are the generations of Terah. Terah procreated Abram, and Nahor, and Haran. And Haran procreated Lot. 

#### Genesis 11:28 And Haran died in the presence of Terah his father, in the land in which he was procreated, in the region of the Chaldeans. 

#### Genesis 11:29 And {took Abram and Nahor} to themselves wives. The name of the wife of Abram was Sarai, and the name of the wife of Nahor was Milcha, daughter of Haran. And he was the father of Milcha, and father of Iscah. 

#### Genesis 11:30 And Sarai was sterile, and not able to produce children. 

#### Genesis 11:31 And Terah took Abram his son, and Lot the son of Haran, the son of his son, and Sarai his daughter-in-law, the wife of Abram his son. And he led them from out of the region of the Chaldeans to go into the land of Canaan. And they came unto Haran and dwelt there. 

#### Genesis 11:32 And were the days of Terah in Haran, two hundred five years; and Terah died in Haran. 

#### Genesis 12:1 And the LORD said to Abram, Come forth from out of your land, and from your kin, and from the house of your father, and come into the land which ever I shall show to you. 

#### Genesis 12:2 And I will make you into {nation a great}, and I will bless you, and I will magnify your name, and you will be a blessing. 

#### Genesis 12:3 And I will bless the ones blessing you; and the ones cursing you, I will curse. And {will be blessed by you all the tribes of the earth}. 

#### Genesis 12:4 And Abram went just as {spoke to him the LORD}. And {set out with him Lot}. And Abram was {years old seventy-five} when he came forth from out of Haran. 

#### Genesis 12:5 And Abram took Sarai his wife, and Lot the son of his brother, and all their possessions, as much as they acquired, and every soul which they acquired from out of Haran. And they went forth to go into the land of Canaan. And they entered into the land of Canaan. 

#### Genesis 12:6 And Abram traveled through the land unto the place of Shechem unto the {oak high}. And the Canaanites then dwelt the land. 

#### Genesis 12:7 And the LORD appeared to Abram, and said to him, {to your seed I will give this land}. And {built there Abram} an altar to the LORD, to the one appearing to him. 

#### Genesis 12:8 And he left from there into the mountain according to the east of Beth-el. And he set up there his tent in Beth-el according to the west, and Hai according to the east. And he built there an altar to the LORD, and he called upon the name of the LORD. 

#### Genesis 12:9 And Abram departed; and going he encamped in the wilderness. 

#### Genesis 12:10 And there was a famine upon the land. And Abram went down into Egypt to sojourn there, for {grew in strength the famine} upon the land. 

#### Genesis 12:11 And it was when Abram approached to enter into Egypt, Abram said to Sarai his wife, I know that {woman a good-looking you are}. 

#### Genesis 12:12 It will be then as when {shall see you the Egyptians} they will say that his wife is this one, and they will kill me, {you and procure}. 

#### Genesis 12:13 Say then that! {his sister I am}. so that {good to me it may become} on account of you, and {shall live my soul} because of you. 

#### Genesis 12:14 And it came to pass when Abram entered into Egypt, {were looking at the Egyptians} his wife, for {beautiful she was exceedingly}. 

#### Genesis 12:15 And {beheld her the rulers of Pharaoh}, and praised her to Pharaoh; and they brought her into the house to Pharaoh. 

#### Genesis 12:16 And {Abram well they treated} on account of her, and there existed to him sheep, and calves, and donkeys, and manservants, and maidservants, and mules and camels. 

#### Genesis 12:17 And the LORD chastised Pharaoh {chastisements with great and severe}, and his house, on account of Sarai the wife of Abram. 

#### Genesis 12:18 {calling And Pharaoh} Abram, said, What is this you did to me, that you reported not to me that {wife she is your}? 

#### Genesis 12:19 Why did you say that, {my sister She is}; and I took her to myself as wife? And now, behold, your wife is before you -- taking her run from me! 

#### Genesis 12:20 And Pharaoh charged the men concerning Abram, to escort him out, and his wife, and all, as much as was his, and Lot with him. 

#### Genesis 13:1 {ascended And Abram} from out of Egypt, he, and his wife, and all of his, and Lot with him, into the wilderness. 

#### Genesis 13:2 And Abram was {rich exceedingly} in cattle, and silver, and gold. 

#### Genesis 13:3 And he went from where he came into the wilderness, unto Beth-el, unto the place where {was his tent formerly}, between Beth-el and between Hai; 

#### Genesis 13:4 unto the place of the altar which he made there at the beginning. And {called upon there Abram the name of the LORD}. 

#### Genesis 13:5 And to Lot, the one going forth with Abram, was sheep, and oxen, and cattle. 

#### Genesis 13:6 And {did not have space for them the land} to dwell together, for {were their possessions} many, and they were not able to dwell together. 

#### Genesis 13:7 And there was a battle between the herdsmen of the cattle of Abram, and between the herdsmen of the cattle of Lot. And the Canaanites and the Perizzites then inhabited the land. 

#### Genesis 13:8 {said And Abram} to Lot, Do not let there be a battle between me and you, and between your herdsmen and between my herdsmen! for {men brothers are we}. 

#### Genesis 13:9 {not Behold all the earth before you is}? Part yourself from me! If you go to the left, I will go to the right; but if you go to the right, I will go to the left. 

#### Genesis 13:10 And Lot, lifting up his eyes, looked upon all the place round about the Jordan, that all was watered (before the eradicating by God of Sodom and Gomorrah) as the paradise of God, and as the land of Egypt unto coming into Zoar. 

#### Genesis 13:11 And Lot chose to himself all the place round about the Jordan. And Lot departed from the east. And they were parted, each from his brother. 

#### Genesis 13:12 And Abram dwelt in the land of Canaan, and Lot dwelt in a city of the place round about, and he pitched a tent in Sodom. 

#### Genesis 13:13 But the men in Sodom were wicked and sinners before God, exceedingly. 

#### Genesis 13:14 And God said to Abram, after Lot parted from him, Look up with your eyes, and behold from the place which {now you are}, to the north and south, and east, and west! 

#### Genesis 13:15 That all the land which you see, {to you I will give it}, and to your seed, unto the eon. 

#### Genesis 13:16 And I will make your seed as the sand of the earth. If {is able anyone} to count out the sand of the earth, then {your seed they shall count out}. 

#### Genesis 13:17 In rising up, you travel through the land unto both the length of it and unto the width; for to you I shall give it, and to your seed, into the eon. 

#### Genesis 13:18 And moving his tent, Abram came and dwelt around the oak of Mamre, which was in Hebron. And he built there an altar to the LORD. 

#### Genesis 14:1 And it came to pass in the kingdom of Amraphel king of Shinar, and Arioch king of Ellasar, and Chedorlaomer king of Elam, and Tidal king of nations, 

#### Genesis 14:2 they made war with Bera king of Sodom, and with Birsha king of Gomorrah, and with Shinab king of Admah, and Shemeber king of Zeboiim, and king Bela -- this is Zoar. 

#### Genesis 14:3 All these joined in harmony upon the {ravine salty}, this being the sea of salts. 

#### Genesis 14:4 Twelve years they slaved to Chedorlaomer, but in the thirteenth year they revolted. 

#### Genesis 14:5 And in the fourteenth year Chedorlaomer came and the kings with him. And they cut in pieces the giants, of the ones in Astaroth Karnaim, and {nations the strong} together with them, and the Emim in Shaveh the city, 

#### Genesis 14:6 and the Horites, the ones in the mountains of Seir, unto the terebinth tree of El-paran, which is in the wilderness. 

#### Genesis 14:7 And returning, they came upon the Spring of Judgment, this is Kadesh. And they cut in pieces all the rulers of Amalek, and the Amorites, of the ones dwelling in Hazezon-tamar. 

#### Genesis 14:8 And came forth the king of Sodom, and the king of Gomorrah, and the king of Admah, and the king of Zeboiim, and the king of Bela -- this is Zoar. And they deployed themselves for war in the {valley salty} 

#### Genesis 14:9 against Chedorlaomer king of Elam, and Tidal king of nations, and Amraphel king of Shinar, and Arioch king of Ellasar -- the four kings against the five. 

#### Genesis 14:10 And the {valley salty} had wells of asphalt, {fled and the king of Sodom}, and the king of Gomorrah, and they fell in there; and the ones being left behind fled into the mountainous area. 

#### Genesis 14:11 And they took {the cavalry all} of Sodom and Gomorrah, and all their foods, and they went forth. 

#### Genesis 14:12 And they took also Lot, the son of the brother of Abram, and his belongings, and moved -- for he was dwelling in Sodom. 

#### Genesis 14:13 {coming And of the ones being rescued a certain person}, reported to Abram, to the traveler. And he dwelt at the oak of Mamre the Amorite of the brother of Eshcol, and the brother of Aner, who were confederates of Abram. 

#### Genesis 14:14 {having heard And Abram} that {has been captured Lot the son of his brother}, counted out {own native-born servants his}, three hundred ten and eight. And he pursued unto Dan. 

#### Genesis 14:15 And he fell upon them at night, he and his manservants. And he struck them, and pursued them unto Hobah, which is at the left of Damascus. 

#### Genesis 14:16 And he returned all the cavalry of Sodom; and {Lot the son of his brother he returned}, and all his possessions, and the women, and the people. 

#### Genesis 14:17 {came forth And the king of Sodom} to meet him, after his returning from the slaughter of Chedorlaomer, and the kings with him, into the valley of Shaveh -- this was the plain of the king. 

#### Genesis 14:18 And Melchizedek king of Salem brought forth bread loaves and wine. And he was priest of God the highest. 

#### Genesis 14:19 And he blessed him. And he said, Abram, a blessing to God the highest, who created the heaven and the earth. 

#### Genesis 14:20 And blessed be God the highest who delivered up your enemies under your hands to you. And {gave to him Abram} a tenth from all. 

#### Genesis 14:21 And said the king of Sodom to Abram, Give to me the men, but the cavalry you take to yourself! 

#### Genesis 14:22 {said And Abram} to the king of Sodom, I will stretch out my hand to the LORD God the highest, who created the heaven and the earth, 

#### Genesis 14:23 that not {from the string unto the knob of the shoe will I take for myself} from all of your things, that you should not have said that, I enriched Abram; 

#### Genesis 14:24 except what {ate the young men} and the portion of the men, of the ones going with me, Eshcol, Aner, Mamre; these will take for themselves a portion. 

#### Genesis 15:1 And after these words came the word of the LORD to Abram in a vision, saying, Do not fear Abram, I will shield you. Your wage {much will be exceedingly}. 

#### Genesis 15:2 {says And Abram}, Master, O LORD, what will you give to me, for I am wasting away childless, but the son of Masek of my native-born maid servant, this Damascus Eliezer is heir? 

#### Genesis 15:3 And Abram said, Since to me you gave not a seed, then my native-born servant will be heir to me. 

#### Genesis 15:4 And straightly the voice of the LORD came to him, saying, {will not be heir to you This one}, another will come forth from you, this one will be heir to you. 

#### Genesis 15:5 And he led him outside, and said to him, Look up indeed into the heaven, and count out the stars, if you are able to count them! And he said, Thus will be your seed. 

#### Genesis 15:6 And Abram trusted in God, and it was imputed to him for righteousness. 

#### Genesis 15:7 And he said to him, I am the God leading you from out of the place of the Chaldeans, so as to give to you this land to inherit. 

#### Genesis 15:8 And he said, Master, O LORD, how will I know that I will inherit it? 

#### Genesis 15:9 And he said to him, Take for me a heifer being three years old, and a goat being three years old, and a ram being three years old, and a turtle-dove, and a pigeon! 

#### Genesis 15:10 And he took to himself all these, and he divided them in the middle, and put them facing one another; but the birds he did not divide. 

#### Genesis 15:11 {came down And birds} upon the {bodies pieces of their}, and {sat down with them Abram}. 

#### Genesis 15:12 And about {of the sun the descent} a change of state fell upon Abram. And behold, {fear dark a great} fell upon him. 

#### Genesis 15:13 And it was said to Abram, In knowing you will know that {a sojourner will be your seed} in a land not their own, and they will enslave them, and will afflict them, and humble them four hundred years. 

#### Genesis 15:14 But the nation which ever they may be slave to, I will judge. And after these things they shall come forth here with {belongings much}. 

#### Genesis 15:15 But you shall go forth to your fathers with peace, being entombed in {old age a good}. 

#### Genesis 15:16 And the fourth generation shall return here, for not yet have {been filled up the sins of the Amorites} unto the present. 

#### Genesis 15:17 And when the sun was in descent, a flame came, and behold, there was an oven smoking; and there were lamps of fire which went through in the midst of these pieces. 

#### Genesis 15:18 In that day the LORD ordained a covenant with Abram, saying, To your seed I will give this land, from the river of Egypt unto the river of the great Euphrates, 

#### Genesis 15:19 the Kenites, and the Kenizites, and the Kadmonites, 

#### Genesis 15:20 and the Hittites, and the Perizzites, and the Raphaim, 

#### Genesis 15:21 and the Amorites, and the Canaanites, and the Girgashites, and the Jebusites. 

#### Genesis 16:1 And Sarai, the wife of Abram, bore not to him. But there was to her a maidservant, an Egyptian, whose name was Hagar. 

#### Genesis 16:2 {said And Sarai} to Abram, Behold, {closed me up the LORD} to not bear. Enter then to my maidservant, that I may produce children from her! {obeyed And Abram} the voice of Sarai. 

#### Genesis 16:3 And {having taken the wife of Abram} Hagar the Egyptian her maidservant, after ten years of living with Abram in the land of Canaan, and she gave her to Abram her husband to him for wife. 

#### Genesis 16:4 And he entered to Hagar, and she conceived. And she saw that {in the womb she had a child}, and {was dishonored the lady} before her. 

#### Genesis 16:5 {said And Sarai} to Abram, I am being wronged because of you. I gave my maidservant to your bosom. And seeing that {a child in the womb she had} I was dishonored before her. May God judge between me and you. 

#### Genesis 16:6 {said And Abram} to Sarai, Behold, your maidservant is in your hands, treat her however {pleasing to you might be}. And {maltreated her Sarai}, and she ran away from her face. 

#### Genesis 16:7 {found And her the angel of the LORD} upon the spring of water in the wilderness, upon the land in the way of Shur. 

#### Genesis 16:8 And {said to her the angel of the LORD}, Hagar, maidservant of Sarai, from what place do you come, and where do you go? And she said, {from the face of Sarai my lady I am running away}. 

#### Genesis 16:9 {said And to her the angel of the LORD}, You return to your lady, and be humble under her hands! 

#### Genesis 16:10 And {said to her the angel of the LORD}, In multiplying I will multiply your seed, and it shall not be counted because of the multitude. 

#### Genesis 16:11 And {said to her the angel of the LORD}, Behold, you {in the womb have a child}, and you shall bear a son, and you shall call his name, Ishmael, for the LORD heeded your humiliation. 

#### Genesis 16:12 This one will be a rugged man; his hands will be upon all, and the hands of all upon him. And {before the face of all his brothers he will dwell}. 

#### Genesis 16:13 And she called the name of the LORD, the one speaking to her, You, the God, the one looking upon me; for she said, For even face to face I beheld the one appearing to me. 

#### Genesis 16:14 Because of this she called the well, Well of which {Face to Face I Beheld}. Behold, it is between Kadesh and between Bared. 

#### Genesis 16:15 And Hagar bore to Abram a son. And Abram called the name of his son, whom {bore to him Hagar}, Ishmael. 

#### Genesis 16:16 And Abram was {years old eighty-six} when Hagar bore to Abram, Ishmael. 

#### Genesis 17:1 {was And Abram years old ninety-nine}, and the LORD appeared to Abram, and he said to him, I am your God, you are well-pleasing before me -- then be blameless! 

#### Genesis 17:2 And I will establish my covenant between me and between you, and I will multiply you exceedingly. 

#### Genesis 17:3 And Abram fell upon his face. And {spoke to him God}, saying, 

#### Genesis 17:4 And behold, my covenant is with you, and you will be father of a multitude of nations. 

#### Genesis 17:5 And {will not be called any longer your name}, Abram; but {will be your name} Abraham, for {father of many nations I have appointed you}. 

#### Genesis 17:6 And I will increase you exceedingly exceedingly. And I will establish you for nations; and kings {from you will come forth}. 

#### Genesis 17:7 And I will establish my covenant between me and between you, and between your seed after you, unto their generations, for {covenant an eternal}, to be your God, and with your seed after you. 

#### Genesis 17:8 And I will give to you and to your seed after you the land which you sojourn, all the land of Canaan for {possession an eternal}. And I myself will be to them for God. 

#### Genesis 17:9 And God said to Abraham, You also {my covenant shall observe}, and your seed after you for their generations. 

#### Genesis 17:10 And this is the covenant which you shall observe between me and you, and between your seed after you. {shall be circumcised to you Every male}. 

#### Genesis 17:11 And you shall be circumcised of the flesh of your foreskin. And it will be for a sign of covenant between me and you. 

#### Genesis 17:12 And a male child eight days old shall be circumcised by you -- every male into your generations; the native-born servant of your house, and the one bought with silver, from every son of an alien who is not from your seed. 

#### Genesis 17:13 By circumcision he shall be circumcised -- the native-born servant of your house, and the one bought with silver. And {will be my covenant} upon your flesh for {covenant an eternal}. 

#### Genesis 17:14 And the uncircumcised male who shall not be circumcised in the flesh of his foreskin in the {day eighth}, {shall be utterly destroyed that soul} from its race, for my covenant he effaced. 

#### Genesis 17:15 And God said to Abraham, Sarai your wife -- {shall not be called her name} Sarai, but, Sarah will be her name. 

#### Genesis 17:16 And I will bless her, and give to you from her a child. And I will bless it, and it will be for nations; and kings of nations {from him will be}. 

#### Genesis 17:17 And Abraham fell upon his face and laughed. And he said in his mind, saying, Shall to the hundred year old be a son? And shall Sarah at ninety years bear? 

#### Genesis 17:18 {said And Abraham} to God, Ishmael, this one, let him live before you! 

#### Genesis 17:19 {said And God} to Abraham, Yes, behold, Sarah your wife will bear to you a son, and you shall call his name Isaac; and I will establish my covenant with him, for {covenant an eternal}, and to his seed after him. 

#### Genesis 17:20 And concerning Ishmael, behold, I heeded you. And behold, I shall bless him, and I will increase him, and I will multiply him exceedingly. Twelve nations he will procreate, and I will make him for {nation a great}. 

#### Genesis 17:21 But my covenant I will establish with Isaac, whom {shall bear to you Sarah} at this time in {year another}. 

#### Genesis 17:22 And he completed speaking to him. And God ascended from Abraham. 

#### Genesis 17:23 And Abraham took Ishmael, his son, and all his native-born servants, and all the ones bought with silver, and every male of the men in the house of Abraham. And he circumcised their foreskins in {time of the day that}, as {spoke to him God}. 

#### Genesis 17:24 And Abraham {ninety-nine was} years old when he circumcised the flesh of his foreskin. 

#### Genesis 17:25 And Ishmael his son was {years old thirteen} when he circumcised the flesh of his foreskin. 

#### Genesis 17:26 In {time of the day that} Abraham was circumcised, and Ishmael his son, 

#### Genesis 17:27 and all the males of his house, and the native-born servants, and the ones bought with silver from foreign nations. 

#### Genesis 18:1 {appeared And to him God} before the oak in Mamre, at his sitting near the door of his tent at midday. 

#### Genesis 18:2 And lifting up his eyes he saw; and behold, three men had set upon him. And seeing, he ran up to meet with them from the door of his tent. And he did obeisance upon the ground. 

#### Genesis 18:3 And he said, O Lord, if surely I found favor before you, you should not go by your servant. 

#### Genesis 18:4 Let there be taken now water, and let them wash your feet, and be cooled under the tree! 

#### Genesis 18:5 And I will bring bread, and you shall eat, and after this you shall go in your journey, because of which you turned aside to your servant. And they said, Thus do as you have said! 

#### Genesis 18:6 And Abraham hastened unto the tent to Sarah. And he said to her, Hasten and mix up three measures of fine flour, and make a cake baked in hot ashes! 

#### Genesis 18:7 And {to the oxen Abraham ran}, and he took a tender {young calf and good}, and gave it to the servant; and he hastened to prepare it. 

#### Genesis 18:8 And he took butter, and milk, and the young calf which he prepared, and placed it near to them, and they ate. And he stood beside them under the tree. 

#### Genesis 18:9 And he said to him, Where is Sarah your wife? And answering he said, Behold, in the tent. 

#### Genesis 18:10 And he said, Returning, I will come to you according to this time to the hour; and {will have a son Sarah your wife}. And Sarah heard by the door of the tent, being behind him. 

#### Genesis 18:11 And Abraham and Sarah were older, advanced of days, {ceased and Sarah} to be in the feminine ways. 

#### Genesis 18:12 {laughed And Sarah} in herself, saying, For not yet has it happened to me until now, and my lord is older. 

#### Genesis 18:13 And the LORD said to Abraham, Why is it that Sarah laughed in herself, saying, Indeed is it truly I will bear, and I have grown old? 

#### Genesis 18:14 Is {impossible to the LORD the saying}? At this time to the hour I will return to you, and there will be to Sarah a son. 

#### Genesis 18:15 {denied But Sarah}, saying, I did not laugh; for she feared. And he said to her, No, but you laughed! 

#### Genesis 18:16 And having risen up from there, the men looked down upon the face of Sodom and Gomorrah. And Abraham went with them, escorting them. 

#### Genesis 18:17 And the LORD said, No way shall I hide from Abraham my servant what I do. 

#### Genesis 18:18 {to Abraham But coming to pass}, he will be made into {nation a great and populous}, and {shall be blessed by him all the nations of the earth}. 

#### Genesis 18:19 For I had known that he will order his sons, and his house after him; and they will guard the ways of the LORD, to do righteousness and judgment; that the LORD may bring upon Abraham all as much as he said to him. 

#### Genesis 18:20 {said And the LORD}, The cry of Sodom and Gomorrah has multiplied towards me, and their sins are great, exceedingly. 

#### Genesis 18:21 Going down then, I will see if it is according to their cry, the cry coming to me that they exhaust; and if not, that I may know. 

#### Genesis 18:22 And turning back from there, the men came unto Sodom. And Abraham was still standing before the LORD. 

#### Genesis 18:23 And Abraham approaching, said, You would not destroy together the just with the impious, and {will be the just} as the impious? 

#### Genesis 18:24 If there might be fifty just in the city, will you destroy them? Will you not spare all the place because of the fifty just, if there should be so in it? 

#### Genesis 18:25 By no means shall you do as this saying, to kill the just with the impious, and {shall be the just} as the impious; by no means, O one judging all the earth. Will you not execute judgment? 

#### Genesis 18:26 {said And the LORD}, If there should be in Sodom fifty just in the city, I will leave off doing so to all the place on account of them. 

#### Genesis 18:27 And Abraham responding said, Now that I began to speak to my Lord, and I am earth and ashes. 

#### Genesis 18:28 But if {may be lessened the fifty just} to forty-five, will you destroy because of the five, all the city? And he said, No way will I destroy if I find there forty-five. 

#### Genesis 18:29 And he added yet to speak to him. And he said, But if there may be found there forty? And he said, No way should I destroy because of the forty. 

#### Genesis 18:30 And he said, Much less, O Lord, if I may speak, but if there may be found there thirty? And he said, No way will I destroy because of the thirty. 

#### Genesis 18:31 And he said, Since I have taken to speak to the Lord, but if there may be found there twenty? And he said, No way will I destroy if I should find there twenty. 

#### Genesis 18:32 And he said, Much less, O Lord, if I may speak still once more, but if there may be found there ten? And he said, No way will I destroy because of the ten. 

#### Genesis 18:33 {went forth And the LORD} as he ceased speaking to Abraham, and Abraham returned to his place. 

#### Genesis 19:1 {came And the two angels} into Sodom at evening. And Lot settled by the city of Sodom. And seeing, Lot rose up to meet them, and did obeisance with his face upon the ground. 

#### Genesis 19:2 And he said, Behold lords, turn aside to the house of your servant, and rest up, and wash your feet! that rising early you may go forth into your way. And they said, No, but in the square we will rest up. 

#### Genesis 19:3 And he constrained them, and they turned aside towards him, and entered unto his house. And he made for them a banquet, and {unleavened breads he baked} for them, and they ate. 

#### Genesis 19:4 Before putting to bed, the men of the city, the Sodomites, surrounded the house, from the young man unto the older, all the people together. 

#### Genesis 19:5 And they called forth Lot. And they said to him, Where are they, the men, the ones entering to you this night? Lead them to us, that we may be intimate with them! 

#### Genesis 19:6 {came forth And Lot} to them, to the threshold, {the and door he shut} behind him. 

#### Genesis 19:7 And he said to them, By no means, brethren, should you do wickedly. 

#### Genesis 19:8 But there are to me two daughters who knew not a man. I will lead them to you, and you treat them as pleases you! Only to these men you should not do unjust, because they entered under the protection of my beams. 

#### Genesis 19:9 And they said to him, You left there to enter here to sojourn, and not {with judgment to judge}. Now then to you we will inflict evil rather than them. And they were pressing the man Lot exceedingly, and they approached to break the door. 

#### Genesis 19:10 {stretching out And the men} the hands, drew Lot towards themselves into the house, and the door of the house they locked. 

#### Genesis 19:11 And the men being at the door of the house were struck with inability to see, from small unto great, and they were disabled in seeking the door. 

#### Genesis 19:12 {said And the men} to Lot, Are there {to you here in-laws}, or sons or daughters? Or if {any to you other there is} in the city you lead them out of this place! 

#### Genesis 19:13 For we destroy this place. For {was raised up high their cry} before the LORD, and {sent us the LORD} to obliterate it. 

#### Genesis 19:14 {went forth And Lot} and spoke to his sons-in-law, the ones taking his daughters. And he said, Rise up, and come forth from out of this place, for the LORD is obliterating the city. {he seemed But to be joking before his sons-in-law}. 

#### Genesis 19:15 And when dawn came {hurried the angels} Lot, saying, In rising up, take your wife and {two daughters your} whom you have, and come forth! that {not also you should} be destroyed together in the lawlessnesses of the city. 

#### Genesis 19:16 And they were disturbed, and {held the angels} his hand, and the hand of his wife, and the hands {two daughters of his}, in the LORD sparing him. 

#### Genesis 19:17 And it came to pass when they led them outside, and said, By escaping escape with your own life! You should not look round about to the rear, nor stand in any round about place. {into the mountain Escape}! lest at any time you may be taken along with them. 

#### Genesis 19:18 {said And Lot} to them, I beseech, O lord, 

#### Genesis 19:19 since {found your servant} favor before you, and you magnified your righteousness, which you do unto me, that {may live my soul}, but I will not be able to come through safe into the mountain, lest {overtake me evils} and I die. 

#### Genesis 19:20 Behold, this city is near for me to take refuge there, which is small, there I will be delivered. {not a small thing Is it} that {will live my soul} because of you? 

#### Genesis 19:21 And he said to him, Behold, I admired your countenance over this saying, that I should not eradicate the city, concerning of which you spoke. 

#### Genesis 19:22 You hasten then to escape there, {not for I will} be able to do the thing until you go there! On account of this he called the name of that city, Zoar. 

#### Genesis 19:23 The sun came up upon the earth, and Lot entered into Zoar. 

#### Genesis 19:24 And the LORD rained upon Sodom and Gomorrah sulphur and fire from the LORD from out of heaven. 

#### Genesis 19:25 And he eradicated these cities, and all the place round about, and all the ones dwelling in the cities, and the things rising from out of the ground. 

#### Genesis 19:26 And {looked his wife} unto the rear, and she became a monument of salt. 

#### Genesis 19:27 {rose early And Abraham} in the morning to the place of which he had stood before the LORD. 

#### Genesis 19:28 And he looked upon the face of Sodom and Gomorrah, and upon the face of the place round about. And he saw. And behold, {ascended a flame} from out of the earth, as vapor of a furnace. 

#### Genesis 19:29 And it came to pass in God obliterating all the {cities adjacent}, God remembered Abraham, and he sent out Lot from the middle of the final event, in the eradicating the cities in which {dwelt in them Lot}. 

#### Genesis 19:30 {came forth And Lot} from out of Zoar, and settled in the mountain, and the two daughters of his with him; for he feared dwelling in Zoar. And he dwelt in the cave, he and the two daughters of his with him. 

#### Genesis 19:31 {said And the elder} to the younger, Our father is older, and there is no one upon the land who will enter to us, as it is fit in all the earth. 

#### Genesis 19:32 Come and we should give {to drink our father wine}, and we should go to bed with him, that we might raise up {from our father seed}. 

#### Genesis 19:33 And they gave {to drink their father wine} in that night. And entering, the elder went to bed with her father in that night, and he did not know about her going to bed and rising up. 

#### Genesis 19:34 And it came to pass in the next day, and {said the elder} to the younger, Behold, I went to bed yesterday with our father. We should give {to drink him wine} also in this night, and entering, you go to bed with him! that we might raise up {from our father seed}. 

#### Genesis 19:35 And they gave to drink also in that night {for their father wine}. And entering, the younger went to bed with her father. And he did not know about her going to bed and rising up. 

#### Genesis 19:36 And {conceived the two daughters of Lot} from their father. 

#### Genesis 19:37 And {bore the elder} a son, and she called his name Moab, saying, He is from my father. This one is father of the Moabites, unto today's day. 

#### Genesis 19:38 {bore And also the younger} a son, and she called his name Ammon, he is a son of my family. This one is father of the Ammonites until today's day. 

#### Genesis 20:1 And {moved from there Abraham} into the land towards the south, and lived between Kadesh and between Shur, and sojourned in Gerar. 

#### Genesis 20:2 {said And Abraham} concerning Sarah his wife, that, {my sister She is}. For he feared to say that, {my wife She is}, lest at any time {should kill him the men of the city} on account of her. {sent So Abimelech king of Gerar}, and he took Sarah. 

#### Genesis 20:3 And God entered to Abimelech by sleep in the night. And he said, Behold, you die on account of the woman of whom you took, for she is living with a man. 

#### Genesis 20:4 And Abimelech {not touched her}. And he said, O Lord, {a nation ignorant and just will you destroy}? 

#### Genesis 20:5 {not he to me Said}, {sister She is my}; and she said to me, {brother He is my}? With a clean heart, and with righteousness of hands I did this. 

#### Genesis 20:6 {said And to him God} by sleep, And I knew that with a clean heart you did this, and I spared you for {to not sin you} against me; because of this I did not let you touch her. 

#### Genesis 20:7 And now give back the wife of the man, for he is a prophet, and he will pray for your account, and you shall live. But if you do not give back, you shall know that you shall die, you and all yours. 

#### Genesis 20:8 And Abimelech rose early in the morning, and he called all his servants. And he spoke all these words into their ears. {feared And all the men} exceedingly. 

#### Genesis 20:9 And Abimelech called Abraham. And he said to him, What is this you did to us, lest we sinned against you, that you bring upon me and upon my kingdom {sin a great}? A work which no one will do, you have done to me. 

#### Genesis 20:10 {said And Abimelech} to Abraham, What seeing did you do this? 

#### Genesis 20:11 {said And Abraham}, For I said, Surely there is not godliness in this place, {me and they will kill} because of my wife. 

#### Genesis 20:12 For also truly {sister she is my} from my father, but not from my mother; and she became to me for wife. 

#### Genesis 20:13 And it happened when {led me God} from the house of my father, and I said to her, This righteousness you will do for me in every place of which ever I enter; there you say of me that, {brother He is my}! 

#### Genesis 20:14 {took And Abimelech} a thousand double-drachmas, and sheep, and calves, and manservants, and maidservants, and gave to Abraham, and he gave back to him Sarah his wife. 

#### Genesis 20:15 And Abimelech said to Abraham, Behold, my land is before you, which ever it may please you, dwell there! 

#### Genesis 20:16 And to Sarah he said, Behold, I have given a thousand double-drachmas to your brother, these will be to you for the value of your person, and all the ones with you; and {in all things you be truthful}! 

#### Genesis 20:17 {prayed And Abraham} to God. And God healed Abimelech, and his wife, and his maidservants, and they bore. 

#### Genesis 20:18 For in closing up, the LORD closed up outside every womb in the house of Abimelech, because of Sarah the wife of Abraham. 

#### Genesis 21:1 And the LORD visited Sarah as he said, and the LORD did to Sarah as he spoke. 

#### Genesis 21:2 And conceiving, she bore to Abraham a son in his old age, in the time as {spoke to him the LORD}. 

#### Genesis 21:3 And Abraham called the name of his son, the one born to him whom {bore to him Sarah} -- Isaac. 

#### Genesis 21:4 {circumcised And Abraham} Isaac on the eighth day as {gave charge to him God}. 

#### Genesis 21:5 And Abraham was a hundred years old when {was born to him Isaac his son}. 

#### Genesis 21:6 {said And Sarah}, {laughter to me caused The LORD}, for whoever may hear will rejoice along with me. 

#### Genesis 21:7 And she said, Who will announce to Abraham that {nurses a male child Sarah}, for I bore a son in my old age. 

#### Genesis 21:8 And {grew the child} and was weaned. And Abraham made {banquet a great} the day {was weaned Isaac his son}. 

#### Genesis 21:9 {beholding And Sarah} the son of Hagar the Egyptian, who was born to Abraham, playing with Isaac her son, 

#### Genesis 21:10 that she said to Abraham, You cast out this maidservant and her son, for {shall not be heir the son of the maidservant} with my son Isaac. 

#### Genesis 21:11 {hard But appeared the saying very} before Abraham concerning his son Ishmael. 

#### Genesis 21:12 {said And God} to Abraham, {not hard Let it be} before you on account of the child, and on account of the maidservant! All as much as {should have said to you Sarah}, you hearken to her voice! for by Isaac {shall be called to you a seed}. 

#### Genesis 21:13 {also the son But} of this maidservant {into nation a great I will make}, for he {seed your is}. 

#### Genesis 21:14 {rose up And Abraham} in the morning, and took bread loaves and a leather bag of water; and he gave to Hagar, and he placed the male child upon her shoulders, and he sent her. And she went forth wandering about the wilderness by the Well of the Oath. 

#### Genesis 21:15 {ceased But the water} coming from out of the leather bag, and she tossed the male child underneath one fir tree. 

#### Genesis 21:16 And going forth she sat down before him, far off as a bow shot. For she said, no way shall I see the death of my child. And she sat before him. And yelling out the child wept. 

#### Genesis 21:17 {listened to But God} the voice of the child from the place where he was. And {called an angel of God} Hagar from out of the heaven, and said to her, What is it, Hagar? Fear not! {has heeded for God} the voice of your child from out of the place where he is. 

#### Genesis 21:18 Rise up and take the child, and hold {in your hand it}! {into For nation a great I will make it}. 

#### Genesis 21:19 And God opened her eyes. And she saw a well {water of living}. And she went and filled the leather bag of water, and gave a drink to the child. 

#### Genesis 21:20 And God was with the child. And he grew, and he dwelt in the wilderness. And he became a bowman. 

#### Genesis 21:21 And he dwelt in the wilderness in Parah. And {took to him his mother} a wife from the land of Egypt. 

#### Genesis 21:22 And it came to pass in that time, that Abimelech spoke, along with Ahuzzath his groomsman, and Phichol the commander-in-chief of his force, to Abraham, saying, God is with you in all things what ever you should do. 

#### Genesis 21:23 Now then swear by an oath to me by God that you will not wrong me, nor my seed, nor my name! but according to the righteousness which I did with you, you shall do with me, and in the land where you sojourned in it. 

#### Genesis 21:24 And Abraham said, I will swear by an oath. 

#### Genesis 21:25 And Abraham reproved Abimelech on account of the wells of water, which {removed the servants of Abimelech}. 

#### Genesis 21:26 And {said to him Abimelech}, I do not know who did this matter, nor you reported it to me, nor I heard -- but only today. 

#### Genesis 21:27 And Abraham took sheep and calves, and gave to Abimelech, and {ordained both a covenant}. 

#### Genesis 21:28 And Abraham set seven ewe-lambs of sheep alone. 

#### Genesis 21:29 And Abimelech said to Abraham, What are the seven ewe-lambs of sheep -- these, which you set alone? 

#### Genesis 21:30 And he said, that, {seven ewe-lambs these You shall take of} of mine, that they should be to me for a testimony that I dug this well. 

#### Genesis 21:31 Because of this {was named the name of that place}, Well of the Oath, for there {swore by an oath both}. 

#### Genesis 21:32 And they ordained a covenant at the Well of the Oath. {rose up And Abimelech}, and Ahuzzath his groomsman, and Phichol the commander-in-chief of his force, and they returned to the land of the Philistines. 

#### Genesis 21:33 And Abraham planted plowed fields near the Well of the Oath. And he called there the name of the LORD, God eternal. 

#### Genesis 21:34 {sojourned And Abraham} in the land of the Philistines {days many}. 

#### Genesis 22:1 And it came to pass after these words, God tested Abraham, and said to him, Abraham, Abraham. And he said, Behold, it is I. 

#### Genesis 22:2 And he said, Take your son, the beloved, whom you loved -- Isaac! And go into the {land high}, and offer him there as a whole offering upon one of the mountains! which ever I may tell you. 

#### Genesis 22:3 {rising up And Abraham} in the morning, saddled his donkey, and he took with himself two servants, and Isaac his son. And splitting wood for a whole offering, {rising up to go and}, they came upon the place which {spoke to him God}, {day on the third}. 

#### Genesis 22:4 And Abraham looking up with his eyes saw the place far off. 

#### Genesis 22:5 And Abraham said to his servants, You sit here with the donkey! and I and the lad will go through unto here. And doing obeisance we will return to you. 

#### Genesis 22:6 {took And Abraham} the wood for the whole offering, and placed it upon Isaac his son. And he took with his hands the fire and the knife; and {went the two} together. 

#### Genesis 22:7 {said And Isaac} to Abraham his father, Father. And he said, What is it child? And he said, Behold, the fire and the wood, where is the sheep -- the one for a whole offering? 

#### Genesis 22:8 {said And Abraham}, God will see to himself a sheep for a whole offering, child. {going And both} together, 

#### Genesis 22:9 they came upon the place which {spoke to him God}. And {built there Abraham} the altar. And he placed upon it the wood. And binding {hand and foot Isaac his son}, he placed him upon the altar upon the wood. 

#### Genesis 22:10 And Abraham stretched his hand to take the knife to slay his son. 

#### Genesis 22:11 And {called him an angel of the LORD} from out of the heaven. And he said, Abraham, Abraham. And he said, Behold, it is I. 

#### Genesis 22:12 And he said, You should not put your hand upon the lad, nor should you do anything to him by any means. For now I know that you fear God, and spared not {son your beloved} on account of me. 

#### Genesis 22:13 And Abraham looking up with his eyes, saw. And behold, {ram one} being held in a plant of a thicket by the horns. And Abraham went and took the ram, and he offered it for a whole offering instead of Isaac his son. 

#### Genesis 22:14 And Abraham called the name of that place, The LORD saw; that they may say today, {in the mountain the LORD was seen}. 

#### Genesis 22:15 And {called the angel of the LORD} Abraham a second time from out of the heaven, saying, 

#### Genesis 22:16 According to myself I swear by an oath, says the LORD, because you did this saying, and you did not spare {son your beloved} on account of me. 

#### Genesis 22:17 Assuredly in blessing, I will bless you, and in multiplying I will multiply your seed as the stars of the heaven, and as the sand by the edge of the sea. And {will inherit your seed} the cities of your opponents. 

#### Genesis 22:18 And {will be blessed by your seed all the nations of the earth}; because you obeyed my voice. 

#### Genesis 22:19 {returned And Abraham} to his servants. And rising up they went together to the Well of the Oath. And Abraham dwelt near the Well of the Oath. 

#### Genesis 22:20 And it came to pass after these words, that it was announced to Abraham, saying, Behold, {has born even Milcah herself} sons to Nahor your brother. 

#### Genesis 22:21 Huz first-born, and Buz his brother, and Kemuel father of the Syrians, 

#### Genesis 22:22 and Chesed, and Hazo, and Pildash, and Jidlaph and Bethuel. 

#### Genesis 22:23 And Bethuel procreated Rebekah. These are the eight sons whom Milcah bore to Nahor the brother of Abraham. 

#### Genesis 22:24 And his concubine, whose name was Reumah, bore even herself, Tebah, and Gaham, and Thahash, and Maachah. 

#### Genesis 23:1 {was And the life of Sarah years a hundred twenty-seven}. 

#### Genesis 23:2 And Sarah died in the city of Arba, which is in the hollow -- this is Hebron in the land of Canaan. {came And Abraham} to lament Sarah, and to mourn. 

#### Genesis 23:3 And Abraham rose up from his dead. And Abraham said to the sons of Heth, saying, 

#### Genesis 23:4 {a sojourner and an immigrant I am} among you. Give then to me a possession of a burying-place among you! and I will entomb my dead away from me. 

#### Genesis 23:5 And answered the sons of Heth to Abraham, saying, No, O lord. 

#### Genesis 23:6 But hear us; {as a king by God you are with us}. {in choice sepulchres our You entomb your dead}! for not one of us in any way will withhold his sepulchre from you to entomb your dead there. 

#### Genesis 23:7 And rising up, Abraham did obeisance to the people of the land, to the sons of Heth. 

#### Genesis 23:8 And {spoke to them Abraham}, saying, If you have it in your soul so as to entomb my dead away from my presence, hear me, and speak about me to Ephron, the son of Zohar! 

#### Genesis 23:9 And let him give to me the {cave double} which is his -- the one being in a part of his field. {of silver for its worth Let him give it to me}, {among you for a possession of a memorial}. 

#### Genesis 23:10 And Ephron was sitting down in the midst of the sons of Heth. And responding Ephron the Hittite {to Abraham spoke} in the hearing of the sons of Heth, and {the ones entering into the city of all}, saying, 

#### Genesis 23:11 By me let it be, O lord, and hear me! The field and the cave in it I give to you. Before all of my fellow-countrymen I have given it to you. You entomb your dead. 

#### Genesis 23:12 And Abraham did obeisance before the people of the land. 

#### Genesis 23:13 And he said to Ephron in the ears before the people of the land, Since {with me you are} hear me! The silver for the field, you take from me! and I will entomb my dead there. 

#### Genesis 23:14 {answered And Ephron} Abraham, saying, 

#### Genesis 23:15 Not so O lord, for I heard four hundred double-drachmas of silver; but what ever may this be between me and you? But you {your dead entomb}! 

#### Genesis 23:16 And Abraham hearkened to Ephron. And Abraham restored to Ephron the silver, which he spoke into the ears of the sons of Heth -- four hundred double-drachmas {silver of unadulterated} of merchants. 

#### Genesis 23:17 And {is the field of Ephron which} was in Double Cave, which is against the face of Mamre. The field and the cave which was in it, and every tree which was in the field, which is in its borders round about, 

#### Genesis 23:18 came to Abraham for a possession before the sons of Heth, and all the ones entering into the city. 

#### Genesis 23:19 And after these things Abraham entombed Sarah his wife in the cave of the field at Double Cave, which is before Mamre; this is Hebron in the land of Canaan. 

#### Genesis 23:20 And {was validated the field}, and the cave which was in it to Abraham for a possession of a burying-place from the sons of Heth. 

#### Genesis 24:1 And Abraham was older, advancing of days. And the LORD blessed Abraham according to all things. 

#### Genesis 24:2 And Abraham said to his servant, to the elder of his house, to the one in charge of all his things, Put your hand under my thigh! 

#### Genesis 24:3 And I adjure you by the LORD God of the heaven, and the God of the earth, that you should not take a wife to my son Isaac from the daughters of the Canaanites, with whom I live among them. 

#### Genesis 24:4 But only unto my land of which I was shall you go, and unto my tribe. And you shall take a wife for my son Isaac from there. 

#### Genesis 24:5 {said And to him the servant}, If at any time {not wills the woman} to go with me back into this land, shall I return your son into the land from where you came forth from there? 

#### Genesis 24:6 {said And to him Abraham}, Take heed to yourself that you should not return my son there. 

#### Genesis 24:7 The LORD God of the heaven, and the God of the earth, who took me from {house my father's}, and from the land of which I was born, who spoke to me, and who swore by an oath to me, saying, To you I will give this land and your seed -- he will send his angel in front of you, and you shall take a wife, for my son from there. 

#### Genesis 24:8 And if {should not want the woman} to go with you into this land, you will be clean from this oath. Only {my son you should not return} there. 

#### Genesis 24:9 And {put the servant} his hand under the thigh of Abraham his master. And he swore by an oath to him on account of this saying. 

#### Genesis 24:10 And {took the servant} ten camels from the camels of his master, and from all the good things of his master with himself. And rising up he went into Mesopotamia, into the city of Nahor. 

#### Genesis 24:11 And he rested the camels outside of the city by the Well of the Water, towards late in the day, when the women came forth drawing water. 

#### Genesis 24:12 And he said, O LORD God of my master Abraham, prosper the way before me today, and perform mercy with my master Abraham! 

#### Genesis 24:13 Behold, I stand near the spring of water, and the daughters of the men living in the city come forth to draw water. 

#### Genesis 24:14 And it shall be the virgin, who ever I should have said, Incline your water-pitcher! that I might drink. And she should have said to me, You drink! and {your camels I will water} until whenever they cease to drink -- this one you prepared for your servant Isaac, and in this I will know that you executed mercy with my master Abraham. 

#### Genesis 24:15 And it came to pass before completing his speaking in his mind, that behold, Rebekah came forth -- the one born to Bethuel, son of Milcah, the wife of Nahor, and brother of Abraham, having the water-pitcher upon her shoulders. 

#### Genesis 24:16 And the virgin was good in the appearance -- exceedingly. She was a virgin, no man knew her. And coming upon the spring, she filled her water-pitcher, and ascended. 

#### Genesis 24:17 {ran And the servant} to meet with her, and he said, Give me to drink a little water from out of your water-pitcher! 

#### Genesis 24:18 And she said, Drink, O lord! And she hastened and lowered the water-pitcher upon her arm, and gave him to drink until he ceased drinking. 

#### Genesis 24:19 And she said, Also to your camels I will draw water until whenever all should have drunk. 

#### Genesis 24:20 And she hastened and emptied out the water-pitcher into the channel, and ran yet again unto the well to draw water. And she drew water for all the camels. 

#### Genesis 24:21 And the man studied her, and remained silent to know if the LORD prospered his way or not. 

#### Genesis 24:22 And it came to pass when {ceased all the camels} drinking, {took the man} ear-rings of gold worth up to a drachma scale-weight, and two bracelets, and put them upon her hands -- ten pieces of gold scale-weight was their weight. 

#### Genesis 24:23 And he asked her, and said, Whose daughter are you? Announce to me if there is by your father a place for us to rest up! 

#### Genesis 24:24 And she said to him, {the daughter of Bathuel I am}, the son of Milcah, whom she bore to Nahor. 

#### Genesis 24:25 And she said to him, Also {straw and fodder there is much} by us, and a place to rest up. 

#### Genesis 24:26 And {finding favor the man}, did obeisance to the LORD, and said, 

#### Genesis 24:27 Blessed be the LORD God of my master Abraham, who abandoned not righteousness and truth from my master. {indeed prospered me The LORD} to the house of the brother of my master. 

#### Genesis 24:28 And running, the maidservant announced in the house to her mother about these words. 

#### Genesis 24:29 And to Rebekah there was a brother whose name was Laban. And Laban ran to the man outside near the spring. 

#### Genesis 24:30 And it came to pass when he saw the ear-rings, and the bracelets upon the hands of his sister, and when he heard the words of Rebekah his sister, saying, So spoke to me the man; that he came to the man standing by himself by the camels near the spring. 

#### Genesis 24:31 And he said to him, Come, enter blessed of the LORD! Why stand outside? For I prepared the residence, and a place for the camels. 

#### Genesis 24:32 {entered And the man} into the residence. And he unharnessed the camels, and gave straw and fodder to the camels, and water for his feet, and for the feet of the men with him. 

#### Genesis 24:33 And he placed near them bread loaves to eat. And he said, No way will I eat until speaking my words. And he said, Speak! 

#### Genesis 24:34 And he said, A servant of Abraham I am. 

#### Genesis 24:35 And the LORD blessed my master exceedingly; and he was raised up high, and he gave to him sheep, and calves, and silver, and pieces of gold, and manservants, and maidservants, camels, and donkeys. 

#### Genesis 24:36 And {bore Sarah the wife of my master} a son, one to my master after his growing old. And he gave to him as much as was his. 

#### Genesis 24:37 And {bound me by an oath my master}, saying, You shall not take a wife for my son from the daughters of the Canaanites, in which I sojourned in their land. 

#### Genesis 24:38 But unto the house of my father you should go, and to my tribe; and you shall take a wife for my son. 

#### Genesis 24:39 And I said to my master, Perhaps {should not go the woman} with me. 

#### Genesis 24:40 And he said to me, The LORD God in whom I was found well-pleasing before him, he will send out his angel with you, and prosper your way. And you will take a wife for my son from out of my tribe, and from out of the house of my father. 

#### Genesis 24:41 Then {innocent you will be} concerning my oath. For when ever you should have come to my tribe, and {not to you they should give her}, then you will be innocent concerning my oath. 

#### Genesis 24:42 And coming today upon the spring, I said, O LORD, the God of my master Abraham; if you prosper my way, in which now I go by it, 

#### Genesis 24:43 behold, I stand near the spring of water, and the daughters of the men of the city came forth to draw water, and it will be the virgin to whom ever I should say, {to drink Give me from your water-pitcher a little water}! 

#### Genesis 24:44 And she should have said to me, You also drink, and to your camels I will draw water. This is the woman whom the LORD prepared for his own attendant Isaac; and in this you will know that you have done mercy to my master Abraham. 

#### Genesis 24:45 And it came to pass before the completing my speaking in my mind, straightway Rebekah came forth having the water-pitcher upon the shoulders, and she went down to the spring, and she drew water. And I said to her, Give me a drink! 

#### Genesis 24:46 And she hastened to lower the water-pitcher upon her arm from herself, and she said, You drink! and {your camels I will water}. And I drank, and {the camels she watered}. 

#### Genesis 24:47 And I asked her, and said, Whose daughter are you? And she said, {the daughter of Bethuel I am}, son of Nahor, whom {bore to him Milcah}. And I put on her the ear-rings, and the bracelets about her hands. 

#### Genesis 24:48 And finding favor, I did obeisance to the LORD. And I blessed the LORD God of my master Abraham, who prospered me in the way of truth, to take the daughter of the brother of my master, for his son. 

#### Genesis 24:49 If then you do mercy and righteousness to my master, report to me that I might turn to the right or left! 

#### Genesis 24:50 And answering Laban and Bethuel said, From the LORD came forth this thing, we will not be able to contradict bad or good. 

#### Genesis 24:51 Behold, Rebekah is before you, in taking her, run! and let her be wife to the son of your master! as the LORD spoke. 

#### Genesis 24:52 And taking place in the hearing of the servant of Abraham their words, he did obeisance upon the ground to the LORD. 

#### Genesis 24:53 And {brought forth the servant} items made of silver and of gold. And {clothes he gave} to Rebekah, and {gifts he gave} to her brother, and to her mother. 

#### Genesis 24:54 And they ate and drank. And he and the men {with him being} went to sleep. And rising up in the morning, he said, Send me forth! that I may go forth to my master. 

#### Genesis 24:55 {said And her brothers and mother}, Let {remain the virgin} with us {days about ten}! and after this she shall go forth. 

#### Genesis 24:56 And he said to them, Do not hold me, for the LORD prospered my way! Send me! that I may go forth to my master. 

#### Genesis 24:57 And they said, We should call the maidservant, and we should ask by her mouth. 

#### Genesis 24:58 And they called Rebekah, and said to her, Will you go with this man? And she said, I will go. 

#### Genesis 24:59 And they sent forth Rebekah their sister, and her possessions, and the servant of Abraham, and the ones with him. 

#### Genesis 24:60 And they blessed Rebekah, and said to her, {sister our You are}, become for a thousand myriads, and {inherit let your seed} the cities of your opponents! 

#### Genesis 24:61 And rising up, Rebekah and her handmaidens mounted upon the camels, and they went with the man. And taking the girl Rebekah, he went forth. 

#### Genesis 24:62 And Isaac was traveling over through the wilderness by the Well of the Vision. And he dwelt in the land towards the south. 

#### Genesis 24:63 And Isaac came forth to meditate in the plain towards afternoon. And looking up with his eyes, he saw camels coming. 

#### Genesis 24:64 And Rebekah looking up with the eyes, saw Isaac, and she leaped down from the camel. 

#### Genesis 24:65 And she said to the servant, Who is that man going in the plain to meet us? And said the servant, This is my master. And she having taken the lightweight covering put it on. 

#### Genesis 24:66 And {described the servant} to Isaac all the words which he did. 

#### Genesis 24:67 {entered And Isaac} into the house of his mother, and took Rebekah, and she became his wife. And he loved her. And Isaac was comforted concerning Sarah his mother. 

#### Genesis 25:1 {added And Abraham} to take a wife whose name was Keturah. 

#### Genesis 25:2 And she bore to him Zimran, and Jokshan, and Medan, and Midian, and Ishbak, and Shuah. 

#### Genesis 25:3 And Jokshan procreated Sheba and Dedan. And sons of Dedan were the Asshurim, and Letushim, and Leummim. 

#### Genesis 25:4 And the sons of Midian were Ephah, and Epher, and Hanoch, and Abida, and Eldaah. All these were sons of Keturah. 

#### Genesis 25:5 {gave And Abraham} all his possessions to Isaac his son. 

#### Genesis 25:6 And to the sons of his concubines Abraham gave gifts. And he sent them from Isaac his son {still living while he was} towards the east into the land of the east. 

#### Genesis 25:7 And these were the years of the days of the life of Abraham, as many as he lived, a hundred seventy-five years. 

#### Genesis 25:8 And failing, Abraham died in {old age a good}, an old man and full of days. And he was added to his people. 

#### Genesis 25:9 And {entombed him, Isaac and Ishmael} {two sons his}, in the {cave double}, in the field of Ephron the son of Zohar the Hittite, which is before Mamre; 

#### Genesis 25:10 the field and the cave which Abraham acquired from the sons of Heth. There they entombed Abraham and Sarah his wife. 

#### Genesis 25:11 And it came to pass after the dying of Abraham, God blessed Isaac his son. And Isaac dwelt by the Well of the Vision. 

#### Genesis 25:12 And these are the origins of Ishmael, the son of Abraham, whom Hagar bore (the Egyptian maidservant of Sarah) to Abraham. 

#### Genesis 25:13 And these are the names of the sons of Ishmael, according to the names of his generations. First-born of Ishmael, Nebajoth, and Kedar, and Adbeel, and Mibsam, 

#### Genesis 25:14 and Mishma, and Dumah, and Massa, 

#### Genesis 25:15 and Hadar, and Tema, and Jetur, and Naphish, and Kedemah. 

#### Genesis 25:16 These are the sons of Ishmael, and these are the names of them by their tents, and by their properties -- twelve rulers according to their nation. 

#### Genesis 25:17 And these are the years of the life of Ishmael, a hundred thirty-seven years; and failing, he died. And he was added to his family. 

#### Genesis 25:18 And he dwelt from Havilah unto Shur, which is against the face of Egypt, unto coming to Assyrian. By the face of all his brethren he dwelt. 

#### Genesis 25:19 And these are the generations of Isaac the son of Abraham. 

#### Genesis 25:20 Abraham procreated Isaac. {was And Isaac years old forty} when he took Rebekah daughter of Bethuel the Syrian to himself for wife. 

#### Genesis 25:21 {beseeched And Isaac} the LORD concerning Rebekah his wife, for she was sterile; {listened and his God}, and {conceived in the womb Rebekah his wife}. 

#### Genesis 25:22 {leaped And the male babies} in her. And she said, If thus {to me is about to happen}, why {to me is this}? And she went to inquire of the LORD. 

#### Genesis 25:23 And the LORD said to her, Two nations {in your womb are}; and two peoples from out of your belly will draw apart. And one people {another people will be superior over}; and the greater will be a servant to the lesser. 

#### Genesis 25:24 And were fulfilled the days for her to bear. And thus there were twins in her belly. 

#### Genesis 25:25 And came forth the first-born fiery red entirely, and of {skin hairy}. And she named his name Esau. 

#### Genesis 25:26 And after this came forth his brother, and his hand took hold of the heel of Esau. And she called his name Jacob. And Isaac was {years old sixty} when {bore them Rebekah}. 

#### Genesis 25:27 {grew And the young}. And Esau was a man knowing to hunt with hounds -- rugged; but Jacob {man was a simple} living in a residence. 

#### Genesis 25:28 {loved But Isaac} Esau, for his hunting food for him. But Rebekah loved Jacob. 

#### Genesis 25:29 {boiled And Jacob} stew; {came and Esau} from out of the plains -- failing. 

#### Genesis 25:30 And Esau said to Jacob, Let me taste from {stew this spicy} for I fail; on account of this {was called his name} Edom. 

#### Genesis 25:31 {said And Jacob} to Esau, Give to me today your rights as first-born. 

#### Genesis 25:32 And Esau said, Behold, I am going to come to an end, and what to me are these, the rights of the first-born? 

#### Genesis 25:33 And {said to him Jacob}, You swear by an oath to me today! And he swore by an oath to him. {gave And Esau} the rights of the first-born to Jacob. 

#### Genesis 25:34 And Jacob gave to Esau bread and stew of lentils. And he ate and drank, and rising up he set out. And Esau treated as worthless the rights of the first-born. 

#### Genesis 26:1 And there became a famine upon the land, separate from the famine formerly, which happened in the time of Abraham. {went And Isaac} to Abimelech king of the Philistines in Gerar. 

#### Genesis 26:2 {appeared And to him the LORD}, and said, You should not go down into Egypt, but dwell in the land! which ever I should tell you. 

#### Genesis 26:3 And sojourn in this land! And I will be with you, and I will bless you. For to you and your seed I will give all this land. And I will establish my oath, which I swore to Abraham your father. 

#### Genesis 26:4 And I will multiply your seed as the stars of the heaven. And I will give your seed all this land. And shall be blessed by your seed all the nations of the earth; 

#### Genesis 26:5 because {obeyed Abraham your father} my voice, and guarded my orders, and my commandments, and my ordinances, and my laws. 

#### Genesis 26:6 {dwelt And Isaac} in Gerar. 

#### Genesis 26:7 {asked And the men of the place} concerning Rebekah his wife. And he said, {sister She is my}, for he feared to say that, {wife She is my}, lest at any time {should kill him the men of the place} on account of Rebekah; for {beautiful her appearance was}. 

#### Genesis 26:8 And he became long-lived there. And {leaned over Abimelech the king of Gerar} through the window, and saw Isaac playing with Rebekah his wife. 

#### Genesis 26:9 {called And Abimelech} Isaac, and said to him, So indeed {your wife is she}? Why is it that you said, {sister She is my}? {said And to him Isaac}, I said it for lest at any time I might die on account of her. 

#### Genesis 26:10 {said And to him Abimelech}, What is this you did to us? Is it a small thing {went to bed if someone kind of my} with your wife, and you brought upon us a sin of ignorance? 

#### Genesis 26:11 {gave orders And Abimelech} to all his people, saying, Any one touching this man and his wife {unto death liable will be}. 

#### Genesis 26:12 {sowed And Isaac} in that land. And he found in that year {bearing a hundred fold barley}, {blessed and him the LORD}. 

#### Genesis 26:13 And {was exalted the man}, and {advancing greatly was}, until of which time {great he became exceedingly}. 

#### Genesis 26:14 And there became to him herds of sheep, and herds of oxen, and {farms many}. {envied And him the Philistines}. 

#### Genesis 26:15 And all the wells which {dug the servants of his father} {obstructed them in the time of his father the Philistines}, and filled them with earth. 

#### Genesis 26:16 {said And Abimelech} to Isaac, Go forth from us! for {mightier than us you became exceedingly}. 

#### Genesis 26:17 And Isaac went forth from there. And he rested up in the ravine of Gerar, and dwelt there. 

#### Genesis 26:18 And again Isaac dug the wells of water which {dug the servants of Abraham his father}; and {obstructed them the Philistines}, after the dying of Abraham his father. And he named them with names according to the names which {named his father}. 

#### Genesis 26:19 And {dug the servants of Isaac} in the ravine of Gerar, and found there a well of {water living}. 

#### Genesis 26:20 And {did combat the shepherds of Gerar} with the shepherds of Isaac, maintaining {theirs to be the water}. And they called the name of the well, Injustice, for they wronged him. 

#### Genesis 26:21 And departing from there he dug {well another}. And they quarreled also on account of that well. And he named the name of it, Hatred. 

#### Genesis 26:22 And departing from there, he dug {well another}. And they did not do combat over it. And he named the name of it, Expanse, saying, Because now the LORD widened us, and caused us to grow upon the earth. 

#### Genesis 26:23 And he ascended from there towards the Well of the Oath. 

#### Genesis 26:24 And {appeared to him the LORD} in that night, and said, I am the God of Abraham your father. Do not fear! {with you for I am}. And I will bless you, and I will multiply your seed because of Abraham your father. 

#### Genesis 26:25 And he built there an altar, and called upon the name of the LORD, and he pitched there his tent. {dug And there the servants of Isaac a well} in the ravine Gerar. 

#### Genesis 26:26 And Abimelech went to him from Gerar, and Ahuzzath his groomsman, and Phichol the commander-in-chief of his force. 

#### Genesis 26:27 And {said to them Isaac}, Why did you come to me; for you detested me, and you sent me from you? 

#### Genesis 26:28 And they said, Seeing, we have seen that the LORD was with you. And we said, Let there become an oath between us and between you! And we will ordain with you a covenant. 

#### Genesis 26:29 You shall not do {with us evil}, in so far as {did not abhor you we}, and which manner we treated you well, and we sent you out in peace. And now, you are being blessed by the LORD. 

#### Genesis 26:30 And he made a banquet for them. And they ate and drank. 

#### Genesis 26:31 And rising up in the morning, {swore by an oath each} to the neighbor. And {sent them out Isaac}, and they moved away from him with safety. 

#### Genesis 26:32 And it came to pass in that day, also {coming the servants of Isaac} reported to him concerning the well which they dug, and said, We did not find water. 

#### Genesis 26:33 And he called it, Oath. On account of this he called the name of that city, Well of Oath, unto today's day. 

#### Genesis 26:34 {was And Esau years old forty} and he took a wife -- Judith the daughter of Beeri the Hittite, and Bashemath daughter of Elon the Hittite. 

#### Genesis 26:35 And they were contending with Isaac and Rebekah. 

#### Genesis 27:1 And it came to pass after the growing old of Isaac, that {were blunted his eyes} to see. And he called Esau {son his older}, and said to him, O my son. And he said, Behold, it is I. 

#### Genesis 27:2 And he said, Behold, I have grown old, and I do not know the day of my decease. 

#### Genesis 27:3 Now then, take your hunting equipment, both the quiver and the bow! and go forth into the plain, and hunt for me game! 

#### Genesis 27:4 And make for me food as I am fond of, and bring it to me! that I may eat, so that {may bless you my soul} before my dying. 

#### Genesis 27:5 And Rebekah heard Isaac speaking to Esau his son. {went And Esau} into the plain to hunt game for his father. 

#### Genesis 27:6 And Rebekah said to Jacob {son her lesser}, See! I heard your father speaking to Esau your brother, saying, 

#### Genesis 27:7 Bring to me game, and make food for me! that eating, I may bless you before the LORD, before my dying. 

#### Genesis 27:8 Now then, O my son, hear me as I give charge to you! 

#### Genesis 27:9 And going unto the sheep, you take for me from there two kids, tender and good! And I will make them for food for your father as he is fond of. 

#### Genesis 27:10 And you shall carry them in to your father, and he shall eat, that {may bless you your father} before his dying. 

#### Genesis 27:11 {said And Jacob} to Rebekah his mother, {is My brother man a hairy}, and I am {man a smooth}; 

#### Genesis 27:12 lest at any time {should handle me my father}, and I will be before him as disdained, and I shall bring upon myself a curse, and not a blessing. 

#### Genesis 27:13 {said And to him the mother}, Upon me be your curse, child. Only you heed my voice! And in going bring them to me! 

#### Genesis 27:14 And going, he took them, and brought them to the mother. And {made his mother} food as {was fond of his father}. 

#### Genesis 27:15 And Rebekah having taken the apparel of Esau {son her elder}, the goodly, which was by her in the house, she put it on Jacob {son her younger}. 

#### Genesis 27:16 And {the skins of the kids she put} upon his arms, and upon the naked parts of his neck. 

#### Genesis 27:17 And she gave the foods and the bread loaves which she made unto the hands of Jacob her son. 

#### Genesis 27:18 And he carried in to his father. And he said, Father! And he said, Behold, it is I, who are you child? 

#### Genesis 27:19 And Jacob said to his father, I am Esau your first-born. I did as you told me. In rising up come take a seat and eat from my game! that {may bless me your soul}. 

#### Genesis 27:20 {said And Isaac} to his son, What is this which so quickly you found, O child? And he said, that which {delivered up the LORD your God} before me. 

#### Genesis 27:21 {said And Isaac} to Jacob, Approach me, and I shall handle you child, to see if you are my son Esau or not! 

#### Genesis 27:22 {approached And Jacob} to Isaac his father. And he handled him, and said, Indeed the voice is the voice of Jacob, but the hands are the hands of Esau. 

#### Genesis 27:23 And he did not recognized him, {were for his hands} as the hands of Esau his brother -- hairy; and he blessed him. 

#### Genesis 27:24 And he said, You are my son Esau? And he said, I am. 

#### Genesis 27:25 And he said, Bring to me! and I will eat from your game, child, that {may bless you my soul}. And he brought it near to him, and he ate; and he carried to him wine, and he drank. 

#### Genesis 27:26 And {said to him Isaac his father}, Approach me, and kiss me child! 

#### Genesis 27:27 And approaching, he kissed him. And he smelled the scent of his garments, and blessed him, and said, Behold, the scent of my son is as the scent {field of a full} which the LORD blessed; 

#### Genesis 27:28 and may {give to you God} from the dew of the heaven, and from the fatness of the earth, and a multitude of grain and wine. 

#### Genesis 27:29 And let {be slave to you nations}! And let {do obeisance to you rulers}! And you become master of your brother! And {will do obeisance to you the sons of your father}. The one cursing you will be accursed, and the one blessing you will be for a blessing. 

#### Genesis 27:30 And it came to pass after the ceasing of Isaac blessing Jacob his son, that it happened as Jacob went forth from the face of Isaac his father, that Esau his brother came from the hunt. 

#### Genesis 27:31 And he made also himself food, and brought it near his father. And he said to the father, Rise up my father, and eat from the game of his son! that {may bless me your soul}. 

#### Genesis 27:32 And {said to him Isaac his father}, Who are you? And he said, I am your son, the first-born, Esau. 

#### Genesis 27:33 {was amazed And Isaac change of state great with an exceedingly}. And he said, Who then is the one hunting game for me, and carrying it in to me? And I ate from all before your coming, and blessed him, and a blessing let it be! 

#### Genesis 27:34 And it happened when Esau heard the words of his father Isaac, he yelled out {voice with a great and bitter exceedingly}. And he said, You bless indeed also me father! 

#### Genesis 27:35 And he said to him, In coming, your brother with cunning took your blessing. 

#### Genesis 27:36 And he said, Justly was {called his name} Jacob. For he has stomped upon me already this second time. Even my rights of the first-born he has taken, and now he took my blessing. And Esau said to his father, Do you not leave behind to me a blessing, O father? 

#### Genesis 27:37 And answering Isaac said to Esau, If {master him I made} of you, and {all his brothers I made} his servants, {with grain and wine to support him} -- then to you what may I do child? 

#### Genesis 27:38 {said And Esau} to his father, {not blessing one in you Is there}, O father? {bless Indeed} me also father! {being vexed And Isaac}, {yelled out a sound Esau}, and he wept. 

#### Genesis 27:39 {answering And Isaac his father} said to him, Behold, from the fatness of the earth will be your dwelling, and from the dew of the heaven above. 

#### Genesis 27:40 And upon your sword you shall live, and {of your brother you will be a servant}. And it will be when ever you should demolish and loosen his yoke from your neck. 

#### Genesis 27:41 And Esau was angry at Jacob on account of the blessing of which {blessed him his father}. {said And Esau} in his mind, Let approach the days of the mourning of my father! that I may kill Jacob my brother. 

#### Genesis 27:42 And were reported to Rebekah the words of Esau {son her elder}. And sending forth, she called Jacob {son her younger}, and she said to him, Behold, Esau, your brother threatens you -- to kill you. 

#### Genesis 27:43 Now then, child, hear my voice! and rising up run away into Mesopotamia to Laban my brother in Haran! 

#### Genesis 27:44 And live with him some days! 

#### Genesis 27:45 until the turning back the rage and the anger of your brother from you, and he should forget what you have done to him. And sending, I will fetch you from there, lest at any time I should be childless from the two of you in {day one}. 

#### Genesis 27:46 {said And Rebekah} to Isaac, I loathe my life, on account of the daughters of the sons of Heth. If Jacob shall take a wife from the daughters of this land, why is it for me to live? 

#### Genesis 28:1 {having called And Isaac} Jacob, blessed him, and gave charge to him, saying, Not shall you take a wife from the daughters of the Canaanites. 

#### Genesis 28:2 Having risen up, you run away unto Mesopotamia to the house of Bethuel the father of your mother! and take to yourself from there a wife from the daughters of Laban the brother of your mother! 

#### Genesis 28:3 And {my God may bless} you, and increase you, and multiply you; and you will be for gatherings of nations. 

#### Genesis 28:4 And may he give to you the blessing of Abraham, my father, to you, and your seed after you; to inherit the land of your sojourning, which God gave to Abraham. 

#### Genesis 28:5 And Isaac sent Jacob. And he went into Mesopotamia to Laban the son of Bethuel the Syrian, brother of Rebekah, the mother of Jacob and Esau. 

#### Genesis 28:6 {having seen And Esau} that Isaac blessed Jacob, and sent him into Mesopotamia of Syria to take to himself a wife from there -- in the blessing him, and gave charge to him, saying, You shall not take a wife of the daughters of the Canaanites, 

#### Genesis 28:7 that Jacob hearkened to {father and mother his}, and went into Mesopotamia of Syria, 

#### Genesis 28:8 and seeing, even Esau, that {are wicked the daughters of Canaan} before Isaac his father, 

#### Genesis 28:9 that Esau went to Ishmael, and he took Mahalath daughter of Ishmael, the son of Abraham, sister of Nebajoth, to his wives, as a wife. 

#### Genesis 28:10 And Jacob went forth from the Well of the Oath, and went into Haran. 

#### Genesis 28:11 And he encountered a place, and slept there, {went down for the sun}. And he took from one of the stones of the place, and put it at his head, and went to sleep in that place. 

#### Genesis 28:12 And he dreamed. And behold, there was a stairway being supported by the earth, of which the top arrived in the heaven. And the angels of God ascended and descended upon it. 

#### Genesis 28:13 And the LORD stayed upon it. And he said, I am the God of Abraham your father, and the God of Isaac. Do not fear! The land of which you sleep upon it, to you I will give it, and to your seed. 

#### Genesis 28:14 And {will be your seed} as sand of the earth. And it will be widened unto the west, and south, and north, and unto the east. And shall be blessed by you all the tribes of the earth, and by your seed. 

#### Genesis 28:15 And behold, I am with you, guarding you in {way every} of which ever you may go. And I will return you to this land, for no way would I abandon you until my doing all as much as I spoke to you. 

#### Genesis 28:16 And Jacob awoke from out of his sleep. And he said that, The LORD is in this place, but I had not known it. 

#### Genesis 28:17 And he feared, and said, How fearful this place. Is not this none other than the house of God, and this the gate of heaven. 

#### Genesis 28:18 And Jacob rose up in the morning, and took the stone which he placed there at his head. And he set it as a monument, and poured oil upon the top of it. 

#### Genesis 28:19 And he called the name of that place, House of God, and Lam-luz was the name to the city formerly. 

#### Genesis 28:20 And Jacob vowed a vow, saying, If {should be the LORD God} with me, and should guard me in this journey which I go, and should give to me bread to eat, and a cloak to put on, 

#### Genesis 28:21 and will return me with safety unto the house of my father, and the LORD will be to me for God, 

#### Genesis 28:22 and this stone which I set as a monument, will be to me a house of God. And all, what ever, you should give to me, {a tenth I will tithe} of it to you. 

#### Genesis 29:1 And Jacob lifting his feet, went into the land of the east to Laban, the son of Bethuel the Syrian, and brother of Rebekah, mother of Jacob and Esau. 

#### Genesis 29:2 And he saw, and behold, there was a well in the plain. And there were there three flocks of sheep resting near it, for from out of that well they watered the flocks. {stone And there was a great} upon the mouth of the well. 

#### Genesis 29:3 And {came together there all the flocks}. And they rolled away the stone from the mouth of the well, and they watered the sheep, and restored the stone upon the mouth of the well into its place. 

#### Genesis 29:4 {said And to them Jacob}, Brethren, from what place are you? And they said, {from Haran We are}. 

#### Genesis 29:5 And he said to them, You know Laban the son of Nahor? And they said, We know him. 

#### Genesis 29:6 And he said to them, Is he in health? And they said, He is in health, and behold, Rachel his daughter comes with the sheep. 

#### Genesis 29:7 And Jacob said, There is still {day much}, for not yet is the hour {to come together for the herds}; having watered the sheep, sending them forth graze them! 

#### Genesis 29:8 And they said, We are not able until the coming together of all the shepherds, for they should roll away the stone from the mouth of the well, and we shall water the sheep. 

#### Genesis 29:9 While he was speaking to them, and behold, Rachel the daughter of Laban comes with the sheep of her father. For she grazed the sheep of her father. 

#### Genesis 29:10 And it came to pass as Jacob saw Rachel, the daughter of Laban, brother of his mother, and the sheep of Laban, the brother of his mother; and coming forward, Jacob rolled away the stone from the mouth of the well. And he watered the sheep of Laban, the brother of his mother. 

#### Genesis 29:11 And Jacob kissed Rachel. And yelling with his voice he wept. 

#### Genesis 29:12 And he reported to Rachel that {a brother of her father he is}, and that {a son of Rebekah he is}. And she ran to report to her father concerning these words. 

#### Genesis 29:13 And it came to pass as Laban heard the name Jacob, the son of his sister, he ran to meet him. And taking hold of him, he kissed him and brought him into his house. And he described to Laban all these matters. 

#### Genesis 29:14 And {said to him Laban}, From out of my bones, and from out of my flesh are you. And he was with him a month of days. 

#### Genesis 29:15 {said And Laban} to Jacob that, For {brother you are my}, you shall not be a slave to me without charge, you tell to me what your wage is? 

#### Genesis 29:16 And to Laban there were two daughters, the name of the older -- Leah, and the name of the younger -- Rachel. 

#### Genesis 29:17 But the eyes of Leah were weak, but Rachel was good to the sight, and beautiful in appearance -- exceedingly. 

#### Genesis 29:18 {loved And Jacob} Rachel. And he said, I will serve you seven years for Rachel {daughter your younger}. 

#### Genesis 29:19 {said And to him Laban}, Better for me to give her to you, than for me to give her {man to another}. You live with me! 

#### Genesis 29:20 And Jacob served for Rachel seven years, and they were before him as {days a few}, because of his love for her. 

#### Genesis 29:21 {said And Jacob} to Laban, Give to me my wife, {are fulfilled for the days} so as to enter to her! 

#### Genesis 29:22 {brought together And Laban} all the men of the place, and he made a wedding. 

#### Genesis 29:23 And it became evening. And taking Leah his daughter, he brought her to Jacob, and {entered to her Jacob}. 

#### Genesis 29:24 {gave And Laban} Leah his daughter Zilpah his maidservant. 

#### Genesis 29:25 And it happened in the morning, and behold, there was Leah. {said And Jacob} to Laban, What is this you did to me, was it not on account of Rachel I served for you, and why did you mislead me? 

#### Genesis 29:26 {said And Laban}, It is not so in our place to give the younger before the elder. 

#### Genesis 29:27 You complete then these sevenths and I will give to you also this woman for the work of which you will work for me, yet {seven years another}. 

#### Genesis 29:28 {did And Jacob} so, and fulfilled these her sevenths. And {gave to him Laban} Rachel his daughter, to him as wife. 

#### Genesis 29:29 {gave And Laban to his daughter Bilhah the maidservant}. 

#### Genesis 29:30 And he entered to Rachel. And he loved Rachel rather than Leah. And he served him {seven years another}. 

#### Genesis 29:31 {seeing And the LORD} that Leah was detested, he opened her womb. But Rachel was sterile. 

#### Genesis 29:32 And Leah conceived and bore a son to Jacob. And she called his name, Reuben, saying, Because {saw my the LORD} the humiliation, and he gave to me a son; now then {will love me my husband}. 

#### Genesis 29:33 And {conceived again Leah} and bore {son a second} to Jacob. And she said, For the LORD heard that I am detested, and he gave in addition to me also this one. And she called his name, Simeon. 

#### Genesis 29:34 And she conceived again and bore a son. And she said, In the present time {by me will be my husband}, for I bore to him three sons. On account of this she called his name, Levi. 

#### Genesis 29:35 And conceiving again she bore a son. And she said, Now yet this I will acknowledge to the LORD. On account of this she called his name, Judah. And she stopped bearing. 

#### Genesis 30:1 {saw And Rachel} that she has not borne to Jacob. And Rachel envied her sister. And she said to Jacob, Give to me a child! and if not, I will come to an end. 

#### Genesis 30:2 {being enraged And Jacob} with Rachel, said to her, {not in place of God I am} who deprived you of the fruit of the belly? 

#### Genesis 30:3 {said And Rachel} to Jacob, Behold, my maidservant Bilhah. Enter to her! and she will bear upon my knees, and {will produce children even I} from her. 

#### Genesis 30:4 And she gave Bilhah to him -- her maidservant to him as wife. And {entered to her Jacob}. 

#### Genesis 30:5 And {conceived Bilhah the maidservant of Rachel}. And she bore to Jacob a son. 

#### Genesis 30:6 And Rachel said, {judged me God}, and he heeded my voice, and he gave to me a son through this one. On account of this she called his name, Dan. 

#### Genesis 30:7 And {conceived again Bilhah the maidservant of Rachel}. And she bore {son a second} to Jacob. 

#### Genesis 30:8 And Rachel said, {aided me God}, and I was twisted by my sister, and I was able. And she called his name, Naphtali. 

#### Genesis 30:9 {saw And Leah} that she stopped bearing. And she took Zilpah her maidservant, and gave her to Jacob as wife. 

#### Genesis 30:10 And {conceived Zilpah the maidservant of Leah}. And she bore to Jacob a son. 

#### Genesis 30:11 And Leah said, I am in good luck. And she named his name, Gad. 

#### Genesis 30:12 And {conceived again Zilpah the maidservant of Leah}. And she bore to Jacob {son a second}. 

#### Genesis 30:13 And Leah said, Blessed am I, for {declare me happy the women}. And she called his name, Asher. 

#### Genesis 30:14 {went And Reuben} in the day {harvest of the wheat}, and he found apples of mandrakes in the field. And he brought them to Leah his mother. {said And Rachel} to Leah her sister, Give to me of the mandrakes of your son! 

#### Genesis 30:15 {said And Leah}, Is it not fit to you that you took my man, shall also {of the mandrakes of my son you take}? {said And Rachel}, Not so, let him go to bed with you this night in return for the mandrakes of your son. 

#### Genesis 30:16 {entered And Jacob} from out of the field at evening. And came forth Leah to meet him. And she said, {to me You shall enter} today, for I have hired you in return for the mandrakes of my son. And he went to bed with her that night. 

#### Genesis 30:17 And God heeded Leah. And conceiving, she bore {son a fifth} to Jacob. 

#### Genesis 30:18 And Leah said, {gave to me God} my wage because I gave my maidservant to my husband. And she called his name, Issachar, which is, Wage. 

#### Genesis 30:19 And {conceived again Leah}. And she bore {son a sixth} to Jacob. 

#### Genesis 30:20 And Leah said, God has presented to me {gift a good} in the present time, {will select me my man} for having borne to him six sons. And she called his name, Zebulun. 

#### Genesis 30:21 And after this she bore a daughter, and she called her name, Dinah. 

#### Genesis 30:22 {remembered And God} Rachel. And {heeded her God}, and he opened her womb. 

#### Genesis 30:23 And conceiving, she bore to Jacob a son. {said And Rachel}, God removed from me the scorn. 

#### Genesis 30:24 And she called his name Joseph, saying, God added to me {son another}! 

#### Genesis 30:25 And it came to pass when Rachel bore Joseph, Jacob said to Laban, Send me that I may go forth into my place, and unto my land! 

#### Genesis 30:26 Give to me my wives, and my children! for whom I have served to you, that I might go forth. For you know the servitude which I have served you. 

#### Genesis 30:27 {said And to him Laban}, If I found favor before you, could I foretell even -- {blessed me God} in your entrance. 

#### Genesis 30:28 You draw your wage from me! and I will give it. 

#### Genesis 30:29 {said And Jacob} to him, You know in what I served you, and how much {was cattle of your} with me. 

#### Genesis 30:30 {little For there was} as much as was to you before me, and it was grown into a multitude; and {blessed you the LORD} by my foot. Now then, when shall {produce I also} for myself a house? 

#### Genesis 30:31 And Laban said to him, What shall I give to you? {said And to him Jacob}, You shall not give to me anything. If you should do for me this word, again I will tend your flocks, and guard them. 

#### Genesis 30:32 Let {go by all your flocks} today, and you part from there every {sheep gray} among the rams, and all white-mixed and speckled among the goats! It will be to me a wage. 

#### Genesis 30:33 And {will take heed to me my righteousness} in the {day next}; for {is my wage} before you -- all which might not be speckled and white-mixed among the goats, and gray among the rams, {stolen will be as} by me. 

#### Genesis 30:34 {said And to him Laban}, Let it be according to your word! 

#### Genesis 30:35 And he drew apart in that day the {he-goats speckled}, and the white-mixed, and all the goats, the speckled and the white-mixed, and all gray, the one which was among the rams. And he gave by the hand of his sons. 

#### Genesis 30:36 And he left a journey of three days between them and between Jacob. And Jacob tended the flocks of Laban -- the ones left behind. 

#### Genesis 30:37 {took And to himself Jacob} a rod {poplar of green}, and of walnut, and of the plane tree. And {peeled them Jacob peels into white}, tearing away the green. And there appeared upon the rods the white which he peeled -- varying. 

#### Genesis 30:38 And he placed the rods which he peeled at the watering troughs of the channels of the water. That whenever {came the flocks} to drink in front of the rods of those having come to drink, the rods should stimulate the flocks at the rods. 

#### Genesis 30:39 And {bore the flocks} white-mixed, and colored, and ashen speckled. 

#### Genesis 30:40 {the And lambs drew apart Jacob}. And he set {before the sheep a ram white-mixed}, and every colored one among the lambs. And he parted to himself flocks for himself, and did not mix them into the flocks of Laban. 

#### Genesis 30:41 And it came to pass in the time {which he stimulated the flocks} in the womb, {taking them put Jacob} the rods before the flocks at the watering troughs for the purpose of stimulating them by the rods. 

#### Genesis 30:42 But whenever {bore the flocks} he did not place them. {became And the unmarked} Laban's, and the marked Jacob's. 

#### Genesis 30:43 And {became rich the man} exceedingly, exceedingly. And there was to him {cattle much}, and oxen, and manservants, and maidservants, and camels, and donkeys. 

#### Genesis 31:1 {heard And Jacob} the utterances of the sons of Laban, saying, Jacob has taken all the things of our father. And by the things of our father he has produced all this glory. 

#### Genesis 31:2 And Jacob saw the face of Laban; and behold, he was not for him as yesterday and the third day before. 

#### Genesis 31:3 {said And the LORD} to Jacob, Return to the land of your father, and to your family! and I will be with you. 

#### Genesis 31:4 {sending And Jacob}, called Leah and Rachel to the plain where {were the flocks}. 

#### Genesis 31:5 And he said to them, I see the face of your father, that it is not towards me as yesterday and the third day before. But the God of my father was with me. 

#### Genesis 31:6 {also you yourselves But} know that with all my strength I have served to your father. 

#### Genesis 31:7 But your father cheated me, and bartered my wage for the ten lambs. And {did not give to him the God of my father} the power to do evil against me. 

#### Genesis 31:8 If thus he should have said, The colored will be your wage, then {would bear all the flocks} colored. And if he should have said, The white will be your wage, then {would bear all the flocks} white. 

#### Genesis 31:9 And God removed all the herds of your father, and he gave them to me. 

#### Genesis 31:10 And it came to pass when {were stimulated the flocks}, in the womb conceiving, that I saw {with my eyes them} in sleep. And behold, the he-goats and the rams ascended upon the flocks, and the she-goats white-mixed and colored and ashen speckled. 

#### Genesis 31:11 And {said to me the angel of God} during sleep, Jacob. And I said, What is it? 

#### Genesis 31:12 And he said, Look up with your eyes, and see the he-goats and the rams ascending upon the flocks, and the she-goats -- white-mixed and colored and ashen speckled! For I have seen as much as {to you Laban does}. 

#### Genesis 31:13 I am God, the one appearing to you in the place of God, of which you anointed to me there a monument, and vowed to me there a vow. Now then, rise up and go forth from out of this land! And go forth into the land of your birth! 

#### Genesis 31:14 And answering Rachel and Leah said to him, Is there not to us still a portion or inheritance in the house of our father? 

#### Genesis 31:15 Are we not {as the aliens considered} to him? For he has sold us, and by eating up a thing devoured our silver. 

#### Genesis 31:16 All the riches and the glory which {removed the God of our father} will be ours and our children's. Now then as much as {has said to you God}, you do! 

#### Genesis 31:17 {rising up And Jacob}, took his wives, and his children upon the camels. 

#### Genesis 31:18 And he took away all his possessions, and all his belongings, which he procured in Mesopotamia, and all his things to go forth to Isaac his father, in the land of Canaan. 

#### Genesis 31:19 And Laban set out to shear his flocks, {stole and Rachel} the idols of her father. 

#### Genesis 31:20 {hid the fact from And Jacob} Laban the Syrian, so as not to announce to him that he is running away. 

#### Genesis 31:21 And he ran away, himself and all of his. And he passed over the river, and he advanced unto the mountain of Gilead. 

#### Genesis 31:22 And it was announced to Laban the Syrian on the {day third} that Jacob ran away. 

#### Genesis 31:23 And taking all the ones of his brethren with himself, he pursued after him {journey days seven}. And he overtook him in the mountain of Gilead. 

#### Genesis 31:24 {came And God} to Laban the Syrian during sleep in the night, and he said to him, Guard! lest at any time you should speak {against Jacob evil}. 

#### Genesis 31:25 And Laban overtook Jacob. And Jacob pitched his tent in the mountain. And Laban stationed his brethren in the mountain of Gilead. 

#### Genesis 31:26 {said And Laban} to Jacob, What did you do? Why did you secretly run away, and ransacked me, and took away my daughters as captives taken by sword? 

#### Genesis 31:27 For if you announced to me, I would have sent out even you with gladness, and with music, and tambourines, and harps. 

#### Genesis 31:28 And not am I worthy to kiss my children, and my daughters. Now then {unwisely you acted}. 

#### Genesis 31:29 And now {is strong my hand} to do evil against you. But the God of your father yesterday said to me, saying, Guard yourself! lest at any time you should speak {against Jacob evil}. 

#### Genesis 31:30 Now then, you go! For with desire you desired to go forth unto the house of your father; why did you steal my gods? 

#### Genesis 31:31 And answering Jacob said to Laban, For I said, Lest at any time you should remove your daughters from me, and all my things. 

#### Genesis 31:32 And Jacob said, By whomsoever you should find your gods, he shall not live before our brethren. Recognize what is from me of the things of yours, and take them! And he did not recognize among what was his -- not one thing. {did not know But Jacob} that Rachel his wife stole them. 

#### Genesis 31:33 And entering, Laban searched in the house of Leah, and he did not find. And he came forth from out of the house of Leah, and he searched the house of Jacob, and in the house of the two maidservants, and he did not find. And he entered also into the house of Rachel. 

#### Genesis 31:34 And Rachel took the idols, and put them in the packsaddles of the camel, and sat on them. 

#### Genesis 31:35 And she said to her father, Do not {heavily bear}, O master, I shall not be able to rise up before you, for the custom of women is to me. {searched And Laban} in the entire house, and he did not find the idols. 

#### Genesis 31:36 {was provoked to anger And Jacob}, and he quarreled with Laban. And responding Jacob said to Laban, What is my offence? and what is my sin, that you pursued after me? 

#### Genesis 31:37 and that you searched all the items of my house? What did you find from all the items of your house? Put here before your brethren and my brethren, and let them reprove between the two of us! 

#### Genesis 31:38 These twenty years I am with you; your flocks and your goats were not barren, and the rams of your flocks I did not eat. 

#### Genesis 31:39 That taken by wild beasts I have not brought to you. I paid for them by myself, even thefts by day, and thefts by night. 

#### Genesis 31:40 I was {by day burning with the sweltering heat}, and with the icy coldness of the night. And {departed sleep my} from my eyes. 

#### Genesis 31:41 These twenty years I am in your residence. I served you fourteen years for {two daughters your}, and six years among your sheep, and you cheated my wage by ten ewe-lambs. 

#### Genesis 31:42 Unless the God of my father Abraham, and the fear of Isaac was with me, now then would {me empty you have sent}. My humiliation and the toil of my hands God saw, and he reproved you yesterday. 

#### Genesis 31:43 And responding Laban said to Jacob, The daughters are my daughters, and the sons my sons, and the cattle my cattle; and all as much as you see is mine, and the property of my daughters. What shall I do with these women today or the children of them whom they bore? 

#### Genesis 31:44 Now then, come here, we should ordain a covenant, I and you, and it will be a testimony between me and you. 

#### Genesis 31:45 {taking And Jacob} a stone, established it as a monument; 

#### Genesis 31:46 {said And Jacob} to his brethren, Collect together stones! And they collected together stones. And they made a hill. And they ate there upon the hill. 

#### Genesis 31:47 And {called it Laban}, Hill of the Witness, but Jacob called it, The Hill is Witness. 

#### Genesis 31:48 {said And Laban}, this hill witnesses between me and you today. Because of this {was called the name of the place}, Hill Witnesses. 

#### Genesis 31:49 And the vision, which he said, Let God look between me and you, is that we will leave the other from the other. 

#### Genesis 31:50 If you shall humble my daughters, if you should take wives over my daughters, you see no one {with us is} seeing -- God is witness between me and between you. 

#### Genesis 31:51 And Laban said to Jacob, Behold, this hill, and the monument which I stood between me and you; 

#### Genesis 31:52 {witnesses this hill}, and the monument which I stood -- it witnesses. For if I pass over, I to you, neither shall you pass over to me beyond this hill and this monument, for evil. 

#### Genesis 31:53 The God of Abraham and the God of Nahor judges between us. 

#### Genesis 31:54 And Jacob swore by an oath according to the fear of his father Isaac. And he sacrificed a sacrifice in the mountain, and he called his brethren; and they ate and drank, and they went to sleep in the mountain. 

#### Genesis 31:55 {rising up And Laban} in the morning, kissed the sons and daughters of his, and he blessed them. And Laban turned and went forth to his place. 

#### Genesis 32:1 And Jacob went forth into his own way. And having looked up, he saw the camp of God encamped. And {met with him the angels of God}. 

#### Genesis 32:2 {said And Jacob}, when he saw them, {the camp of God This is}. And he called the name of that place, Camps. 

#### Genesis 32:3 {sent And Jacob} messengers in front of him to Esau his brother, into the land of Seir into the region of Edom. 

#### Genesis 32:4 And he gave charge to them, saying, Thus you shall say to my master Esau; Thus says your servant Jacob, {with Laban I sojourned}, and passed time until the present. 

#### Genesis 32:5 And came to me oxen, and donkeys, and sheep, and manservants, and maidservants. And I sent to announce to my master Esau, that {might find your servant} favor before you. 

#### Genesis 32:6 And {returned the messengers} to Jacob, saying, We came to your brother Esau. And behold, he is coming to meet you, and four hundred men with him. 

#### Genesis 32:7 {feared And Jacob} exceedingly, and he was perplexed. And he divided the people, the one with himself, and the oxen, and the sheep into two camps. 

#### Genesis 32:8 And Jacob said, If Esau should come into {camp one} and should smite it, {will be the camp second} for delivering. 

#### Genesis 32:9 {said And Jacob}, The God of my father Abraham, and the God of my father Isaac, O LORD, the one saying to me, Run to the land of your birth! and {good to you I will do}. 

#### Genesis 32:10 It is fit to me for all righteousness, and of all truth, of which you did to your servant; for with {my rod this} I passed over this Jordan, and now I exist in two camps. 

#### Genesis 32:11 Rescue me from the hand of my brother, from the hand of Esau! For I fear him, lest coming he should strike me, and the mother with children. 

#### Genesis 32:12 But you, you said, {good you I will do}, and I will establish your seed as the sand of the sea, which shall not be counted by the multitude. 

#### Genesis 32:13 And he went to sleep there that night. And he took {of which he brought gifts}, and he sent to Esau his brother; 

#### Genesis 32:14 goats -- two hundred; he-goats -- twenty; sheep -- two hundred; rams -- twenty; 

#### Genesis 32:15 camels nursing and their offspring -- thirty; oxen -- forty; bulls -- ten; donkeys -- twenty; and foals -- ten. 

#### Genesis 32:16 And he gave them by hand to his servants a flock alone. And he said to his servants, You go forth in front of me, and {a space make} between flock and flock. 

#### Genesis 32:17 And he gave charge to the first, saying, If {should meet you Esau my brother}, and he should ask you, saying, Who are you? and where might you go? and who are these going before you? 

#### Genesis 32:18 You shall say, Your servant Jacob {gifts has sent} to my master Esau. And behold, he is behind us. 

#### Genesis 32:19 And he gave charge to the first, and to the second, and to the third, and to all the ones going before behind these flocks, saying, According to this saying you speak to Esau when you find him! 

#### Genesis 32:20 And you shall say, Behold, your servant Jacob comes after us. For he said, I will appease his face by the gifts going before him; and after this I will see his countenance, for perhaps he will favorably receive my person. 

#### Genesis 32:21 And {went before the gifts} his face. And he went to sleep that night in the camp. 

#### Genesis 32:22 And rising that night, he took the two wives, and the two maidservants, and the eleven children of his, and he passed over the ford of the Jabbok. 

#### Genesis 32:23 And he took them, and passed over the rushing stream, and he caused to pass over all the ones of his. 

#### Genesis 32:24 {was left behind And Jacob} alone, and {wrestled a man} with him until morning. 

#### Genesis 32:25 And he saw that he was not able to prevail against him; and he touched the wide part of his thigh, and he paralyzed the wide part of the thigh of Jacob in his wrestling with him. 

#### Genesis 32:26 And he said to him, You send me away! {ascended for the dawn}. And he said, No way will I send you away if {not me you should bless}. 

#### Genesis 32:27 And he said to him, What {name your is}? And he said, Jacob. 

#### Genesis 32:28 And he said to him, {not shall be called any longer your name} Jacob, but Israel will be your name; for you grew in strength against God, and against {men mighty}. 

#### Genesis 32:29 {asked And Jacob} and said, Announce to me your name! And he said, Why is this you ask my name, which is wonderful? And he blessed him there. 

#### Genesis 32:30 And Jacob called the name of that place, Sight of God. For I saw God face to face, and {was delivered my life}. 

#### Genesis 32:31 {arose And to him the sun} when he went by the form of God, but he was limping in his thigh. 

#### Genesis 32:32 Because of this, no way {eat do the sons of Israel} the nerve by which he was paralyzed, which is upon the wide part of the thigh, until this day. For he touched the wide part of the thigh of Jacob, of the nerve, in which he was paralyzed. 

#### Genesis 33:1 {looking up And Jacob} saw. And behold, Esau his brother was coming, and four hundred men with him. And Jacob divided the servants unto Leah and unto Rachel, and the two maidservants. 

#### Genesis 33:2 And he made the two maidservants and their sons go in first, and Leah and her children after, and Rachel and Joseph last. 

#### Genesis 33:3 But he went forth in front of them, and did obeisance on the ground seven times, while approaching to his brother. 

#### Genesis 33:4 And Esau ran up to meet him. And taking hold of him, he kissed him. And he fell upon his neck. And he kissed him, and they {wept both}. 

#### Genesis 33:5 And Esau looking up, he saw the women and the children. And he said, What {these to you are}? And he said, The children which God showed mercy on your servant. 

#### Genesis 33:6 And {drew near the maidservants and their children}, and did obeisance. 

#### Genesis 33:7 And Leah drew near and her children, and they did obeisance. And after this {drew near Rachel and Joseph}, and they did obeisance. 

#### Genesis 33:8 And he said, What {these to you are}, all these camps which I have met? And he said, that {should find your servant} favor before you, O master. 

#### Genesis 33:9 {said And Esau}, There is to me much, O brother, let {be yours things your}! 

#### Genesis 33:10 {said And Jacob}, If I found favor before you, take the gifts by my hands! Because of this I saw your face, as if one may have seen the face of God, and you shall think well of me. 

#### Genesis 33:11 Take the things of my blessing, which I brought to you! for {showed mercy on me God}, and there is to me all things. And he forced him, and he took. 

#### Genesis 33:12 And he said, Departing we will go straight. 

#### Genesis 33:13 And he said to him, My master knows that the children are tender, and the sheep and the oxen are giving birth to me. If then I should drive them {day one more will die all the cattle}. 

#### Genesis 33:14 Let {go forth my master} in front of his servant! and I shall gain strength in the way according to the ease of the trek before me, and according to the foot of the youngsters, until my coming to my master in Seir. 

#### Genesis 33:15 {said And Esau}, I will leave behind with you some of the people of the ones with me. And he said, Why this? It is enough that I found favor before you, O lord. 

#### Genesis 33:16 {returned And Esau} in that day unto his journey to Seir. 

#### Genesis 33:17 And Jacob departed to Tents. And he made himself there a residence, and {for his cattle he made tented shelters}. On account of this they call the name of that place, Tents. 

#### Genesis 33:18 And Jacob came to Shalem, a city of Shechem, which is in the land of Canaan, when he returned back from Mesopotamia Syria. And he camped before the face of the city. 

#### Genesis 33:19 And he acquired the portion of the field which sat there by his tent, from Hamor father of Shechem, for a hundred lambs. 

#### Genesis 33:20 And he set up there an altar, and called upon the God of Israel. 

#### Genesis 34:1 And went forth Dinah, the daughter whom Leah bore to Jacob, to study the daughters of the native inhabitants. 

#### Genesis 34:2 And {beheld her Shechem}, the son of Hamor the Hivite, the ruler of the land. And taking her, he went to bed with her, and humbled her. 

#### Genesis 34:3 And he took heed to the soul of Dinah the daughter of Jacob. And he loved the virgin, and he spoke concerning the thought of her virgin state. 

#### Genesis 34:4 And said Shechem to Hamor his father, saying, Take for me this maidservant for a wife. 

#### Genesis 34:5 And Jacob heard that {defiled the son of Hamor} Dinah his daughter. But his sons were with his cattle in the plain. {remained silent And Jacob} until they came. 

#### Genesis 34:6 And came forth Hamor the father of Shechem to Jacob to speak to him. 

#### Genesis 34:7 And the sons of Jacob came from the plain. And as they heard, {were vexed the men}, and it was distressing to them exceedingly. For {an indecent act he did} in Israel, going to bed with the daughter of Jacob. And not thus shall it be. 

#### Genesis 34:8 And Hamor spoke to them, saying, Shechem my son prefers {in his soul your daughter}. Give her then to him as wife! 

#### Genesis 34:9 And be allied by marriage to us! {your daughters You give us}, and {our daughters you take} for your sons! 

#### Genesis 34:10 And {with us dwell}! And the land -- behold, it is spacious before you; you dwell and do trade in it, and acquire possessions in it! 

#### Genesis 34:11 {said And Shechem} to her father, and to her brothers, I want to find favor before you, and what ever you should have said we will give. 

#### Genesis 34:12 You multiply the dowry exceedingly! and I will give in so far as whatever you should have said to me. And you shall give to me this child as wife. 

#### Genesis 34:13 {responded And the sons of Jacob} to Shechem and Hamor his father with treachery. And they spoke to them, for they defiled Dinah their sister. 

#### Genesis 34:14 And said to them Simeon and Levi the brothers of Dinah, We shall not be able to do this matter, to give our sister to a man who has a foreskin, for it is scorn to us. 

#### Genesis 34:15 Only in this we will be like you, and dwell among you, if you should become as us and we you, in the circumcision {of yours of every male}. 

#### Genesis 34:16 And we will give our daughters to you, and from your daughters we will take to ourselves wives, and we will live by you, and we will be {race one}. 

#### Genesis 34:17 But if you should not listen to us, of the being circumcised, taking our daughter, we shall go forth. 

#### Genesis 34:18 And {were pleasing the words} before Hamor, and before Shechem the son of Hamor. 

#### Genesis 34:19 And {did not pass time the young man} to do this word, for he clung to the daughter of Jacob. And he was most honorable of all of the ones in the house of his father. 

#### Genesis 34:20 {came And Hamor and Shechem his son} to the gate of their city, and spoke to the men of their city, saying, 

#### Genesis 34:21 These men are peaceable with us; let them live upon the land, and let them trade in it! And the land, behold, it is spacious before them; {of their daughters we shall take to ourselves wives}, and {daughters we shall give our} to them. 

#### Genesis 34:22 In this only will {be like us the men}, to dwell with us, so as to be {people one} -- in the being circumcised of us every male, as also they have been circumcised. 

#### Genesis 34:23 And their cattle, and the four-footed animals, and their possessions -- {not ours will they be}? Only in this, should we be like them, and they will live with us. 

#### Genesis 34:24 And they listened to Hamor and Shechem his son, and all the ones going forth at the gate of their city. And they were circumcised in the flesh of their foreskin -- every male. 

#### Genesis 34:25 And it came to pass in the {day third}, when they were in misery, {taking the two sons of Jacob Simeon and Levi brothers of Dinah each} his sword, even entered to the city safely, and killed every male. 

#### Genesis 34:26 Also Hamor and Shechem his son they killed by the mouth of the sword. And they took Dinah from the house of Shechem, and went forth. 

#### Genesis 34:27 And the sons of Jacob entered unto the wounded, and plundered the city in which {was defiled Dinah their sister}. 

#### Genesis 34:28 And their sheep, and their oxen, and their donkeys, as much as was in the city, and as much as was in the plain, they took. 

#### Genesis 34:29 And all their persons, and all their belongings, and their women they captured. And they plundered as much as was in the city, and as much as was in the houses. 

#### Genesis 34:30 {said And Jacob} to Simeon and Levi, {me detested You have made}, so as {wicked for me to be} to all the ones dwelling the land, among both the Canaanites and among the Perizzites. And I am very few in number. And gathering against me, they shall cut me down, and I shall be obliterated, I and my house. 

#### Genesis 34:31 And they said, But as a harlot they treated our sister. 

#### Genesis 35:1 {said And God} to Jacob, Rising up, ascend unto the place Beth-el! And live there, and make there an altar to God! to the one appearing to you in the running away from the face of Esau your brother. 

#### Genesis 35:2 {said And Jacob} to his house, and to all the ones with him, Take away {gods the alien} from your midst, and cleanse and change your robes! 

#### Genesis 35:3 And rising up, let us ascend unto Beth-el, and let us make there an altar to God! to the one taking heed of me in the day of affliction, who was with me, and preserved me in the way which I went. 

#### Genesis 35:4 And they gave to Jacob {gods the alien}, which were in their hands, and the ear-rings in their ears. And {hid them Jacob} under the turpentine tree, the one in Shechem. And he destroyed them unto today's day. 

#### Genesis 35:5 And Israel lifted away from Shechem. And there was a fear of God upon the cities round about them. And they did not pursue after the sons of Israel. 

#### Genesis 35:6 {came And Jacob} into Luz, which is in the land of Canaan, which is Beth-el, he and all the people who were with him. 

#### Genesis 35:7 And he built there an altar, and he called the name of the place, Beth-el, for there {appeared to him God} in his running away from the face of Esau his brother. 

#### Genesis 35:8 {died And Deborah the nurse of Rebekah}, and they entombed her below Beth-el, under the acorn tree, and Jacob called the name of it, Acorn tree of Mourning. 

#### Genesis 35:9 {appeared And God} to Jacob still in Luz, when he came from out of Mesopotamia of Syria. And {blessed him God}. 

#### Genesis 35:10 And {said to him God}, Your name shall not be called any longer Jacob, but Israel will be your name. And he called his name Israel. 

#### Genesis 35:11 {said And to him God}, I am your God. Grow and multiply! Nations and gatherings of nations will be from you, and kings {from your loin shall come forth}. 

#### Genesis 35:12 And the land which I gave Abraham and Isaac, {to you I give it}. And to your seed after you I shall give this land. 

#### Genesis 35:13 {ascended And God} from him, from the place where he spoke with him. 

#### Genesis 35:14 And Jacob set up a monument in the place in which {spoke with him God} -- {monument a stone}. And he offered upon it a libation, and he poured upon it olive oil. 

#### Genesis 35:15 And Jacob called the name of the place in which {spoke with him there God}, Beth-el. 

#### Genesis 35:16 {departed And Jacob} from Beth-el, and he pitched his tent beyond the tower of Gader. And it came to pass when he approached Chabratha, to come into Ephrath, Rachel bore. And in the giving birth she suffered birth pangs. 

#### Genesis 35:17 And it came to pass in her harshly bearing, {said to her the midwife}, Be of courage! for also this {to you is a son}. 

#### Genesis 35:18 And it came to pass in her letting go the soul, for she was dying, she called his name, Son of my Grief; but the father called his name, Benjamin. 

#### Genesis 35:19 {died And Rachel}, and she was entombed in the way of Ephrath, this is Beth-lehem. 

#### Genesis 35:20 And Jacob set up a monument for her memorial. This is the monument upon the tomb of Rachel, until this day. 

#### Genesis 35:21 And it came to pass when Israel dwelt in that land, Reuben went and bedded with Bilhah, the concubine of his father Jacob. And Israel heard, and {wicked it appeared} before him. 

#### Genesis 35:22 {were And the sons of Jacob} twelve. 

#### Genesis 35:23 The sons of Leah, the first-born of Jacob, Reuben, Simeon, Levi, Judah, Issachar, Zebulun. 

#### Genesis 35:24 And the sons of Rachel, Joseph and Benjamin. 

#### Genesis 35:25 And the sons of Bilhah the maidservant of Rachel, Dan and Naphtali. 

#### Genesis 35:26 And the sons of Zilpah the maidservant of Leah, Gad and Asher. These are the sons of Jacob, the ones who were born to him in Mesopotamia of Syria. 

#### Genesis 35:27 {came And Jacob} to Isaac his father in Mamre, in a city of the plain -- this is Hebron, in the land of Canaan, where {sojourned Abraham and Isaac}. 

#### Genesis 35:28 And were the days of Isaac which he lived, {years a hundred eighty}. 

#### Genesis 35:29 And failing, Isaac died. And he was added to his family, older and full of days. And {entombed him Esau and Jacob two sons his}. 

#### Genesis 36:1 And these are the generations of Esau -- he is Edom. 

#### Genesis 36:2 And Esau took wives to himself from the daughters of the Canaanites -- Adah, daughter of Elon the Hittite; and Aholibamah, daughter of Anah the son of Zibeon the Hivite; 

#### Genesis 36:3 and Bashemath, daughter of Ishmael, sister of Nebajoth. 

#### Genesis 36:4 {bore And to him Adah} Eliphaz; and Bashemath bore Reuel. 

#### Genesis 36:5 And Aholibamah bore Jeush, and Jaalam, and Korah. These are the sons of Esau, born to him in the land of Canaan. 

#### Genesis 36:6 {took And Esau} his wives, and his sons, and his daughters, and all the persons of his house, and all his possessions, and all the cattle, and all as much as he acquired, and all as much as he procured in the land of Canaan. And Esau went from the land of Canaan, from the face of Jacob his brother. 

#### Genesis 36:7 For it was that their possessions were many to live together. And {was not able the land of their sojourning} to bear them, because of the multitude of their possessions. 

#### Genesis 36:8 {dwelt And Esau} in the mountain of Seir. Esau, he is Edom. 

#### Genesis 36:9 And these are the generations of Esau, father of Edom in the mountain of Seir. 

#### Genesis 36:10 And these were the names of the sons of Esau -- Eliphaz son of Adah, wife of Esau, and Reuel, son of Bashemath wife of Esau. 

#### Genesis 36:11 And born to Eliphaz -- sons Teman, Omar, Zepho, Gatam, and Kenaz. 

#### Genesis 36:12 And Timnah was a concubine of Eliphaz, the son of Esau. And she bore to Eliphaz, Amalek. These were the sons of Adah, wife of Esau. 

#### Genesis 36:13 And these are the sons of Reuel -- Nahath, Zerah, Shammah, and Mizzah. These were the sons of Bashemath wife of Esau. 

#### Genesis 36:14 And these were the sons of Aholibamah daughter of Anah, of the son of Zibeon wife of Esau; and she bore to Esau Jeush, and Jaalam, and Korah. 

#### Genesis 36:15 These were the princes, sons of Esau. The sons of Eliphaz first-born of Esau -- prince Teman, prince Omar, prince Zepho, prince Kenaz, 

#### Genesis 36:16 prince Korah, prince Gatam, prince Amalek. These were the princes of Eliphaz in the land of Edom; and these were the sons of Adah. 

#### Genesis 36:17 And these were the sons of Reuel, son of Esau -- prince Nahath, prince Zerah, prince Shammah, prince Mizzah. These were the princes of Reuel in the land of Edom. These were the sons of Bashemath, wife of Esau. 

#### Genesis 36:18 And these were the sons of Aholibamah, wife of Esau -- prince Jeush, prince Jaalam, prince Korah. These were the princes of Aholibamah, daughter of Anah, wife of Esau. 

#### Genesis 36:19 These were the sons of Esau. And these were their princes. These are sons of Edom. 

#### Genesis 36:20 And these were the sons of Seir the Horite, of the one dwelling the land -- Lotan, Shobal, Zibeon, Anah, 

#### Genesis 36:21 and Dishon, and Ezer, and Dishan. These were the princes of the Horite, of the son of Seir, in the land of Edom. 

#### Genesis 36:22 And were born sons of Lotan -- Hori and Heman. And the sister of Lotan -- Timna. 

#### Genesis 36:23 And these were the sons of Shobal -- Golam, and Manahath, and Ebal, and Shepho, and Onam. 

#### Genesis 36:24 And these were the sons of Zibeon -- Ajah and Anah; this Anah is who found the mules in the wilderness when he was feeding the beasts of burden of Zibeon his father. 

#### Genesis 36:25 And these were the sons of Anah -- Dishon, and Aholibama was daughter of Anah. 

#### Genesis 36:26 And these were the sons of Dishon -- Hemdan, and Eshban, and Ithran, and Cheran. 

#### Genesis 36:27 And these were the sons of Ezer -- Bilhan, and Zaavan, and Akan. 

#### Genesis 36:28 And these were the sons of Dishan -- Uz and Aran. 

#### Genesis 36:29 And these were the princes of Horites -- prince Lotan, prince Shobal, prince Zibeon, prince Anah, 

#### Genesis 36:30 prince Dishon, prince Ezer, prince Dishan. These were the princes of Hori, in their governing in the land of Edom. 

#### Genesis 36:31 And these were the kings, the ones reigning in the land of Edom before the reigning of a king in Israel. 

#### Genesis 36:32 And {reigned in Edom Balak son of Beor}, and the name of his city -- Dinhabah. 

#### Genesis 36:33 {died And Balak}, and there reigned instead of him -- Jobab, son of Zerah, from Bozrah. 

#### Genesis 36:34 {died And Jobab}, and reigned instead of him -- Husham, from the land of Temani. 

#### Genesis 36:35 {died And Husham}, and reigned instead of him, Hadad son of Bedad, the one cutting off Midian in the plain of Moab. And the name of his city -- Getham. 

#### Genesis 36:36 {died And Hadad}, and reigned instead of him -- Samiah from Masrekah. 

#### Genesis 36:37 {died And Samiah}, and reigned instead of him -- Saul from Rehoboth of the place by the river. 

#### Genesis 36:38 {died And Saul}, and reigned instead of him -- Baal-hanan son of Achbor. 

#### Genesis 36:39 {died And Baal-hanan son of Achbor}, and reigned instead of him -- Arad, son of Barad; and the name of his city -- Phogor; and the name of his wife -- Mehetabel, daughter of Matred, son of Mezahab. 

#### Genesis 36:40 These are the names of the princes of Esau, in their tribes according to their place, in their regions, and in their nations -- prince Timnah, prince Alvah, prince Jetheth, 

#### Genesis 36:41 prince Aholibamah, prince Elah, prince Pinon, 

#### Genesis 36:42 prince Kenaz, prince Teman, prince Mibzar, 

#### Genesis 36:43 prince Magdiel, prince Zaphoi. These are the princes of Edom, in the buildings in the land of their property. This is Esau, father of Edom. 

#### Genesis 37:1 {dwelt And Jacob} in the land of which {sojourned his father} in the land of Canaan. 

#### Genesis 37:2 These are the generations of Jacob. And Joseph {ten and seven years old was} tending the sheep of his father with his brothers, being young among the sons of Bilhah, and with the sons of Zilpah, the wives of his father. And they brought against Joseph {fault a bad} to Israel their father. 

#### Genesis 37:3 But Jacob loved Joseph beyond all his sons, for {the son of old age he was to him}. And he made for him {garment a colored}. 

#### Genesis 37:4 {seeing And his brothers} that {him the father was fond of} over all of his sons, they detested him, and were not able to speak to him, not one thing peaceable. 

#### Genesis 37:5 {dreaming And Joseph} a dream, reported it to his brothers. 

#### Genesis 37:6 And he said to them, Hear this dream which I dreamed! 

#### Genesis 37:7 I imagined you all were binding sheaves in the middle of the plain. And there rose up my sheaf, and it was straight up. {moving around And sheaves your}, did obeisance to my sheaf. 

#### Genesis 37:8 {said And to him his brothers}, Do you mean in reigning you will reign over us, or in dominating you will dominate us? And they added still to detest him because of his dreams, and because of his words. 

#### Genesis 37:9 And he saw {dream another}. And he described it to his father, and to his brothers. And he said, Behold, I dreamed {dream another}; as if the sun, and the moon, and eleven stars did obeisance to me. 

#### Genesis 37:10 And {reproached him his father}, and said to him, What is this dream which you dreamed? Is it so indeed in having come I will come also, and your mother, and your brothers, to do obeisance to you upon the ground? 

#### Genesis 37:11 {envied And him his brothers}, but his father kept the saying. 

#### Genesis 37:12 {went And his brothers} to graze the sheep of their father in Shechem. 

#### Genesis 37:13 And Israel said to Joseph, Did not your brothers tend in Shechem? Come, I will send you to them. And he said to him, Behold, I am ready. 

#### Genesis 37:14 {said And to him Israel}, In going see if {are in health your brothers} and the sheep, and announce it to me! And he sent him from the valley of Hebron. And he came into Shechem. 

#### Genesis 37:15 And {found him a man} wandering in the plain. {asked And him the man}, saying, What do you seek? 

#### Genesis 37:16 And he said, {my brothers I seek}; report to me where they graze! 

#### Genesis 37:17 {said And to him the man}, They have departed from here. For I heard them saying, Let us go unto Dothan. And Joseph went after his brothers, and found them in Dothan. 

#### Genesis 37:18 And they spied him far off before his approaching to them. And they acted wickedly to kill him. 

#### Genesis 37:19 And said each to his brother, Behold, that dreamer comes. 

#### Genesis 37:20 Now then, come, let us kill him and toss him into one of the wells! And we shall say, {wild beast A ferocious} devoured him. And we shall see what will be of his dreams. 

#### Genesis 37:21 {hearing And Reuben}, rescued him from out of their hands. And he said, Do not strike him as far as his life. 

#### Genesis 37:22 {said And to them Reuben}, You should not shed blood, put him into one of these wells of the ones in the wilderness, {a hand and not bear} against him, that he might rescue him from out of their hands, and that he might give him to his father. 

#### Genesis 37:23 And it came to pass when Joseph came to his brothers, they took {off Joseph garment the colored}, the one around him. 

#### Genesis 37:24 And taking him, they tossed him into the well. But the well was empty, {water it did not have}. 

#### Genesis 37:25 And they sat to eat bread. And looking up with the eyes they saw. And behold, journeying Ishmaelites having come from Gilead, and their camels full of incenses, and balm, and balsam. And they were going leading down into Egypt. 

#### Genesis 37:26 {said And Judah} to his brothers, What profit if we kill our brother, and hide his blood? 

#### Genesis 37:27 Come let us give him to these Ishmaelites, and the hands of ours, let them not be upon him! for he is our brother, and {flesh he is our}. {hearkened And his brothers}. 

#### Genesis 37:28 And {came near the men}, the Midianite merchants, and they drew out and hauled Joseph from out of the well. And {rendered for Joseph the Ishmaelites} twenty pieces of gold. And they led Joseph into Egypt. 

#### Genesis 37:29 {returned And Ruben} upon the well, and he did not see Joseph in the well, and he tore his clothes. 

#### Genesis 37:30 And he turned towards his brothers, and he said, The boy is not, and I, where shall I go yet? 

#### Genesis 37:31 And taking the garment of Joseph, they slew a kid of the goats, and tainted the garment in the blood. 

#### Genesis 37:32 And they sent {garment the colored}, and they carried it to their father, and said, This we found, do you recognize if the garment {son is of your} or not? 

#### Genesis 37:33 And he recognized it, and said, The garment {of my son is}, {wild beast a ferocious} devoured him, a wild beast seized Joseph. 

#### Genesis 37:34 {tore And Jacob} his clothes, and placed sackcloth upon his loin, and mourned for his son {days many}. 

#### Genesis 37:35 {came together And all his sons and daughters}. And they came to comfort him, and he did not want to be comforted, saying that, I will go down to my son in mourning into Hades. And {wept for him his father}. 

#### Genesis 37:36 And the Midianites gave Joseph into Egypt to Potiphar the castrato of Pharaoh -- the chief guard. 

#### Genesis 38:1 And it came to pass in that time, Judah went from his brothers, and he arrived unto before a certain man of Adullam, whose name was Hirah. 

#### Genesis 38:2 And {saw there Judah} a daughter of a Canaanite man, whose name was Shuah. And he took her, and entered to her. 

#### Genesis 38:3 And she conceived and bore a son, and she called his name, Er. 

#### Genesis 38:4 And she conceived and bore a son still again, and she called his name, Onan. 

#### Genesis 38:5 And adding she bore a son, and she called his name, Shelah. And she was in Chezib when she bore them. 

#### Genesis 38:6 And Judah took a wife for Er his first-born, whose name was Tamar. 

#### Genesis 38:7 And it came to pass Er the first-born of Judah was wicked before the LORD; and {killed him God}. 

#### Genesis 38:8 {said And Judah} to Onan, Enter to the wife of your brother, and ally to her by marriage, and raise up seed to your brother! 

#### Genesis 38:9 {knowing And Onan} that {not his will be the seed} -- that it came to pass whenever he entered to {wife his brother's}, he discharged upon the ground, to not give seed to his brother. 

#### Genesis 38:10 {wicked And it appeared} before God that he did this; and he put to death also this one. 

#### Genesis 38:11 {said And Judah} to Tamar his daughter-in-law, You sit as a widow in the house of your father! until {older becomes Shelah my son}. For he said, Lest at any time {should die also this one} as also his brothers. {going forth And Tamar} settled in the house of her father. 

#### Genesis 38:12 {multiplied And the days}, and {died Shuah the wife of Judah}. And being comforted, Judah ascended to the shearing of his sheep, himself and Hirah his shepherd the Adullamite, unto Timnath. 

#### Genesis 38:13 And it was reported to Tamar his daughter-in-law, saying, Behold, your father-in-law ascends to Timnath, to shear his sheep. 

#### Genesis 38:14 And removing the garments of the widowhood from herself, she put around a lightweight covering, and bedecked herself, and sat by the gates of Enaim, which is in the byway of Timnath. For she knew that {older was Shelah}, but he did not give her to him as wife. 

#### Genesis 38:15 And {seeing her Judah}, assumed her to be a harlot. For she covered up her face, and {not he recognized her}. 

#### Genesis 38:16 And he turned aside to her in the way. And he said to her, Allow me to enter to you. For he did not know that {his daughter-in-law she is}. And she said, What will you give to me, if you should enter to me? 

#### Genesis 38:17 And he said, I will send to you a kid of the goats from out of my flocks. And she said, You should give a deposit until you send it. 

#### Genesis 38:18 And he said, What deposit shall I give to you? And she said, Your ring, and the pendant, and the rod in your hand. And he gave them to her, and he entered to her. And {in the womb she conceived} from him. 

#### Genesis 38:19 And rising up she went forth. And she removed her lightweight garment from herself, and put on the garments of her widowhood. 

#### Genesis 38:20 {sent And Judah} the kid of the goats by the hand of his shepherd the Adullamite, to deliver by him to the woman the deposit. And he did not find her. 

#### Genesis 38:21 And he asked the men of the place, Where is the harlot, the one being in Enaim upon the way? And they said, There was no {here harlot}. 

#### Genesis 38:22 And he returned to Judah, and said, I did not find her, and the men, the ones from the place, say, There was no {here harlot}. 

#### Genesis 38:23 {said And Judah}, Let her have them, but lest at any time we should be ridiculed, I indeed sent this kid, but you have not found her. 

#### Genesis 38:24 And it came to pass after three months, it was announced to Judah, saying, {fornicated Tamar your daughter-in-law}. And behold, {in the womb she has one} out of harlotry. {said And Judah}, Lead her out, and let her be incinerated! 

#### Genesis 38:25 {her And while leading}, she sent to her father-in-law, saying, From the man whom these things are I {in the womb have one}. And she said, Recognize whose ring and pendant and rod these are! 

#### Genesis 38:26 {realized And Judah}, and said, Tamar has done justice rather than I, because I did not give her Shelah my son. And he did not add any longer to know her. 

#### Genesis 38:27 And it came to pass when she was bearing, that thus there were twins in her womb. 

#### Genesis 38:28 And it came to pass in her bearing, the one put forth first the hand. And taking it, the midwife tied upon his hand a scarlet thread, saying, This one will come forth prior. 

#### Genesis 38:29 And as he retracted the hand, straightway came forth his brother. And she said, Why was {cut because of you the barrier}? And she called his name, Pharez. 

#### Genesis 38:30 And after this came forth his brother, of which was upon his hand the scarlet thread. And she called his name Zarah. 

#### Genesis 39:1 And Joseph was carried down into Egypt. And {acquired him Potiphar}, the eunuch of Pharaoh, the chief guard, an Egyptian man, from out of the hands of the Ishmaelites, the ones that led him there. 

#### Genesis 39:2 And the LORD was with Joseph. And he was a man succeeding in things. And he was in the house by his master the Egyptian. 

#### Genesis 39:3 {saw And his master} that the LORD was with him, and whatever as much as he should do, the LORD prospered the way by his hands. 

#### Genesis 39:4 And Joseph found favor before his master. And he was well-pleasing to him, and he placed him over his house; and all as much as was his he gave through the hand of Joseph. 

#### Genesis 39:5 And it came to pass after placing him over his house, and over all as much as was his, that the LORD blessed the house of the Egyptian on account of Joseph; and he became a blessing for his master in all his possessions in the house, and in his fields. 

#### Genesis 39:6 And he committed to care all as much as was his into the hand of Joseph. And he did not know the things about his own -- not one thing, except the bread which he ate. And Joseph was good to the sight, and handsome in appearance -- exceedingly. 

#### Genesis 39:7 And it happened after these things, and {put the wife of his master} her eyes upon Joseph. And she said, Come to bed with me! 

#### Genesis 39:8 But he was not willing. And he said to the wife of his master, If my master does not know on account of me one thing in his house, and all as much as is his he gave into my hands, 

#### Genesis 39:9 and not exists in this house one thing outside of me, nor is {secretly removed from me one thing}, besides you, on account of you {his wife being}, then how should I do {thing this wicked}, and sin before God? 

#### Genesis 39:10 And when she spoke to Joseph day by day, and he did not obey her to sleep with her, to be intimate with her. 

#### Genesis 39:11 And it came to pass on such a day, Joseph entered into the house to do his works, and no one was in the house inside. 

#### Genesis 39:12 And she drew him by his clothes, saying, Come to bed with me! And leaving behind his clothes in her hands, he fled and went forth outside. 

#### Genesis 39:13 And it came to pass as she saw that leaving behind his clothes in her hands, he fled and went forth outside, 

#### Genesis 39:14 that she called the ones being in the house, and said to them, saying, See! he brought in to us a Hebrew servant to mock us. He entered to me, saying, Come to bed with me! And I yelled {voice a great}. 

#### Genesis 39:15 And in his hearing that {was raised my voice}, and I yelled, leaving behind his clothes by me, he fled, and he went forth outside. 

#### Genesis 39:16 And she left the clothes by herself, until {came the master} into his house. 

#### Genesis 39:17 And she spoke to him concerning these things, saying, There entered to me the Hebrew servant, whom you brought in to us, to mock me. And he said to me, I will come to bed with you. 

#### Genesis 39:18 But as he heard that I raised my voice, and I yelled, leaving behind his clothes by me, he fled, and went forth outside. 

#### Genesis 39:19 And it happened as {heard his master} the words of his wife, as much as she spoke to him, saying, Thus {did to me your servant}, that he was enraged with anger. 

#### Genesis 39:20 And {taking the master} Joseph, put him into the fortress, in the place in which the prisoners of the king were held there in the fortress. 

#### Genesis 39:21 And the LORD was with Joseph, and he poured down upon him mercy; and he gave to him favor before the chief jailer. 

#### Genesis 39:22 And {gave the chief jailer} the jail over to the hand of Joseph, and all the ones being taken away, as many as were in the jail, and all as much as they do there, he was doing. 

#### Genesis 39:23 For not was the chief jailer of the jail knowing anything concerning him -- not one thing. For all was through the hand of Joseph, because of the reason the LORD {with him being}. And as much as he did, the LORD prospered the way in his hands. 

#### Genesis 40:1 And it came to pass after these things, {sinned the chief wine taster of the king of Egypt}, and the chief baker against their master the king of Egypt. 

#### Genesis 40:2 And Pharaoh was provoked to anger over {two eunuchs his} -- over the chief wine taster and over the chief baker. 

#### Genesis 40:3 And he put them under guard in the jail, into the place where Joseph had been taken away there. 

#### Genesis 40:4 And {combined the chief jailer} them to Joseph, and he stood beside them. And they were some days under guard. 

#### Genesis 40:5 And {saw both} a dream in one night. And the vision of the dream of the chief wine taster and the chief baker, the ones who were in service to the king of Egypt, the ones being in the jail, was this. 

#### Genesis 40:6 {entered And to them Joseph} in the morning, and he saw them, and they were disturbed. 

#### Genesis 40:7 And he asked the eunuchs of Pharaoh, who were with him under guard, by his master, saying, Why is it that your faces are looking downcast today? 

#### Genesis 40:8 And they said to him, {a dream We saw}, and the interpreting it is not. {said And to them Joseph}, {not through God the explanation of them Is}? Describe them then to me. 

#### Genesis 40:9 And {described the chief wine taster} his dream to Joseph. And he said, In my sleep there was a grapevine before me. 

#### Genesis 40:10 And in the grapevine three lower branches; and it flourished offering {buds mature} -- the clusters of the grape. 

#### Genesis 40:11 And the cup of Pharaoh was in my hand, and I took the grape cluster and squeezed it into the cup, and gave the cup into the hand of Pharaoh. 

#### Genesis 40:12 And {said to him Joseph}, This is the interpretation of it. The three lower branches {three days are}. 

#### Genesis 40:13 In yet three days and Pharaoh will remember your office, and restore you to your office of chief wine taster, and you will give the cup to Pharaoh, into his hand according to {office your former}, as you were of the wine servers. 

#### Genesis 40:14 But remember me of yourself, whenever good happens to you, and you shall do with me an act of mercy. And you shall remind {concerning me Pharaoh}, and lead me from this fortress. 

#### Genesis 40:15 For by stealth I was stolen from the land of the Hebrews, and here I did not do anything, but they put me into this pit. 

#### Genesis 40:16 And {saw the chief baker} that rightly he interpreted, and he said to Joseph, I also saw a dream, and I imagined three bins of groats, lifted upon my head. 

#### Genesis 40:17 And in the bin above, items of all kinds of things of which Pharaoh eats -- the work of a baker. And the birds of the heaven ate them from the bin upon my head. 

#### Genesis 40:18 And answering Joseph said to him, This is the interpretation of it. The three bins {three days are}. 

#### Genesis 40:19 Yet in three days and Pharaoh will remove your head from you, and hang you upon a timber, and {will eat the birds of the heaven} the flesh from you. 

#### Genesis 40:20 And it came to pass in the {day third}, {day the birth that it was} of Pharaoh, and he made a banquet for all his servants, and he remembered concerning the chief wine taster, and the office of the chief baker in the midst of his servants. 

#### Genesis 40:21 And he restored the chief wine taster to his office, and he gave the cup unto the hand of Pharaoh. 

#### Genesis 40:22 And the chief baker he hung, as {interpreted to them Joseph}. 

#### Genesis 40:23 And {remembered not the chief wine taster} Joseph, but forgot him. 

#### Genesis 41:1 And it came to pass after two years of days, Pharaoh saw a dream. He imagined standing at the river. 

#### Genesis 41:2 And behold, as if from the river ascended seven oxen good to the sight and choice in the flesh; and they were grazing in the reed-grass. 

#### Genesis 41:3 And another seven oxen ascended after these from out of the river, shameful to the sight and thin in the flesh, and feeding by the oxen by the edge of the river. 

#### Genesis 41:4 And {ate up the seven oxen shameful and thin in the flesh} the seven oxen good to the sight and choice. {arose And Pharaoh}. 

#### Genesis 41:5 And he dreamed the second time. And behold, seven {ears of corn ascended in the lower branch one choice and good}. 

#### Genesis 41:6 And behold, seven ears of corn, thin and destroyed by the wind grew up after them. 

#### Genesis 41:7 And {swallowed down the seven ears of corn thin and destroyed by wind} the seven {ears of corn choice and full}. {arose And Pharaoh}, and it was a dream. 

#### Genesis 41:8 And it came to pass in the morning and {was disturbed his soul}. And sending, he called all the expositors of Egypt, and all her wise men. And {described to them Pharaoh} his dream. And there was no one reporting it to Pharaoh. 

#### Genesis 41:9 And {spoke the chief wine taster} to Pharaoh, saying, My sin I call to mind today. 

#### Genesis 41:10 Pharaoh was provoked to anger against his servants, and he put us under guard in the house of the chief guard -- both me and the chief baker. 

#### Genesis 41:11 And we saw a dream, both in {night one}, I and he, each according to his dream saw. 

#### Genesis 41:12 And there was there with us a young Hebrew servant of the chief guard. And we described to him, and he interpreted to us. 

#### Genesis 41:13 And it came to pass as he interpreted to us, so also it came to pass, both me being restored to my office, and that one being hanged. 

#### Genesis 41:14 {having sent And Pharaoh}, called for Joseph. And they led him from the fortress, and shaved him, and changed his apparel, and he came to Pharaoh. 

#### Genesis 41:15 {said And Pharaoh} to Joseph, {a dream I have seen}, and {not one interpreting there is} it. But I have heard concerning you, saying, In your hearing dreams you interpret them. 

#### Genesis 41:16 {answering And Joseph} to Pharaoh said, Without God {shall not be answered deliverance} to Pharaoh. 

#### Genesis 41:17 {spoke And Pharaoh} to Joseph, saying, In my sleep I imagined standing by the edge of the river. 

#### Genesis 41:18 And as if from out of the river ascended seven oxen, good to the sight and choice in the flesh, and they fed at the reed-grass. 

#### Genesis 41:19 And behold, {seven oxen another} ascended after them from the river, in a sorry state and shameful to the sight, and thin in the flesh, what thing {I saw not such as} {in the entire land of Egypt a shameful thing}. 

#### Genesis 41:20 And {ate up the seven oxen shameful and thin} the seven oxen -- the first, the good and the choice. 

#### Genesis 41:21 And they entered into their bellies. And it did not {apparent become} that they entered into their bellies. And their appearance was shameful, as also in the beginning. And after awakening, I went back to bed. 

#### Genesis 41:22 And I saw again in my sleep, even as if seven ears of corn ascended in {lower branch one}, full and good. 

#### Genesis 41:23 And another seven ears of corn, thin and destroyed by the wind grew up next to them. 

#### Genesis 41:24 And {swallowed down the seven ears of corn thin and destroyed by the wind} the seven {ears of corn good and full}. I told it then to the expositors, and there was no one reporting it to me. 

#### Genesis 41:25 And Joseph said to Pharaoh, The dream to Pharaoh is one. As much as God does, he showed to Pharaoh. 

#### Genesis 41:26 The seven {oxen good seven years are}, and the seven {ears of corn good seven years are}; the dream of Pharaoh is one. 

#### Genesis 41:27 And the seven {oxen thin}, the ones ascending after them, {seven years are}; and the seven {ears of corn thin and destroyed by the wind seven years are} -- there will be seven years of famine. 

#### Genesis 41:28 And the saying which I have said to Pharaoh, {as much God will do} to show to Pharaoh. 

#### Genesis 41:29 Behold, for seven years there comes {prosperity great} in all the land of Egypt. 

#### Genesis 41:30 {shall come But seven years of famine} after these, and they shall forget the fullness being in all the land Egypt, and {will consume the famine} the land. 

#### Genesis 41:31 And {shall not be realized the prosperity} in the land because of the famine being after these things. {strong For it will be exceedingly}. 

#### Genesis 41:32 And concerning the repetition of the dream to Pharaoh twice, it is because {will be true the saying by God}, and God will hasten to do it. 

#### Genesis 41:33 Now then, look about for a man intelligent and discerning, and place him over the land of Egypt! 

#### Genesis 41:34 And let Pharaoh make and place toparchs over the land. And let them take a fifth of all the produce of the land of Egypt of the seven years of prosperity! 

#### Genesis 41:35 And let them bring together all the foods {seven years coming good of these}! And let them bring together the grain under the hand of Pharaoh! foods {in the cities to be guarded}. 

#### Genesis 41:36 And {shall be the foods being guarded} for the land in the seven years of the famine, which will be in the land of Egypt, and {shall not be obliterated the land} in the famine. 

#### Genesis 41:37 {was pleasing And the saying} before Pharaoh, and before all his servants. 

#### Genesis 41:38 And Pharaoh said to his servants, Shall we find {a man such} who has spirit of God in him? 

#### Genesis 41:39 {said And Pharaoh} to Joseph, Since God showed to you all these things, there is not a man more intelligent and more discerning than you. 

#### Genesis 41:40 You will be over my house, and by your mouth {shall obey all my people}. Except for the throne -- {will excel you I}. 

#### Genesis 41:41 {said And Pharaoh} to Joseph, Behold, I place you today over all the land of Egypt. 

#### Genesis 41:42 And Pharaoh removing the ring from his hand, put it upon the hand of Joseph. And he put on him {apparel fine linen}, and he put a collar of gold about his neck. 

#### Genesis 41:43 And he transported him upon {chariot second his}. And {proclaimed in front of him a herald}. And he placed him over the entire land of Egypt. 

#### Genesis 41:44 {said And Pharaoh} to Joseph, I am Pharaoh, without you not {shall lift anyone} his hand over all the land of Egypt. 

#### Genesis 41:45 And Pharaoh called the name of Joseph, Zaphnath-paaneah. And he gave to him Asenath, daughter of Poti-phera, priest of Heliopolis, to him as a wife. 

#### Genesis 41:46 And Joseph was {years old thirty} when he stood before Pharaoh king of Egypt. {went forth And Joseph} from the face of Pharaoh, and went through all the land of Egypt. 

#### Genesis 41:47 And {produced the land} in the seven years prosperity of sheaves. 

#### Genesis 41:48 And was brought together all the foods of the seven years in which there was prosperity in the land of Egypt. And he put the foods in the cities. Foods of the plains of the city of the places round about it, he put in it. 

#### Genesis 41:49 And Joseph gathered together grain as the sand of the sea, much exceedingly, until they were not able to count it, {no for there was} number. 

#### Genesis 41:50 And to Joseph were born {sons two} before the coming of the seven years of famine, which {bore to him Asenath}, the daughter of Poti-phera, priest of Heliopolis. 

#### Genesis 41:51 {called And Joseph} the name of the first-born, Manasseh, for {me forget made God} all my miseries, and all of the things of my father. 

#### Genesis 41:52 And the name of the second he called, Ephraim, for {increased me God} in the land of my humiliation. 

#### Genesis 41:53 And went by the seven years of prosperity, which came to pass in the land of Egypt. 

#### Genesis 41:54 And {began the seven years of famine} to come as Joseph said. And there became famine in all the earth; but in all the land of Egypt there were bread loaves. 

#### Genesis 41:55 And {hungered all the land of Egypt}. {cried out And the people} to Pharaoh for bread loaves. {said And Pharaoh} to all the Egyptians, You go to Joseph, and what ever he says to you, you do! 

#### Genesis 41:56 And the famine was upon the face of all the earth. {opened And Joseph} all the granaries, and sold to all the Egyptians. 

#### Genesis 41:57 And all the regions came to Egypt to buy from Joseph, {prevailed for the famine} in all the earth. 

#### Genesis 42:1 {seeing And Jacob} that there is grain for sale in Egypt, said to his sons, Why are you lazy? 

#### Genesis 42:2 Behold, I have heard that there is grain in Egypt; go down there and buy for us a small amount of foods! that we should live, and not die. 

#### Genesis 42:3 {went down And the brothers of Joseph}, the ten, to buy grain from Egypt. 

#### Genesis 42:4 But Benjamin the brother of Joseph was not sent with his brothers. For he said, Lest at any time should come to pass to him an infirmity. 

#### Genesis 42:5 {came And the sons of Israel} to buy with the ones coming; {was for the famine} in the land of Canaan. 

#### Genesis 42:6 And Joseph was the ruler of the land; he sold to all the people of the land. {coming And the brothers of Joseph} did obeisance to him upon their face upon the ground. 

#### Genesis 42:7 {seeing And Joseph} his brothers recognized and alienated himself from them, and he spoke to them hard. And he said to them, From what place have you come? And they said, From out of the land of Canaan, to buy foods. 

#### Genesis 42:8 {recognized And Joseph} his brothers, but they did not recognize him. 

#### Genesis 42:9 And Joseph remembered his dreams, of which he himself saw. And he said to them, You are spies to study the tracks of the place in which you have come. 

#### Genesis 42:10 And they said, Not so, O lord, your servants came to buy foods. 

#### Genesis 42:11 We are all sons of one man; we are peaceable. {are not Your servants} spies. 

#### Genesis 42:12 And he said to them, No, but {the tracks of the land you came to see}. 

#### Genesis 42:13 And they said, {twelve We are your servants} brothers in the land of Canaan; and behold, our younger brother is with our father today, and the other does not exist. 

#### Genesis 42:14 {said And to them Joseph}, This is it that I have said to you, saying that, You are spies. 

#### Genesis 42:15 In this you shall appear exposed, by the health of Pharaoh, no way should you go forth from here, if {should not brother your younger} come here. 

#### Genesis 42:16 You send {from you one}, and take your brother! But you shall be taken away until {apparent become your sayings}, if you be truthful, or not. But if not, by the health of Pharaoh, assuredly you are spies. 

#### Genesis 42:17 And he put them in prison {days three}. 

#### Genesis 42:18 And he said to them {day on the third}, You do this and you shall live! {God For I fear}. 

#### Genesis 42:19 If you are peaceable, {of your brothers let be held one} in the prison! but you yourselves proceed, and take back the purchase of your provision! 

#### Genesis 42:20 And {brother your younger you lead} to me! and I will trust your sayings; but if not you shall die. And they did so. 

#### Genesis 42:21 And said each to his brother, Yes, {in sins for we are} on account of our brother, for we overlooked the affliction of his soul when he besought us, and we did not listen to him, and because of this {came upon us this affliction}. 

#### Genesis 42:22 {answering And Reuben} said to them, Did I not speak to you, saying, You should not wrong the lad, and you did not hearken to me? And behold, his blood is required. 

#### Genesis 42:23 And they did not know that Joseph heard, for the translator {between them was}. 

#### Genesis 42:24 And turning from them, Joseph wept. And again he came forward to them, and spoke to them. And he took Simeon from them, and he tied him before them. 

#### Genesis 42:25 {gave charge And Joseph} to fill up their containers of grain, and to give back their silver to each in his sackcloth, and to give them provisions for the journey. And it became to them so. 

#### Genesis 42:26 And placing the grain upon their donkeys, they went forth from there. 

#### Genesis 42:27 {untying And one} his bag, to give fodder to his donkeys where they rested, and he saw {bundle of silver his}, for it was upon the mouth of the bag. 

#### Genesis 42:28 And he said to his brothers, {was given back to me the silver}, and behold, this is in my bag. And it startled their hearts, and they were disturbed with one another, saying, What is this God did to us? 

#### Genesis 42:29 And they came to Jacob their father in the land of Canaan. And they reported to him all the things coming to pass to them, saying, 

#### Genesis 42:30 {spoke The man the master of the land} to us hard, and put us in prison as spying out the land. 

#### Genesis 42:31 And we said to him, We are peaceable, we are not spies. 

#### Genesis 42:32 Twelve brothers we are, sons of our father; the one does not exist, and the younger is with our father today in the land of Canaan. 

#### Genesis 42:33 {said And to us the man the master of the land}, By this I will know that you are peaceable, {of your brothers you leave one} here with me! and the purchase of the provision for your house having taken, you go forth! 

#### Genesis 42:34 And you lead to me {brother your younger}! and I shall know that {not spies you are}, but that you are peaceable, and {your brother I will give back to you}, and {in the land you can trade}! 

#### Genesis 42:35 And it happened in their emptying their sackcloths, and there was {in each a bundle of silver} in their sackcloth. And they saw the bundles of their silver to them, and their father, and they feared. 

#### Genesis 42:36 {said And to them Jacob their father}, You are making me childless; Joseph is not, Simeon is not, and will you take Benjamin? Upon me {happened these things all}. 

#### Genesis 42:37 {said And Reuben} to his father, saying, The two sons of mine you may kill if I do not lead him to you. You give him into my hand, and I will lead him to you. 

#### Genesis 42:38 And he said, {shall not go down My son} with you, for his brother died, and he alone is left behind. And suppose it shall come to pass that he be infirm in the way which ever you go, and you will lead me in old age with distress into Hades. 

#### Genesis 43:1 But the famine grew in strength upon the land. 

#### Genesis 43:2 And it came to pass when they completed eating up the grain which they brought from Egypt, that {said to them their father}, In again going, you buy us a small amount of foods! 

#### Genesis 43:3 {said And to him Judah}, saying, {bore witness by testifying to us The man}, the master of the land, saying, You shall not see my face if {should not brother your younger with you come}. 

#### Genesis 43:4 If then, you send our brother with us, we will go down, and we will buy foods for you. 

#### Genesis 43:5 But if you do not send our brother with us, we will not go, for the man said to us, saying, You shall not see my face if {should not brother your younger with you be}. 

#### Genesis 43:6 {said And Israel}, Why did you do evil to me announcing to the man that there is to you a brother? 

#### Genesis 43:7 And they said, In asking, {asked of us the man} and our family, saying, Does {still our father} live, and if there is to us a brother. And we reported to him according to this questioning. We did not know that he would say to us, You bring your brother! 

#### Genesis 43:8 {said And Judah} to Israel his father, You send the lad with me, and rising up let us go, that we may live and not die, and we and you and our belongings. 

#### Genesis 43:9 I will look out for him. {from out of my hand You seek him}. If I do not lead him to you, and set him before you, I will be sinning against you all the days. 

#### Genesis 43:10 {if not For we slowed}, already even we should have returned twice. 

#### Genesis 43:11 {said And to them Israel their father}, If so it is, this you do! You take from the fruits of the earth in your containers, and bring to the man gifts of balm, and of honey, and incense, and balsam, and turpentine, and walnuts! 

#### Genesis 43:12 And {silver double you take} in your hands. And the silver being returned in your bags, return it with you, perhaps it is by ignorance! 

#### Genesis 43:13 And {your brother you take}, and rising go down to the man! 

#### Genesis 43:14 And my God give to you favor before the man, even to send your brother, the other one, and Benjamin. {I indeed For as much as} have been made childless, I have been made childless. 

#### Genesis 43:15 {receiving And the men} these gifts, and the {silver double} they took in their hands, and Benjamin, and rising up they went down into Egypt, and stood before Joseph. 

#### Genesis 43:16 {saw And Joseph} them, and Benjamin his brother, the one born of the same mother. And he said to the one over his house, Bring the men into the house, and slay the things offered for sacrifices, and prepare! {with me for will eat the men} bread loaves at midday. 

#### Genesis 43:17 {did And the man} as Joseph said. And he brought the men into the house of Joseph. 

#### Genesis 43:18 {seeing And the men} that they were brought into the house of Joseph, said, On account of the silver returned in our bags in the beginning we are brought in -- to extort us, and to place charge upon us, to take us as servants, and our donkeys. 

#### Genesis 43:19 And coming forward to the man, the one over the house of Joseph, they spoke to him in the vestibule of the house, 

#### Genesis 43:20 saying, We beseech you, O master, we went down in the beginning to buy foods, 

#### Genesis 43:21 and it happened when we came to rest up, and we opened our bags, that thus, the silver was in each of his bag. {our silver with the weight We returned now} in our hands, 

#### Genesis 43:22 and {silver other we brought} with ourselves to buy foods, we do not know who put the silver in our bags. 

#### Genesis 43:23 And he said to them, Kindness be to you, do not fear. Your God, and the God of your fathers gave to you treasures in your bags, and your silver in approving I receive. And he led out to them Simeon. 

#### Genesis 43:24 And he brought water to wash their feet. And he gave fodder to their donkeys. 

#### Genesis 43:25 And they prepared the gifts until {came at Joseph} midday. For they heard that {there he was about to dine}. 

#### Genesis 43:26 {entered And Joseph} into the house, and they brought to him the gifts which they had in their hands, into the house. And they did obeisance to him upon their face upon the ground. 

#### Genesis 43:27 And he asked them, How have you been? And he said to them, Is {in health your father}, the old man whom you spoke of? Still he lives? 

#### Genesis 43:28 And they said, He is in health -- your servant our father, still lives. And he said, Blessed be that man by God. And bowing they did obeisance to him. 

#### Genesis 43:29 And looking up with his eyes, he saw Benjamin his brother, the one born of the same mother. And he said, This is your brother the younger whom you spoke to me of bringing? And he said, God show mercy to you child. 

#### Genesis 43:30 {was disturbed And Joseph}. {contracted For his innards} over his brother, and he was seeking to weep, and he entered into the storeroom to weep there. 

#### Genesis 43:31 And he washed his face, and coming forth he controlled himself, and said, You place the bread loaves. 

#### Genesis 43:32 And they placed a setting to him alone, and to them by themselves, and to the Egyptians dining with them by themselves, {were not for able the Egyptians} to eat {with the Hebrews bread loaves}, {an abomination for it is} to the Egyptians. 

#### Genesis 43:33 And he seated before himself the first-born according to their seniority, and the younger according to his youth. {were looking amazed And the men each} at his brother. 

#### Genesis 43:34 And they lifted away the portions from him to them. {was magnified And the portion of Benjamin} over the portions of all -- five-fold over those. And they drank and became intoxicated with him. 

#### Genesis 44:1 And Joseph gave charge to the one over his house, saying, Fill the bags of the men with foods, as much as they are able to lift away. And put in each the silver at the mouth of the bag. 

#### Genesis 44:2 And {drinking cup my silver} put into the bag of the younger, and the value of his grain. And it happened according to the word of Joseph, as he said. 

#### Genesis 44:3 In the morning light shone through, and the men were sent, they and their donkeys. 

#### Genesis 44:4 {going forth from And their} the city, not {distance at a far}, and Joseph said to the one over his house, In rising up, pursue after the men, and you shall overtake them! And you shall say to them, For what reason did you recompense bad for good? Why did you steal my {drinking cup silver}? 

#### Genesis 44:5 {not Is this} in which {drinks my master}? And he {an omen foretells} by it? {the wicked things You completed} which you have done. 

#### Genesis 44:6 And having found them, he said to them according to these words. 

#### Genesis 44:7 And they said to him, Why speaks the master in these words? May it not be for your servants to do according to this word; 

#### Genesis 44:8 since the silver which we found in our bags we returned to you from the land of Canaan. How then would we steal from out of the house of your master silver or gold? 

#### Genesis 44:9 By whom ever {should be found the drinking cup} of your servants, let him die. {also we And} will be servants to your master! 

#### Genesis 44:10 And he said, And now as you say, so it will be. By whom ever {should be found the drinking cup}, will be my servant, and you all shall be pure. 

#### Genesis 44:11 And they hastened, and {lowered each} his bag upon the ground, and {opened each} his bag. 

#### Genesis 44:12 And he searched {from the older beginning} until he came to the younger. And he found the drinking cup in the bag of Benjamin. 

#### Genesis 44:13 And they tore their cloaks, and {placed each} his bag upon his donkey, and returned to the city. 

#### Genesis 44:14 {entered And Judah} and his brothers to Joseph, while he was there. And they fell before him upon the ground. 

#### Genesis 44:15 {said And to them Joseph}, What is this you did? Did you not know that {an omen shall foretell a man such as I}? 

#### Genesis 44:16 {said And Judah}, How shall we contradict the master, or what shall we speak, or how shall we be justified? For God found the injustice of your servants. Behold, we are servants to our master, both we and by whom was found with the drinking cup. 

#### Genesis 44:17 {said And Joseph}, Let it not be to me to do this thing. The man by whom was found with the drinking cup, he will be my servant. But you all ascend with safety to your father. 

#### Genesis 44:18 And approaching to him, Judah said, I beseech O lord, let {speak your servant} before you, and be not enraged with your servant, for you are after Pharaoh! 

#### Genesis 44:19 O lord you asked your servants, saying, {you Have} a father or brother? 

#### Genesis 44:20 And we said to the master, There is to us a father, an older man, and {child old age a younger in his}, and his brother died, and he alone was left behind of his mother, and his father loved him. 

#### Genesis 44:21 And you said to your servants, Lead him to me! and I will care for him. 

#### Genesis 44:22 And we said to the master, {is not able The child} to leave his father; and if he should leave his father, he will die. 

#### Genesis 44:23 And you said to your servants, If {does not go down brother Your younger} with you, you shall not proceed to see my face. 

#### Genesis 44:24 And it happened when we ascended to your servant our father, we reported to him the words of our master. 

#### Genesis 44:25 {said And our father}, Proceed again, and buy for us a small amount of foods! 

#### Genesis 44:26 And we said, We will not be able to go down; but if then {brother our younger} goes down with us, we will go down; for not will we be able to see the face of the man, {brother our younger if} is not being with us. 

#### Genesis 44:27 {said And our father your servant} to us, You know that {two bore to me my wife}; 

#### Genesis 44:28 and {went forth the one} from me, and you said that, {devoured by wild beasts He was}. And I did not see him as far as now. 

#### Genesis 44:29 If then you should take also this one from my face, and comes to pass to him an infirmity in the way, then know that you will lead me in old age with distress into Hades. 

#### Genesis 44:30 Now then, if I should enter to your servant {father and our}, and the child should not be with us, then know his life depends on this one's life. 

#### Genesis 44:31 And it will be in his seeing {not being the child} with us, he will come to an end, and {will lead your servants} to old age your servant {father and our} with distress into Hades. 

#### Genesis 44:32 For your servant has looked out for the child for my father, saying, If I do not lead him to you, {sinning I will be} against my father all the days. 

#### Genesis 44:33 Now then, I will remain to you as a servant instead of the child, as a domestic servant of my master. But let the child ascend with his brothers. 

#### Genesis 44:34 For how shall I ascend to the father of the child not being with us, that I should not see the bad things which will find my father? 

#### Genesis 45:1 And {was not able Joseph} to withhold of all the ones standing beside him. But he said, Send all from me! And {stood beside no one} Joseph when he made himself known to his brothers. 

#### Genesis 45:2 And he let go with a voice of weeping. {heard And all the Egyptians}, and {audible it became} into the house of Pharaoh. 

#### Genesis 45:3 {said And Joseph} to his brothers, I am Joseph, {still father does my} live? And {were not able the brothers} to respond to him, for they were disturbed. 

#### Genesis 45:4 {said And Joseph} to his brothers, Approach to me! And they approached. And he said, I am Joseph your brother, whom you delivered into Egypt. 

#### Genesis 45:5 Now then do not fret, nor {hard to you let it appear} that you delivered me here; {for for life sent me God} in front of you. 

#### Genesis 45:6 For this second year a famine is upon the earth, and still remaining are five years in which there is no plowing nor harvest. 

#### Genesis 45:7 {sent For me God} in front of you, that there may be left to you a vestige upon the earth, and to nourish to you {remnant a great}. 

#### Genesis 45:8 Now then, you did not send me here, but God. And he made me as father to Pharaoh, and master of all his house, and ruler of all the land of Egypt. 

#### Genesis 45:9 Hastening then, you ascend to my father and say to him! Thus says your son Joseph. {made me God} master of all the land of Egypt. Come down then to me! and you should not wait. 

#### Genesis 45:10 And you shall dwell in the land of Goshen, and you will be near me, you and your sons, and the sons of your sons, your sheep and your oxen, and as much as is yours. 

#### Genesis 45:11 And I will nourish you there. For there is still five years of famine; that you shall not be obliterated -- you and your sons, and all your possessions. 

#### Genesis 45:12 Behold, your eyes see, and the eyes {Benjamin of my brother} that my mouth is speaking to you. 

#### Genesis 45:13 Report then to my father all my glory in Egypt, and as much as you saw! And hastening, bring down my father here! 

#### Genesis 45:14 And falling upon the neck of Benjamin his brother, he weeped upon him. And Benjamin weeped upon his neck. 

#### Genesis 45:15 And kissing all his brothers, he wept on them. And after these things {spoke his brothers} to him. 

#### Genesis 45:16 And {was proclaimed forth the report} into the house of Pharaoh, saying, {have come The brothers of Joseph}. {rejoiced And Pharaoh}, and his attendant. 

#### Genesis 45:17 {said And Pharaoh} to Joseph, Speak to your brothers! This you do, fill your carriages and go forth into the land of Canaan! 

#### Genesis 45:18 And taking up your father, and your possessions, come to me! And I will give to you all the good things of Egypt, and you shall eat the marrow of the land. 

#### Genesis 45:19 And you charge these to take for themselves wagons from out of the land of Egypt for your children, and your wives! And taking up your father come! 

#### Genesis 45:20 And you should not be sparing to the eyes of your items, {the for all} good things of Egypt will be unto you. 

#### Genesis 45:21 And they did thus, the sons of Israel. {gave And Joseph} to them wagons, according to the sayings by Pharaoh the king. And he gave to them provisions for the journey. 

#### Genesis 45:22 And to all he gave double robes. But to Benjamin he gave three hundred pieces of gold, and five changings of robes. 

#### Genesis 45:23 And to his father he sent according to the same, and ten donkeys carrying of all the good things of Egypt; and ten mules carrying bread loaves to his father for the journey. 

#### Genesis 45:24 {sent out And Joseph} his brothers. And they went. And he said to them, Do not be provoked to anger in the way! 

#### Genesis 45:25 And they ascended from out of Egypt. And they came into the land of Canaan, to Jacob their father. 

#### Genesis 45:26 And they announced to him, saying that, Your son Joseph lives, and he rules all the land of Egypt. And {receded in his thought Jacob}, for he did not trust them. 

#### Genesis 45:27 And they spoke to him all the sayings of Joseph, as much as he said to them. And seeing the wagons which Joseph sent, so as to take him, {rekindled the spirit of Jacob their father}. 

#### Genesis 45:28 {said And Israel}, {a great thing to me It is} if {still Joseph my son} lives. In going I will see him before dying. 

#### Genesis 46:1 {departing And Israel}, and all of his, he came upon the Well of the Oath. And he sacrificed a sacrifice to the God of his father Isaac. 

#### Genesis 46:2 {said And God} to Israel in a vision in the night, saying, Jacob, Jacob! And he said, What is it? 

#### Genesis 46:3 And he says to him, I am the God of your fathers; do not fear to go down into Egypt! {into For nation a great I will make you} there. 

#### Genesis 46:4 And I will go down with you into Egypt. And I will transport you to the end. And Joseph will put his hands upon your eyes. 

#### Genesis 46:5 {rose up And Jacob} from the Well of the Oath. And {took up the sons of Israel} Jacob their father, and the belongings, and their wives upon the wagons which Joseph sent to carry him. 

#### Genesis 46:6 And taking up their possessions, and all the property which they acquired in the land of Canaan, they entered into Egypt -- Jacob and all his seed with him. 

#### Genesis 46:7 Sons, and sons of his sons with him; daughters, and daughters of his daughters, and all his seed he led into Egypt. 

#### Genesis 46:8 And these are the names of the sons of Israel, the ones entering into Egypt together with Jacob their father. Jacob and his sons -- the first-born of Jacob, Reuben. 

#### Genesis 46:9 And the sons of Reuben -- Hanoch, and Phallu, Hezron, and Carmi. 

#### Genesis 46:10 And the sons of Simeon -- Jemuel, and Jamin, and Ohad, and Jachin, and Zohar, and Shaul, son of the Canaanitess. 

#### Genesis 46:11 And the sons of Levi -- Gerson, and Kohath, and Merari. 

#### Genesis 46:12 And the sons of Judah -- Er, and Onan, and Shelah, and Pharez, and Zerah. {died And Er and Onan} in the land of Canaan. {born And the sons} of Pharez -- Hezron, and Hamul. 

#### Genesis 46:13 And the sons of Issachar -- Tola, and Phuvah, and Job, and Shimron. 

#### Genesis 46:14 And the sons of Zebulun -- Sered, and Elon, and Jahleel. 

#### Genesis 46:15 These are the sons of Leah, whom she bore to Jacob in Mesopotamia of Syria, and Dinah his daughter. All the souls, sons and daughters, thirty three. 

#### Genesis 46:16 And the sons of Gad -- Ziphion, and Haggai, and Shuni, and Ezbon, and Eri, and Arodi, and Areli. 

#### Genesis 46:17 And the sons of Asher -- Jimnah, Ishuah, and Isui, and Beriah, and Serah their sister. And the sons of Beriah -- Heber and Malchiel. 

#### Genesis 46:18 These are the sons of Zilpah, whom Laban gave to Leah his daughter, who bore these to Jacob -- sixteen souls. 

#### Genesis 46:19 And the sons of Rachel, wife of Jacob -- Joseph and Benjamin. 

#### Genesis 46:20 {born And the sons of Joseph} in the land of Egypt, whom {bore to him Asenath}, the daughter of Poti-phera, priest of Heliopolis -- Manasseh and Ephraim. And were born the sons of Manasseh whom {bore to him concubine the Sura} -- Machir. And Machir procreated Gilead. And the sons of Ephraim brother of Manasseh -- Sutalaam, and Tam. And the sons of Sutalaam -- Edem. 

#### Genesis 46:21 And the sons of Benjamin -- Belah, and Becher, and Ashbel, Gera, and Naaman, and Ehi, Rosh, and Muppim, and Huppim. And Gera procreated Ard. 

#### Genesis 46:22 These are the sons of Rachel, whom she bore to Jacob -- all the souls were eighteen. 

#### Genesis 46:23 And the sons of Dan -- Hushim. 

#### Genesis 46:24 And the sons of Naphtali -- Jahzeel, and Guni, and Jezer, and Shillem. 

#### Genesis 46:25 These are the sons of Bilhah whom Laban gave to Rachel his daughter, who bore these to Jacob -- all the souls were seven. 

#### Genesis 46:26 And all the souls entering with Jacob into Egypt -- the ones coming forth from out of his thighs, separate from the wives of Jacob's sons -- all souls were sixty-six. 

#### Genesis 46:27 And the sons of Joseph being born to him in the land of Egypt -- {souls nine}. All the souls of the house of Jacob of the ones entering with Jacob into Egypt -- {souls seventy-five}. 

#### Genesis 46:28 And he sent Judah in front of him to Joseph, to meet him near Heropolis, in the land of Rameses. 

#### Genesis 46:29 {teaming up And Joseph} his chariots, ascended to meet Israel his father at Heropolis. And seeing him, he fell upon his neck. And he wept weeping greatly. 

#### Genesis 46:30 And Israel said to Joseph, I will gladly die from now on, since I have seen your face, for still you live. 

#### Genesis 46:31 {said And Joseph} to his brothers, In ascending, I will report to Pharaoh. And I will say to him, My brothers, and the house of my father, who were in the land of Canaan, have come to me. 

#### Genesis 46:32 And the men are shepherds, {men for grazing cattle they were}. And the cattle, and the oxen, and all their things, they have brought. 

#### Genesis 46:33 If then {should call you Pharaoh}, and he should say, What {your work is}? 

#### Genesis 46:34 You shall say, {men grazing cattle We are your servants}, from child hood until the present, even we and our fathers; that you may dwell in the land of Goshen of Arabia. {is an abomination For to the Egyptians every shepherd of flocks}. 

#### Genesis 47:1 {came And Joseph} to report to Pharaoh, saying, my father and my brothers, and the cattle, and their oxen, and all their things, are come from the land of Canaan, and behold, they are in the land of Goshen. 

#### Genesis 47:2 And from his brothers he took to himself five men, and stood them before Pharaoh. 

#### Genesis 47:3 And Pharaoh said to the brothers of Joseph, What is your work? And they said to Pharaoh, {are shepherds of flocks Your servants}, even we and our fathers. 

#### Genesis 47:4 And they said to Pharaoh, {to sojourn in the land We come}, {no for there is} pasture for the cattle of your servants, {grew in strength for the famine} in the land of Canaan. Now then let {dwell your servants} in the land of Goshen! 

#### Genesis 47:5 And Pharaoh said to Joseph, saying, Your father and your brothers have come to you. 

#### Genesis 47:6 Behold, the land of Egypt {before you is}, in the best land settle your father and your brothers. Let them dwell in the land of Goshen! And if you should have knowledge that there are among them {men able}, you place them in charge of my cattle! 

#### Genesis 47:7 {brought in And Joseph} Jacob his father, and stood him before Pharaoh. And Jacob blessed Pharaoh. 

#### Genesis 47:8 {said And Pharaoh} to Jacob, How many are the years of days of your life? 

#### Genesis 47:9 And Jacob said to Pharaoh, The days of the years of my life which I sojourned are a hundred thirty years; small and severe have become the days of the years of my life; they did not attain to the days of the years of the life of my fathers, which days they sojourned. 

#### Genesis 47:10 And Jacob having blessed Pharaoh, he went forth from him. 

#### Genesis 47:11 And Joseph settled his father, and his brothers, and he gave to them a possession in the land of Egypt, in the best land, in the land of Rameses, as Pharaoh assigned. 

#### Genesis 47:12 And Joseph measured out grain to his father, and to his brothers, and to all the house of his father -- grain according to person. 

#### Genesis 47:13 {grain And no there was} in all the earth. {grew in strength For the famine} exceedingly. {failed And the land of Egypt}, and the land of Canaan, because of the famine. 

#### Genesis 47:14 {brought together And Joseph} all the silver being found in the land of Egypt, and in the land of Canaan, from the grain which they bought. And he measured out grain to them. And Joseph carried in all the silver into the house of Pharaoh. 

#### Genesis 47:15 And {dissipated all the silver} from the land of Egypt, and from the land of Canaan. {came And all the Egyptians} to Joseph, saying, Give us bread loaves! And why should we die before you, {has dissipated for our silver}? 

#### Genesis 47:16 {said And to them Joseph}, Bring your cattle, and I will give to you bread loaves in exchange for your cattle, if {has dissipated the silver}. 

#### Genesis 47:17 And they led their cattle to Joseph. And {gave to them Joseph} bread loaves in return for the horses, and for the sheep, and for the oxen, and for the donkeys. And he nourished them with bread loaves in exchange for all of their cattle in that year. 

#### Genesis 47:18 {went by And year that}, and they came to him in the {year second}, and said to him, Lest at some time we should be obliterated from our master -- for since {has dissipated the silver}, and the possessions, and the cattle to you, the master, and there has not been left behind to us before our master, but only our own body and our land, 

#### Genesis 47:19 that then we might not die before you, and the land should be made desolate, you acquire us and our land for bread loaves, and we will be to you and our land, servants to Pharaoh! Give us seed! that we should sow, and we should live and should not die, and the land will not be made desolate. 

#### Genesis 47:20 And Joseph acquired all the land of the Egyptians for Pharaoh. {gave For the Egyptians} their land to Pharaoh. {prevailed For over them the famine}, and {came the land} to Pharaoh. 

#### Genesis 47:21 And the people were reduced to slavery to him as servants from the uttermost parts of the boundaries of Egypt, unto the uttermost parts, 

#### Genesis 47:22 except the land of the priests only {did not acquire this Joseph}, {a portion for gave as a gift to the priests Pharaoh}. And they ate the portion which {gave to them Pharaoh}. On account of this they did not give up their land. 

#### Genesis 47:23 {said And Joseph} to all the Egyptians, Behold, I have acquired you and your land today for Pharaoh. Take to yourselves seed, and sow the land! 

#### Genesis 47:24 And there will be produce of it, and you will give the fifth part to Pharaoh, and the four parts will be for you yourselves, for seed in the earth, and for food to you, and to all the ones in your houses. 

#### Genesis 47:25 And they said, You have delivered us; we found favor before our master, and we will be servants to Pharaoh. 

#### Genesis 47:26 And {established it to them Joseph} as an order until this day for the land of Egypt, for Pharaoh to take a fifth, except of the land of the priests only, which was not to Pharaoh. 

#### Genesis 47:27 {dwelt And Israel} in the land of Egypt, upon the land of Goshen. And they were heir over it. And they grew and multiplied exceedingly. 

#### Genesis 47:28 {outlived And Jacob} in the land of Egypt for seventeen years. And {were the days of Jacob's years of his life} a hundred forty-seven years. 

#### Genesis 47:29 {approached And the days} for Israel to die. And he called his son Joseph, and said to him, If I have found favor before you, place your hand upon my thigh! and you will do for me a charity and truth -- that is to not entomb me in Egypt. 

#### Genesis 47:30 But I shall be gone to sleep with my fathers, then you shall lift me from out of Egypt, and entomb me in their burying-place. And he said, I will do according to your saying. 

#### Genesis 47:31 And he said to him, Swear by an oath to me! And he swore by an oath to him. And Israel did obeisance upon the top of his cane. 

#### Genesis 48:1 And it came to pass after these things, and it was announced to Joseph that, Your father is troubled. And taking up {two sons his}, Manasseh and Ephraim, he came to Jacob. 

#### Genesis 48:2 And it was reported to Jacob, saying, Behold, your son Joseph comes to you. And Israel growing strong sat upon the bed. 

#### Genesis 48:3 And Jacob said to Joseph, My God was appeared to me in Luz, in the land of Canaan, and blessed me. 

#### Genesis 48:4 And he said to me, Behold, I will increase you, and I will multiply you, and I will make you into a gathering of nations. And I will give to you this land, and to your seed after you, for {possession an eternal}. 

#### Genesis 48:5 Now then, {two sons your}, the ones born to you in the land of Egypt, before my coming to you in Egypt, are mine, Ephraim and Manasseh, as Reuben and Simeon they shall be mine. 

#### Genesis 48:6 And the progeny, who ever should be procreated after these will be yours. By the name of their brothers they shall be called in those lots. 

#### Genesis 48:7 But I, when I came from Mesopotamia of Syria, {died Rachel your mother} in the land of Canaan at my approaching down by the course of the horses of Habratha of the land, before coming into Ephrath. And I buried her in the way of the course of the horses -- this is Beth-lehem. 

#### Genesis 48:8 {seeing And Israel} the sons of Joseph, said, Who are these to you? 

#### Genesis 48:9 {said And Joseph} to his father, {my sons They are} whom {gave to me God} here. And Jacob said, Lead {forward to me them} that I may bless them. 

#### Genesis 48:10 And the eyes of Israel were weighed down because of old age, and he was not able to see. And they approached to him, and he kissed them, and embraced them. 

#### Genesis 48:11 And Israel said to Joseph, Behold, {of your face I was not deprived}; and behold, {showed to me God} your seed. 

#### Genesis 48:12 And {led them Joseph} from his knees, and they did obeisance to him with their face upon the ground. 

#### Genesis 48:13 {taking And Joseph two sons his}, with Ephraim at the right, {from the left but} of Israel, and Manasseh at the left, {from the right but} of Israel, and he approached them to him. 

#### Genesis 48:14 {stretching out And Israel} the {hand right} put it upon the head of Ephraim, and this one was the younger; and the left upon the head of Manasseh; crosswise with the hands. 

#### Genesis 48:15 And he blessed them, and he said, The God in whom {were well-pleasing my fathers} in his presence -- Abraham and Isaac; the God maintaining me from my youth until this day; 

#### Genesis 48:16 the angel rescuing me from all evils, bless these boys! And {shall be called upon them my name}, and the name of my fathers -- Abraham and Isaac. And may they multiply into {multitude a great} upon the earth. 

#### Genesis 48:17 {seeing And Joseph} that {put his father} {hand his right} upon the head of Ephraim, {wrong to him it appeared}. And Joseph took hold of the hand of his father to remove it from the head of Ephraim, to the head of Manasseh. 

#### Genesis 48:18 {said And Joseph} to his father, Not so father, for this one is the first-born; place your right hand upon his head. 

#### Genesis 48:19 And he would not, but said, I know child, I know; and this one will be for a people, and this one will be raised up high. But {brother his younger greater than he will be}, and his seed will be a multitude of nations. 

#### Genesis 48:20 And he blessed them in that day, saying, By you Israel shall be blessed, saying, {make you God} as Ephraim and as Manasseh! And he put Ephraim in front of Manasseh. 

#### Genesis 48:21 {said And Israel} to Joseph, Behold, I die, and God will be with you, and he will return you to the land of your fathers. 

#### Genesis 48:22 And I give to you {portion a chosen out} above your brothers, which I took from the hand of the Amorites with my sword and bow. 

#### Genesis 49:1 {called And Jacob} his sons, and said, Come together that I may announce to you what will meet to you upon the last of the days! 

#### Genesis 49:2 Gather and hear, O sons of Jacob, hear Israel your father! 

#### Genesis 49:3 Reuben my first-born, you are my strength and the beginning of my children, stubborn to bear, and stubborn self-willed. 

#### Genesis 49:4 Overflowing as water, you should not erupt. For you ascended upon the marriage-bed of your father. Then you defiled the strewn bed of which you ascended. 

#### Genesis 49:5 Simeon and Levi -- brothers. They completed injustice by their sects. 

#### Genesis 49:6 {into their counsel May not come my soul}, and {with their joint-conspiracy may not be established my insides}. For in their rage they killed men, and in their passion they hamstrung a bull. 

#### Genesis 49:7 Accursed is their rage, for it was self-willed. And accursed is their vehement anger, for it was hardened. I will divide them in Jacob, and disseminate them in Israel. 

#### Genesis 49:8 Judah, may {have praised you your brothers}. Your hands are upon the back of your enemies. {will do obeisance to you The sons of your father}; 

#### Genesis 49:9 {cub a lion Judah is}. From a bud, O son of mine, you ascended. Reclining, you went to bed as a lion; and as a cub who will rouse him? 

#### Genesis 49:10 {shall not fail A ruler} from Judah, and one leading from his thighs, until whenever should come the things reserved to him. And he is expectation of nations. 

#### Genesis 49:11 Binding {to a grapevine his foal}, and with the fetter the foal of his donkey. He shall wash {in wine his apparel}, and in the blood of the grape his wrap-around garment. 

#### Genesis 49:12 {causing joy His eyes} away from wine, and the white of his teeth than milk. 

#### Genesis 49:13 Zebulun {on the coast shall dwell}, even himself by the mooring of boats; and he shall extend until Sidon. 

#### Genesis 49:14 Issachar {the good desired}, taking rest between the lots. 

#### Genesis 49:15 And seeing the rest, that it was good, and the earth, that it was plentiful, he placed his shoulder to the toil, and became a man for farming. 

#### Genesis 49:16 Dan will judge his people, as even one tribe in Israel. 

#### Genesis 49:17 And let Dan become a serpent upon the way, lying in wait upon the road, biting the heel of the horse. And {shall fall the horseman} upon the rear places, 

#### Genesis 49:18 {for the deliverance remaining about} of the LORD. 

#### Genesis 49:19 Gad, a marauder will maraud against him. But he will maraud against him by feet. 

#### Genesis 49:20 Asher, plentiful is his bread, and he will give a delicacy to rulers. 

#### Genesis 49:21 Naphtali, a trunk springing up giving {in the offspring beauty}. 

#### Genesis 49:22 {a son increasing Joseph is}; {son increasing zealous}; {son my younger}; to me you returned! 

#### Genesis 49:23 against whom with deliberation reviled. And {pressed against him the masters of the bowmen}, 

#### Genesis 49:24 and {were broken with might their bows}, and {were loosened the nerves arms of their hand's} through the hand of the mighty one of Jacob; from there the one strengthening Israel by means of God of your father. 

#### Genesis 49:25 And {gave help to you my God}, and blessed you with the blessing of heaven above, and the blessing of earth having all things; because of the blessing of breasts and of the womb; 

#### Genesis 49:26 a blessing of your father and of your mother -- he excelled in strength over the blessing {mountains of the stable}, and beyond the blessings {hills of everlasting}; they will be upon the head of Joseph, and upon the top {whom he took the lead of the brothers}. 

#### Genesis 49:27 Benjamin, {wolf a predacious in the early morning shall eat}, yet even in the evening he distributes provisions. 

#### Genesis 49:28 All these sons of Jacob -- twelve. And these words {said to them their father}. And he blessed them each. According to his blessing he blessed them. 

#### Genesis 49:29 And he said to them, I am added to my people. Entomb me with my fathers in the cave which is in the field of Ephron the Hittite! 

#### Genesis 49:30 in the {cave double}, in the one before Mamre, in the land of Canaan, which Abraham acquired; the cave of Ephron the Hittite, for possession of a memorial. 

#### Genesis 49:31 There they entombed Abraham and Sarah his wife. And there they entombed Isaac and Rebekah his wife. And there they entombed Leah, 

#### Genesis 49:32 in a property of the field, and of the cave being in it, the one from the sons of Heth. 

#### Genesis 49:33 And Jacob rested giving orders to his sons. And lifting up his feet upon the bed he failed. And he was added to his people. 

#### Genesis 50:1 And Joseph falling upon the face of his father, wept over him, and kissed him. 

#### Genesis 50:2 And Joseph assigned to his servants, to the embalmers to embalm his father. And {embalmed the embalmers} Israel. 

#### Genesis 50:3 And they accomplished embalming him in forty days, for thus they counted down the days of the burial. And {mourned him Egypt} seventy days. 

#### Genesis 50:4 And when {went by the days} of the mourning, Joseph spoke to the mighty ones of Pharaoh, saying, If I found favor before you, speak into the ears of Pharaoh! saying, 

#### Genesis 50:5 My father bound me by an oath before his coming to an end, saying, In the memorial which I dug myself, in the land of Canaan, there entomb me! Now then, ascending, I will entomb my father, and I will return back. 

#### Genesis 50:6 And Pharaoh said to Joseph, Ascend, entomb your father! just as he bound you by an oath. 

#### Genesis 50:7 And Joseph ascended to entomb his father. And went up with him all the servants of Pharaoh, and the elders of his house, and all the elders of the land of Egypt, 

#### Genesis 50:8 and all the whole family of Joseph, and his brothers, and all the house hold of his father, and the kin. And the sheep and the oxen were left behind in the land of Goshen. 

#### Genesis 50:9 And went up with him also chariots and horsemen. And {became the camp great exceedingly}. 

#### Genesis 50:10 And they came upon the threshing-floor of Atad, which is on the other side of the Jordan. And they lamented him by beating the breast, great and strong, exceedingly. And he made the mourning of his father seven days. 

#### Genesis 50:11 And {saw the inhabitants of the land of Canaan} the mourning at the threshing-floor of Atad. And they said, {mourning a great This is} to the Egyptians. On account of this they called the name of that place, Mourning of Egypt, which is on the other side of the Jordan. 

#### Genesis 50:12 And {did to him thus his sons}, as he gave charge to them. 

#### Genesis 50:13 And {took him his sons} into the land of Canaan. And they entombed him in the {cave double} which Abraham acquired; the cave for a possession of a memorial from Ephron the Hittite, over against Mamre. 

#### Genesis 50:14 And Joseph returned to Egypt, himself and his brothers, and all the ones going up with him to entomb his father. 

#### Genesis 50:15 {knowing And the brothers of Joseph} that {died their father}, said, Lest at any time {should resent us Joseph}, and with a recompense, recompense to us all the bad things which we demonstrated against him, 

#### Genesis 50:16 that they having come to Joseph, said, Your father bound us by an oath before he came to an end, saying, 

#### Genesis 50:17 So say to Joseph, You forgive them the injustice and their sin! for the wicked way they demonstrated against you. And now you accept the injustice of the attendants of the God of your father! And Joseph wept during their speaking to him. 

#### Genesis 50:18 And coming to him, they said, See! we are your servants. 

#### Genesis 50:19 And {said to them Joseph}, Do not fear! for {of God I am}. 

#### Genesis 50:20 You planned concerning me for evil, but God planned concerning me for good, that it should be as it is today, that he might maintain {people many}. 

#### Genesis 50:21 And he said to them, Do not fear! I will maintain you, and your residence. And he comforted them, and spoke of them in the heart. 

#### Genesis 50:22 And Joseph dwelt in Egypt, he and his brothers, and all the whole family of his father. And Joseph lived {years a hundred ten}. 

#### Genesis 50:23 And Joseph saw Ephraim's children unto the third generation. And the sons of Machir, the son of Manasseh, were born upon Joseph's thighs. 

#### Genesis 50:24 And Joseph said to his brothers, saying, I die, and visiting, {will visit you God}, and lead you from out of this land, into the land which {swore by an oath God} to your fathers, Abraham, Isaac, and Jacob. 

#### Genesis 50:25 And Joseph bound by an oath the sons of Israel, saying, In the visitation in which God will visit you, even you shall join in carrying off my bones from here with you. 

#### Genesis 50:26 And Joseph came to an end -- {years old a hundred ten}. And they entombed him, and they placed him in the coffin in Egypt.