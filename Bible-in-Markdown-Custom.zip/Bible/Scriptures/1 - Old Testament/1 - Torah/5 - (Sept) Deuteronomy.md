#### Deuteronomy 1:1 These are the words which Moses spoke to all Israel on the other side of the Jordan, in the wilderness towards the west, neighboring the red sea, between Paran Tophel and Laban, and Canyons, and Place Abounding in Gold. 

#### Deuteronomy 1:2 {eleven days from Horeb It is a journey} by mount Seir unto Kadesh Barnea. 

#### Deuteronomy 1:3 And it came to pass in the fortieth year, in the eleventh month, day one of the month, Moses spoke to all the sons of Israel according to all as much as the LORD gave charge to him for them, 

#### Deuteronomy 1:4 after the striking of Sihon king of the Amorites, the ones dwelling in Heshbon, and Og king of Bashan, the one dwelling in Astaroth and in Edrei. 

#### Deuteronomy 1:5 On the other side of the Jordan, in the land of Moab, Moses began to make clear this law, saying, 

#### Deuteronomy 1:6 The LORD your God spoke to you in Horeb, saying, Let it be enough for you to dwell in this mountain! 

#### Deuteronomy 1:7 {turn and depart You}, and enter into the mountain of the Amorites, and to all the ones adjacent to the wilderness, to the mountain, and the plain, and to the south, and the coast land of the Canaanites, and Antilebanon, unto the river of the great Euphrates! 

#### Deuteronomy 1:8 Behold! I have delivered up before you the land. Having entered, inherit the land! which I swore by an oath to your fathers, to Abraham, and Isaac, and Jacob, to give to them and to their seed after them. 

#### Deuteronomy 1:9 And I said to you in that time, saying, I will not be able alone to bear you, 

#### Deuteronomy 1:10 the LORD your God multiplied you. And behold, you are today as the stars of the heaven in multitude. 

#### Deuteronomy 1:11 The LORD God of your fathers may he add to you as you are a thousand times more, and bless you in so far as he spoke to you! 

#### Deuteronomy 1:12 How shall I be able alone to bear your toil, and support you, and your disputes? 

#### Deuteronomy 1:13 Appoint to yourselves {men wise}, and having knowledge, and discerning among your tribes! And I will ordain them over you as your leaders. 

#### Deuteronomy 1:14 And you answered to me, and said, {is good The saying} which you spoke to do. 

#### Deuteronomy 1:15 And I took from you {men wise}, and having knowledge, and discerning for your tribes. And I ordained them to take the lead over you -- commanders of thousands, and commanders of hundreds, and commanders of fifties, and commanders of tens, and judicial recorders for your judges. 

#### Deuteronomy 1:16 And I gave charge to your judges in that time, saying, Hold a hearing between your brethren, and judge justly between a man and between his brother, and between the foreigner with him! 

#### Deuteronomy 1:17 You shall not discriminate for a person in a judgment; concerning the small and according to the great you shall judge equally. In no way shall you avoid justice by accepting the person of a man, for the judgment is of God. And the matter which ever might be hard for you, you shall bear it to me, and I shall hear it. 

#### Deuteronomy 1:18 And I gave charge to you at that time all the words which you shall do. 

#### Deuteronomy 1:19 And departing from out of Horeb, we went through all {wilderness great and dreadful that}, which you beheld by the way of the mountain of the Amorite, in so far as {gave charge the LORD our God} to us; and we came unto Kadesh Barnea. 

#### Deuteronomy 1:20 And I said to you, You came unto the mountain of the Amorite, the one the LORD our God gives to you. 

#### Deuteronomy 1:21 Behold! {has delivered up to you the LORD your God before your face the land}. Ascending, you inherit it! in which manner {spoke the LORD God of your fathers} to you. You should not fear nor be timid. 

#### Deuteronomy 1:22 And {came forward to me you all}, and said, You should send men in front of us, and let them explore {for us the land}, and let them announce to us an answer for the way through which we shall ascend by it! and the cities into which we shall enter into them. 

#### Deuteronomy 1:23 And {was pleasing before me the saying}. And I took from you twelve men -- {man one} according to tribe. 

#### Deuteronomy 1:24 And turning they ascended into the mountain, and came unto Ravine of Cluster, and they spied it. 

#### Deuteronomy 1:25 And they took in their hands of the fruit of the land, and carried it to you, and said, {is good The land} which the LORD our God gives to us. 

#### Deuteronomy 1:26 And you did not want to ascend, but you resisted persuasion against the word of the LORD your God. 

#### Deuteronomy 1:27 And you complained in your tents, and said, Because the LORD detested us he led us out of the land of Egypt, to deliver us into the hands of the Amorites, and to utterly destroy us. 

#### Deuteronomy 1:28 Where do we ascend? And our brethren caused {to abstain our heart}, saying, {nation It is a great and populous}, and mightier than we; and {cities great}, and walled unto the heaven; moreover also {sons of giants we saw} there. 

#### Deuteronomy 1:29 And I said to you, Do not be alarmed, nor fear from them! 

#### Deuteronomy 1:30 The LORD your God, the one going forth before your face, he will join in making war against them with you, according to all as much as he did for you in the land of Egypt, 

#### Deuteronomy 1:31 and in this wilderness which you beheld, how as {nurtured you the LORD your God}, as if any {should nurture man} his son, according to all the way into which you were gone, until you came unto this place. 

#### Deuteronomy 1:32 And in this word you did not entrust to the LORD your God, 

#### Deuteronomy 1:33 who goes forth in front of you in the way, to choose for you a place, guiding you by fire at night, showing to you the way by which you go by it, and with a cloud by day. 

#### Deuteronomy 1:34 And the LORD heard the voice of your words, and he being provoked swore by an oath, saying, 

#### Deuteronomy 1:35 Shall {see any men of these wicked} {land good this} which I swore by an oath to their fathers, no. 

#### Deuteronomy 1:36 except Caleb son of Jephunneh, this one shall see it; and to this one I shall give the land upon which he mounted, and to his sons, because of joining {to himself the things of the LORD}. 

#### Deuteronomy 1:37 And {at me was enraged the LORD} because of you, saying, Nor should you in any way enter there. 

#### Deuteronomy 1:38 Joshua son of Nun, the one standing beside you, this one shall enter there; you strengthen him! for he shall allot it to Israel and your children, which you said {for ravaging to be}. 

#### Deuteronomy 1:39 And every {child new}, whoever does not know today good or bad, this one shall enter there, and to these I shall give it, and to them they shall inherit it. 

#### Deuteronomy 1:40 And you, in turning, encamped in the wilderness, the way near the red sea. 

#### Deuteronomy 1:41 And you answered and said to me, We sinned before the LORD our God; we, in ascending, shall wage war according to all as much as {gave charge the LORD our God} to us. And {taking up each} the items for his warfare, and gathering together, ascended into the mountain. 

#### Deuteronomy 1:42 And the LORD said to me, Say to them, You shall not ascend, nor wage war, {not for I am} with you; and in no way shall you be broken before your enemies. 

#### Deuteronomy 1:43 And I spoke to you, and you did not listen to me, and you violated the word of the LORD, and pressing forward you ascended unto the mountain. 

#### Deuteronomy 1:44 And {came forth the Amorite dwelling in that mountain} to meet you. And they pursued you as do the bees, and pierced you from Seir until Hormah. 

#### Deuteronomy 1:45 And sitting you wept before the LORD your God, and {did not listen to the LORD} your voice, nor took heed to you. 

#### Deuteronomy 1:46 And you laid in wait in Kadesh {days many}, as many {as at some other time days} you laid in wait. 

#### Deuteronomy 2:1 And turning we departed into the wilderness by way {sea of the red}, in which manner the LORD spoke to me. And we encircled mount Seir {days many}. 

#### Deuteronomy 2:2 And the LORD said to me, 

#### Deuteronomy 2:3 {is enough Your encircling this mountain}; turn then towards the north! 

#### Deuteronomy 2:4 And {to the people you give charge}, saying, You go through the borders of your brethren, the sons of Esau, the ones dwelling in Seir! And they shall fear you, and shall be {cautious of you exceedingly}. 

#### Deuteronomy 2:5 You shall not join against them for war, for not in any way will I give to you of their land, nor a stool for your foot; for by lot I have given to Esau mount Seir. 

#### Deuteronomy 2:6 With silver {foods buy} from them and eat, and {water measured out you shall receive} from them by silver, and you shall drink. 

#### Deuteronomy 2:7 For the LORD your God blessed you in every work of your hands. Determine how you went through {wilderness great and dreadful that}! Behold, forty years the LORD your God was with you; you did not want of a thing. 

#### Deuteronomy 2:8 And we went by our brethren the sons of Esau, the ones dwelling in Seir, by the way of the wilderness from Aelon, and from Ezion Gaber; and turning we went by the way of the wilderness of Moab. 

#### Deuteronomy 2:9 And the LORD said to me, Do not hate the Moabites, and do not join together against them in war! for in no way will I give to you of their land. {by lot For to the sons of Lot I have given Aroer} to inherit. 

#### Deuteronomy 2:10 The Emim prior laid in wait upon it, {nation a great and populous}, and strong, as the Anakim. 

#### Deuteronomy 2:11 {of the Raphaim shall be considered And these} as also the Anakim; and the Moabites named them Emim. 

#### Deuteronomy 2:12 And in Seir {laid in wait the Horite} the former one; and the sons of Esau destroyed them, and obliterated them from their face; and they settled in place of them in which manner Israel did to the land of his inheritance, which the LORD gave to them. 

#### Deuteronomy 2:13 Now then, I said, Rise up, and depart, and come near the ravine of Zared! And we went by the ravine of Zared. 

#### Deuteronomy 2:14 And the days which we passed from Kadesh Barnea until of which time we went by the ravine of Zared was thirty eight years, until of which time {perished all the generation of men of war}, dying from the camp, as {swore by an oath the LORD God} to them. 

#### Deuteronomy 2:15 And the hand of God was upon them, to completely consume them from out of the midst of the camp, until they perished. 

#### Deuteronomy 2:16 And it came to pass, as soon as {fell all the ones dying}, men warriors, from out of the midst of the people, 

#### Deuteronomy 2:17 that the LORD spoke to me, saying, 

#### Deuteronomy 2:18 You shall pass over today the borders of Moab -- the Aroer. 

#### Deuteronomy 2:19 And you shall lead near the sons of Ammon. Do not hate them, nor join against them in war! for I will not give from the land of the sons of Ammon to you by lot, for to the sons of Lot I have given it by lot. 

#### Deuteronomy 2:20 {land of Raphaim It shall be considered}, for even upon it {dwelt the Raphaim formerly}. And the Ammonites named them Zummim, 

#### Deuteronomy 2:21 {nation a great and populous}, and mightier than you, as also the Anakim; and {destroyed them the LORD} before their face, and they inherited them; and they were settled there in place of them until this day, 

#### Deuteronomy 2:22 even as they did inherit the sons of Esau, the ones dwelling in Seir, in which manner he obliterated the Horite from their face; and they inherited them, and they were settled in place of them until this day. 

#### Deuteronomy 2:23 And the Hivites dwelling in Aseroth unto Gaza, and the Cappadocians coming forth from out of Cappadocia, obliterated them, and were settled in place of them. 

#### Deuteronomy 2:24 Now then, rise up and depart and go by the ravine of Arnon! Behold, I have delivered up into your hands Sihon king of Heshbon the Amorite and his land. Commence to inherit it! Join against him in war! 

#### Deuteronomy 2:25 On this day commence to give the trembling of you and the fear of you upon the face of all the nations of the ones underneath the heaven! Whoever hearing your name shall be disturbed, and {pangs of anguish shall have} before your face. 

#### Deuteronomy 2:26 And I sent ambassadors from the wilderness of Kedemoth to Sihon king of Heshbon {words with peaceable}, saying, 

#### Deuteronomy 2:27 I will go through your land; in the journey I will go -- I will not turn aside right nor left. 

#### Deuteronomy 2:28 {foods for silver You shall give to me}, and I shall eat; and {water for silver you shall give to me}, and I shall drink; only that I shall go by on the feet, 

#### Deuteronomy 2:29 as {did to me the sons of Esau dwelling in Seir}, and the Moabites, the ones dwelling in Ar, until whenever I should go by the Jordan into the land which the LORD our God gives us. 

#### Deuteronomy 2:30 And {did not want Sihon king of Heshbon} us to go by through his land, for {hardened the LORD our God} his spirit, and strengthened his heart, that he should be delivered up into your hands, as in this day. 

#### Deuteronomy 2:31 And the LORD said to me, Behold, I have begun to deliver up before your face Sihon king of Heshbon the Amorite, and his land. Commence to inherit his land! 

#### Deuteronomy 2:32 And came forth Sihon king of Heshbon to meet us, he and all his people, for war at Jahaz. 

#### Deuteronomy 2:33 And {delivered him the LORD our God} before our face, into our hands; and we struck him, and his sons, and all his people. 

#### Deuteronomy 2:34 And we held all his cities in that time. And we utterly destroyed every city; next also their women, and their children we did not leave behind for taking alive. 

#### Deuteronomy 2:35 Except the cattle we despoiled for ourselves. And the spoils from the cities we took, 

#### Deuteronomy 2:36 from Aroer, which is by the bank of the rushing stream Arnon, and the city being in the ravine, and unto mount Gilead. There was not a city which evaded us; {delivered up all the LORD our God} into our hands. 

#### Deuteronomy 2:37 Except in the land of the sons of Ammon we did not draw near, all the parts falling in with the stream Jabbok, and the cities, the ones in the mountainous area, in so far as {gave charge to us the LORD our God}. 

#### Deuteronomy 3:1 And turning we ascended the way into Bashan. And came forth Og king of Bashan to meet us, he and all his people for war, in Edrei. 

#### Deuteronomy 3:2 And the LORD said to me, You should not fear him, for into your hands I will deliver him, and all his people, and all his land. And you shall do to him as you did to Sihon king of the Amorites, who dwelt in Heshbon. 

#### Deuteronomy 3:3 And {delivered him the LORD our God} into our hands, even Og king of Bashan, and all his people. And we struck him until there was not left behind any of his seed. 

#### Deuteronomy 3:4 And we held all of his cities in that time; there was not a city which we did not take from them; sixty cities, all the places round about Argob, of king Og in Bashan. 

#### Deuteronomy 3:5 All these cities were fortified {walls with high}, gates, and bars; besides the cities of the Perizzites -- {many very}. 

#### Deuteronomy 3:6 We utterly destroyed them as we did Sihon king of Heshbon. And we utterly destroyed every city, next also the women and the children, 

#### Deuteronomy 3:7 and all the cattle; and the spoils of the cities we despoiled for ourselves. 

#### Deuteronomy 3:8 And we took in that time the land from the hands of the two kings of the Amorites, the ones who were on the other side of the Jordan -- from the rushing stream of Arnon unto mount Hermon. 

#### Deuteronomy 3:9 The Phoenicians named Hermon, Sirion, but the Amorite named it Shenir. 

#### Deuteronomy 3:10 All the cities of Misor, and all Gilead, and all Bashan unto Salchah and Edrei -- cities of the kingdom of Og in Bashan. 

#### Deuteronomy 3:11 For only Og king of Bashan was left from the Rephaim. Behold his bed is a bed of iron. Behold this is in the Akra of the sons of Ammon. Nine cubits was the length of it, and four cubits the breadth of it, in the cubit of a man. 

#### Deuteronomy 3:12 And that land we inherited in that time from Aroer, which is by the bank of the stream Arnon, and the half of the mountain of Gilead. And his cities I gave to Reuben and Gad. 

#### Deuteronomy 3:13 And the remainder of Gilead, and all Bashan -- the kingdom of Og, I gave to the half tribe of Manasseh; and all the place round about Argob. All that Bashan {the land of Raphaim shall be considered}. 

#### Deuteronomy 3:14 And Jair son of Manasseh took all the place round about Argob, unto the borders of the Geshurites and Maachathites. And he named them after his name -- Bashan Havoth Jair until this day. 

#### Deuteronomy 3:15 And to to Machir I gave Gilead. 

#### Deuteronomy 3:16 And to Reuben and to Gad I gave of Gilead unto the rushing stream Arnon, between the rushing stream's border and unto the Jabbok; and the rushing streams are the border to the sons of Ammon. 

#### Deuteronomy 3:17 And the Araba and the Jordan are the border from Chinnereth, and unto the sea of Araba, {sea the salty} by Ashdoth of Pisgah from the east. 

#### Deuteronomy 3:18 And I gave charge to you at that time, saying, The LORD your God has given to you this land by lot. Arming yourselves, go forth before the face of your brethren of the sons of Israel -- every one able! 

#### Deuteronomy 3:19 Except your wives, and your children, and your cattle, for I know there are many cattle to you, let them dwell at your cities in which I gave to you, 

#### Deuteronomy 3:20 until whenever {should rest the LORD your God} your brethren, as also you, and they should have inherited also themselves the land which the LORD your God gives to you on the other side of the Jordan; then {shall turn back each} to his inheritance, which I have given to you. 

#### Deuteronomy 3:21 And to Joshua I gave charge at that time, saying, Your eyes have seen all as much as {did the LORD our God} {two kings to these}; so {shall do the LORD} to all the kingdoms unto which you passed over there. 

#### Deuteronomy 3:22 You shall not have fear of them, for the LORD our God himself shall wage war for you. 

#### Deuteronomy 3:23 And I besought the LORD in that time, saying, 

#### Deuteronomy 3:24 O Lord, O LORD, you began to show to your attendant your strength, and your power, and the {hand fortified}, and the {arm high}. For what God is in the heaven or upon the earth, who shall do as you did yourself, according to your works, and according to your strength? 

#### Deuteronomy 3:25 Passing over then I will see {land this good}, the one being on the other side of the Jordan, {mountain this good}, and the Antilebanon. 

#### Deuteronomy 3:26 And the LORD overlooked me because of you. And he did not listen to me. And the LORD said to me, Let it be enough for you to not add yet to speak to me on this matter! 

#### Deuteronomy 3:27 Ascend upon the top the dressed stone, and lift up your eyes towards the west and the north and the south and the east! And behold with your eyes! for you shall not pass over this Jordan. 

#### Deuteronomy 3:28 And you give charge to Joshua, and strengthen him, and comfort him! for this one shall pass over before the face of this people, and he shall allot to them the land which you have seen. 

#### Deuteronomy 3:29 And we laid in wait in a grove in the vicinity of the house of Peor. 

#### Deuteronomy 4:1 And now, O Israel, hear the ordinances and the judgments! as many as I teach you today to do, that you should live and manifoldly multiply; and entering should be heir to the land which the LORD God of your fathers gives to you. 

#### Deuteronomy 4:2 You shall not add to the saying which I give charge to you, and you shall not remove from it. Guard the commandments of the LORD your God! as many as I give charge to you today. 

#### Deuteronomy 4:3 Your eyes have seen all as many things as {did the LORD our God} to Baal-peor. For every man whoever went after Baal-peor, {obliterated him the LORD your God} from you. 

#### Deuteronomy 4:4 But you, the ones joining with the LORD your God, all live today. 

#### Deuteronomy 4:5 Behold! I have shown to you ordinances and judgments, as {gave charge to me the LORD my God}, to do thus for you in the land into which you enter there to inherit it. 

#### Deuteronomy 4:6 And you shall guard and shall do; for this is your wisdom and your understanding before all the nations, as many as should hear all these ordinances. Then they shall say, Behold, {people is a wise and intelligent nation this great}. 

#### Deuteronomy 4:7 For what {nation great} in which there is to it a God near to them as the LORD our God is in all things in which we should call upon him? 

#### Deuteronomy 4:8 And what {nation great} in which there is to it {ordinances and judgments just} according to all this law, which I give before you today? 

#### Deuteronomy 4:9 Take heed to yourself, and guard your life exceedingly! You should not forget all the words which {have seen your eyes}, and let them not leave from your heart all the days of your life! And instruct your sons and the sons of your sons! 

#### Deuteronomy 4:10 Specially the day which you stood in the presence of the LORD your God in Horeb, in the day of the assembly; for the LORD said to me, Hold an assembly to me, {the people and let} hear my words! so that they should learn to fear me all the days which they live upon the earth, and that {their sons they should have taught}. 

#### Deuteronomy 4:11 And you came forward and stood under the mountain; and the mountain burned fire unto the heaven -- darkness, dimness, and a storm. 

#### Deuteronomy 4:12 And the LORD spoke to you in the mountain from the midst of the fire. A voice of utterances you heard, and a representation you did not behold -- but only a voice. 

#### Deuteronomy 4:13 And he announced to you his covenant, which he gave charge to you to observe -- the ten discourses; and he wrote them upon two tablets of stone. 

#### Deuteronomy 4:14 And {to me the LORD gave charge} in that time to teach you ordinances and judgments, for you to do them upon the land into which you enter there to inherit it. 

#### Deuteronomy 4:15 And you shall guard exceedingly your lives, that you not behold any representation in the day in which the LORD spoke to you in Horeb in the mountain from the midst of the fire. 

#### Deuteronomy 4:16 Lest you should act lawlessly, and make to yourselves a carving representation, any image, a representation of a male or female; 

#### Deuteronomy 4:17 a representation of any beast of the ones being upon the earth; a representation of any {bird feathered} which flies under the heaven; 

#### Deuteronomy 4:18 a representation of any reptile which crawls upon the earth; a representation of any fish, as many as are in the waters underneath the earth. 

#### Deuteronomy 4:19 And lest at any time looking up into the heaven, and beholding the sun, and the moon, and the stars, and all the cosmos of the heaven wandering, you should do obeisance to them, and you should serve them, which {bestowed the LORD your God} them to all the nations underneath the heaven. 

#### Deuteronomy 4:20 {you But took the LORD God}, and led you from out of the furnace of iron, out of Egypt, to be to him {people a hereditary}, as in this day. 

#### Deuteronomy 4:21 And the LORD God was enraged with me on account of the things having been said by you. And he swore by an oath that I should not pass over this Jordan, and that I should not enter into the {land good} which the LORD your God gives to you by lot. 

#### Deuteronomy 4:22 For I die in this land, and I shall not pass over this Jordan. But you shall pass over and shall inherit {land this good}. 

#### Deuteronomy 4:23 Take heed to yourselves! lest at any time you should forget the covenant of the LORD your God, which he ordained with you, and you should make to you yourselves a carving representation of all of which {gave orders to you not to do the LORD your God}. 

#### Deuteronomy 4:24 For the LORD your God {fire a consuming is} -- a jealous God. 

#### Deuteronomy 4:25 And if you should procreate sons and sons of your sons, and you should pass time upon the land, and you should act lawlessly, and you should make a carving representation of any thing, and you should do the wicked thing in the presence of the LORD our God to provoke him to anger, 

#### Deuteronomy 4:26 I call to testify against you today both the heaven and the earth, that by destruction you shall be destroyed from the land in which you pass over the Jordan there to inherit it. You shall not delay long days upon it, but by obliteration you shall be obliterated. 

#### Deuteronomy 4:27 And the LORD shall disseminate you among all the nations, and there shall be left few of you in number among all the nations into which the LORD shall bring you there. 

#### Deuteronomy 4:28 And you shall serve there other gods, works of the hands of man -- wood and stones, which cannot see, nor hear, nor eat, nor smell. 

#### Deuteronomy 4:29 And you shall seek after there the LORD your God, and you shall find him whenever you should seek after him with {entire heart your}, and with {entire soul your} in your affliction. 

#### Deuteronomy 4:30 And {shall find you all these words} at the last of the days, and you shall turn towards the LORD your God, and you shall hearken to his voice. 

#### Deuteronomy 4:31 For God {is pitying and merciful the LORD your God}. He will not abandon you, nor in any way will he obliterate you; he will not forget the covenant of your fathers, which he swore by an oath to them. 

#### Deuteronomy 4:32 Ask {days former}! the ones having taken place prior of you, from the day of which God created man upon the earth, and upon the one extremity of the heaven unto the other extremity of the heaven, if anything has taken place according to {thing this great}, if {was heard such}; 

#### Deuteronomy 4:33 if {has heard a nation} the voice of the living God speaking in the midst of the fire, in which manner you have heard and lived; 

#### Deuteronomy 4:34 if God tested, entering to take to himself a nation from out of the midst of a nation, for a test; and in signs, and in miracles, and by war, and by {hand a fortified}, and with {arm a high}, and in {visions great}, according to all as much as {did the LORD our God} in Egypt, in the presence of your seeing; 

#### Deuteronomy 4:35 so as to see yourself that the LORD your God, he is God, and there is not yet one besides him. 

#### Deuteronomy 4:36 From out of the heaven {audible to you he made his voice}, to correct you; and upon the earth he showed you {fire his great}; and his discourses you heard from the midst of the fire. 

#### Deuteronomy 4:37 It is on account of his loving your fathers that he chose their seed after them -- you. And he led you himself by {strength his great} from out of Egypt, 

#### Deuteronomy 4:38 to utterly destroy {nations great and stronger} than you before your face, to bring you and to give to you their land to inherit as you have today. 

#### Deuteronomy 4:39 And you shall know today, and shall turn your mind, that the LORD your God -- he is God, in the heaven upward, and upon the earth below; and there is not any besides him. 

#### Deuteronomy 4:40 And you shall guard his commandments, and his ordinances, as many as I give charge to you today; that {good to you it should be}, and to your sons after you, so that {long-lived you should be} upon the earth, of which the LORD your God gives to you all the days. 

#### Deuteronomy 4:41 Then Moses separated three cities on the other side of the Jordan of the east sun, 

#### Deuteronomy 4:42 {to flee there for the man-killer} who ever should have slaughtered the neighbor not knowingly, and this one having not detested him before yesterday and the third day before. And he shall take refuge in one of these cities, and he shall live -- 

#### Deuteronomy 4:43 Bezer in the wilderness, in the land in the plain of Reuben; and Ramoth in Gilead to the of Gadites; and Golon in Bashan to the Manassites. 

#### Deuteronomy 4:44 This is the law which Moses placed before the sons of Israel. 

#### Deuteronomy 4:45 These are the testimonies, and the ordinances, and the judgments, as many as Moses spoke to the sons of Israel in the wilderness, in their coming forth from the land of Egypt, 

#### Deuteronomy 4:46 on the other side of the Jordan, in the ravine near the house of Peor, in the land of Sihon king of the Amorites whom dwelt in Heshbon, who Moses struck, and the sons of Israel, in their coming forth from out of the land of Egypt. 

#### Deuteronomy 4:47 And they inherited his land, and the land of Og king of Bashan, two kings of the Amorites who were on the other side of the Jordan, according to the rising of the sun. 

#### Deuteronomy 4:48 From Aroer, which is upon the bank of the rushing stream Arnon, and upon the mountain of Sion, which is Hermon, 

#### Deuteronomy 4:49 all the wilderness on the other side of the Jordan according to the rising of the sun by Asedoth -- the one of dressed stone. 

#### Deuteronomy 5:1 And Moses called all Israel, and he said to them, Hear O Israel, the ordinances and the judgments! as many as I speak in your ears in this day. And you shall learn them, and guard to do them. 

#### Deuteronomy 5:2 The LORD your God ordained to you a covenant in Horeb. 

#### Deuteronomy 5:3 Not with your fathers the LORD ordained this covenant, but only with you; even you here all living today. 

#### Deuteronomy 5:4 Face to face the LORD spoke to you in the mountain from the midst of the fire. 

#### Deuteronomy 5:5 And I stood between the LORD and you in that time, to announce to you the sayings of the LORD (for you were in fear from before the fire, and you did not ascend unto the mountain), saying, 

#### Deuteronomy 5:6 I am the LORD your God, the one leading you from out of the land of Egypt, from the house of slavery. 

#### Deuteronomy 5:7 There shall not be {to you gods other} before my face. 

#### Deuteronomy 5:8 You shall not make for yourself a carving, nor any representation, as many as are in the heaven upward, and as many as are in the earth below, and as many as are in the waters underneath the earth. 

#### Deuteronomy 5:9 You shall not do obeisance to them, nor in any way serve them; for I am the LORD your God, a jealous God, repaying the sins of the fathers upon the children unto the third and fourth generation to the ones detesting me, 

#### Deuteronomy 5:10 and executing mercy to thousands, to the ones loving me, and to the ones keeping my orders. 

#### Deuteronomy 5:11 You shall not take the name of the LORD your God in vain; for {shall not cleanse the LORD your God} the one taking his name in vain. 

#### Deuteronomy 5:12 Guard the day of the Sabbaths! to sanctify it in which manner {gave charge to you the LORD your God}! 

#### Deuteronomy 5:13 Six days you shall work, and do all your works. 

#### Deuteronomy 5:14 But the {day seventh} is a Sabbath to the LORD your God. You shall not do on it any work -- you, and your son, and your daughter, your manservant, and your maidservant, your ox, and your beast of burden, and every beast of yours, and the foreigner sojourning among you, that {should have cause to rest your manservant and your maidservant} as also you. 

#### Deuteronomy 5:15 And you shall remember that you were a servant in the land of Egypt, and {led you the LORD your God} from there by {hand a fortified} and with {arm a high}. On account of this {gave orders to you the LORD your God}, so as for you to guard the day of the Sabbaths, and to sanctify it. 

#### Deuteronomy 5:16 Esteem your father and your mother! in which manner {gave charge to you the LORD your God}, that good should be to you, and that {a long time you may be} upon the earth, of which the LORD your God gives to you. 

#### Deuteronomy 5:17 You shall not murder. 

#### Deuteronomy 5:18 You shall not commit adultery. 

#### Deuteronomy 5:19 You shall not steal. 

#### Deuteronomy 5:20 You shall not witness falsely against your neighbor {witness as a lying}. 

#### Deuteronomy 5:21 You shall not desire the wife of your neighbor. You shall not desire the house of your neighbor, nor his field, nor his manservant, nor his maidservant, nor his ox, nor his beast of burden, nor any beast of his, nor any thing as much as {of your neighbor is}. 

#### Deuteronomy 5:22 These are the discourses the LORD spoke to all your congregation in the mountain from the midst of the fire, darkness, dimness, storm -- {voice a great}; and he did not add any more. And he wrote them upon two tablets of stone, and he gave them to me. 

#### Deuteronomy 5:23 And it came to pass as you heard the voice from out of the midst of the fire, and the mountain burned fire, and there came forward to me all the leaders of your tribes, and your council of elders, 

#### Deuteronomy 5:24 that you said, Behold, {showed to us the LORD our God} his glory, and his voice we hear from the midst of the fire. In this day we beheld that God shall speak to man, and he shall live. 

#### Deuteronomy 5:25 And now lest at any time we die, for {shall completely consume us fire this great}, if we {should have added to hear ourselves} the voice of the LORD our God any more -- then we shall die. 

#### Deuteronomy 5:26 For what flesh who heard the voice of the living God speaking from the midst of the fire {as we even shall live}? 

#### Deuteronomy 5:27 You approach and hear all as much as {should say the LORD our God} to you! And you shall speak to us all whatever as much as {should speak the LORD our God} to you, and we will hear, and we will do. 

#### Deuteronomy 5:28 And the LORD heard the voice of your words speaking to me. And the LORD said to me, I heard the voice of the words of this people, as many as they spoke to you rightly, all as many as they spoke. 

#### Deuteronomy 5:29 Who shall give {to be thus their heart} in them, so as to fear me, and to guard my commandments all the days, that good might be to them and to their sons through the eon. 

#### Deuteronomy 5:30 Proceed! Say to them! You return to your houses! 

#### Deuteronomy 5:31 But you here stand with me! and I shall speak to you all the commandments, and the ordinances, and the judgments, as many as you shall teach them. And let them do thus in the land which I give to them by lot! 

#### Deuteronomy 5:32 And you shall guard to do in which manner {gave charge to you the LORD your God}, to not turn aside right nor left, 

#### Deuteronomy 5:33 but according to every way which {gave charge to you the LORD your God} to go by it, so that he should rest you, and good might be to you, and you should prolong your days upon the land which you shall inherit. 

#### Deuteronomy 6:1 And these are the commandments, and the ordinances, and the judgments, as many as {gave charge the LORD our God} to teach you to do thus in the land into which you enter there to inherit it. 

#### Deuteronomy 6:2 That you should fear the LORD our God, to guard all his ordinances and his commandments which I give charge to you today, you and your sons, and the sons of your sons, all the days of your life, that you should prolong your days. 

#### Deuteronomy 6:3 And hear, O Israel, and guard to do! so that good might be to you, and that you should multiply exceedingly, just as {spoke the LORD God of your fathers} to give to you a land flowing milk and honey. And these are the ordinances, and the judgments, as many as the LORD gave charge to the sons of Israel in the wilderness, in their coming forth from the land of Egypt. 

#### Deuteronomy 6:4 Hear, O Israel! The LORD our God {Lord one is}. 

#### Deuteronomy 6:5 And you shall love the LORD your God with {entire heart your}, and with {entire soul your}, and with {entire power your}. 

#### Deuteronomy 6:6 And {will be these discourses as many as I give charge to you today} in your heart, and in your soul. 

#### Deuteronomy 6:7 And you shall assist {with them your sons}, and you shall speak of them sitting down in your house, and going in the way, and lying in bed, and arising. 

#### Deuteronomy 6:8 And you shall affix them for a sign upon your hand, and it shall be unshaken before your eyes. 

#### Deuteronomy 6:9 And you shall write them upon the lintels of your houses, and your gates. 

#### Deuteronomy 6:10 And it will be whenever {shall bring you the LORD your God} into the land which he swore by an oath to your fathers, to Abraham, and to Isaac, and to Jacob, to give to you {cities the great and good} which you did not build; 

#### Deuteronomy 6:11 houses full of all good things which you did not fill up; pits of quarrying which you did not quarry; vineyards and olive groves which you did not plant; and eating and being filled up; 

#### Deuteronomy 6:12 take heed to yourself! that you should not forget the LORD your God. the one leading you from the land of Egypt, from out of a house of slavery. 

#### Deuteronomy 6:13 {the LORD your God You shall fear}, and to him only you shall serve, and to him you shall cleave to, and by his name you shall swear an oath by. 

#### Deuteronomy 6:14 You shall not go after other gods of the gods of the nations surrounding you. 

#### Deuteronomy 6:15 For {is a jealous God the LORD your God} among you, lest being provoked to anger {should be enraged the LORD your God} against you, and should utterly destroy you from the face of the earth. 

#### Deuteronomy 6:16 You shall not put to test the LORD your God in which manner you put to test in Test. 

#### Deuteronomy 6:17 Guarding, you shall guard the commandments of the LORD your God, and his testimonies, and his ordinances, as many as he gave charge to you. 

#### Deuteronomy 6:18 And you shall do the pleasing and the good before the LORD your God, that {good to you it should be}, and you should enter, and should inherit the {land good} which the LORD swore by an oath to your fathers, 

#### Deuteronomy 6:19 to drive out all your enemies before your face, as the LORD spoke. 

#### Deuteronomy 6:20 And it will be whenever {should ask you your son} tomorrow, saying, What are the testimonies, and the ordinances, and the judgments, as many as {gave charge the LORD our God} to us? 

#### Deuteronomy 6:21 And you shall say to your son, We were servants to Pharaoh in the land of Egypt, and {led us the LORD} from there by {hand a fortified} and with {arm a high}. 

#### Deuteronomy 6:22 And the LORD executed signs and {miracles great and severe} in Egypt to Pharaoh, and to his house in our presence. 

#### Deuteronomy 6:23 And {led us the LORD} from there, that he should bring us, to give to us this land which {swore by an oath the LORD our God} to our fathers to give to us. 

#### Deuteronomy 6:24 And {gave charge to us the LORD} to do all these ordinances, to fear the LORD our God, that good might be to us all the days, that we should live as even today. 

#### Deuteronomy 6:25 And mercy will be to us, if we guard to do all the commandments of this law before the LORD our God, as he gave charge to us. 

#### Deuteronomy 7:1 And it will be in {bringing you the LORD your God} into the land into which you enter there to inherit it, and he shall lift away {nations great and numerous} from your presence -- the Hittite, and the Girgashite, and the Amorite, and Canaanite, and Perizzite, and the Hivite, and the Jebusite -- seven {nations great and numerous}, even stronger than you. 

#### Deuteronomy 7:2 And {shall deliver them the LORD your God} into your hands, and you shall strike them. To extinction you shall remove them. You shall not ordain with them a covenant, nor in any way should you show mercy unto them; 

#### Deuteronomy 7:3 nor contract a marriage with them. {your daughter You shall not give} to his son, and his daughter you shall not take to your son. 

#### Deuteronomy 7:4 {will leave For your son} from me, and shall serve other gods, and {shall be provoked to anger in rage the LORD} against you, and shall utterly destroy you quickly. 

#### Deuteronomy 7:5 But thus you shall do to them; {their shrines you shall demolish}, and {their monuments you shall break}, and {their sacred groves you shall cut down}; and {carvings of the gods their} you shall incinerate by fire. 

#### Deuteronomy 7:6 For {people a holy you are} to the LORD your God. And {preferred you the LORD your God} to be to him {people a prized} from all the nations, as many as are upon the face of the earth. 

#### Deuteronomy 7:7 Not because you were more numerous than all the nations {prefer did the LORD} you, and chose you; for you are ones very few of all the nations. 

#### Deuteronomy 7:8 But because the LORD loved you, and to observe the oath which he swore to your fathers, {led you the LORD} by {hand a fortified} and with {arm a high}; and he ransomed you from out of a house of slavery, from the hand of Pharaoh king of Egypt. 

#### Deuteronomy 7:9 And you shall know that the LORD your God -- this one is God, the trustworthy God, the one guarding the covenant and mercy to the ones loving him, and to the ones guarding his commandments into a thousand generations; 

#### Deuteronomy 7:10 and repaying to the ones detesting his face, to utterly destroy them. And he shall not be slow to the ones detesting; by person he shall render what is due to them. 

#### Deuteronomy 7:11 And you shall guard the commandments, and the ordinances, and these judgments, as many as I give charge to you today to do. 

#### Deuteronomy 7:12 And it will be when ever you should hear these ordinances, and should have guarded and should have done them, that {will protect the LORD your God with you the covenant}, and the mercy which he swore by an oath to your fathers. 

#### Deuteronomy 7:13 And he will love you, and shall bless you, and shall multiply you, and shall bless the descendants of your belly, and the fruit of your land -- your grain, and your wine, and your olive oil, the herds of your oxen, and the flocks of your sheep upon the land which the LORD swore by an oath to your fathers to give to you. 

#### Deuteronomy 7:14 Blessed you will be of all the nations. There will not be among you barren nor sterile, even among your cattle. 

#### Deuteronomy 7:15 And {shall remove the LORD} from you every infirmity; and all {diseases of Egypt the severe} which you knew, he will not place upon you. And he will place them upon all the ones detesting you. 

#### Deuteronomy 7:16 And you shall eat all the spoils of the nations which the LORD your God gives to you; you shall not spare your eye over them; and no way should you serve to their gods; for {an impediment this shall be} to you. 

#### Deuteronomy 7:17 But if you should say in your mind that, {is great nation This}; or, I, how shall I be able to utterly destroy them? 

#### Deuteronomy 7:18 You shall not fear them; remembering you shall remember as much as {did the LORD your God} to Pharaoh and to all the Egyptians; 

#### Deuteronomy 7:19 the {tests great} which you beheld with your eyes; the signs and {miracles those great}; the {hand fortified} and the {arm high}. As {led you the LORD your God}, so {will do the LORD your God} to all the nations which you fear from their face. 

#### Deuteronomy 7:20 And {the swarms of wasps will send the LORD your God} unto them, until whenever shall be obliterated the ones being left behind, and the ones being hidden from you. 

#### Deuteronomy 7:21 You shall not be pierced from their face, for the LORD your God among you is a God great and fortified. 

#### Deuteronomy 7:22 And {shall consume the LORD your God} these nations from your face according to little by little. You shall not be able to completely consume them quickly, that {might not become the land} wilderness, and {should multiply upon you the beasts wild}. 

#### Deuteronomy 7:23 And {delivered them the LORD your God} into your hands, and you shall destroy them {destruction in a great}, until whenever you should utterly destroy them. 

#### Deuteronomy 7:24 And he shall deliver up their kings into your hands. And he shall destroy their name under the heaven. Not shall {withstand anyone} against your face until whenever you should have utterly destroyed them. 

#### Deuteronomy 7:25 The carvings of their gods you shall incinerate in fire. You shall not desire silver nor gold from them, to take for yourself, lest you should be at fault because of it, for {an abomination to the LORD your God it is}. 

#### Deuteronomy 7:26 And you shall not carry an abomination into your house, that it be anathema as this thing. Loathing you shall loathe, and as an abomination you shall abhor it, for it is anathema. 

#### Deuteronomy 8:1 All the commandments which I give charge to you today you shall guard to do, that you should live and manifoldly multiply, and should enter and should inherit the land which {swore by an oath the LORD} to your fathers. 

#### Deuteronomy 8:2 And you shall remember the whole journey which {led you the LORD your God} this fortieth year in the wilderness, how he should afflict you, and should test you, and should determine the things in your heart, if you shall guard his commandments or not. 

#### Deuteronomy 8:3 And he afflicted you, and caused you to hunger, and fed you the manna which {had not known your fathers}; that he should announce to you that, {not by bread alone shall live A man}; but by every word going forth through the mouth of God shall {live a man}. 

#### Deuteronomy 8:4 Your garments did not grow old from you; your feet were not calloused -- behold, for forty years. 

#### Deuteronomy 8:5 And you shall know in your heart, that as if any man should correct his son, so the LORD your God corrects you. 

#### Deuteronomy 8:6 And you shall guard the commandments of the LORD your God, to go in his ways, and to fear him. 

#### Deuteronomy 8:7 For the LORD your God shall bring you into a land good and abundant, of which are rushing streams of waters, and springs of the deeps going forth through the plains, and through the mountains. 

#### Deuteronomy 8:8 A land of wheat, and barley, grapevines, fig-trees, pomegranates; a land of olive oil and honey. 

#### Deuteronomy 8:9 A land upon which {without poorness you shall eat your bread}, and you shall not be in want upon it. A land of which its stones are iron, and from out of its mountains you shall mine brass. 

#### Deuteronomy 8:10 And you shall eat and shall be filled up, and shall bless the LORD your God upon the {land good} of which he has given to you. 

#### Deuteronomy 8:11 Take heed to yourself! that you should not forget the LORD your God, so as to not guard his commandments, and his judgments, and his ordinances, as many as I give charge to you today; 

#### Deuteronomy 8:12 lest having eaten, and being filled up, and {houses good having built}, and dwelling in them, 

#### Deuteronomy 8:13 and your oxen, and your sheep having been multiplied to you, and silver and gold having been multiplied to you, and all as much as to you shall be multiplying, 

#### Deuteronomy 8:14 you should be raised up high in your heart, and should forget the LORD your God, the one leading you from the land of Egypt, from the house of slavery, 

#### Deuteronomy 8:15 the one leading you through the {wilderness great and dreadful}, that one of which is {serpent the biting}, and scorpion, and thirst, of which there was no water; the one leading to you {from out of rock chiseled a spring of water}; 

#### Deuteronomy 8:16 the one feeding you the manna in the wilderness, which {had not known you}, and {did not know your fathers}; that he should afflict you, and that he should put you to the test, and {good unto you do} upon the last of your days; 

#### Deuteronomy 8:17 and lest you should say in your heart, My strength and the might of my hand produced to me {ability this great}. 

#### Deuteronomy 8:18 And you shall remember the LORD your God, that he gives to you strength to produce the ability, that he should establish his covenant which he swore by an oath to your fathers as today. 

#### Deuteronomy 8:19 And it will be if in forgetfulness you should forget the LORD your God, and should go after other gods, and should serve to them, and should do obeisance to them, I testify to you today on both heaven and the earth that by destruction you shall be destroyed. 

#### Deuteronomy 8:20 As also the remaining nations, as many as the LORD destroys before your face, so shall you be destroyed; because you did not hearken to the voice of the LORD your God. 

#### Deuteronomy 9:1 Hear, O Israel! You pass over today the Jordan to enter to inherit {nations great and stronger} than you; {cities great and walled} unto the heaven; 

#### Deuteronomy 9:2 a people great and populous and tall -- sons of Anak whom you know, and you have heard said, Who can withstand against the face of the sons of Anak? 

#### Deuteronomy 9:3 And you shall know today that the LORD your God, he shall go forth before your face. {fire a consuming He is}. He shall utterly destroy them, and he shall turn them away before your presence. And he shall utterly destroy them, and he will destroy them quickly, just as {said to you the LORD}. 

#### Deuteronomy 9:4 You should not say in your heart by the complete consuming by the LORD your God of these nations before your face, saying, Because of my righteousness {brought me the LORD} to inherit {land this good}. But on account of the impiety of these nations {will utterly destroy them the LORD} before your face. 

#### Deuteronomy 9:5 Not because of your righteousness, nor because of the sacredness of your heart do you enter to inherit their land. But because of the impiety of these nations the LORD shall utterly destroy them from your presence, and that he should establish the covenant which the LORD swore by an oath to your fathers -- to Abraham, and to Isaac, and to Jacob. 

#### Deuteronomy 9:6 And you shall know today that not through your works of righteousness the LORD your God gives to you {land this good} to inherit; for {people a hard-necked you are}. 

#### Deuteronomy 9:7 Remember! you should not forget as much as you provoked the LORD your God in the wilderness, from which day you came forth from the land of Egypt, until you came into this place, for by resisting persuasion you completed the things against the LORD. 

#### Deuteronomy 9:8 And in Horeb you provoked the LORD, and the LORD was enraged with you to utterly destroy you. 

#### Deuteronomy 9:9 Of my ascending into the mountain to take the tablets of stone, tablets of covenant of which the LORD ordained for you. And I was occupied in the mountain forty days and forty nights. {bread I did not eat}, and water I did not drink. 

#### Deuteronomy 9:10 And {gave to me the LORD} the two tablets of stone, being written by the finger of God. And upon them he had written all the words, the ones which the LORD spoke to you in the mountain, from amidst the fire, in the day of assembly. 

#### Deuteronomy 9:11 And it came to pass through forty days and through forty nights, the LORD gave to me the two tablets of stone -- tablets of covenant. 

#### Deuteronomy 9:12 And the LORD said to me, Arise, go down quickly from here! for {acted lawlessly your people}, of whom you led out of the land of Egypt. They violated quickly from the way of which you gave charge to them; they made to themselves a molten casting. 

#### Deuteronomy 9:13 And the LORD said to me, saying, I have spoken to you once and twice, saying, I have seen this people; and, behold, {people it is a hard-necked}. 

#### Deuteronomy 9:14 Allow me! to utterly destroy them, and I will wipe away their name from beneath the heaven. And I will make you into {nation a great and strong}, and more numerous rather than this one. 

#### Deuteronomy 9:15 And turning, I went down from the mountain, and the mountain burned fire. And the two tablets of the covenant were in {two hands my}. 

#### Deuteronomy 9:16 And seeing that you sinned before the LORD your God, and made to yourselves a calf molten image, and transgressed quickly from the way which the LORD gave charge to you; 

#### Deuteronomy 9:17 that taking hold of the two tablets, I tossed them from {two hands my}, and I broke them before you. 

#### Deuteronomy 9:18 And I beseeched before the LORD a second time, as also even formerly, forty days and forty nights. Bread I did not eat, and water I did not drink, on account of all your sins which you sinned, to do the wicked thing before the LORD God, to provoke him. 

#### Deuteronomy 9:19 And I am frightened on account of the rage and the anger that the LORD was provoked by you to utterly destroy you. And the LORD hearkened to me even at that time. 

#### Deuteronomy 9:20 And upon Aaron the LORD was enraged exceedingly to utterly destroy him. And I made a vow also for Aaron in that time. 

#### Deuteronomy 9:21 And your sin which you made -- the calf; I took and I incinerated it in fire, and cut it down, and ground it down exceeding, until of which it became fine, and became as a cloud of dust. And I tossed the dust into the rushing stream, the one coming down from the mountain. 

#### Deuteronomy 9:22 And in Combustion, and in Test and in Tombs of the Desire, you were provoking the LORD your God. 

#### Deuteronomy 9:23 And when {sent you the LORD} from Kadesh Barnea, saying, Ascend and inherit the land which I give to you! that you resisted persuasion in the word of the LORD your God, and did not trust him, and did not listen to his voice. 

#### Deuteronomy 9:24 You were resisting the things towards the LORD from which day he was made known to you. 

#### Deuteronomy 9:25 And I beseeched before the LORD forty days and forty nights. Many things I beseeched; {said for the LORD} he would utterly destroy you. 

#### Deuteronomy 9:26 And I made a vow to God, and said, O Lord, the LORD, you should not utterly destroy your people, and your inheritance whom you ransomed in {strength your great}, of whom you led out of the land of Egypt by {hand your fortified}, and by {arm your high}. 

#### Deuteronomy 9:27 Remember Abraham, and Isaac, and Jacob, your attendants! ones to whom you swore by an oath according to yourself. You should not look upon the hardness of this people, and upon their acts of impiety, and their sins; 

#### Deuteronomy 9:28 lest should say the ones dwelling the land from where you led us from there, saying, Because {was not able the LORD} to bring them into the land which he said to them, and because of {detesting the LORD} them, he led them in the wilderness to kill them. 

#### Deuteronomy 9:29 And these are your people and your inheritance, of whom you led out of the land of Egypt by {strength your great} and by {arm your high}. 

#### Deuteronomy 10:1 In that time the LORD said to me, You dress stone for yourself -- two tablets of stone as the first! And ascend to me into the mountain, and make for yourself {ark a wooden}! 

#### Deuteronomy 10:2 And I will write upon the tablets the words which were on the {tablets first} which you broke, and you shall put them into the ark. 

#### Deuteronomy 10:3 And I made the ark from out of {wood incorruptible}. And I dressed the two {tablets stone} as the first. And I ascended into the mountain, and the two tablets were upon {two hands my}. 

#### Deuteronomy 10:4 And he wrote upon the tablets according to the {writing first}, the ten words which the LORD spoke to you in the mountain out of the midst of the fire in the day of the gathering. And {gave them the LORD} to me. 

#### Deuteronomy 10:5 And turning, I went down from the mountain, and I put the tablets into the ark which I made; and they were there as {gave charge to me the LORD}. 

#### Deuteronomy 10:6 And the sons of Israel departed from Beeroth of the sons of Jaakin to Mosera; there Aaron died, and he was entombed there. And {officiated as priest Eleazar his son} instead of him. 

#### Deuteronomy 10:7 From there they departed into Gudgodah; and from Gudgodah to Jobath, a land of rushing streams of waters. 

#### Deuteronomy 10:8 In that time the LORD separated the tribe of Levi to lift the ark of the covenant of the LORD, to stand before the LORD to officiate, and to invoke upon his name until this day. 

#### Deuteronomy 10:9 On account of this there is not to the Levites a portion or lot among their brethren. The LORD himself is his lot, as {told them the LORD your God}. 

#### Deuteronomy 10:10 And I stayed in the mountain forty days and forty nights; and the LORD listened to me, And in that time {did not want the LORD} to utterly destroy you. 

#### Deuteronomy 10:11 And the LORD said to me, Proceed, depart before this people, and let them enter and inherit the land! which I swore by an oath to their fathers to give to them. 

#### Deuteronomy 10:12 And now, Israel, what does the LORD your God ask from you, but only to fear the LORD your God, and to go in all his ways, and to love him, and to serve the LORD your God from {entire heart your}, and from {entire soul your}; 

#### Deuteronomy 10:13 to guard the commandments of the LORD your God, and his ordinances, as many as I give charge to you today, that {good to you it might be}. 

#### Deuteronomy 10:14 Behold, {is of the LORD your God the heaven}, and the heaven of the heaven, the earth and all as much as is in it. 

#### Deuteronomy 10:15 Except concerning your fathers, the LORD preferred to love them, and he chose their seed after them -- you, from all the nations according to this day. 

#### Deuteronomy 10:16 And you shall circumcise the hardness of your heart, and {your neck you shall not harden} any longer. 

#### Deuteronomy 10:17 For the LORD your God, he is God of gods, and Lord of lords, the {God great and strong and fearful} who does not marvel over a person, nor should take a bribe; 

#### Deuteronomy 10:18 the one executing judgment for a foreigner, and orphan, and widow; and he loves the foreigner so as to give to him bread and a garment. 

#### Deuteronomy 10:19 And you shall love the foreigner; {foreigners for you were} in the land of Egypt. 

#### Deuteronomy 10:20 The LORD your God you shall fear, and to him you shall serve, and to him you shall cleave, and upon his name you shall swear by an oath. 

#### Deuteronomy 10:21 He is your boasting, and he is your God, who did among you the great and the honorable things, these things which {beheld your eyes}. 

#### Deuteronomy 10:22 With seventy souls {went down your fathers} into Egypt. But now {made you the LORD your God} as the stars of the heaven in multitude. 

#### Deuteronomy 11:1 And you shall love the LORD your God, and you shall guard his injunctions, and his ordinances, and his commandments, and his judgments all the days. 

#### Deuteronomy 11:2 And you shall know today that I do not speak to your children, as many as are not knowing, nor knew the instruction of the LORD your God, and his magnificence, and the {hand fortified}, and the {arm high}, 

#### Deuteronomy 11:3 and his signs, and his miracles as many as he did in the midst of Egypt to Pharaoh king of Egypt, and all his land; 

#### Deuteronomy 11:4 and as many things as he did to the force of the Egyptians, their chariots, and their cavalry, as he inundated them in the water of the {sea red} upon their face pursuing them from the coming after you, and {destroyed them the LORD} until today's day; 

#### Deuteronomy 11:5 and as many things as he did to you in the wilderness, until you came into this place; 

#### Deuteronomy 11:6 and as many things as he did to Dathan and Abiram, sons of Eliab, son of Reuben; which {opening the earth} her mouth swallowed them, and their houses, and their tents, and all their means of support with them in the midst of all Israel; 

#### Deuteronomy 11:7 for your eyes saw all the works of the LORD, the great ones, as many as he did among you today. 

#### Deuteronomy 11:8 And you shall guard all of his commandments, as many as I give charge to you today, that you should live, and should manifoldly multiply, and you should enter, and should inherit the land into which you pass over the Jordan there to inherit it; 

#### Deuteronomy 11:9 that you should prolong your days upon the land of which the LORD swore by an oath to your fathers to give to them, and to their seed after them -- a land flowing milk and honey. 

#### Deuteronomy 11:10 For it is the land into which you enter there to inherit it; {not as the land of Egypt it is}, from where you went forth from there; whenever they sow the seed, and water with the feet, as a garden of vegetables. 

#### Deuteronomy 11:11 But the land into which you enter there to inherit it, {land is a mountainous} and plain; from out of the rain of the heaven it shall drink water; 

#### Deuteronomy 11:12 a land which the LORD your God oversees it always, as the eyes of the LORD your God are upon it from the beginning of the year and until the completion of the year. 

#### Deuteronomy 11:13 But if in hearing you should hear all his commandments, as many as I give charge to you today, to love the LORD your God, and to serve to him from {entire heart your}, and from {entire soul your}, 

#### Deuteronomy 11:14 then he will give the rain for your land according to season -- early and late; and you shall carry in your grain, and your wine, and your olive oil. 

#### Deuteronomy 11:15 And he shall give fodder in your fields to your cattle. And having eaten and having been filled up, 

#### Deuteronomy 11:16 take heed to yourselves! not widening your heart, that you should transgress, and should serve other gods, and should do obeisance to them; 

#### Deuteronomy 11:17 and {being enraged should be angry the LORD} with you, that he should hold together the heaven, and there will not be rain, and the earth shall not give of its fruit, and you shall be destroyed quickly from the {land good} which the LORD gave to you. 

#### Deuteronomy 11:18 And you shall put these words into your heart, and into your soul, and you shall affix them for a sign upon your hand, and it shall be unshaken before your eyes. 

#### Deuteronomy 11:19 And you shall teach {them your children}, to speak them sitting down in the house, and going in the way, and laying in bed, and arising. 

#### Deuteronomy 11:20 And you shall write them upon the lintels of your houses, and of your gates; 

#### Deuteronomy 11:21 that you should multiply your days, and the days of your sons, upon the land which the LORD swore by an oath to your fathers to give to them, as the days of heaven upon the earth. 

#### Deuteronomy 11:22 And it will be if hearing you should hear all these commandments which I give charge to you today, to do them, to love the LORD your God, and to go in all his ways, and to cleave to him; 

#### Deuteronomy 11:23 then the LORD will cast out all these nations from your face, and you shall inherit {nations great}, and stronger ones than you. 

#### Deuteronomy 11:24 Every place which ever {may tread the track of your foot} will be yours. From the wilderness and Antilebanon, and from the river of the great river Euphrates, and unto the sea at the descent of the sun it will be your boundaries. 

#### Deuteronomy 11:25 Not shall {withstand any one} against your face. The fear of you and the trembling because of you {shall place the LORD your God} upon the face of all the land, upon which ever you should mount upon it, in which manner he spoke to you. 

#### Deuteronomy 11:26 Behold, I give before you today a blessing and curse. 

#### Deuteronomy 11:27 The blessing, if you should hear the commandments of the LORD your God, as many as I give charge to you today. 

#### Deuteronomy 11:28 And the curse, if you do not hearken to the commandments of the LORD your God, as many as I give charge to you today, and you should wander from the way which I gave charge to you, having gone to serve other gods, ones who do not perceive. 

#### Deuteronomy 11:29 Then it will be whenever {should bring you the LORD your God} into the land into which you pass over there to inherit it, then you shall give the blessing upon mount Gerizim, and the curse upon mount Ebal. 

#### Deuteronomy 11:30 {not Behold are these} on the other side of the Jordan, behind the way of the descent of the sun in the land of Canaan, the people dwelling upon the descent, being next to Gilgal, neighboring the {oak high}? 

#### Deuteronomy 11:31 For you are passing over the Jordan, entering to inherit the land which the LORD our God gives to us by lot all the days. And you shall inherit and dwell in it. 

#### Deuteronomy 11:32 And you shall guard to do all his orders, and these judgments, which I give in your presence today. 

#### Deuteronomy 12:1 And these are the orders and the judgments, which you shall guard to do in the land of which the LORD the God of your fathers gives to you by lot, all the days of which you live upon the land. 

#### Deuteronomy 12:2 By destruction you shall destroy all the places in which {serve there the nations} their gods, whose lands you shall inherit them upon the {mountains high}, and upon the hills, and underneath every {tree bushy}. 

#### Deuteronomy 12:3 And you shall raze their shrines, and break their monuments; and {their sacred groves you shall cut down}; and the carvings of their gods you shall incinerate by fire; and you shall destroy their names from out of that place. 

#### Deuteronomy 12:4 You shall not do so with the LORD your God. 

#### Deuteronomy 12:5 But in the place which ever {should choose the LORD your God} from all of your tribes to name his name there, and to be called upon -- even you shall seek after and enter there. 

#### Deuteronomy 12:6 And you shall bring there the whole burnt-offerings of yours, and your sacrifices, and your tenths, and your vow offerings, and your voluntary offerings, and your acknowledgment offerings, the first-born of your oxen, and of your sheep. 

#### Deuteronomy 12:7 And you shall eat there before the LORD your God, and you shall be glad in all the things of which ever you should put your hands, you and your houses, in so far as {blessed you the LORD your God}. 

#### Deuteronomy 12:8 You shall not do according to all as many as we do here today -- each doing the pleasing thing before him. 

#### Deuteronomy 12:9 {not For you have} come unto the present time for the rest and for the inheritance which the LORD our God gives you. 

#### Deuteronomy 12:10 But you shall pass over the Jordan, and you shall dwell upon the land of which the LORD our God shall inherit to you; and he shall rest you from all your enemies round about; and you shall dwell with safety. 

#### Deuteronomy 12:11 And there will be the place which ever {should choose the LORD your God} {to be called upon his name} there -- there you shall bring all as many things as I give charge to you today; your whole burnt-offerings, and your sacrifices, and your tithes, and the first-fruits of your hands, and every choice thing of your gifts, as many as you should vow to the LORD. 

#### Deuteronomy 12:12 And you shall be glad before the LORD your God, you and your sons, and your daughters, and your manservants, and your maidservants, and the Levite at your gates; for there is not to him a portion nor lot with you. 

#### Deuteronomy 12:13 Take heed to yourself that you should not offer of your whole burnt-offerings in any place of which ever you should behold, 

#### Deuteronomy 12:14 but only in the place which {should choose the LORD your God} it, in one of your cities -- there you shall offer your whole burnt-offerings, and there you shall do all as many things as I give charge to you today. 

#### Deuteronomy 12:15 But in all your desire you shall sacrifice and shall eat meats according to the blessing of the LORD your God which he gave to you in every city -- the unclean among you, and the clean {the same shall eat it}, as a doe or stag. 

#### Deuteronomy 12:16 Except the blood you shall not eat upon the land; you shall pour it out as water. 

#### Deuteronomy 12:17 You shall not be able to eat in your cities the tithe of your grain, and your wine, and your olive oil, the first-born of your oxen, and of your sheep, and all the vows, as many as you should have vowed, and your acknowledgment offerings, and the first-fruits of your hands. 

#### Deuteronomy 12:18 But only before the LORD your God shall you eat them in the place in which ever {should choose the LORD your God himself} for you and your son and your daughter, your manservant and your maidservant, and the Levite, and the foreigner in your cities. And you shall be glad before the LORD your God over all of whatsoever you should put {upon your hand}. 

#### Deuteronomy 12:19 Take heed to yourself! that you should not abandon the Levite all the time, as much as you should live upon the land. 

#### Deuteronomy 12:20 And if {should widen the LORD your God} your borders, just as he spoke to you, and you shall say, I will eat meats; if {should desire your soul} so as to eat meats, in every desire of your soul, you shall eat meats. 

#### Deuteronomy 12:21 And if at a farther distance from you be the place which ever {should choose the LORD your God} to call upon his name there, then you shall sacrifice from your oxen, and from your sheep what ever {should give to you the LORD your God}, in which manner I gave charge to you; and you shall eat in your cities according to the desire of your soul. 

#### Deuteronomy 12:22 As {are eaten the doe and the stag}, so shall you eat it; the unclean among you, and the clean {likewise shall eat it}. 

#### Deuteronomy 12:23 Take heed strongly! to not eat blood, for its blood is life. You shall not eat life with the meats. 

#### Deuteronomy 12:24 You shall not eat blood; upon the earth you shall pour it out as water. 

#### Deuteronomy 12:25 You shall not eat it, that good should happen to you, and to your sons after you, if you should do the good and the pleasing thing before the LORD your God. 

#### Deuteronomy 12:26 Except your holy things, which ever should come to you, and {your vow offerings taking}, you shall come into the place which ever {should choose the LORD your God} {to be called upon his name} there. 

#### Deuteronomy 12:27 And there you shall offer your whole burnt-offerings; the meats you shall offer upon the altar of the LORD your God; but the blood of your sacrifices you shall pour towards the base of the altar of the LORD your God, but the meats you may eat. 

#### Deuteronomy 12:28 Guard and hearken! and you shall do all the words which I give charge to you, that good should happen to you, and to your sons through the eon, if you should do the pleasing and the good thing before the LORD your God. 

#### Deuteronomy 12:29 But if {should utterly destroy the LORD your God} the nations into which you enter there to inherit their land from your presence, and you should inherit them, and dwell in their land; 

#### Deuteronomy 12:30 take heed to yourself! you should not seek to follow them after their being utterly destroyed from your face. In no way should you seek after their gods, saying, How {act these nations} with their gods {shall act I also}. 

#### Deuteronomy 12:31 You shall not do so to the LORD your God; for the abominations which the LORD detested they did with their gods; for also their sons and their daughters they incinerated in fire to their gods. 

#### Deuteronomy 12:32 Every word which I give charge to you today, this you shall guard to do. You shall not add unto it, nor remove from it. 

#### Deuteronomy 13:1 And if there should rise up among you a prophet or one dreaming dreams, and he should give to you a sign or miracle, 

#### Deuteronomy 13:2 and it should come to pass -- the sign or the miracle which he spoke to you, saying, We should go and serve other gods who we do not know. 

#### Deuteronomy 13:3 You shall not hearken to the words of that prophet, or the one dreaming that dream; for {tests the LORD your God} you, to know, if you love the LORD your God from {entire heart your} and from {entire soul your}. 

#### Deuteronomy 13:4 {after the LORD your God You shall go}, and him you shall fear, and his commandments you shall keep, and his voice you shall hearken to, and to him you shall serve, and to him you shall be added to. 

#### Deuteronomy 13:5 And that prophet, or {the dream dreaming that one} shall die; for he spoke to cause you to wander from the LORD your God (the one leading you from the land of Egypt, ransoming you from slavery) to push you from the way of which {gave charge to you the LORD your God} to go by it. And you shall remove {wicked thing from you their}. 

#### Deuteronomy 13:6 But if there should enjoin you, your brother from your father, or from your mother, or of your son, or of your daughter, or of your wife, or one in your bosom, or {friend your equal} to your soul, in private saying, We should go and should serve other gods which neither {know you nor your fathers}, 

#### Deuteronomy 13:7 of the gods of the nations surrounding you, of the ones near to you, or of the ones far from you, from the uttermost part of the earth, unto the uttermost part of the earth; 

#### Deuteronomy 13:8 you shall not acquiesce to him, and you shall not hear him, and you shall not spare your eye upon him, and you shall not show mercy upon him, nor shall you shelter him. 

#### Deuteronomy 13:9 Announcing, you shall announce concerning him, and your hand shall be upon him as first to kill him, and the hand of all the people upon him last. 

#### Deuteronomy 13:10 And they shall throw stones at him with stones, and he shall die; for he sought to abstain you from the LORD your God, the one leading you from the land of Egypt, from the house of slavery. 

#### Deuteronomy 13:11 And all Israel hearing, shall fear, and shall not add to do again according to {matter this wicked} among you. 

#### Deuteronomy 13:12 And if it should be heard in one of your cities, which the LORD your God gives to you for you to dwell there, saying, 

#### Deuteronomy 13:13 {came forth Men lawbreakers} from you, and left all the ones dwelling in their city, saying, We should go and serve other gods, which you did not know; 

#### Deuteronomy 13:14 then you shall examine, and shall ask, and shall search exceedingly; and behold, {true be clearly if the word has taken place abomination that this} among you; 

#### Deuteronomy 13:15 then by doing away with, you shall do away with all the ones dwelling in that city by carnage of the sword; under anathema you shall devote it to consumption, and all the things in it, and all its cattle by the mouth of the sword. 

#### Deuteronomy 13:16 And all its spoils you shall bring together into its corridors, and you shall burn the city by fire, and all its spoils in full assembly before the LORD your God; and it shall be uninhabited into the eon; it shall not be rebuilt again. 

#### Deuteronomy 13:17 And you shall not cleave to anything of that being offered up for consumption as anathema in your hand so that the LORD should be turned away from the rage of his anger, and should grant to you mercy, and should show mercy on you, and should multiply you in which manner the LORD swore by an oath to your fathers; 

#### Deuteronomy 13:18 if you should hearken to the voice of the LORD your God, to guard all his commandments, which I give charge to you today, to do the good and the pleasing thing before the LORD your God. 

#### Deuteronomy 14:1 You are sons of the LORD your God. You shall not make baldness between your eyes for the dead. 

#### Deuteronomy 14:2 For {people a holy you are} to the LORD your God, and {chose you the LORD your God} to become {people his prized} of all the nations of the ones upon the face of the earth. 

#### Deuteronomy 14:3 You shall not eat any abomination. 

#### Deuteronomy 14:4 These are the cattle which you shall eat -- the calf of the oxen, and a lamb of the sheep, and a young he-goat of the goats, 

#### Deuteronomy 14:5 the stag, and doe, and roebuck, and antelope, and white-tailed hart, and gazelle, and cameleopard. 

#### Deuteronomy 14:6 Every beast cloven hoof, and cloven-footed to claw with two claws, and embarks chewing the cud among the cattle, these you shall eat. 

#### Deuteronomy 14:7 And these you shall not eat -- from of the ones embarking chewing the cud, and of the ones being cloven of the hoofs, and clawing cloven-footed -- the camel, and hare, and hyrax -- for they embark chewing the cud, but the hoof is not cloven, these are unclean to you. 

#### Deuteronomy 14:8 And the pig, for {is cloven of hoof this one}, and claws cloven-footed of hoof, but this one as far as chewing the cud does not chew the cud -- this one is unclean to you; from their meats you shall not eat, and of their decaying flesh you shall not touch. 

#### Deuteronomy 14:9 And these you shall eat from all the ones in the waters -- all as much as there are {on them fins and scales} you shall eat. 

#### Deuteronomy 14:10 And all as much as there is not {to them fins and scales} you shall not eat; {unclean these shall be} to you. 

#### Deuteronomy 14:11 {every fowl clean You shall eat}. 

#### Deuteronomy 14:12 And these you shall not eat of them -- the eagle, and the griffin, and the osprey, 

#### Deuteronomy 14:13 and the vulture, and the kite, and the ones likened to it, 

#### Deuteronomy 14:14 and every crow and the ones likened to it, 

#### Deuteronomy 14:15 and the ostrich, and owl, and gull, 

#### Deuteronomy 14:16 and heron, and swan, and ibis, 

#### Deuteronomy 14:17 and cormorant, and hawk, and the ones likened to it, and hoopoe, and long-eared owl, 

#### Deuteronomy 14:18 and pelican, and curlew, and the ones likened to it, and the purple-legged stork, and bat. 

#### Deuteronomy 14:19 All the crawling things of the winged creatures -- {unclean these are} to you, you shall not eat from them. 

#### Deuteronomy 14:20 Every winged creature being clean you shall eat. 

#### Deuteronomy 14:21 Any decaying flesh you shall not eat. To the foreigner in your cities it shall be given, and he shall eat it; or you shall render it to the alien. For {people a holy you are} to the LORD your God. You shall not boil a lamb in the milk of his mother. 

#### Deuteronomy 14:22 A tenth you shall tithe of all {produce of seed your}, the produce of your field year by year. 

#### Deuteronomy 14:23 And you shall eat it before the LORD your God in the place in which ever {should choose the LORD your God} {to be called upon his name} there. You shall bring the tithes of your grain, and of your wine, and of your olive oil, and the first-born of your oxen, and of your sheep, that you should learn to fear the LORD your God all the days. 

#### Deuteronomy 14:24 And if {far should be the journey} from you, and you should not be able to offer them, because {is far from you the place} which ever {should choose the LORD your God} {to be called upon his name} there, that {shall bless you the LORD your God}; 

#### Deuteronomy 14:25 then you shall render for them of silver, and you shall take the silver in your hands, and you shall go to the place which ever {should choose the LORD your God} it. 

#### Deuteronomy 14:26 And you shall give the silver for all, of what ever {should desire your soul}, for oxen, or for sheep, or for wine, or for liquor, or for any thing of which ever {should desire your soul}. And you shall eat there before the LORD your God. And you shall be glad, you and your house. 

#### Deuteronomy 14:27 And the Levite in your cities -- you shall not abandon him, for there is not to him a portion nor a lot with you. 

#### Deuteronomy 14:28 After three years you shall bring forth every tenth of your produce; in that year you shall place it in your cities. 

#### Deuteronomy 14:29 And {shall come the Levite}, for there is no portion for him nor lot with you, and the foreigner, and the orphan, and the widow in your cities, and they shall eat and shall be filled; that {should bless you the LORD your God} in all the works of your hands, in whichever ones you should do. 

#### Deuteronomy 15:1 For seven years you shall make a release. 

#### Deuteronomy 15:2 And thus is the order of the release. You shall cancel every {loan private}, the one which {owes to you your neighbor}. And {of your brother you shall not exact payment}, for it has been called a release to the LORD your God. 

#### Deuteronomy 15:3 The alien -- you shall exact as much as might be due you from him; but {for your brother a release you shall make} of your loan. 

#### Deuteronomy 15:4 For there shall not be among you one lacking; for by a blessing {shall bless you the LORD your God} in the land which the LORD your God gives to you by lot to inherit it. 

#### Deuteronomy 15:5 But if in hearing you should hearken to the voice of the LORD your God, to guard and to do all these commandments which I give charge to you today, 

#### Deuteronomy 15:6 for the LORD your God blessed you in which manner he spoke to you; then you shall lend {nations to many}, but you shall not borrow; and you shall control {nations many}, but of you they shall not control. 

#### Deuteronomy 15:7 And if there should be among you one lacking from your brethren in one of your cities in the land which the LORD your God gives to you, you shall not disregard your heart, nor in any way close your hand from your brother -- the one wanting. 

#### Deuteronomy 15:8 In opening, you shall open your hands to him, and {a loan you shall lend} to him as much as he wants, and according to as much as he lacks. 

#### Deuteronomy 15:9 Take heed to yourself! there be not {thing a hidden} in your heart, a violation of the law, saying, {approaches The year seventh}, the year of the release; and {should be wicked your eye} towards your brother that is wanting, that you should not give to him; and he shall call to aid against you to the LORD, and there shall be in you {sin a great}. 

#### Deuteronomy 15:10 Giving, you shall give to him, and {a loan you shall lend to him} as much as he wants of you. And you shall not fret in your heart of your giving to him, for on account of this matter {will bless you the LORD your God} in all your works, and in all things of which ever you should put your hand to. 

#### Deuteronomy 15:11 For in no way should {fail the one lacking} from your land. Because of this I give charge to you to do this thing, saying, In opening, you shall open your hands to {brother your needy}, and to the one wanting upon your land. 

#### Deuteronomy 15:12 And if {should be sold to you your brother a Hebrew man}, or the Hebrew woman, he shall serve to you six years, and the seventh you shall send him free from you. 

#### Deuteronomy 15:13 And whenever you should send him free from you, you shall not send him empty. 

#### Deuteronomy 15:14 With supplies you shall provide him from your sheep, and from your grain, and from your wine vat. As {blessed you the LORD your God} you shall give to him. 

#### Deuteronomy 15:15 And you shall remember that you were a servant in the land of Egypt, and {ransomed you the LORD your God} from there. On account of this I give charge to you to do this thing. 

#### Deuteronomy 15:16 But if he should say to you, I shall not go forth from you, for he loves you, and your house, for it is good to him to be by you; 

#### Deuteronomy 15:17 then you shall take the shoemaker's awl, and make a hole in his ear against the door, and he will be to you a servant into the eon. And of your maidservant you shall do likewise. 

#### Deuteronomy 15:18 {not hard It shall be} before you sending them free from you, for the yearly wage of the hireling -- he served to you six years. And {shall bless you the LORD your God} in all what ever you should do. 

#### Deuteronomy 15:19 Every first-born which ever should give birth among your oxen, and among your sheep, {the males you shall sanctify} to the LORD your God. You shall not work with {first-born calf your}, and in no way should you shear the first-born of your sheep. 

#### Deuteronomy 15:20 Before the LORD your God you shall eat it year by year, in the place in which ever {should choose the LORD your God} -- you and your house. 

#### Deuteronomy 15:21 And if there might be in it a blemish -- lame or blind, or even any {blemish severe}, you shall not sacrifice it to the LORD your God. 

#### Deuteronomy 15:22 In your cities you shall eat it. The unclean in you and the clean likewise shall eat as the doe or stag. 

#### Deuteronomy 15:23 Except its blood you shall not eat; {upon the ground you shall pour it} as water. 

#### Deuteronomy 16:1 Guard the month of the new corn! And you shall observe the passover to the LORD your God, for in the month of the new corn {led you the LORD your God} out of Egypt by night. 

#### Deuteronomy 16:2 And you shall sacrifice the passover to the LORD your God -- sheep and oxen in the place in which ever {should choose the LORD your God to be called upon his name} there. 

#### Deuteronomy 16:3 You shall not eat it with yeast; seven days you shall eat it with unleavened breads, bread of affliction; for in haste you came forth from out of Egypt at night; that you should remember the day of your departure from out of the land of Egypt all the days of your life. 

#### Deuteronomy 16:4 There shall not be seen by you any yeast in all your boundaries for seven days, and you shall not go to bed with any of the meats, which ever you should have sacrificed in the evening, left over the {day first} in the morning. 

#### Deuteronomy 16:5 You shall not be able to sacrifice the passover in any one of your cities which the LORD your God gives to you; 

#### Deuteronomy 16:6 but only in the place which ever {should choose the LORD your God to be called upon his name} there. You shall sacrifice the passover at evening towards the descent of the sun, in the time which you came forth from out of the land of Egypt. 

#### Deuteronomy 16:7 And you shall boil, and bake, and eat in the place in which ever {should choose the LORD your God} it. And you shall return in the morning and go to your houses. 

#### Deuteronomy 16:8 Six days you shall eat unleavened breads, and the {day seventh} is a recess holiday to the LORD your God; you shall not do on it any work except as much as shall be done for your life. 

#### Deuteronomy 16:9 Seven {periods of seven entire} you shall count out to yourself; with the beginning of your sickle upon the harvest you shall begin to count out seven periods of seven. 

#### Deuteronomy 16:10 And you shall observe the holiday of the period of sevens to the LORD your God, as your hand is strong, in as much as {should give to you in so far as he blessed you the LORD your God}. 

#### Deuteronomy 16:11 And you shall be glad before the LORD your God, you and your son and your daughter, your manservant, and your maidservant, and the Levite in your cities, and the foreigner, and the orphan, and the widow among you, in the place in which ever {should choose the LORD your God} {to be called upon his name} there. 

#### Deuteronomy 16:12 And you shall remember that {a servant you were} in the land of Egypt. And you shall guard and observe these commandments. 

#### Deuteronomy 16:13 The holiday of tents you shall observe to yourself seven days, in your bringing from your threshing-floor, and from your wine vat. 

#### Deuteronomy 16:14 And you shall be glad in your holiday, you and your son, and your daughter, your manservant, and your maidservant, and the Levite, and the foreigner, and the orphan, and the widow being in your cities. 

#### Deuteronomy 16:15 Seven days you shall solemnize a holiday to the LORD your God in the place in which ever {should choose the LORD your God} for himself. But if {should bless you the LORD your God} in all your offspring, and in every work of your hands, then you shall be glad. 

#### Deuteronomy 16:16 Three times of the year {shall appear every male of yours} before the LORD your God in the place in which ever {should have chosen the LORD} in the holiday of the unleavened breads, and in the holiday of the period of sevens, and in the holiday of the pitching of tents. You shall not appear in the presence of the LORD your God empty. 

#### Deuteronomy 16:17 Each offering according to the power of your hands; according to the blessing of the LORD your God which he gave to you. 

#### Deuteronomy 16:18 Judges and judicial recorders you shall ordain to yourself in all your cities, which the LORD your God gives to you according to tribes. And they shall judge the people {judgment with just}. 

#### Deuteronomy 16:19 They shall not turn aside a judgment, they shall not discriminate a person, nor shall they take bribes; for the bribes make blind the eyes of the wise, and lift away the words of the just. 

#### Deuteronomy 16:20 Justly {justice you shall pursue}, that you should live, and entering you should inherit the land which the LORD your God gives to you. 

#### Deuteronomy 16:21 You shall not plant for yourself a sacred grove; any tree by the altar of the LORD your God you shall not produce for yourself. 

#### Deuteronomy 16:22 You shall not set up for yourself a monument which {detests the LORD your God}. 

#### Deuteronomy 17:1 You shall not sacrifice to the LORD your God a calf or sheep in which there is in it a blemish, any thing in a sorry state, for {an abomination to the LORD your God it is}. 

#### Deuteronomy 17:2 But if there should be among you, in one of your cities which the LORD your God gives to you, a man or woman who shall do the wicked thing before the LORD your God, to pass by his covenant, 

#### Deuteronomy 17:3 and going forth should serve other gods, and should do obeisance to them -- to the sun, or the moon, or to any of the ones of the cosmos of the heaven, which I assigned not; 

#### Deuteronomy 17:4 and it should be announced to you, and you heard, and you sought exceedingly, and behold, if truly {has happened the thing} {came to pass that this abomination} in Israel; 

#### Deuteronomy 17:5 then you shall lead out that man or that woman, (the ones who made {order this wicked},) unto the gate. And you shall stone them with stones, and they shall come to an end. 

#### Deuteronomy 17:6 By two witnesses or three witnesses one shall die. The one dying shall not die by one witness. 

#### Deuteronomy 17:7 And the hand of the witnesses shall be upon him among the first to put him to death, and the hand of all of the people upon him last. And you shall lift away the wicked thing {from you of them}. 

#### Deuteronomy 17:8 But if {should be powerless for you to decide a matter in a judgment}, between blood and blood, and between judgment and judgment, and between blow and blow, and between dispute and dispute, for matters of judgment in your cities; then rising up you shall ascend unto the place which ever {should choose the LORD your God to be called upon for his name} there. 

#### Deuteronomy 17:9 And you shall come to the priests of the Levites, and to the judge, who ever happens to be in those days; and seeking after the matter they shall announce to you the judgment. 

#### Deuteronomy 17:10 And you shall do according to the thing, which ever they should announce to you from the place of which ever {should choose the LORD your God}. And you shall guard exceedingly to do according to all as much as the law should be established to you. 

#### Deuteronomy 17:11 According to the law, and according to the judgment, which ever they should tell to you, thus you shall do it. You shall not turn aside from the matter of which ever they should announce to you, right nor left. 

#### Deuteronomy 17:12 And the man who ever should do in pride to not obey the priest standing beside to officiate in the name of the LORD your God, or the judge who ever should be in those days, then {shall die that man}, and you shall lift away the wicked one from out of Israel. 

#### Deuteronomy 17:13 And all the people hearing shall fear, and shall not be impious any more. 

#### Deuteronomy 17:14 And whenever you should enter into the land which the LORD your God gives to you by lot, and you should inherit it, and should dwell upon it, and you should say, I shall place over myself a ruler, as also the rest of the nations round about me; 

#### Deuteronomy 17:15 then in placing, you shall place over yourself a ruler, which ever {should choose the LORD your God} -- him from out of your brethren you shall place over yourself as ruler. You shall not be able to place over yourself {man an alien}, for {not your brother he is}. 

#### Deuteronomy 17:16 Furthermore he shall not multiply to himself a cavalry, nor shall he return the people to Egypt, so that he should not multiply to himself a cavalry. For the LORD said to you, You shall not add to return this way any more. 

#### Deuteronomy 17:17 And he shall not multiply to himself wives, that he shall not change over his heart. And silver and gold he shall not multiply to himself exceedingly. 

#### Deuteronomy 17:18 And it will be whenever he shall be settled in the chair of his office, then he shall write for himself this second book of the law into a scroll by the hands of the priests of the Levites. 

#### Deuteronomy 17:19 And it shall be with him, and he shall read in it all the days of his life; that he should learn to fear the LORD his God, to guard all these commandments, and {these ordinances to do}; 

#### Deuteronomy 17:20 that {should not be raised up high his heart} above his brethren; that he should not transgress from the commandments, right or left; so that he should be a long time in his office -- he and his sons among the sons of Israel. 

#### Deuteronomy 18:1 There will not be to the priests, to the Levites, the entire tribe of Levi, a portion nor a lot with Israel. The yield offerings of the LORD are their lot -- they shall eat them. 

#### Deuteronomy 18:2 {a lot And there will not be} to him among his brethren; the LORD himself is his lot, in so far as he said to him. 

#### Deuteronomy 18:3 And this is the distinguishing thing of the priests -- the things from the people, from the ones sacrificing the sacrifices, if both a calf, or if also a sheep -- that you shall give the shoulder to the priest, and the jawbones, and the large intestine, 

#### Deuteronomy 18:4 and the first-fruits of your grain, and of your wine, and of your olive oil; and the first-fruit of the shearing of your sheep you shall give to him: 

#### Deuteronomy 18:5 for {chose him the LORD your God} from out of all your tribes, to stand before the LORD God, to officiate in the name of the LORD, he and his sons all the days. 

#### Deuteronomy 18:6 And if {should come the Levite} from one of your cities of all the sons of Israel, of which he himself sojourns, that {desires his soul}, into the place which ever the LORD should choose; 

#### Deuteronomy 18:7 then he shall officiate in the name of the LORD his God, as all his brethren the Levites, the ones standing there before the LORD. 

#### Deuteronomy 18:8 {a portion having been portioned He shall eat}, besides the sale of the things of his family. 

#### Deuteronomy 18:9 And whenever you should enter into the land which the LORD your God gives to you, you shall not learn to do according to the abominations of those nations. 

#### Deuteronomy 18:10 There shall not be found in you one purging his son or his daughter in fire, or one using oracles for divination, or one prognosticating and foretelling, 

#### Deuteronomy 18:11 an administer of potions, one charming an enchantment, one who delivers oracles, and an observer of signs asking of the dead. 

#### Deuteronomy 18:12 {is For an abomination to the LORD your God every one doing these things}. For because of these abominations the LORD your God shall utterly destroy them from your face. 

#### Deuteronomy 18:13 You shall be perfect before the LORD your God. 

#### Deuteronomy 18:14 For these nations which you inherit them, these {prognostications and divinations shall hear}; but to you {did not so give the LORD your God}. 

#### Deuteronomy 18:15 A prophet from out of your brethren, as me, {shall raise up to you the LORD your God}; him you shall hear. 

#### Deuteronomy 18:16 According to all as much as you asked of the LORD your God in Horeb, in the day of the assembly, saying, We shall not add to hear the voice of the LORD your God, and {fire this great} we shall not see any longer, nor shall we die. 

#### Deuteronomy 18:17 And the LORD said to me, Rightly all as much as they spoke. 

#### Deuteronomy 18:18 {a prophet I shall raise up} to them from amidst their brethren, as you, and I shall put my word in his mouth; and he shall speak to them in so far as I give charge to him. 

#### Deuteronomy 18:19 And the man who ever should not hear his words, as many as {should speak the prophet} in my name, I shall exact punishment from him. 

#### Deuteronomy 18:20 Except the prophet, who ever should be impious to speak a word in my name, which I did not assign to him to speak, and who ever should speak in the name of other gods, {shall die that prophet}. 

#### Deuteronomy 18:21 But if you should say in your heart, How shall we know the word which {spoke not the LORD}? 

#### Deuteronomy 18:22 As many things as {should speak the prophet} in the name of the LORD, and {should not take place the thing}, and {should not come to pass this thing} which {spoke not the LORD}; through impiety {spoke the prophet}; you shall not receive from him. 

#### Deuteronomy 19:1 But whenever {should remove from view the LORD your God} the nations which your God gives to you of their land, and you should inherit them, and should dwell in their cities, and in their houses; 

#### Deuteronomy 19:2 {three cities you shall draw apart to yourself} in the midst of your land, which the LORD your God gives to you. 

#### Deuteronomy 19:3 Take thought to yourself of the way, and you shall make three parts the boundaries of your land which {divides to you the LORD your God}, and it will be there for a refuge to every man-slayer. 

#### Deuteronomy 19:4 And this will be the order for the man-slayer, who ever should flee there, and shall live -- who ever should strike his neighbor unintentionally, and this one was not detesting him before yesterday and before the third day. 

#### Deuteronomy 19:5 And who ever should enter with the neighbor into the oak grove to bring wood, and {was knocked back his hand} with the axe while felling the wood, and {in falling off the iron implement} from the wood handle should happen by chance to strike the neighbor, and he should die; this one shall take refuge in one of these cities, and shall live. 

#### Deuteronomy 19:6 Lest {pursue the one acting as next of kin for blood} after the man-slayer, because {is overheated his heart}, and overtakes him, if it might be a longer way, and he strikes his life and he should die. And {to this man there is no judgment of death}, for {not detesting he was} him before yesterday and before the third day. 

#### Deuteronomy 19:7 Because of this I give charge to you this thing, saying, Three cities you shall draw apart to yourself. 

#### Deuteronomy 19:8 And if {should widen the LORD your God} your borders, in which manner he swore by an oath to your fathers, and {should give to you the LORD} all the land which he said he would give to your fathers; 

#### Deuteronomy 19:9 if you should listen to do all these commandments which I give charge to you today, to love the LORD your God, to go in all his ways all the days; then you shall add to yourself again three cities to these three. 

#### Deuteronomy 19:10 And {shall not be poured out the blood of the innocent} in the land which the LORD your God gives to you by lot, and there will not be among you blood liability. 

#### Deuteronomy 19:11 But if there should be a man detesting his neighbor, and he shall lie in wait for him, and should rise up against him, and should strike his life, and he should die, and he should flee into one of these cities; 

#### Deuteronomy 19:12 then they shall send the council of elders of his city, and they shall take him from there, and shall deliver him into the hands to the one acting as next of kin for blood, and he shall die. 

#### Deuteronomy 19:13 You shall not spare your eye for him, and you shall cleanse the blood for the innocent from out of Israel, and {good to you it will be}. 

#### Deuteronomy 19:14 You shall not move the boundaries of your neighbor, which they established, the ones prior of you among your inheritance, which you inherited in the land, which the LORD your God gives to you by lot. 

#### Deuteronomy 19:15 You shall not adhere to {witness one} in witnessing against a man for any injustice, and for any sin, and for any sin which ever he should have sinned. By the mouth of two witnesses, and by the mouth of three witnesses {shall be established every word}. 

#### Deuteronomy 19:16 And if {should stand witness an unjust} against a man alleging his impiety; 

#### Deuteronomy 19:17 then {shall stand the two men}, in which {is with them the dispute}, before the LORD, and before the priests, and before the judges -- the ones as might be in those days. 

#### Deuteronomy 19:18 And {should inquire the judges} exactly. And behold, {witness if an unjust} witnessed unjustly, and stood against his brother, 

#### Deuteronomy 19:19 then you shall do to him in which manner he devised wickedly to do against his brother, and you shall lift away the wicked from yourselves. 

#### Deuteronomy 19:20 And the rest hearing shall fear, and they shall not add again to do according to {thing this wicked} among you. 

#### Deuteronomy 19:21 {shall not spare Your eye} him; life for life, eye for eye, tooth for tooth, hand for hand, foot for foot; in so far as any should give a blemish to the neighbor, thus you shall give to him. 

#### Deuteronomy 20:1 And if you should go forth to war against your enemies, and you should behold a horse, and rider, and {people many more} than you, do not be fearful of them! for the LORD your God is with you, the one bringing you from the land of Egypt. 

#### Deuteronomy 20:2 And it will be whenever you should approach to the war, that {drawing near the priest} shall speak to the people, and shall say to them, 

#### Deuteronomy 20:3 Hear, O Israel! You go today to war with your enemies; do not loosen your heart; do not fear nor be devastated, nor turn aside from their face! 

#### Deuteronomy 20:4 For the LORD your God, the one going forth with you, he shall join in war with you against your enemies, and he shall preserve you. 

#### Deuteronomy 20:5 And {shall speak the scribes} to the people, saying, Who is the man building {house a new}, and did not dedicate it? Let him go and return to his house! lest he die in the war, and {man another} shall dedicate it. 

#### Deuteronomy 20:6 And Who is the man whoever plants a vineyard, and was not glad from it? Let him go, and let him return to his house! lest he should die in the war, and {man another} be glad from out of his labor. 

#### Deuteronomy 20:7 And who is the man who has espoused a woman, and did not take her? Let him go, and let him return to his house! lest he die in the war, and {man another} shall take her. 

#### Deuteronomy 20:8 And {shall add the scribes} to speak to the people, and shall say, Who is the man, the one fearing and timid in the heart? Let him go, and let him return to his house! that he should not make timid the heart of his brother, as he. 

#### Deuteronomy 20:9 And it will be whenever {should cease the scribes} speaking to the people, that they shall place rulers of the military taking lead of the people. 

#### Deuteronomy 20:10 And if you should come forward to a city to wage war against it, that you should call them forth with peace. 

#### Deuteronomy 20:11 And it shall be if then they should peaceably answer you, and open to you, it shall be that all the people being found in it shall be {to you tributaries}, and subjects to you. 

#### Deuteronomy 20:12 But if they should not obey you, and should make {against you war}, and you shall besiege it, 

#### Deuteronomy 20:13 and {shall deliver it the LORD your God} into your hands, then you shall strike every male of it by carnage of the sword, 

#### Deuteronomy 20:14 except the women and the belongings. And all the cattle, and all as much as exists in the city, and all the chattel you shall despoil for yourself, and you shall eat all the plunder of your enemy, whom the LORD your God gives to you. 

#### Deuteronomy 20:15 Thus you shall do for all the cities {far away being} from you exceedingly, which are not from the cities of these nations which the LORD your God gives to you to inherit their land. 

#### Deuteronomy 20:16 But behold, from the cities of these nations which the LORD your God gives to you to inherit their land, you shall not take alive any one breathing. 

#### Deuteronomy 20:17 But you shall devote them to consumption -- the Hittite, and the Amorite, and the Canaanite, and Perizzite, and Hivite, and Jebusite, and Gergesite; in which manner {gave charge to you the LORD your God}; 

#### Deuteronomy 20:18 that they should not teach you to do all their abominations, as many as they made unto their gods, that you shall sin before the LORD your God. 

#### Deuteronomy 20:19 But if you should besiege around a city {days many} to wage war against it for taking it, you shall not utterly destroy its trees by putting upon them an iron axe; but of it you shall eat, {it down but you shall not cut}; nor is a man {the tree in the grove to enter unto} from your presence for the siege mound? 

#### Deuteronomy 20:20 But the tree which you know that {not fruit-bearing it is}, this you shall annihilate, and you shall cut it, and shall build a siege mound at the city, whichever makes {against you war}, until whenever it should be delivered up. 

#### Deuteronomy 21:1 And if {should be found a slain person} in the earth (which the LORD your God gives to you to inherit) fallen in the plain, and they do not know the one striking him; 

#### Deuteronomy 21:2 there shall come forth your council of elders, and your judges, and they shall measure out the distances of the cities round about the slain person; 

#### Deuteronomy 21:3 and it shall be to the city near to the slain person, that {shall take the council of elders of that city} a heifer from the oxen, which has not worked, and which did not draw a yoke; 

#### Deuteronomy 21:4 and {shall bring the council of elders of that city} the heifer into {ravine a rough} which has not been worked, nor sowed; and they shall hamstring the heifer in the ravine, 

#### Deuteronomy 21:5 and {shall come forward the priests the Levites}, for {chose them the LORD your God} to stand beside him, and to bless over his name, and by their mouth will be every dispute and every blow decided. 

#### Deuteronomy 21:6 And every one of the council of elders of that city, the ones approaching the slain person, shall wash their hands over the head of the heifer -- the one being hamstrung in the ravine. 

#### Deuteronomy 21:7 And answering they shall say, Our hands did not pour out this blood, and our eyes have not seen it. 

#### Deuteronomy 21:8 Let kindness come to your people Israel, whom you ransomed from the land of Egypt, O LORD, that there should not be {blood innocent} to your people Israel. And {shall be atoned for to them the blood}. 

#### Deuteronomy 21:9 And you shall lift away the {blood innocent} from you of them, if you should do the good and the pleasing thing before the LORD your God. 

#### Deuteronomy 21:10 And whenever you should go forth to war with your enemies, and {should deliver them up the LORD your God} into your hands, that you shall despoil them by plunder. 

#### Deuteronomy 21:11 And should you behold among the spoils a woman good to the sight, and should ponder her, and you should take her to yourself for a wife; 

#### Deuteronomy 21:12 then you shall bring her inside into your house, and you shall shave her head, and trim her nails; 

#### Deuteronomy 21:13 and you shall remove the garments of her captivity from her, and you shall seat her in your house, and she shall weep over her father and mother for a month of days; and after this you shall enter to her, and you shall be living together with her, and she shall be your wife. 

#### Deuteronomy 21:14 And it shall be if you should not want her, you shall send her free, and for sale you shall not sell her for silver, you shall not disrespect her, for you humbled her. 

#### Deuteronomy 21:15 But if there be to a man two wives, one of them being loved, and one of them being detested, and they should bear with him, both the one being loved and the one being detested, and {is born son the first-born} of the one being detested, 

#### Deuteronomy 21:16 then it shall be in which ever day he should divide by lot to his sons of his possessions, he shall not be able to give the right of the first-born to the son of the one being loved, overlooking the son of the one being detested -- the first-born. 

#### Deuteronomy 21:17 But the first-born son of the one being detested he shall recognize to give to him double from all which ever should be found by him, for this one is {beginning child his}, and to this one {is fitting the rights of the first-born}. 

#### Deuteronomy 21:18 And if any might have a son resisting persuasion, and an irritant, not obeying the voice of his father, and the voice of his mother, and they should correct him, and he should not listen to them; 

#### Deuteronomy 21:19 then {seizing him his father and his mother} then shall lead him to the council of elders of his city, and unto the gate of his place. 

#### Deuteronomy 21:20 And they shall say to the men of their city, Our son, this one resists persuasion, and he aggravates, not obeying our voice; he is fond of carousing drunk with wine. 

#### Deuteronomy 21:21 And {shall stone him the men of his city} with stones, and he shall die; and thus you shall lift away the wicked from you of them; and all Israel hearing, they shall be fearful. 

#### Deuteronomy 21:22 And if there be {in any sin} with the judgment of death upon him, and he should die, and you should hang him upon a tree, 

#### Deuteronomy 21:23 {shall not rest his body} upon the tree, but by burial you shall entomb him on that day, for being cursed by God is every one hanging upon a tree; and in no way shall you defile the land which the LORD your God gives to you by lot. 

#### Deuteronomy 22:1 In beholding the calf of your brother or of his sheep wandering in the way, do not overlook them; by returning you shall return them to your brother, and you shall give them back to him. 

#### Deuteronomy 22:2 And if {is not near your brother} to you, nor do you know him, you shall bring them inside into your house; and it shall be with you until whenever {should seek them your brother}, and you shall give them back to him. 

#### Deuteronomy 22:3 So shall you do for his donkey, and so you shall do for his garment, and so you shall do according to all loss of your brother; as much as should perish of his, and you should find them, you shall not be able to overlook. 

#### Deuteronomy 22:4 You shall not see the donkey of your brother, or his calf fallen in the way, and not overlook them; by raising you shall raise them up for him. 

#### Deuteronomy 22:5 {shall not be The items of a man} upon a woman, nor should {put on a man apparel feminine}, for {an abomination to the LORD your God is every one doing these things}. 

#### Deuteronomy 22:6 And if you should meet with a nest of birds before your face in the way, or upon any tree, or upon the ground -- young chicks or eggs, and the mother should be incubating upon the young, or upon the eggs, you shall not take the mother with the offspring. 

#### Deuteronomy 22:7 By discharge you shall send off the mother, but the offspring you shall take to yourself; that {good for you it should be}, and {of many days you shall be}. 

#### Deuteronomy 22:8 And if you should build {house a new}, then you shall make a rim for your roof, and you will not cause carnage in your house if should fall one falling from it. 

#### Deuteronomy 22:9 You shall not scatter abroad your vineyard diverse seed, that {should not be sanctified the produce}, and the seed which ever you should sow with the produce of your vineyard. 

#### Deuteronomy 22:10 You shall not plow with a calf and donkey upon the same yoke. 

#### Deuteronomy 22:11 You shall not put on commingled wool and flax upon the same garment. 

#### Deuteronomy 22:12 A twisted fringe you shall make for yourself upon the four decorative hems of your wrap-around garments, which ever you should put around yourself by them. 

#### Deuteronomy 22:13 And if any should take a wife, and should live with her, and should detest her, 

#### Deuteronomy 22:14 and should place upon her {offered as an excuse words}, and should bring upon her {name a bad}, and should say, {woman this I took}, and drawing near to her, I did not find her tokens of virginity. 

#### Deuteronomy 22:15 And taking, the father of the child and the mother, they shall bring forth the tokens of the virginity of the child to the council of elders at the gate. 

#### Deuteronomy 22:16 And {shall say the father of the child} to the council of elders, {daughter of mine This} I gave to this man as wife, and he is detesting her. 

#### Deuteronomy 22:17 He now places upon her {offered as an excuse words}, saying, I did not find {of your daughter tokens of virginity}; and these are the tokens of virginity of my daughter. And they shall unfold the garment worn by her before the council of elders of the city. 

#### Deuteronomy 22:18 And {shall take the council of elders of that city} that man, and they shall correct him, 

#### Deuteronomy 22:19 and shall penalize him a hundred shekels, and shall give them to the father of the young woman, because he brought {name a bad} upon an Israelite virgin, and she shall be his wife; he shall not be able to send her away at any time. 

#### Deuteronomy 22:20 But if in truth {be this word}, and {should not be found tokens of virginity} to the young woman; 

#### Deuteronomy 22:21 then they shall lead the young woman unto the doors {house of her father's}, and {shall stone her with stones the men of her city}, and she shall die; for she did folly among the sons of Israel, to fornicate the house of her father. And you shall lift away the wicked from yourselves of them. 

#### Deuteronomy 22:22 And if {should be found a man} going to bed with a wife living with a husband, you shall kill both, the man going to bed with the wife, and the wife; and you shall lift away the wickedness from Israel. 

#### Deuteronomy 22:23 And if there be {child a virgin} being espoused to a man, and {finding her a man} in the city should have gone to bed with her; 

#### Deuteronomy 22:24 you shall lead out both unto the gate of their city, and they shall be stoned with stones, and they shall die; the young woman, for she did not yell out in the city; and the man, for he humbled the wife of his neighbor; and you shall lift away the evil from yourselves of them. 

#### Deuteronomy 22:25 But if in a plain {should find a man} a girl, being espoused; and using force should go to bed with her, you shall kill the man, the one going to bed with her only; 

#### Deuteronomy 22:26 for the young woman shall not do anything, there is no {to the young woman sin worthy of death}. For as if any {should rise up man} against his neighbor, and should do murder taking his life, thus this thing, 

#### Deuteronomy 22:27 for in the field he found her; {yelled the young woman being espoused}, and was there no one helping her. 

#### Deuteronomy 22:28 And if any should find the {child virgin}, whoever was not espoused, and using force on her, he went to bed with her, and he should be found, 

#### Deuteronomy 22:29 {shall give the man going to bed with her} to the father of the young woman fifty double-drachmas of silver, and she will be his wife, because he humbled her; he will not be able to send her away at any time. 

#### Deuteronomy 22:30 {shall not take A man} the wife of his father, and shall not uncover the marriage veil of his father. 

#### Deuteronomy 23:1 {shall not enter One with crushed testicles} (nor being cut off) into the assembly of the LORD. 

#### Deuteronomy 23:2 {shall not enter One born of a harlot} into the assembly of the LORD unto the tenth generation. 

#### Deuteronomy 23:3 {shall not enter The Ammonite and Moabite} into the assembly of the LORD; even unto the tenth generation he shall not enter into the assembly of the LORD, even unto into the eon, 

#### Deuteronomy 23:4 for reason {not meeting with of their} you with bread loaves and water in the way, of your going forth from Egypt; and that they hired against you Balaam son of Beor from out of Mesopotamia to curse you. 

#### Deuteronomy 23:5 And {did not want the LORD your God} to listen to Balaam; and {converted the LORD your God} the curses into a blessing, for {loved you the LORD your God}. 

#### Deuteronomy 23:6 You shall not address peaceable to them, nor be advantageous to them all your days into the eon. 

#### Deuteronomy 23:7 You shall not abhor an Edomite, for {your brother he is}. You shall not abhor an Egyptian, for {a sojourner you were} in his land. 

#### Deuteronomy 23:8 {sons If they shall bear} to themselves {generation in the third}, they shall enter into the assembly of the LORD. 

#### Deuteronomy 23:9 And if you should go forth to camp against your enemies, then you shall guard from every evil thing. 

#### Deuteronomy 23:10 If there might be among you a man who is not clean because of his flow by night, then he shall go forth outside the camp, and he shall not enter into the camp. 

#### Deuteronomy 23:11 And it will be towards evening he shall bathe his body in water; and at the going down of the sun, he shall enter into the camp. 

#### Deuteronomy 23:12 And a place will be for you outside the camp, and you shall go forth there outside, 

#### Deuteronomy 23:13 and a trowel will be upon your belt, and it will be whenever you should sit separately outside, that you shall dig with it, and bringing it you shall cover your indecency by it. 

#### Deuteronomy 23:14 For the LORD your God walks about in your camp to rescue you, and to deliver up your enemy before your face; and {shall be your camp} holy, and there shall not be seen among you {of indecency a thing}, that he shall turn away from you. 

#### Deuteronomy 23:15 You shall not deliver up a servant to his master, who was added to you by his master; 

#### Deuteronomy 23:16 {with you he shall dwell}, among you, in every place of which ever it should please him. You shall not afflict him. 

#### Deuteronomy 23:17 There shall not be a harlot from the daughters of Israel, and there shall not be one whoring from the sons of Israel. 

#### Deuteronomy 23:18 You shall not bring the hire of a harlot, nor the price of a dog, into the house of the LORD your God for any vow. For {an abomination to the LORD your God are even both}. 

#### Deuteronomy 23:19 You shall not lend to your brother with interest of silver, and interest of foods, and interest of any thing of which ever you should lend. 

#### Deuteronomy 23:20 To the alien you may lend with interest, but to your brother you shall not lend with interest; that {should bless you the LORD your God} in all your works upon the land into which you enter there to inherit it. 

#### Deuteronomy 23:21 And if you shall vow a vow to the LORD your God, you shall not pass time to give it; for requiring, {shall require it the LORD your God} from you; and it will be {to you sin}. 

#### Deuteronomy 23:22 But if you should not want to make a vow, it is not a sin to you. 

#### Deuteronomy 23:23 The things going forth through your lips you shall guard, and you shall do in which manner you made a vow to the LORD your God in the matter of a gift which {spoke your mouth}. 

#### Deuteronomy 23:24 And if you enter into the vineyard of your neighbor, you may eat {grape as much your soul as to fill up}, {into but a container you shall not put them}. 

#### Deuteronomy 23:25 And if you should enter into the harvest field of your neighbor, then you may collect together {in your hands corn}; but the sickle in no way shall be put upon the harvest of your neighbor. 

#### Deuteronomy 24:1 And if any take a woman and should live with her, and it shall be if she should not find favor before him, for he finds in her an indecent thing, then he shall write to her {scroll a certificate of divorce}, and he shall put it into her hands, and he shall send her from out of his house. 

#### Deuteronomy 24:2 And going forth, should she become {man's wife another}, 

#### Deuteronomy 24:3 and {should detest her husband the last}, and should write to her {scroll certificate of divorce}, and he should put it into her hands, and send her from out of his house; or {should die husband her last} who took her to himself as wife; 

#### Deuteronomy 24:4 {shall not be able husband the former sending her out} to return to take her to himself for a wife after her being defiled; for it is an abomination before the LORD your God, and you shall not defile the land which the LORD your God gives to you by lot. 

#### Deuteronomy 24:5 And if any should take a wife recently, he shall not go forth to war, and not {shall be put upon him one thing} -- he shall be innocent in his house, {year for one} he shall make glad his wife whom he took. 

#### Deuteronomy 24:6 You shall not take for security a millstone nor an upper millstone, for {a life this one takes} for security. 

#### Deuteronomy 24:7 And if you should capture a man stealing the life of his brethren of the sons of Israel, and tyrannizing him to sell him; {shall die thief that}; and you shall lift away the evil from yourselves of them. 

#### Deuteronomy 24:8 Take heed to yourself in the infection of leprosy! You shall guard exceedingly to do according to all the law which ever {should announce to you the priests the Levites}, in which manner I gave charge to you to guard to do. 

#### Deuteronomy 24:9 Remember as much as {did the LORD your God} to Miriam! in the way of your going forth from Egypt. 

#### Deuteronomy 24:10 And if a debt might be owed by your neighbor, any debt whatsoever, you shall not enter into his house to take for security of his item for security. 

#### Deuteronomy 24:11 {outside You shall stand}, and the man of whom your debt is in, he shall bring forth to you the item of security outside. 

#### Deuteronomy 24:12 But if the man should be in need, you shall not go to bed with his item of security. 

#### Deuteronomy 24:13 By restitution you shall give back to him his item of security towards the descent of the sun, and he shall go to bed in his garment, and he will bless you; and it will be to you charity before the LORD your God. 

#### Deuteronomy 24:14 You shall not disregard the wage of the needy and one lacking from your brethren, or of the foreigners, of the ones in your cities. 

#### Deuteronomy 24:15 Daily you shall give him his wage, {shall not set the sun} upon him, for he is needy, and in it he has hope; and he shall not yell out against you to the LORD, and thus it will be to you a sin. 

#### Deuteronomy 24:16 {shall not die Fathers} for the children, and the sons shall not die for the fathers; each for his own sin shall die. 

#### Deuteronomy 24:17 You shall not turn aside a judgment of a foreigner, and an orphan, and a widow; and you shall not take for security a garment of a widow. 

#### Deuteronomy 24:18 And you shall remember that you were a servant in the land of Egypt, and {ransomed you the LORD your God} from there. On account of this I give charge to you to do this thing. 

#### Deuteronomy 24:19 And if you should reap your harvest in your field, and you should forget a sheaf in your field, you shall not turn back to take it; for to the poor, and to the foreigner, and to the orphan, and to the widow it will be; that {should bless you the LORD your God} in every work of your hands. 

#### Deuteronomy 24:20 And if one should pick olives, you shall not turn back to glean after you; {to the foreigner and to the orphan and to the widow it shall be}. 

#### Deuteronomy 24:21 And whenever you should gather the vintage of your vineyard, you shall not glean the things after you; {for the foreigner and the orphan and the widow it will be}. 

#### Deuteronomy 24:22 And you shall remember that you were a servant in the land of Egypt. On account of this I give charge to you to do this thing. 

#### Deuteronomy 25:1 And if there be a dispute between men, and they should come forward for judgment, and they should judge, and should do justice for the just, and should condemn the impious; 

#### Deuteronomy 25:2 then it will be if {worthy might be of strokes the one being impious}, they shall sit him before the judges, and they shall whip him before them according to his impiety. 

#### Deuteronomy 25:3 {in number forty stripes They shall whip him}, they shall not add more; but if he should add to whip him above these, by the strokes being more you shall be disgraced of your brother before you. 

#### Deuteronomy 25:4 You shall not muzzle an ox threshing. 

#### Deuteronomy 25:5 And if {should dwell brethren} in the same place, and {should die one of them}, {seed and there might not be} to him, {shall not be the wife of the one having died} outside the husband's family not near. The brother of her husband shall enter to her, and he shall take her to himself as wife, and he shall live with her. 

#### Deuteronomy 25:6 And it will be, that the male child, who ever she should give birth to, shall be ordained from the name of the one coming to an end, and {shall not be wiped away his name} from out of Israel. 

#### Deuteronomy 25:7 But if {does not want the man} to take the wife of his brother; then {shall ascend the woman} unto the gate to the council of elders, and shall say, {does not want The brother of my husband} to raise up the name of his brother in Israel -- {does not want to the brother of my husband}. 

#### Deuteronomy 25:8 And {shall call him the council of elders of that city}, and they shall speak to him. And standing, should he say, I am not willing to take her; 

#### Deuteronomy 25:9 then {coming forward the wife of his brother} to him, before the council of elders, then shall untie his sandal, the one from his foot, and shall spit into his face; and responding she shall say, Thus shall they do to the man who shall not build the house of his brother. 

#### Deuteronomy 25:10 And {shall be called his name} in Israel, House of the Untied Sandal. 

#### Deuteronomy 25:11 And if {should do combat two men} at the same time -- a man against his brother; and should come forward the wife of one of them to rescue her husband from out of the hand of the one beating him, and stretching out her hand should take hold of his twins, 

#### Deuteronomy 25:12 you shall cut off her hand; {shall not spare your eye} over her. 

#### Deuteronomy 25:13 There shall not be in your money bag a weight and a weight -- a great or small. 

#### Deuteronomy 25:14 There shall not be in your house a measure and a measure -- a great or a small. 

#### Deuteronomy 25:15 {weight a true and just There shall be to you}, and {measure a true and just there shall be to you}, that {many days you should be} upon the land which the LORD your God gives to you by lot. 

#### Deuteronomy 25:16 For it is an abomination to the LORD your God every one doing these things -- every one doing unjustly. 

#### Deuteronomy 25:17 Remember as many things {did to you Amalek} in the way of your going forth from Egypt! 

#### Deuteronomy 25:18 How he opposed you in the way, and beat your rear guard, the ones tiring in your rear, and you hungered and were tired. And he feared not God. 

#### Deuteronomy 25:19 And it will be when ever {rests you the LORD your God} from all your enemies round about you in the land which the LORD your God gives to you by lot to inherit, you shall wipe away the name Amalek from under the heaven, and in no way should you forget. 

#### Deuteronomy 26:1 And it will be whenever you should enter into the land which the LORD your God gives to you by lot to inherit it, and should dwell upon it; 

#### Deuteronomy 26:2 that you shall take from the first-fruit of the fruits of your land, which the LORD your God gives by lot, and you shall put them into a basket, and you shall go into the place which ever {should choose the LORD your God} to call upon his name there. 

#### Deuteronomy 26:3 And you shall come to the priest, who ever might be in those days, and you shall say to him, I announce today to the LORD your God, that I have entered into the land which the LORD swore by an oath to our fathers to give to us. 

#### Deuteronomy 26:4 And {shall take the priest} the basket from out of your hands, and he shall put it before the altar of the LORD your God. 

#### Deuteronomy 26:5 And you shall respond and shall say before the LORD your God, {threw off Syria My father}, and he went down into Egypt, and sojourned there with {in number few}, and became there into {nation a great} and {multitude a populous}. 

#### Deuteronomy 26:6 And {maltreated us the Egyptians}, and humbled us, and placed upon us {works hard}. 

#### Deuteronomy 26:7 And we yelled out to the LORD God of our fathers, and the LORD listened to our voice, and beheld our humiliation, and our trouble, and our affliction. 

#### Deuteronomy 26:8 And {led us the LORD} out of Egypt with {strength great}, and with {hand a fortified}, and with {arm a high}, and with {visions great}, and with signs, and with miracles. 

#### Deuteronomy 26:9 And he brought us into this place, and he gave to us this land, a land flowing milk and honey. 

#### Deuteronomy 26:10 And now, behold, I have brought the first-fruit of the produce of the land which you gave to me, O LORD. And you shall leave it before the LORD your God, and you shall do obeisance before the LORD your God. 

#### Deuteronomy 26:11 And you shall be glad in all the good things which {gave to you the LORD your God}, and to your family, you and the Levite and the foreigner among you. 

#### Deuteronomy 26:12 And whenever you should complete to tithe all the tenth part of the produce of your land in the {year third}, the second tenth part you shall give to the Levite, and to the foreigner, and to the orphan, and to the widow; and they shall eat in your cities, and they shall be satisfied. 

#### Deuteronomy 26:13 And you shall say before the LORD your God, I cleared the holy things from out of my house, and I gave them to the Levite, and to the foreigner, and to the orphan, and to the widow, according to all your commandments which you gave charge to me; I did not pass by your commandment, and I did not forget. 

#### Deuteronomy 26:14 And I did not eat {in my grief of them}; I did not yield of them in an unclean manner; I did not give of them to the one having died; I obeyed the voice of the LORD my God to do as he gave charge to me. 

#### Deuteronomy 26:15 Look down from out of {house your holy}, from heaven, and bless your people Israel! and the land which you gave to them, as you swore by an oath to our fathers, to give to us a land flowing milk and honey! 

#### Deuteronomy 26:16 On this day the LORD your God gave charge to you to do all these ordinances and judgments. And you shall guard and observe them from {entire heart your}, and from {entire soul your}. 

#### Deuteronomy 26:17 You took God today to be your God, and to go in all his ways, and to guard the ordinances, and the commandments, and his judgments, and to obey his voice. 

#### Deuteronomy 26:18 And the LORD took you today for you to be to him {people a prized}, just as he spoke to you -- for you to guard all his commandments; 

#### Deuteronomy 26:19 and for you to be above all the nations, as he made you famous, and a boasting, and glorious; for you to be {people a holy} to the LORD your God as he spoke. 

#### Deuteronomy 27:1 And {assigned Moses and the council of elders of Israel}, saying, Guard all the commandments! as many as I give charge to you today. 

#### Deuteronomy 27:2 And it will be in which ever day you should pass over the Jordan into the land which the LORD your God gives to you, that you shall set up to yourself {stones great}, and you shall whitewash them in lime. 

#### Deuteronomy 27:3 And you shall write upon the stones all the words of this law, as when whenever you should pass over the Jordan, when ever you should enter into the land which the LORD your God gives to you; a land flowing milk and honey; in which manner {spoke the LORD God of your fathers} to you. 

#### Deuteronomy 27:4 And it will be as when ever you should pass over the Jordan, you shall set these stones, which I give charge to you today, on mount Ebal, and you shall whitewash them with lime. 

#### Deuteronomy 27:5 And you shall build there an altar to the LORD your God -- an altar from out of stones; you shall not put upon them an iron tool. 

#### Deuteronomy 27:6 {stones Of whole} you shall build the altar to the LORD your God, and you shall offer upon it whole burnt-offerings to the LORD your God. 

#### Deuteronomy 27:7 And you shall sacrifice a sacrifice of deliverance; and you shall eat there and shall be filled up, and be glad before the LORD your God. 

#### Deuteronomy 27:8 And you shall write upon the stones all this law -- {clearly very}. 

#### Deuteronomy 27:9 And {spoke Moses and the priests the Levites} to all Israel, saying, Keep silent and hear, O Israel! On this day you have become a people to the LORD your God. 

#### Deuteronomy 27:10 And you shall listen to the voice of the LORD your God, and you shall observe all his commandments, and his ordinances, which I give charge to you today. 

#### Deuteronomy 27:11 And Moses gave charge to the people in that day, saying, 

#### Deuteronomy 27:12 These shall stand to bless the people in mount Gerizim passing over the Jordan; Simeon, Levi, Judah, Issachar, Joseph, and Benjamin. 

#### Deuteronomy 27:13 And these shall stand for the cursing on mount Ebal; Reuben, Gad, and Asher, Zebulun, Dan, and Naphtali. 

#### Deuteronomy 27:14 And {responding shall say the Levites} to all Israel {voice with a great}, 

#### Deuteronomy 27:15 Accursed is the man who shall make a carving and a molten image, an abomination to the LORD, a work of the hands of a craftsman, and shall put it in concealment. And answering all the people shall say, May it be. 

#### Deuteronomy 27:16 Accursed is the one dishonoring his father or his mother. And {shall say all the people}, May it be. 

#### Deuteronomy 27:17 Accursed is the one altering boundaries of the neighbor. And {shall say all the people}, May it be. 

#### Deuteronomy 27:18 Accursed is the one misleading the blind in the way. And {shall say all the people}, May it be. 

#### Deuteronomy 27:19 Accursed is who ever turns aside a judgment which favors a foreigner, and orphan, and widow. And {shall say all the people}, May it be. 

#### Deuteronomy 27:20 Accursed is the one going to bed with the wife of his father, for he uncovered the marriage veil of his father. And {shall say all the people}, May it be. 

#### Deuteronomy 27:21 Accursed is the one going to bed with any beast. And {shall say all the people}, May it be. 

#### Deuteronomy 27:22 Accursed is the one going to bed with a sister from {father or mother his}. And {shall say all the people}, May it be. 

#### Deuteronomy 27:23 Accursed is the one going to bed with his mother-in-law. And {shall say all the people}, May it be! Accursed is the one going to bed with a sister of his wife. And {shall say all the people}, May it be. 

#### Deuteronomy 27:24 Accursed is the one striking his neighbor with treachery. And {shall say all the people}, May it be. 

#### Deuteronomy 27:25 Accursed is who ever should take bribes to strike the life {blood of innocent}. And {shall say all the people}, May it be. 

#### Deuteronomy 27:26 Accursed is every man whoever shall not adhere to all the words of this law to do them. And {shall say all the people}, May it be. 

#### Deuteronomy 28:1 If in hearing you should hear the voice of the LORD your God to guard and to observe all his commandments which I give charge to you today, then {shall appoint you the LORD your God} above all the nations of the earth, 

#### Deuteronomy 28:2 then {shall come upon you all these blessings}, and they shall find you if in hearing you should listen to the voice of the LORD your God. 

#### Deuteronomy 28:3 Being blessed are you in the city, and being blessed are you in the field. 

#### Deuteronomy 28:4 Being blessed are the progeny of your belly, and the produce of your land, and the herds of your oxen, and the flocks of your sheep. 

#### Deuteronomy 28:5 Being blessed are your storehouses and your surpluses. 

#### Deuteronomy 28:6 Being blessed are you in your entering, and being blessed are you in your going forth. 

#### Deuteronomy 28:7 {shall deliver up The LORD your God} your enemies opposing you by breaking them before your face; {way in one} they shall come forth against you, and in seven ways they will flee from your face. 

#### Deuteronomy 28:8 May the LORD send upon you the blessing among your storerooms, and on all what ever you should put your hand. And he will bless you upon the land of which the LORD your God gives to you. 

#### Deuteronomy 28:9 May {raise you up The LORD your God} for himself {people as a holy}, in which manner he swore by an oath to your fathers, if you should hearken to the voice of the LORD your God, and should go in his ways. 

#### Deuteronomy 28:10 And {shall see you all the nations of the earth}, that the name of the LORD is called upon by you, and they shall fear you. 

#### Deuteronomy 28:11 And {shall multiply you the LORD your God} for good things upon the progeny of your belly, and upon the progeny of your cattle, and upon the produce of your ground, upon the land which the LORD swore by an oath to your fathers to give to you. 

#### Deuteronomy 28:12 May {open to you the LORD treasury his good}, the heaven, to give the rain to your land in its season; to bless all the works of your hands; and you shall lend {nations to many}, but you shall not borrow; and you shall yourself rule {nations many}, {you but they shall not rule}. 

#### Deuteronomy 28:13 May {place you the LORD your God} as head, and not as the tail; and you will be then above, and you will not be underneath, if you should hearken to the commandments of the LORD your God, as many as I give charge to you today, to guard and to observe. 

#### Deuteronomy 28:14 You shall not transgress from all the words which I give charge to you today, to the right or to the left, to go after other gods, to serve them. 

#### Deuteronomy 28:15 And it shall be if you should not listen to the voice of the LORD your God, to guard and to observe all his commandments, as many as I give charge to you today, then shall come upon you all these curses, and they shall overtake you. 

#### Deuteronomy 28:16 Accursed are you in the city, and accursed are you in the field. 

#### Deuteronomy 28:17 Accursed are your storehouses, and your surplus. 

#### Deuteronomy 28:18 Accursed are the progeny of your belly, and the produce of your land; the herds of your oxen, and the flocks of your sheep. 

#### Deuteronomy 28:19 Accursed are you in your entering, and accursed are you in your going forth. 

#### Deuteronomy 28:20 May the LORD send upon you lack, and craving, and consumption, upon all things of which ever you should put {upon your hand}, as much as you should do, until whenever he should utterly destroy you, and until whenever he should consume you quickly because of {wicked practices your}, because you abandoned me. 

#### Deuteronomy 28:21 May the LORD cleave {to you the plague} until whenever he should completely consume you from the land into which you enter there to inherit it. 

#### Deuteronomy 28:22 {strike you The LORD} with perplexity, and burning heat, and shivering, and aggravation, and carnage, and wind-blown, and paleness; and may they pursue you until whenever they should destroy you. 

#### Deuteronomy 28:23 And {will be to you the heaven above your head} as brass, and the earth underneath you as iron. 

#### Deuteronomy 28:24 May the LORD appoint the rain of your land a cloud of dust; and dust from out of the heaven shall come down upon you, until it should obliterate you, and until whenever it should destroy you. 

#### Deuteronomy 28:25 May {appoint you the LORD} for slaughter before your enemies. In {way one} you shall go forth against them, and in seven ways you shall flee from their face. And you will be in dispersion among all kingdoms of the earth. 

#### Deuteronomy 28:26 And {will be your dead} things devoured by the winged creatures of the heaven, and the wild beasts of the earth; and there will not be one frightening away. 

#### Deuteronomy 28:27 {strike you The LORD} with the sore of Egypt in the buttocks, and {mange wild}, and itching, so as to not be able to heal. 

#### Deuteronomy 28:28 {strike you The LORD} in derangement, and inability to see, and an astonishment of thought. 

#### Deuteronomy 28:29 And you will be groping at midday as {one gropes the blind} in the darkness, and {will not prosper your ways}. And you will be then injured and torn in pieces all the days, and there shall not be {you one helping}. 

#### Deuteronomy 28:30 {a wife You shall take}, and {man another} shall have her. {a house You shall build}, and you shall not live in it. {a vineyard You shall plant}, and in no way shall you gather its vintage. 

#### Deuteronomy 28:31 Your calf being slain before you, and you will not eat from it. Your donkey being seized by force from you, and it shall not be given back to you. Your sheep being given to your enemies, and there shall not be one helping you. 

#### Deuteronomy 28:32 Your sons and your daughters will be given {nation to another}, and your eyes shall see being inflamed over them. And {shall not be strong your hand}. 

#### Deuteronomy 28:33 The resources of your land, and all the things of your toils {shall eat a nation} which you have no knowledge of; and you will be injured and devastated all the days. 

#### Deuteronomy 28:34 And you will be deranged through the visions of your eyes which you shall see. 

#### Deuteronomy 28:35 {strike you The LORD} with {sore a severe} upon the knees, and upon the legs, so as to not be able to heal yourself from the sole of your feet unto the top of your head. 

#### Deuteronomy 28:36 May the LORD take you and your rulers, whom ever you should place over yourself, by a nation who you have no knowledge of yourself nor your fathers; and you shall serve there other gods of wood and stone. 

#### Deuteronomy 28:37 And you will be there for an enigma, and a parable, and a tale, in all the nations into which ever {should take you the LORD} there. 

#### Deuteronomy 28:38 {seed Much} you shall bring forth in the plain, and little will be carried in, for {shall eat them the locust}. 

#### Deuteronomy 28:39 A vineyard you shall plant, and you will work it, and wine you shall not drink, nor will you be glad from it, for {shall eat it the worm}. 

#### Deuteronomy 28:40 Olive trees will be to you in all your borders, but with olive oil you will not anoint, for {shall flow away your olive}. 

#### Deuteronomy 28:41 Sons and daughters you shall bear, but they shall not be yours, for they shall go forth in captivity. 

#### Deuteronomy 28:42 All your woods and the produce of your land {shall completely consume the blight}. 

#### Deuteronomy 28:43 The foreigner who is among you shall ascend over you upward and upward; but you shall go down lower and lower. 

#### Deuteronomy 28:44 This one shall lend to you, but you {to this one shall not lend}; this one will be for the head, and you will be for the tail. 

#### Deuteronomy 28:45 And {shall come upon you all these curses}, and they shall pursue you, and overtake you, until whenever they shall utterly destroy you, and until whenever they shall consume you. For you did not listen to the voice of the LORD your God, to guard his commandments, and his ordinances, as many as I gave charge to you. 

#### Deuteronomy 28:46 And they will be for signs to you, and miracles, and among your seed until the eon. 

#### Deuteronomy 28:47 Because you did not serve the LORD your God with gladness, and with a good heart, because of the multitude of all these. 

#### Deuteronomy 28:48 And you shall serve your enemies whom the LORD shall send as a successor over you in hunger, and in thirst, and in nakedness, and in want of all things. And he shall put a collar of iron upon your neck, until whenever he should utterly destroy you. 

#### Deuteronomy 28:49 {shall bring upon you The LORD} a nation far off from the end of the earth, as the impulse of an eagle, a nation of which you will not hear its voice; 

#### Deuteronomy 28:50 a nation impudent in its face who will not admire the face of an old man, and {for the young will not show mercy}. 

#### Deuteronomy 28:51 And it will devour the progeny of your cattle, and the produce of your land, so as to not leave behind for you grain, wine, olive oil, herds of your oxen, and the flocks of your sheep, until whenever it should destroy you, 

#### Deuteronomy 28:52 and should obliterate you in all your cities, until whenever {should be demolished your walls}, the high and the fortified ones upon which you rely upon them in all your land. And it shall afflict you in all your cities, which {gave to you the LORD your God}. 

#### Deuteronomy 28:53 And you shall eat the progeny of your belly, the meat of your sons and your daughters, as many as {gave to you the LORD your God} in your straits, and in your affliction, in which {shall afflict you your enemy}. 

#### Deuteronomy 28:54 The one tender among you, and the {delicate very} shall charm with his eye his brother, and the wife in his bosom, and the left behind children, who ever should be left to him; 

#### Deuteronomy 28:55 so as to give one of them from the flesh of his children whom ever he should eat, because of the not having left behind to him anything in the straits, and in the affliction, in which ever {should afflict you your enemies} in all your cities. 

#### Deuteronomy 28:56 And the tender among you, and the {delicate one exceedingly} of whom has not {an attempt taken} with her foot to go upon the land because of the delicacy, and because of the tenderness -- she shall charm with her eye her husband, the one near her bosom, and {son and daughter her}; 

#### Deuteronomy 28:57 and her afterbirth coming forth through her thighs, and her child which ever she should give birth to -- they she shall eat them because of the lack of all things, secretly, in the straits. and in the affliction by which {shall afflict you your enemy} in your cities, 

#### Deuteronomy 28:58 if you should not hearken to do all the discourses of this law, the ones being written in this scroll, to fear {name valued and this wonderful} -- the LORD your God. 

#### Deuteronomy 28:59 Then the LORD will render notorious your calamities, and the calamities of your seed, {calamities great and surprising}, and {diseases severe and sure}. 

#### Deuteronomy 28:60 And he shall turn upon you all the grief of Egypt, the severe grief which you were on guard from in front of them, and they shall cleave to you. 

#### Deuteronomy 28:61 And every infirmity, and every calamity not being written, and every one being written in {scroll of the law this}, the LORD shall bring upon you, until whenever he should utterly destroy you. 

#### Deuteronomy 28:62 And you shall be left behind {in number few} for you were as the stars of the heaven in multitude, for you did not hearken to the voice of the LORD your God. 

#### Deuteronomy 28:63 And it will be in the manner the LORD was glad over you, {good to do} for you, and to multiply you; so the LORD will be glad over you to utterly destroy you, and to lift you away from the land into which you enter there to inherit it. 

#### Deuteronomy 28:64 And {will disperse you the LORD your God} into all the nations, from the tip of the earth, unto the other tip of the earth. And you shall slave there to other gods of wood and stone, which {have no knowledge of you}, nor your fathers. 

#### Deuteronomy 28:65 But also in those nations he will not rest you, nor in any way will {become stationary the sole of your foot}. And {will give to you the LORD} there {heart another} being depressed, and failing eyes, and a melting soul. 

#### Deuteronomy 28:66 And {will be your life} hanging before your eyes. And you shall have fear day and night, and not trust in your life. 

#### Deuteronomy 28:67 In the morning you shall say, O how that it might become evening. And in the evening you shall say, O how that it might become morning; from the fear of your heart of which you shall have fear, and from the visions of your eyes which you shall see. 

#### Deuteronomy 28:68 And {will return you the LORD} unto Egypt in boats, and in the way which I said, You shall not proceed again to behold it. And you shall be sold there to your enemies for manservants and maidservants, and none shall be acquiring you. 

#### Deuteronomy 29:1 These are the words of the covenant, which the LORD gave charge to Moses to establish with the sons of Israel in the land of Moab, besides the covenant of which he ordained with them in Horeb. 

#### Deuteronomy 29:2 And Moses called all the sons of Israel, and he said to them, You see all as many things as {did the LORD your God} in the land of Egypt before you to Pharaoh and his attendants, and all his land; 

#### Deuteronomy 29:3 the {tests great} which {have seen your eyes}; the signs and {miracles those great}, by the {hand strong}, and the {arm high}. 

#### Deuteronomy 29:4 And {did not give the LORD God} to you a heart to behold, and eyes to see, and ears to hear, until this day. 

#### Deuteronomy 29:5 And he led you forty years in the wilderness. {did not become old Your garments}, and your sandals did not wear away from your feet. 

#### Deuteronomy 29:6 {bread You did not eat}; {wine and liquor you did not drink}, that you should know that I am the LORD your God. 

#### Deuteronomy 29:7 And you came unto this place. And came forth Sihon king of Heshbon, and Og king of Bashan to meet us in war. 

#### Deuteronomy 29:8 And we struck them, and we took their land, and we gave it by lot to Reuben, and to Gad, and to the half tribe of Manasseh. 

#### Deuteronomy 29:9 And you shall guard all the words of this covenant, to do them, that you should perceive all as much as you do. 

#### Deuteronomy 29:10 You all stand today before the LORD your God; your tribal chiefs, and your council of elders, and your judges, and your judicial recorders, every man of Israel; 

#### Deuteronomy 29:11 your wives, and your children, and the foreigner in the midst of your camp; from your woodcutter and unto your water-carrier, 

#### Deuteronomy 29:12 to go in the covenant of the LORD your God, and in his oaths, as many as the LORD your God ordains for you today. 

#### Deuteronomy 29:13 That he should establish you to himself for a people, and he will be your God, in which manner he said to you, and in which manner he swore by an oath to your fathers -- Abraham and Isaac and Jacob. 

#### Deuteronomy 29:14 And not to you alone I ordain this covenant and this oath, 

#### Deuteronomy 29:15 but also to the ones here being with you today before the LORD your God, and to the ones not being with you here today. 

#### Deuteronomy 29:16 For you know how we dwelt in the land of Egypt, as we went by in the midst of the nations which you went by. 

#### Deuteronomy 29:17 And you beheld their abominations, and their idols -- wood and stone, silver and gold, which is among them. 

#### Deuteronomy 29:18 Lest there is among you, a man or woman, or family or tribe, whose thought turned aside from the LORD your God, to go to serve to the gods of those nations; lest there is among you a root {upward germinating bile and bitterness}. 

#### Deuteronomy 29:19 And it shall be if you should hear the words of this imprecation, and one should portend in his heart, saying, {sacred things to me May happen}, for {by the digression of my heart I shall go}, that {should not be destroyed together with the sinner} the sinless, 

#### Deuteronomy 29:20 in no way should God want to propitiate for him, but then {shall be burned away the anger of the LORD}, and his zeal against that man. Then shall cleave to him all the imprecations of this covenant, the ones being written in {scroll of the law this}. And the LORD will wipe away his name from under heaven. 

#### Deuteronomy 29:21 And {shall separate him the LORD} for evils from all the sons of Israel, according to all the imprecations of the covenant, the ones being written in {scroll of the law this}. 

#### Deuteronomy 29:22 And {shall say generation another} -- even your sons who rise up after you, and the alien which ever should come from out of a land far off, that they shall see the calamities of that land, and its diseases, which the LORD sent unto it, 

#### Deuteronomy 29:23 sulphur and salt incinerating; all its land shall not be sown, nor shall rise, nor should ascend upon it any green thing. As {were eradicated Sodom and Gomorrah} -- Admah and Zeboim, which the LORD eradicated in rage and anger, 

#### Deuteronomy 29:24 and {shall say all the nations}, Why did {do the LORD} thus to this land? What is {rage of anger this great}? 

#### Deuteronomy 29:25 And they shall say, Because they left the covenant of the LORD, God of their fathers, which he ordained with their fathers, when he led them out of the land of Egypt. 

#### Deuteronomy 29:26 And going, they served other gods, and they did obeisance to them, ones which they had no knowledge of, nor knowledge spread to them. 

#### Deuteronomy 29:27 And {was provoked to anger in rage the LORD} over that land, to bring upon it according to all the imprecations being written in {scroll of the law this}. 

#### Deuteronomy 29:28 And {lifted them the LORD} from their land in rage and anger, and {fit of temper great an exceedingly}, and cast them into {land another} as now. 

#### Deuteronomy 29:29 The secret things belong to the LORD your God. But the open things are to you, and to your children into the eon, to do all the words of this law. 

#### Deuteronomy 30:1 And it will be whenever {should come upon you all these things}, the blessing and the curse, which I put before your face, and you shall take them into your heart in all the nations of which ever {should disperse you the LORD your God} there; 

#### Deuteronomy 30:2 and you shall turn towards the LORD your God, and you shall hearken to his voice, according to all as much as I give charge to you today, from {entire heart your}, and from {entire soul your}; 

#### Deuteronomy 30:3 that the LORD shall heal your sins, and shall show mercy on you, and again shall bring you from out of all the nations into which {dispersed you the LORD your God} there. 

#### Deuteronomy 30:4 Even if {might be your dispersion} from one tip of the heaven unto one tip of the heaven, from there {shall bring you the LORD your God}, and from there he will take you. 

#### Deuteronomy 30:5 And {will bring you the LORD your God} into the land which {inherited your fathers}, and you shall inherit it, and {you good he will do}, and {superabundant for you he will do} above your fathers. 

#### Deuteronomy 30:6 And the LORD shall purge your heart, and the heart of your seed, to love the LORD your God from {entire heart your}, and from {entire soul your}, that you should live. 

#### Deuteronomy 30:7 And {shall put the LORD your God} these curses upon your enemies, and upon the ones detesting you, who pursued you. 

#### Deuteronomy 30:8 And you shall turn and shall listen to the voice of the LORD your God, and shall observe his commandments, as many as I give charge to you today. 

#### Deuteronomy 30:9 And {shall take great care of you the LORD your God} in every work of your hands, in the progeny of your belly, and in the progeny of your cattle, and in the produce of your land, because {shall turn the LORD your God} to be glad over you for good things, as he was glad over your fathers. 

#### Deuteronomy 30:10 If you should hearken to the voice of the LORD your God, to guard his commandments, and his ordinances -- the ones written in the scroll of this law, if you turn to the LORD your God with {entire heart your}, and with {entire soul your}. 

#### Deuteronomy 30:11 For this commandment which I give charge to you today {not enormous is}, nor {far from you is it}. 

#### Deuteronomy 30:12 {not in the heaven It is}, saying, Who shall ascend of us into the heaven, and shall take it to us, and hearing it we will do it? 

#### Deuteronomy 30:13 Nor {on the other side of the sea is it}, saying, Who will pass through for us to the other side of the sea, and shall take it for us, and hearing it we will do it? 

#### Deuteronomy 30:14 {near you is But the word very}, in your mouth, and in your heart, and in your hands to do it. 

#### Deuteronomy 30:15 Behold, I put before your face today life and death, good and bad. 

#### Deuteronomy 30:16 But if you should hearken to the commandments of the LORD your God, which I give charge to you today, to love the LORD your God, to go in all his ways, and to guard his ordinances, and his commandments, and his judgments, then you shall live, and you will be populous, and {will bless you the LORD your God} in all the land into which you enter there to inherit it. 

#### Deuteronomy 30:17 And if {should change over your heart}, and you should not listen, and in wandering you should do obeisance to other gods, and should serve them; 

#### Deuteronomy 30:18 I announce to you today, that by destruction you will be destroyed, and in no way {many days shall there be} upon the land, into which you pass over the Jordan there to inherit it. 

#### Deuteronomy 30:19 I call to testify to you today both the heaven and the earth. The life and death I put before your face; the blessing and the curse; then choose the life, that you should live and your seed; 

#### Deuteronomy 30:20 to love the LORD your God, to listen to his voice, and to hold what is of his. For this is your life, and the duration of your days, to dwell upon the land of which the LORD swore by an oath to your fathers -- Abraham and Isaac and Jacob, to give it to them. 

#### Deuteronomy 31:1 And Moses completed speaking all these words to all the sons of Israel. 

#### Deuteronomy 31:2 And he said to them, A hundred and twenty years I am today. I shall not be able still to enter and go forth. For the LORD said to me, You shall not pass over this Jordan. 

#### Deuteronomy 31:3 The LORD your God, the one going forth before your face, he shall utterly destroy these nations from your face, and you shall inherit them; and Joshua is the one going forth before your face, as spoke the LORD. 

#### Deuteronomy 31:4 And the LORD shall do to them as he did to Sihon and Og, to the two kings of the Amorites, the ones who were on the other side of the Jordan, and to their land, in so far as he utterly destroyed them. 

#### Deuteronomy 31:5 And {delivered them up the LORD} before you; and you shall do to them in so far as I gave charge to you. 

#### Deuteronomy 31:6 Be manly and be strong! Do not fear! nor should you be timid, nor should you be terrified from their face. For the LORD your God, the one going before with you -- in no way should he forsake you, nor in any way should he abandon you. 

#### Deuteronomy 31:7 And Moses called Joshua, and said to him before all Israel, Be manly and strong! For you shall enter before the face of this people, into the land which the LORD swore by an oath to your fathers to give to them, and you shall allot it to them. 

#### Deuteronomy 31:8 And the LORD, the one going with you will not send you away, nor in any way abandon you. Do not fear nor be timid! 

#### Deuteronomy 31:9 And Moses wrote the sayings of this law in a scroll, and he gave it to the priests, the sons of Levi, the ones lifting the ark of the covenant of the LORD, and to the elders of the sons of Israel. 

#### Deuteronomy 31:10 And Moses gave charge to them in that day, saying, After seven years, in the time of the year of release, in the holiday of pitching of tents, 

#### Deuteronomy 31:11 in the going with all Israel to appear before the LORD your God, in the place in which ever the LORD should choose, you shall read this law before all Israel in their ears. 

#### Deuteronomy 31:12 Assemble the people! the men, and the women, and the progeny, and the foreigner, the one in your cities, that they should hear, and that they should learn to fear the LORD your God. And they shall hearken to do all the words of this law. 

#### Deuteronomy 31:13 And their sons, the ones who have not known, they shall hear, and shall learn to fear the LORD your God all the days, as many as they live upon the land, into which you pass over the Jordan there to inherit it. 

#### Deuteronomy 31:14 And the LORD said to Moses, Behold, {are approaching the days of your death}; call Joshua, and stand by the door of the tent of the testimony! and I will give charge to him. And {went Moses and Joshua} into the tent of the testimony, and they stood by the door of the tent of the testimony. 

#### Deuteronomy 31:15 And the LORD came down in a column of cloud. And it stood at the door of the tent of the testimony. And {stood the column of cloud} by the door of the tent. 

#### Deuteronomy 31:16 And the LORD said to Moses, Behold, you go to sleep with your fathers. And rising up, this people shall fornicate after alien gods of the land into which this people enter there into it. And they shall forsake me, and shall efface my covenant which I ordained with them. 

#### Deuteronomy 31:17 And I shall be provoked to anger in rage with them in that day, and I will leave them, and I will turn my face from them, and they shall be a thing devoured. And {shall find him evils many and afflictions}; and he shall say in that day, because {is not the LORD my God} among me {found me these evils}. 

#### Deuteronomy 31:18 And I in turning will turn away my face from them in that day because of all the evils which they did, for they turned away unto alien gods. 

#### Deuteronomy 31:19 And now write the words of this ode, and teach it to the sons of Israel! And you shall put it into their mouth, that {should be to me ode this} a testimony among the sons of Israel. 

#### Deuteronomy 31:20 For I shall bring them into the {land good} which I swore by an oath to their fathers; a land flowing milk and honey. And they shall eat. And being filled up they shall satisfy themselves, and shall turn to alien gods, and shall serve to them, and shall provoke me, and shall efface my covenant which I ordained with them. 

#### Deuteronomy 31:21 And it will be whenever {shall find him evils many and afflictions}, and {shall stand firm ode this against their face witnessing}. For they should not forget it from their mouth, and from the mouth of their seed. For I perceive their wickedness, as much as they do here today, before my bringing them into the {land good} which I swore by an oath to their fathers. 

#### Deuteronomy 31:22 And Moses wrote this ode in that day, and he taught it to the sons of Israel. 

#### Deuteronomy 31:23 And Moses gave charge to Joshua son of Nun and said, Be manly and be strong! For you shall bring the sons of Israel into the land which {swore by an oath to them the LORD}, and he will be with you. 

#### Deuteronomy 31:24 And when Moses completed writing all the words of this law in a scroll, until completion, 

#### Deuteronomy 31:25 that he gave charge to the Levites, to the ones lifting the ark of the covenant of the LORD, saying, 

#### Deuteronomy 31:26 Taking the scroll of this law, you shall put it sideways in the ark of the covenant of the LORD your God; and it will be there to you for a testimony. 

#### Deuteronomy 31:27 For I know the aggravation caused by you, and {neck your hard}. For still in my living with you today, {embittering greatly you have been} the things towards God; how not so also at the last at my death? 

#### Deuteronomy 31:28 Hold an assembly for me of your tribal chiefs, and your elders, and your judicial recorders! that I should speak into their ears all these words; and I call to testify to them both the heaven and the earth. 

#### Deuteronomy 31:29 For I know that at the last of my decease, with lawlessness you shall act lawlessly, and shall turn aside from the way of which I gave charge to you; and {shall meet with you evils} at the last of the days; for you shall do the evil before the LORD to provoke him to anger by the works of your hands. 

#### Deuteronomy 31:30 And Moses spoke into the ears of all the assembly of Israel the words of this ode, until completion. 

#### Deuteronomy 32:1 Take heed, O heaven! and I will speak. And hear, O earth, the discourses from out of my mouth! 

#### Deuteronomy 32:2 Expect as the rain my maxims, and let {go down as dew my discourses}, as a heavy shower upon wild grass, and as snowflakes upon grass! 

#### Deuteronomy 32:3 For {the name of the LORD I called}. Give greatness to our God! 

#### Deuteronomy 32:4 God, {are true his works}, and all his ways are equity. God is trustworthy, and there is no injustice in him; just and sacred is the LORD. 

#### Deuteronomy 32:5 They sinned -- they are not his children; they are a scoffing -- {generation a crooked}, and one turning aside. 

#### Deuteronomy 32:6 {these things to the LORD Do you recompense} thus, O people, moronish and not wise? Did not he, this your father, acquire you, and make you, and shape you? 

#### Deuteronomy 32:7 Remember the days of the eon! Perceive indeed the years of the generations of generations! Ask your father, and he will announce to you; your elders, and they shall speak to you. 

#### Deuteronomy 32:8 When {divided into parts the highest nations}, as he disseminated the sons of Adam, he set the borders of nations according to the number of the angels of God; 

#### Deuteronomy 32:9 and {became a portion for the LORD his people Jacob}. {is a piece of measured out land of his inheritance Israel}. 

#### Deuteronomy 32:10 He sufficed him in {land a wilderness}, in thirst of sweltering heat in {land a waterless}. He encircled him, and corrected him, and guarded him as a pupil of an eye. 

#### Deuteronomy 32:11 As an eagle sheltering his nest, {and over his young he longs after}. Thrusting out his wings he receives them; and he takes them upon his upper back. 

#### Deuteronomy 32:12 The LORD alone led them, and there was not with them an alien god. 

#### Deuteronomy 32:13 He brought them unto the strength of the land. He fed them produce of fields. They nursed honey out of the rock, and olive oil out of the solid rock. 

#### Deuteronomy 32:14 Butter of oxen, and milk of sheep, with fat of lambs and rams, offspring of bulls and he-goats, with fat of kidneys of wheat, and {the blood of the grape they drank wine}. 

#### Deuteronomy 32:15 And Jacob ate and was filled up, and {kicked up the one being loved}; he was fattened, he was thickened, he was widened, and he abandoned God the one making him; and he left from God his deliverer. 

#### Deuteronomy 32:16 They provoked me over the alien ones; in their abominations they greatly embittered me. 

#### Deuteronomy 32:17 They sacrificed to demons, and not to God -- to gods in whom they did not know; new and newly made gods have come, in whom {knew not their fathers}. 

#### Deuteronomy 32:18 God, the one creating you, you abandoned; and you forgot God the one maintaining you. 

#### Deuteronomy 32:19 And the LORD beheld, and was jealous; and he was provoked to anger by their sons and daughters. 

#### Deuteronomy 32:20 And he said, I will turn away my face from them, and I will show what will be to them at the last times, for {a generation being distorted it is}; sons in whom there is no belief in them. 

#### Deuteronomy 32:21 They provoked me to jealousy over that which is not god; they provoked me to anger with their idols. And I shall provoke them to jealousy over that which is not a nation. Over {nation a senseless} I will provoke them to anger. 

#### Deuteronomy 32:22 For a fire burns away of my rage; it shall be burned unto {Hades lower}; it shall devour the land, and its produce; it shall blaze on the foundations of mountains. 

#### Deuteronomy 32:23 I bring together to them bad things; and by my arrows I will finish with them; 

#### Deuteronomy 32:24 melting them away in hunger, and being food of fowls, and {convulsion incurable}. The teeth of wild beasts I will send as a successor to them, with rage dragging them upon the ground. 

#### Deuteronomy 32:25 From outside {shall make them childless the sword}, and from out of the inner chambers fear; the young man with the virgin, the one nursing being placed with the old man. 

#### Deuteronomy 32:26 I said, I will disperse them, and I will cause {to cease from among men their memorial}. 

#### Deuteronomy 32:27 Unless they should say it was on account of the anger of the enemies, that in no way should they live a long time, and that in no way {join in making an attack their opponents}, lest they should say, {hand Our high}, and not the LORD did all these things. 

#### Deuteronomy 32:28 For {a nation destroying counsel it is}, and there is no {in them higher knowledge}. 

#### Deuteronomy 32:29 They did not think to perceive; let them appreciate in the coming time. 

#### Deuteronomy 32:30 How shall {pursue one} thousands, and two rout ten thousands, unless God rendered them up, and the LORD delivered them up? 

#### Deuteronomy 32:31 For {are not as our God their gods}, but our enemies are unthinking. 

#### Deuteronomy 32:32 For of the grapevine of Sodom is their grapevine, and their small vine branch is of Gomorrah; their grape is the grape of bile, their cluster is bitterness to them. 

#### Deuteronomy 32:33 The rage of serpents is their wine, and {rage of asps the incurable}. 

#### Deuteronomy 32:34 Behold, are not these things brought together by me, and a set seal among my treasures? 

#### Deuteronomy 32:35 In the day of punishment I shall recompense, in a time whenever {should trip their foot}; for {is near the day of their destruction}, and at hand prepared for you. 

#### Deuteronomy 32:36 For the LORD judges his people, and over his menservants he shall be comforted. For he beheld their being disabled, and failing in the hostile invasion, and were weakened. 

#### Deuteronomy 32:37 And the LORD said, Where are their gods upon whom they yielded upon them? 

#### Deuteronomy 32:38 Of whom the fat of their sacrifices you ate, and drank the wine of their libations? Let them rise up and help you, and be your shelterer! 

#### Deuteronomy 32:39 Behold! behold that I am! and there is no God besides me. I shall kill, and {to live I shall make}. I shall strike, and I will heal. And there is not one who shall rescue from out of my hands. 

#### Deuteronomy 32:40 For I shall lift into the heaven my hand, and I shall swear by an oath by my right hand. And I will say, I live into the eon. 

#### Deuteronomy 32:41 For I will sharpen {as lightning my sword}, and {will hold to equity my hand}. And I will recompense punishment against the enemies; and against the ones detesting me I will recompense. 

#### Deuteronomy 32:42 I shall intoxicate my arrows of blood, and my sword shall devour meats from the blood of the slain, and from the captivity of the heads of the rulers of the enemies. 

#### Deuteronomy 32:43 Be glad, O heavens, together with him! and do obeisance to him, all angels of God! Be glad, O nations, with his people! And grow in strength in him all, O sons of God! For the blood of his sons he shall avenge, and he shall avenge and recompense punishment to the enemies. And to the ones detesting him he will recompense, and the LORD shall clear out the land for his people. 

#### Deuteronomy 32:44 And Moses wrote this ode in that day. And he taught it to the sons of Israel. And Moses approached and spoke all the words of this law into the ears of the people, he and Joshua the son of Nun. 

#### Deuteronomy 32:45 And Moses completed speaking these words to all Israel. 

#### Deuteronomy 32:46 And he said to them, You take heed in your heart over all these words which I testify to you today, which you shall charge to your sons, to guard and to do all the words of this law! 

#### Deuteronomy 32:47 For {is not word an empty this} for you, for this is your life. And because of this word you shall prolong your days upon the land into which you pass over the Jordan there to inherit it. 

#### Deuteronomy 32:48 And the LORD spoke to Moses in this day, saying, 

#### Deuteronomy 32:49 Ascend into the mountain Abarim, this mountain Nebo! which is in the land of Moab, against the face of Jericho. And behold the land of Canaan! which I give to the sons of Israel for a possession. 

#### Deuteronomy 32:50 And come to an end in the mountain into which you ascend there! And be added to your people! in which manner {died Aaron your brother} in Hor the mountain, and was added to his people. 

#### Deuteronomy 32:51 Because you resisted persuasion of my word, among the sons of Israel at the water of dispute, Kadesh, in the wilderness of Sin; because you did not sanctify me among the sons of Israel. 

#### Deuteronomy 32:52 For {before you you shall see the land}, and {there you shall not enter}, into the land which I give to the sons of Israel. 

#### Deuteronomy 33:1 This is the blessing which {blessed Moses the man of God} the sons of Israel before his decease. 

#### Deuteronomy 33:2 And he said, The LORD {from out of Sinai is come}, and he appeared upon Seir to us. And he hastened from out of mount Paran with myriads of Kadesh -- at his right were angels with him. 

#### Deuteronomy 33:3 And he spared his people, and all the ones being sanctified by your hands; these {under you are}; and he received of his words 

#### Deuteronomy 33:4 the law which {gave charge to us Moses}, an inheritance of the congregation of Jacob. 

#### Deuteronomy 33:5 And he will be {with the one being loved a ruler} being brought {with rulers of peoples together} among tribes of Israel. 

#### Deuteronomy 33:6 Let Reuben live and not die! And let Simon be many in number! 

#### Deuteronomy 33:7 And this for Judah, Listen, O LORD, of the voice of Judah, and unto his people! may they enter in. His hands shall litigate for him; and {a helper from his enemies you will be}. 

#### Deuteronomy 33:8 And to Levi he said, Give to Levi his manifestations and his truth to the {man sacred}, whom they tested him in Trial; they reviled him at Water of Dispute; 

#### Deuteronomy 33:9 the one saying to his father and to his mother, I have not seen you; and his brethren he did not recognize, and his sons he did not know. He guarded your oracles, and {your covenant he observed}. 

#### Deuteronomy 33:10 They shall manifest your ordinances to Jacob, and your law to Israel. They shall place incense in the time of your anger always upon your altar. 

#### Deuteronomy 33:11 Bless, O LORD his strength! And the works of his hands receive! Break the loin {having risen up against him of his enemies}! And the ones detesting him let them not rise up! 

#### Deuteronomy 33:12 And to Benjamin he said, One being loved by the LORD; he shall encamp being yielded, and God shadows over him all the days, and {between his shoulders he rested}. 

#### Deuteronomy 33:13 And to Joseph he said, {is of the blessing of the LORD His hand}, of seasons of heaven, and of dew, and of the deeps of springs below, 

#### Deuteronomy 33:14 and according to the season of the offsprings {of the sun of the circuits}, and of the returns of the months; 

#### Deuteronomy 33:15 from the top {mountains of ancient}, and from the top {hills of everlasting}, 

#### Deuteronomy 33:16 and according to {in season of the land the fullness}, and the accepted things being seen in the bush -- may they come upon the head of Joseph, and upon the top being glorified among brethren. 

#### Deuteronomy 33:17 As a first-born bull is his beauty. Horns of a unicorn are his horns. With them {nations he shall gore} together, even from the tip of the earth. These are the myriads of Ephraim, and these are the thousands of Manasseh. 

#### Deuteronomy 33:18 And to Zebulun he said, Be glad, O Zebulun, in your departure, and Issachar in your tents! 

#### Deuteronomy 33:19 {nations They shall utterly destroy}, and you shall call upon there, and you shall sacrifice a sacrifice of righteousness; for the riches of the sea shall nurse you, and market-places {on the coast dwelling}. 

#### Deuteronomy 33:20 And to Gad he said, One being blessed, widening Gad. As a lion he rested, having broken the arm, and the ruler. 

#### Deuteronomy 33:21 And he beheld his first-fruit, for there {was portioned the land} by rulers being brought together, heads of peoples; {righteousness the LORD did}, and his equity was with Israel. 

#### Deuteronomy 33:22 And to Dan he said, Dan, {cub a lion}, and he shall rush out from Bashan. 

#### Deuteronomy 33:23 And to Naphtali he said, Naphtali a fullness of acceptable things; and let him be filled with blessing from the LORD! {the west and the south You shall inherit}. 

#### Deuteronomy 33:24 And to Asher he said, {is one being blessed of children Asher}; and he will be acceptable to his brethren; he shall dip {in olive oil his foot}; 

#### Deuteronomy 33:25 iron and brass {his sandal will be}; and as your days so your strength. 

#### Deuteronomy 33:26 There is not any as the God of the one being loved. The one mounting upon the heaven is your helper, even the majestic one of the firmament. 

#### Deuteronomy 33:27 And {shall shelter you of God the sovereignty}, and that under the strength {arms of everlasting}. And he shall cast out from your face the enemy, saying, May you perish. 

#### Deuteronomy 33:28 And Israel shall encamp alone complying; fountain of Jacob, with grain and wine; and the heaven {on him covered with clouds in dew}. 

#### Deuteronomy 33:29 Blessed are you, O Israel. Who is likened to you, a people being delivered by the LORD? {is the shield Your helper}, and the sword of your boasting. And {shall lie to you your enemies}, and you {upon their neck shall mount}. 

#### Deuteronomy 34:1 And Moses ascended from the wilderness of Moab unto mount Nebo, upon the top of Pisgah, which is upon the face of Jericho. And {showed to him the LORD} all the land of Gilead unto Dan, 

#### Deuteronomy 34:2 and all the land of Naphtali, and all the land of Ephraim and Manasseh, and all the land of Judah unto the {sea latter}; 

#### Deuteronomy 34:3 and the wilderness, and the places round about Jericho, City of Palms unto Zoar. 

#### Deuteronomy 34:4 And the LORD said to Moses, This is the land which I swore by an oath to Abraham, and Isaac, and Jacob, saying, To your seed I shall give it. And I showed it to your eyes, but there you shall not enter. 

#### Deuteronomy 34:5 And {came to an end there Moses}, the servant of the LORD, in the land of Moab by the word of the LORD. 

#### Deuteronomy 34:6 And they entombed him in the land of Moab near the house of Peor. And not has {known any one} his burial place until this day. 

#### Deuteronomy 34:7 And Moses was a hundred and twenty years old at his coming to an end. {were not darkened His eyes}, nor were {corrupted his lips}. 

#### Deuteronomy 34:8 And {wept over the sons of Israel} Moses in the wilderness of Moab, at the Jordan by Jericho for thirty days; and they completed the days of the mourning of weeping for Moses. 

#### Deuteronomy 34:9 And Joshua son of Nun was filled of spirit of understanding; {placed for Moses} his hands upon him. And {hearkened to him the sons of Israel}, and they did in so far as the LORD gave charge to Moses. 

#### Deuteronomy 34:10 And rose up not any longer a prophet in Israel as Moses, whom the LORD knew him face to face, 

#### Deuteronomy 34:11 in all the signs and miracles, which {sent him the LORD} to do them in the land of Egypt, to Pharaoh, and to his attendants, and to all his land; 

#### Deuteronomy 34:12 and the {wonders great}, and all by the {hand fortified} which Moses executed before all Israel.