#### Exodus 1:1 These are the names of the sons of Israel of the ones entering into Egypt together with Jacob their father; each of them sojourning entered. 

#### Exodus 1:2 Reuben, Simeon, Levi, Judah, 

#### Exodus 1:3 Issachar, Zebulun, Benjamin, 

#### Exodus 1:4 Dan, and Naphtali, Gad, and Asher. 

#### Exodus 1:5 But Joseph was in Egypt. And were all the souls coming forth from Jacob -- five and seventy. 

#### Exodus 1:6 {came to an end And Joseph], and all his brothers, and all that generation. 

#### Exodus 1:7 And the sons of Israel grew and multiplied, and {extensive became], and grew strong exceedingly, exceedingly. {multiplied And the land] of them. 

#### Exodus 1:8 {rose up And king another] over Egypt who did not know Joseph. 

#### Exodus 1:9 And he said to his nation, Behold, the race of the sons of Israel are a great multitude, and they are strong above us. 

#### Exodus 1:10 Come then we should deal subtly with them, lest at any time they should multiply, and whenever {to us may come to pass a war], {will add these also] to the opponents, and waging war against us they shall go forth from the land. 

#### Exodus 1:11 And he set to them supervisors over the works, that they might afflict them in their works. And they built {cities fortified] to Pharaoh -- Pithom and Raamses, and On which is Heliopolis. 

#### Exodus 1:12 And in so far as they humbled them by so much, {many more they became]. And they were strong exceedingly, exceedingly. And {were abhorred the Egyptians] of the sons of Israel. 

#### Exodus 1:13 And {tyrannized the Egyptians] the sons of Israel by force. 

#### Exodus 1:14 And they grievously afflicted them by the life in the {works hard] in the mortar, and in the making of bricks, and in all the works in the plains, according to all the works which they were reducing them to slavery with force. 

#### Exodus 1:15 And {said the king of the Egyptians] to the midwives of the Hebrews, to a certain one of them with the name Shiphrah, and the name of the second Puah. 

#### Exodus 1:16 And he said to them, Whenever you act as midwife to the Hebrews, and they should be about to bear, if then it should be a male, you kill it! But if a female, preserve it! 

#### Exodus 1:17 {feared But the midwives] God, and they did not do in so far as {ordered them the king of Egypt]. And they brought forth alive the males. 

#### Exodus 1:18 {called And the king of Egypt] the midwives, and said to them, Why is it that you did this thing, and brought forth alive the males? 

#### Exodus 1:19 {said And the midwives] to Pharaoh, Not as the women of Egypt are the Hebrews, for they give birth before {entered to them the midwives], and they bear. 

#### Exodus 1:20 {good And God did] to the midwives. And he multiplied the people, and it became strong exceedingly. 

#### Exodus 1:21 Since {feared the midwives] God, they made to themselves families. 

#### Exodus 1:22 {gave orders And Pharaoh] to all his people, saying, Every male who ever should be born to the Hebrews {into the river toss], and every female bring it forth alive! 

#### Exodus 2:1 And there was a certain man from the tribe of Levi, and he took of the daughters of Levi, and had her. 

#### Exodus 2:2 And {in the womb she conceived], and bore a male. And seeing that it was fair, they sheltered it {months three]. 

#### Exodus 2:3 But when they were not able {it any longer to hide], {took for him his mother] a wicker basket of papyrus, and besmeared it with tar, and put the male child into it, and put it into the marsh by the river. 

#### Exodus 2:4 And {spied out his sister] far off to learn what would result to him. 

#### Exodus 2:5 {went down And the daughter of Pharaoh] to bathe upon the river, and her handmaidens came near unto the river. And they saw the wicker basket in the marsh, and she sent the handmaiden to take it up. 

#### Exodus 2:6 And opening, she sees a male child weeping in the wicker basket. And {spared him the daughter of Pharaoh], and said, {from the male children of the Hebrews This one is]. 

#### Exodus 2:7 And {said his sister] to the daughter of Pharaoh, If you want I will call for you a woman nursing from the Hebrews, and she will suckle for you the male child. 

#### Exodus 2:8 And {said to her the daughter of Pharaoh], Go! And going, the young woman called the mother of the male child. 

#### Exodus 2:9 {said And to her the daughter of Pharaoh], Carefully keep for me this male child, and suckle it for me, and I will give to you the wage. {took And the woman] the male child, and suckled it. 

#### Exodus 2:10 {maturing And the male child], she brought it to the daughter of Pharaoh. And he became to her for a son. And she named his name Moses. Saying, For from the water I took him up. 

#### Exodus 2:11 And it came to pass in {days many those], {older becoming Moses], he went forth to his brethren of the sons of Israel. And contemplating their misery, he saw an Egyptian man beating a certain Hebrew of his own brethren of the sons of Israel. 

#### Exodus 2:12 And looking about here on this side and here on that side he did not see anyone. And striking the Egyptian, he hid him in the sand. 

#### Exodus 2:13 And coming forth the {day second], he saw two men, Hebrews skirmishing. And he says to the one in the wrong, Why do you beat your neighbor? 

#### Exodus 2:14 And he said, Who placed you magistrate and judge over us? Is it that {to do away with me you want] in which manner you did away yesterday with the Egyptian? {feared And Moses], and said, Surely thus {apparent has become this thing]. 

#### Exodus 2:15 {heard about And Pharaoh] this thing, and he sought to do away with Moses. {withdrew But Moses] from the face of Pharaoh, and he dwelt in the land of Midian. And coming into the land of Midian, he sat at the well. 

#### Exodus 2:16 And to the priest of Midian there were seven daughters tending the sheep of their father Jethro. And they came to draw water until they filled the troughs to water the sheep of their father Jethro. 

#### Exodus 2:17 And coming, the shepherds cast them away. {rose up But Moses] to rescue them, and he drew water for them, and he watered their sheep. 

#### Exodus 2:18 And they came to Reuel their father. And he said to them, Why is it that you hastened to come today? 

#### Exodus 2:19 And they said, An Egyptian man rescued us from the shepherds, and he drew water for us, and he watered our sheep. 

#### Exodus 2:20 And he said to his daughters, And where is he, and why thus have you left the man? You call him indeed! that he may eat bread. 

#### Exodus 2:21 {settled And Moses] by the man. And he handed over Zipporah his daughter to Moses as wife. 

#### Exodus 2:22 {in the womb And conceiving], the woman bore a son, and Moses named his name Gershom, saying that, I am a sojourner in {land an alien]. And still again conceiving, she bore {son a second], and he called his name Eliezer, saying that, the God of my father, my helper, also rescued me from the hand of Pharaoh. 

#### Exodus 2:23 And after {days many those], {came to an end the king of Egypt], and {groaned the sons of Israel] from the works, and yelled out. And {ascended their yell] to God because of the works. 

#### Exodus 2:24 And God listened to their moaning, and God remembered his covenant, the one with Abraham, and Isaac, and Jacob. 

#### Exodus 2:25 And God looked upon the sons of Israel, and he was made known to them. 

#### Exodus 3:1 And Moses was tending the sheep of Jethro his father-in-law, the priest of Midian. And he led the sheep by the wilderness. And he came unto the mountain of God -- Horeb. 

#### Exodus 3:2 And appeared to him an angel of the LORD in flaming fire from out of the bush. and he saw that the bush burned with fire, but the bush did not incinerate. 

#### Exodus 3:3 {said And Moses], Going by I will see {vision this great]. Why is it that {is not incinerated the bush]. 

#### Exodus 3:4 And as the LORD saw that he neared to see, {called him the LORD] from out of the bush, saying, Moses, Moses. And he said, What is it? 

#### Exodus 3:5 And he said, You should not approach here. Untie the sandal from your feet, for the place in which you stand {ground is holy]. 

#### Exodus 3:6 And he said to him, I am the God of your father; the God of Abraham, and the God of Isaac, and the God of Jacob. {turned And Moses] his face, for he venerated to look in the presence of God. 

#### Exodus 3:7 {said And the LORD] to Moses, In seeing, I saw the ill-treatment of my people in Egypt, and their cry I have heard because of the foremen. For I have seen their grief. 

#### Exodus 3:8 And I came down to rescue them from the hand of the Egyptians, and to lead them from out of that land, and to bring them into a land good and populous; into a land flowing milk and honey; into the place of the Canaanites, and Hittites, and Amorites, and Perizzites, and Gergesites, and Hivites, and Jebusites. 

#### Exodus 3:9 And now, behold, the cry of the sons of Israel is come to me. And I have seen the affliction by which the Egyptians afflict them. 

#### Exodus 3:10 And now, come, I shall send you to Pharaoh king of Egypt. And you shall lead my people the sons of Israel from out of the land of Egypt. 

#### Exodus 3:11 And Moses said to God, Who am I that I shall go to Pharaoh king of Egypt, and that I shall lead out the sons of Israel from the land of Egypt? 

#### Exodus 3:12 {said And God] to Moses, saying that, I will be with you. And this will be to you the sign that I send you in your leading my people from out of Egypt, and you shall serve God in this mountain. 

#### Exodus 3:13 And Moses said to God, Behold, I will go to the sons of Israel, and I shall say to them, The God of our fathers sent me to you. And if they shall ask me, What is the name given to him? What shall I say to them? 

#### Exodus 3:14 And God said to Moses, I am the one being. And he said, Thus you shall say to the sons of Israel, The one being has sent me to you. 

#### Exodus 3:15 And God said again to Moses, Thus you shall say to the sons of Israel, The LORD God of our fathers, the God of Abraham, and the God of Isaac, and the God of Jacob sent me to you; this is my {name eternal], and a memorial for generations to generations. 

#### Exodus 3:16 Going then, gather the council of elders of the sons of Israel! And you shall say to them, The LORD God of our fathers appeared to me; the God of Abraham, and the God of Isaac, and the God of Jacob, saying, In overseeing I have watched you, and as much as has come to pass to you in Egypt. 

#### Exodus 3:17 And he said, I will haul you from the ill treatment of the Egyptians into the land of the Canaanites, and Hittites, and Hivites, and Amorites, and Perizzites, and Gergesites, and Jebusites, into a land flowing milk and honey. 

#### Exodus 3:18 And they shall hearken to your voice. And you shall enter, and the council of elders of Israel, to Pharaoh king of Egypt. And you shall say to him, The LORD God of the Hebrews calls us. We shall go then on {journey a three days] into the wilderness, that we might sacrifice to the LORD our God. 

#### Exodus 3:19 But I know that {will not let you go Pharaoh king of Egypt], {going unless] with {hand a fortified], 

#### Exodus 3:20 and stretching out my hand to strike the Egyptians in all my wonders, which I will do among them. And after these things I will send you out. 

#### Exodus 3:21 And I will give favor to this people before the Egyptians. And whenever you might run from them, you will not go forth empty. 

#### Exodus 3:22 But {will ask a woman] from {neighbor and fellow tent-dweller her] of items of silver, and of gold, and clothes. And you will place them upon your sons, and upon your daughters, and you will despoil the Egyptians. 

#### Exodus 4:1 {answered And Moses] and said, If then they should not believe me, nor listen to my voice, for they shall say that {did not appear to you God], what shall I say to them? 

#### Exodus 4:2 {said And to him the LORD], What is this the thing in your hand? And he said, A rod. 

#### Exodus 4:3 And he said to him, Toss it upon the ground! And he tossed it upon the ground, and it became a serpent. And Moses fled from it. 

#### Exodus 4:4 And the LORD said to Moses, Stretch out the hand, and take hold of the tail! Stretching out then the hand, he took hold of the tail, and it became a rod in his hand -- 

#### Exodus 4:5 that they might trust you that there appeared to you the LORD God of their fathers, the God of Abraham, and the God of Isaac, and the God of Jacob. 

#### Exodus 4:6 {said And to him the LORD] again, Insert your hand into your bosom! And he inserted his hand into his bosom. And he brought it from out of his bosom, and {was his hand] leprous as snow. 

#### Exodus 4:7 And {said again to him the LORD], Insert your hand into your bosom! And he inserted the hand into his bosom. And he brought it out of his bosom, and again it was restored unto the complexion of his flesh. 

#### Exodus 4:8 And if they do not believe you, nor hearken to the voice of the {sign first], they will believe you by the voice of the {sign second]. 

#### Exodus 4:9 And it will be if they do not believe you in {two signs these], nor hearken to your voice, you shall take from the water of the river, and pour it upon the dry land. And {will be water which ever you should take from the river] blood upon the dry land. 

#### Exodus 4:10 {said And Moses] to the LORD, I beseech, O LORD, {not fit I am] before yesterday nor before the third day, nor from which time you began to speak to your attendant, {weak voiced and slow of tongue for I am]. 

#### Exodus 4:11 {said And the LORD] to Moses, Who gave {a mouth man], and who made the hard of hearing and mute, the seeing, and blind? Was it not I the LORD God? 

#### Exodus 4:12 And now go! And I will open your mouth, and I will instruct you what you will be about to speak. 

#### Exodus 4:13 And Moses said, I beseech, O LORD, to handpick another one able whom you shall send. 

#### Exodus 4:14 And {being enraged in anger the LORD] over Moses, said, Behold, is not Aaron your brother, the Levite? I know that speaking, he will speak to you. And behold, he will come forth to meet you; and seeing you, he will rejoice in himself. 

#### Exodus 4:15 And you will say to him, and you will put my words into his mouth. And I will open your mouth and his mouth, and I will instruct you what you shall do. 

#### Exodus 4:16 And he shall speak the things to the people, and he will be your mouth. But you will be to him the things for God. 

#### Exodus 4:17 And this rod, the one turning into a serpent, you shall take in your hand in which you will do by it the signs. 

#### Exodus 4:18 {went And Moses], and he returned to Jethro his father-in-law. And he says, I will go, and return to my brethren, the ones in Egypt, and I will see if they still live. And Jethro said to Moses, Proceed, be in health! But after {days those many] {came to an end the king of Egypt]. 

#### Exodus 4:19 {said And the LORD] to Moses in the land of Midian, Proceed, go forth into Egypt! For have died all the ones seeking your life. 

#### Exodus 4:20 {took up And Moses] his wife and the male children, and he hauled them upon the beasts of burden, and turned to Egypt. {took And Moses] the rod, the one by God in his hand. 

#### Exodus 4:21 {said And the LORD] to Moses, In your going and returning unto Egypt, discover all the miracles which I have put in your hand, to do them before Pharaoh. But I will harden his heart, and no way shall he send out the people. 

#### Exodus 4:22 But you will say to Pharaoh, Thus says the LORD -- son of my first-born, Israel. 

#### Exodus 4:23 And I said to you, Send my people! that they should serve me. If indeed then you should not be willing to send them, see then! I will kill your son, the first-born! 

#### Exodus 4:24 And it came to pass during the journey in the lodging, {met him an angel of the LORD], and sought to kill him. 

#### Exodus 4:25 And Zipporah, taking a small sharp stone, circumcised the foreskin of her son. And she fell at his feet, and said, {is stopped The blood of the circumcision of my male child]. 

#### Exodus 4:26 And {went forth from him the angel], for she said, {is stopped The blood of the circumcision of my male child]. 

#### Exodus 4:27 {said And the LORD] to Aaron, Go to meet with Moses in the wilderness! And he went, and he met with him in the mountain of God, and they kissed one another. 

#### Exodus 4:28 And Moses announced to Aaron all the words of the LORD which he sent to him, and all the signs which he gave charge to him. 

#### Exodus 4:29 {went And Moses and Aaron], and brought together the council of elders of the sons of Israel. 

#### Exodus 4:30 And Aaron spoke all the words which God spoke to Moses. And he did the signs before the people. 

#### Exodus 4:31 And {believed the people], and rejoiced that God visited the sons of Israel, and that he saw their affliction. And bowing, the people did obeisance. 

#### Exodus 5:1 And after these things {entered Moses and Aaron] to Pharaoh, and they said to him, Thus says the LORD God of Israel. Send forth my people! that they may solemnize a holiday to me in the wilderness. 

#### Exodus 5:2 And Pharaoh said, Who is he, of whom I will listen to his voice so as to send out the sons of Israel? I do not know the LORD, and {Israel I will not send out]. 

#### Exodus 5:3 And they say to him, The God of the Hebrews called on us. We will go then on a journey of three days into the wilderness, that we may sacrifice to the LORD our God, lest at any time {might meet with us death or murder]. 

#### Exodus 5:4 And {said to them the king of Egypt], Why do you, Moses and Aaron, turn aside the people from the works? Go forth each of you to his works! 

#### Exodus 5:5 And Pharaoh said, Behold, now {are numerous The people of the land]; {not then I shall] rest them from the works. 

#### Exodus 5:6 {gave orders And Pharaoh] to the foremen of the people, and to the scribes, saying, 

#### Exodus 5:7 No longer will it be added to give straw to the people for the brickmaking, as yesterday and the third day before. Let them go and bring together for themselves the straw! 

#### Exodus 5:8 And the rate of the making of bricks which they produce each day, you shall put it upon them. You shall not remove any of them, for they are idle. On account of this they cry out, saying, We should go and sacrifice to our God. 

#### Exodus 5:9 Let {be oppressive the works of these men], and let {be anxious these men], and not anxious in {words empty]! 

#### Exodus 5:10 And hastened of them the foremen, and the scribes of the people. And they said to the people, saying, Thus says Pharaoh, No longer do I give to you straw. 

#### Exodus 5:11 You yourselves in going, collect together for yourselves straw! from where ever you should find. For nothing is removed from your rate, not one thing. 

#### Exodus 5:12 And he dispersed the people in the entire land of Egypt to gather together stubble for straw. 

#### Exodus 5:13 But the foremen hastened them, saying, You complete the works, the ones fit according to the day, just as also when the straw was given to you. 

#### Exodus 5:14 And they were whipped -- the scribes of the race of the sons of Israel, the ones being placed over them by the supervisors of Pharaoh, and saying, Why did you not complete your rate of the making of bricks as also yesterday and the third day before and today? 

#### Exodus 5:15 And entering, the scribes of the sons of Israel yelled out to Pharaoh, saying, Why do you thus do to your servants? 

#### Exodus 5:16 Straw has not been given to your servants, and {brick they tell us to make]. And behold, your servants have been whipped. Shall you wrong therefore your people? 

#### Exodus 5:17 And he said to them, You are idle, you are idlers. Because of this you say, We should go, we should sacrifice to the LORD. 

#### Exodus 5:18 Now then, in going, work! For the straw {to you shall not be given], and the rate for the making of bricks you shall render. 

#### Exodus 5:19 {seeing And the scribes of the sons of Israel] themselves in bad ways, in the saying, You shall not leave off from the making of bricks fit for the day, 

#### Exodus 5:20 that they met Moses and Aaron coming to meet with them in their going forth from Pharaoh. 

#### Exodus 5:21 And they said to them, {give over God you] and judge, for you caused {to be abhorred our scent] before Pharaoh, and before his attendants, to put a broadsword into his hands to kill us. 

#### Exodus 5:22 {turned And Moses] to the LORD, and said, O LORD, for why did you inflict evil on this people? And why have you sent me? 

#### Exodus 5:23 And when I went to Pharaoh to speak in the {being to you name], he inflicted evil on this people, and you did not rescue your people. 

#### Exodus 6:1 And the LORD said to Moses, Already you shall see what I will do to Pharaoh. For with {hand a fortified] he shall send them; and with {arm a high] he will cast them from out of his land. 

#### Exodus 6:2 {spoke And God] to Moses, and said to him, I am the LORD. 

#### Exodus 6:3 And I appeared to Abraham, and Isaac, and Jacob, {God being their]. And my name, the LORD, was not manifested to them. 

#### Exodus 6:4 And I established my covenant with them, so as to give to them the land of Canaan, the land which they sojourned, in which also they sojourned upon it. 

#### Exodus 6:5 And I hearkened to the moaning of the sons of Israel, in which the Egyptians reduced them to slavery. And I remembered your covenant. 

#### Exodus 6:6 Proceed, say to the sons of Israel! saying, I am the LORD, and I will lead you from the domination of the Egyptians, and I will rescue you from their slavery, and I will ransom you with {arm a high] and {judgment great]. 

#### Exodus 6:7 And I will take you to myself as a people to me. And I will be your God. And you will know that I am the LORD your God, the one leading you from out of the tyranny of the Egyptians. 

#### Exodus 6:8 And I will bring you into the land in which I stretched out my hand to give it to Abraham, and Isaac, and Jacob. And I will give it to you by lot. I am the LORD. 

#### Exodus 6:9 {spoke And Moses] thus to the sons of Israel, and they did not hearken to Moses because of faint-heartedness, and because of the {works hard]. 

#### Exodus 6:10 {said And the LORD] to Moses, saying, 

#### Exodus 6:11 Enter, speak to Pharaoh king of Egypt! that he may send out the sons of Israel from his land. 

#### Exodus 6:12 {spoke And Moses] before the LORD, saying, Behold, the sons of Israel do not listen to me, and how shall {listen to me Pharaoh], for I am not reckoned? 

#### Exodus 6:13 {spoke And the LORD] to Moses and Aaron, and he ordered them to Pharaoh king of Egypt, so as to lead out the sons of Israel from out of the land of Egypt. 

#### Exodus 6:14 And these are the chiefs of the houses of their families. The sons of Reuben first-born of Israel -- Hanoch and Pallu, Hezron, and Carmi -- this is the kin of Reuben. 

#### Exodus 6:15 And the sons of Simeon -- Jemuel, and Jamin, and Ohad, and Jachin, and Zohar, and Shaul the one from the Phoenician woman. These are the families of the sons of Simeon. 

#### Exodus 6:16 And these are the names of the sons of Levi according to their kin -- Gershon, Kohath and Merari; and the years of the life of Levi -- a hundred thirty-seven years. 

#### Exodus 6:17 And these are the sons of Gershon -- Libni and Shimei; the houses of their family. 

#### Exodus 6:18 And the sons of Kohath -- Amram, and Izhar, and Hebron, and Uzziel; and the years of the life of Kohath -- a hundred thirty years. 

#### Exodus 6:19 And the sons of Merari -- Mahli, and Mushi. These are the houses of the families of Levi, according to their kin. 

#### Exodus 6:20 And Amram took Jochebed daughter of the brother of his father to himself for a wife. And she bore to him also Aaron, and Moses, and Miriam their sister. And the years of the life of Amram -- a hundred thirty-seven years. 

#### Exodus 6:21 And the sons of Izhar -- Korah, and Nepheg, and Zithri. 

#### Exodus 6:22 And the sons of Uzziel -- Mishael, and Elzaphan, and Zithri. 

#### Exodus 6:23 {took And Aaron] Elisheba daughter of Amminadab sister of Naahshon to himself as wife. And she bore to him also Nadab, and Abihu, and Eleazar, and Ithamar. 

#### Exodus 6:24 And the sons of Korah -- Assir, and Elkanah, and Abiasar. These are the generations of Korah. 

#### Exodus 6:25 And Eleazar the son of Aaron, took of the daughters of Putiel to himself as wife; and she bore to him Phinehas. These are the heads of the family of the Levites, according to their generations. 

#### Exodus 6:26 This Aaron and Moses, is whom God said to them to lead the sons of Israel from out of Egypt with their force. 

#### Exodus 6:27 These are the ones reasoning with Pharaoh king of Egypt, so as to lead the sons of Israel from out of Egypt -- Aaron himself and Moses, 

#### Exodus 6:28 in the day the LORD spoke to Moses in the land of Egypt. 

#### Exodus 6:29 And the LORD spoke to Moses, saying, I am the LORD. Speak to Pharaoh king of Egypt as much as I tell to you! 

#### Exodus 6:30 And Moses said before the LORD, Behold, I am weak-voiced, and how shall {listen to me Pharaoh]? 

#### Exodus 7:1 And the LORD said to Moses, saying, Behold, I have made you as a god to Pharaoh, and Aaron your brother will be your prophet. 

#### Exodus 7:2 But you shall speak to him all as much as I give charge to you. But Aaron your brother will speak to Pharaoh, so as to send the sons of Israel from out of his land. 

#### Exodus 7:3 But I will harden the heart of Pharaoh, and I will multiply my signs, and the miracles in the land of Egypt. 

#### Exodus 7:4 And {will not listen to you Pharaoh], and I will put my hand against Egypt, and I will lead out with my power my people the sons of Israel from out of the land of Egypt with {punishment great]. 

#### Exodus 7:5 And {shall know all the Egyptians] that I am the LORD, stretching out my hand against Egypt; and I will lead the sons of Israel from their midst. 

#### Exodus 7:6 {did And Moses and Aaron] just as {gave charge to them the LORD] -- thus they did. 

#### Exodus 7:7 And Moses was {years old eighty], and Aaron was eighty-three years old when they spoke to Pharaoh. 

#### Exodus 7:8 And the LORD said to Moses and Aaron, saying, 

#### Exodus 7:9 And if {should speak to you Pharaoh], saying, Give to us a sign or miracle, then {Aaron shall say your brother], Take the rod and toss it upon the ground before Pharaoh, and before his attendants, and it will be a serpent. 

#### Exodus 7:10 {entered And Moses and Aaron] before Pharaoh, and his attendants. And they did thus, as {gave charge to them the LORD]. And Aaron tossed the rod before Pharaoh, and before his attendants. And it became a serpent. 

#### Exodus 7:11 {called together And the wise men of Egypt Pharaoh], and the sorcerers. And {did also the enchanters of the Egyptians] their sorceries likewise. 

#### Exodus 7:12 And {tossed each] his rod, and they became serpents. And {swallowed down the rod of Aaron] the rods of those men. 

#### Exodus 7:13 And {grew strong the heart of Pharaoh], and he did not listen to them as {said to them the LORD]. 

#### Exodus 7:14 {said And the LORD] to Moses, {is weighed down The heart of Pharaoh] to not send out the people. 

#### Exodus 7:15 You proceed to Pharaoh in the morning! Behold, he will go forth upon the water. And you will be able to meet him upon the edge of the river, and the rod, the one turning into a serpent, take in your hand. 

#### Exodus 7:16 And you shall say to him, The LORD God of the Hebrews has sent me to you, saying, Send out my people! that they may serve to me in the wilderness. And behold, you hearkened not unto this time. 

#### Exodus 7:17 Thus says the LORD, In this you will know that I am the LORD. Behold, I strike with the rod in my hand upon the water in the river, and it will turn into blood. 

#### Exodus 7:18 And the fishes in the river shall come to an end. And {will stink the river], and {will not be able the Egyptians] to drink water from the river. 

#### Exodus 7:19 {said And the LORD] to Moses, Say to Aaron your brother, Take your rod, and stretch out your hand upon the waters of Egypt, and upon their rivers, and upon their aqueducts, and upon their marshes, and upon all {standing water their], and there will be blood in all the land of Egypt, in both the wood vessels and in the stone vessels. 

#### Exodus 7:20 And {did so Moses and Aaron], just as {gave charge to them the LORD]. And Aaron lifting his rod struck the water in the river before Pharaoh, and before his attendants. And {turned all the water in the river] into blood. 

#### Exodus 7:21 And the fishes, the ones in the river came to an end. And {stunk the river]. And {were not able the Egyptians] to drink water from out of the river. And {was the blood] in all the land of Egypt. 

#### Exodus 7:22 {did And likewise also the enchanters of the Egyptians] in their sorceries. And was hardened the heart of Pharaoh, and he did not listen to them, just as the LORD said. 

#### Exodus 7:23 {turned And Pharaoh] to enter into his house, and he did not set his mind neither upon this thing. 

#### Exodus 7:24 {dug And all the Egyptians] round about the river so as to drink water; and they were not able to drink water from the river. 

#### Exodus 7:25 And {were fulfilled seven days] after the LORD struck the river. 

#### Exodus 8:1 {said And the LORD] to Moses, Enter to Pharaoh! And you shall say to him, Thus says the LORD, Send out my people that they may serve me! 

#### Exodus 8:2 But if {should not be willing you] to send, behold, I strike all your boundaries with frogs. 

#### Exodus 8:3 And {will discharge forth the river] frogs. And in ascending, they shall enter into your houses, and into the closets of your bedrooms, and upon your beds, and into the houses of your attendants, and your people, and in your batches of flour, and in your ovens. 

#### Exodus 8:4 And upon you, and upon your people, and upon your attendants {will ascend the frogs]. 

#### Exodus 8:5 {said And the LORD] to Moses, Say to Aaron your brother! Stretch forth in your hand the rod upon the rivers, and upon the aqueducts, and upon the marshes, and lead the frogs! 

#### Exodus 8:6 And Aaron stretched out his hand upon the waters of Egypt, and he led the frogs. And {was brought up the frog], and covered all the land of Egypt. 

#### Exodus 8:7 {did And likewise also the enchanters of the Egyptians] with their sorceries; and they led the frogs upon the land of Egypt. 

#### Exodus 8:8 And Pharaoh called Moses and Aaron, and said, Make a vow for me to the LORD, and remove the frogs from me, and from my people! And I will send the people, and they shall sacrifice to the LORD. 

#### Exodus 8:9 {said And Moses] to Pharaoh, Order for me! when should I make a vow for you, and for your attendants, and your people, to remove from view the frogs from you, and from your people, and from your houses -- except for the ones in the river which shall be left behind? 

#### Exodus 8:10 And he said, During tomorrow. He said therefore, As you have said; that you might see that there is no other besides the LORD. 

#### Exodus 8:11 And {shall be removed the frogs] from you, and from your houses, and from your attendants, and from your people, only the ones in the river will be left behind. 

#### Exodus 8:12 {went forth And Moses and Aaron] from Pharaoh. And Moses yelled out to the LORD concerning the enactment of the frogs, as Pharaoh arranged. 

#### Exodus 8:13 {did And the LORD] just as Moses said, and ended the frogs from the houses, and from the properties, and from the fields. 

#### Exodus 8:14 And they brought them heaps upon heaps, and {stunk the land]. 

#### Exodus 8:15 {seeing And Pharaoh] that there came to pass a respite, {was weighed down therefore his heart], and he did not hearken to them, just as the LORD said. 

#### Exodus 8:16 {said And the LORD] to Moses, Say to Aaron! Stretch out with your hand your rod, and strike the embankment of the land! and there will be midges in all the land of Egypt. 

#### Exodus 8:17 {stretched out Then Aaron with the hand the rod], and he struck the embankment of the earth, and there were the midges among both men and among also the four-footed creatures. And among all embankments of the land there were the midges in all the land of Egypt. 

#### Exodus 8:18 {did And likewise also the enchanters] in their sorceries, to lead out the midge, but they were not able. And there were midges among both men, and among the four-footed creatures. 

#### Exodus 8:19 {said then And the enchanters] to Pharaoh, {the finger of God This is]. And {was hardened the heart of Pharaoh], and he did not listen to them, just as the LORD said. 

#### Exodus 8:20 {said And the LORD] to Moses, Rise early in the morning, and stand before Pharaoh! And behold, he will come forth near the water. And you shall say to him, Thus says the LORD, Send out my people! that they shall serve me in the wilderness. 

#### Exodus 8:21 But if you do not want to send out my people, behold, I will send upon you, and upon your attendants, and upon your people, and upon your houses the dog-fly. And {shall be filled the houses of the Egyptians] with the dog-fly, and into the land upon which they are upon it. 

#### Exodus 8:22 And I will do an incredible thing in that day in the land of Goshen, upon which my people are upon it; upon which there will not be there the dog-fly, that you may know that I am the LORD of all the earth. 

#### Exodus 8:23 And I will make a difference between my people, and between your people. And in the next morning {will be the sign this] upon the land. 

#### Exodus 8:24 {did And the LORD] so. And {came the dog-fly] in multitude in the houses of Pharaoh, and in the houses of his attendants, and in all the land of Egypt. And {was utterly destroyed the land] because of the dog-fly. 

#### Exodus 8:25 {called And Pharaoh] Moses and Aaron, saying, In going, you sacrifice to your God in the land! 

#### Exodus 8:26 And Moses said, It is not possible to be so. For the abominations of the Egyptians we sacrifice to the LORD our God. For if we should sacrifice the abominations of the Egyptians before them, we shall have stones thrown at us. 

#### Exodus 8:27 A journey of three days we shall go into the wilderness, and we shall sacrifice to the LORD our God, just as he told us. 

#### Exodus 8:28 And Pharaoh said, I shall send you, and you sacrifice to the LORD your God in the wilderness! but do not {far away to extend go]! Make a vow then for me to the LORD! 

#### Exodus 8:29 {said And Moses], Behold I will go forth from you, and I will make a vow to God, and {shall go forth the dog-fly] from you, and from your attendants, and from your people tomorrow. You should not add again, O Pharaoh, to deceive completely, to not send out the people to sacrifice to the LORD. 

#### Exodus 8:30 {went forth And Moses] from Pharaoh, and made a vow to God. 

#### Exodus 8:31 {did And the LORD] just as Moses said, and removed the dog-fly from Pharaoh, and from his attendants, and from his people; and he did not leave behind even one. 

#### Exodus 8:32 And Pharaoh was oppressed in his heart also at this time, and he did not want to send out the people. 

#### Exodus 9:1 {said And the LORD] to Moses, Enter to Pharaoh! And you shall say to him, Thus says the LORD God of the Hebrews, Send out my people! that they may serve to me 

#### Exodus 9:2 For if then you do not want to send out my people, but still to have power over them, 

#### Exodus 9:3 behold, the hand of the LORD will be against your cattle in the plains, and against also the horses, and against the beasts of burden, and the camels, and oxen, and sheep, {plague great by an exceedingly]. 

#### Exodus 9:4 And I will do an incredible thing, even I in that time, between the cattle of the Egyptians, and between the cattle of the sons of Israel. And there shall not come to an end of any of the ones of the sons of Israel in particular. 

#### Exodus 9:5 And God gave confirmation, saying, In the next morning the LORD will do this thing upon the land. 

#### Exodus 9:6 And the LORD did this thing in the next day. And there came to an end all the cattle of the Egyptians. But of the cattle of the sons of Israel they did not come to an end -- not one. 

#### Exodus 9:7 {seeing And Pharaoh] that none came to an end from all of the cattle of the sons of Israel -- not one, {was oppressed the heart of Pharaoh], and he did not send out the people. 

#### Exodus 9:8 {spoke And the LORD] to Moses and Aaron, saying, Take with you {full hands] of soot of a furnace! and let Moses strew it into the heaven before Pharaoh, and before his attendants! 

#### Exodus 9:9 And let there become a cloud of dust upon all the land of Egypt! and there will be upon men and upon the four-footed creatures sores of boils breaking out among both men, and among the four-footed creatures, and in all the land of Egypt. 

#### Exodus 9:10 And they took the soot of the furnace before Pharaoh; and {strew it Moses] into the heaven; and there became sores of boils breaking out among both men, and among the four-footed creatures. 

#### Exodus 9:11 And {were not able the sorcerers] to stand before Moses, on account of the sores. {happened For the sores] among the sorcerers, and in all the land of Egypt. 

#### Exodus 9:12 {hardened And the LORD] the heart of Pharaoh, and he did not hearken to them; as the LORD ordered to Moses. 

#### Exodus 9:13 {said And the LORD] to Moses, Rise early in the morning, and stand before Pharaoh! And you shall say to him, Thus says the LORD God of the Hebrews, Send out my people! that they may serve to me. 

#### Exodus 9:14 {in the For] present time I will send out all my events into your heart, and your attendants, and your people, that you might see that there is not another as I in all the earth. 

#### Exodus 9:15 For now, sending my hand, I will strike you; and your people I shall put to death; and I will obliterate you from the earth. 

#### Exodus 9:16 And because of this you were carefully kept, that I might demonstrate in you my strength, and how {should be declared my name] in all the earth. 

#### Exodus 9:17 Still then you cause my people {to not be sent out for them]. 

#### Exodus 9:18 Behold, I rain this hour tomorrow {hail great exceedingly], in which such has not happened in Egypt from which day it was created, and until this day. 

#### Exodus 9:19 Now then hasten to bring together your cattle, and as much as is to you in the plain! For all the men, and the cattle, as much as might be found in the plains, and what might not enter into a residence, {should have fallen and upon them what hail], it will come to an end. 

#### Exodus 9:20 The ones fearing the word of the LORD of the attendants of Pharaoh brought together their cattle into the houses. 

#### Exodus 9:21 And he who did not take heed to the thought unto the word of the LORD, he allowed the cattle to stay in the plains. 

#### Exodus 9:22 {said And the LORD] to Moses, Stretch out your hand unto heaven! and there will be hail upon all the land of Egypt; upon both the men, and the cattle, and upon all pasturage upon the land. 

#### Exodus 9:23 {stretched out And Moses] his hand unto the heaven, and the LORD gave sounds and hail. And {ran across fire] upon the earth. And the LORD rained hail upon all the land of Egypt. 

#### Exodus 9:24 And there was hail, and the fire blazing in the hail. And the hail was great -- exceedingly, in which was there not such in Egypt from when there was {upon it a nation]. 

#### Exodus 9:25 {struck And the hail] in all the land of Egypt -- all as much as was in the plain from man unto beast. And all pasturage in the plain {struck the hail]. And all the trees in the plains broke. 

#### Exodus 9:26 Except in the land of Goshen, of which were there the sons of Israel, there was not hail. 

#### Exodus 9:27 {sending And Pharaoh], called Moses and Aaron, and he said to them, I have sinned now, the LORD is just, but I and my people are impious. 

#### Exodus 9:28 Make a vow then to the LORD, and let {cease to happen the sounds of God], and the hail and fire! And I will send you out, and no longer will I insist for you to remain. 

#### Exodus 9:29 {said And to him Moses], whenever I should go from the city, I will spread forth my hands to the LORD, and the sounds will cease; and the hail and the rain will not be any longer, that you may know that {is of the LORD the earth]. 

#### Exodus 9:30 And you and your attendants -- I know that you do not yet fear the LORD. 

#### Exodus 9:31 And the flax and the barley were struck. For the barley was standing, and the flax was seeding. 

#### Exodus 9:32 And the wheat and the wild oat were not struck, {late for it was]. 

#### Exodus 9:33 {went forth And Moses] from Pharaoh outside of the city, and he spread forth the hands to the LORD, and the sounds ceased, and the hail; and the rain did not drip any longer upon the land. 

#### Exodus 9:34 {seeing And Pharaoh] that {has been ceased the rain], and the hail, and the sounds -- he added to sin. And {was oppressed his heart], and the ones of his attendants. 

#### Exodus 9:35 And {was hardened the heart of Pharaoh], and he did not send out the sons of Israel; just as the LORD said to Moses. 

#### Exodus 10:1 {said And the LORD] to Moses, saying, Enter to Pharaoh! for I oppressed his heart, and the heart of his attendants, that {in a row should come these signs] upon them; 

#### Exodus 10:2 that you may describe them into the ears of your children, and to the children of your children; as much as I mocked the Egyptians, and my signs which I did among them. And you will know that it is I the LORD. 

#### Exodus 10:3 {entered And Moses and Aaron] before Pharaoh, and said to him, Thus says the LORD, the God of the Hebrews, Until when will you not shame me? Send out my people! that they may serve to me. 

#### Exodus 10:4 But if {should not want you] to send out my people, behold, I will bring this in the hour tomorrow -- {locust much] upon all your boundaries. 

#### Exodus 10:5 And {will be covered the appearance of the earth], and you will not be able to look down at the ground, and will be eaten up all the extra being left behind which {left behind for you the hail]. And will be eaten up every tree germinating of yours upon the land. 

#### Exodus 10:6 And I will fill your houses, and the houses of your attendants, and all the houses in all the land of the Egyptians, which at no time have {seen your fathers], nor their forefathers, from which day they were upon the land, until this day. And turning aside he went forth from Pharaoh. 

#### Exodus 10:7 And {say the attendants of Pharaoh] to him, For how long will this be to us an impediment? Send out the men! so that they may serve to the LORD their God. Or {to see do you prefer] that they destroy Egypt? 

#### Exodus 10:8 And {returned both Moses and Aaron] to Pharaoh. And he said to them, Go, and serve to the LORD your God! But which and who are the ones going? 

#### Exodus 10:9 And Moses says, With the young and the older we will go; with our sons, and daughters, and sheep, and our oxen; for it is the holiday of the LORD our God. 

#### Exodus 10:10 And he said to them, Let it be so! The LORD be with you, in so far as I send you; but should also your belongings? See! for wickedness lies near to you. 

#### Exodus 10:11 Not so, let {go forth the men] and serve God! for this they seek after. And they cast them from the face of Pharaoh. 

#### Exodus 10:12 {said And the LORD] to Moses, Stretch out your hand upon the land of Egypt! and let {ascend the locust] upon the land, and it will eat up all the pasturage of the land, and all the fruit of the trees which {left behind the hail]. 

#### Exodus 10:13 And Moses stretched out the rod into the heaven, and the LORD brought {wind the south] upon the land {entire day that] and entire night. In the morning came the {wind south] lifting up the locust, 

#### Exodus 10:14 and it led it upon all the land of Egypt. And it rested upon all the boundaries of Egypt -- many, exceedingly. Prior of them there were not such locust, and after this there will not be so. 

#### Exodus 10:15 And they covered the appearance of the land, and corrupted the land, and ate up all the pasturage of the land, and all the fruit of the trees, which were left behind from the hail. There was not left a green thing, not one thing among the trees, even in all the pasturage of the plain in all the land of Egypt. 

#### Exodus 10:16 {hastened And Pharaoh] to call Moses and Aaron, saying, I have sinned before the LORD your God, and against you. 

#### Exodus 10:17 Favorably receive then my sin still now, and pray to the LORD your God, and remove from me this plague! 

#### Exodus 10:18 {went forth And Moses] from Pharaoh, and made a vow to God. 

#### Exodus 10:19 And the LORD turned {wind from the sea a vehement], and it took up the locust, and cast it into the red sea. And there was not left behind {locust one] in all the land of Egypt. 

#### Exodus 10:20 And the LORD hardened the heart of Pharaoh, and he did not send out the sons of Israel. 

#### Exodus 10:21 {said And the LORD] to Moses, Stretch out the hand into the heaven, and let {become darkness] upon the land of Egypt -- a tangible darkness! 

#### Exodus 10:22 {stretched out And Moses] the hand unto the heaven. And there was darkness, dimness, and a storm upon all the land of Egypt three days. 

#### Exodus 10:23 And not {know did anyone] his brother, and not {rise up did anyone] from his bed for three days. But to all the sons of Israel there was light in all places in which they occupied. 

#### Exodus 10:24 And Pharaoh called Moses and Aaron, saying, Proceed, serve the LORD your God! only the sheep and the oxen leave behind! but {your belongings let] run with you! 

#### Exodus 10:25 And Moses said, But also you shall give us means for whole burnt-offerings and sacrifices which we will make to the LORD our God. 

#### Exodus 10:26 And our cattle shall go with us, and we shall not leave behind a hoof. {of them For] we shall take to serve the LORD our God. But we know not how we shall serve the LORD our God until the arriving of us there. 

#### Exodus 10:27 {hardened But the LORD] the heart of Pharaoh, and he did not want to send them. 

#### Exodus 10:28 And Pharaoh says, Go forth from me! Take heed to yourself yet to add to see my face! for whatever day you should see me, you shall die. 

#### Exodus 10:29 {says And Moses], As you have said, no longer shall I appear to you in person. 

#### Exodus 11:1 {said And the LORD] to Moses, Still one more calamity I will bring upon Pharaoh, and upon Egypt, and after this he will send you from here. And whenever he should send you, {with all your things by expulsion he will cast you]. 

#### Exodus 11:2 You speak then secretly into the ears of the people! And let {ask each man] from the neighbor, and each woman from the neighbor, items of silver and of gold, and clothes! 

#### Exodus 11:3 And the LORD gave favor to his people before the Egyptians, and they treated them. And the man Moses {great became exceedingly] before the Egyptians, and before Pharaoh, and before his attendants. 

#### Exodus 11:4 And Moses said, Thus says the LORD, Around the middle of the night I will enter into the midst of Egypt. 

#### Exodus 11:5 And shall come to an end every first-born in the land of Egypt; from the first-born of Pharaoh, who sits down upon the throne, and unto the first-born of the female attendant by the millstone, and unto the first-born of every beast. 

#### Exodus 11:6 And there will be {cry a great] by all the land of Egypt, in which such as was not, and such as no longer shall be added. 

#### Exodus 11:7 But among all the sons of Israel there shall not growl even a dog with its tongue, from man unto beast; so that you may see as much as {does an incredible thing the LORD] between the Egyptians and Israel. 

#### Exodus 11:8 And {shall descend all these your servants] to me, and shall do obeisance to me, saying, You go forth, and all your people whom you guide! and after these things I will go forth. {went forth And Moses] from Pharaoh with rage. 

#### Exodus 11:9 {said And the LORD] to Moses, {will not listen to you Pharaoh] that I might multiply my signs, and my miracles in the land of Egypt. 

#### Exodus 11:10 And Moses and Aaron did all these miracles in the land of Egypt before Pharaoh. {hardened And the LORD] the heart of Pharaoh, and he did not want to send the sons of Israel out of the land of Egypt. 

#### Exodus 12:1 {said And the LORD] to Moses and Aaron in the land of Egypt, saying, 

#### Exodus 12:2 This month is to you the beginning of months. {the first It is to you] among the months of the year. 

#### Exodus 12:3 Speak to all the gathering of the sons of Israel! saying, The tenth of this month let {take each] a sheep according to the houses of the families! a sheep according to a house. 

#### Exodus 12:4 But if there should be very few in the house, so as for there not to be enough for the sheep, he shall include with himself the neighbor, neighboring him, according to the number of souls, each sufficient for him to be counted for the sheep. 

#### Exodus 12:5 {sheep a perfect male unblemished of a year old It shall be to you]; from the lambs and from the kids you shall take. 

#### Exodus 12:6 And it will be to you for carefully keeping until the fourteenth of this month. And they shall slay it -- all the multitude of the gathering of the sons of Israel towards evening. 

#### Exodus 12:7 And they shall take from the blood, and they shall put it upon the two doorposts, and upon the lintel on the houses in which they should eat them in them. 

#### Exodus 12:8 And they shall eat the meats in this night, roasted by fire; and unleavened breads with bitter herbs they shall eat. 

#### Exodus 12:9 You shall not eat of them raw, nor being boiled in water, but roasted by fire, head with the feet, and the entrails. 

#### Exodus 12:10 You shall not leave anything from it into the morning. And {a bone you shall not break] of it. And the things being left behind from it unto morning, {in fire you shall incinerate]. 

#### Exodus 12:11 And thus shall you eat it -- with your loins girded, and the sandals on your feet, and your staff in your hands; and you shall eat it with haste -- it is the passover of the LORD. 

#### Exodus 12:12 And I shall go through in the land of Egypt in this night, and I shall strike all first-born in the land of Egypt, from man unto beast; and among all the gods of the Egyptians I will execute punishment -- I the LORD. 

#### Exodus 12:13 And {shall be the blood] to you for a sign upon the houses in which you are there; and I will see the blood and shelter you; and there shall not be to you a calamity of the obliteration, whenever I smite in the land of Egypt. 

#### Exodus 12:14 And {shall be this day] to you a memorial. And you shall solemnize it a holiday to the LORD unto your generations; {law an eternal] you shall solemnize it. 

#### Exodus 12:15 Seven days you shall eat unleavened breads. And from the {day first] you shall remove yeast from your houses. All who ever shall eat yeast, {shall be utterly destroyed that soul] from out of Israel; it shall be from the {day first] until {day the seventh]. 

#### Exodus 12:16 And {day the first] shall be called holy. And {day the seventh called holy will be] to you. All {work servile] shall not be done in them, except as much as is necessary to do for every soul, this only shall be done by you. 

#### Exodus 12:17 And you shall guard this commandment. For in this day I will lead your force from out of the land of Egypt. And you shall appoint this day into your generations {law as an eternal]. 

#### Exodus 12:18 Commencing the fourteenth day {month of the first], from evening you shall eat unleavened breads until {day the first and twentieth] of the month, until evening. 

#### Exodus 12:19 For seven days yeast shall not be found in your houses. All whosoever should eat leavened bread, {shall utterly be destroyed that soul] from out of the congregation of Israel, unto both foreigners and native born of the land. 

#### Exodus 12:20 Anything leavened you shall not eat. In every home of yours you shall eat unleavened breads. 

#### Exodus 12:21 {called And Moses] the whole council of elders of Israel. And he said to them, Going forth, take to yourselves a sheep according to your kin, and sacrifice the passover! 

#### Exodus 12:22 But you shall take a bundle of hyssop, and having dipped it from the blood, of the blood by the door, you shall place it on the lintel and upon both of the doorposts, of the blood which is by the door; and you shall not go forth -- each from the door of his house until morning. 

#### Exodus 12:23 And the LORD will go by to strike the Egyptians. And he shall see the blood upon the lintel and upon both of the doorposts. And the LORD will go by the door, and he will not leave off the annihilating so as to enter into your house to strike. 

#### Exodus 12:24 And you shall guard this thing for the law to yourself, and to your sons unto the eon. 

#### Exodus 12:25 And if you should enter into the land which ever the LORD should give to you, in so far as he spoke, you shall guard this service. 

#### Exodus 12:26 And it will be if {should say to you your sons], What is this service? 

#### Exodus 12:27 That you shall say to them, {sacrifice the passover This is] to the LORD, as he sheltered the houses of the sons of Israel in Egypt, when he struck the Egyptians, but our houses he rescued. And bowing, the people did obeisance. 

#### Exodus 12:28 And going forth, {did the sons of Israel] as the LORD gave charge to Moses and Aaron -- so they did. 

#### Exodus 12:29 And it happened in the middle of the night, and the LORD struck all the first-born in the land of Egypt; from the first-born of Pharaoh, of the one sitting upon the throne, unto the first-born of the captive, of the one in the pit, and every first-born of the beast. 

#### Exodus 12:30 And Pharaoh rose up at night, and all his attendants, and all the Egyptians, and there was {cry a great] in all the land of Egypt. {no For there was] house in which there was not one {in it dying]. 

#### Exodus 12:31 And Pharaoh called Moses and Aaron at night, and he said to them, Rise up, and go forth from my people, both you and the sons of Israel! Proceed and serve to the LORD your God! as you say. 

#### Exodus 12:32 And the sheep and the oxen of yours in taking up, go! just as you say; and bless also me! 

#### Exodus 12:33 And {constrained the Egyptians] the people with diligence to cast them from the land; for they said that, We all shall die. 

#### Exodus 12:34 {took And the people] their dough before the leavening of their batches, being bound in their cloaks upon their shoulders. 

#### Exodus 12:35 And the sons of Israel did as {ordered them Moses]. And they asked from the Egyptians items of silver, and of gold, and clothes. 

#### Exodus 12:36 And the LORD gave favor to his people before the Egyptians, and they furnished to them; and they despoiled the Egyptians. 

#### Exodus 12:37 {having departed And the sons of Israel] from out of Rameses into Succoth, to the number of six hundred thousand footmen, the males, besides the belongings, 

#### Exodus 12:38 and {intermixed company a great] went up with them, and sheep and oxen, and cattle -- many exceedingly. 

#### Exodus 12:39 And they baked the dough which they brought from out of Egypt -- {cakes baked in hot ashes unleavened]. {not For it was] leavened, {cast out because them the Egyptians], and they were not able to remain, nor {provisions to prepare] for themselves for the journey. 

#### Exodus 12:40 And the dwelling of the sons of Israel, which they dwelt in the land of Egypt, and in the land of Canaan, they and their fathers -- four hundred thirty years. 

#### Exodus 12:41 And it came to pass after the four hundred and thirty year, came forth all the force of the LORD from out of the land of Egypt. 

#### Exodus 12:42 {a night post It is] to the LORD, so as to lead them from out of the land of Egypt. That night itself is a post to the LORD, so as {to all the sons of Israel to be] into their generations. 

#### Exodus 12:43 {said And the LORD] to Moses and Aaron, This is the law of the passover. Every foreigner shall not eat of it. 

#### Exodus 12:44 And every domestic servant, any which was bought with silver, you shall circumcise him. And then he shall eat of it. 

#### Exodus 12:45 Sojourner or hireling shall not eat of it. 

#### Exodus 12:46 In {house one] it shall be eaten, and you shall not bring forth from the house of any of the meats outside, and {a bone you shall not break] of it. 

#### Exodus 12:47 Every gathering of the sons of Israel shall do it. 

#### Exodus 12:48 And if any {should come forward to you convert], and should observe the passover to the LORD, you shall circumcise {of his every male]. And then he shall come forward to do it. And he will be as also the native born of the land. Every uncircumcised one shall not eat of it. 

#### Exodus 12:49 {law one There shall be] to the native inhabitant, and to the one coming forward to convert among you. 

#### Exodus 12:50 And {did the sons of Israel] as the LORD gave charge to Moses and Aaron to them -- so they did. 

#### Exodus 12:51 And it came to pass in that day the LORD led out the sons of Israel from the land of Egypt with their force. 

#### Exodus 13:1 {said And the LORD] to Moses, saying, 

#### Exodus 13:2 Sanctify to me every first-born, first-born of its kind opening wide every womb among the sons of Israel, from man unto beast -- it is mine. 

#### Exodus 13:3 {said And Moses] to the people, Remember this day in which you came forth from out of Egypt, from out of the house of slavery. For with {hand a fortified led you the LORD] from here, and you shall not eat yeast. 

#### Exodus 13:4 For today you go forth in {month the new]. 

#### Exodus 13:5 And it will be when ever {should bring you the LORD your God] into the land of the Canaanites, and Hittites, and Amorites, and Hivites, and Jebusites, and Gergesites, and Perizzites, which he swore by an oath to your fathers to give to you the land flowing milk and honey, then you shall do this service in this month. 

#### Exodus 13:6 Six days you shall eat unleavened breads, but the {day seventh] is a holiday of the LORD. 

#### Exodus 13:7 Unleavened bread shall you eat seven days. There shall not be seen in you leavened bread, nor shall there be to you yeast in all your boundaries. 

#### Exodus 13:8 And you shall announce to your son in that day, saying, Concerning this {did the LORD God] to me as I went forth from out of Egypt. 

#### Exodus 13:9 And it will be to you for a sign upon your hand, and a memorial before your eyes, that {may be the law of the LORD] in your mouth. For with {hand a fortified led you the LORD] out of Egypt. 

#### Exodus 13:10 And you shall guard this law according to the times of hours, from days to days. 

#### Exodus 13:11 And it shall be whenever {should bring you the LORD your God] into the land of the Canaanites, in which manner he swore by an oath to your fathers, and shall give it to you, 

#### Exodus 13:12 that you shall separate every offspring opening the womb, the males to the LORD, every offspring opening the womb from the herds among your cattle. As many as come to pass to you, the males are to the LORD. 

#### Exodus 13:13 Every newborn opening the womb of donkey you shall barter for sheep. But if you should not barter you shall ransom it. Every first-born of man of your sons you shall ransom. 

#### Exodus 13:14 And if {should ask you your son] about these, saying, What is this? And you shall say to him, that, With {hand a fortified] {led you the LORD] out of the land of Egypt, from out of the house of slavery. 

#### Exodus 13:15 And when he hardened Pharaoh to send us, the LORD slew all the first-born in the land of Egypt, from the first-born of men, unto the first-born of cattle. On account of this I sacrifice to the LORD every offspring opening the womb, the males to the LORD, and every first-born of my sons I will ransom. 

#### Exodus 13:16 And it shall be for a sign upon your hand, and unshaken before your eyes. For by {hand a fortified led you the LORD] out of Egypt. 

#### Exodus 13:17 And as Pharaoh sent out the people, {did not guide them God] in the way of the land of the Philistines, for it was near; {said for God], Lest at any time {should repent the people] seeing war, and they should return into Egypt; 

#### Exodus 13:18 and God circled the people in the way -- the one into the wilderness, to the red sea. And in the fifth generation {ascended the sons of Israel] from out of the land of Egypt. 

#### Exodus 13:19 And Moses took the bones of Joseph with him, for with an oath Joseph bound the sons of Israel, saying, With a visit the LORD will visit you, and you shall join in carrying off my bones from here with you. 

#### Exodus 13:20 {lifted away And the sons of Israel] from out of Succoth, and they encamped in Etham by the wilderness. 

#### Exodus 13:21 But God led them, by day by a column of cloud, to show to them the way; but in the night by a column of fire. 

#### Exodus 13:22 {did not fail The column of cloud] by day, and the column of fire by night before all the people. 

#### Exodus 14:1 And the LORD spoke to Moses, saying, 

#### Exodus 14:2 Speak to the sons of Israel! And turning let them encamp before the property between Migdol and between the sea, right opposite Baal-Zephon! Before them you shall encamp by the sea. 

#### Exodus 14:3 And Pharaoh will say concerning the sons of Israel, These wander in the land, {has closed up for them the wilderness]. 

#### Exodus 14:4 But I will harden the heart of Pharaoh, and he will pursue after them, and I will be glorified by Pharaoh, and by all his military; and {shall know all the Egyptians] that I am the LORD. And they did thus. 

#### Exodus 14:5 And it was announced to the king of the Egyptians that {have fled the people]. And {was converted the heart of Pharaoh], and the hearts of his attendants against the people. And they said, What is this we have done to send out the sons of Israel to not slave to us? 

#### Exodus 14:6 {teamed up then Pharaoh] his chariots, and {all his people he led] with himself. 

#### Exodus 14:7 And he took six hundred {chariots chosen], and all the cavalry of the Egyptians, and tribunes over all. 

#### Exodus 14:8 And the LORD hardened the heart of Pharaoh king of Egypt. And he pursued after the sons of Israel. But the sons of Israel went with {hand a high]. 

#### Exodus 14:9 And {pursued the Egyptians] after them. And they found them camping by the sea. And all the cavalry, and the chariots of Pharaoh, and the horsemen, and his military were before the property right opposite Baal-zephon. 

#### Exodus 14:10 And Pharaoh led forward. And {looking up the sons of Israel] with the eyes, they beheld. And behold, the Egyptians were encamped behind them. And they feared exceedingly. {yelled out And the sons of Israel] to the LORD. 

#### Exodus 14:11 And they said to Moses, Because there were no {existing tombs] in Egypt you led us to be put to death in the wilderness? What is this you did to us bringing us forth from out of Egypt? 

#### Exodus 14:12 {this not Was] the saying which we spoke in Egypt to you? saying, Disregard us! so that we may slave to the Egyptians. For it is better for us to slave to the Egyptians, than to die in this wilderness. 

#### Exodus 14:13 {said And Moses] to the people, Be of courage! Stand, and see the deliverance by the LORD, which he will do for us today! {in which manner For] you see the Egyptians today, you will not proceed still to see them into the eon of time. 

#### Exodus 14:14 The LORD will wage war for us, and you shall be quiet. 

#### Exodus 14:15 {said And the LORD] to Moses, Why do you yell to me? Speak to the sons of Israel, and break camp! 

#### Exodus 14:16 And you, lift up your rod, and stretch out your hand upon the sea, and tear it! And let {enter the sons of Israel] in the midst of the sea on dry land! 

#### Exodus 14:17 And behold, I will harden the heart of Pharaoh, and {the Egyptians all]; and they will enter in after them, and I will be glorified by Pharaoh, and by all his military, and by the chariots, and by his horses. 

#### Exodus 14:18 And {shall know all the Egyptians] that I am the LORD glorifying myself by Pharaoh, and by the chariots, and by his horses. 

#### Exodus 14:19 {lifted away And the angel of God], the one going before the camp of the sons of Israel, and he went at the rear. And lifted away also the column of cloud from their sight, and it stood at the rear of them. 

#### Exodus 14:20 And it entered between the camp of the Egyptians and between the camp of Israel, and it stood. And there was darkness and dimness. And {went by the night]. And they did not mix together one to another the entire night. 

#### Exodus 14:21 {stretched out And Moses] his hand upon the sea. And the LORD drew away the sea by {wind south a violent] the entire night. And he made the sea dry, and cut asunder the water. 

#### Exodus 14:22 And {entered the sons of Israel] in the midst of the sea down on the dry land. And its water was a wall from the right and a wall from the left. 

#### Exodus 14:23 {pursued And the Egyptians]. And {entered after them all the cavalry of Pharaoh], and the chariots, and the riders in the midst of the sea. 

#### Exodus 14:24 And it came to pass in the watch, in the early morning, and the LORD gave attention unto the camp of the Egyptians with a column of fire and a cloud; and he disturbed the camp of the Egyptians. 

#### Exodus 14:25 And he bound the axles of their chariots, and led them with force. And {said the Egyptians], We should flee from the face of Israel, for the LORD wages war for them against the Egyptians. 

#### Exodus 14:26 {said And the LORD] to Moses, Stretch out your hand upon the sea, and restore the water, and cover over the Egyptians, over both the chariots and over the riders! 

#### Exodus 14:27 {stretched out And Moses] his hand upon the sea, and {restored the water] at day to its place. And the Egyptians fled from under the water. And the LORD shook off the Egyptians in the midst of the sea. 

#### Exodus 14:28 And in turning back, the water covered the chariots, and the riders, and all the force of Pharaoh, of the ones entering after them into the sea. And there was not left of them not even one. 

#### Exodus 14:29 And the sons of Israel went through dry land in the midst of the sea. And the water was to them a wall on the right, and a wall on the left. 

#### Exodus 14:30 And the LORD rescued Israel in that day from the hand of the Egyptians. And Israel saw the Egyptians having died by the edge of the sea. 

#### Exodus 14:31 {saw And Israel hand the great] by which the LORD executed against the Egyptians. {feared And the people] the LORD, and they trusted in God, and Moses his attendant. 

#### Exodus 15:1 Then they sang, Moses and the sons of Israel, this ode to the LORD. And they said, We should sing to the LORD, for gloriously he is glorified; horse and rider he tossed into the sea. 

#### Exodus 15:2 Helper and shelterer he became to me for deliverance; this is my God, and I will glorify him; the God of my father, and I will exalt him. 

#### Exodus 15:3 The LORD breaking by wars; the LORD is his name. 

#### Exodus 15:4 The chariots of Pharaoh, and his force he tossed into the sea; chosen riders -- tribunes he sank in the red sea. 

#### Exodus 15:5 A high sea covered them; they descended unto the bottom of the sea as stone. 

#### Exodus 15:6 Your right hand, O LORD, has been glorified in strength; your right hand, O LORD, devastated the enemies. 

#### Exodus 15:7 And in the magnitude of your glory you broke the opponents. You sent your anger, and it devoured them as stubble. 

#### Exodus 15:8 And by the breath of your rage {was parted the water]; {a banked up as] wall were the waters; {were banked up and the waves] in the midst of the sea. 

#### Exodus 15:9 {said The enemy], In pursuing I shall overtake; I shall portion the spoils; I shall fill up my soul; I will take up my sword; {will dominate my hand]. 

#### Exodus 15:10 You sent your breath, {covered them the sea]; they went down as lead in {water vehement]. 

#### Exodus 15:11 Who is likened to you among gods, O LORD? Who is likened to you, being glorified among holy ones, wonderful in glories, doing miracles? 

#### Exodus 15:12 You stretched out your right hand, {swallowed them the earth]. 

#### Exodus 15:13 You guided by your righteousness -- {your people this] whom you ransomed. You aided in your strength in {lodging your holy]. 

#### Exodus 15:14 {heard Nations], and were provoked to anger; pangs took hold of the ones dwelling among the Philistines. 

#### Exodus 15:15 Then hastened the princes of Edom, and the rulers of the Moabites; {took hold of them trembling]; they melted away -- all the ones dwelling in Canaan. 

#### Exodus 15:16 May there fall upon them fear and trembling; by the greatness of your arm they are petrified, until whenever {may go by your people], O LORD, until whenever {may go by your people this], whom you acquired. 

#### Exodus 15:17 Bringing them in -- plant them in {mountain of inheritance your]; into {prepared home your] which you manufactured, O LORD; the sanctuary, O LORD, which you prepared by your hands. 

#### Exodus 15:18 The LORD reigning into the eon, and unto eon, and still! 

#### Exodus 15:19 For {entered the horse of Pharaoh] with chariots and riders into the sea; and {brought upon them the LORD] the water of the sea. But the sons of Israel went through dry land in the midst of the sea. 

#### Exodus 15:20 {took And Miriam the prophetess the sister of Aaron] the tambourine in her hand. And came forth all the women after her with tambourines and dancers. 

#### Exodus 15:21 {led And them Miriam], saying, We should sing to the LORD, for gloriously he glorified himself -- horse and rider he tossed into the sea. 

#### Exodus 15:22 {lifted up And Moses] the sons of Israel from {sea the red], and he led them into the wilderness of Shur. And they went three days in the wilderness, and they did not find water so as to drink. 

#### Exodus 15:23 And they came unto Marah. And they were not able to drink water at Marah, {bitter for it was]. On account of this {was named the name of that place], Bitter. 

#### Exodus 15:24 And {complained the people] unto Moses, saying, What shall we drink? 

#### Exodus 15:25 {yelled And Moses] to the LORD. And {showed to him the LORD] a tree. And he put it into the water, and {was sweetened the water]. There he established with him ordinances and judgments, and there he tested him. 

#### Exodus 15:26 And he said, If you should hear the voice of the LORD your God, and {the things pleasing before him you should do], and you should give ear to his commandments, and you should guard all his ordinances, then every disease which was brought upon the Egyptians, I will not bring upon you. For I am the LORD healing you. 

#### Exodus 15:27 And they came into Elim. And there were there twelve springs of waters, and seventy trunks of palm trees; and they camped there by the waters. 

#### Exodus 16:1 And they departed from Elim, and {came all the congregation of the sons of Israel] unto the wilderness of Sin, which is between Elim and between Sinai. And on the fifteenth day in {month the second] they went forth from the land of Egypt. 

#### Exodus 16:2 {complained All the gathering of the sons of Israel] to Moses and Aaron. 

#### Exodus 16:3 And {said to them the sons of Israel], Ought we died being struck by the LORD in the land of Egypt, whenever we sat at the kettles of the meats, and ate bread loaves in fullness. For you led us into this wilderness to kill all this congregation by hunger. 

#### Exodus 16:4 {said And the LORD] to Moses, Behold, I rain upon you bread loaves from out of the heaven; and {shall come forth the people], and they shall collect together the bread day to day, that I should test them if they shall go by my law or not. 

#### Exodus 16:5 And it will be in {day the sixth], and they shall prepare what ever they should carry in, and it shall be double what ever they should bring according to day by day. 

#### Exodus 16:6 {said And Moses and Aaron] to all the gathering of the sons of Israel, At evening you will know that the LORD led you out of the land of Egypt. 

#### Exodus 16:7 And in the morning you will see the glory of the LORD, in the hearing of your grumbling against God. And we, what are we that you complain against us? 

#### Exodus 16:8 And Moses said, It is in the {giving the LORD] to you in the evening meats to eat, and bread loaves in the morning for fullness, on account of the LORD's hearing your grumbling which you complain against us. But we, what are we? For not {against us your grumbling is], but against God. 

#### Exodus 16:9 {said And Moses] to Aaron, Say to all the congregation of the sons of Israel! Come forward before God! for he has heard your grumbling. 

#### Exodus 16:10 And when Aaron spoke to all the congregation of the sons of Israel, that they turned into the wilderness, and the glory of the LORD appeared in a cloud. 

#### Exodus 16:11 And the LORD spoke to Moses, saying, 

#### Exodus 16:12 I have heard the grumbling of the sons of Israel. Speak to them! saying, Towards evening you shall eat meats, and in the morning you will be filled of bread loaves. And you shall know that I am the LORD your God. 

#### Exodus 16:13 And it was evening. And there ascended the mother-quail, and it covered the camp. And in the morning there was a resting of the dew round about the camp. 

#### Exodus 16:14 And behold, upon the face of the wilderness, a thin thing as coriander -- white, as ice upon the earth. 

#### Exodus 16:15 And seeing it, the sons of Israel said, an other to the other, What is this? {not For they had] known what it was. {said And Moses] to them, This is the bread which the LORD gave to you to eat. 

#### Exodus 16:16 This is the thing which the LORD ordered. Bring together of it each for what is fitting! A homer per head, according to the number of your souls; {each with your tents let] collect together! 

#### Exodus 16:17 And {did so the sons of Israel], and they collected together what was much and what was less. 

#### Exodus 16:18 And measuring with the homer, {was not superabundant the one which had much], and the one which had less had not too less, for each {what was fitting for himself collected together]. 

#### Exodus 16:19 {said And Moses] to them, Let no one leave behind of his into the morning! 

#### Exodus 16:20 And they did not hearken to Moses, but left behind some of it into the morning. And {erupted worms], and it stunk. And {was embittered over them Moses]. 

#### Exodus 16:21 And they collected it together morning by morning, each the fitting thing for himself. And when {warmed through the sun], it melted away. 

#### Exodus 16:22 And it happened in the {day sixth] they collected together the necessary double amount, two homers to the one person. {entered And all the rulers of the congregation], and announced to Moses. 

#### Exodus 16:23 {said And Moses] to them, This word is what the LORD spoke. A Sabbath rest, holy to the LORD is tomorrow. Whatever as much as you should bake -- bake. And whatever as much as you should boil -- boil! And all that being superabundant leave it for reposit for the morning! 

#### Exodus 16:24 And they left of it into the morning, as {ordered them Moses]. And it did not stink, nor {a worm was there] in it. 

#### Exodus 16:25 {said And Moses], You eat it today, for it is a Sabbath to the LORD! Today you shall not find any in a plain. 

#### Exodus 16:26 Six days you shall collect together, but the {day seventh] is a Sabbath, for it shall not be found in it. 

#### Exodus 16:27 And it came to pass on the seventh day, and came forth certain ones from the people to collect together, and they did not find. 

#### Exodus 16:28 {said And the LORD] to Moses, For how long will you not listen to my commandments, and my law? 

#### Exodus 16:29 See! for the LORD gave to you {Sabbath day this]. On account of this he gave to you on the {day sixth] bread loaves for two days. Let {sit down each] in your houses by himself! Not one of you go forth from out of his place during the {day seventh]! 

#### Exodus 16:30 And {observed the Sabbath the people] in the {day seventh]. 

#### Exodus 16:31 And {named it the sons of Israel] -- the name of it, Manna. And it was as the seed of coriander -- white. And the taste of it was as pastry with honey. 

#### Exodus 16:32 {said And Moses], This is the thing which the LORD ordered. Fill the homer of the manna, for reposit for your generations! that they might see the bread which you ate in the wilderness, as {led you the LORD] out of the land of Egypt. 

#### Exodus 16:33 And Moses said to Aaron, Take {jar golden one], and put in it a full homer of manna, and put it aside before God for preservation into your generations! 

#### Exodus 16:34 In which manner the LORD ordered Moses, even {put aside Aaron it] before the testimony for preservation. 

#### Exodus 16:35 And the sons of Israel ate the manna {years forty], until they came into the land to be lived in. {the manna They ate] until they came into a part of Phoenicia. 

#### Exodus 16:36 Now the homer {the tenth of three measures was]. 

#### Exodus 17:1 And {departed all the congregation of the sons of Israel] from out of the wilderness of Sin, according to their camps, through the saying of the LORD. And they camped in Rephidim. {there was no But] water for the people to drink. 

#### Exodus 17:2 And {reviled the people] against Moses, saying, Give to us water! that we may drink. And {said to them Moses], Why do you revile me? And why do you test the LORD? 

#### Exodus 17:3 {thirsted And there the people] for water. And {complained the people] against Moses, saying, Why is this that you hauled us from out of Egypt to kill us, and our children, and the cattle by thirst? 

#### Exodus 17:4 {yelled And Moses] to the LORD, saying, What should I do with this people? Yet in a little while and they will cast stones at me. 

#### Exodus 17:5 And the LORD said to Moses, Go before this people! and take with yourself some of the elders of the people, and the rod in which you struck the river! Take it in your hand and go! 

#### Exodus 17:6 Behold, I stand there, before your coming upon the rock in Horeb. And you shall strike the rock, and shall come forth from out of it water, and {shall drink the people]. {did And Moses] thus before the sons of Israel. 

#### Exodus 17:7 And he named the name of that place -- Test and Reviling; on account of the reviling of the sons of Israel, and on account of the testing the LORD, saying, Is the LORD with us or not? 

#### Exodus 17:8 {came And Amalek] and waged war against Israel in Rephidim. 

#### Exodus 17:9 {said And Moses] to Joshua, Choose for yourself {men mighty], and going forth deploy against Amalek tomorrow! And behold, I shall stand upon the top of the hill, and the rod of God in my hand. 

#### Exodus 17:10 And Joshua did as {told to him Moses]. And going forth he deployed against Amalek. And Moses and Aaron and Hur ascended upon the top of the hill. 

#### Exodus 17:11 And it happened whenever Moses lifted up the hands, Israel grew strong. But whenever he lowered his hands, Amalek grew strong. 

#### Exodus 17:12 And the hands of Moses became heavy. And taking a stone they placed it under him, and he sat down upon it. And Aaron and Hur supported his hands; here one and there one. And {were the hands of Moses] supported until the descent of the sun. 

#### Exodus 17:13 And Joshua routed Amalek, and all his people by a carnage of the sword. 

#### Exodus 17:14 {said And the LORD] to Moses, Write this for a memorial in a scroll, and put it unto the ears of Joshua! For as ointment I will wipe away the memorial of Amalek from under heaven. 

#### Exodus 17:15 And Moses built an altar to the LORD, and named the name of it, The LORD My Refuge, 

#### Exodus 17:16 for with {hand a hidden] the LORD wages war against Amalek from generations unto generations. 

#### Exodus 18:1 {heard And Jethro the priest of Midian the father-in-law of Moses] all as much as the LORD did to Israel, to his own people; {led for the LORD] Israel out of Egypt. 

#### Exodus 18:2 {took And Jethro the father-in-law of Moses] Zipporah the wife of Moses after her release, 

#### Exodus 18:3 and the two sons of his -- the name to the one was Gershom, saying, I was a sojourner in {land an alien]. 

#### Exodus 18:4 And the name of the second was Eliezer, saying, For the God of my father is my helper, and he rescued me from out of the hand of Pharaoh. 

#### Exodus 18:5 And came forth Jethro, the father-in-law of Moses, and the sons, and the wife, to Moses, into the wilderness of which place he camped at the mountain of God. 

#### Exodus 18:6 And it was announced to Moses, saying, Behold, your father-in-law Jethro comes to you, and your wife, and {two sons your] with him. 

#### Exodus 18:7 {came forth And Moses] to meet with his father-in-law; and he did obeisance to him, and he kissed him, and they greeted one another, and he brought them into the tent. 

#### Exodus 18:8 And Moses described to his father-in-law all as much as the LORD did to Pharaoh, and to the Egyptians, on account of Israel; and all the trouble, the one coming to them in the way; and that {rescued them the LORD] from out of the hand of Pharaoh, and from out of the hand of the Egyptians. 

#### Exodus 18:9 {was amazed And Jethro] by all the good things which {did to them the LORD]; that {rescued them the LORD] from out of the hand of the Egyptians, and from out of the hand of Pharaoh. 

#### Exodus 18:10 And Jethro said, Blessed be the LORD, for he rescued his people from out of the hand of the Egyptians, and from out of the hand of Pharaoh. 

#### Exodus 18:11 Now I know that the LORD is great above all the gods, because of of this -- that they made an attempt against them. 

#### Exodus 18:12 And {took Jethro the father-in-law of Moses] whole burnt-offerings, and sacrifices to God. {came For Aaron and all the elders of Israel] to eat bread with the father-in-law of Moses before God. 

#### Exodus 18:13 And it came to pass after the next day, Moses sat down to judge the people, {stood by and all the people] Moses from morning until evening. 

#### Exodus 18:14 And Jethro seeing all as much as he did to the people, says, What is this which you do to the people? Why do you sit down alone, and all the people stand by you from morning until afternoon? 

#### Exodus 18:15 And Moses says to his father-in-law, Because {come to me the people] to seek after a judgment from God. 

#### Exodus 18:16 For whenever there is to them a dispute, and they should come to me, I litigate each, and I instruct them in the orders of God, and his law. 

#### Exodus 18:17 {said And the father-in-law] to Moses to him, Not rightly do you do this thing. 

#### Exodus 18:18 {corruption will be corrupted in unsufferable And you], and all this people, which is with you. {is heavy on you This thing], you will not be able to act yourself alone. 

#### Exodus 18:19 Now then hear me! and I shall advise you, and God will be with you. You become to the people, the one before God! and you shall offer their words to God. 

#### Exodus 18:20 And you shall testify to them the orders of God, and his law, and you shall signify to them the ways in which they shall go by them, and the works which they shall do. 

#### Exodus 18:21 And you yourself look about all the people for men mighty and godly! {men just] detesting pride. And you shall place them over them commanders of thousands, and commanders of hundreds, and commanders of fifties, and commanders of tens. 

#### Exodus 18:22 And they shall judge the people at every hour. But the {thing enormous] they shall offer unto you; but the little matters of the judgments, they shall judge them; and they shall lighten the load from you, and shall give aid to you. 

#### Exodus 18:23 If this thing you do, then {will strengthen you God], and you will be able to stand, and all this people shall come unto their own place with peace. 

#### Exodus 18:24 {hearkened And Moses] to the voice of his father-in-law, and he did as much as he said to him. 

#### Exodus 18:25 And Moses chose {men mighty] from all Israel, and appointed them over them as commanders of thousands, and commanders of hundreds, and commanders of fifties, and commanders of tens, and judicial recorders. 

#### Exodus 18:26 And they judged the people every hour, but the {matter enormous] they offered to Moses. But every {matter light] they judged themselves. 

#### Exodus 18:27 {sent out And Moses] his own father-in-law, and he went forth unto his land. 

#### Exodus 19:1 And in the {month third] of the exodus of the sons of Israel from the land Egypt, on this day they came into the wilderness of Sinai. 

#### Exodus 19:2 And they lifted away from Rephidim, and came into the wilderness of Sinai, and {camped there Israel] over against the mountain. 

#### Exodus 19:3 And Moses ascended into the mountain of God. And {called him God] from the mountain, saying, Thus you shall say to the house of Jacob, and announce to the sons of Israel, 

#### Exodus 19:4 {to them You have seen as much as I have done] -- to the Egyptians. And I took you as upon wings of eagles, and led you to myself. 

#### Exodus 19:5 And now, if in hearing, you should hear my voice, and guard my covenant, you will be to me {people a prized] from all the nations. {mine For is all the earth]. 

#### Exodus 19:6 And you shall be to me a royal priesthood, and {nation a holy]. These words you shall say to the sons of Israel. 

#### Exodus 19:7 {came And Moses], and called the elders of the people, and placed near them all these words which {gave orders to them God]. 

#### Exodus 19:8 {answered And all the people] with one accord, and said, All, as much as God said, we shall do, and we shall hearken. {offered And Moses] the words of the people to God. 

#### Exodus 19:9 {said And the LORD] to Moses, Behold, I come to you in a column of cloud, that {may hear the people] me speaking to you, and may trust you into the eon. {announced And Moses] the words of the people to the LORD. 

#### Exodus 19:10 {said And the LORD] to Moses, In going down, testify to the people, and purify them today and tomorrow, and let them wash their garments! 

#### Exodus 19:11 And let them be prepared for {day the third]! For {day on the third shall come down the LORD] upon mount Sinai before all the people. 

#### Exodus 19:12 And you shall separate the people round about, saying, Take heed to yourselves ascending unto the mountain, and {lightly touching any] of it. All touching the mountain, by death he will come to an end. 

#### Exodus 19:13 {shall not touch it His hand], for with stones they shall be stoned or with an arrow they shall be shot; if it be also cattle, or if it be also man, he shall not live. And whenever the voices, and the trumpets, and the cloud go forth from the mountain, they shall ascend to the mountain. 

#### Exodus 19:14 {went down And Moses] from the mountain to the people, and sanctified them. And they washed their garments. 

#### Exodus 19:15 And he said to the people, Be prepared three days, come forward not to a woman. 

#### Exodus 19:16 And it came to pass {day on the third], happening towards dawn, and there were voices, and lightnings, and {clouds overcast] upon mount Sinai; the voice of the trumpet sounded greatly, and {were terrified all the people in the camp]. 

#### Exodus 19:17 And Moses led the people for a meeting with God from the camp. And they stood by the mountain. 

#### Exodus 19:18 The mount Sinai smoked entirely on account of God coming down upon it in fire. {ascended And the smoke] as smoke of a furnace. And {amazed all the people were exceedingly]. 

#### Exodus 19:19 And there were the sounds of the trumpet advancing strong -- exceedingly. Moses spoke, and God answered to him by voice. 

#### Exodus 19:20 {came down And the LORD] upon mount Sinai, upon the top of the mountain. And the LORD called Moses unto the top of the mountain; and Moses ascended. 

#### Exodus 19:21 And God said to Moses, saying, Go down to testify to the people! lest at any time they should approach to God to contemplate, and {should fall of them a multitude]. 

#### Exodus 19:22 And the priests, the ones approaching to the LORD God, let them be sanctified! lest at any time {should get rid of them the LORD]. 

#### Exodus 19:23 And Moses said to God, {shall not be able the people] to ascend to mount Sinai, for you testified to us, saying, Separate from the mountain and sanctify it! 

#### Exodus 19:24 {said And to him the LORD], Proceed, go down, and then ascend, you and Aaron with you! But the priests and the people shall not use force to ascend to God, lest at any time {should destroy some of them the LORD]. 

#### Exodus 19:25 {went down And Moses] to the people, and spoke to them. 

#### Exodus 20:1 And the LORD spoke all these words, saying, 

#### Exodus 20:2 I am the LORD your God, the one leading you from the land of Egypt, from out of the house of slavery. 

#### Exodus 20:3 There shall not be to you other gods besides me. 

#### Exodus 20:4 You shall not make to yourself an idol, nor any representation, as much as is in the heaven upward, nor as much as is in the earth below, nor as much as is in the waters underneath the earth. 

#### Exodus 20:5 You shall not do obeisance to them, nor shall you serve to them. For I am the LORD your God, a jealous God, rendering sins of fathers upon children unto the third and fourth generation to the ones detesting me; 

#### Exodus 20:6 and having mercy to thousands loving me, and guarding my orders. 

#### Exodus 20:7 You shall not take the name of the LORD your God in vain. For no way shall the LORD cleanse the one taking his name in vain. 

#### Exodus 20:8 Remember the day of the Sabbaths to sanctify it! 

#### Exodus 20:9 Six days you shall work, and shall do all your works; 

#### Exodus 20:10 but the {day seventh] is a Sabbath to the LORD your God. You shall not do on it any work -- you, and your son, and your daughter, your servant, and your maidservant, your ox, and your beast of burden, and all your cattle, and the convert -- the one sojourning among you. 

#### Exodus 20:11 For in six days the LORD made the heaven, and the earth, and the sea, and all the things in them. And he rested on the {day seventh]. Because of this the LORD blessed the {day seventh], and sanctified it. 

#### Exodus 20:12 Esteem your father and your mother! that good should happen to you, and that {a long time you may be] upon the {earth good] which the LORD your God gives to you. 

#### Exodus 20:13 You shall not murder. 

#### Exodus 20:14 You shall not commit adultery. 

#### Exodus 20:15 You shall not steal. 

#### Exodus 20:16 You shall not witness falsely against your neighbor {witness as a lying]. 

#### Exodus 20:17 You shall not covet the wife of your neighbor. You shall not covet the house of your neighbor, nor his field, nor his manservant, nor his maidservant, nor his ox, nor his beast of burden, nor any of his beasts, nor as much {to your neighbor is]. 

#### Exodus 20:18 All the people perceived the voice, and the lamps, and the sound of the trumpet, and the mountain smoking. And fearing, all the people stood afar off. 

#### Exodus 20:19 And they said to Moses, You speak to us, and do not let {speak to us God]! lest we might die. 

#### Exodus 20:20 And {says to them Moses], Be of courage! because {to test you came God to you], so that there might be the fear of him in you, that you should not sin! 

#### Exodus 20:21 {stood And all the people] afar off. But Moses entered into the dimness where God was. 

#### Exodus 20:22 {said And the LORD] to Moses, Thus shall you say to the house of Jacob, and announce to the sons of Israel, You have seen that from out of the heaven I have spoken to you. 

#### Exodus 20:23 You shall not make to yourselves gods of silver, and gods of gold; you shall not make them to yourselves. 

#### Exodus 20:24 An altar from out of the earth you shall make to me, and you shall sacrifice upon it your whole burnt-offerings, and your deliverance offerings -- the sheep, and your calves, in every place of which ever I should name my name there. And I will come to you, and I will bless you. 

#### Exodus 20:25 And if {an altar of stones you should make] to me, you shall not build them cut into shape; for {your knife you have put] upon them, and they are defiled. 

#### Exodus 20:26 You shall not ascend by stairs unto my altar, so that you should not uncover your indecency upon it. 

#### Exodus 21:1 And these are the ordinances which you shall place before them. 

#### Exodus 21:2 If you should acquire {servant a Hebrew], {six years he shall serve to you], but the seventh year you shall send him free without charge. 

#### Exodus 21:3 If he alone should enter, also alone he shall go forth; but if a wife should enter together with him, also the wife shall go out together with him. 

#### Exodus 21:4 And if the master should give to him a wife, and she should bear to him, sons and daughters, the wife and the children shall be his masters, and he alone shall go forth by himself. 

#### Exodus 21:5 And if responding {should have said the servant], I have loved my master, and my wife, and the children; I do not run free. 

#### Exodus 21:6 {shall lead him Then his master] to the judgment seat of God, and then lead him to the door, unto the doorpost. And {shall make a hole in his master] the ear with the shoemaker's awl, and he shall serve to him into the eon. 

#### Exodus 21:7 But if any should give over his own daughter as a domestic servant, she shall not go forth as {run forth the maidservants]. 

#### Exodus 21:8 If she should not be well-pleasing to her master, who did not solemnly promise her; on payment of ransom he shall release her; {nation but to an alien not the master is to sell her], for he disrespected her. 

#### Exodus 21:9 And if to his son he solemnly promised her, according to the ordinance of the daughters he shall commit to her. 

#### Exodus 21:10 And if {another woman he should take] to himself, the things necessary, and the clothes, and her companionship he shall not deprive. 

#### Exodus 21:11 And if these three things he should not do for her, she shall go forth freely, without paying money. 

#### Exodus 21:12 And if any should strike any, and he should die, to death let him be put to death! 

#### Exodus 21:13 But if it be done not willingly, but God delivered up into his hands, I will give to you a place in which he shall flee there -- the one man-slaying. 

#### Exodus 21:14 But if any should set against the neighbor to kill him by treachery, and should take refuge; {from my altar you shall take him] to be put to death. 

#### Exodus 21:15 Whoever beats his father or his mother, to death he should be put to death. 

#### Exodus 21:16 The one speaking evil of his father or his mother, to death let him come to an end! 

#### Exodus 21:17 Who ever should steal any of any one of the sons of Israel, and tyrannizing him, should give him over, and should be found with him, to death let him come to an end! 

#### Exodus 21:18 And if {revile each other two men], and one should strike the neighbor with a stone or fist, and he should not die, but lies down upon the bed; 

#### Exodus 21:19 if in arising, the man should walk outside upon his cane, {will be innocent the one striking]; except {for his idleness he shall pay], and the physician's fee. 

#### Exodus 21:20 But if any strike his servant or his maidservant with a rod, and one should die by his hand, with punishment let him be punished! 

#### Exodus 21:21 And if the one should continue to live {day one] or two, he shall not be punished, for {his money he is]. 

#### Exodus 21:22 And if {should do combat two men], and should strike a woman {in the womb having one], and should come forth her child not completely formed, with a fine he shall be penalized, in so far as {should put upon him the husband of the woman], and he shall give by means of what is fit. 

#### Exodus 21:23 And if {completely formed it should be], he shall give life for life, 

#### Exodus 21:24 eye for eye, tooth for tooth, hand for hand, foot for foot, 

#### Exodus 21:25 burning for burning, wound for wound, stripe for stripe. 

#### Exodus 21:26 And if any should strike the eye of his man-servant, or the eye of his female attendant, and he should blind; {free he shall send them] on account of their eye. 

#### Exodus 21:27 And if the tooth of the man-servant, or the tooth of his female attendant he should knock out; {free he shall send them] on account of their tooth. 

#### Exodus 21:28 And if {should gore a bull] a man or woman, and either die; with stones you shall stone the bull, and you shall not eat of its meats; but the owner of the bull shall be innocent. 

#### Exodus 21:29 But if the bull {goring was] before yesterday and before the third day before, and men testified to its owner, and he should not remove it; and if it should have done away with a man or a woman, they shall stone the bull, and the owner of it shall die in addition. 

#### Exodus 21:30 And if ransoms should be put to him, he shall give ransoms for the life of it, as much as should be put upon him. 

#### Exodus 21:31 And if a son or daughter should be gored, according to this ordinance they shall observe it. 

#### Exodus 21:32 And if {a manservant should have gored the bull] or a maidservant, {of silver thirty double-drachmas he shall give] to their owner, and the bull shall be stoned. 

#### Exodus 21:33 And if any should open a pit, or a quarry pit, and should not cover it, and {should fall in there a calf or donkey], 

#### Exodus 21:34 the owner of the pit shall pay; {money he shall give] to their owner, and the animal coming to an end will be his. 

#### Exodus 21:35 And if {should gore any bull] the bull of the neighbor, and it should come to an end, they shall give over {bull for sale the living], and divide the money from it, and the bull having died they shall divide. 

#### Exodus 21:36 And if it is made known {the bull that given to goring is] before yesterday and before the third day, and {have been testifying they should] to its owner, and he did not remove it, he shall pay bull for bull, but the bull coming to an end will be his. 

#### Exodus 22:1 And if any should steal a calf or a sheep, and should slay it, or should sell it, {five calves he shall pay] for the calf, and four sheep for the sheep. 

#### Exodus 22:2 And if {in the ditch should be found the thief], and being struck should die, it is not murder to him striking. 

#### Exodus 22:3 But if the sun should rise upon him, he is liable, he shall die for it; and if there be no possessions to him, let him be sold for the theft. 

#### Exodus 22:4 And if anything should be left and should be found in his hand from the theft, from both donkey unto sheep which may be living, {double for it he shall pay]. 

#### Exodus 22:5 And if any should graze upon a field or a vineyard, and should let his cattle graze upon {field another], he shall pay from his field according to his produce; but if all the field should be grazed upon, {best field from his and best vineyard from his he shall pay]. 

#### Exodus 22:6 And if {going forth a fire] should find thorn-bushes, and should set on fire a threshing-floor, or corn, or a field, {shall pay the one the fire burning with]. 

#### Exodus 22:7 And if any should give to his neighbor silver or items to guard, and it should be stolen from out of the house of the man, if {should be found the one stealing] he shall pay double. 

#### Exodus 22:8 But if {should not be found the one stealing], {shall come forward the master of the house] before God, and shall swear by an oath that assuredly he did not do wickedly regarding all that was in deposit for the care of his neighbor. 

#### Exodus 22:9 According to every particular offence, concerning both calf, and beast of burden, and sheep, and garment, and every destruction being accused, the one who then should be, before God {shall come the judgment of both], then the one convicted by God shall pay double to his neighbor. 

#### Exodus 22:10 And if any should give to the neighbor a beast of burden, or a calf, or sheep, or any cattle to guard; and it should break, or come to an end, or {captive become], and no one should know, 

#### Exodus 22:11 there shall be an oath of God between both, swearing that assuredly he had not done wickedly to partake altogether of the deposit put in care by his neighbor, and thus {shall receive him favorably his owner], and he shall not pay. 

#### Exodus 22:12 And if it be stolen from him, he shall pay the owner of it. 

#### Exodus 22:13 And if {taken by wild beasts it should be], he shall lead him to the game, and he shall not pay. 

#### Exodus 22:14 And if anyone should ask to borrow from his neighbor, and it should break, or die, or {captive become], and the owner of it should not be with it, he shall pay. 

#### Exodus 22:15 But if its owner should be with it, he shall not pay. But if a hireling should be with it, it will be to him for his wage. 

#### Exodus 22:16 And if any should beguile a virgin not betrothed, and should go to bed with her, {with a dowry he shall endow her to himself as a wife]. 

#### Exodus 22:17 But if in shaking he shakes his head in dissent, and {should not be willing her father] to give her to him as wife, {silver he shall pay to the father], according to as much as is the dowry of the virgins. 

#### Exodus 22:18 {administers of potions You shall not procure]. 

#### Exodus 22:19 Every one going to bed with a beast -- to death you shall kill them. 

#### Exodus 22:20 The one sacrificing to gods shall be utterly destroyed, except to the LORD alone. 

#### Exodus 22:21 And {a foreigner you shall not maltreat], nor should you afflict him, for you were foreigners in the land of Egypt. 

#### Exodus 22:22 Every widow and orphan you shall not maltreat. 

#### Exodus 22:23 And if you should maltreat them, and crying out they should yell out to me, in hearing I shall listen to their yell, 

#### Exodus 22:24 and I shall be provoked to anger with rage, and I will kill you by the sword, and {will be your wives] widows, and your children orphans. 

#### Exodus 22:25 And if money should be lent with interest to the brother that is destitute close to you, you shall not be coercing him, you shall not place {upon him interest]. 

#### Exodus 22:26 And if for collateral you should take for security the cloak of your neighbor, before the descent of the sun you shall give it back to him, 

#### Exodus 22:27 {is for this] his wrap-around garment, this alone is {cloak for indecency his]; in what manner shall he go to bed? If then he should yell out to me, I will listen to him, {merciful for I am]. 

#### Exodus 22:28 {magistrates You shall not speak evil of], and rulers of your people you shall not speak wickedly. 

#### Exodus 22:29 {first-fruits of the threshing-floor and wine vat of your You shall not be late]. {first-born son Your] you shall give to me -- 

#### Exodus 22:30 so shall you do with your calf, and your sheep, and your beast of burden. Seven days it shall be under the mother, but {day the eighth] you shall give {back to me it]. 

#### Exodus 22:31 And {men holy you shall be] to me, and meat in a field taken by wild beasts you shall not eat, {to the dogs throw it away]! 

#### Exodus 23:1 You shall not welcome {report a vain]. You shall not assent together with the unjust to become {witness an unjust]. 

#### Exodus 23:2 You shall not be with many people for evil. You shall not be added with a multitude to turn aside a judgment. 

#### Exodus 23:3 And {because one is needy you shall not show mercy in a judgment]. 

#### Exodus 23:4 And if you should meet up with the ox of your enemy, or with his beast of burden wandering, by returning, you shall give it back to him. 

#### Exodus 23:5 And if you should see the beast of burden of your enemy falling under its load of merchandise, you shall not go by it, but you shall raise it with him. 

#### Exodus 23:6 You shall not turn aside a judgment of the needy in his judgment. 

#### Exodus 23:7 From all things unjust you shall abstain. The innocent and the just you shall not kill. And you shall not give justice to the impious because of bribes. 

#### Exodus 23:8 And bribes you shall not receive; for the bribes blind the eyes for seeing and lay waste {matters just]. 

#### Exodus 23:9 And a foreigner you shall not maltreat, nor in any way afflict. For you know the soul of the foreigner, for you yourselves were foreigners in the land of Egypt. 

#### Exodus 23:10 Six years you shall sow your land, and you shall gather its produce, 

#### Exodus 23:11 but on the seventh {a release from work you shall make], and spare it, and {shall eat the poor of your nation]; and the things being left behind of them {shall eat the wild beasts] of the field. Thus you shall do with your vineyard, and your olive grove. 

#### Exodus 23:12 Six days you shall do your works, but on the {day seventh] you shall rest, that {may rest ox your], and your beast of burden, and that {may be refreshed the son of your maidservant], and the foreigner. 

#### Exodus 23:13 All, as much as I have spoken to you, guard! And the name {gods of other] you shall not call to mind, nor should one be heard from out of your mouth. 

#### Exodus 23:14 Three times of the year solemnize a holiday to me! 

#### Exodus 23:15 The holiday of the unleavened breads keep to do! Seven days you shall eat unleavened breads, just as I gave charge to you, according to the time of the month of the new produce; for in it you came forth from out of Egypt. You shall not appear before me empty. 

#### Exodus 23:16 And a holiday of the harvest of the first produce you shall observe of your works, what ever you sow in your field; and a holiday of completion at the conclusion of the year in the gathering of your works, of the ones from out of your field. 

#### Exodus 23:17 Three times a year {shall appear every male of yours] before the LORD your God. 

#### Exodus 23:18 For whenever I should cast out the nations from your face, and widen your boundaries, you shall not sacrifice with yeast the blood of my sacrifice, neither shall {remain through the night the fat of my holiday feast] until morning. 

#### Exodus 23:19 The first-fruits of the first produce of your land you shall carry into the house of the LORD your God. You shall not boil a lamb in {milk her mother's]. 

#### Exodus 23:20 And behold, I send my messenger before your face, that he may guard you in the way, that he may bring you into the land which I prepared for you. 

#### Exodus 23:21 Take heed to yourself, and hearken to him, and do not resist his persuasion, for he should not avoid you, for my name is upon him! 

#### Exodus 23:22 If in hearing you shall hearken to my voice, and do all as much as I give charge to you, I will be an enemy to your enemies, and I will be an adversary to the ones being an adversary of you. 

#### Exodus 23:23 {shall go For my messenger] leading you; and he will bring you to the Amorite, and Hittite, and Perizzite, and Canaanite, and Gergesite, and Hivite, and Jebusite; and I will obliterate them. 

#### Exodus 23:24 You shall not do obeisance to their gods, nor shall you serve to them. You shall not do according to their works; but by demolition you shall demolish them, and by breaking you shall break their monuments. 

#### Exodus 23:25 And you shall serve to the LORD your God; and I will bless your bread, and your wine, and your water; and I will turn infirmity from you. 

#### Exodus 23:26 It will not be barren nor sterile upon your land; the number of your days I will fill up. 

#### Exodus 23:27 And the fear of me I will send leading before you; and I will startle all the nations into which you enter into them; and I will give over all your opponents unto exiles. 

#### Exodus 23:28 And I will send the swarms of wasps in front of you. And I will cast out the Amorites, and the Hivites, and the Canaanites, and the Hittites from you. 

#### Exodus 23:29 I will not cast them from your face in {year one], that {should not become the land] wilderness, and many {should happen upon you wild beasts] in the land. 

#### Exodus 23:30 According to little by little I will cast them from you, until whenever you should grow and be heir to the land. 

#### Exodus 23:31 And I will establish your boundaries from the red sea unto the sea of the Philistines; and from the wilderness unto the river of the great Euphrates. And I will deliver up into your hands the ones lying in wait in the land; and I will cast them from you. 

#### Exodus 23:32 You shall not assent together with them, and with their gods you shall not establish a covenant. 

#### Exodus 23:33 And they shall not lie in wait in your land, lest {you to sin they should cause] against me; for if you should be a slave to their gods, these will be to you an occasion for stumbling. 

#### Exodus 24:1 And to Moses he said, Ascend to the LORD, you and Aaron and Nadab and Abihu, and seventy of the elders of Israel! And they shall do obeisance far off to the LORD. 

#### Exodus 24:2 And Moses shall approach alone to God, but they shall not approach, and the people shall not go up with them. 

#### Exodus 24:3 {entered And Moses] and described to the people all the words of God, and the ordinances. {answered And all the people voice in one], saying, All the words which the LORD spoke, we will do, and we will hearken. 

#### Exodus 24:4 And Moses wrote down all the words of the LORD. {rising early And Moses] in the morning built an altar by the mountain, and with twelve stones for the twelve tribes of Israel. 

#### Exodus 24:5 And he sent out the young men of the sons of Israel, and they offered whole burnt-offerings, and they sacrificed a sacrifice of deliverance to God -- of young calves. 

#### Exodus 24:6 {taking And Moses] half of the blood, poured it into a basin; and the other half of the blood he poured upon the altar. 

#### Exodus 24:7 And taking the scroll of the covenant, he read into the ears of the people. And they said, All as much as the LORD spoke we shall do, and we shall hearken to. 

#### Exodus 24:8 {taking And Moses] the blood, he scattered it upon the people, and said, Behold, the blood of the covenant of which the LORD ordained for you concerning all these words. 

#### Exodus 24:9 And Moses ascended and Aaron and Nadab and Abihu, and seventy of the elders of Israel. 

#### Exodus 24:10 And they saw the place where {stood the God of Israel]. And the things under his feet were as {work a brick] of sapphire; and as the form of firmament of the heaven in the cleanliness. 

#### Exodus 24:11 And of the chosen ones of Israel, none dissented -- not one. And they appeared in the place of God, and ate and drank. 

#### Exodus 24:12 And the LORD said to Moses, Ascend to me unto the mountain, and you be there! And I will give to you the {writing-tablets stone] of the law, and the commandments which I wrote to establish law to them. 

#### Exodus 24:13 And Moses rising up, and Joshua the one standing beside him, they ascended into the mountain of God. 

#### Exodus 24:14 And {to the elders they said], Be still here until we return to you! And behold, Aaron and Hur are with you. If anyone should come for a judgment, let them go to them! 

#### Exodus 24:15 And Moses ascended into the mountain, and {covered the cloud] the mountain. 

#### Exodus 24:16 And {came down the glory of God] upon mount Sinai, and {covered it the cloud] six days. And the LORD called Moses on the {day seventh] from out of the midst of the cloud. 

#### Exodus 24:17 And the sight of the glory of the LORD was as fire blazing upon the top of the mountain before the sons of Israel. 

#### Exodus 24:18 And Moses entered in the midst of the cloud, and ascended unto the mountain, and was there in the mountain forty days and forty nights. 

#### Exodus 25:1 And the LORD spoke to Moses, saying, 

#### Exodus 25:2 Speak to the sons of Israel! And take to me first-fruits of all the things which seem good in the heart! You shall take the first-fruits of mine. 

#### Exodus 25:3 And this is the first-fruit which you shall take of them -- gold, silver, brass, 

#### Exodus 25:4 blue, purple, scarlet doubled up, and linen being twined, and hairs of goats, 

#### Exodus 25:5 and skins of rams being dyed red, and skins of blue, and {wood incorruptible], 

#### Exodus 25:6 and oil for the giving light, incenses for the oil of the anointing, and for the composition of the incense, 

#### Exodus 25:7 and stones of sardius, and stones for the carving for the shoulder-piece, and the foot length robe. 

#### Exodus 25:8 And you shall make for me a sanctuary, and I will be seen by you. 

#### Exodus 25:9 And you shall make for me according to all as much as I show you in the mountain -- the model of the tent, and the model of all the items of it -- even so shall you do. 

#### Exodus 25:10 And you shall make an ark of testimony from out of {wood incorruptible] -- two cubits and a half the length, and a cubit and a half the width, and a cubit and a half the height. 

#### Exodus 25:11 And you shall gild it {gold with pure]; from inside and from outside you shall gild it. And you shall make for it a waved border of gold, twisted round about. 

#### Exodus 25:12 And you shall forge for it four rings of gold; and you shall place them upon the four sides, two rings upon the {side one], and two rings upon the {side second]. 

#### Exodus 25:13 And you shall make bearing poles from {wood incorruptible], and you shall gild them with gold. 

#### Exodus 25:14 And you shall bring the bearing poles into the rings, the ones on the sides of the ark, to lift the ark by them. 

#### Exodus 25:15 In the rings of the ark of the covenant {will be the bearing poles] fixed. 

#### Exodus 25:16 And you shall put into the ark the testimonies which ever I give to you. 

#### Exodus 25:17 And you shall make an atonement-seat, a lid {gold of pure]; two cubits and a half is the length, and a cubit and a half the width. 

#### Exodus 25:18 And you shall make two cherubim wrought in gold, and you shall place them at both of the sides of the atonement-seat. 

#### Exodus 25:19 You shall make {cherub one] from out of this one side, and {cherub one] from out of {side the second] of the atonement-seat. Thus you shall make the two cherubim upon the two sides. 

#### Exodus 25:20 {will be The two cherubim] stretching out the wings on top, overshadowing with their wings above the atonement-seat, and their faces to one another; {towards the atonement-seat will be the faces of the cherubim]. 

#### Exodus 25:21 And you shall place the atonement-seat upon the ark from above. And into the ark you shall put the testimonies which I shall give to you. 

#### Exodus 25:22 And I will be known to you from there, and I will speak to you from above the atonement-seat between the two cherubim being upon the ark of the testimony, according to all as much as I give charge to you for the sons of Israel. 

#### Exodus 25:23 And you shall make a table of {woods incorruptible], of two cubits being the length, and a cubit the breadth, and a cubit and a half the height. 

#### Exodus 25:24 And you shall gild it {gold in pure]. And you shall make for it a twisted waved border of gold round about. And you shall make for it a rim of a palm width round about. 

#### Exodus 25:25 And you shall make a twisted waved border on the rim round about. 

#### Exodus 25:26 And you shall make for it four rings of gold, and you shall place the four rings upon the four parts of its feet under the rim. 

#### Exodus 25:27 And {shall be the rings] for holders for the bearing poles, so as to lift {the table]. 

#### Exodus 25:28 And you shall make the bearing poles from out of {woods incorruptible]. And you shall gild them {gold with pure]. And {shall be lifted by them the table]. 

#### Exodus 25:29 And you shall make its saucers, and the incense pans, and the libation bowls, and the cups, in which you shall offer a libation in them; {gold of pure] you shall make them. 

#### Exodus 25:30 And you shall place upon the table bread loaves face to face before me always. 

#### Exodus 25:31 And you shall make a lamp-stand from out of {gold pure]; a turned piece you shall make the lamp-stand. Its stem, and the branches, and the basins, and the knobs, and the lilies {of it will be]. 

#### Exodus 25:32 And six branches going forth sideways -- three branches of the lamp-stand from out of the {side one], and three branches of the lamp-stand from the {side second]. 

#### Exodus 25:33 And three basins being shaped nut-like on the one branch, with a knob and a lily; thus to the six branches of the ones going forth from out of the lamp-stand. 

#### Exodus 25:34 And in the lamp-stand, four basins being shaped nut-like. To the one branch, the knobs, and its lilies. 

#### Exodus 25:35 And the knob under the two branches from out of it, and a knob under the other two branches from out of it, thus to the six branches -- to the ones going forth from out of the lamp-stand. 

#### Exodus 25:36 The knobs and the branches from out of it -- let them be entirely turned from out of one piece {gold of pure]. 

#### Exodus 25:37 And you shall make {lamps its seven]. And you shall place its lamps. And they shall shine forth from the one before it. 

#### Exodus 25:38 And its funnel, and its underparts from out of {gold pure]. 

#### Exodus 25:39 A talent {gold of pure] you shall make all these items. 

#### Exodus 25:40 See that you should make according to the impression being shown to you on the mountain! 

#### Exodus 26:1 And for the tent you shall make ten curtains of linen being twined, and blue, and purple, and scarlet, being twined with cherubim. A work of a weaver you shall make them. 

#### Exodus 26:2 The length of the {curtain one] shall be eight and twenty cubits; and a breadth of four cubits {to the curtain one shall be]. {measure The same] shall be to all the curtains. 

#### Exodus 26:3 And five curtains will be of one another, being held the other with the other. And five curtains will be of one another, being held the other with the other. 

#### Exodus 26:4 And you shall make for them hooks of blue upon the edge of the {curtain one], joining the one part to the coupling. And thus you shall make upon the edge of the {curtain outer] for the {coupling second]. 

#### Exodus 26:5 And fifty hooks you shall make for the {curtain one], and fifty hooks you shall make for the part of the curtain corresponding to the coupling of the second, facing headlong into one another each. 

#### Exodus 26:6 And you shall make {hooks fifty] of gold. And you shall join together the curtains one to the other to the hooks. And {will be the tent] one. 

#### Exodus 26:7 And you shall make hide coverings of hair for protection upon the tent, eleven hide coverings you shall make them. 

#### Exodus 26:8 The length of the {hide covering one] will be thirty cubits; and four cubits the breadth of the {hide covering one]; {measure the same] will be to the eleven hide coverings. 

#### Exodus 26:9 And you shall join together the five hide coverings to the same, and the six hide coverings to the same. And you shall double up the {hide covering sixth] in front of the tent. 

#### Exodus 26:10 And you shall make {hooks fifty] upon the edge of the {hide covering one], of the one in the middle by the coupling. And fifty hooks you shall make upon the edge of the hide covering, of the one joining of the second. 

#### Exodus 26:11 And you shall make {hooks of brass fifty]. And you shall join together the hooks by the hooks, and you shall join together the hide coverings, and it shall be one. 

#### Exodus 26:12 And you shall set the extra in the hide coverings of the tent. The half of the hide covering being left over you shall cover up for the extra of the hide coverings of the tent. You shall cover up behind the tent. 

#### Exodus 26:13 A cubit from this side, and a cubit from that side of the superior part of the hide coverings, of the length of the hide coverings of the tent. And it will be to cover up the sides of the tent on this side and that side, that it should be covered. 

#### Exodus 26:14 And you shall make a covering of the tent -- skins of rams dyed red, and coverings of skins of blue on top. 

#### Exodus 26:15 And you shall make posts for the tent from out of {wood incorruptible]. 

#### Exodus 26:16 Of ten cubits you shall make the {post one], and {cubit one] and a half the width of the {post one]. 

#### Exodus 26:17 Two joints to the {post one] resting headlong against one to the other. Thus you shall make to all the posts of the tent. 

#### Exodus 26:18 And you shall make the posts for the tent -- twenty posts by the side towards the south. 

#### Exodus 26:19 And forty bases of silver you shall make for the twenty posts. Two bases to the {post one] for both its parts, and two bases to the other {post one] for both its parts. 

#### Exodus 26:20 And the {side second] towards the north -- twenty posts. 

#### Exodus 26:21 And forty bases for them made of silver. Two bases to the {post one] for both its parts, and two bases for the other {post one] for both its parts. 

#### Exodus 26:22 And by the rear of the tent by the part towards the west you shall make six posts. 

#### Exodus 26:23 And two posts you shall make at the corners of the tent at the posteriors. 

#### Exodus 26:24 And they shall be of equal below, and according to the same measurement they shall be equal from the heads unto {coupling one]. Thus shall you make to both the two corners, let them be equal! 

#### Exodus 26:25 And there shall be eight posts. And their bases of silver -- sixteen; and two bases to the {post one], and two bases to the other {post one]. 

#### Exodus 26:26 And you shall make bars from out of {wood incorruptible]; five to the posts from the one part of the tent. 

#### Exodus 26:27 And five bars to the posts to the {side of the tent second], and five bars for the posts on the posterior side of the tent, the one towards the west. 

#### Exodus 26:28 And the {bar middle] in between the posts -- let it penetrate from the one side unto the other side! 

#### Exodus 26:29 And the posts you shall gild in gold. And the rings you shall make of gold, into which you shall insert the bars. And you shall gild the bars in gold. 

#### Exodus 26:30 And you shall raise the tent according to the form being shown to you in the mountain. 

#### Exodus 26:31 And you shall make a veil from out of blue, and purple, and scarlet being twined, and linen being spun. {work a woven You shall make it] with cherubim. 

#### Exodus 26:32 And you shall place it upon four posts of incorruptible wood being gilded in gold. And the tips of them in gold, and {bases their four] made of silver. 

#### Exodus 26:33 And you shall put the veil upon the posts. And you shall carry in there, inside the veil, the ark of the testimony. And {shall separate the veil] to you between the holy and between the holy of the holies. 

#### Exodus 26:34 And you shall cover up by the veil the ark of the testimony in the holy of the holies. 

#### Exodus 26:35 And you shall put the table outwardly of the veil, and the lamp-stand directly opposite the table near the part of the tent towards the south. and the table you shall put by the part of the tent towards the north. 

#### Exodus 26:36 And you shall make a draw curtain for the door, of blue and purple, and scarlet being twined, and linen being twined, the work of an embroiderer. 

#### Exodus 26:37 And you shall make for the veil five posts, and you shall gild them with gold; and the tips of them of gold; and you shall cast for them five bases of brass. 

#### Exodus 27:1 And you shall make an altar from out of {woods incorruptible], of five cubits the length, and five cubits the breadth. {four-cornered will be The altar], and {three cubits its height]. 

#### Exodus 27:2 And you shall make the horns upon the four corners. {part of it will be The horns]. And you shall cover them in brass. 

#### Exodus 27:3 And you shall make a rim for the altar. And its lid, and its bowls, and its meat hooks, and its censer, and all its utensils you shall make of brass. 

#### Exodus 27:4 And you shall make for it {grate work a latticed brass]. And you shall make for the grate four rings of brass upon the four sides. 

#### Exodus 27:5 And you shall place them under the grate of the altar from below. {will be And the grate] for half the altar. 

#### Exodus 27:6 And you shall make for the altar bearing poles from out of {woods incorruptible], and you shall brass plate them in brass. 

#### Exodus 27:7 And you shall bring the bearing poles into the rings; and let {be the bearing poles] according to the sides of the altar in the lifting it! 

#### Exodus 27:8 {hollow planked You shall make it]; according to the holding forth of the example to you on the mountain -- thus you shall make it. 

#### Exodus 27:9 And you shall make a courtyard for the tent in the side, the one towards the south, and shrouds for the courtyard from out of linen being twined, the length a hundred cubits to the one side. 

#### Exodus 27:10 And their posts -- twenty; and their bases -- twenty, of brass; and their hooks, and their clips made of silver. 

#### Exodus 27:11 So also to the side towards the north you shall make shrouds a hundred cubits in length, and their posts -- twenty; and their bases -- twenty, made of brass; and their hooks, and the clips for the posts, and the bases being silver plated with silver metal. 

#### Exodus 27:12 And the breadth of the courtyard by the west with shrouds of fifty cubits, their posts -- ten; and their bases -- ten. 

#### Exodus 27:13 And the breadth of the courtyard towards the east with shrouds of fifty cubits; their posts -- ten, and their bases -- ten. 

#### Exodus 27:14 And fifteen cubits for the shrouds is to be the height for the {side one]; their posts -- three, and their bases -- three. 

#### Exodus 27:15 And for the {side second] fifteen cubits for the shrouds is to be the height; their posts -- three, and their bases -- three. 

#### Exodus 27:16 And in the gate of the courtyard a covering twenty cubits in height, from out of blue and purple, and scarlet being twined, and linen being twined in the embroidery of the stitcher; their posts -- four, and their bases -- four. 

#### Exodus 27:17 All the posts of the courtyard round about being plated in silver, and their tips made of silver, and their bases of brass. 

#### Exodus 27:18 And the length of the courtyard -- a hundred by a hundred. And the breadth -- fifty by fifty. And the height -- five cubits from out of linen being twined. And their bases were of brass. 

#### Exodus 27:19 And all the furniture, and all the work tools, and the stanchions of the courtyard were of brass. 

#### Exodus 27:20 And you give orders to the sons of Israel! And let them take to you olive oil from olive trees free from impurities! {pure being beaten] for a light, that {should burn a lamp] always. 

#### Exodus 27:21 In the tent of the testimony, from outside the veil, the one by the covenant -- {shall burn it Aaron] and his sons from evening until morning before the LORD; {law for an eternal] unto your generations by the sons of Israel. 

#### Exodus 28:1 And you lead forward to yourself both Aaron your brother, and his sons from out of the sons of Israel! to officiate as priest to me -- Aaron, and Nadab, and Abihu, and Eleazar, and Ithamar -- sons of Aaron. 

#### Exodus 28:2 And you shall make {apparel holy] for Aaron your brother, for honor and glory. 

#### Exodus 28:3 And you speak to all the wise in thought! whom I filled a spirit of wisdom and perception. And they shall make the {apparel holy] for Aaron, for the holy place, in which he shall officiate as priest to me. 

#### Exodus 28:4 And these are the apparels which they shall make; the breast-plate, and the shoulder-piece, and the foot length robe, and {inner garment a fringed], and turban, and belt. And they shall make {apparels holy] for Aaron and to his sons for officiating as priest to me. 

#### Exodus 28:5 And they shall take the gold, and the blue, and the purple, and the scarlet, and the linen. 

#### Exodus 28:6 And they shall make the shoulder-piece from out of linen being twined, {work a woven] of an embroiderer. 

#### Exodus 28:7 Two shoulder-pieces will be for him, being held together the other to the other, {upon the two parts attached]. 

#### Exodus 28:8 And the woven work of the shoulder-pieces which is upon him, concerning the making of it, shall be from {gold pure], and blue, and purple, and scarlet being spun, and linen being twined. 

#### Exodus 28:9 And you shall take the two stones -- stones of emerald; and you shall carve on them the names of the sons of Israel. 

#### Exodus 28:10 Six names upon the {stone one], and the six names remaining upon the {stone second], according to their births. 

#### Exodus 28:11 A work of a stonecutter's craft, as a carving of a seal you shall carve the two stones with the names of the sons of Israel. 

#### Exodus 28:12 And you shall put the two stones upon the shoulders of the shoulder-piece. {stones of memorial They are] to the sons of Israel. And Aaron shall lift up the names of the sons of Israel before the LORD upon {two shoulders his], as a memorial for them. 

#### Exodus 28:13 And you shall make bezels from {gold pure]. 

#### Exodus 28:14 And you shall make two bordered fringes from out of {gold pure], being mixed with {flowers a work of wreathen]. And you shall place the bordered fringes being plaited upon the bezels, on their shoulder straps from the front. 

#### Exodus 28:15 And you shall make an oracle of the judgments; a work of an embroiderer, according to the proportion of the shoulder-piece; you shall make it from gold, and blue, and purple, and scarlet being twined, and linen being twined -- you shall make it. 

#### Exodus 28:16 Four-cornered it shall be, doubled; a span the length, and a span the breadth. 

#### Exodus 28:17 And you shall interweave in it a woven work inlaid with precious stones, arranged in four rows. A row of stones will be sardius, topaz, and emerald -- for the {row one]. 

#### Exodus 28:18 And the {row second], carbuncle, and sapphire, and jasper. 

#### Exodus 28:19 And the {row third], amber, and agate, and amethyst. 

#### Exodus 28:20 And the {row fourth], chrysolite, and beryl, and onyx, being covered all around in gold and being tied together by gold; let them be according to their row! 

#### Exodus 28:21 And {the stones let] be of the names of the sons of Israel, twelve, according to their names! Carvings as seals each; {according to the names let them be] for the twelve tribes! 

#### Exodus 28:22 And you shall make upon the oracle a border, being a closely joined, {work a chain] of {gold pure]. 

#### Exodus 28:23 And you shall make upon the oracle two {rings golden]. And you shall place the two {rings golden] upon both the corners of the oracle. 

#### Exodus 28:24 And you shall put upon the borders even the chain-works of gold upon the two rings upon both of the sides of the oracle. 

#### Exodus 28:25 And two sides of the two borders you shall place upon the two wreaths. And you shall place them upon the shoulders of the shoulder-piece right opposite in front. 

#### Exodus 28:26 And you shall make two rings of gold. And you shall place them upon the borders of the oracle, upon the tip from tip of the posterior of the shoulder-piece within. 

#### Exodus 28:27 And you shall make two rings of gold, and you shall place them upon both of the shoulders of the shoulder-piece from below it, according to the front, according to the coupling from above of the woven part of the shoulder-piece. 

#### Exodus 28:28 And you shall clasp the oracle from the rings of the ones upon it, to the rings of the shoulder-piece banded together of the blue work, closely joined to the woven work of the shoulder-piece, that {should not slacken the oracle] from the shoulder-piece. 

#### Exodus 28:29 And Aaron shall receive the names of the sons of Israel upon the oracle of the judgment, upon the breast, entering into the holy place, as a memorial before God. 

#### Exodus 28:30 And you shall place upon the oracle of the judgment, the Manifestation and the Truth; and they shall be upon the breast of Aaron, whenever he should enter into the holy place before the LORD. And Aaron shall bring the judgments of the sons of Israel upon the breast, before the LORD always. 

#### Exodus 28:31 And you shall make {undergarment a foot length robe] entirely of blue. 

#### Exodus 28:32 And {will be the cleft of it] in the middle, {an edge having] round about the cleft -- a work of a weaver; {in the coupling being woven together] of it that it should not be torn. 

#### Exodus 28:33 And you shall make upon the hem of the undergarment below, as it were of a blossoming pomegranate -- figures of pomegranates from out of blue, and purple, and scarlet being spun, and linen being twined upon the hem of the undergarment round about. And the form of it as the figures of pomegranates of gold, and bells in between these that are surrounding. 

#### Exodus 28:34 By the figure of a pomegranate of gold, a bell, and flowered work upon the hem of the undergarment round about. 

#### Exodus 28:35 And it shall be {of Aaron in the officiating] {will be audible his sound] entering into the holy place before the LORD, and his exiting, that he might not die. 

#### Exodus 28:36 And you shall make a panel {gold of pure]. And you shall shape on it an impression seal -- Sanctified of the LORD. 

#### Exodus 28:37 And you shall place it upon blue being twined; and it will be upon the mitre -- in front of the mitre it shall be. 

#### Exodus 28:38 And it shall be upon the forehead of Aaron; and Aaron shall lift away the sins of the holy things whatever as much as {should sanctify the sons of Israel] -- every gift of their holy things; and it will be upon the forehead of Aaron always -- accepted for them before the LORD. 

#### Exodus 28:39 And the fringes of the inner garments shall be of linen; and you shall make a {turban fine linen]; and {a belt you shall make], the work of an embroiderer. 

#### Exodus 28:40 And for the sons of Aaron you shall make inner garments, and belts; and {turbans you shall make] for them for honor and glory. 

#### Exodus 28:41 And you shall put them on Aaron your brother, and his sons with him. And you shall anoint them, and you shall fill their hands. And you shall sanctify them that they should officiate as priests to me. 

#### Exodus 28:42 And you shall make for them {pants flaxen linen] to cover the indecency of their flesh -- from the loin unto the thighs they shall be. 

#### Exodus 28:43 And Aaron shall have them and his sons, whenever they should enter into the tent of the testimony, or whenever they should go to officiate to the altar of the holy place; and thus they shall not bring upon themselves sin that they should not die -- {law for an eternal] for him, and his seed after him. 

#### Exodus 29:1 And these are what you shall do to them, to sanctify them, so as to officiate as priest to me. You shall take {young calf from out of the oxen one], and {rams unblemished two], 

#### Exodus 29:2 and {breads unleavened] being mixed up with olive oil, and {pancakes unleavened] being coated with olive oil. {of fine flour of wheat You shall make them]. 

#### Exodus 29:3 And you shall place them upon {bin one], and you shall offer them at the bin, and the young calf, and the two rams. 

#### Exodus 29:4 And Aaron and his sons you shall lead forward at the door of the tent of the testimony, and you shall bathe them in water. 

#### Exodus 29:5 And taking the apparels, you shall put on Aaron your brother both the inner garment, the foot length robe, and the shoulder-piece, and the oracle; and you shall join it -- the oracle to the shoulder-piece. 

#### Exodus 29:6 And you shall place the mitre upon his head; and you shall place the {panel sanctified] upon the mitre. 

#### Exodus 29:7 And you shall take of the oil of the scented unguent, and pour it upon his head, and anoint him. 

#### Exodus 29:8 And his sons you shall lead forward, and put on them the inner garments. 

#### Exodus 29:9 And you shall tie around them the belts, and shall put on them the turbans, and it will be for them a priesthood to me into the eon. And you shall perfect the hands of Aaron, and the hands of his sons. 

#### Exodus 29:10 And you shall lead forward the calf unto the door of the tent of the testimony. And {shall place Aaron and his sons] their hands upon the head of the calf, before the LORD, by the doors of the tent of the testimony. 

#### Exodus 29:11 And you shall slay the calf before the LORD by the doors of the tent of the testimony. 

#### Exodus 29:12 And you shall take from the blood of the calf, and put it upon the horns of the altar with your finger. {the And remaining all] blood you shall discharge by the base of the altar. 

#### Exodus 29:13 And you shall take all the fat, upon the belly, and the lobe of the liver, and the two kidneys, and the fat upon them, and you shall place it upon the altar. 

#### Exodus 29:14 But the meats of the calf, and the skin, and the dung you shall incinerate with fire outside the camp, {an offering on account of sin for it is]. 

#### Exodus 29:15 And {ram you shall take one], and {shall place Aaron and his sons] their hands upon the head of the ram. 

#### Exodus 29:16 And you shall slay the ram. And taking the blood of it, you shall pour it upon the altar round about. 

#### Exodus 29:17 And the ram you shall cut in pieces according to its limbs. And you shall wash the entrails, and the feet in water. And you shall place them upon the pieces with the head. 

#### Exodus 29:18 And you shall offer all the ram upon the altar as a whole burnt-offering to the LORD, for a scent of pleasant aroma; {a sacrifice to the LORD it is]. 

#### Exodus 29:19 And you shall take the ram -- the second; and {shall place Aaron and his sons] their hands upon the head of the ram. 

#### Exodus 29:20 And you shall slay it, and take of the blood of it, and place it upon the lobe of the ear of Aaron -- of the right one, and upon the big toe of the foot -- of the right one, and upon the lobes of the {ears of his sons right], and upon the thumbs {hands of their right], and upon the big toes {feet of their right]. 

#### Exodus 29:21 And you shall take from of the blood, of blood before the altar, and from the oil of the anointing, and you shall sprinkle it upon Aaron, and upon his apparel, and upon his sons, and upon the apparels of his sons with him. And you shall sanctify him, and his apparel, and his sons, and the apparels of his sons with him. And the blood of the ram you shall pour before the altar round about. 

#### Exodus 29:22 And you shall take from the ram its fat, both the fat covering up the belly, and the lobe of the liver, and the two kidneys, and the fat upon them, and the {shoulder right] -- {is for a consecration this]. 

#### Exodus 29:23 And {bread loaf one] made with olive oil, and {pancake one] from the bin of the unleavened breads, of the ones being set before the LORD. 

#### Exodus 29:24 And you shall place the whole amount upon the hands of Aaron, and upon the hands of his sons. And you shall separate them as a separation offering before the LORD. 

#### Exodus 29:25 And you shall take them from their hands, and you shall offer them upon the altar of the whole burnt-offering as a scent of pleasant aroma before the LORD -- {a yield offering it is] to the LORD. 

#### Exodus 29:26 And you shall take the breast from the ram of the consecration, which is Aaron's, and you shall separate it as a separation offering before the LORD -- and it will be to you for a portion. 

#### Exodus 29:27 And you shall sanctify the {breast separation offering], and the shoulder of the choice portion which has been separated, and which has been removed from the ram of the consecration -- from Aaron, and from his sons. 

#### Exodus 29:28 And it will be to Aaron, and to his sons {law an eternal] for the sons of Israel, {is for a choice portion this]; and {a choice portion it will be] by the sons of Israel from the things offered in sacrifices of the deliverance offerings -- a choice portion to the LORD. 

#### Exodus 29:29 And the apparel of the holy place which is Aaron's, shall be to his sons' after him, for them to be anointed in them, and to perfect their hands. 

#### Exodus 29:30 Seven days he shall put them on -- the priest replacing him from his sons, who shall enter into the tent of the testimony to officiate in the holy place. 

#### Exodus 29:31 And the ram of the consecration you shall take, and you shall boil the meats in {place the holy]. 

#### Exodus 29:32 And {shall eat Aaron and his sons] the meats of the ram, and the bread loaves that are in the bin by the door of the tent of the testimony. 

#### Exodus 29:33 They shall eat the offerings with which they were sanctified by them, to perfect their hands, to sanctify them. And a foreigner shall not eat from them, for it is holy. 

#### Exodus 29:34 And if anything should be left behind from the meats of the sacrifice of the consecration, and of the bread loaves, until morning, you shall incinerate the remainder with fire; it shall not be eaten, {sanctified for it is]. 

#### Exodus 29:35 And you shall do for Aaron and his sons thus according to all as much as I gave charge to you. Seven days you shall perfect their hands. 

#### Exodus 29:36 And the young calf, the one of the sin offering, you shall offer in the day of cleansing. And you shall cleanse the altar in your sanctifying upon it. And you shall anoint it so as to sanctify it. 

#### Exodus 29:37 Seven days you shall cleanse the altar, and sanctify it. And {will be the altar] a holy of the holies; all touching the altar shall be sanctified. 

#### Exodus 29:38 And these are what you shall offer upon the altar -- lambs of a year old, unblemished, two for each day perpetually -- a yield offering of perpetuity. 

#### Exodus 29:39 The lamb -- the first one you shall offer in the morning, and the {lamb second], you shall offer at dusk. 

#### Exodus 29:40 And a tenth measure of fine flour being mixed with olive oil being beaten to the fourth part of a hin; and a libation -- the fourth part of the hin of wine to the lamb -- to the first one. 

#### Exodus 29:41 And the lamb -- the second, you shall offer at dusk, after the manner of the sacrifice -- the early morning, and according to its libation you shall do it for a scented pleasant aroma, a yield offering to the LORD; 

#### Exodus 29:42 {sacrifice a perpetual] unto your generations upon the doors of the tent of the testimony before the LORD, in which I will be known to you there, so as to speak to you. 

#### Exodus 29:43 And I will give orders there to the sons of Israel, and I will be sanctified in my glory. 

#### Exodus 29:44 And I will sanctify the tent of the testimony, and the altar; and Aaron, and his sons I will sanctify, to officiate as priests to me. 

#### Exodus 29:45 And I will be called upon by the sons of Israel, and I will be their God. 

#### Exodus 29:46 And they shall know that I am the LORD their God, the one leading them from out of the land of Egypt, to be called upon by them, and to be their God. 

#### Exodus 30:1 And you shall make an altar of incense from out of {wood incorruptible]. 

#### Exodus 30:2 And you shall make it a cubit in length, and a cubit in breadth -- four-cornered is shall be, and two cubits in height; from out of it will be its horns. 

#### Exodus 30:3 And you shall gild these {gold in pure] -- its grates, and its walls round about, and its horns. And you shall make for it a twisted {rim gold] round about. 

#### Exodus 30:4 And two rings {gold of pure] for it you shall make under {twisted rim its] for the two corners. You shall make them on two sides, and they will be clips for the staves so as to lift it by them. 

#### Exodus 30:5 And you shall make staves from out of {wood incorruptible], and you shall gild them in gold. 

#### Exodus 30:6 And you shall put it before the veil being for the ark of the testimony, in which I shall be made known to you there. 

#### Exodus 30:7 And {will burn incense upon it Aaron]; incense compounded fine -- in the morning by morning. Whenever he should trim the lamps, he shall burn incense upon it. 

#### Exodus 30:8 And whenever Aaron should ignite the lamps late, he shall burn incense upon it -- incense of perpetuity, continually before the LORD unto your generations. 

#### Exodus 30:9 And you shall not offer upon it {incense another]. A yield offering, and a sacrifice offering, and a libation offering you shall not offer upon it. 

#### Exodus 30:10 And {shall atone Aaron] upon its horns once a year. From the blood of the cleansing of sins of the making an atonement once a year he shall cleanse it for your generations; {a holy of holies it is] to the LORD. 

#### Exodus 30:11 And the LORD spoke to Moses, saying, 

#### Exodus 30:12 If you should take the assessment of the sons of Israel in the overseeing of them, then {shall give each] ransoms for his soul to the LORD, and there shall not be among them a failure in the overseeing of them. 

#### Exodus 30:13 And this is what they shall give, as many as pass the numbering -- the half double-drachma, which it shall be according to the double-drachma of the holy place -- twenty oboli to the double-drachma; but the half double-drachma is a contribution to the LORD. 

#### Exodus 30:14 Every one passing in the numbering from twenty years old and above shall give the contribution to the LORD. 

#### Exodus 30:15 The ones being rich shall not add more, and the ones needing shall not add less from the half of the double-drachma in the giving the contribution to the LORD to atone for your souls. 

#### Exodus 30:16 And you shall take the silver of the contribution given by the sons of Israel, and you shall give it for the upkeep of the tent of the testimony. And it will be to the sons of Israel a memorial before the LORD, to atone for your souls. 

#### Exodus 30:17 And the LORD spoke to Moses, saying, 

#### Exodus 30:18 Make a bathing tub of brass, and a base for it of brass, so as to wash. And you shall put it between the tent of the testimony, and between the altar. And you shall pour into it water. 

#### Exodus 30:19 And {shall wash Aaron and his sons] from it their hands and their feet. 

#### Exodus 30:20 Whenever they should enter into the tent of the testimony they shall wash in water, and no way shall they die. Or whenever they should go to the altar to officiate and to offer the whole burnt-offerings to the LORD, 

#### Exodus 30:21 they shall wash their hands and their feet in water, that they should not die. And it will be to them {law an eternal], to him and his generations after him. 

#### Exodus 30:22 And the LORD spoke to Moses, saying, 

#### Exodus 30:23 And you take spices, the flower {myrrh of choice] -- five hundred shekels, and {cinnamon sweet smelling] half of this -- two hundred and fifty, and {calamus sweet smelling] -- two hundred fifty, 

#### Exodus 30:24 and of oil of cassia -- five hundred shekels of the holy place, and olive oil from olives -- a hin! 

#### Exodus 30:25 And you shall make it {oil scented unguent a holy], a perfumed liquid scented by the craft of a perfumer -- {oil scented unguent a holy it shall be]. 

#### Exodus 30:26 And you shall anoint with it the tent of the testimony, and the ark of the testimony, 

#### Exodus 30:27 and all its utensils, and the lamp-stand, and its utensils, and the altar of incense, 

#### Exodus 30:28 and the altar of the whole burnt-offerings, and all its utensils, and the table, and all its utensils, and the bathing tub, and its base. 

#### Exodus 30:29 And you shall sanctify them. And they shall be a holy of the holies. Every one touching them shall be sanctified. 

#### Exodus 30:30 And Aaron and his sons you shall anoint, and you shall sanctify them to officiate as priests to me. 

#### Exodus 30:31 And to the sons of Israel you shall speak, saying, An oil of anointing -- {anointing a holy] this will be to you into your generations. 

#### Exodus 30:32 {upon the flesh of man You shall not anoint with it]. And concerning this composition, you shall not make any to you yourselves likewise -- it is holy, and it shall be sanctified to you. 

#### Exodus 30:33 Who ever should make likewise, and who ever should give of it to a foreigner, he shall be utterly destroyed from his people. 

#### Exodus 30:34 And the LORD said to Moses, Take to yourself spices -- balsam, and onycha, and {galbanum luscious], and {frankincense transparent], equal to equal it will be. 

#### Exodus 30:35 And they shall make with it {incense scented], a work of a perfumer -- {being mixed a pure work holy]. 

#### Exodus 30:36 And you shall cut of these into fine parts, and you shall put it before the testimony in the tent of the testimony from where I will be known to you from there. {a holy of the holies It will be to you] incense. 

#### Exodus 30:37 According to this composition you shall not make to you yourselves -- it shall be a sanctified thing to you to the LORD. 

#### Exodus 30:38 Who ever should make likewise so as to smell by it, he shall be destroyed from out of his people. 

#### Exodus 31:1 And the LORD spoke to Moses, saying, 

#### Exodus 31:2 Behold, I have called by name Bezaleel the son of Uri, son of Hur, of the tribe of Judah. 

#### Exodus 31:3 And I filled him {spirit a divine] of wisdom, and understanding, and higher knowledge, {in every work to consider], 

#### Exodus 31:4 and to supervise construction; to work the gold, and the silver, and the brass, and the blue, and the purple and the {scarlet spun], 

#### Exodus 31:5 and the linen being twined, and the stonecutting works, and for the woodworkers of the works of wood -- to work according to all the works. 

#### Exodus 31:6 And I have given him even Aholiab, the son of Ahisamach, of the tribe of Dan. And to every one discerning in heart I have given understanding. And they shall make all as much as I gave orders to you -- 

#### Exodus 31:7 the tent of the testimony, and the ark of the covenant, and the atonement-seat, the one upon it, and the equipment of the tent, 

#### Exodus 31:8 and the altars, and the table, and all the utensils for it, and the {lamp-stand pure], and all the utensils for it, 

#### Exodus 31:9 and the bathing tub, and its base, 

#### Exodus 31:10 and the {apparels ministry] of Aaron, and the apparels of his sons in the officiating as priest to me, 

#### Exodus 31:11 and the {oil anointing], and the incense of the composition of the holy place -- according to all as much as I gave charge to you they shall make. 

#### Exodus 31:12 And the LORD spoke to Moses, saying, 

#### Exodus 31:13 You also speak to the sons of Israel! saying, Perceive, and {my Sabbaths guard]! For it is a sign by me and among you unto your generations, that you might know that I the LORD am the one sanctifying you. 

#### Exodus 31:14 And you shall guard the Sabbath, for {holy it is] to you. The one profaning it, unto death shall be put to death. Every one who shall do {on it work], {shall be utterly destroyed that soul] from the midst of his people. 

#### Exodus 31:15 Six days you shall do works, but the {day seventh Sabbath rest is a holy] to the LORD. All who shall do work on the day of the Sabbaths shall be put to death. 

#### Exodus 31:16 And {shall guard the sons of Israel] the Sabbaths to observe them unto their generations. 

#### Exodus 31:17 {covenant It is an eternal] with me and the sons of Israel, {sign it is an eternal]. For in six days the LORD made the heaven and the earth, and on the {day seventh] he ceased and rested. 

#### Exodus 31:18 And he gave to Moses, when he rested from speaking to him in mount Sinai, the two tablets of the testimony -- tablets of stone, written by the finger of God. 

#### Exodus 32:1 And {seeing the people] that Moses passed time to come down from out of the mountain, {stood together the people] by Aaron, and they say to him, Rise up and make for us gods! the ones who will go before us. For Moses, this man who led us from out of the land of Egypt, we do not know what has happened to him. 

#### Exodus 32:2 And {says to them Aaron], Remove the {ear-rings gold]! the ones in the ears of your wives, and daughters; and bring them to me! 

#### Exodus 32:3 And {removed all the people the ear-rings gold], the ones in their ears, and they brought them to Aaron. 

#### Exodus 32:4 And he took them from out of their hands, and he shaped them with the stylus. And he made it {calf a molten]. And they said, These are your gods, O Israel, who hauled you from out of the land of Egypt. 

#### Exodus 32:5 And seeing, Aaron built an altar over against it. And Aaron proclaimed, saying, A holiday of the LORD is tomorrow. 

#### Exodus 32:6 And rising early in the next day, he offered whole burnt-offerings, and he offered the sacrifice of deliverance. And {sat the people] to eat and to drink, and they rose up to play. 

#### Exodus 32:7 And the LORD spoke to Moses, saying, Proceed quickly! to go down from here, {acted lawlessly for your people], whom you led from the land of Egypt. 

#### Exodus 32:8 They violate quickly from the way which I gave charge to them; they made to themselves a calf, and they do obeisance to it, and they have sacrificed to it. And they said, These are your gods, O Israel, who hauled you from the land of Egypt. 

#### Exodus 32:9 And now allow me! for being enraged in anger against them, I will obliterate them. 

#### Exodus 32:10 And I will make you into {nation a great]. 

#### Exodus 32:11 And Moses beseeched in front of the LORD God, and said, Why, O LORD, be enraged in anger against your people, whom you led from out of the land of Egypt in {strength great], and with {arm your high]? 

#### Exodus 32:12 lest at any time {should say the Egyptians], in saying, With wickedness he led them to kill them in the mountains, and to completely consume them from the earth. Cease in the anger of your rage, and {propitious be] to the evil of your people! 

#### Exodus 32:13 remembering Abraham, and Isaac, and Jacob your servants, to whom you swore by an oath to them according to yourself. And you spoke to them, saying, I will greatly multiply your seed as the stars of the heaven in multitude, and all this land which you spoke of to give it to their seed, so that they shall hold it into the eon. 

#### Exodus 32:14 And the LORD dealt kindly concerning the bad which he said he would do to his people. 

#### Exodus 32:15 And Moses returning, went down from the mountain along with the two tablets of the testimony in his hands -- tablets of stone, having been written on both their parts; on this side and that side they were written. 

#### Exodus 32:16 And the tablets {a work of God were], and the writing, {a writing of God is] chiseled in the tablets. 

#### Exodus 32:17 And Joshua hearing the voice of the people crying out, says to Moses, It is a sound of war in the camp. 

#### Exodus 32:18 And he says, It is not a sound originating from strength, nor a sound originating by a routing of the enemy, but a sound originating from wine I hear. 

#### Exodus 32:19 And when he approached the camp, he sees the calf and the company of dancers. And {being provoked to anger in rage Moses] tossed from his hands the two tablets, and he broke them below the mountain. 

#### Exodus 32:20 And having taken the calf which they made, he incinerated it in fire, and ground it fine, and sowed it upon the water, and made {drink it the sons of Israel]. 

#### Exodus 32:21 And Moses said to Aaron, What did {do to you this people] that you brought upon them {sin a great]? 

#### Exodus 32:22 And Aaron said to Moses, Be not provoked to anger, O master! for you know the impulse of this people. 

#### Exodus 32:23 For they say to me, Make us gods! which shall go before us, for {Moses this man], who led us out of Egypt, we do not know what has happened to him. 

#### Exodus 32:24 And I said to them, Anyone who possesses pieces of gold, remove them! And they gave them to me, and I tossed them into the fire, and there came forth this calf. 

#### Exodus 32:25 And Moses seeing the people, that they have been dispersed, {dispersed for them Aaron] to be a derision to their opponents. 

#### Exodus 32:26 Moses stood at the gate of the camp, and he said, Who is for the LORD? Come to me! {came together Then to him all the sons of Levi]. 

#### Exodus 32:27 And he says to them, Thus says the LORD God of Israel, Let {put each] on himself a broadsword upon his thigh! And let him go through and return from gate to gate through the camp! and let {kill each] his brethren, and each his neighbor, and each the one nearest him! 

#### Exodus 32:28 And {did the sons of Levi] as {said to them Moses]. And there fell of the people in that day three thousand males. 

#### Exodus 32:29 And {said to them Moses], You filled your hands today to the LORD; each one on his brother, and his son, to give upon you a blessing. 

#### Exodus 32:30 And it came to pass after the next morning, Moses said to the people, You have sinned {sin a great]. And now I will ascend to God, that I might make atonement on account of your sin. 

#### Exodus 32:31 {returned And Moses] to the LORD, and said, I beseech O LORD, {have sinned this people sin a great], and made to themselves golden gods. 

#### Exodus 32:32 And now, if forasmuch as you forgive them of their sin -- forgive! But if not, wipe me away from out of your book of which you wrote! 

#### Exodus 32:33 And the LORD said to Moses, If any sin before me, I will wipe them from out of my book. 

#### Exodus 32:34 And now, proceed, and guide this people into the place which I told to you! Behold, my angel shall go forth before your face, and in whatever day I should visit, I will bring upon them their sin. 

#### Exodus 32:35 And the LORD struck the people on account of the making of the calf, which Aaron made. 

#### Exodus 33:1 And the LORD said to Moses, Go forth, ascend from here, you and your people! whom you led from out of the land of Egypt, into the land which I swore by an oath to Abraham, and to Isaac, and to Jacob, saying, To your seed I will give it. 

#### Exodus 33:2 And I will send along my angel before your face; and he will cast out the Amorite, and Hittite, and Perizzite, and Gergesite, and Hivite, and Jebusite, and Canaanite. 

#### Exodus 33:3 And I will bring you into a land flowing milk and honey. {not For I will] go up with you, because {people a hard-necked you are], that I should not completely consume you in the way. 

#### Exodus 33:4 And {hearing the people saying this severe], mourned in mourning. 

#### Exodus 33:5 And the LORD said to the sons of Israel, You are a people hard-necked; see that {do not calamity another I bring] upon you! and should completely consume you. Now then remove {apparels your glorious], and the ornament! and I will show to you what I will do to you. 

#### Exodus 33:6 And {removed the sons of Israel] their ornamentation, and the attire at the mountain of Horeb. 

#### Exodus 33:7 And Moses, taking his tent, pitched outside the camp far from the camp. And it was called -- Tent of Testimony. And it came to pass, all the ones seeking the LORD went forth unto the tent outside the camp. 

#### Exodus 33:8 And whenever Moses entered into the tent outside the camp, {stood all the people] watching, each one by the door of his tent. And they contemplated Moses' going away unto his entering into the tent. 

#### Exodus 33:9 And as Moses entered into the tent, {came down the column of cloud] and stood at the door of the tent, and he spoke to Moses. 

#### Exodus 33:10 And {saw all the people] the column of cloud standing by the door of the tent. And {stood all the people]. And they did obeisance, each from the door of his tent. 

#### Exodus 33:11 And the LORD spoke to Moses face to face, as if any might speak to his own friend. And he retired into the camp. And the attendant Joshua, the son of Nun, a young man, did not go forth from out of the tent. 

#### Exodus 33:12 And Moses said to the LORD, Behold, you say to me, Lead this people! But you manifested not to me whom you shall send along with me. But you said to me, I know you above all, and {favor you have] with me. 

#### Exodus 33:13 If then I have found favor before you, reveal to me yourself knowingly! that I might see you, how ever I should be found in favor before you; and that I might know, that {is your people this nation]. 

#### Exodus 33:14 And he says, I myself will go before you, and will rest you. 

#### Exodus 33:15 And he says to him, Unless you yourself should go with us, {not me you should lead] from here. 

#### Exodus 33:16 And how {be made known will it truly] that I have found favor by you -- I and also your people, unless you are going with us, and {will be glorified both I and your people] by all the nations, as many as {upon the earth are]? 

#### Exodus 33:17 {said And the LORD] to Moses, And this {to you word which you have said I will do], for you have found favor before me, and I know you above all. 

#### Exodus 33:18 And he says, Show to me your own glory! 

#### Exodus 33:19 And he said, I will go by in front of you in my glory; and I will call the name, the LORD, before you; and I will show mercy on whom ever I should show mercy, and I will pity whom ever I should pity. 

#### Exodus 33:20 And he said, You will not be able to see my face, for not in any way may {see man] my face, and shall live. 

#### Exodus 33:21 And the LORD said, Behold, a place by me. And you shall stand upon the rock; 

#### Exodus 33:22 and when ever {should go by my glory], even I will put you into an opening in the rock, and I will shelter with my hand upon you until whenever I should go by. 

#### Exodus 33:23 And I shall remove the hand, and then you shall see the rear of me, but my face will not appear to you. 

#### Exodus 34:1 And the LORD said to Moses, Dress to yourself two tablets of stone, as also the first, and ascend to me into the mountain! and I will write upon the tablets the words which were upon the {tablets first], which you broke. 

#### Exodus 34:2 And come prepared in the morning! and you shall ascend upon mount Sinai, and you shall stand there to me upon the tip of the mountain. 

#### Exodus 34:3 And let no one ascend with you, nor appear in all the mountain! And the sheep and the oxen let them not feed neighboring that mountain! 

#### Exodus 34:4 And he dressed two tablets of stone, just as also the first. And Moses rising early in the morning ascended unto mount Sinai, in so far as {ordered him the LORD]. And Moses took with himself the two tablets, the ones of stone. 

#### Exodus 34:5 And the LORD came down in a cloud, and stood beside him there. And he called by the name of the LORD. 

#### Exodus 34:6 And the LORD went by before his face, and called out, The LORD, The LORD God, pitying and merciful, lenient and full of mercy and true, 

#### Exodus 34:7 and {righteousness observing], and doing mercy for thousands, removing lawlessnesses, and iniquities, and sins; and the ones liable he will not cleanse; bringing the lawlessnesses of the fathers upon the children, and upon the children of the children, unto the third and fourth generation. 

#### Exodus 34:8 And Moses hastening, bowing upon the earth, did obeisance. 

#### Exodus 34:9 And he said, If I have found favor before you, let {go my LORD] with us! {the people For] are hard-necked. And you shall remove the sins, and our lawless deeds, and we will be yours. 

#### Exodus 34:10 And the LORD said to Moses, Behold, I establish with you a covenant before all your people. And I will do honorable, which has not happened in all the earth, and with any nation. And {shall see all the people among whom you are] the works of the LORD, for it is wonderful what I will do for you. 

#### Exodus 34:11 You heed all as much as I give charge to you! Behold, I cast out before your face the Amorite, and the Canaanite, and the Hittite, and the Perizzite, and the Hivite, and the Gergesite, and the Jebusite. 

#### Exodus 34:12 Take heed to yourself! lest at any time you should establish a covenant with the ones lying in wait upon the land, into which you enter into it, lest at any time it become an occasion of stumbling to you. 

#### Exodus 34:13 Their shrines you shall demolish, and their monuments you shall break, and their sacred groves you shall cut down, and the carvings of their gods you shall incinerate in fire. 

#### Exodus 34:14 For you should not do obeisance to other gods. For the LORD God, a jealous name, {God is a jealous]; 

#### Exodus 34:15 lest at any time you should establish a covenant with the ones lying in wait upon the land, and they should fornicate after their gods, and should sacrifice to their gods, and they should call you, and you should eat of their sacrifices; 

#### Exodus 34:16 and you should take of their daughters to your sons, and of your daughters you should give to their sons; and {should fornicate your daughters] after their gods, and {will fornicate your sons] after their gods. 

#### Exodus 34:17 And {gods molten you shall not make to yourself]. 

#### Exodus 34:18 And the holiday of the unleavened breads you shall guard; seven days you shall eat unleavened breads, just as I gave charge to you, at the time in the month of the new produce. For in the month of the new produce you came forth out of Egypt. 

#### Exodus 34:19 All opening wide the womb -- to me are the males; first-born of the calf, and of the sheep. 

#### Exodus 34:20 And a first-born beast of burden you shall ransom with a sheep. But if you will not ransom it, {value you shall give] for it. Every first-born of your sons you shall ransom. You shall not appear before me empty. 

#### Exodus 34:21 Six days you shall work, but the {day seventh] you shall rest -- in the sowing and in the harvest you shall rest. 

#### Exodus 34:22 And a holiday of a period of sevens you shall observe to me, the beginning of the harvest of wheat, and a holiday gathering being in the middle of the year. 

#### Exodus 34:23 Three times of the year {shall appear every male of yours] before the LORD God of Israel. 

#### Exodus 34:24 For whenever I shall cast out the nations from your face, and I widen your borders, {shall desire no one] your land, when ever you ascend to appear before the LORD your God three times a year. 

#### Exodus 34:25 You shall not slay {with yeast the blood of my sacrifices]; and {shall not remain through the night into the morning that which is offered in sacrifices] for the holiday of the passover. 

#### Exodus 34:26 The first produce of your land you shall carry into the house of the LORD your God. You shall not boil a lamb in the milk of its mother. 

#### Exodus 34:27 And the LORD said to Moses, Write to yourself these words! for upon these words I have established to you a covenant, and to Israel. 

#### Exodus 34:28 And {was there Moses] before the LORD forty days and forty nights. Bread he did not eat, and water he did not drink. And he wrote upon the tablets these words of the covenant -- the ten words. 

#### Exodus 34:29 And as Moses went down from mount Sinai, even the two tablets were upon the hands of Moses. {going down And in his] from the mountain, even Moses did not know that {was glorified the appearance of the complexion of his face] in his speaking to him. 

#### Exodus 34:30 And {saw Aaron and all the sons of Israel] Moses; and he was being glorified in the appearance of the complexion of his face. And they feared to approach him. 

#### Exodus 34:31 And {called them Moses]; and {turned towards him Aaron] and all the rulers of the congregation. And {spoke to them Moses]. 

#### Exodus 34:32 And after these things came forward to him all the sons of Israel. And he gave charge to them all as much as the LORD spoke to him on mount Sinai. 

#### Exodus 34:33 And as soon as he rested speaking to them, he placed upon his face a covering. 

#### Exodus 34:34 And when ever Moses entered before the LORD to speak to him, he removed the covering until exiting. And going forth he spoke to all the sons of Israel, as much as {gave charge to him the LORD]. 

#### Exodus 34:35 And {saw the sons of Israel] the face of Moses, that it was glorified; and Moses put the covering upon his face until whenever he entered to converse together with him. 

#### Exodus 35:1 And Moses gathered together all the congregation of the sons of Israel. And he said to them, These are the words which the LORD told them to do. 

#### Exodus 35:2 Six days you shall do works, but on the {day seventh] you shall rest a holy Sabbath rest to the LORD; every one doing work on it -- let him come to an end. 

#### Exodus 35:3 You shall not burn a fire in any place of your house on the day of the Sabbaths -- I am the LORD. 

#### Exodus 35:4 And Moses said to all the congregation of the sons of Israel, saying, This is the saying which the LORD ordered, saying, 

#### Exodus 35:5 Take from yourselves of them -- a choice-portion to the LORD. Every one appreciating in his heart shall bring the first-fruits to the LORD -- gold, silver, brass, 

#### Exodus 35:6 blue, purple, scarlet {double being spun], and linen being twined, and hair of goats, 

#### Exodus 35:7 and skins of rams dyed red, and skins of blue, and {wood incorruptible], 

#### Exodus 35:8 and oil for the giving light, and incense for the oil of the anointing, and for the compound of the incense, 

#### Exodus 35:9 and stones of sardius, and stones for the carving for the shoulder-piece and for the oracle. 

#### Exodus 35:10 And all the wise in thought among you, in coming, let him work all things as much as the LORD ordered -- 

#### Exodus 35:11 the tent, and the covering sheets of leather, and the coverings, and the clasps, and the posts, and the bars, and the pegs, and bases, 

#### Exodus 35:12 the ark, and its bearing poles, and the atonement-seat, and the veil, 

#### Exodus 35:13 and the table, and its bearing poles, and all its utensils, and the bread loaves of the place setting, 

#### Exodus 35:14 and the lamp-stand of the light, and all its utensils, and its lamps, and the oil of the light, 

#### Exodus 35:15 and the altar of the incense, and the bearing poles of it, and the oil for the anointing, and incense for the composition, and the draw curtain for the door of the tent, 

#### Exodus 35:16 and the altar of the whole burnt-offering, and {grate its brass], and its bearing poles, and all its utensils, and the bathing tub, and it base, 

#### Exodus 35:17 and the shrouds of the courtyard, and its posts, 

#### Exodus 35:18 and the pegs of the tent, and the pegs of the courtyard, and their cords, and the {apparels holy] of Aaron the priest, 

#### Exodus 35:19 and the apparels in which they officiate in them in the holy place, and the inner garments for the sons of Aaron for the priesthood, and the oil of the anointing, and the incense of the composition. 

#### Exodus 35:20 And went forth all the congregation of the sons of Israel from Moses. 

#### Exodus 35:21 And {brought each] what {offered their heart]. And the ones which it seemed good in their soul brought a choice portion to the LORD for all the works of the tent of the testimony, and for all the upkeep of it, and for all the {apparels holy]. 

#### Exodus 35:22 And {brought the men] from the women every thing which seemed good in their thought. They brought seals, and ear-rings, and rings, and wreaths, and right armbands -- every item of gold. 

#### Exodus 35:23 And all as many as brought choice-portions of gold to the LORD, and all which was found by them of blue, and purple, and scarlet, and linen, and skins of rams being dyed red, and skins of blue -- they brought. 

#### Exodus 35:24 And everyone removing the choice-portion silver and brass, brought the choice-portions to the LORD. And from whomever {was found wood incorruptible] for all the works of the preparation -- they brought. 

#### Exodus 35:25 And every woman wise in considering with the hands to spin, brought works being spun -- the blue, and the purple, and the scarlet, and the linen. 

#### Exodus 35:26 And all the women to whom it seemed good in their consideration with wisdom, spun the hair of the goats. 

#### Exodus 35:27 And the rulers brought the stones of emerald, and the stones for the filling in the shoulder-piece, and for the oracle, 

#### Exodus 35:28 and the compositions, and for the oil of the anointing, and the composition of the incense. 

#### Exodus 35:29 And every man and woman which brought their consideration, entering to do all the work; as many as the LORD ordered them to do through Moses -- {brought the sons of Israel] the choice-portion to the LORD. 

#### Exodus 35:30 And Moses said to the sons of Israel, Behold, God has called by name Bezaleel the son of Uri, son of Hur, of the tribe of Judah. 

#### Exodus 35:31 And he filled him with {spirit divine] of wisdom, and understanding, and of higher knowledge of all things; 

#### Exodus 35:32 to supervise construction according to all the works of the construction; to prepare the gold, and the silver, and the brass, 

#### Exodus 35:33 and to cut the stone, and to manufacture the wood things, and to produce with every work of wisdom. 

#### Exodus 35:34 And {assistance indeed God gave] in the considering to him, and also to Aholiab, to the son of Ahisamach, of the tribe of Dan. 

#### Exodus 35:35 And he filled them with wisdom of understanding in considering all things, to perceive, to make the works of the holy place, and the woven works, and embroidered works; to weave with the scarlet and with the linen; to make every work of construction and embroidery. 

#### Exodus 36:1 And Bezaleel prepared, and Aholiab, and all wise in thought, in whom was given wisdom and higher knowledge for them to perceive to do all the works {for the holies, being fit], according to all as much as the LORD ordered. 

#### Exodus 36:2 And Moses called Bezaleel and Aholiab, and all the ones having the wisdom, to whom God gave higher knowledge in the heart, and all of the ones voluntarily willing to go to the works so as to complete them. 

#### Exodus 36:3 And they took from Moses all the choice-portion offerings which {brought the sons of Israel] for all the works of the holy place, to prepare them. And they favorably received still the things being brought from the ones bringing morning by morning. 

#### Exodus 36:4 And {came all the wise ones], the ones doing the works of the holy place, each according to his own work, which they worked. 

#### Exodus 36:5 And they said to Moses, that, {a multitude bring The people] for the works, as much as the LORD ordered to do. 

#### Exodus 36:6 And Moses assigned, and proclaimed in the camp, saying, Let a man and woman no longer work in the first-fruits of the holy place. And {were restrained the people] still to bring. 

#### Exodus 36:7 And the supply of works was to them enough for {the furniture making]; and they left surplus. 

#### Exodus 36:8 And {produced every wise one in thought among the ones working] for the tent ten curtains from out of linen being twined, and blue and purple, and scarlet being twined; {with cherubim the work of a weaver he made them]. 

#### Exodus 36:9 The length of the {curtain one] -- eight and twenty cubits, and the breadth of four cubits {to the curtain one was]. {measure The same] was to all the curtains. 

#### Exodus 36:10 And five curtains were of one another, being held the other with the other. And five curtains were of one another, being held the other with the other. 

#### Exodus 36:11 And he made hooks of blue upon the edge of the {curtain one] joining the one part for the coupling. And thus he made upon the edge of the {curtain outer] for the {coupling second]. 

#### Exodus 36:12 And fifty hooks he made for the {curtain one], and fifty hooks he made for the part of the curtain corresponding to the coupling of the second, facing headlong into one another each. 

#### Exodus 36:13 And he made {hooks fifty] of gold. And he joined together the curtains an other to an other by the hooks. And {became the tent] one. 

#### Exodus 36:14 And he made hide coverings of hair to protect over the tent. Eleven hide coverings he made them. 

#### Exodus 36:15 The length of the {hide covering one] was thirty cubits, and four cubits the breadth of the {hide covering one]. {measure The same] was to the eleven hide coverings. 

#### Exodus 36:16 And he joined together the five hide coverings to the same, and the six hide coverings to the same. 

#### Exodus 36:17 And he made {hooks fifty] upon the edge of the {hide covering one], in the middle by the coupling. And fifty hooks he made upon the edge of the {hide covering joining second]. 

#### Exodus 36:18 And he made {hooks of brass fifty]. And he joined together the hooks by the hooks, and he joined together the hide coverings, and it became one. 

#### Exodus 36:19 And he made a covering for the tent -- skins of rams dyed red, and coverings of skins of blue on top. 

#### Exodus 36:20 And he made posts for the tent from out of {wood incorruptible]. 

#### Exodus 36:21 Ten cubits was the {post one], and {cubit one] and a half the width of the {post one]. 

#### Exodus 36:22 Two joints to the {post one] resting headlong against an other to an other; thus he made all the posts of the tent. 

#### Exodus 36:23 And he made the posts of the tent -- twenty posts by the side of the one towards the south. 

#### Exodus 36:24 And forty bases of silver he made for the twenty posts. Two bases to the {post one], for both its parts. And two bases to the other {post one], for both its parts. 

#### Exodus 36:25 And the {side second] towards the north -- twenty posts, 

#### Exodus 36:26 and forty bases for them made of silver. Two bases to the {post one], for both its parts. And two bases for the other {post one], for both its parts. 

#### Exodus 36:27 And by the rear of the tent by the part towards the west, he made six posts. 

#### Exodus 36:28 And two posts he made at the corners of the tent at the posteriors. 

#### Exodus 36:29 And they were of equal below, and according to the same measurement they were equal from the heads unto {coupling one]. Thus he made to both the {corners two]. 

#### Exodus 36:30 And there were eight posts, and their bases of silver -- sixteen. Two bases to the {post one], and two bases to the {post one], for both it parts. 

#### Exodus 36:31 And he made bars from out of {wood incorruptible]; five to the posts from the one part of the tent; and five bars to the posts to the {side of the tent second]. 

#### Exodus 36:32 And five bars for the posts to the posterior side of the tent towards the west. 

#### Exodus 36:33 And the {bar middle] in between the posts penetrated from the one side unto the other side. 

#### Exodus 36:34 And the posts he gilded in gold; and their rings he made of gold for holders to the bearing poles. And he gilded the bars in gold. 

#### Exodus 36:35 And he made a veil from out of blue, and purple, and scarlet being twined, and linen being spun. {work a woven He made it] with cherubim. 

#### Exodus 36:36 And he placed it upon four posts of incorruptible wood being gilded in gold. And the tips of them of gold, and {bases their four] were made of silver. 

#### Exodus 36:37 And he made a draw curtain for the door of the tent of blue, and purple, and of scarlet being twined, and linen being twined, a work of an embroiderer; 

#### Exodus 36:38 and {posts its five], and their tips. And he gilded their tips with gold. And he cast for them five bases of brass. 

#### Exodus 37:1 And Bezaleel made the ark from {wood incorruptible]; two cubits and a half was the length, and a cubit and a half was the width, and a cubit and a half was the height. 

#### Exodus 37:2 And he gilded it {gold in pure] from inside and from outside. And he made for it a waved border twisted of gold round about. 

#### Exodus 37:3 And he cast for it four {rings golden] upon {four sides its]. Two rings upon the {side one], and two rings upon the {side second]. 

#### Exodus 37:4 And he made bearing poles of {wood incorruptible], and he gilded them with gold. 

#### Exodus 37:5 And he inserted the bearing poles into the rings, the ones on the sides of the ark, to lift the ark by them. 

#### Exodus 37:6 And he made the atonement-seat lid {gold of pure]. Two cubits and a half was the length, and a cubit and a half was the width. 

#### Exodus 37:7 And he made two cherubim wrought in gold. And he put them at both of the sides of the atonement-seat. 

#### Exodus 37:8 {cherub One] at this side, and {cherub one] at the {side second] of the atonement-seat. And he made the two cherubim upon {two sides its]. 

#### Exodus 37:9 And {were the two cherubim] stretching out the wings above, overshadowing with their wings over the atonement-seat, their faces to one another -- to the atonement-seat were the faces of the cherubim. 

#### Exodus 37:10 And he made the table from {wood incorruptible]. Two cubits was the width, and a cubit the breadth, and a cubit and a half the height. 

#### Exodus 37:11 And he gilded it {gold in pure]. 

#### Exodus 37:12 And he made for it a twisted {waved border golden] round about. And he made for it a rim -- a palm's width round about. And he made a twisted waved border round about the rim. 

#### Exodus 37:13 And he cast for it four {rings golden]. And he placed the four rings upon the four parts by its feet. 

#### Exodus 37:14 By the waved border rim were the rings for a holder to the bearing poles, so as to lift the table. 

#### Exodus 37:15 And he made the bearing poles of {wood incorruptible], and he gilded them with gold so as to lift the table. 

#### Exodus 37:16 And he made the utensils for the table, both its saucers, and the incense pans, and the cups, and the libation bowls in which the priest will offer libations in them, {gold made of pure]. 

#### Exodus 37:17 And he made the lamp-stand of {gold pure]; a turned piece he made the lamp-stand. Its stem, and the branches, and the basins, and the knobs, and the lilies {of it were]. 

#### Exodus 37:18 And six branches were going forth sideways -- three branches of the lamp-stand from out of {side its one], and three branches of the lamp-stand from the {side second]. 

#### Exodus 37:19 And three basins being shaped nut-like were on the one branch, with a knob and lily; and three basins being shaped nut-like on the one branch with a knob and a lily; thus to the six branches, to the ones going forth from the lamp-stand. 

#### Exodus 37:20 And on the lamp-stand were four basins being shaped nut-like to the one branch, with the knobs, and its lilies. 

#### Exodus 37:21 The knob under the two branches of it, and a knob under the two branches of it, thus to the six branches, to the ones going forth from out of the lamp-stand. 

#### Exodus 37:22 And the branches, and the knobs of it were entirely turned from out of one piece {gold of pure]. 

#### Exodus 37:23 And he made {lamps its seven], and its tongs, and their oil funnels -- {gold of pure]. 

#### Exodus 37:24 A talent {gold of pure] he made all its items. 

#### Exodus 37:25 And he made an altar of incense from out of {wood incorruptible]. A cubit was the length of it; and a cubit was the breadth of it, four-cornered; and two cubits was the height of it; of it were its horns. 

#### Exodus 37:26 And he gilded it {gold with pure], its grate, and its walls, and its horns. And he made for it a twisted {rim gold] round about. 

#### Exodus 37:27 And two rings {gold of pure] he made for it under {rim twisted its] for {two corners its] on {two sides its] for holders for the bearing poles to lift it by them. 

#### Exodus 37:28 And he made the bars out of {wood incorruptible]; and he gilded them with gold. 

#### Exodus 37:29 And he prepared the oil for the anointing the holy, and the composition of the incense, a pure work of a perfumer. 

#### Exodus 38:1 And he made an altar for whole burnt-offering out of {wood incorruptible]; of five cubits was the length, and five cubits the breadth; {four-cornered was the altar], and {three cubits its height]. 

#### Exodus 38:2 And he made the horns. Upon the four corners of it were the horns, and he covered them in brass. 

#### Exodus 38:3 And he made a rim on the altar, and the lid for it, and the bowls for it, and the meat hooks for it, and the censer for it; and all the utensils for it he made of brass. 

#### Exodus 38:4 And he made for it {grate work a latticed brass]. 

#### Exodus 38:5 And he made for the grate four rings of brass upon the four sides. And he placed them under the grate of the altar from below; and {was the grate] unto half the altar. 

#### Exodus 38:6 And he made the bearing poles for the altar out of {wood incorruptible]; and he brass plated them in brass. 

#### Exodus 38:7 And he inserted the bearing poles at the sides of the altar in the lifting it! {hollow planked He made it]. 

#### Exodus 38:8 And he made the {bathing tub brass], and the {base of it brass] from out of the mirrors of the women that fasted, who fasted by the doors of the tent of the testimony. 

#### Exodus 38:9 And he made for the courtyard, the one towards the south, shrouds for the courtyard from out of linen being twined -- a hundred by a hundred. 

#### Exodus 38:10 And their posts -- twenty, and {bases their twenty brass]. And their hooks and their clips were of silver. 

#### Exodus 38:11 And the side towards the north was a hundred by a hundred. And their posts -- twenty, and {bases their twenty, brass]. And their hooks, and their clips were of silver. 

#### Exodus 38:12 And the side towards the west -- curtains of fifty cubits; their posts -- ten, and their bases -- ten, and their hooks, and their clips were of silver. 

#### Exodus 38:13 And the side towards the east -- {of fifty cubits shrouds], 

#### Exodus 38:14 of fifteen cubits according to the back, and their posts -- three, and their bases -- three. 

#### Exodus 38:15 And upon the back of the second on this side and that side according to the gate of the courtyard -- curtains of fifteen cubits, and their posts -- three, and their bases -- three. 

#### Exodus 38:16 All the curtains for the tent were of linen being twined. 

#### Exodus 38:17 And the bases, the ones of their posts were of brass, and their hooks were of of silver, and their tips being silver plated in silver; and the posts being silver plated in silver, all the posts of the courtyard. 

#### Exodus 38:18 And the veil of the gate of the courtyard was a work of an embroiderer, of blue, and purple, and scarlet being spun, and linen being twined; twenty cubits was the length, and the height and breadth five cubits, being made equal to the shrouds of the courtyard. 

#### Exodus 38:19 And their posts -- four; and their bases -- four, were of brass; and their hooks were of silver, and their tips being silver plated in silver. 

#### Exodus 38:20 And all the stanchions of the courtyard round about were of brass. 

#### Exodus 38:21 And this was the arrangement of the tent of the testimony, as was given orders to Moses; the ministration to be of the Levites through Ithamar the son of Aaron the priest. 

#### Exodus 38:22 And Bezaleel the son of Uri, of the tribe of Judah, made as the LORD gave orders to Moses, 

#### Exodus 38:23 and Aholiab, the son of Ahisamach, of the tribe of Dan, who supervised construction -- the woven works, and the stitched works, and the embroideries, woven in the blue and purple, and scarlet being spun, and linen. 

#### Exodus 38:24 All the gold which was manufactured for the works according to all the work of the holies, was of the gold of the first-fruit -- nine and twenty talents, and seven hundred and thirty shekels, according to the {shekel holy]. 

#### Exodus 38:25 And of the silver and the choice-portion offering from the {being numbered men] of the congregation -- a hundred talents, and a thousand seven hundred seventy five shekels, {drachma one] per head, the half shekel, according to the {shekel holy], 

#### Exodus 38:26 for every one passing into the numbering, from a son twenty years and up, for the sixty ten thousands, and three thousand and five hundred fifty. 

#### Exodus 38:27 And came to pass the hundred talents of silver for the molten casting of the tips of the tent, and for the tips of the veil; a hundred tips for the hundred talents, a talent to the tip. 

#### Exodus 38:28 And the thousand seven hundred seventy five shekels he made for the hooks for the posts; and he gilded their tips, and adorned them. 

#### Exodus 38:29 And the brass of the choice-portion offering was three hundred seventy talents, and two thousand and four hundred shekels. 

#### Exodus 38:30 And they made from out of it the bases of the door of the tent of the testimony, and the altar of brass with its grate, and all the utensils of the altar, 

#### Exodus 38:31 and the bases of the courtyard round about, and the bases of the gate of the courtyard, and the stanchions of the tent, and the stanchions of the courtyard round about. 

#### Exodus 39:1 And the leftover blue and purple and the scarlet they made into apparels for the ministry of Aaron, for the officiating in them in the holy place, as the LORD gave orders to Moses. 

#### Exodus 39:2 And they made the shoulder-piece from out of gold, and blue, and purple, and scarlet being spun, and linen being twined. 

#### Exodus 39:3 And {were trimmed apart the panels], of the {of gold hairs], so as to weave together with the blue and the purple, and with the scarlet being spun, and with the linen being twined -- {work a woven] they made it; 

#### Exodus 39:4 shoulder-pieces held together by both of the parts; {work a woven] into one another being closely joined to itself. 

#### Exodus 39:5 From it they made according to the same making, of gold, and blue, and purple, and scarlet being spun, and linen being twined, as the LORD gave orders to Moses. 

#### Exodus 39:6 And they made both of the stones of emerald, being clasped together and being inlaid in gold, being carved and being engraved -- an engraved seal of the names of the sons of Israel. 

#### Exodus 39:7 and they placed them upon the shoulders of the shoulder-piece; {stones of memorial they are] of the sons of Israel, as the LORD gave orders to Moses. 

#### Exodus 39:8 And they made the oracle -- {work a woven] in embroidery, according to the work of the shoulder-piece; of gold, and blue, and purple, and scarlet being spun, and linen being twined. 

#### Exodus 39:9 {four-cornered double They made the oracle]. A span was the length, and a span was the breadth, doubled. 

#### Exodus 39:10 And they wove together in it a woven work inlaid with precious stones, arranged in four rows. A row of stones -- sardius, and topaz, and emerald, was the {row one]. 

#### Exodus 39:11 And the {row second] -- carbuncle, and sapphire, and jasper. 

#### Exodus 39:12 And the {row third] -- amber, and agate, and amethyst; 

#### Exodus 39:13 and the {row fourth] -- chrysolite, and beryl, and onyx; being surrounded by gold and being tied together by gold. 

#### Exodus 39:14 And the stones were of the names of the {sons of Israel twelve], of {twelve names their] being engraved seals, each of its own name for the twelve tribes. 

#### Exodus 39:15 And they made {upon the oracle a border], {being closely joined a work of wreath] from out of {gold pure]. 

#### Exodus 39:16 And they made two bezels of gold, and two rings of gold. 

#### Exodus 39:17 And they placed the two rings of gold upon both the corners of the oracle. And they placed the wreaths of gold upon the two rings, upon both of the parts of the oracle, and for the two couplings for the two wreaths. 

#### Exodus 39:18 And they placed them upon the two bezels of the shoulders of the shoulder-piece, right opposite down in front. 

#### Exodus 39:19 And they made two rings of gold. And they placed them upon the two fins at the tip of the oracle upon the tip of the posterior of the shoulder-piece from inside. 

#### Exodus 39:20 And they made two rings of gold, and placed them upon both of the shoulders of the shoulder-piece from below it, down in front, down from the coupling from above the woven part of the shoulder-piece. 

#### Exodus 39:21 And he fastened the oracle by the rings upon it, to the rings of the shoulder-piece, to hold it together -- from out of blue, being closely joined into the woven work of the shoulder-piece, that {would not slacken the oracle] from the shoulder-piece, as the LORD gave orders to Moses. 

#### Exodus 39:22 And they made the undergarment under the shoulder-piece, {work a woven], entirely of blue. 

#### Exodus 39:23 And the cleft of the undergarment was in the middle, being interwoven closely, {an edge having] round about the cleft, reinforced. 

#### Exodus 39:24 And they made upon the hem of the undergarment from below as it were of a blossoming pomegranate -- figures of pomegranates of blue, and purple, and scarlet being spun, and linen being twined. 

#### Exodus 39:25 And they made bells of gold. And they placed the bells upon the hems of the undergarment round about, between the figures of pomegranates. 

#### Exodus 39:26 Bells of gold and pomegranate figures upon the hem of the undergarment round about, for the officiating, as the LORD gave orders to Moses. 

#### Exodus 39:27 And they made garments of fine linen, {work a woven], for Aaron and his sons. And the turbans from out of linen, 

#### Exodus 39:28 and the mitre from out of linen, and the pants from out of linen being twined; 

#### Exodus 39:29 and their belts from out of linen, and blue, and purple, and scarlet being spun, the work of an embroiderer, in which manner the LORD gave orders to Moses. 

#### Exodus 39:30 And they made the {panel golden], a separation offering for the holy place, {gold of pure]. And they wrote upon it letters being shaped as of a seal, Sanctified to the LORD. 

#### Exodus 39:31 And they put upon it a hem of blue, so as to rest upon the mitre above, in which manner the LORD gave orders to Moses. 

#### Exodus 39:32 And {was completed all work of the tent of the testimony]. And {made the sons of Israel] according to all whatsoever the LORD gave orders to Moses. 

#### Exodus 39:33 And they brought the tent to Moses, and all the items for it, and its rings, and its posts, and its bars, and its stanchions, and its bases, 

#### Exodus 39:34 and the leather coverings of the skins of rams dyed red, and the {coverings skin] of blue, and the veil, 

#### Exodus 39:35 and the ark of the testimony, and its poles, and the altar, 

#### Exodus 39:36 and the table, and all its utensils, and the bread loaves of the place setting, 

#### Exodus 39:37 and the {lamp-stand pure], and its lamps -- lamps for burning, and all its utensils, and the oil for the light, 

#### Exodus 39:38 and the {altar golden], and the oil for the anointing, and the incense of the composition, and the draw curtain of the door of the tent, 

#### Exodus 39:39 and the altar of brass, and its grate brass, and its bearing poles, all its items, and the bathing tub, and its base, 

#### Exodus 39:40 and the shrouds of the courtyard, and the posts, and its bases, and the draw curtain of the gate of the courtyard, and its lines, and its stanchions, and all the work tools, the ones for the works of the tent of the testimony, and the robes of the ministries for the ministering in them in the holy place, 

#### Exodus 39:41 and the apparels of the holy place which are for Aaron, and the apparels of his sons for the priesthood. 

#### Exodus 39:42 According to all as much as the LORD gave orders to Moses, thus {made the sons of Israel] all the accoutrements. And Moses saw all the works; and they were doing them in the manner the LORD gave orders 

#### Exodus 39:43 to Moses; thus they did them, and {blessed them Moses]. 

#### Exodus 40:1 And the LORD spoke to Moses, saying, 

#### Exodus 40:2 On day one of the month of the first new moon, you shall set up the tent of the testimony, 

#### Exodus 40:3 and you shall set up there the ark of the testimony, and you shall shelter the ark by the veil. 

#### Exodus 40:4 And you shall carry in the table, and you shall set its place setting. And you shall carry in the lamp-stand, and you shall place on it its lamps. 

#### Exodus 40:5 And you shall place the {altar golden] to burn incense before the ark of the testimony. And you shall place a covering veil upon the door of the tent. 

#### Exodus 40:6 And the altar of the yield offerings you shall put by the door of the tent of the testimony. 

#### Exodus 40:7 And you shall place the bathing tub between the tent of the testimony and between the altar. And you shall put {in it water]. 

#### Exodus 40:8 And you shall station the courtyard round about. And you shall station the veil of the gate of the courtyard. 

#### Exodus 40:9 And you shall take the oil of the scented unguent, and you shall anoint the tent, and all the things in it. And you shall sanctify it, and all its items. And it shall be holy. 

#### Exodus 40:10 And you shall anoint the altar of the yield offerings, and all its utensils. 

#### Exodus 40:11 And you shall anoint the bathing tub, and its base, and you shall sanctify it. And you shall sanctify the altar. And it will be the altar of the holy of the holies. 

#### Exodus 40:12 And you shall lead Aaron and his sons unto the doors of the tent of the testimony, and you shall bathe them in water. 

#### Exodus 40:13 And you shall put on Aaron the {apparels holy], and you shall anoint him, and you shall sanctify him, and he shall officiate as priest to me. 

#### Exodus 40:14 And his sons you shall lead forward, and you shall put on them inner garments. 

#### Exodus 40:15 And you shall anoint them in which manner you anointed their father, and they shall officiate as priests to me. And it will be so as to be to them an anointing priesthood into the eon, unto their generations. 

#### Exodus 40:16 And Moses did all as much as {gave charge to him the LORD] -- thus he did. 

#### Exodus 40:17 And it came to pass in the {month first], in the second year of their going forth from out of Egypt, at the new moon, {was set up the tent]. 

#### Exodus 40:18 And Moses set up the tent, and placed the tips, and inserted the bars, and set up its posts. 

#### Exodus 40:19 And he stretched out the curtains upon the tent, and they placed the {coverings tent] upon it from above -- as the LORD gave orders to Moses. 

#### Exodus 40:20 And taking the testimonies, he put them into the ark, and he placed the poles under the ark, and he placed the atonement-seat upon the ark. 

#### Exodus 40:21 And he carried the ark into the tent, and he set the covering of the veil, and it sheltered the ark of the testimony in which manner the LORD gave orders to Moses. 

#### Exodus 40:22 And he placed the table in the tent of the testimony, upon the side of the tent of the testimony, the one towards the north, from outside the veil of the tent. 

#### Exodus 40:23 And he set upon it the bread loaves of the place setting before the LORD, in which manner the LORD gave orders to Moses. 

#### Exodus 40:24 And he put the lamp-stand in the tent of the testimony before the table, to the side of the tent towards the south. 

#### Exodus 40:25 And he placed upon it its lamps before the LORD, in which manner the LORD gave orders to Moses. 

#### Exodus 40:26 And he put the {altar golden] in the tent of the testimony before the veil. 

#### Exodus 40:27 And he burned incense upon it, the incense of the composition, just as the LORD gave orders to Moses. 

#### Exodus 40:28 And he placed the draw curtain of the door of the tent. 

#### Exodus 40:29 And the altar of the yield offerings he put by the door of the tent of the testimony. And he offered on it a whole burnt-offering, and a sacrifice offering, as {gave orders the LORD] to Moses. 

#### Exodus 40:30 And he put the bathing tub between the tent of the testimony, and between the altar. And he placed {in it water] 

#### Exodus 40:31 for {to wash from it Moses and Aaron and his sons] their hands and feet, 

#### Exodus 40:32 in their entering into the tent of the testimony; or whenever they went to the altar to officiate, they washed from it, as the LORD gave orders to Moses. 

#### Exodus 40:33 And he set up the courtyard round about the tent and the testimony, and he stationed the draw curtain of the door of the courtyard. And Moses completed all the works. 

#### Exodus 40:34 And {covered the cloud] the tent of the testimony, and {of the glory of the LORD was filled the tent]. 

#### Exodus 40:35 And {was not able Moses] to enter into the tent of the testimony, for {overshadowed upon it the cloud], and {of the glory of the LORD was filled the tent]. 

#### Exodus 40:36 And when ever {ascended the cloud] from the tent, {broke camp the sons of Israel] with their chattel. 

#### Exodus 40:37 But if {ascends not the cloud], they did not break camp till the day which {ascended the cloud]. 

#### Exodus 40:38 For the cloud was upon the tent by day, and fire was upon it by night, before all Israel, in all their marchings.