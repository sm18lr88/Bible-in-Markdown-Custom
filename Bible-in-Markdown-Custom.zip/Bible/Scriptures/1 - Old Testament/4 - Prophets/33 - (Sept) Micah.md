#### Micah 1:1 And came to pass the word of the LORD to Micah the one of the Morasthite, in the days of Jotham, and Ahaz, and Hezekiah, kings of Judah, over what he saw concerning Samaria and concerning Jerusalem. 

#### Micah 1:2 Hear, O peoples, all the words! and take heed, O earth, and all the ones in it! Even {will be the LORD God} among you for a testimony -- the LORD from out of {house his holy}. 

#### Micah 1:3 For behold, the LORD goes forth from out of his place, and he will go down, and will mount upon the heights of the earth. 

#### Micah 1:4 And {shall be shaken the mountains} from beneath him, and the valleys shall melt away as beeswax from in front of fire, and as water being carried down in a descent. 

#### Micah 1:5 {are on account of the impiety of Jacob All these things}, and because of the sin of the house of Israel. What is the impiety of Jacob? Is it not Samaria? And what is the sin of the house of Judah? Is it not Jerusalem? 

#### Micah 1:6 And I will make Samaria for a storehouse of fruits of the field, and for planting a vineyard. And I will tear down in chaos her stones; and her foundations I will uncover. 

#### Micah 1:7 And all her carved images I will cut in pieces, and all her hires shall burn in fire, and all her idols I shall establish for extinction, because {of the hires of harlotry she gathered together}, and of the hires of harlotry he eradicated. 

#### Micah 1:8 Because of this she shall beat her chest and wail. She shall go barefoot and naked. She shall make a beating of the breast as dragons, and mourning as the daughters of sirens. 

#### Micah 1:9 For {holds firmly her calamity}; because it went unto Judah; and it touched unto the gate of my people, unto Jerusalem. 

#### Micah 1:10 O ones in Gath, do not magnify yourselves! And, O ones in Baceim, do not rebuild of your house with laughter! {earth Strew} on your laughter! 

#### Micah 1:11 Her inhabiting well her cities did not come forth. Her inhabiting Zaanan to beat her chest for the house next to her; she shall receive from your calamity of grief. 

#### Micah 1:12 Who began to act for good to her dwelling in griefs? for {came down bad things} from the LORD upon the gates of Jerusalem; 

#### Micah 1:13 even noise of chariots and ones riding. Dwelling Lachish {the head of sin is} to the daughter of Zion; for in you they found the impious deeds of Israel. 

#### Micah 1:14 On account of this he shall grant ones to be sent forth unto the inheritance of Gath, {houses the vain}; for {vanity they became} to the kings of Israel; 

#### Micah 1:15 until {the heirs they should bring} to you, O inhabitant of Lachish, your inheritance. Unto Adullam {shall come glory of the daughter of Israel}. 

#### Micah 1:16 Shave and shear for {children your delightful}, widening your shaving as an eagle, for they were taken captive from you. 

#### Micah 2:1 They came devising troubles, and working evils on their beds, and together during the day they complete them; for they lifted not {to God their hands}. 

#### Micah 2:2 And they desired fields, and they plundered orphans, and {households tyrannized}, and plundered a man and his house, a man and his inheritance. 

#### Micah 2:3 On account of this, thus says the LORD, Behold, I devise against this tribe bad things, of which in no way should you lift your necks, and in no way should you be able to go straight; for {time it is a wicked}. 

#### Micah 2:4 In that day there shall be taken up against you a parable, and {shall be wailed a lament} in a strain, saying, With misery we were miserable; the portion of my people was measured out with a measuring line, and there was none restraining him to return. Your fields were divided. 

#### Micah 2:5 On account of this, there will not be for you one putting a measuring line for a lot in the assembly of the LORD. 

#### Micah 2:6 Weep not tears, nor burst into tears over these things! For he will not thrust away the scorn. 

#### Micah 2:7 The one saying, The house of Jacob provoked to anger the spirit of the LORD; {these his practices are}? Are not his words good with him, and straight going? 

#### Micah 2:8 And in former times my people {for enmity opposed} against his peace; his skin they flayed to remove hope of the conflict of war. 

#### Micah 2:9 The ones leading my people shall be thrown from out of {houses their luxurious}. Because of {wicked practices their} they were pushed out. Approach {mountains to everlasting}! 

#### Micah 2:10 Rise up and go! for there is not to you this rest. Because of uncleanness you were corrupted by corruption. 

#### Micah 2:11 You were pursued by no one pursuing. Your spirit established lying, it trickled you with wine and for strong drink; and it will be from the drop of this people. 

#### Micah 2:12 In being gathered Jacob shall be brought together with all. In looking out I shall look out for the remnant of Israel. Together I will establish their return, as sheep in affliction; as a flock in the midst of their fold, they leap out because of men. 

#### Micah 2:13 Ascend through the breach before in front of them! They cut through and went through the gate, and came forth through it; and {went forth their king} before in front of them; and the LORD shall lead them. 

#### Micah 3:1 And he shall say, Hear indeed, O heads of Jacob, and O remnant of the house of Israel! {not for you Is it} to know equity? 

#### Micah 3:2 O ones detesting the good things, and seeking the wicked things; seizing by force their skins from them, and their flesh from their bones; 

#### Micah 3:3 in which manner they devoured the flesh of my people, and their skins they flayed from them, and their bones they fractured in pieces as flesh for the kettle, and as meats for the pot. 

#### Micah 3:4 Thus they shall cry out to the LORD, and he will not listen to them. And he shall turn his face from them in that time, because they were wicked in their practices. 

#### Micah 3:5 Thus says the LORD concerning the prophets, of the ones misleading my people; the ones biting with their teeth, and proclaiming peace upon them, and when nothing was put into their mouth, they even sanctified {against them a war}. 

#### Micah 3:6 On account of this {night to you there shall be} instead of a vision; and darkness will be to you for divination; and {shall go down the sun} upon the prophets, and {shall darken upon them the day}. 

#### Micah 3:7 And {shall be disgraced the ones seeing the dreams}; and {shall be ridiculed the clairvoyants}; and {shall speak ill against them all these}; because there is not one heeding them. 

#### Micah 3:8 Surely I shall fill up strength in spirit of the LORD, and judgment, and might, to report to Jacob of his impiety, and to Israel of his sins. 

#### Micah 3:9 Hear indeed these things, O leaders of the house of Jacob, and, O remnants of the house of Israel! the ones abhorring equity, and all the ones {straight things perverting}; 

#### Micah 3:10 the ones building Zion with blood, and Jerusalem with injustice. 

#### Micah 3:11 Her leaders {with bribes judge}, and her priests {with a wage answer}, and her prophets {with silver are divining}; but upon the LORD they rest upon, saying, {not the LORD among us is}? In no way shall {come upon us bad things}. 

#### Micah 3:12 On account of this, because of you, Zion {as a field shall be plowed}, and Jerusalem {as a vacant storehouse of fruits will be}, and the mountain of the house as a place of the forest. 

#### Micah 4:1 And {will be at the last of the days apparent the mountain of the LORD}, readied upon the tops of the mountains, and it shall rise up high above the hills; and {shall hasten to it peoples}. 

#### Micah 4:2 And {shall go nations many}, and shall say, Come, we should ascend unto the mountain of the LORD, and unto the house of the God of Jacob; and they shall show us his way, and we shall go by his roads. For from out of Zion shall go forth the law, and the word of the LORD from out of Jerusalem. 

#### Micah 4:3 And he shall judge between {peoples many}, and shall completely refute {nations strong} unto afar. And they shall cut their broadswords into plows, and their spears into sickles. And no longer should {raise up a nation against a nation a broadsword}, and no longer should they learn to wage war. 

#### Micah 4:4 And {shall rest each} underneath his grapevine, and each underneath his fig-tree. And there shall not be one frightening them, because the mouth of the LORD almighty spoke these things. 

#### Micah 4:5 For all the peoples shall go each in his own way; but we shall go in the name of the LORD our God into the eon and beyond. 

#### Micah 4:6 In that day, says the LORD, I will gather together her being broken, and her being thrust away. I will take in even whom I thrusted away. 

#### Micah 4:7 And I will make her being broken into a vestige, and her being thrust away into {nation a mighty}. And the LORD shall reign over them on mount Zion, from the present and unto the eon. 

#### Micah 4:8 And you, O tower of the flock, austere daughter of Zion, unto you shall come, and shall enter in the head of the foremost kingdom of Babylon to the daughter of Jerusalem. 

#### Micah 4:9 And now, why did you know bad things? {not a king Was} in you? Or has your counsel perished? For {hold firmly your pangs} as one giving birth. 

#### Micah 4:10 Travail, and take courage, O daughter of Zion, as the one giving birth! For now you shall come forth from the city, and shall encamp in the plain, and shall come unto Babylon. From there he shall rescue you, and from there he shall ransom you, the LORD your God, from the hand of your enemies. 

#### Micah 4:11 And now {were assembled against you nations many}, saying, We shall rejoice and scrutinize over Zion with our eyes. 

#### Micah 4:12 But they knew not the devices of the LORD, and perceived not his counsel. For he gathered them as sheaves for the threshing-floor. 

#### Micah 4:13 Rise up and thresh them, O daughter of Zion! For {your horns I will make} iron, and your hoofs I will make brass, and I will dissolve {peoples many}. And you shall present to the LORD their abundance, even their strength to the LORD of all the earth. 

#### Micah 5:1 Now {shall be obstructed the daughter} by an obstruction. {conflict He ordered} for us. {with a rod They shall strike} upon the jaw the tribes of Israel. 

#### Micah 5:2 And you, Beth-lehem, of the house of Ephratah, are very few being among thousands of Judah; from out of you to me shall come forth the one being for ruler of Israel; and his goings forth were from the beginning, from {of days eon}. 

#### Micah 5:3 On account of this, he will appoint them unto a time of giving birth. She shall give birth, and the remnants of their brethren shall return unto the sons of Israel. 

#### Micah 5:4 And he shall stand and tend in strength of the LORD; and in the glory of the name of the LORD their God they shall exist; for now he shall be magnified unto the uttermost parts of earth. 

#### Micah 5:5 And this shall be the peace, whenever the Assyrian should come upon our land, and whenever he should mount upon our place. And there shall be roused up against him seven shepherds, and eight strikes of men. 

#### Micah 5:6 And they shall tend Assyria with a broadsword, and the land of Nimrod at her trench. And he shall rescue from Assyria whenever it should come against your land, and whenever it should mount over your borders. 

#### Micah 5:7 And {will be the vestige of Jacob} in the midst {peoples of many}, as the dew from the LORD falling, and as lambs upon wild grass; so that it should be gathered to no one, nor should stand among the sons of men. 

#### Micah 5:8 And {will be the vestige of Jacob} among the nations, in the midst {peoples of many}, as a lion among cattle in the forest, and as a cub among the flocks of sheep, in which manner whenever he should go through and draw apart to seize his prey by force, and there should be none rescuing. 

#### Micah 5:9 {shall be raised up high Your hand} against the ones afflicting you, and all your enemies shall be utterly destroyed. 

#### Micah 5:10 And it will be in that day, says the LORD, I will utterly destroy your horses from out of your midst, and I will destroy your chariots. 

#### Micah 5:11 And I will utterly destroy the cities of your land, and I will remove all your fortresses. 

#### Micah 5:12 And I will utterly destroy your potions from out of your hands; and ones declaring fortunes shall not be to you. 

#### Micah 5:13 And I will utterly destroy your carved images, and your monuments from out of your midst. And no longer should you do obeisance to the works of your hands. 

#### Micah 5:14 And I will cut your sacred groves from out of your midst; and I will obliterate your cities. 

#### Micah 5:15 And I will execute in anger and in rage vengeance among the nations, because they listened not. 

#### Micah 6:1 Hear indeed what the LORD said! Rise up, plead with the mountains, and let {hear the hills} your voice! 

#### Micah 6:2 Hear, O mountains, the judgment of the LORD, and O ravines, foundations of the earth! For there is a case with the LORD against his people; and with Israel he will plead. 

#### Micah 6:3 O my people, what did I to you, or how did I trouble you? Answer me! 

#### Micah 6:4 For I led you out of the land of Egypt; and from out of the house of slavery I ransomed you. And I sent out before your face Moses and Aaron and Miriam. 

#### Micah 6:5 O my people, remember indeed what {planned against you Balak king of Moab}! and what {answered to him Balaam son of Beor}, from the rushes unto Gilgal, so that {should be known the righteousness of the LORD}. 

#### Micah 6:6 By what means should I overtake the LORD? Shall I take hold of my God the highest? Shall I overtake him with a whole burnt-offering, with calves of a year old, no. 

#### Micah 6:7 Shall the LORD favorably receive a thousand rams, or myriads {winter yearlings of hearty}, no. Shall I give my first-born for my sin offering, no. the fruit of my belly for impiety of my soul, no. 

#### Micah 6:8 He explained to you, O man, what is good or what the LORD requires from you; but only to execute equity, and to love mercy, and to be prepared to go with your God. 

#### Micah 6:9 The voice of the LORD {in the city shall be called upon}, and he shall deliver ones fearing his name. Hear, O tribe! and who shall adorn the city? 

#### Micah 6:10 Is there not fire, and the house of the lawless one treasuring up treasures of lawless deeds, and with {insolence unrighteous}? 

#### Micah 6:11 Shall {be justified by a yoke balance scale the lawless one}, or by a bag {weights of deceitful}, 

#### Micah 6:12 of which {their riches of impiety they filled}, and the ones dwelling it spoke lies, and their tongue was exalted in their mouth, no. 

#### Micah 6:13 And I tormented you for extinction on account of your sins. 

#### Micah 6:14 You shall eat, and in no way be filled up. And I shall banish you to yourself, and you shall be forsaken, and in no way should you be preserved; and as many as should be preserved {unto the broadsword shall be delivered up}. 

#### Micah 6:15 You shall sow, but you shall not reap; you shall compress the olive, but in no way should you anoint with olive oil; and wine, and in no way shall you drink; and {shall be obliterated the laws of my people}. 

#### Micah 6:16 For you kept the ordinances of Omri, and all the works of the house of Ahab. And you went by their plans, so that I should deliver you unto extinction, and the ones dwelling her for a hissing; and {scorn of peoples you shall receive}. 

#### Micah 7:1 Alas, for I became as one gathering stubble in a harvest, and as {grape gleanings one gathering} where there does not exist a cluster of {grapes to eat first-ripe}, which {longs after my soul}. Woe O soul. 

#### Micah 7:2 For {is destroyed the reverent one} from the earth; and {one keeping straight among men there does not exist}. All {unto blood adjudicate}; each {his neighbor squeezes out} by oppression; 

#### Micah 7:3 {for evil their hands they prepare}; the ruler asks for gifts, and the judge {peaceable words for bribes speaks}. {the wish of his soul It is}. 

#### Micah 7:4 And I will take out their good things, as a moth chews away, and one proceeding by the rule in the day of the watch. Woe, your punishments came, now there shall be their weeping. 

#### Micah 7:5 Do not confide in friends; do not hope upon leaders; of your bed-mate watch out to not present anything to her. 

#### Micah 7:6 For the son dishonors the father; the daughter rises up against her mother, the daughter-in-law against her mother-in-law; enemies are all the men, the ones in his own house. 

#### Micah 7:7 But I {upon my LORD will look}; I will wait upon the LORD my deliverer. {will listen to me My God}. 

#### Micah 7:8 Rejoice not against me, O my enemy! for I have fallen and I will rise up. For if I shall sit in the darkness, the LORD will give light to me. 

#### Micah 7:9 The anger of the LORD I shall endure, for I sinned against him, until he does justice to my cause, and shall execute my judgment. He shall lead me into the light; I shall see his righteousness. 

#### Micah 7:10 And {shall see my enemy} and shall wear shame, saying to me, Where is the LORD your God? My eyes shall scrutinize her, now she will be for trampling upon as mud in the ways. 

#### Micah 7:11 A day of plastering of brick is your wiping out, and {shall be thrust away your laws} in that day. 

#### Micah 7:12 And your cities shall come unto leveling, and into partition by the Assyrians; and {cities your fortified} for partitioning from Tyre unto the river, and from sea unto sea, and from mountain unto mountain. 

#### Micah 7:13 And {will be the land} for extinction with the ones dwelling it, because of the fruits of their practices. 

#### Micah 7:14 Tend your people with your rod, the sheep of your inheritance, the ones encamping by themselves in a forest, in the midst of Carmel! They shall feed Bashan, and Gilead, according to the days of the eon. 

#### Micah 7:15 And according to the days of your departure from the land of Egypt, I will show to them wonderful things. 

#### Micah 7:16 {shall see Nations} and shall be disgraced, even of all their strength. They shall place hands over their mouth, their ears shall be deafened. 

#### Micah 7:17 They shall lick dust as serpents dragging on the earth; they shall be confounded in their confinement; by the LORD our God they shall be amazed, and shall fear from you. 

#### Micah 7:18 What God is as you, removing iniquities and passing over impiety to the remnants of his inheritance? {is not constrained for a testimony His anger}, for {a wisher of mercy he is}. 

#### Micah 7:19 He shall turn and shall pity us; he shall sink our iniquities, and shall throw away into the depths of the sea all our sins. 

#### Micah 7:20 He shall give truth to Jacob, mercy to Abraham, in so far as you swore an oath to our fathers, according to the {days former}.