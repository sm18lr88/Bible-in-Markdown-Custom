#### Haggai 1:1 In the second year of Darius the king, in the {month sixth}, day one of the month, came the word of the LORD by the hand of Haggai the prophet, saying, Say to Zerubbabel the son of Shealtiel, from the tribe of Judah, and to Joshua the son of Josedech the {priest great}, saying, 

#### Haggai 1:2 Thus says the LORD almighty, saying, This people say, {is not come The time} to build the house of the LORD. 

#### Haggai 1:3 And came to pass the word of the LORD by the hand of Haggai the prophet, saying, 

#### Haggai 1:4 Is {indeed time for you it} to live in {houses your vaulted}, but this house is quite desolate? 

#### Haggai 1:5 And now, thus says the LORD almighty, Arrange your hearts for your journeys! 

#### Haggai 1:6 You sowed much, and carried in little; you ate and not unto fullness; you drank and not unto intoxication; you clothed yourselves, and were not heated by these; and the one of the ones {wages gathering} gathered them in a bundle having holes being made in it. 

#### Haggai 1:7 Thus says the LORD almighty, Establish your hearts for your journeys! 

#### Haggai 1:8 Ascend into the mountain, and cut wood! and you shall build the house. And I will think well by it, and I will be glorified, said the LORD. 

#### Haggai 1:9 You looked for much, and there became little; and it was carried into the house, and I blew it away. On account of this, thus says the LORD almighty, Because my house is deserted, and you {pursue each} unto his own house. 

#### Haggai 1:10 On account of this {withholds the heaven} of dew, and the earth keeps back its resources. 

#### Haggai 1:11 And I will bring the broadsword upon the land, and upon the mountains, and upon the grain, and upon the wine, and upon the olive oil, and as much as {brings forth the earth}, and upon the men, and upon the cattle, and upon all the toils of their hands. 

#### Haggai 1:12 And they heard (Zerubbabel the son of Shealtiel from the tribe of Judah, and Joshua the son of Josedech the {priest great}, and all the rest of the people) the voice of the LORD their God, and the words of Haggai the prophet, in so far as what {sent him the LORD their God} for them. And {feared the people} from in front of the LORD. 

#### Haggai 1:13 And {said Haggai the messenger of the LORD} among the messengers of the LORD, Say to the people! I am with you, says the LORD. 

#### Haggai 1:14 And the LORD awakened the spirit of Zerubbabel the son of Shealtiel from the tribe of Judah, and the spirit of Joshua the son of Josedech the {priest great}, and the spirit of the rest of the people. And they entered and did the works in the house of the LORD almighty, their God, 

#### Haggai 1:15 on the fourth and twentieth day of the {month sixth}, in the second year of Darius the king. 

#### Haggai 2:1 In the seventh month, one and twentieth day of the month, came to pass the word of the LORD by the hand of Haggai the prophet, saying, 

#### Haggai 2:2 Speak indeed to Zerubbabel the son of Shealtiel of the tribe of Judah, and to Joshua the son of Josedech the {priest great}, and to all the ones left of the people, saying, 

#### Haggai 2:3 Who is there of you who beheld this house in the {glory of it former}? And how do you see it now? Is it as not existing before you? 

#### Haggai 2:4 And now, take strength, O Zerubbabel, says the LORD! And take strength, O Joshua, son of Josedech the {priest great}! and let {grow strong all the people of the land}! says the LORD, and act! For I {with you am}, says the LORD almighty. 

#### Haggai 2:5 The word which I ordained with you in your coming forth from Egypt, and my spirit I set in the midst of you -- take courage! 

#### Haggai 2:6 For thus says the LORD almighty, Still once I shall shake the heaven, and the earth, and the sea, and the dry land. 

#### Haggai 2:7 And I shall shake all the nations. And {shall come the chosen of all the nations}, and I will fill this house with glory, says the LORD almighty. 

#### Haggai 2:8 Mine is the silver, and mine is the gold, says the LORD almighty. 

#### Haggai 2:9 For great will be the glory of this house, the last one above the first, says the LORD almighty. And in this place I will establish peace, says the LORD almighty; even peace of soul for the procurement to every one creating to raise up this temple. 

#### Haggai 2:10 In the fourth and twentieth day in the ninth month, in the {year second} of Darius, came to pass the word of the LORD to Haggai the prophet, saying, 

#### Haggai 2:11 Thus says the LORD almighty, Ask indeed of the priests concerning the law! saying, 

#### Haggai 2:12 If {took a man meat holy} with the tip of his garment, and there touched the tip of his garment some bread, or stew, or wine, or olive oil, or any food, shall it be sanctified? And {answered the priests} and said, No. 

#### Haggai 2:13 And Haggai said, If {should touch one being defiled} upon a dead soul of any of these, shall he be defiled? And {answered the priests} and said, He shall be defiled. 

#### Haggai 2:14 And Haggai answered and said, So this people, and so this nation is before me, says the LORD; and so all the works of their hands; and whoever should approach unto there shall be defiled; because of their concerns of the early morning burdens; they shall grieve from in front of their wickednesses; and you detested the ones {at the doors reproving}. 

#### Haggai 2:15 And now, set it indeed upon your hearts from this day and above, before putting stone upon stone in the temple of the LORD, 

#### Haggai 2:16 what you were when you put into the granary {of barley twenty seahs}, and there existed only ten seahs of barley. And you entered into the wine-vat to draw out fifty measures, and there existed only twenty. 

#### Haggai 2:17 I struck you with being non-productive, and with being wind-blown, and with hail upon all the works of your hands; and you did not turn to me, says the LORD. 

#### Haggai 2:18 Arrange indeed your hearts from this day and beyond! From the fourth and twentieth day of the ninth month, and from the day of which {was laid a foundation the temple of the LORD}, establish it in your hearts! 

#### Haggai 2:19 Shall yet it be recognized upon the threshing-floor, no. And shall yet the grapevine, and the fig-tree, and the pomegranate, and the trees of the olive, the ones not bearing fruit be recognized, no. From this day I shall bless. 

#### Haggai 2:20 And came to pass the word of the LORD the second time to Haggai the prophet, the fourth and twentieth day of the month, saying, 

#### Haggai 2:21 Speak to Zerubbabel the son of Shealtiel, of the tribe of Judah, saying, I shall shake the heaven, and the earth, and the sea, and the dry land. 

#### Haggai 2:22 And I shall eradicate thrones of kings, and I shall annihilate the power of kings of the nations. And I shall eradicate chariots and riders. And there shall come down horses and their riders, each with a broadsword against his brother. 

#### Haggai 2:23 In that day, says the LORD almighty, I will take you Zerubbabel the son of Shealtiel my servant, says the LORD, and I will set you as a seal. For I have selected you, says the LORD almighty.