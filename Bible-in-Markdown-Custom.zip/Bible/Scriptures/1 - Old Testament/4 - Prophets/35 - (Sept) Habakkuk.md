#### Habakkuk 1:1 The concern which {saw Habakkuk the prophet}. 

#### Habakkuk 1:2 For how long, O LORD, shall I cry out, and in no way should you listen? For how long shall I yell to you being wronged, and you should not deliver? 

#### Habakkuk 1:3 Why did you show to me toils and troubles, to look upon misery and impiety? Right opposite me takes place judgment, and the judge takes away. 

#### Habakkuk 1:4 On account of this {is effaced the law}, and {is not administered unto the end judgment}, for the impious tyrannize over the just. Because of this {shall go forth judgment} being perverted. 

#### Habakkuk 1:5 Behold, O despisers, and look! and wonder wonders, and vanish! For {a work I work} in your days which in no way you shall believe if any should tell of it in detail. 

#### Habakkuk 1:6 For behold, I awaken the Chaldeans, the {nation bitter and quick}; the one going upon the widths of the earth, to inherit tents not of his. 

#### Habakkuk 1:7 {fearful and apparent He is}; {of himself his judgment will be}, and his concern of himself shall come forth. 

#### Habakkuk 1:8 And {shall leap more than leopards his horses}, and are sharper than the wolves of Arabia. And {shall ride forth his horsemen}, and shall advance far off; and they shall spread out as an eagle eager for something to eat. 

#### Habakkuk 1:9 Consumption {unto the impious shall come} opposing their fronts right opposite, and he shall gather {as the sand the captivity}. 

#### Habakkuk 1:10 And he {among kings shall revel}, and sovereigns are his playthings. And he {at every fortress shall mock}, and shall throw up an embankment, and shall prevail over it. 

#### Habakkuk 1:11 Then he shall turn the spirit, and shall go through, and shall make atonement, saying, This strength is to my god. 

#### Habakkuk 1:12 Are you not from the beginning, O LORD my God, my holy one? In no way should we die. O LORD, for judgment -- you have ordered it. And he shaped me to reprove for his discipline. 

#### Habakkuk 1:13 Pure is the eye to not see evil things, and {to look upon evils you are not able}. Why should you look upon ones disdaining? Shall you remain silent in the {swallowing down impious} the just? 

#### Habakkuk 1:14 And will you make the men as the fishes of the sea, and as the reptiles not having one taking the lead? 

#### Habakkuk 1:15 {consumption with a hook He pulled up}, and drew it with his casting-net, and gathered it in his dragnets. Because of this he shall be glad and shall rejoice. 

#### Habakkuk 1:16 Because of this he will sacrifice to his dragnet, and burn incense to his casting-net; for by them he fattened his portion, even {foods his choice}. 

#### Habakkuk 1:17 On account of this he will cast his casting-net, and always to kill nations -- not sparing? 

#### Habakkuk 2:1 Upon my watch I will stand, and I will mount upon a rock. And I will watch over to behold what he should speak in me, and what I will answer upon my being reproved. 

#### Habakkuk 2:2 And {answered to me the LORD} and said, Write the vision clearly onto a writing-tablet, so that {should take flight the one reading these things}. 

#### Habakkuk 2:3 For the vision is yet for a time, and it shall rise in the end, and not in vain. If he should lack, wait for him! for in coming he shall come and in no way should he delay. 

#### Habakkuk 2:4 If he keeps back, {favors not my soul} in him; but the just one {by my belief shall live}. 

#### Habakkuk 2:5 But the one being arrogant and despising, {man the ostentatious}, not one thing in any way should he have achieved, who widened {as Hades his soul}, and so as death not being filled up, even he shall assemble unto himself all the nations, and will take in to himself all the peoples. 

#### Habakkuk 2:6 {not these all a parable against him Shall take up}, and a riddle for his narrative? And they shall say, Woe, the one multiplying to himself the things not being his -- how long? even the one oppressing his collar densely. 

#### Habakkuk 2:7 For suddenly {shall raise up ones biting him}, and {shall sober up the plotters against you}, and you will be for ravaging to them. 

#### Habakkuk 2:8 Because you despoiled {nations many}, {shall despoil you all the being left peoples}, because of the blood of men, and the impious deeds of the land and city, and all of the ones dwelling in it. 

#### Habakkuk 2:9 O, the one overabounding in a desire for {wealth evil} to his house, to arrange {in the height his nest}, to pull out from the hand of evils. 

#### Habakkuk 2:10 You deliberated shame to your house; you finished off many peoples, and {was led into sin your soul}. 

#### Habakkuk 2:11 For the stone {from the wall shall yell out}; and the beetle from out of the wood shall utter its sounds. 

#### Habakkuk 2:12 Woe, the one building a city in blood, and prepares a city by iniquities. 

#### Habakkuk 2:13 {these not Are} from the LORD almighty that {failed peoples fit} by fire, and {nations many}, and they became faint-hearted? 

#### Habakkuk 2:14 For {shall be filled the earth} to know the glory of the LORD, as water covers up seas. 

#### Habakkuk 2:15 O, the one giving a drink to his neighbor {diet of lees a clouded and intoxicating}, so that he should look upon their private parts. 

#### Habakkuk 2:16 {to the fullness of the dishonor of your glory Drink}, and be excited! {encircled you The cup of the right hand of the LORD}, and {was brought dishonor} upon your glory. 

#### Habakkuk 2:17 For the impiety of Lebanon shall cover you, and the misery from wild beasts shall terrify you, because of the blood of men, and the impious deeds of the land, and of the city, and of all the ones dwelling it. 

#### Habakkuk 2:18 What benefit is the carved image that they carved it? He shaped it for a molten casting, {visible display a false}. For {has relied the one shaping} upon the thing shaped by him in the making of {idols mute}. 

#### Habakkuk 2:19 Woe, the one saying to the wood, Sober up, arise! And to the stone, Be exalted! But it is only a visible display, and it is a hammered piece of gold and silver, and {at all no breath} is in it. 

#### Habakkuk 2:20 But the LORD is in {temple his holy}; let {venerate from before him all the earth}! 

#### Habakkuk 3:1 The prayer of Habakkuk the prophet with an ode. 

#### Habakkuk 3:2 O LORD, I listened to your report, and I feared. O LORD, I contemplated your works, and was startled. In the midst of the two living creatures you shall be known; in the approaching of the years you shall be recognized; in the {at hand time} you shall be made manifest when {is disturbed my soul}; in wrath {mercy you shall remember}. 

#### Habakkuk 3:3 God {from out of Teman shall come}, even the holy one from out of the mount of the shady Paran. PAUSE. {covered the heavens His virtue}, and his praise filled the earth. 

#### Habakkuk 3:4 And his brightness {as light will be}, and horns in his hands. And he established {affection a strong} by his strength. 

#### Habakkuk 3:5 Before his face shall go a word, and it shall go forth for a flat ground. 

#### Habakkuk 3:6 At his feet {stood and shook the earth}; he looked and {melted nations}; {were broke through the mountains} by force; {melted away hills the eternal} -- {ways his eternal}. 

#### Habakkuk 3:7 {in troubles I beheld the tents of Ethiopians}, {shall be disturbed and the tents of the land of Midian}. 

#### Habakkuk 3:8 Were {at the rivers you provoked to anger}, O LORD, or {at the rivers was your rage}, or {at the sea was your impulse}? The one riding upon your horses, and your riding is deliverance. 

#### Habakkuk 3:9 Stretching out, you shall stretch out your bow against the chiefdoms, says the LORD. PAUSE. {of rivers shall be torn The land}. 

#### Habakkuk 3:10 They saw you, and {shall travail peoples}. You shall disperse waters of the coursing. {gave out The abyss} her voice -- the height of his visible display. 

#### Habakkuk 3:11 {was exalted The sun}, and the moon stood in her order. At the light of your arrows they shall go forth, and {in brightness of lightning your weapons}. 

#### Habakkuk 3:12 By intimidation you shall make {few the land}, and in rage you shall break nations. 

#### Habakkuk 3:13 You came forth for deliverance of your people, to deliver your anointed one. You threw {onto the heads of lawless ones death}; {you rose bonds unto the neck For the completion}. 

#### Habakkuk 3:14 You cut {for astonishment heads of mighty ones}; they shall shake in it; they shall open wide their bridles as the {eating poor} in private. (3:14) You divided into parts in stupefaction the heads of the mighty. They shall shake in it. They shall open their reins as {chewing the poor} in concealment. 

#### Habakkuk 3:15 And you conducted {into the sea your horses}, disturbing {waters great}. 

#### Habakkuk 3:16 I watched, and {was terrified my belly} from the sound of the prayer of my lips; and {entered trembling} into my bones, and my part beneath. {was disturbed My manner}. I will rest in a day of my affliction for me to ascend to the people of my sojourn. 

#### Habakkuk 3:17 For though the fig-tree shall not bear fruit, and there shall not be produce on the grapevines; {shall lie and the work of the olive}, and the plains shall not produce food, {cease from having food and sheep}, and {shall not exist the oxen} at the stables; 

#### Habakkuk 3:18 yet I {in the LORD shall exult}; I will rejoice over God my deliverer. 

#### Habakkuk 3:19 The LORD God is my power, and he will arrange my feet unto completion; and upon the high places he shall set me, for me to overcome by his ode.