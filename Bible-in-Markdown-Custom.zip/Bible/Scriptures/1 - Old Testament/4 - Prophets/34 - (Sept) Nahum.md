#### Nahum 1:1 The concern for Nineveh. The scroll of the vision of Nahum the Elkoshite. 

#### Nahum 1:2 God is jealous, and the LORD is punishing; the LORD is punishing with rage; the LORD is punishing his adversaries, and lifting away himself of his enemies. 

#### Nahum 1:3 The LORD is lenient, and great is his strength; and {one as innocent will not acquit the LORD}; {is by consummation and by a rumbling his way}, and the clouds are the dust of his feet; 

#### Nahum 1:4 the one pressing together the sea, and the one drying it, and {all the rivers making quite desolate}. {are lessened Bashan and Carmel}, and the blossoming of Lebanon failed. 

#### Nahum 1:5 The mountains shake from him, and the hills are shaken, and {rises upwards the earth} at his presence; the whole, and all the ones dwelling in it. 

#### Nahum 1:6 From in front of his anger who shall stand, and who shall withstand in the anger of his rage? His rage melts away sovereignties, and the rocks are broken because of him. 

#### Nahum 1:7 Gracious is the LORD to the ones waiting on him in the day of affliction; and he is knowing of the ones venerating him. 

#### Nahum 1:8 And by a flood coursing {a consummation he shall execute} of the ones rousing up; and {his enemies shall pursue darkness}. 

#### Nahum 1:9 What do you devise against the LORD? {a consummation He himself will make}. He will not punish twice for the same thing with affliction. 

#### Nahum 1:10 For the enemy {unto his foundation will be made barren}, and as a yew tree being twisted he shall be devoured, even as stubble he shall be dried up fully. 

#### Nahum 1:11 From out of you shall come forth a device against the LORD, {wicked things planning} adverse to him. 

#### Nahum 1:12 Thus says the LORD, who rules many waters, And so they shall be drawn apart, and the report of you shall not be listened to attentively any longer. 

#### Nahum 1:13 And now I will break his rod from you, and the bonds I will tear up. 

#### Nahum 1:14 And {shall give charge concerning you the LORD}, There shall not be sown the report of your name any longer from out of the house of your god; I will utterly destroy the carved images, and the molten images; I will establish your burial, and that quickly. 

#### Nahum 1:15 Behold upon the mountains the feet announcing good news, and reporting peace. Solemnize, O Judah, your holidays! Render your vows! For in no way should they proceed any longer to go through you, for they should have grown old. 

#### Nahum 2:1 He is finished, he is consumed, {ascended breathing in your face the one being lifted away from out of affliction}. Watch the way! Hold the loin! Be {manly in strength very}! 

#### Nahum 2:2 For the LORD perverted the insolence of Jacob, as the insolence of Israel; for the ones shaking off shook them off, and {their vine branches they ruined}. 

#### Nahum 2:3 The weapons of his command of men {men are mighty} mocking with fire; the reins of their chariots in the day of his preparation, and the horsemen shall be making a disruption. 

#### Nahum 2:4 In the ways; {shall be in tumult the chariots}, and shall be closely joined in the squares; the sight of them as lamps of fire, and as lightnings running along. 

#### Nahum 2:5 And {shall be remembering their great men}, and shall flee by day; and they shall be weak in their goings; and they shall hasten unto the walls, and they shall prepare {advance guards their}. 

#### Nahum 2:6 Gates of the cities were opened wide, and the palaces fell into ruin, 

#### Nahum 2:7 and the support was uncovered; and she ascended, and her maidservants were led away as doves, uttering sounds in their hearts. 

#### Nahum 2:8 And Nineveh, {are as a pool of water her waters}; and they fleeing did not stand, and there was none paying attention. 

#### Nahum 2:9 They plundered the silver, they plundered the gold, and there was no limit to her decoration; they were weighed down by all {items her desirable}. 

#### Nahum 2:10 Thrusting and violent shaking, and tumult, and heart breaking, and loosening of the knees, and pangs on every loin, and the face of all as a burnt earthen pot. 

#### Nahum 2:11 Where is the home of the lions, and the pasture being to the cubs? Where {go did the lion}, for {to enter there cub the lion}, and there was none frightening? 

#### Nahum 2:12 The lion seized by force the things fit for his cubs, and choked prey for his young lions, and filled {with game his nest}, and his home of things of seizure. 

#### Nahum 2:13 Behold, I am against you, says the LORD almighty, and I will burn away {in smoke multitude your}, and your lions I will devour by the broadsword, and I will utterly destroy {from out of the land your game}, and in no way should {be heard of yet your works}. 

#### Nahum 3:1 O city of blood, entirely false, {of iniquity full}, {shall not be handled the game}. 

#### Nahum 3:2 The sound of whips, and the sound of quaking of wheels, and {horse the pursuing}, and the chariot stirring up, 

#### Nahum 3:3 horseman ascending, and of the shining broadsword, and flashing shields; and the multitude of slain, and of a heavy downfall; and there was no limit to her nations, and they shall be weak in their bodies from a multitude of harlotry; 

#### Nahum 3:4 {harlot a good}, and gratifying, taking the lead in potions; the one selling nations in her harlotry, and tribes with her potions. 

#### Nahum 3:5 Behold, I am against you, says the LORD almighty. And I will uncover your behind in your presence, and I will show the nations your shame, and to kingdoms your dishonor. 

#### Nahum 3:6 And I will cast upon you an abomination according to your uncleannesses, and I will make you for an example. 

#### Nahum 3:7 And it will be all the ones seeing you shall go from you, and shall say, Wretched Nineveh, who shall moan her? From what place shall I seek comfort to her? 

#### Nahum 3:8 Tune the string of the lyre! Prepare a part for Amon, the one inhabiting in rivers! Water is round about her, whose rule is the sea, and {water her walls}. 

#### Nahum 3:9 Ethiopia is her strength, and Egypt. And there stood no limit of your flight into exile. Put and Libya became her helpers. 

#### Nahum 3:10 And she into displacement shall go captive; and her infants they shall dash upon corners of all her ways; and over all her honorable things they shall cast lots, and all her great men shall be tied with manacles. 

#### Nahum 3:11 And you shall be intoxicated. And you shall be for overlooking, and you shall seek for yourself a position from enemies. 

#### Nahum 3:12 All your fortresses are as you, {fruits having}, and if they should be shaken, they shall fall into the mouth of ones eating. 

#### Nahum 3:13 Behold, your people are as women among you to the ones your enemies. By opening {shall be open the gates of your land}. {shall devour Fire} the bars of your gates. 

#### Nahum 3:14 {water for being encompassed about Draw to yourself}! Secure your fortresses! Step into the mortar, and trample it together with straw! Secure it more than with a brick! 

#### Nahum 3:15 There {shall devour you the fire}; {shall utterly destroy you the broadsword}; it shall devour you as a locust, and you shall be oppressed as a grasshopper. 

#### Nahum 3:16 You multiplied your trade above the stars of the heaven. The grasshopper advanced and spread forth. 

#### Nahum 3:17 {leaped out as the small locust Your consolidation}, as the locust mounted upon a fence on {day an icy}; the sun rises, and it hops, and knows not its place -- woe to them. 

#### Nahum 3:18 {slumbered Your shepherds}, O king of Assyria, {rested your mighty ones}. {departed Your people} unto the mountains, and there was none looking out for them. 

#### Nahum 3:19 There is no healing to your destruction; {is inflamed your wound}. All the ones hearing the message of you clap hands over you. For upon whom {not come upon did your evil} continually?