#### Daniel 1:1 In the {year third} of the kingdom of Jehoiakim king of Judah came Nebuchadnezzar the king of Babylon unto Jerusalem, and assaulted it. 

#### Daniel 1:2 And the LORD gave into his hand Jehoiakim king of Judah, and from part of the items of the house of the LORD. And he brought them into the land of Shinar of the house of his god. And the items he carried into the house of the treasury of his god. 

#### Daniel 1:3 And {told the king} Ashpenaz his chief eunuch to bring in some from the sons of the captivity of Israel, and from the seed of royalty, and from the nobles; 

#### Daniel 1:4 young men to whom there is no {upon them blemish}, and good to the appearance, and perceiving in all wisdom, and knowing knowledge, and considering in intelligence, and ones in whom there is strength in them to stand in the house before the king, to teach them letters and the language of the Chaldeans. 

#### Daniel 1:5 And {set in order to them the king} day by day from the table of the king, and from the wine of his banquet; and to maintain them {years for three}, and after these things to stand them before the king. 

#### Daniel 1:6 And there existed among them from out of the sons of Judah, Daniel, and Hananiah, and Mishael, and Azariah. 

#### Daniel 1:7 And {added to them the chief eunuch names}; to Daniel -- Belteshazzar, and to Hananiah -- Shadrach, and to Mishael -- Meshach, and to Azariah -- Abed-nego. 

#### Daniel 1:8 And Daniel put unto his heart so as in no way he should be polluted in the table of the king, and in the wine of his banquet. And he petitioned the chief eunuch so that in no way he should be polluted. 

#### Daniel 1:9 And God granted Daniel for mercy and compassion before the chief eunuch. 

#### Daniel 1:10 And {said the chief eunuch} to Daniel, I fear my lord the king, the one arraying your food and your drink, lest at any time he should behold your faces looking downcast more than the boys, the ones of your contemporaries; and you should condemn my head to the king. 

#### Daniel 1:11 And Daniel said to Melzar, whom {placed the chief eunuch} over Daniel, and Hananiah, and Mishael, and Azariah. 

#### Daniel 1:12 Test now indeed your servants {days ten}; and let there be given to us from food of the seeds of the earth! and we shall eat of it, and water we shall drink. 

#### Daniel 1:13 And let {be seen before you our shape}! and the shapes of the boys of the ones eating at the table of the king. And how ever you should behold, do accordingly with your servants! 

#### Daniel 1:14 And he hearkened to them, and he tested them {days ten}. 

#### Daniel 1:15 And after the end of the ten days {looked their shape} good and strong in flesh above all the boys eating at the table of the king. 

#### Daniel 1:16 And it came to pass Melzar did away with their supper and the wine for their drink, and he gave to them food of the seeds. 

#### Daniel 1:17 And {gave to them God} understanding and intelligence in all academics, and wisdom. And Daniel perceived in every vision and in dreams. 

#### Daniel 1:18 And after the end of the days which {told the king} to bring them in, that {brought them in the chief eunuch} before Nebuchadnezzar. 

#### Daniel 1:19 And {spoke with them the king}; and there was not found from out of all of them one likened to Daniel, and Hananiah, and Mishael, and Azariah; and they stood before the king. 

#### Daniel 1:20 And in every discourse of wisdom and higher knowledge, as much as {sought from them the king}, he found them ten-times more than all of the enchanters, and the magi, the ones being in all of his kingdom. 

#### Daniel 1:21 And Daniel existed until year one of Cyrus the king. 

#### Daniel 2:1 In the {year second} of the kingdom of Nebuchadnezzar, {dreamed Nebuchadnezzar} a dream, and {was startled his spirit}, and his sleep went from him. 

#### Daniel 2:2 And {said the king} to call the enchanters, and the magi, and the administers of potions, and the Chaldeans, to announce to the king the things of his dreams. And they came and stood before the king. 

#### Daniel 2:3 And {said to them the king}, I dreamed, and it startled my spirit so as to know the dream. 

#### Daniel 2:4 And {spoke the Chaldeans} to the king in Syriac, O king, {into the eons live}! You tell the dream to your servants! and the interpretation of it we shall announce. 

#### Daniel 2:5 {answered The king} and said to the Chaldeans, The matter {from me departed}. If then you should not make known to me the dream and the interpretation of it, {for destruction you will be}, and your houses shall be torn in pieces. 

#### Daniel 2:6 But if the dream and the interpretation of it you should make known to me, gifts and favors without charge, and {honor much} you shall receive from me. Except the dream and the interpretation of it report to me! 

#### Daniel 2:7 They answered a second time and said, {the king Let} tell the dream to his servants! and the interpretation of it we shall announce. 

#### Daniel 2:8 And {answered the king} and said, In truth I know that {time you buy back}, even in so far as you knew that {departed from me the word}. 

#### Daniel 2:9 If then the dream you should not announce to me, I know that {word a lying and corrupt} you agreed to speak before me until the time should go by. {my dream Tell to me}! and I shall know that also its interpretation you shall announce to me. 

#### Daniel 2:10 Answered again the Chaldeans before the king, and they say, There is not a man upon the dry land who is able {the discourse of the king to make known}, in so far as every {king great} and ruler {matter according to such} asked not an enchanter, magus or Chaldean. 

#### Daniel 2:11 For the word which the king asks is heavy, and {no other there is} who shall announce it before the king, except the gods, which are not dwelling with any flesh. 

#### Daniel 2:12 Then the king in rage and {anger much}, said to destroy all the wise men of Babylon. 

#### Daniel 2:13 And the decree went forth, that the wise men be killed; and they sought Daniel and his friends to do away with. 

#### Daniel 2:14 Then Daniel answered counsel and opinion to Arioch the chief guard of the king, who came forth to do away with the wise men of Babylon. 

#### Daniel 2:15 And he inquired of him, saying, O Ruler of the king, for what reason came forth the decree which is impudent from in front of the king? {made known And the saying Arioch} to Daniel. 

#### Daniel 2:16 And Daniel entered and petitioned the king so as {time to give} to him, and the interpretation of it he should announce to the king. 

#### Daniel 2:17 And Daniel went into his house, and to Hananiah, and to Mishael, and to Azariah his friends {the saying to make known}. 

#### Daniel 2:18 And {compassions they sought} from the God of heaven concerning this mystery, so that therefore {should not be destroyed Daniel and his friends} with the rest of the wise men of Babylon. 

#### Daniel 2:19 Then {to Daniel in vision a night the mystery was uncovered}, and {blessed the God of heaven Daniel}. 

#### Daniel 2:20 And he said, May it be -- the name of God being blessed from the eon and unto the eon, for the wisdom and the might are his. 

#### Daniel 2:21 And he changes seasons and times; he ordains kings, and changes; giving wisdom to the wise, and intelligence to the ones knowing understanding. 

#### Daniel 2:22 He uncovers deep and concealed things, knowing the things in the darkness, and the light {with him is}. 

#### Daniel 2:23 To you, O God of my fathers, I acknowledge and praise, for wisdom and power you gave to me, and made known to me what we petitioned from you; and the matter of the king you made known to me. 

#### Daniel 2:24 And Daniel came to Arioch, whom {appointed the king} to destroy the wise men of Babylon, and said to him, The wise men of Babylon you should not destroy, but bring me before the king, and the interpretation to the king I will announce. 

#### Daniel 2:25 Then Arioch in haste brought Daniel before the king, and said to him, I found a man from out of the sons of the captivity of Judea, one who {the interpretation to the king will announce}. 

#### Daniel 2:26 And {answered the king} and said to Daniel, of which the name was Belteshazzar, Are you able to announce to me the dream which I beheld, and the interpretation of it? 

#### Daniel 2:27 And Daniel answered before the king, and he said, The mystery which the king asks is not of wise men, magi, enchanters, astrologers, to announce to the king. 

#### Daniel 2:28 But there is a God in heaven uncovering mysteries, and he made known to king Nebuchadnezzar what must take place at the last of the days. The dream of yours, and the visions of your head upon your bed, is this, 

#### Daniel 2:29 You, O king, your thoughts upon your bed ascended to what must take place after these things. And the one uncovering mysteries made known to you what must take place. 

#### Daniel 2:30 And to me there is not a wisdom being in me more than all the living; {this mystery was uncovered but} because of the interpretation {to the king to be made known}, that {the thoughts of your heart you should know}. 

#### Daniel 2:31 You, O king, viewed. And behold, {image one great}. {image That great}, and the aspect of it was overwhelming, standing before your face; and the vision of it was fearful. 

#### Daniel 2:32 An image of which the head was of {gold pure}, the hands and the breast and the arms of it silver, the belly and the thighs brass, 

#### Daniel 2:33 the legs iron, the feet part somewhat of iron, and part somewhat earthenware. 

#### Daniel 2:34 You viewed until {was shredded a stone} from a mountain without hands, and it struck the image upon the feet of iron and earthenware; and it thinned them out unto completion. 

#### Daniel 2:35 Then they were thinned out at once -- the potsherd, the iron, the brass, the silver, the gold; and they became as a cloud of dust from the threshing-floor at harvest; and {lifted them away the abundance of the wind}, and no place was found for them; and the stone which struck the image became {mountain a great}, and it filled all the earth. 

#### Daniel 2:36 This is the dream; and the interpretation of it we will tell before the king. 

#### Daniel 2:37 You, O king, are king of kings, to whom the God of heaven {kingdom a strong and fortified and honorable gave}. 

#### Daniel 2:38 In every place where {dwell the sons of men}, both wild beasts of the field and birds of heaven he gave into your hand, and he placed you lord of all. You are the head of gold. 

#### Daniel 2:39 And after you shall arise {kingdom another} inferior of you, and {kingdom a third} which is the brass, which shall dominate over all the earth. 

#### Daniel 2:40 And {kingdom a fourth} which shall be strong as iron, in which manner iron makes fine and tames all things -- so it shall be made fine and be tamed. 

#### Daniel 2:41 And that which you beheld of the feet and of the toes, part somewhat earthenware, and part somewhat of iron, {a kingdom divided will be}; and some from the root of iron will be in it, in which manner you beheld the iron being intermingled with the potsherd. 

#### Daniel 2:42 And the toes of the feet, part somewhat of iron and part somewhat earthenware, part {somewhat of the kingdom will be} strong, and some from it will be broken. 

#### Daniel 2:43 For you beheld the iron being intermingled with the potsherd; {mixed together so they will be} with the seed of men. But they will not be cleaving, this one with this other one, as the iron does not intermingle with the potsherd. 

#### Daniel 2:44 And in the days of those kings {shall raise up the God of heaven} a kingdom, which {into the eons shall not be corrupted}. And his kingdom {people to another shall not be left}, but it shall thin and winnow all the kingdoms, and this one shall rise up into the eons. 

#### Daniel 2:45 In which manner you beheld that from a mountain {was trimmed a stone} without hands, and it thinned the potsherd, the iron, the brass, the silver, the gold; the great God made known to the king what must take place after these things. And {is true the dream}, and {is trustworthy the interpretation of it}. 

#### Daniel 2:46 Then king Nebuchadnezzar fell upon his face, and did obeisance to Daniel, and {of a gift offering and of a pleasant aroma offering said to offer a libation to him}. 

#### Daniel 2:47 And responding the king said to Daniel, In truth your God, he is God of gods, and lord of the kings, and uncovering mysteries, for you were able to uncover this mystery. 

#### Daniel 2:48 And {magnified the king} Daniel, and {gifts great and many he gave to him}, and he established him over all the places of Babylon, and ruler of satraps, over all the wise men of Babylon. 

#### Daniel 2:49 And Daniel asked of the king, and he placed over the works of the region of Babylon, Shadrach, Meshach and Abed-nego. And Daniel was in the courtyard of the king. 

#### Daniel 3:1 Nebuchadnezzar the king made {image a gold}. Its height -- {cubits sixty}, its breadth -- {cubits six}, and he stationed it in the plain of Dura, in the region of Babylon. 

#### Daniel 3:2 And he sent to gather together the supreme leaders, and the commandants, and the toparchs, leaders, and sovereigns, and the ones in authorities, and all the rulers of the regions, to come unto the holidays of dedication of the image which {stationed Nebuchadnezzar the king}. 

#### Daniel 3:3 And gathered together the toparchs, supreme leaders, commandants, leaders, sovereigns, great ones, the ones in authorities, and all the rulers of the regions, to the dedication of the image which {stationed Nebuchadnezzar the king}. And they stood before the image which Nebuchadnezzar stationed. 

#### Daniel 3:4 And the herald yelled in strength, To you it is spoken, O nations, peoples, tribes, languages, 

#### Daniel 3:5 in which ever hour you should hear a sound of a trumpet, even flute, and harp, even sambuke and psaltery, and every harmony of sound of kinds of music -- falling, you shall do obeisance to the image of gold which {stationed Nebuchadnezzar the king}. 

#### Daniel 3:6 And who ever should not fall to do obeisance, in that same hour they shall be put into the {furnace of fire burning}. 

#### Daniel 3:7 And it came to pass when {heard the peoples} the sound of the trumpet, even flute and harp, even sambuke and psaltery, and every kind of music, falling down the peoples, tribes, languages, did obeisance to the image of gold which {stationed Nebuchadnezzar the king}. 

#### Daniel 3:8 Then {came forward men Chaldean}, and they accused the Jews. And undertaking, they said {Nebuchadnezzar to king}, 

#### Daniel 3:9 O king, {into the eons live}! 

#### Daniel 3:10 You O king established a decree, Every man who ever should hear the sound of the trumpet, even flute and harp, even sambuke and psaltery, and harmony of sound, and every kind of music, 

#### Daniel 3:11 and should not fall to do obeisance to the image in gold, shall be put into the {furnace of fire burning}. 

#### Daniel 3:12 There are men Jews whom you placed over the works of the region of Babylon -- Shadrach, Meshach, Abed-nego. These men obeyed not, O king, your decree, and your gods they serve not, and to the image of gold which you stationed they do not do obeisance to. 

#### Daniel 3:13 Then Nebuchadnezzar in rage and anger said to lead in Shadrach, Meshach, and Abed-nego. And they led them before the king. 

#### Daniel 3:14 And Nebuchadnezzar responded and said to them, Is it truly, Shadrach, Meshach, Abed-nego, to my gods you serve not, and to the image in gold which I stationed, you do not do obeisance to? 

#### Daniel 3:15 Now then if it suffices readily that as whenever you should hear the sound of the trumpet, also flute and harp, also sambuke and psaltery, and harmony of sound, and every kind of music, falling you should do obeisance to the image which I made -- good. And if you should not do obeisance this hour, you shall be put into the {furnace of fire burning}; and who is God who shall rescue you from out of my hands? 

#### Daniel 3:16 And answered Shadrach, Meshach, and Abed-nego, saying to king Nebuchadnezzar, {no need have We} concerning this matter to answer to you. 

#### Daniel 3:17 {is For God our in the heavens in whom we serve} able to rescue us from out of the {furnace of fire burning}. And from out of your hands, O king, he shall rescue us. 

#### Daniel 3:18 But if not, {made known let it be} to you, O king! that your gods we will not serve, and to the {image golden} which you stationed, we will not do obeisance to. 

#### Daniel 3:19 Then Nebuchadnezzar was filled of rage, and the appearance of his face changed against Shadrach, Meshach, and Abed-nego. And he said to burn the furnace seven-fold until which {to the end it should burn}. 

#### Daniel 3:20 And {men strong of strength he told} shackling Shadrach, Meshach, and Abed-nego, to cast them into the {furnace fire burning}. 

#### Daniel 3:21 Then those men were shackled with their pantaloons, and tiaras, and leggings, and their garments. And they were thrown into the midst of the {furnace of fire burning}, 

#### Daniel 3:22 since the saying of the king excelled, and the furnace burned away over even extra seven-fold. 

#### Daniel 3:23 And these three -- Shadrach, Meshach, and Abed-nego, fell into the midst of the {furnace of fire burning}, being shackled. 

#### Daniel 3:24 And Nebuchadnezzar heard their praising. And he wondered, and rose up in haste, and said to his great men, Was it not {men three} we threw into the midst of the fire being shackled? And they said to the king, Truly, O king. 

#### Daniel 3:25 And {said the king}, Here, I see {men four} being loose and walking in the midst of the fire, and {no corruption there is} to them, and the vision of the fourth is likened to son of God. 

#### Daniel 3:26 Then Nebuchadnezzar came forward to the door of the {furnace of fire burning}, and he said, Shadrach, Meshach, and Abed-nego, O servants of God the highest, come forth and come! And came forth Shadrach, Meshach, and Abed-nego from out of the midst of the fire. 

#### Daniel 3:27 And {were brought together the satraps}, and the commandants, and the toparchs, and the mighty ones of the king. And they viewed the men, for {did not dominate over the fire} their body, and the hair of their head was not ablaze, and their pantaloons did not change, and the scent of fire was not on them. 

#### Daniel 3:28 And {did obeisance before them the king} to the LORD. And {responded Nebuchadnezzar the king}, and he said, Blessed be the God of Shadrach, Meshach, and Abed-nego, who sent his angel, and rescued his servants, for they relied upon him. And the word of the king they changed, and they delivered up their bodies unto fire so that they should not serve nor do obeisance to any god except their God. 

#### Daniel 3:29 And I display a decree, Every people, tribe, language, which ever should speak blasphemy against the God of Shadrach, Meshach, Abed-nego, {for destruction shall be}, and their houses for ravaging, in so far as there is no {God other} who shall be able to rescue thus. 

#### Daniel 3:30 Then the king prospered Shadrach, Meshach, Abed-nego in the region of Babylon. 

#### Daniel 4:1 Nebuchadnezzar the king to all the peoples, tribes, languages, to the ones dwelling in all the land; {peace to you may be multiplied}. 

#### Daniel 4:2 The signs and the miracles which {did with me God the highest} is pleasing before me to announce to you. 

#### Daniel 4:3 As of how great his signs, and as of how mighty his wonders. His kingdom {kingdom is an everlasting}, and his authority unto generation and generation. 

#### Daniel 4:4 I Nebuchadnezzar was prospering in my house, and thriving upon my throne. 

#### Daniel 4:5 {a dream I beheld}, and it threw me into fear. And I was disturbed upon my bed, and the visions of my head disturbed me. 

#### Daniel 4:6 And by me was made a decree to bring in before me all the wise men of Babylon, so that the interpretation of the dream they should make known to me. 

#### Daniel 4:7 And {entered the enchanters magi astrologers Chaldeans}. And the dream I told before them; and the interpretation of it they did not make known to me, 

#### Daniel 4:8 until Daniel came, whose name was Belteshazzar (according to the name of my God) who {spirit of God holy within himself has}. And the dream {before him I told}. 

#### Daniel 4:9 O Belteshazzar, ruler of the enchanters, whom knowing that {spirit holy} is in you, and concerning every mystery {not powerless you are}, hear the vision of my dream which I beheld, and the interpretation of it tell to me! 

#### Daniel 4:10 And the visions of my head {upon my bed I viewed}. And behold, a tree was in the midst of the earth, and the height of it was great. 

#### Daniel 4:11 {was magnified The tree}, and became strong, and its height came unto the heaven, and the extent of it into the ends of all the earth. 

#### Daniel 4:12 Its leaves were beautiful, and its fruit abundant, and a nourishment for all was in it. And underneath it encamped the {beasts wild}, and in its branches dwelt the birds of the heaven; from out of it {was nourished all flesh}. 

#### Daniel 4:13 I viewed in a vision of the night upon my bed, and behold, a sentinel, even a holy one from heaven came down. 

#### Daniel 4:14 And he spoke out loud in strength, and thus he said, Cut down the tree, and pluck off his branches, and shake off his leaves, and scatter his fruit! Let {be shaken away the wild beasts} from beneath him, and the birds from his branches! 

#### Daniel 4:15 Only the development of his roots in the earth allow! even with a bond of iron and brass, and in the tender shoots of grass in the outside; and in the dew of the heaven he shall lay down, and {with the wild beasts his portion} will be in the grass of the ground. 

#### Daniel 4:16 His heart {from the ones of men shall be changed}, and the heart of a wild beast shall be given to him; and seven times shall change over him. 

#### Daniel 4:17 {through the interpretation of a sentinel The word is}, and the saying of holy ones the response, that {should know the ones living} that the LORD is the highest of the kingdom of men, and to whom ever it should seem good he shall give it, and {that which is in contempt of men he will raise up over it}. 

#### Daniel 4:18 This dream I beheld, I the king, Nebuchadnezzar. And you, O Belteshazzar, {the interpretation tell}! for all the wise men of my kingdom are not able {the interpretation of it to manifest} to me. But you Daniel are able, for {spirit of God holy} is in you. 

#### Daniel 4:19 Then Daniel, whose name was Belteshazzar, was rendered speechless for {hour one}, and his thoughts disturbed him. And {answered the king} and said, Belteshazzar, the dream and interpretation {hasten not you}! Belteshazzar answered and said, O lord, let be the dream to the ones detesting you, and the interpretation of it for your enemies! 

#### Daniel 4:20 The tree which you beheld, the one magnified and strengthened, of which the height came unto the heaven, and the extent of it into all the earth, 

#### Daniel 4:21 and its leaves flourishing, and its fruit abundant, and a nourishment to all by it, and underneath it dwelt the {beasts wild}, and in its branches encamped the birds of the heaven -- 

#### Daniel 4:22 You are, O king. For you were magnified and strengthened, and your greatness was magnified, and it came unto heaven, and your dominion unto the ends of the earth. 

#### Daniel 4:23 And that {beheld the king} a sentinel, and a holy one coming down from the heaven, and he said, Pluck the tree, and destroy it; only the development of his roots in the earth allow! even with a bond of iron and brass; and in the tender shoots of grass in the outside, and in the dew of the heaven he shall lodge, and with {beasts wild} will be his portion, until of which time seven seasons should be changed over him. 

#### Daniel 4:24 This is the interpretation of it, O king, and {an interpretation of the highest it is} which came upon my lord the king. 

#### Daniel 4:25 And you shall be banished from men; and {with beasts wild will be your dwelling}; and grass as an ox they shall feed you, and from the dew of the heaven you shall lodge, and seven seasons shall change over you, until of which time you should know that {dominates the highest} the kingdom of men, and to whomever it seems good he will give it. 

#### Daniel 4:26 And whereas they said, Allow the development of the roots of the tree in the ground; your kingdom abides to you from of which ever time you should know the {authority heavenly}. 

#### Daniel 4:27 On account of this, O king, {my counsel let} please you, and {your sins by charities ransom}, and your iniquities by compassions on the needy! Perhaps it will be lenient to your transgressions. 

#### Daniel 4:28 All these things came upon Nebuchadnezzar the king. 

#### Daniel 4:29 After twelve months, upon the temple of his kingdom in Babylon while walking, 

#### Daniel 4:30 {responded the king}, and said, {not this Is} Babylon the great, which I built for a house of royalty, by the might of my strength, for the honor of my glory? 

#### Daniel 4:31 With the word {in the mouth of the king being}, a voice from heaven came, To you it is spoken, O king Nebuchadnezzar, your kingdom went from you. 

#### Daniel 4:32 And from men they shall banish you, and with {beasts wild} your dwelling shall be, and grass as an ox they shall feed you, and seven seasons shall change over you, until of which time you shall know that {dominates the highest} the kingdom of men, and to whom ever it seems good to give it. 

#### Daniel 4:33 In this hour the word was completed upon Nebuchadnezzar, and {from men he was banished}, and {grass as an ox he ate}, and from the dew of the heaven his body was dipped, until his hairs {as lions' hairs were enlarged}, and his fingernails as birds' claws. 

#### Daniel 4:34 And after the end of the days I Nebuchadnezzar {my eyes unto heaven lifted up}, and my senses {unto me returned}, and to the highest I blessed, and to the one living into the eons I praised and glorified. For his authority {authority is an eternal}, and his kingdom is unto generation and generation. 

#### Daniel 4:35 And all the ones inhabiting the earth {as nothing are considered}; and according to his will he does among the force of the of heaven, and among the one dwelling the earth. And there is not one who shall act against his hand, and says to him, What did you do? 

#### Daniel 4:36 At the same time my senses returned unto me, and {into the honor of my kingdom I came}, and my appearance returned to me, and my sovereigns and my great men sought me; and over my kingdom I was strengthened, and {greatness more extra} was added to me. 

#### Daniel 4:37 Now then I Nebuchadnezzar praise and greatly exalt and glorify the king of heaven, for all his works are true, and his paths equitable, and all the ones going in pride he is able to humble. 

#### Daniel 5:1 Belshazzar the king made {supper a great} for his great men -- a thousand; and before the thousand was the wine. 

#### Daniel 5:2 And drinking Belshazzar spoke in the tasting of the wine to bring the items, the ones of gold and the ones of silver which {brought forth Nebuchadnezzar his father} from out of the temple in Jerusalem. And they drank with them -- the king, and his great men, and his concubines, and his mistresses. 

#### Daniel 5:3 And they brought the items of gold, and the ones of silver, which were brought forth from out of the temple of God in Jerusalem, and they drank with them -- the king, and his great men, and his concubines, and his mistresses. 

#### Daniel 5:4 They drank wine, and they praised the gods of gold, and of silver, and of brass, and of iron, and of wood, and of stones. 

#### Daniel 5:5 In the same hour came forth fingers of the hand of a man, and they wrote over against the lamp upon the whitewashed portion of the wall of the house of the king. And the king viewed the knuckles of the hand writing. 

#### Daniel 5:6 Then {of the king the appearance} changed, and his thoughts disturbed him, and the bonding together of his loin parted, and his knees struck together. 

#### Daniel 5:7 And {yelled the king} in strength to bring the magi, and the Chaldeans, and the astrologers. And he said to the wise men of Babylon, Who ever should read this writing, and {its interpretation should make known} to me, purple shall be put on him, and the necklace of gold upon his neck, and as third in my kingdom he shall rule. 

#### Daniel 5:8 And entering were all the wise men of the king, and they were not able {the writing to read}, nor {the interpretation to make known} to the king. 

#### Daniel 5:9 And king Belshazzar was disturbed, and his appearance changed in him, and his great men were disturbed. 

#### Daniel 5:10 And the queen entered into the house of the banquet. And {responded the queen} and said, O king, {into the eon live}! {not Let disturb you your thoughts}, and {appearance your not let} be changed! 

#### Daniel 5:11 There is a man in your kingdom in which {spirit God of the holy is}. And in the days of your father, vigilance, and understanding, and wisdom as wisdom of God, was found in him; and king Nebuchadnezzar your father {ruler of enchanters of magi of Chaldeans and of astrologers placed him}. 

#### Daniel 5:12 For {spirit extra} is in him, and intelligence, and understanding of interpreting dreams, and reporting things held, and untying things bonded together -- it is Daniel, and the king put to him the name -- Belteshazzar. Now then let him be called! and its interpretation he will announce to you. 

#### Daniel 5:13 Then Daniel was brought in before the king. And {said the king} to Daniel, Are you Daniel, the one from the sons of the captivity of Judea, of which {brought the king my father}? 

#### Daniel 5:14 I heard concerning you, that spirit of God is in you, and vigilance, and understanding, and {wisdom extra} is found in you. 

#### Daniel 5:15 And now there entered before me the wise men, magi, and astrologers, that {this writing they should read}, and the interpretation they should make known to me. But they were not able to announce to me. 

#### Daniel 5:16 And I heard concerning you, that you are able {judgments to interpret}. Now then, if you should be able {this writing to read}, and its interpretation to make known to me, purple shall be put on you, and the necklace of gold will be upon your neck, and as third in my kingdom you shall rule. 

#### Daniel 5:17 Then answered Daniel, and he said before the king, {your gifts yours Let be}, and the present of your house {to another give}! But I {the writing shall read} to the king, and the interpretation of it I shall make known to you. 

#### Daniel 5:18 O king, God the highest {the kingdom and the greatness and the honor and the glory gave} to Nebuchadnezzar your father. 

#### Daniel 5:19 And because of the greatness of which he gave to him, all the peoples, tribes, languages were trembling and fearing from before him. Whom he willed he did away with, and whom he willed he beat, and whom he willed he raised up high, and whom he willed he humbled. 

#### Daniel 5:20 And when {was raised up high his heart}, and his spirit was fortified to be prideful, he was brought down from the throne of the kingdom, and the honor was removed from him. 

#### Daniel 5:21 And from the men he was driven out, and his heart {with the wild beasts was given to be}, and with the wild donkeys among which he dwelt. And grass {as an ox was fed him}, and {of the dew of the heaven his body was dipped}, until of which time he knew that {dominated God the highest} the kingdom of men, and to whomever it seems good he gives it. 

#### Daniel 5:22 And you, his son, O Belshazzar, humbled not your heart in front of God, of which all these things you knew. 

#### Daniel 5:23 And against the LORD the God of heaven you were haughty, and the items of his house they brought before you; even you, and your great men, and your concubines, and your mistresses {wine drank} in them, and the gods of gold, and of silver, and of brass, and of iron, and of wood, and of stones, the ones that see not, and hear not, and know not, you praised; and the God of whom your breath is in his hand, and all your ways -- him you glorified not. 

#### Daniel 5:24 On account of this, {from his presence was sent the knuckle of a hand}, and this writing he arranged. 

#### Daniel 5:25 And this is the writing being arranged -- Mene, Tekel, Peres. 

#### Daniel 5:26 This is the interpretation of the saying, Mene -- God measured your kingdom and finished it. 

#### Daniel 5:27 Tekel -- it was set in the yoke balance scale and found lacking. 

#### Daniel 5:28 Peres -- {was divided your kingdom} and was given to the Medes and Persians. 

#### Daniel 5:29 And Belshazzar spoke, and they put on Daniel purple, and the {necklace gold} they put around his neck, and proclaimed concerning him for him to be {ruler third} in the kingdom. 

#### Daniel 5:30 In the same night {was done away with Belshazzar the king of the Chaldeans}. 

#### Daniel 5:31 And Darius the Mede took the kingdom, being {years old sixty two}. 

#### Daniel 6:1 And it was pleasing before Darius, and he placed over the kingdom {satraps a hundred twenty}, for them to be in {entire kingdom his}. 

#### Daniel 6:2 And above them {tacticians three}, which Daniel was one of them, for the {to render to them satraps a reckoning}, so that the king should not be troubled. 

#### Daniel 6:3 And Daniel was over them, for {spirit extra} was in him, and the king placed him over {entire kingdom his}. 

#### Daniel 6:4 And the tacticians and the satraps sought an excuse to find something against Daniel; and any excuse, or transgression, or error they did not find against him, for he was trustworthy. 

#### Daniel 6:5 And {said the tacticians}, We did not find against Daniel an excuse unless it be in the laws of his God. 

#### Daniel 6:6 Then the tacticians, and the satraps stood beside the king. And they said to him, O king Darius, {into the eons live}! 

#### Daniel 6:7 {took counsel All the ones over your kingdom} -- the commandants, and satraps, the supreme leaders, and toparchs, to establish {position a royal}, and to strengthen an enactment, so that whoever should ask a request from any god or man, for {days thirty}, except from you, O king, shall be put into the pit of the lions. 

#### Daniel 6:8 Now then, O king, establish the enactment, and display in writing how {should not be changed the decree of the Persians and Medes}! 

#### Daniel 6:9 Then king Darius gave orders to write the decree. 

#### Daniel 6:10 And when Daniel knew that {was arranged the decree}, he went into his house, and the windows were open to him in his upper rooms before Jerusalem. And {times three} of the day he was bending upon his knees, and praying, and making acknowledgment before his God, as he was doing before. 

#### Daniel 6:11 Then those men closely watched, and they found Daniel petitioning and beseeching his God. 

#### Daniel 6:12 And coming forward, they say to the king, O king, did you not {an enactment order} so that every man who ever should ask from any God or man a request unto {days thirty}, except from you, O king, shall be put into the pit of lions? And {said the king}, {is true The word}, and the decree of the Medes and Persians shall not pass. 

#### Daniel 6:13 Then they responded, and they spoke before the king, saying, Daniel, the one from the sons of the captivity of Judea was not submitted to your decree; and {times three} of the day he asks of his God the requests of his. 

#### Daniel 6:14 Then the king, as he heard the saying, {much fretted} over him; and concerning Daniel he struggled to rescue him, and until evening he was struggling to rescue him. 

#### Daniel 6:15 Then those men say to the king, Know, O king! that the decree of the Medes and Persians, every enactment and position which the king shall establish must not be altered. 

#### Daniel 6:16 Then the king spoke, and they led Daniel, and they put him into the pit of the lions. But {said the king} to Daniel, Your God in whom you serve continually, he will rescue you. 

#### Daniel 6:17 And they brought {stone one}, and they placed it upon the mouth of the pit, and {set seal on it the king} with his ring, and with the ring of his great men; so that {should not be changed the thing} with regard to Daniel. 

#### Daniel 6:18 And {went forth the king} unto his house, and he went to bed supperless; and food was not carried in to him, and sleep left from him. 

#### Daniel 6:19 Then the king rose up in the morning at the light. And in haste he came unto the pit of the lions. 

#### Daniel 6:20 And at his approaching to the pit {to Daniel he yelled voice a strong}, Daniel, O servant of the living God, your God in whom you serve continually, was he able to rescue you from out of the mouth of the lions? 

#### Daniel 6:21 And Daniel said to the king, O king, {into the eons live}! 

#### Daniel 6:22 My God sent his angel, and he obstructed the mouths of the lions, and they did not lay me waste; for before him uprightness was found in me; and even before you, O king, {a transgression I did not commit}. 

#### Daniel 6:23 Then the king felt much good over him, and spoke for Daniel to be brought from out of the pit. And they bore Daniel from out of the pit, and all hurt was not found on him, for he trusted in his God. 

#### Daniel 6:24 And {spoke the king}, and they led the men, the ones accusing Daniel, and {into the pit of the lions they put them}, and their sons, and their wives. And they did not come unto the floor of the pit before {dominated them the lions}, and {all of their bones made fine}. 

#### Daniel 6:25 Then Darius the king wrote to all the peoples, tribes, and languages, to the ones living in all the earth, saying, Peace be multiplied unto you. 

#### Daniel 6:26 From my presence I made a decree for the one in every rule of my kingdom to be trembling and fearing from the face of the God of Daniel. For he is the living God, and the one abiding into the eons, and his kingdom shall not be destroyed, and his dominion is unto the end. 

#### Daniel 6:27 He takes hold of and he rescues, and he produces signs and miracles in the heaven and upon the earth, who rescued Daniel from the mouth of the lions. 

#### Daniel 6:28 And Daniel prospered during the kingdom of Darius, and during the kingdom of Cyrus the Persian. 

#### Daniel 7:1 In the first year of Belshazzar king of the Chaldeans, Daniel {a dream beheld}, and the visions of his head upon his bed. And {his dream he wrote}, and the total sum of the words he said, 

#### Daniel 7:2 I Daniel viewed in my vision of the night. And behold, the four winds of the heaven struck up in the {sea great}. 

#### Daniel 7:3 And four {wild beasts great} ascended from out of the sea, differing from one another. 

#### Daniel 7:4 The first was as a lioness, and her wings were of an eagle. I viewed until of which time {were plucked her wings}, and she was lifted away from the earth, and upon the feet of a man she stood, and the heart of a man was given to her. 

#### Daniel 7:5 And behold, {wild beast a second} likened to a bear, and on {part one} she stood, and three ribs were in her mouth, in between her teeth. And so they said to her, Rise up, eat {flesh much}! 

#### Daniel 7:6 After it I viewed, and behold, another wild beast as a leopard; and to her {wings were four} of a bird above her, and four heads were to the wild beast, and authority was given to her. 

#### Daniel 7:7 After this I viewed, and behold, {wild beast a fourth}, fearful and utterly astonishing, and {great extremely}, and its teeth iron, strong, eating, and making fine, and the rest with its feet it trampled. And it was {diverse extremely} from all the wild beasts, the ones before it. And {horns ten} were to it. 

#### Daniel 7:8 I paid attention to its horns, and behold, {horn another small} ascended in the midst of them, and three horns prior to it were rooted out from in front of it. And behold, eyes as eyes of a man were in this horn, and a mouth speaking great things. 

#### Daniel 7:9 I viewed until when thrones were set, and the old one of days sat down. And his garment was as snow -- white. And the hair of his head was as {wool pure}. His throne a flame of fire, its wheels as fire blazing. 

#### Daniel 7:10 A river of fire drew exiting before him; a thousand thousands ministering to him; and ten thousand ten thousands were present before him. A judgment seat was set, and books were opened. 

#### Daniel 7:11 I viewed then because of a voice of the {words great} which that horn spoke, until {was done away with the wild beast}, and destroyed, and its body was given unto burning fire. 

#### Daniel 7:12 And {of the rest of the wild beasts was changed over the rule}, and a duration of life was given to them until a time and a season. 

#### Daniel 7:13 I viewed in a vision of the night, and behold, with the clouds of the heaven, and one as son of man was coming. And {unto the old one of days he came}, and {before him he was brought}. 

#### Daniel 7:14 And to him was given the rule, and the honor, and the kingdom; and all the peoples, tribes, and languages shall serve to him. His authority {authority is an eternal} which shall not pass away, and his kingdom shall not be destroyed. 

#### Daniel 7:15 {shuddered My spirit}, I Daniel, in my manner, and the visions of my head disturbed me. 

#### Daniel 7:16 And I came forward to one of the ones standing, and the exactness I sought of him to learn concerning all these things. And he spoke to me the exactness; and the interpretation of the words he made known to me. 

#### Daniel 7:17 These, the {wild beasts great four} -- four kingdoms shall rise up upon the earth, 

#### Daniel 7:18 the ones that shall be lifted away. And {shall take to themselves the kingdom holy ones of the highest}; and they shall hold it unto the eon, and unto the eon of the eons. 

#### Daniel 7:19 And I sought exactly concerning the {wild beast fourth}, that was diverse from every wild beast, {fearsome extremely}, its teeth of iron, and its fingernails of brass; devouring, and making fine; and {the rest with its feet it trampled upon}. 

#### Daniel 7:20 And concerning the horns of it, of the ten, of the ones in his head, and of the other one of the ascending and shaking off the former three, that horn in which the eyes and mouth spoke great things, and the sight of it was greater than the rest, 

#### Daniel 7:21 I viewed, and that horn made war with the holy ones, and prevailed against them, 

#### Daniel 7:22 until of which time {came the old one of days}, and {judgment gave} to holy ones of the highest. And the time came, and {of the kingdom took control the holy ones}. 

#### Daniel 7:23 And he said, The {wild beast fourth kingdom a fourth will be} on the earth, which shall excel all the kingdoms, and shall devour all the earth, and shall trample upon it and cut it in pieces. 

#### Daniel 7:24 And the ten horns of it are ten kings, and they shall rise up. And after them shall rise up another who shall overwhelm all the ones prior, and three kings he shall humble, 

#### Daniel 7:25 and words against the highest he shall speak, and the holy ones of the highest he shall mislead, and shall be of the opinion to change times and law. And it shall be granted in his hand until a time and times and half a time. 

#### Daniel 7:26 And the judgment seat he shall set, and the rule shall change over to remove it from view, and to destroy it until the end. 

#### Daniel 7:27 And the kingdom, and the authority, and the greatness of the kings underneath all the heaven was given to holy ones of the highest. And his kingdom {kingdom is an eternal}, and all the sovereignties {him shall serve and obey}. 

#### Daniel 7:28 Unto here is the end of the matter. I Daniel, very much the thoughts of mine disturbed me, and my appearance changed upon me, and the matter {in my heart I preserved}. 

#### Daniel 8:1 In {year the third} of the kingdom of Belshazzar the king, a vision appeared to me, I Daniel, after the appearing to me the beginning. 

#### Daniel 8:2 And I was in Sushan in the palace, the one which is in the region of Elam; and I saw in a vision, and I was upon the Ulai. 

#### Daniel 8:3 And I lifted my eyes and looked. And behold, {ram one} standing before the Ubal; and there was to him horns, and the horns were high; and the one was higher than the other, and the high one ascended up last. 

#### Daniel 8:4 And I beheld the ram butting towards the west, and the north, and the south; and all the wild beasts shall not stand before him, and there was no one rescuing from out of his hand; and he did according to his will, and he was magnified. 

#### Daniel 8:5 And I was perceiving. And behold, a he-goat of the goats came from the southwest upon the face of all the earth, and was not touching the earth. And to the he-goat was a horn which may be viewed between his eyes. 

#### Daniel 8:6 And he came unto the ram, the one {the horns having}, which I beheld standing before the Ubal, and it ran against him with the thrust of his strength. 

#### Daniel 8:7 And I beheld him anticipating unto the ram, and he was furiously enraged against him, and he hit the ram, and he broke both of his horns; and there was no strength to the ram to stand before him; and he tossed him upon the ground, and trampled upon him, and there was not one rescuing the ram from out of his hand. 

#### Daniel 8:8 And the he-goat of the goats was magnified even unto exceedingly. And in his being strong {was broken horn his great}, and there ascended another {horns four} underneath him unto the four winds of the heaven. 

#### Daniel 8:9 And from out of the one of them came forth {horn one strong}, and was magnified extremely towards the south, and towards the east, and towards the setting of the sun. 

#### Daniel 8:10 And it was magnified unto the force of the heaven; and it fell upon the earth from the force of the of heaven, and from the stars, and he trampled upon them. 

#### Daniel 8:11 And unto the commander-in-chief he was magnified, and through him the sacrifice was disturbed, and the holy place shall be made desolate. 

#### Daniel 8:12 And {was given for the sacrifice a sin offering}, and {was tossed onto the ground righteousness}; and he performed and was prospered. 

#### Daniel 8:13 And I heard one holy one speaking. And {said one holy one} to the Phelmouni, to the one speaking, For how long shall the vision stand, {the sacrifice the taking away}, and {the sin of desolation the granting}, and the holy place and the force shall be trampled upon? 

#### Daniel 8:14 And he said to him, Unto evening and morning {days two thousand three hundred}, and {shall be cleansed the holy place}. 

#### Daniel 8:15 And it came to pass in my beholding, I Daniel, the vision, and I sought understanding. And behold, there stood before me as an appearance of a man. 

#### Daniel 8:16 And I heard the voice of a man in the midst of the Ulai. And he called, and said, Gabriel, bring understanding {for that one the vision}! 

#### Daniel 8:17 And he came and stood next to my position. And in his coming I was distraught, and I fell upon my face. And he said to me, Take notice, O son of man! {is still for for time end the vision}. 

#### Daniel 8:18 And in his speaking with me, I fell upon my face unto the earth. And he touched me, and he stood me upon my feet. 

#### Daniel 8:19 And he said, Behold, I make known to you the things being at the last of the wrath, for it is yet for {of time end}. 

#### Daniel 8:20 The ram which you beheld, the one having the horns, is the king of the Medes and Persians. 

#### Daniel 8:21 And the he-goat of the goats is the king of the Greeks, and the {horn great}, the one that was in between his eyes, he is the {king foremost}. 

#### Daniel 8:22 And of the one being broken, of which {stood four horns} underneath -- four kings from out of his nation shall rise up, and not in his strength. 

#### Daniel 8:23 And at the last of their kingdom, being full of the sins, shall rise up a king with an impudent face, and perceiving riddles. 

#### Daniel 8:24 And {is fortified his strength}, and not by his strength. And wonderfully he shall corrupt, and shall prosper, and shall perform, and shall corrupt strong ones, and {people a holy}. 

#### Daniel 8:25 And the yoke of the collar shall prosper; treachery in his hand, and {in his heart he shall magnify himself}, and by treachery he shall corrupt many, and for a destruction of many he shall establish himself; and as eggs in a hand he shall break. 

#### Daniel 8:26 And the vision of the evening and of the morning of the thing being spoken -- it is true. And you set a seal upon the vision, for it is for many days! 

#### Daniel 8:27 And I Daniel went to bed, and I was infirm for days. And I rose up and I did the works of the king; and I wondered at the vision, and there was no one perceiving. 

#### Daniel 9:1 In the first year of Darius the son of Ahasuerus, of the seed of the Medes, who reigned over the kingdom of Chaldeans, 

#### Daniel 9:2 in year one of his kingdom, I Daniel perceived in the books the number of the years of which {became the word of the LORD} to Jeremiah the prophet for a fulfillment of the desolation of Jerusalem -- seventy years. 

#### Daniel 9:3 And I put my face towards the LORD God, to inquire by prayer and supplication, in fasting, and sackcloth, and ashes. 

#### Daniel 9:4 And I prayed to the LORD my God, and I made acknowledgment, and I said, O LORD, the {God great and wonderful}, keeping your covenant, and the mercy to the ones loving you, and to the ones keeping your commandments; 

#### Daniel 9:5 we sinned, we did wrong, we were impious, and we left and turned aside from your commandments, and from your judgments. 

#### Daniel 9:6 And we did not listen to your servants the prophets, the ones speaking in your name to our kings, and our rulers, and our fathers, and to all the people of the land. 

#### Daniel 9:7 To you, O LORD, is righteousness, and to us the shame of face, as this day; to the man of Judah, and to the ones dwelling Jerusalem, and to all Israel, to the ones near, and to the ones far off in all the earth, of which you dispersed them there, for their rebellion in which they annulled covenant with you, O LORD. 

#### Daniel 9:8 To us shame of face, and to our kings, and to our rulers, and to our fathers, to the ones who sinned against you. 

#### Daniel 9:9 To the LORD our God are the compassions, and the atonements, for we separated from the LORD. 

#### Daniel 9:10 And we hearkened not to the voice of the LORD our God, to go by his laws, the ones which he executed before our face by the hands of his servants the prophets. 

#### Daniel 9:11 And all Israel violated your law, and turned aside to not hearken to your voice; and there came upon us the curse, and the oath, the one having been written in the law of Moses the servant of God, for we sinned against him. 

#### Daniel 9:12 And he established his words which he spoke against us, and against our judges, the ones judging us, to bring upon us {evils great}; such as have not taken place underneath all of the heaven, according to the things taking place in Jerusalem. 

#### Daniel 9:13 As was written in the law of Moses, all these evils came upon us. And we did not beseech the face of the LORD our God, to turn from our iniquities, and to perceive in all truth. 

#### Daniel 9:14 And {was vigilant the LORD our God} against the evil, and brought them upon us. For {is just the LORD our God} in all his doing which he did. And we hearkened not to his voice. 

#### Daniel 9:15 And now, O LORD our God, who led your people from the land of Egypt by {hand a fortified}, and you made for yourself a name as it is this day -- we sinned, we acted lawlessly, we transgressed. 

#### Daniel 9:16 O LORD, in all your charity let turn indeed your rage, and your anger from your city Jerusalem, {mountain your holy}! For we sinned in our iniquities, and of the ones of our fathers. Jerusalem and your people {for scorn became} among all the ones surrounding us. 

#### Daniel 9:17 And now, hearken O LORD our God, of the prayer of your servant and his supplications! And let {appear your face} upon your sanctified place, the deserted one, because of you O LORD! 

#### Daniel 9:18 Lean, O my God, your ear, and hearken! Open your eyes, and behold our extinction! and of your city upon which {is called your name} upon it. For not upon our righteousness we toss our compassion before you, but upon {compassions your great}, O LORD. 

#### Daniel 9:19 Hearken, O LORD! Atone, O LORD! Take heed, O LORD! Act, and do not delay for your sake, O LORD my God! For your name is called upon your city, and upon your people. 

#### Daniel 9:20 And yet during my speaking, and praying, and declaring openly my sins, and the sins of my people Israel, and tossing my desire for mercy before the LORD my God concerning the {mountain holy} of my God, 

#### Daniel 9:21 and yet during my speaking in the prayer, that behold, the man Gabriel, whom I beheld in the vision at the beginning flying, and he touched me about the hour {sacrifice of the evening}. 

#### Daniel 9:22 And he brought understanding to me, and spoke with me, and said, O Daniel, now I came forth to instruct you for understanding. 

#### Daniel 9:23 In the beginning of your supplication {went forth the word}, and I came to announce to you; for {a man desired you are}. And now reflect in the matter, and perceive in the apparition! 

#### Daniel 9:24 Seventy periods of seven were rendered concise upon your people, and upon the {city holy}, to finish off sin, and to set a seal upon sins, and to wipe out the lawless deeds, and to atone for iniquities, and to bring {righteousness eternal}, and to set a seal upon vision and prophecy, and to anoint the holy of holies. 

#### Daniel 9:25 And you shall know and perceive, from the delivery of the word to respond and to build Jerusalem until the anointed one leading -- {periods of seven seven}, and {periods of seven sixty-two}. Again {shall be built the square and wall} in straits of the times. 

#### Daniel 9:26 And after the {periods of seven sixty-two}, {shall be utterly destroyed the anointing}, and judgment is no longer in it. And the city, and the holy place he shall corrupt with the one taking the lead, the one coming, and they shall be cut off as in a flood, and {until the end of war being terminated he shall order in extinctions}. 

#### Daniel 9:27 And he shall strengthen covenant with many {period of sevens one}; and in the half of the period of seven shall be lifted away sacrifice and libation offering, and upon the temple an abomination of the desolations will be; and until the completion of time, completion shall be given unto the desolation. 

#### Daniel 10:1 In {year the third} of Cyrus, king of the Persians, the word was uncovered to Daniel (of whom the name was called Belteshazzar) and {is true the word}. And {ability great} and understanding was given to him in the apparition. 

#### Daniel 10:2 In those days, I Daniel was mourning three periods of seven of days. 

#### Daniel 10:3 {bread Of desirable} I ate not, and meat and wine did not go into my mouth, and an anointing I did not anoint with until the fullness of the three period of sevens of days. 

#### Daniel 10:4 On the {day twentieth and fourth} of the {month first}, and I was next to the {river great} -- it is the Tigris. 

#### Daniel 10:5 And I lifted my eyes and looked. And behold, a man, one being clothed with linen clothes, and his loin being girded in gold of Uphaz. 

#### Daniel 10:6 And his body was as Tharsis stone, and his face as a sight of lightning, and his eyes as lamps of fire, and his arms and his legs as the sight of brass shining, and the sound of his words as a sound of a multitude. 

#### Daniel 10:7 And {beheld I Daniel alone} the apparition. And the men, the ones with me, beheld not the apparition, but {change of state a great} fell upon them, and they fled in fear. 

#### Daniel 10:8 And I was left behind alone. And I beheld {apparition this great}, and there was not left in me strength, and my glory converted into corruption, and I held no strength. 

#### Daniel 10:9 And I heard the voice of his words. And in my hearing the sound of his discourses, I was being vexed, and my face was upon the ground. 

#### Daniel 10:10 And behold, a hand was touching me, and raised me upon my knees and palms of my hands. 

#### Daniel 10:11 And he said to me, Daniel, man desired; perceive by the words which I speak to you, and stand at your position! for now I am sent to you. And in his speaking to me this word, I rose up trembling. 

#### Daniel 10:12 And he said to me, Fear not Daniel! for from the {day first} of which you gave your heart to perceive, and to afflict yourself before the LORD your God, {were heard your words}, and I came because of your words. 

#### Daniel 10:13 And the ruler of the kingdom of the Persians stood right opposite me twenty days and one day. And behold, Michael, one of the rulers of the ones foremost, came to help me; and I left him there with the ruler of the kingdom of the Persians. 

#### Daniel 10:14 And I came to bring understanding to you as much as shall meet your people in last of the days. For {is still the vision} for days. 

#### Daniel 10:15 And in his speaking with me according to these words, I put my face unto the ground, and was vexed. 

#### Daniel 10:16 And behold, as a likeness of a son of man touched my lips, and I opened my mouth, and I spoke, and said to the one standing before me, O lord, at the apparition of you {turned my within} in me, and I had not strength. 

#### Daniel 10:17 And how shall {be able your servant}, O lord, to speak after {my lord this}? And I, from the present shall not stand with strength in me, and there is no breath left in me. 

#### Daniel 10:18 And proceeded and touched me as it were a vision of a man. And he strengthened me. 

#### Daniel 10:19 And he said to me, Fear not, man desired! Peace to you, be manly and strong! And in his speaking with me, I strengthened, and I said, Speak, my lord! for you strengthened me. 

#### Daniel 10:20 And he said, Do you know why I came to you? And now, I shall return to wage war with the ruler of the Persians. And I coming forth, and the ruler of the Greeks came. 

#### Daniel 10:21 But I will announce to you the arranging in the writing of truth. And there is no one holding with me concerning these things, except Michael your ruler. 

#### Daniel 11:1 And I in {year the first} of Cyrus stood for might and strength. 

#### Daniel 11:2 And now {truth I shall announce} to you, Behold, still three kings shall arise in Persia; and the fourth shall be rich {riches in great}, more than all. And after his prevailing by his riches, he shall rise up against all the kingdoms of the Greeks. 

#### Daniel 11:3 And {shall rise up king a mighty}, and he shall lord over {dominion a great}, and he shall do according to his will. 

#### Daniel 11:4 And when ever {should stand his kingdom}, it shall be broken, and shall be divided into the four winds of the heaven; and not unto his latter end, nor according to his dominion which he lorded over. For {was plucked up kingdom his}, and to others outside of these it shall be given. 

#### Daniel 11:5 And {grew in strength the king of the south}; and one of his rulers shall grow in strength over him, and shall lord over {dominion a great} by his authority. 

#### Daniel 11:6 And after his years they shall be mixed together; and the daughter of the king of the south shall enter in to the king of the north to make treaties with him. And she shall not hold strength of arm; and {shall not stand his seed}, and she shall be delivered up, and the ones bringing her, and the young woman, and the one strengthening her in the times. 

#### Daniel 11:7 And one shall rise up from out of the flower of her root unto his preparation; and he shall come against the force, and shall enter unto the supporters of the king of the north, and shall deal with them, and shall prevail. 

#### Daniel 11:8 And indeed their gods with their molten images, and every {item desirable} of theirs of silver and of gold, with the captivity, he shall bring into Egypt. And he shall stand over the king of the north. 

#### Daniel 11:9 And he shall enter into the kingdom of the king of the south, and shall return unto his land. 

#### Daniel 11:10 And his sons shall gather a multitude {forces of many}. And {shall come one coming}, even inundating, and shall go by. And he shall settle, and shall grapple together unto his strength. 

#### Daniel 11:11 And {shall be wild the king of the south}, and shall come forth and wage war with the king of the north. And he shall establish {multitude a great}; but there shall be delivered up a multitude in his hand. 

#### Daniel 11:12 And he shall take the multitude, and {shall be exalted his heart}; and he shall throw down myriads, and he shall not prevail. 

#### Daniel 11:13 And {shall return the king of the north}, and shall lead {multitude a great} more than the former. And in the end of the times he shall come upon an entrance in {power great}, and in {substance much}. 

#### Daniel 11:14 And in those times many shall rise up against the king of the south. And the sons of the pestilent ones of your people shall be lifted up to establish the vision; and they shall weaken. 

#### Daniel 11:15 And {shall enter the king of the north}, and shall discharge a mound, and shall seize {cities fortified}. And the arms of the king of the south shall not stand, and {shall rise up his chosen ones}, and there will not be strength to stand. 

#### Daniel 11:16 And {shall do the one entering} to him according to his will, and there is not one standing against his face. And he shall stand in the land of glory, and it shall be finished off entirely by his hand. 

#### Daniel 11:17 And he shall arrange his face to enter in the strength of all his kingdom, and {upright all} with him; thus he shall do. And the daughter of women he will give to him to corrupt her. But in no way shall she remain, and {not to him she will be}. 

#### Daniel 11:18 And he shall turn his face unto the islands, and shall seize many. And he will cause {to cease rulers} their scorning, only his scorning shall return to him. 

#### Daniel 11:19 And he shall turn his face unto the strength of his land. And he shall weaken, and shall fall, and shall not be found. 

#### Daniel 11:20 And shall rise up from out of his root a plant of a kingdom, unto his preparation, casting aside, exacting glory of the kingdom. And in those days he shall be broken, and not in faces, nor in war. 

#### Daniel 11:21 One shall stand upon his preparation, who was treated with contempt, and they did not give unto him glory of the kingdom. And he shall come in prosperity, and he shall prevail over a kingdom by a slip. 

#### Daniel 11:22 And the arms of the one inundating shall be flooded from his face, and they shall be broken; even the one taking the lead of the covenant. 

#### Daniel 11:23 And because of the interminglings with him he shall deal in treachery. And he shall ascend, and shall excel in strength over him by a little nation. 

#### Daniel 11:24 And in prosperity and in plentiful places he shall come; and he shall do what {did not do his fathers}, and the fathers of his fathers. Plunder, and spoils, and substance, {to them he will disperse}. And against Egypt he will devise his devices for a time. 

#### Daniel 11:25 And {shall be awakened his strength}, and his heart against the king of the south with {force a great}; and the king of the south shall join together in war, and in {power a great}, even in strength exceedingly. And he shall not stand, for they shall devise {against him devices}. 

#### Daniel 11:26 And they shall eat the things necessary of his, and they shall break him, and forces shall break up, and {shall fall slain many}. 

#### Daniel 11:27 And both the kings -- their hearts are for wickedness, and at {table one lies they shall speak}, and it shall not straighten out, for the end is for a time. 

#### Daniel 11:28 And he shall return unto his land with {substance much}, and his heart against {covenant holy}. And he shall act, and he shall return unto his land. 

#### Daniel 11:29 In the time he shall return, and he shall come in the south, and it will not be as the first and the last. 

#### Daniel 11:30 And they shall enter in it, even the ones coming forth, the Chittim. And he shall be humbled, and he shall return, and he shall be enraged against {covenant holy}; and he shall act, and he shall return, and he shall perceive with the ones forsaking {covenant holy}. 

#### Daniel 11:31 And {arms from him} shall rise up, and shall profane the sanctuary of the might. And they shall change over the perpetual sacrifice, and shall offer {abomination an obliterating}. 

#### Daniel 11:32 And the ones acting lawlessly {a covenant shall bring upon} by a slip. And a people knowing his God shall grow strong, and shall act. 

#### Daniel 11:33 And the discerning of the people shall perceive in many things, and they shall be weak by the broadsword, and by flame, and by captivity, and by ravaging of days. 

#### Daniel 11:34 And in the weakening of them they shall be helped {help with a little}, and {shall be added unto them many} by a slip. 

#### Daniel 11:35 And of the ones perceiving shall weaken, to purify them by fire, and to choose, and to be uncovered until the time of the end. For it is still for a time. 

#### Daniel 11:36 And he shall do according to his will; and the king shall be exalted, and magnified over every god, and over the God of gods. And he shall speak pompous words, and shall prosper until of which time {should be completed the wrath}. For unto completion it is coming to pass. 

#### Daniel 11:37 And unto all gods of his fathers he will not take notice, nor the desire of women; and concerning every god he will not take notice; for above all he will be magnified. 

#### Daniel 11:38 And {a god of fortress at his place he will glorify}. And a god whom {knew not his fathers} he shall glorify with gold, and silver, and {stone precious}, and with desirable things. 

#### Daniel 11:39 And he shall act in the fortresses of refuge with a strange god, of which ever he should recognize. And he shall multiply glory, and shall submit to them many; and the land he shall divide by gifts. 

#### Daniel 11:40 And in {time end} he will mix horns with the king of the south; and {shall be gathered together unto him the king of the north} with chariots, and with horsemen, and with {ships many}. And he shall enter into the land, and he shall break and go by. 

#### Daniel 11:41 And he shall enter into the land of glory, and many shall be weakened. And these shall be delivered from out of his hand -- Edom and Moab, and the sovereignty of the sons of Ammon. 

#### Daniel 11:42 And he shall stretch out his hand upon the land; and the land of Egypt will not be for deliverance. 

#### Daniel 11:43 And he shall dominate by the concealed things of gold and of silver, and in all the desirable things of Egypt, and of the Libyans, and Ethiopians, in their fortresses. 

#### Daniel 11:44 And hearings shall disturb him from out of the east, and the north. And he shall come in rage with many to obliterate, and to devote {to consumption many}. 

#### Daniel 11:45 And he shall pitch his tent of a royal pavilion between the seas, in {mountain of glory the holy}. And he shall come unto his parts, and there shall be the one rescuing him. 

#### Daniel 12:1 And in that time shall rise up Michael the {ruler great}, the one standing for the sons of your people. And it will be a time of affliction such as has not taken place from of which time there became a nation on the earth, until that time. And in that time {shall be delivered your people}, every one found being written in the book. 

#### Daniel 12:2 And many of the ones sleeping in {of earth an embankment} shall awaken, these unto {life eternal}, and these others unto scorning, and for {shame eternal}. 

#### Daniel 12:3 And the ones perceiving shall shine forth as the brightness of the firmament; and of the {righteous many} as the stars into the eons and still. 

#### Daniel 12:4 And you Daniel obstruct the words, and set a seal upon the scroll until the time of completion! until {should be taught many}, and {be multiplied the knowledge}. 

#### Daniel 12:5 And I beheld, I Daniel, and behold, two others stood, one here on this bank of the river, and one here on the other bank of the river. 

#### Daniel 12:6 And they said to the man being clothed with the linen clothes, who was upon the water of the river, Until when will be the end of which you have spoken of the wonders? 

#### Daniel 12:7 And I heard the man, of the one being clothed with the linen clothes, who was upon the water of the river. And he raised up high his right hand, and his left unto the heaven. And he swore an oath to the one living into the eon, that for a time and times and half a time, in the completing the dispersing hand of people having been sanctified, they shall know all these things. 

#### Daniel 12:8 And I heard, and I perceived not. And I said, O lord, what of these last things? 

#### Daniel 12:9 And he said, Go Daniel! for {are obstructed and sealed the words} until {time end}. 

#### Daniel 12:10 {shall be chosen and whitened and purified by fire and sanctified Many}. And {shall act lawlessly the lawless ones}, and {shall not perceive all the lawless ones}, but the intelligent shall perceive. 

#### Daniel 12:11 And from the time of the alteration of the perpetual sacrifice, and the putting of the abomination of desolation -- {days a thousand two hundred ninety}. 

#### Daniel 12:12 Blessed is the one enduring and coming into {days a thousand three hundred thirty-five}. 

#### Daniel 12:13 And you, go, for satisfying completion. And you shall rest, and shall rise up at your lot at the completion of days.