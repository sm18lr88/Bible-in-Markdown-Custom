#### Jonah 1:1 And {came the word of the LORD} to Jonah the son of Amittai, saying, 

#### Jonah 1:2 Rise up, and go unto Nineveh the {city great}, and proclaim in it! for {ascended the cry of its evils} to me. 

#### Jonah 1:3 And Jonah rose up to flee into Tarshish from the face of the LORD. And he went down into Joppa. And he found a boat proceeding to Tarshish, and he gave his fare, and ascended into it to sail with them unto Tarshish from the face of the LORD. 

#### Jonah 1:4 And the LORD raised up a wind upon the sea; and there became {swell a great} in the sea, and the boat was exposed to danger of breaking up. 

#### Jonah 1:5 And {feared the mariners}, and yelled out each to his god. And {an expulsion they made} of the items, of the ones in the boat, into the sea, to lighten of them. But Jonah went down into the hold of the boat, and he went to sleep, and snored. 

#### Jonah 1:6 And {drew near to him the captain}, and said to him, Why do you snore? Rise up, call upon your God! so that God should preserve us, and in no way we should be destroyed. 

#### Jonah 1:7 And {said each} to his neighbor, Come we should cast lots, and we shall know for what reason this evil is to us. And they cast lots, and {fell the lot} upon Jonah. 

#### Jonah 1:8 And they said to him, Report indeed! for what reason {this evil is} to us? What {your work is}, and from where have you come, and from out of what kind of place, and of what kind of people are you? 

#### Jonah 1:9 And he said to them, {a servant of the LORD I am}, and {the God of the heaven I worship} who made the sea and the dry land. 

#### Jonah 1:10 And {feared the men fear a great}, and they said to him, What is this you did? (because {knew the men} that {from the face of the LORD he was fleeing}, for he reported it to them.) 

#### Jonah 1:11 And they said to him, What should we do to you, and {abates the sea} from us? (for the sea went forth and rose up a rather great swell.) 

#### Jonah 1:12 And Jonah said to them, Lift me, and cast me into the sea, and {shall abate the sea} from you! Because I know, that on account of me {swell great this upon you is}. 

#### Jonah 1:13 And {pressed on the men} to turn towards the land, and they were not able, for the sea went, and it rose up rather upon them. 

#### Jonah 1:14 And they yelled out to the LORD, and they said, By no means, O LORD, should you destroy us because of the soul of this man, and should not be imputed against us the blood of the just; for you, O LORD, in which manner you want, you do. 

#### Jonah 1:15 And they took Jonah, and they cast him into the sea. And {stood the sea} from its tossing about. 

#### Jonah 1:16 And {feared the men fear a great} of the LORD, and they sacrificed a sacrifice to the LORD, and vowed the vows. 

#### Jonah 1:17 And the LORD assigned {whale a great} to swallow Jonah. And Jonah was in the belly of the whale three days and three nights. 

#### Jonah 2:1 And Jonah prayed to the LORD his God from out of the belly of the whale. 

#### Jonah 2:2 And he said, I yelled my affliction to the LORD my God, and he hearkened to me. From out of the belly of Hades was my cry; you heard my voice. 

#### Jonah 2:3 You threw me into the depths of the heart of the sea, and rivers encircled me. All your crests and your waves {upon me went}. 

#### Jonah 2:4 And I said, Have I been thrust away from your eyes? Surely I shall proceed to look towards {temple holy your}. 

#### Jonah 2:5 {was poured about me Water} unto the soul. The deep encircled me to the extreme; {went down head my}. 

#### Jonah 2:6 Into the fissures of mountains I went down; into the earth of which its bars {holds are the eternal}. Yet let {ascend from corruption my life}, O LORD my God! 

#### Jonah 2:7 In the faltering {from me of my soul} I remembered the LORD; and may {come to you my prayer} in {temple holy your}. 

#### Jonah 2:8 The ones watching vanities and lies {their mercy abandoned}. 

#### Jonah 2:9 But I with the voice of praise and acknowledgment will sacrifice to you. As much as I vowed I will render to you. For my deliverance is by the LORD. 

#### Jonah 2:10 And it was assigned from the LORD to the whale; and it cast out Jonah upon the dry land. 

#### Jonah 3:1 And came to pass the word of the LORD to Jonah the second time, saying, 

#### Jonah 3:2 Rise up, go unto Nineveh the {city great}! and proclaim in it! according to the proclamation {before which I spoke to you}. 

#### Jonah 3:3 And Jonah rose up, and went into Nineveh as the LORD spoke. And Nineveh was {city a great} to God, as the goings of a journey of three days. 

#### Jonah 3:4 And Jonah began to go into the city, as the going {day of one}. And he proclaimed and said, Yet three days, and Nineveh shall be eradicated. 

#### Jonah 3:5 And {believed the men of Nineveh} in God, and they proclaimed a fast, and put on sackcloths, from their great unto their small. 

#### Jonah 3:6 And {approached the word} to the king of Nineveh. And he rose up from his throne, and he removed his apparel from himself, and he wore sackcloth, and sat upon ashes. 

#### Jonah 3:7 And it was proclaimed and was spoken in Nineveh by the king, and by his great men, saying, The men, and the cattle, and the oxen, and the sheep -- let them not taste, nor feed, and {water let them not drink}! 

#### Jonah 3:8 And {put around sackcloths the men and the cattle}. And they yelled out to God fervently. And {turned each} from {way their wicked}, and from the iniquity in their hands, saying, 

#### Jonah 3:9 Who knows if {shall change his mind God}, and he shall turn from the anger of his rage, and in no way should we perish? 

#### Jonah 3:10 And God saw their works, that they turned from {ways their wicked}; and God changed his mind over the evil which he spoke to do to them; and he did not do it. 

#### Jonah 4:1 And Jonah was grieved {distress with great}, and was confounded. 

#### Jonah 4:2 And he prayed to the LORD, and he said, O LORD, Were not these my words still being in my land? Because of this I thought beforehand to flee unto Tarshish. Because I knew that you are merciful and pitying, lenient and full of mercy, and one to change his mind over the evils. 

#### Jonah 4:3 And now, master, O LORD, take my soul from me, for it is good for me to die than live! 

#### Jonah 4:4 And the LORD said, Are {exceedingly grieved you}? 

#### Jonah 4:5 And Jonah went forth from out of the city, and he sat before the city, and he made for himself there a tent, and he sat down underneath it, unto of which he could look over what will be of the city. 

#### Jonah 4:6 And {assigned the LORD God} a gourd, and it ascended above the head of Jonah, to be shading up above his head, to shade him from his hurts. And Jonah rejoiced over the gourd {joy with great}. 

#### Jonah 4:7 And God assigned a worm for early morning the next day, and it struck the gourd, and it was dried up. 

#### Jonah 4:8 And it came to pass at the same time as the rising of the sun, and God assigned {wind a burning} to burn; and {struck the sun} upon the head of Jonah, and he became faint-hearted, and resigned of his life, and said, Better for me to die than live. 

#### Jonah 4:9 And {said God} to Jonah, Are {exceedingly grieved you} over the gourd? And he said, {exceedingly grieved I am} unto death. 

#### Jonah 4:10 And the LORD said, You indeed spared for the gourd, for which you suffered no hardship over it, nor nourished it; which came up during the night, and {during the night perished}. 

#### Jonah 4:11 But I, shall I not spare for Nineveh the {city great}, in which dwells in it more than twelve myriads of men, who do not know their right hand or their left, and {cattle much}?