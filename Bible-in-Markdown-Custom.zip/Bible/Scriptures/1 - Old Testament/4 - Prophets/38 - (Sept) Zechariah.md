#### Zechariah 1:1 In the eighth month, {year of the second} unto Darius, came to pass the word of the LORD to Zechariah, the son of Berechiah, son of Iddo the prophet, saying, 

#### Zechariah 1:2 The LORD was provoked to anger by your fathers -- {anger a great}. 

#### Zechariah 1:3 And you shall say to them, Thus says the LORD of the forces, Turn to me, says the LORD of the forces! and I shall be turned towards you, says the LORD of the forces. 

#### Zechariah 1:4 And do not become as your fathers! ones whom {accused them the prophets}, the ones beforehand saying, Thus says the LORD of the forces, Turn from {ways your wicked}, and from {practices your wicked}! And they did not listen, and did not take heed to listen to me, says the LORD. 

#### Zechariah 1:5 Your fathers, where are they and the prophets, Shall {into the eon they live}? 

#### Zechariah 1:6 Furthermore {my words and my laws do you receive}, as many as I give charge by my spirit to my servants the prophets, the ones overtaking your fathers? And they answered and said, As {deployed the LORD of the forces} to do to us according to our ways, and according to our practices, so he did to us. 

#### Zechariah 1:7 On the fourth and twentieth day in the eleventh month, this is the month Shebat, in the second year unto Darius, came to pass the word of the LORD to Zechariah, the son of Berechiah, son of Iddo the prophet, saying, 

#### Zechariah 1:8 I saw the night, and behold, a man having mounted {horse a reddish}, and this one stood in the midst of the {mountains shady}; and behind him {horses reddish}, and white, and spotted. 

#### Zechariah 1:9 And I said, What are these, O lord? And {said to me the angel}, the one speaking to me, I will show to you what these are. 

#### Zechariah 1:10 And {answered the man}, the one standing in the midst of the mountains, and he said to me, These are whom the LORD sent out to travel about the earth. 

#### Zechariah 1:11 And they answered to the angel of the LORD standing in the midst the mountains, and they said, We have traveled about the earth, and behold, all the earth is inhabited and tranquil. 

#### Zechariah 1:12 And {answered the angel of the LORD} and said, O LORD of the forces, until when shall you in no way show mercy on Jerusalem, and the cities of Judah, in which you were enraged over this seventieth year? 

#### Zechariah 1:13 And the LORD responded to the angel, the one speaking with me {sayings with good}, {words and comforting}. 

#### Zechariah 1:14 And {said to me the angel speaking with me}, Shout aloud! saying, Thus says the LORD almighty; I am jealous for Jerusalem, and for Zion {zeal with great}. 

#### Zechariah 1:15 And {anger with great I am provoked} by the nations, the ones joining in making an attack; because I indeed was provoked to anger a little, but they joined in making an attack for evils. 

#### Zechariah 1:16 On account of this, thus says the LORD, I will turn towards Jerusalem for compassion; and my house shall be rebuilt in it, says the LORD of the forces, and a measure shall be stretched out upon Jerusalem. 

#### Zechariah 1:17 Shout aloud again! saying, Thus says the LORD of the of the forces; Yet shall {be dispersed cities} for good things, and the LORD shall show mercy still on Zion, and shall select still Jerusalem. 

#### Zechariah 1:18 And I lifted my eyes, and I looked, and behold, four horns. 

#### Zechariah 1:19 And I said to the angel, the one speaking with me, What are these, O lord? And he said to me, These are the horns, the ones scattering Judah, and Israel, and Jerusalem. 

#### Zechariah 1:20 And {showed to me the LORD} four fabricators. 

#### Zechariah 1:21 And I said, What are these come to do? And he said to me, saying, These are the horns, the ones having scattered Judah, and they broke Israel, and not one of them lifted his head. And these are come forth to sharpen them in their hands -- the four horns {nations are} lifting up their horn against the land of the LORD to scatter it. 

#### Zechariah 2:1 And I lifted my eyes, and I beheld, and behold, a man, and in his hand was a measuring line of a surveyor. 

#### Zechariah 2:2 And I said to him, Where do you go? And he said to me, To measure out Jerusalem, and to see how great the width of it is, and how great the length. 

#### Zechariah 2:3 And behold, the angel speaking with me stopped, and another angel went forth to meet with him. 

#### Zechariah 2:4 And he said to him, Run and speak to that young man! saying, Fruitfully shall Jerusalem be inhabited because of a multitude of men and cattle in the midst of her. 

#### Zechariah 2:5 And I will be to her, says the LORD, a wall of fire round about, and {for glory I will be} in the midst of her. 

#### Zechariah 2:6 Oh, Oh flee from the land of the north! says the LORD. For from out of the four winds of the heaven I will gather you, says the LORD. 

#### Zechariah 2:7 Unto Zion escape! O ones dwelling with the daughter of Babylon. 

#### Zechariah 2:8 Because, thus says the LORD almighty, After glory he has sent me out unto the nations, the ones despoiling you; for the one touching you is as one touching the pupil of his eye. 

#### Zechariah 2:9 For behold, I bear my hand against them, and they will be spoils to the ones serving them. And you shall know that the LORD almighty has sent me. 

#### Zechariah 2:10 Be happy and glad, O daughter of Zion! For behold, I come, and I will encamp in the midst of you, says the LORD. 

#### Zechariah 2:11 And {shall take refuge nations many} unto the LORD in that day, and they will be to him for a people. And I will encamp in your midst, and you shall realize that the LORD almighty has sent me to you. 

#### Zechariah 2:12 And the LORD shall inherit Judah his portion upon the {land holy}, and will select still Jerusalem. 

#### Zechariah 2:13 Let {show reverence all flesh} from in front of the LORD; for he was awakened from out of {clouds his holy}. 

#### Zechariah 3:1 And {showed to me the LORD} Joshua the {priest great} standing in front of the angel of the LORD, and the devil standing at the right of him, being an adversary against him. 

#### Zechariah 3:2 And the LORD said to the devil, May the LORD reproach against you, O devil, and may the LORD reproach against you, the one choosing Jerusalem. Is this not a firebrand being pulled out of the fire? 

#### Zechariah 3:3 And Joshua was being clothed {garments with filthy}, and he stood in front of the angel. 

#### Zechariah 3:4 And the angel responded and said to the ones standing in front of him, saying, Remove the {garments filthy} from him! And he said to him, Behold, I took your iniquities. And you clothe him in a foot length robe! 

#### Zechariah 3:5 And he said, Place also a mitre and {turban a clean} upon his head! And they placed a mitre and {turban a clean} upon his head. And they put {around him garments}. And the angel of the LORD stood. 

#### Zechariah 3:6 And {testified the angel of the LORD} to Joshua, saying, 

#### Zechariah 3:7 Thus says the LORD almighty, If {in my ways you should go}, and {my orders should keep guard}, then you shall litigate my house; and you shall guard my courtyard, and I will give to you ones pacing in the midst of these standing. 

#### Zechariah 3:8 Hear indeed, O Joshua the {priest great}! you and your neighbors, the ones sitting down before in front of you. For {men that are observers of signs they are}. For behold, I will bring my servant -- rising. 

#### Zechariah 3:9 For the stone which I put before the face of Joshua; upon the {stone one seven eyes are}. Behold, I dig an excavation, says the LORD almighty; and I will handle all the injustice of the land in {day one}. 

#### Zechariah 3:10 In that day, says the LORD almighty, you shall call together each his neighbor underneath a grapevine and underneath a fig-tree. 

#### Zechariah 4:1 And {returned the angel speaking with me}; and he awakened me, in which manner whenever {should be awakened a man} from out of his sleep. 

#### Zechariah 4:2 And he said to me, What do you see? And I said, I have seen, and behold, a lamp-stand {of gold entirely}, and the oil lamp bowl upon it, and seven lamps upon it, and seven oil funnels to the seven lamps upon it, 

#### Zechariah 4:3 and two olive trees upon it, one at the right of its oil lamp bowl, and one at the left. 

#### Zechariah 4:4 And I asked, and I said to the angel, the one speaking with me, saying, What are these, O lord? 

#### Zechariah 4:5 And {answered the angel}, the one speaking with me. And he said to me, Do you not know what these are? And I said, No, O lord. 

#### Zechariah 4:6 And he responded and said to me, saying, This is the word of the LORD to Zerubbabel, saying, Not by {power great}, nor by strength, but by my spirit, says the LORD almighty. 

#### Zechariah 4:7 Who are you {mountain great} before the face of Zerubbabel to set up? And I will bring forth the stone of the inheritance {equaling my favor of its favor}. 

#### Zechariah 4:8 And came to pass the word of the LORD to me, saying, 

#### Zechariah 4:9 The hands of Zerubbabel laid the foundation of this house, and his hands shall complete it; and you shall recognize that the LORD almighty has sent me to you. 

#### Zechariah 4:10 For who treated with contempt {days small}? And they shall rejoice, and shall see the {stone plummet tin} in the hand of Zerubbabel; these seven eyes of the LORD are the ones looking upon all the earth. 

#### Zechariah 4:11 And I responded and said to him, What are {two olive trees these}, the ones on the right side of the lamp-stand, and on the left? 

#### Zechariah 4:12 And I asked of a second time, and I said to him, What are the two branches of the olive trees, the ones by the handles of the two tubes of gold of the ones pouring and returning back the oil by funnels of gold? 

#### Zechariah 4:13 And he spoke to me, saying, Do you know not what these are? And I said, No, O lord. 

#### Zechariah 4:14 And he said, These are the two sons of fatness, they stand beside the LORD of all the earth. 

#### Zechariah 5:1 And I turned, and I lifted my eyes, and I saw, and behold, a sickle flying. 

#### Zechariah 5:2 And he said to me, What do you see? And I said, I see a sickle flying, the length -- {cubits twenty}, and the width -- {cubits ten}. 

#### Zechariah 5:3 And he said to me, This is the curse, the one going forth upon the face of all the earth; for every thief of this one side {unto death shall be punished}, and every perjurer of this other side {unto death shall be punished}. 

#### Zechariah 5:4 And I will bring it forth, says the LORD almighty, and it shall enter into the house of the thief, and into the house of the one swearing an oath by my name for a lie; and it shall rest in the midst of his house, and it shall finish it off entirely, even its wood and its stones. 

#### Zechariah 5:5 And came forth the angel, the one speaking to me, and he said to me, Look up with your eyes, and behold what this going forth is! 

#### Zechariah 5:6 And I said, What is it? And he said, This is the measure basket going forth. And he said, This is their iniquity in all the earth. 

#### Zechariah 5:7 And behold, a talent of lead was being lifted away; and behold, {woman one} sat down in the midst of the measure basket. 

#### Zechariah 5:8 And he said, This is lawlessness. And he tossed it into the midst of the measure basket, and he tossed the stone of lead into her mouth. 

#### Zechariah 5:9 And I lifted my eyes, and I saw, and behold, two women going forth, and the wind was in their wings, and these had wings as wings of the hoopoe bird; and they took up the measure basket between the earth and the heaven. 

#### Zechariah 5:10 And I said to the angel, the one speaking with me, Where are these carrying the measure basket? 

#### Zechariah 5:11 And he said to me, They build for it a house in the land of Babylon, and to prepare. And they shall put it there upon its preparation place. 

#### Zechariah 6:1 And I turned, and lifted my eyes; and I beheld, and behold, four chariots going forth from out of the midst of two mountains; and the mountains were mountains of brass. 

#### Zechariah 6:2 With the {chariot first horses reddish}; and with the {chariot second horses black}; 

#### Zechariah 6:3 and with the {chariot third horses white}; and with the {chariot fourth horses spotted} and dapple-gray. 

#### Zechariah 6:4 And I answered and said to the angel, the one speaking with me, What are these, O lord? 

#### Zechariah 6:5 And {answered the angel}, the one speaking with me. And he said, These are the four winds of the heaven, and they go forth to stand beside the Lord of all the earth, 

#### Zechariah 6:6 with which were {horses the black} -- they went forth upon the land of the north; and the white -- they went forth after them; and the spotted -- they went forth upon the land of the south, 

#### Zechariah 6:7 and dapple-gray -- they went forth, and they looked to travel about the earth. And he said, Go and travel about the earth! And they traveled about the earth. 

#### Zechariah 6:8 And he yelled out and spoke to me, saying Behold, the ones going forth upon the land of the north caused rest for my rage in the land of the north. 

#### Zechariah 6:9 And came to pass the word of the LORD to me, saying, 

#### Zechariah 6:10 Take the ones of the captivity from the rulers, and from its profitable ones, and from the ones recognizing it! And you shall enter in that day, into the house of Josiah the son of Zephaniah, the one having come from out of Babylon. 

#### Zechariah 6:11 And you shall take silver and gold, and you shall make crowns, and you shall place upon the head of Joshua the son of Josedech the {priest great}. 

#### Zechariah 6:12 And you shall say to him, Thus says the LORD almighty, Behold, a male, Rising is his name; and from beneath him he shall rise and shall build the house of the LORD. 

#### Zechariah 6:13 And he shall receive virtue, and shall sit and rule upon his throne; and there shall be a priest at his right. And {counsel peaceable} will be between both. 

#### Zechariah 6:14 But the crown will be to the ones waiting, and to the ones profitable of her, and to the ones recognizing her, and for the favor of the son of Zephaniah, and for a psalm in the house of the LORD. 

#### Zechariah 6:15 And the ones far from them shall come, and they shall build in the house of the LORD. And you shall know that the LORD almighty has sent me to you; and it will be as if ones listening should have listened to the voice of the LORD your God. 

#### Zechariah 7:1 And it came to pass in the fourth year of Darius the king, {came the word of the LORD} to Zechariah the fourth of the {month ninth}, which is Chisleu. 

#### Zechariah 7:2 And {sent to Beth-el Sherezar}, and Regem the king, and his men, to atone the LORD, 

#### Zechariah 7:3 saying to the priests in the house of the LORD almighty, and to the prophets, saying, {has entered here in the fifth month The sanctified offering}, as it did already a fit number of years. 

#### Zechariah 7:4 And came to pass the word of the LORD of the forces to me, saying, 

#### Zechariah 7:5 Speak to all the people of the land, and to the priests, saying, If you should fast or beat your chest in the fifth or in the seventh months, and behold, for seventy years, by fasting have you fasted to me? 

#### Zechariah 7:6 And if you should eat or should drink, do you not eat and drink to yourselves? 

#### Zechariah 7:7 {not these my words Are}, which the LORD spoke by the hands of the prophets, of the ones before, when Jerusalem was inhabited, and prospering? and her cities round about, and the mountainous area, and the plain was inhabited? 

#### Zechariah 7:8 And came to pass the word of the LORD to Zechariah, saying, 

#### Zechariah 7:9 Thus says the LORD almighty, saying, {judgment A just} you shall judge, and {mercy and compassion let execute each} towards his brother! 

#### Zechariah 7:10 And {the widow and orphan and foreigner and needy tyrannize not}! and {the hurt each of his brother not let resent} in your hearts! 

#### Zechariah 7:11 And they resisted to take heed, and they gave their backside ranting, and {their ears pressed} to not listen, 

#### Zechariah 7:12 and their heart was ordered for resisting persuasion, to not listen to my law, and the words which {sent out the LORD almighty} by his spirit, by the hands of the prophets, of the ones before. And there was {anger great} by the LORD almighty. 

#### Zechariah 7:13 And it will be in which manner I spoke, and they did not listen to him, so they shall cry out, and in no way shall I listen, says the LORD almighty. 

#### Zechariah 7:14 And I will cast them into all the nations which they did not know. And the land shall be obliterated after them from traveling, and from returning through it. Yes, they ordered up the {land choice} for extinction. 

#### Zechariah 8:1 And came to pass the word of the LORD almighty, saying, 

#### Zechariah 8:2 Thus says the LORD almighty, I have been zealous for Jerusalem and Zion {zeal with a great}; even {rage with great} I have been zealous over her. 

#### Zechariah 8:3 Thus says the LORD, I will return unto Zion, and I will encamp in the midst of Jerusalem. And {will be called Jerusalem city the true}, and the mountain of the LORD almighty, {mountain the holy}. 

#### Zechariah 8:4 Thus says the LORD almighty, Yet shall sit down older men and older women in the squares of Jerusalem, each {his cane having} in his hand because of a multitude of days. 

#### Zechariah 8:5 And the squares of the city shall be filled with boys and girls playing in her squares. 

#### Zechariah 8:6 Thus says the LORD almighty, Shall it be impossible in the presence of the remnant of this people in those days, no. Shall {also before me it be impossible}, says the LORD almighty, no. 

#### Zechariah 8:7 Thus says the LORD almighty, Behold, I shall deliver my people from the land of the east, and from the land of the west. 

#### Zechariah 8:8 And I will bring them, and they will encamp in the midst of Jerusalem; and they will be to me for a people, and I will be to them for God, in truth and in righteousness. 

#### Zechariah 8:9 Thus says the LORD almighty, Strengthen your hands, O ones hearing in these days these words from the mouth of the prophets, from which day {was founded the house of the LORD almighty}, and {the temple from which day} was built. 

#### Zechariah 8:10 For before those days the wage of men will not be for profitability, and the wage of the cattle does not exist. And to the one going forth and to the one entering there will be no peace because of the affliction. And I shall send out all the men, each against his neighbor. 

#### Zechariah 8:11 And now, not according to the days prior will I do to the remnant of this people, says the LORD almighty, 

#### Zechariah 8:12 but I will show peace; The grapevine shall give her fruit, and the earth will give her produce, and the heaven will give its dew; and I will allot to the remnants of my people all these things. 

#### Zechariah 8:13 And it will be in which manner you were a curse among the nations, O house of Judah, and O O house of Israel; so shall I preserve you, and you will be a blessing. Be of courage and grow strong in your hands! 

#### Zechariah 8:14 For thus says the LORD almighty, In which manner I consider to inflict evil on you in {provoking me to anger your fathers}, says the LORD almighty, and I did not change my mind. 

#### Zechariah 8:15 So I was deployed and have considered in these days {well to do} for Jerusalem and the house of Judah -- be of courage! 

#### Zechariah 8:16 These are the matters which you shall do. Let {speak truth each} to his neighbor, and {judgment peaceable}, and {righteously judge} at your gates! 

#### Zechariah 8:17 And {each evil against his neighbor not let consider} in your hearts! And {oath a lying do not love}! For all these things I detested, says the LORD almighty. 

#### Zechariah 8:18 And came to pass the word of the LORD almighty to me, saying, 

#### Zechariah 8:19 Thus says the LORD almighty, Fasting on the fourth month, and fasting on the fifth, and fasting on the seventh, and fasting on the tenth, shall be to the house of Judah for joy and gladness, and for {holiday feasts good}; and you shall be glad, and {truth and peace love}. 

#### Zechariah 8:20 Thus says the LORD almighty, Still there shall come {peoples many}, and dwelling {cities many}. 

#### Zechariah 8:21 And shall come together ones dwelling cities to one city, saying, We should go to beseech the face of the LORD, and to seek after the face of the LORD almighty -- {shall go even I}. 

#### Zechariah 8:22 And there shall come {peoples many} and many nations to seek after the face of the LORD almighty in Jerusalem, and to atone in front of the LORD. 

#### Zechariah 8:23 Thus says the LORD almighty, In those days {shall take hold ten men} of ones of all the languages of nations. And they shall take hold of the decorative hem of a Jewish man, saying, We shall go with you, because we have heard that God {with you is}. 

#### Zechariah 9:1 The concern of the word of the LORD against the land of Hadrach, and {of Damascus his sacrifice}. For the LORD inspects men, and all the tribes of Israel; 

#### Zechariah 9:2 and Hamath among her limits, Tyre and Sidon, for they thought exceedingly. 

#### Zechariah 9:3 And Tyre built a fortress to herself, and treasured up silver as dust, and gathered gold as mud of streets. 

#### Zechariah 9:4 On account of this, the LORD will inherit her, and he shall strike {in the sea her power}; and she {by fire shall be consumed}. 

#### Zechariah 9:5 Ashkelon shall see, and shall fear; and Gaza, even she shall grieve exceedingly; and Ekron, for she shall be ashamed over her transgression; and {shall perish the king} from Gaza; and Ashkelon in no way should be inhabited. 

#### Zechariah 9:6 And foreigners shall dwell in Ashdod, and I will demolish the insolence of the Philistines. 

#### Zechariah 9:7 And I will lift away their blood from out of their mouth, and their abominations from between their teeth. And they shall leave behind also these to our God; and they will be as under a commander of a thousand in Judah; and Ekron will be as the Jebusite. 

#### Zechariah 9:8 And I will stand my house on a height, so as to not travel through nor return. And in no way should there come upon them any longer ones launching an expedition, because now I have seen with my eyes. 

#### Zechariah 9:9 Rejoice exceedingly, O daughter of Zion! Proclaim, O daughter of Jerusalem! Behold, your king comes to you, righteous and delivering. He is gentle and mounted upon a beast of burden, even {foal a young}. 

#### Zechariah 9:10 And he shall utterly destroy chariots from Ephraim, and the horse from Jerusalem; {shall be utterly destroyed the bow of warfare}, and abundance and peace out of nations. And he shall rule waters unto the sea, and from rivers of the passes of the earth. 

#### Zechariah 9:11 And you, by the blood of your covenant, sent out your prisoners from the pit not having water. 

#### Zechariah 9:12 You shall settle {in fortresses prisoners of the congregation}; and for one day of your sojourning {double I will recompense to you}. 

#### Zechariah 9:13 For I stretched you tight to myself, O Judah, as a bow. I filled Ephraim, and I will awaken your children, O Zion, against the children of the Greeks. And I will handle you as the broadsword of a warrior. 

#### Zechariah 9:14 And the LORD {over them shall be seen}, and {shall go forth as lightning his arrow}. And the LORD God by a trumpet shall trump, and {goes for tossing about his intimidation}. 

#### Zechariah 9:15 The LORD almighty shall shield them; and they shall consume them, and shall heap upon them with stones of a sling; and they shall drink their blood as wine, and shall fill the bowls as an altar basin. 

#### Zechariah 9:16 And {shall deliver them the LORD their God} in that day as the sheep of his people. For {stones holy} shall roll upon his land. 

#### Zechariah 9:17 For if anything be good of his, and if any be fair of his, the grain will be for the young men, and wine being fragrant for the virgins. 

#### Zechariah 10:1 Ask of the LORD for rain according to season, the early and late rain. The LORD made a visible display; and the rain of winter he gives to them; to each, pasturage in the field. 

#### Zechariah 10:2 For the ones declaring maxims speak troubles, and the clairvoyants {visions false}; and {dreams false they speak}. In vain they comfort. On account of this they dry up as sheep, and they were afflicted that there was no healing. 

#### Zechariah 10:3 {over the shepherds was provoked My rage}, and over the lambs I visit}. And {will visit the LORD God almighty} his flock, the house of Judah. And he shall order them as {horse his good-looking} in battle. 

#### Zechariah 10:4 And from him he looked out upon, and from him he ordered a bow in rage, and from him shall come forth every expedition by him. 

#### Zechariah 10:5 And they shall be as warriors treading mud in the ways in battle. And they shall deploy, because the LORD is with them, and {shall be disgraced the riders of horses}. 

#### Zechariah 10:6 And I will strengthen the house of Judah. And the house of Joseph I will deliver. And I will settle them; for I loved them. And they will be in which manner when {not them I disowned}. Because I am the LORD their God, and I shall take heed of them. 

#### Zechariah 10:7 And they will be as warriors to Ephraim, and {shall rejoice their heart} as with wine. And their children shall see, and be glad, and {shall rejoice their heart} over the LORD. 

#### Zechariah 10:8 I will signify for them, and I will take them in. For I will ransom them, and they shall be multiplied, in so far as they were many. 

#### Zechariah 10:9 And I will sow them among peoples, and the ones far off shall remember me. And they shall nourish their children, and they shall return. 

#### Zechariah 10:10 And I will turn them from out of the land of Egypt; and from the Assyrians I will take them in; and into the land of Gilead, and into Lebanon I will bring them; and in no way should there be left behind of them not even one. 

#### Zechariah 10:11 And they shall go through by {sea the narrow}, and they shall strike {in the sea waves}; and {shall be dried up all the depths of rivers}. And {shall be removed all the insolence of the Assyrians}; and the staff of Egypt shall be removed. 

#### Zechariah 10:12 And I will strengthen them in the LORD their God; and in his name they shall boast, says the LORD. 

#### Zechariah 11:1 Open wide, O Lebanon, your doors, and let {devour fire} your cedars! 

#### Zechariah 11:2 Let {shriek the pine}! because {has fallen the cedar}, for {were in misery great ones}. Shriek, O oaks of Bashan! for {were torn down groves the planted}. 

#### Zechariah 11:3 A sound of wailing of shepherds, for {languishes their greatness}. A sound of roaring lions, for {languishes the neighing of the Jordan}. 

#### Zechariah 11:4 Thus says the LORD almighty, Tend the sheep of the slaughter, 

#### Zechariah 11:5 which the ones acquiring butcher, and are repenting not. And the ones selling them said, Blessed be the LORD, we were enriched. And their shepherds suffered not anything for them. 

#### Zechariah 11:6 On account of this, I will not spare any longer over the ones inhabiting the land, says the LORD. And behold, I deliver up the men, each into the hand of his neighbor, and into the hand of his king; and they shall cut in pieces the land, and in no way should I rescue from out of their hand. 

#### Zechariah 11:7 And I will tend the sheep of the slaughter in the land of the Canaanites. And I will take for myself two rods; the one I called Beauty, and the other I called, A piece of measured out land; and I will tend the sheep. 

#### Zechariah 11:8 And I will lift away the three shepherds in {month one}; and {shall be weighed down my soul} over them, for their souls roared against me. 

#### Zechariah 11:9 And I said, I will not tend you. The dying, let it die! And the failing, let it fail! and the rest, let them {eat each} the flesh of his neighbor! 

#### Zechariah 11:10 And I will take my rod, Beauty, and I will throw it away to efface my covenant which I ordained with all the peoples. 

#### Zechariah 11:11 And it shall be effaced in that day. And {shall know the Canaanites} the sheep being guarded for me, that {the word of the LORD it is}. 

#### Zechariah 11:12 And I will say to them, if {good before you it is}, give my wage, or forbid it! And they established my wage -- thirty pieces of silver. 

#### Zechariah 11:13 And the LORD said to me, Lower them into the foundry furnace! and to look about if it is unadulterated! in which manner I was proved for them. And I took the thirty pieces of silver, and I put them into the house of the LORD, into the foundry furnace. 

#### Zechariah 11:14 And I threw away my rod, the second, A Piece of Measured out Land -- to efface the taking possession the thing between Judah and between Israel. 

#### Zechariah 11:15 And the LORD said to me, Yet take to yourself the equipment of a shepherd -- {shepherd an inexperienced}! 

#### Zechariah 11:16 For behold, I shall arouse a shepherd against the land, one who {the one faltering in no way shall visit}; and {the one being dispersed in no way shall he seek}; and {the one being broken in no way shall he heal}; and {the whole in no way shall he conduct}. And {meats of the choice} he shall devour, and {their vertebrae he shall distort}. 

#### Zechariah 11:17 O the ones tending the vain things, and leaving behind the sheep; a sword shall be against his arm, and against {eye his right}. His arm withering shall be withered, and {eye his right} by blinding shall be blinded. 

#### Zechariah 12:1 The concern of the word of the LORD over Israel, says the LORD, the one stretching out the heaven, and laying the foundation for the earth, and shaping the spirit of man in him. 

#### Zechariah 12:2 Behold, I appoint Jerusalem as thresholds for shaking off all the peoples round about, and in Judea there will be an encompassing about against Jerusalem. 

#### Zechariah 12:3 And it will be in that day I will appoint Jerusalem as a stone being trampled on by all the nations. Every one trampling her with mocking shall mock, and {shall be assembled against her all the nations of the earth}. 

#### Zechariah 12:4 In that day, says the LORD almighty, I will strike every horse with astonishment, and its rider in ranting. But over the house of Judah I will open my eyes, and all the horses of the peoples I will strike with blindness. 

#### Zechariah 12:5 And {shall say the commanders of thousands of Judah} in their hearts, We shall find ourselves of the ones dwelling Jerusalem in the LORD almighty their God. 

#### Zechariah 12:6 In that day I will make the commanders of thousands of Judah as a firebrand of fire among the wood, and as a lamp of fire among stubble; and they shall devour from the right, and from the left all the peoples round about. And Jerusalem shall dwell yet according to herself in Jerusalem. 

#### Zechariah 12:7 And the LORD shall deliver the tents of Judah as at the beginning, so that {should not magnify their boasting the house of David}, and the haughtiness of the ones dwelling in Jerusalem over Judah. 

#### Zechariah 12:8 And it will be in that day the LORD will shield over the ones dwelling Jerusalem. And it will be the one being weak among them in that day will be as David, and the house of David as the house of God, as the angel of the LORD before them. 

#### Zechariah 12:9 And it shall be in that day I will seek to lift away all the nations, the ones coming against Jerusalem. 

#### Zechariah 12:10 And I will pour out upon the house of David, and upon the ones dwelling Jerusalem a spirit of favor and compassion. And they shall look to me, because they treated me despitefully; and they shall beat over him with a beating of the breast, as over a beloved one; and they shall grieve with grief as over the first-born. 

#### Zechariah 12:11 In that day {shall be magnified beating the breast} in Jerusalem, as the beating of the breast over the pomegranate grove in the plain having been cut down. 

#### Zechariah 12:12 And {shall beat the chest the land}, according to tribes by tribes; the tribe of the house of David by itself, and their wives by themselves; the tribe of the house of Nathan by itself, and their wives by themselves; 

#### Zechariah 12:13 the tribe of the house of Levi by itself, and their wives by themselves; the tribe of Simeon by itself, and their wives by themselves. 

#### Zechariah 12:14 All the tribes being left behind, a tribe by itself, and their wives by themselves. 

#### Zechariah 13:1 In that day {will be every place} opening wide to the house of David and to the ones dwelling in Jerusalem for the removal and for the sprinkling. 

#### Zechariah 13:2 And it will be in that day, says the LORD of Hosts, I will utterly destroy the names of the idols from the land, and there will not be any longer a memory of them. And the false prophets and the {spirit unclean} I will remove from the land. 

#### Zechariah 13:3 And it will be if {should prophesy a man} still, and shall say to him his father and his mother, the ones engendering him, You shall not live, for {lies you spoke} upon the name of the LORD; then they shall bind him (his father and his mother, the ones engendering him) at his prophesying. 

#### Zechariah 13:4 And it will be in that day {shall be disgraced the prophets}, each at his vision when he prophesies; and they shall put on {hide covering a hair}, because they lied. 

#### Zechariah 13:5 And he shall say, {am not a prophet I}, for {a man working the ground I am}; for a man engendered me from my youth. 

#### Zechariah 13:6 And I will say to him, What are these wounds in the middle of your hands? And he will say, The ones which I was struck by in the house of my beloved. 

#### Zechariah 13:7 O broadsword, awaken against my shepherds, and against a man, my fellow-countryman! says the LORD almighty. Strike the shepherd! and {were dispersed the sheep}. And I will bring my hand upon the shepherds. 

#### Zechariah 13:8 And it will be in that day, says the LORD, the two parts shall be utterly destroyed, and shall cease; but the third part shall be left in it. 

#### Zechariah 13:9 And I shall lead the third part through fire, and I will purify them as {is fired silver}, and I will try them as {is tried gold}. He will call upon my name, and I will heed him. And I will say, {my people This is}. And he shall say, The LORD is my God. 

#### Zechariah 14:1 Behold, days {come of the LORD}, and {shall be divided your spoils} among you. 

#### Zechariah 14:2 And I will assemble all the nations against Jerusalem for battle; and {shall be captured the city}, and {shall be plundered the houses}, and the women shall be tainted. And shall come forth half the city into captivity, and the rest of my people in no way shall be utterly destroyed from the city. 

#### Zechariah 14:3 And the LORD shall come forth, and he shall deploy against those nations, as the day of his battle array in the day of war. 

#### Zechariah 14:4 And {shall stand his feet} in that day upon the mount of olives, the one over against Jerusalem according to the east; and {shall split the mount of olives}, half of it towards the east and west, {chaos great an exceedingly}. And {shall lean half of the mountain} towards the north, and half of it towards the south. 

#### Zechariah 14:5 And {shall be obstructed the valley of my mountains}, and {shall be joined together the ravine} by mountains unto Azal. And it shall be obstructed in which manner it was obstructed from in front of the earthquake in the days of Uzziah king of Judah. And {shall come the LORD my God}, and all the holy ones with him. 

#### Zechariah 14:6 And it will be in that day there shall not be light; and chilliness and ice. 

#### Zechariah 14:7 It shall be one day, and that day shall be known to the LORD, and neither day nor night, and towards evening it shall be light. 

#### Zechariah 14:8 And it shall be in that day shall come forth {water living} from out of Jerusalem. The half of it into the {sea foremost}, and half of it into the {sea latter}; in summer and in spring thus it will be. 

#### Zechariah 14:9 And the LORD will be for king over all the earth. In that day there shall be { LORD one}, and his name one, 

#### Zechariah 14:10 encircling all the earth, and the wilderness -- from Geba unto Remmon according to the south of Jerusalem. And Rama {in its place shall remain}; from the gate of Benjamin unto the place of the {gate first}, and unto the gate of the corners, and unto the tower of Hananeel, unto the wine-vats of the king. 

#### Zechariah 14:11 And they shall dwell in it, and {anathema it will not be} any longer; and Jerusalem shall dwell securely. 

#### Zechariah 14:12 And this will be the downfall in which the LORD shall smite all the peoples, as many as marched against Jerusalem. {shall melt away Their flesh} while standing upon their feet; and their eyes shall flow from out of their openings, and their tongue shall melt away in their mouth. 

#### Zechariah 14:13 And there will be in that day {astonishment from the LORD a great} upon them; and they shall take hold each the hand of his neighbor, and shall closely join his hand to the hand of his neighbor. 

#### Zechariah 14:14 And Judah shall deploy in Jerusalem; and he shall bring together the strength of all the peoples round about -- gold, and silver, and clothes into abundance exceedingly. 

#### Zechariah 14:15 And this will be the downfall of the horses, and the mules, and the camels, and the donkeys, and of all the cattle of the ones being in those camps, according to this downfall. 

#### Zechariah 14:16 And it will be as many as should be left of all the nations coming against Jerusalem, that they shall ascend by year to do obeisance to the king, to the LORD almighty, and to solemnize the holiday of the pitching of tents. 

#### Zechariah 14:17 And it will be as many as should not ascend from out of all the tribes of the earth unto Jerusalem to do obeisance to the king, to the LORD almighty, and these things shall be added to those -- there shall not be {upon them rain}. 

#### Zechariah 14:18 And if the tribe of Egypt should not ascend, nor come, then upon these will be the downfall which the LORD struck all the nations, as many as should not ascend to solemnize the holiday of the pitching of tents. 

#### Zechariah 14:19 This will be the sin of Egypt, and the sin of all the nations which ever should not ascend to solemnize the holiday of the pitching of tents. 

#### Zechariah 14:20 In that day there will be upon the bridle of the horse, Holy to the LORD Almighty. And {will be the kettles in the house of the LORD} as bowls before the face of the altar. 

#### Zechariah 14:21 And it will be every kettle in Jerusalem and in Judah holy to the LORD almighty. And {shall come all the ones sacrificing} and shall take of them; and they shall cook with them. And there will not be any longer the Canaanite in the house of the LORD of the forces in that day.