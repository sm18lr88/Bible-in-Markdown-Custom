#### Obadiah 1:1 The vision of Obadiah. Thus says the LORD God to Edom. {a report I heard} from the LORD, and a summary he sent out unto the nations, saying, Rise up! even we should rise up against her for battle. 

#### Obadiah 1:2 Behold, {very few I have made you} among the nations, disgracing you exceedingly. 

#### Obadiah 1:3 Pride of your heart lifted you up, encamping in the openings of the rocks, exalting his dwelling, saying in his heart, Who shall lead me down unto the ground? 

#### Obadiah 1:4 If you should rise up on high as an eagle, and if in the midst of the stars you should put your nest, from there I will lead you down, says the LORD. 

#### Obadiah 1:5 If thieves entered to you, or robbers by night, where would you be thrown away? Would they not have stolen the things fit for themselves? And if grape gatherers entered to you, would they not have left behind a gleaning? 

#### Obadiah 1:6 How was Esau searched out, and {forsaken his hidden things}? 

#### Obadiah 1:7 Unto the borders they sent you; all the men of your covenant opposed you; they prevailed against you; {men peaceable} with you put an ambush underneath you. There is no understanding in them. 

#### Obadiah 1:8 In that day, says the LORD, I will destroy the wise ones from out of Edom, and understanding from the mount of Esau. 

#### Obadiah 1:9 And {shall be terrified your warriors}, the ones from Teman, so that {shall be removed man} from the mountain of Esau. 

#### Obadiah 1:10 Because of the slaughter and the impiety against your brother Jacob, {shall cover you shame}, and you shall be removed into the eon. 

#### Obadiah 1:11 From which day you opposed right opposite, in the day of the capturing by foreigners of his force, and strangers entered into his gates, and over Jerusalem they cast lots, even you were as one of them. 

#### Obadiah 1:12 And you should not have looked upon the day of your brother in the day of strangers; and you should not have rejoiced over the sons of Judah in the day of their destruction; and you should not have spoken great words in the day of their affliction; 

#### Obadiah 1:13 nor should you have entered into the gates of peoples in the day of their miseries; and you should not have looked, even you, upon their gathering in the day of their ruin; and you should not have joined in an attack upon their force in the day of their destruction; 

#### Obadiah 1:14 nor should you have stood upon their mountain passes to utterly destroy the ones escaping of them; nor should you have closed up the ones fleeing from them in the day of their affliction. 

#### Obadiah 1:15 For {is near the day of the LORD} upon all the nations. In which manner you did, so it will be to you. Your recompense shall be recompensed unto your head. 

#### Obadiah 1:16 For in which manner you drank upon {mountain my holy}, {shall drink so all the nations} wine; they shall drink, and they shall swallow down, and they shall be as not having existed. 

#### Obadiah 1:17 But on mount Zion there will be deliverance, and there will be a holy place. And {shall inherit the house of Jacob} the ones inheriting them. 

#### Obadiah 1:18 And {will be the house of Jacob} fire, and the house of Joseph a flame, but the house of Esau for stubble, and they shall be burnt in them, and they shall devour them; and there will not be a wheat harvest to the house of Esau; for the LORD spoke. 

#### Obadiah 1:19 And {shall inherit the ones in the Negev} the mountain of Esau, even the ones dwelling in the Sephela of the Philistines. And they shall inherit the mountain of Ephraim, and the plain of Samaria, and Benjamin, and the land of Gilead. 

#### Obadiah 1:20 And the displacement of this company to the sons of Israel shall inherit that of the Canaanites, unto Zarephath; and the displacement of Jerusalem, unto Ephratah, shall inherit the cities of the Negev. 

#### Obadiah 1:21 And {shall ascend the ones being rescued} from mount Zion to take vengeance on the mountain of Esau; and {will be to the LORD the kingdom}.