#### Obadiah 1:1  The vision of Obadiah. Thus says the Lord GOD concerning Edom: We have heard a report from the LORD, and a messenger has been sent among the nations: “Rise up! Let us rise against her for battle!”
#### Obadiah 1:2  Behold, I will make you small among the nations; you shall be utterly despised.
#### Obadiah 1:3  The pride of your heart has deceived you, you who live in the clefts of the rock, in your lofty dwelling, who say in your heart, “Who will bring me down to the ground?”
#### Obadiah 1:4  Though you soar aloft like the eagle, though your nest is set among the stars, from there I will bring you down, declares the LORD.
#### Obadiah 1:5  If thieves came to you, if plunderers came by night— how you have been destroyed!— would they not steal only enough for themselves? If grape gatherers came to you, would they not leave gleanings?
#### Obadiah 1:6  How Esau has been pillaged, his treasures sought out!
#### Obadiah 1:7  All your allies have driven you to your border; those at peace with you have deceived you; they have prevailed against you; those who eat your bread have set a trap beneath you— you have no understanding.
#### Obadiah 1:8  Will I not on that day, declares the LORD, destroy the wise men out of Edom, and understanding out of Mount Esau?
#### Obadiah 1:9  And your mighty men shall be dismayed, O Teman, so that every man from Mount Esau will be cut off by slaughter.
#### Obadiah 1:10  Because of the violence done to your brother Jacob, shame shall cover you, and you shall be cut off forever.
#### Obadiah 1:11  On the day that you stood aloof, on the day that strangers carried off his wealth and foreigners entered his gates and cast lots for Jerusalem, you were like one of them.
#### Obadiah 1:12  But do not gloat over the day of your brother in the day of his misfortune; do not rejoice over the people of Judah in the day of their ruin; do not boast in the day of distress.
#### Obadiah 1:13  Do not enter the gate of my people in the day of their calamity; do not gloat over his disaster in the day of his calamity; do not loot his wealth in the day of his calamity.
#### Obadiah 1:14  Do not stand at the crossroads to cut off his fugitives; do not hand over his survivors in the day of distress.
#### Obadiah 1:15  For the day of the LORD is near upon all the nations. As you have done, it shall be done to you; your deeds shall return on your own head.
#### Obadiah 1:16  For as you have drunk on my holy mountain, so all the nations shall drink continually; they shall drink and swallow, and shall be as though they had never been.
#### Obadiah 1:17  But in Mount Zion there shall be those who escape, and it shall be holy, and the house of Jacob shall possess their own possessions.
#### Obadiah 1:18  The house of Jacob shall be a fire, and the house of Joseph a flame, and the house of Esau stubble; they shall burn them and consume them, and there shall be no survivor for the house of Esau, for the LORD has spoken.
#### Obadiah 1:19  Those of the Negeb shall possess Mount Esau, and those of the Shephelah shall possess the land of the Philistines; they shall possess the land of Ephraim and the land of Samaria, and Benjamin shall possess Gilead.
#### Obadiah 1:20  The exiles of this host of the people of Israel shall possess the land of the Canaanites as far as Zarephath, and the exiles of Jerusalem who are in Sepharad shall possess the cities of the Negeb.
#### Obadiah 1:21  Saviors shall go up to Mount Zion to rule Mount Esau, and the kingdom shall be the LORD's.
