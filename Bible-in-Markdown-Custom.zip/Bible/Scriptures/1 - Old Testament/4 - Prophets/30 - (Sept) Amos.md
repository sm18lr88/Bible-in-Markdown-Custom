#### Amos 1:1 The words of Amos, which took place in Kirjath Jearim of Tekoa, which he saw concerning Jerusalem in the days of Uzziah king of Judah, and in the days of Jeroboam son Joash king of Israel, {before two years} the earthquake. 

#### Amos 1:2 And he said, The LORD {from Zion uttered a sound}, and from Jerusalem he gave his voice; and {mourned the pastures of the shepherds}, and {was dried up the top of Carmel}. 

#### Amos 1:3 And the LORD said, For the three impious deeds of Damascus, even for the four, I will not turn away from him. Because they sawed {saws by iron} the ones {in the womb having one} in Gilead. 

#### Amos 1:4 And I will send a fire unto the house of Hazael, and it shall devour the foundations of the son of Hadad. 

#### Amos 1:5 And I shall break the bars of Damascus, and I will utterly destroy the inhabitants of the plain of On; and I will cut in pieces a tribe of the men of Eden; and {shall be captured people of Syria select}, says the LORD. 

#### Amos 1:6 Thus says the LORD, For the three impious deeds of Gaza, and for the four, I will not turn away from them. Because of their capturing the captivity of Solomon, to close them up in Edom. 

#### Amos 1:7 And I will send out fire upon the walls of Gaza, and it shall devour her foundations. 

#### Amos 1:8 And I will utterly destroy the inhabitants of Ashdod, and shall lift away a tribe from Ashkelon, and I will bring my hand upon Ekron. And {shall be destroyed the rest of the Philistines}, says the LORD. 

#### Amos 1:9 Thus says the LORD, For the three impious deeds of Tyre, even for the four, I will not turn away from her. Because they closed up the captivity of Solomon in Edom, and remembered not the covenant of brethren. 

#### Amos 1:10 And I will send out fire upon the walls of Tyre, and it shall devour her foundations. 

#### Amos 1:11 Thus says the LORD, For the three impious deeds of Edom, even for the four, I will not turn away from them. Because of {pursuing them with the broadsword his brother}, and he laid waste the mother upon the earth, and seized by force for a testimony of his shuddering awe; and his impulse he kept unto victory. 

#### Amos 1:12 And I will send forth fire against Teman, and it shall devour her foundations. 

#### Amos 1:13 Thus says the LORD, For the three impious deeds of the sons of Ammon, even for the four, I will not turn away from them. Because they ripped open the ones {in the womb having one} of the ones of Gilead, so that they should widen their borders. 

#### Amos 1:14 And I will light a fire even against the walls of Rabbah, and it shall devour her foundations with a cry in the day of war, and it shall be shaken in the days of her consumption. 

#### Amos 1:15 And {shall go king their} into captivity -- the priests and their rulers together, says the LORD. 

#### Amos 2:1 Thus says the LORD, For the three impious deeds of Moab, even for four, I shall not turn away from it. Because they incinerated the bones of the king of Edom into powder. 

#### Amos 2:2 And I will send fire upon Moab, and it shall devour the foundations of the cities. And {shall die in powerlessness Moab} with a sound and with a cry of a trumpet. 

#### Amos 2:3 And I will utterly destroy the judge from out of her; and all her rulers I will kill with him, says the LORD. 

#### Amos 2:4 Thus says the LORD, For the three impious deeds of the sons of Judah, even for the four, I will not turn away from it; Because of their thrusting away the law of the LORD, and his orders they kept not, and {caused them to wander their vain idols which they made}, the ones which {followed their fathers} after them. 

#### Amos 2:5 And I will send out fire upon Judah, and it shall devour the foundations of Jerusalem. 

#### Amos 2:6 Thus says the LORD, For the three impious deeds of Israel, even for the four, I will not turn away from. Because they rendered silver for the just, and the needy for sandals; 

#### Amos 2:7 trampling upon the dust of the earth; and they smote for the head of the poor, and the way of the humble they turned aside. And a son and his father entered to the same maidservant, so that they should profane the name of their God. 

#### Amos 2:8 And {their garments binding} with rough cords, {canopies they made} next to the altar; and wine of extortions they drank in the house of their God. 

#### Amos 2:9 But I lifted away the Amorite from in front of them, as the height of cedar in his height, and he was strong as an oak; and I removed his fruit on top, and his roots beneath. 

#### Amos 2:10 And I led you out of the land of Egypt, and led you about in the wilderness forty years, to inherit the land of the Amorites. 

#### Amos 2:11 And I took of your sons for prophets, and of your young men for sanctification. {not so Are these things}, O sons of Israel, says the LORD? 

#### Amos 2:12 But you gave {to drink for the ones having been sanctified wine}; and to the prophets you gave charge, saying, In no way prophesy! 

#### Amos 2:13 On account of this, behold, I roll you underneath; in which manner {rolls the wagon} being full of stubble. 

#### Amos 2:14 And {shall be destroyed flight into exile} from the runner; and the strong in no way should hold his strength; and the warrior in no way should deliver his soul; 

#### Amos 2:15 and the bowman in no way should stand; and the keen of his feet in no way should be preserved; and the horseman in no way should have delivered his life, 

#### Amos 2:16 and the strong in no way shall find his heart in might; the naked shall be pursued in that day, says the LORD. 

#### Amos 3:1 Hear this word! which the LORD spoke concerning you, O house of Israel, even against every tribe of which I led from out of the land of Egypt, saying, 

#### Amos 3:2 Only you I knew from out of all the tribes of the earth. On account of this I will take vengeance upon you for all your sins. 

#### Amos 3:3 Shall {go two} together altogether if they do not make themselves known to each other, no. 

#### Amos 3:4 Shall {bellow a lion} from out of his forest {game not having}, no. Shall {utter a cub} his voice from out of his haven altogether, if {should not have been seized anything}, no. 

#### Amos 3:5 Shall {fall a bird} upon the earth without a fowler, no. Shall {be opened up a snare} upon the earth without seizing anything, no. 

#### Amos 3:6 Shall {sound out loud the trumpet} in the city, and the people shall not be terrified, no. Shall hurt be in a city which the LORD did it not, no. 

#### Amos 3:7 For in no way shall {make the LORD God} a thing that he should not uncover instruction to his servants the prophets. 

#### Amos 3:8 A lion shall bellow, and who will not be fearful? The LORD God spoke, and who will not prophesy? 

#### Amos 3:9 Announce it to the places among the Assyrians, and unto the places in the land of Egypt! And say, Gather together upon the mountain of Samaria, and behold {wonders many} in the midst of her, and the tyranny in her! 

#### Amos 3:10 And he knew not what will be before her, says the LORD, the ones treasuring up injustice and misery in their regions. 

#### Amos 3:11 On account of this, thus says the LORD God, Tyre and round about your land shall be made desolate; and he shall lead out of you your strength, and shall tear in pieces your regions. 

#### Amos 3:12 Thus says the LORD, In which manner {should pull out the shepherd} from the mouth of the lion two legs or a lobe of an ear, so shall {be pulled out the sons of Israel}, the ones dwelling in Samaria before a foreign tribe, and in Damascus. 

#### Amos 3:13 O priests, hear and attest to the house of Jacob! says the LORD God almighty. 

#### Amos 3:14 For in the day whenever I shall avenge the impious deeds of Israel upon him, also I will take vengeance upon the altars of Beth-el. And {shall be razed the horns of the altar}, and shall fall upon the ground. 

#### Amos 3:15 I will confound and I will strike the {house turreted} upon the {house harvest}; and {shall be destroyed houses the ivory}, and {shall be added houses other many}, says the LORD. 

#### Amos 4:1 Hear this word, O heifers of the land of Bashan! the ones in the mountain of Samaria, the ones tyrannizing over the poor, and trampling upon the needy; the ones saying to their masters, Give over to us so that we should drink! 

#### Amos 4:2 The LORD swears an oath according to his holy things, For behold, days come upon you when they shall take you with weapons; and the ones with you {into kettles being fired up with they shall put fires pestilent}. 

#### Amos 4:3 And you shall be brought forth naked in front of one another, and you shall be thrown onto mount Renmon, says the LORD. 

#### Amos 4:4 You entered into Beth-el, and were impious; and in Gilgal you multiplied to be impious; and you brought in the morning of your sacrifice offerings in the third day of your tithes. 

#### Amos 4:5 And they read outside the law, and called for an acknowledgment offering. Announce! that {these things loved the sons of Israel}, says the LORD. 

#### Amos 4:6 And I will give to you an ache of teeth among all your cities, and lack of bread loaves in all your places; and you did not return to me, says the LORD. 

#### Amos 4:7 And I withheld from you the rain before the three months of the gathering of crops; and I shall rain upon {city one}, but upon {other city one} I will not rain; {portion one} there shall be rain, and the portion upon which I shall not rain shall be dry. 

#### Amos 4:8 And {shall be gathered together the inhabitants of two or three cities} to one city to drink water; and in no way shall they be filled up. And you returned not to me, says the LORD. 

#### Amos 4:9 I struck you with burning fire and with jaundice. You multiplied your gardens. Your vineyards, and your fig groves, and your olive groves -- {devoured them the caterpillar}. And neither thus you returned to me, says the LORD. 

#### Amos 4:10 I sent to you plague in the way of Egypt. I killed {by the broadsword your young men}, with a captivity of your horses. And I led {by fire your camps} in your anger, and neither thus you returned to me, says the LORD. 

#### Amos 4:11 I eradicated you as {eradicated God} Sodom and Gomorrah, and you became as a firebrand being pulled out from burning; and neither thus you returned to me, says the LORD. 

#### Amos 4:12 On account of this, thus I will do to you, O Israel. Furthermore that thus I will do to you, you prepare to call upon your God, O Israel! 

#### Amos 4:13 For behold, the one stiffening thunder, and creating wind, and reporting unto men his graciousness, producing the dawn and fog, and mounting upon the heights of the earth -- the LORD God almighty is his name. 

#### Amos 5:1 Hear the word of the LORD which I take up against you -- a lamentation! The house of Israel fell; no longer should it proceed to rise. 

#### Amos 5:2 Virgin Israel tripped upon its land; there is none raising her up. 

#### Amos 5:3 For thus says the LORD God, The city from out of which went a thousand, shall be left with a hundred; and from out of which went forth a hundred, shall be left ten to the house of Israel. 

#### Amos 5:4 For thus says the LORD to the house of Israel, Inquire of me! and you shall live. 

#### Amos 5:5 And do not seek after Beth-el, and into Gilgal enter not, and by Well of the Oath do not pass over! For Gilgal, by capturing shall be captured, and Beth-el will be as not existing. 

#### Amos 5:6 Inquire of the LORD, and live! so that {should not blaze up as fire the house of Joseph}, and it should devour him, and there shall not be the one extinguishing to the house of Israel. 

#### Amos 5:7 The one appointing {in the height judgment}, even {righteousness for the earth established}; 

#### Amos 5:8 The one making all things, and fashioning them differently, and turning {into the morning the shadow}, and {day into night darkening}; the one calling on the water of the sea, and pouring it upon the face of the earth -- the LORD God almighty is his name. 

#### Amos 5:9 The one dividing conflict into strength, and {misery upon the fortress the one bringing}. 

#### Amos 5:10 They detested {at the gates the one reproving}, and {word the sacred they abhorred}. 

#### Amos 5:11 On account of this, because they struck {with their fist the poor}, and {gifts choice they took} from them; {houses planed seeing that you built}, that in no way shall you dwell in them; {vineyards desirable you planted}, but in no way should you drink of their wine. 

#### Amos 5:12 For I knew many impious deeds of yours, and {mighty sins your} -- trampling the just, taking prices, and {the needy at the gates turning aside}. 

#### Amos 5:13 Because of this, the one perceiving in that time shall keep silent, for the time is evil. 

#### Amos 5:14 Inquire of the good, and not the wicked! so that you should live. And it will be thus -- the LORD God almighty with you in which manner you spoke, saying, 

#### Amos 5:15 We have detested the evil things, and we loved the good things. Then restore {in the gates judgment}! so that {should show mercy on the LORD God almighty} the residue of Joseph. 

#### Amos 5:16 On account of this, thus says the LORD God almighty, In all squares shall be a beating of the breast, and in all ways it shall be said, Woe, woe. {shall be called The farmer} unto mourning, and for beating of the breast, and for knowing wailing. 

#### Amos 5:17 Even in all the ways a beating of the breast. For I shall go through your midst, said the LORD. 

#### Amos 5:18 Woe, O ones desiring the day of the LORD, saying, What is this, {to us the day of the LORD}? Even this is darkness and not light. 

#### Amos 5:19 It will be in which manner if {should flee a man} from the face of a lion, and {should fall to him a bear}. And he should rush into his house, and should fasten his hands upon the wall, and {should bite it a serpent}. 

#### Amos 5:20 Is not darkness the day of the LORD, and not light? and dimness, not having brightness in it? 

#### Amos 5:21 I have detested, I have thrust away your holiday feasts, and in no way shall I savor in your festivals. 

#### Amos 5:22 For if you should bring to me whole burnt-offerings and your sacrifice offerings, I will not favorably receive them. And {deliverance offering the grandeur of your I will not look upon}. 

#### Amos 5:23 Remove from me the sound of your odes! and {the psalm of your instruments I will not hear}. 

#### Amos 5:24 And {shall roll down as water judgment}, and righteousness as {rushing stream an impassable}. 

#### Amos 5:25 Did {victims for slaughter and sacrifices you bring near to me}, O house of Israel, for forty years in the wilderness? 

#### Amos 5:26 And you took up the tent of Molech, and the star of your god, Raiphan, the impressions of them which you made for yourselves. 

#### Amos 5:27 And I will displace you beyond Damascus, says the LORD. God almighty is the name to him. 

#### Amos 6:1 Woe to the ones treating Zion with contempt, and to the ones yielding upon the mountain of Samaria; they harvested the heads of nations, and {entered themselves, the house of Israel}. 

#### Amos 6:2 Pass over all and behold, and go through from there into Hamath Rabba! And go down to Gath of the Philistines! {the most excellent out of these kingdoms Are you}? {greater than their borders Are your borders}? 

#### Amos 6:3 The ones coming unto {day an evil}; the ones approaching and attaching to {Sabbaths false}; 

#### Amos 6:4 the ones sleeping upon beds of ivory, and living wastefully upon their strewn beds, and eating kids of the flocks, and young calves of the midst of the herds -- sucklings; 

#### Amos 6:5 the ones clapping along with the sound of instruments; (as being established they considered them, and not as fleeting;) 

#### Amos 6:6 the ones drinking {being strained wine}, and {with the foremost perfumes anointing themselves}, and they suffered not anything over the destruction of Joseph. 

#### Amos 6:7 On account of this, now they will be captives by a company of mighty ones; and there shall be lifted away the snorting of horses from Ephraim. 

#### Amos 6:8 For the LORD swore an oath according to himself, saying, Because I abhor every insult of Jacob, and {his places I have detested}, that I will lift away his city with all the ones in her. 

#### Amos 6:9 And it will be if there should be left behind ten men in {house one}, even they shall die. 

#### Amos 6:10 And {shall be left behind their family members}, and they should press to bring forth their bones from out of the house; and one shall say to the ones set over the house, Is there still any existing with you? And he shall say, No longer, and the other shall say, Quiet, so as to not name the name of the LORD. 

#### Amos 6:11 For behold, the LORD gives charge, and he shall strike the {house great} with fractures, and the {house small} with torn pieces. 

#### Amos 6:12 Shall {pursue in the rocks horses}, no. shall they remain silent around females, no. For you distorted {into rage judgment}, and the fruit of righteousness into bitterness; 

#### Amos 6:13 the ones being glad over no {word good}; the ones saying, Was it not in our strength we had horns? 

#### Amos 6:14 For behold, I will rouse against you, O house of Israel, a nation. And they shall squeeze you to not enter into Hamath, and unto the rushing stream of the west. 

#### Amos 7:1 Thus {showed to me the LORD God}; and behold, a breed of locusts coming in early morning, and behold {grasshopper one} -- Gog the king. 

#### Amos 7:2 And it shall be when {should be completed the devouring the grass of the land}, that I said, O LORD, {kind be}! Who shall raise up Jacob, for he is very few? 

#### Amos 7:3 Change your mind, O LORD, over this! And this shall not be, says the LORD. 

#### Amos 7:4 Thus {showed to me the LORD}. And behold {called punishment by fire the LORD}, and it devoured the {abyss great}, and it devoured the portion. 

#### Amos 7:5 And I said, O LORD God, abate indeed! Who shall raise up Jacob, for he is very few? Change your mind, O LORD, over this! 

#### Amos 7:6 And this in no way should be, says the LORD. 

#### Amos 7:7 So {showed to me the LORD}. And behold, the Lord was standing upon a wall of adamantine, and in his hand adamant. 

#### Amos 7:8 And the LORD said to me, What do you see, Amos? And I said, Adamant. And the Lord said to me, Behold, I arrange an adamant in the midst of my people Israel; no longer shall I proceed to go by it. 

#### Amos 7:9 And {shall be obliterated the shrines of laughter}; and the sites of the mystic rites of Israel shall be made desolate. And I will rise up against the house of Jeroboam with a broadsword. 

#### Amos 7:10 And {sent out Amaziah the priest} of Beth-el to Jeroboam king of Israel, saying, {a confederacy makes against you Amos} in the midst of the house of Israel. In no way will {be able the land} to endure all his words. 

#### Amos 7:11 For thus says Amos, By the broadsword Jeroboam shall come to an end, and Israel {captive shall be led} from his land. 

#### Amos 7:12 And Amaziah said to Amos, the one seeing, Proceed! Withdraw into the land of Judah, and there spend your life! and there you shall prophesy. 

#### Amos 7:13 But in Beth-el no longer shall you proceed to prophesy. For {a sanctuary for the king it is}, and {a house of royalty it is}. 

#### Amos 7:14 And Amos answered and said to Amaziah, I was not a prophet, nor a son of a prophet; but I was a herder, one plucking fruit of the mulberry-tree. 

#### Amos 7:15 And {took me the LORD} from the sheep, and the LORD said to me, Proceed and prophesy over my people Israel! 

#### Amos 7:16 And now, hear the word of the LORD! You say, Prophesy not over Israel! for in no way should you lead a mob against the house of Jacob. 

#### Amos 7:17 On account of this, thus says the LORD, Your wife {in the city shall commit harlotry}; and your sons and your daughters {by the broadsword shall fall}; and your land {by a measuring line shall be measured out}; and you {in land an unclean shall come to an end}; and Israel {captive shall be led} from his land. 

#### Amos 8:1 Thus {showed to me the LORD}. And behold, a container of a fowler. 

#### Amos 8:2 And the LORD said, What do you see, Amos? And I said, A container of a fowler. And the LORD said to me, {is come The end} for my people Israel; I shall not proceed any longer to pass by them. 

#### Amos 8:3 And {shall shriek the fretworks of the temple} in that day, says the LORD. And there shall be many falling; in every place I will cast a silence. 

#### Amos 8:4 Hear indeed these things! O ones obliterating the needy, and tyrannizing the poor of the land. 

#### Amos 8:5 Saying, When shall {go by the month} that we shall make trade, and the Sabbaths, that we shall open the treasury to make the measure small, and to unequally magnify the scale-weight, and to make the yoke balance scale unjust? 

#### Amos 8:6 That we may acquire {by silver the poor}, and the needy in return for sandals; and of every business we shall trade. 

#### Amos 8:7 The LORD swears an oath according to the pride of Jacob, Shall there be forgotten for victory any of their works, no. 

#### Amos 8:8 And concerning these things, {not shall be disturbed the land}, and {mourn all the ones dwelling in it}? And {shall ascend as a river the consumption}, and shall go down as the river of Egypt. 

#### Amos 8:9 And it will be in that day, says the LORD, {shall go down the sun} at midday, and {shall darken upon the earth during the day the light}; 

#### Amos 8:10 and I will convert your holiday feasts into mourning, and all your songs into wailing. And I will bring upon every loin, sackcloth; and upon every head, baldness. And I will appoint him as one mourning a beloved one; and the ones with him as a day of grief. 

#### Amos 8:11 Behold days come, says the LORD, and I will send out famine upon the land; not a famine of bread loaves, nor famine of water, but a famine to hear the word of the LORD. 

#### Amos 8:12 And {shall shake waters} from the sea unto sea. And from north unto east ones shall run about seeking the word of the LORD, and in no way should they find. 

#### Amos 8:13 In that day {will dissipate the virgins fair and the young men} by thirst. 

#### Amos 8:14 The ones swearing an oath according to the atonement of Samaria, and ones saying, {lives Your God}, O Dan; and your God, O Beer-sheba. And they shall fall and in no way should they rise up again. 

#### Amos 9:1 I saw the LORD standing at the altar. And he said, Strike upon the atonement-seat! and {shall be shaken the gateways}. And cut unto the heads of all! and the ones remaining of them {by the broadsword I will kill}. In no way should one evade from them by fleeing, and in no way shall there be preserved one of them by rescuing. 

#### Amos 9:2 If they should be buried in Hades, from there my hand shall pull them up. And if they ascend into the heaven, from there I will lead them down. 

#### Amos 9:3 If they hide in the top of Carmel, from there I will search out and take them. And if they descend from out of my eyes into the depths of the sea, there I will give charge to the dragon, and it will bite them. 

#### Amos 9:4 And if they go into captivity in front of their enemies, there I will give charge to the broadsword, and it shall kill them. And I will firmly fix my eyes against them for bad, and not for good. 

#### Amos 9:5 And the LORD God almighty, is the one attaching the earth and shaking it. And {shall mourn all the ones dwelling it}. And it shall ascend as the river of Egypt. 

#### Amos 9:6 The one building {into the heaven his ascent}. and the one {his promise upon the earth founding}, the one calling on the water of the sea, and pouring it upon the face of the earth -- the LORD is his name. 

#### Amos 9:7 {not as sons of Ethiopians Are you} to me, O sons of Israel, says the LORD? Did I not lead Israel from out of the land of Egypt, and the Philistines from out of Cappadocia, and the Syrians from out of the pit? 

#### Amos 9:8 Behold the eyes of the LORD God are upon the kingdom of the sinners, and I will lift it from the face of the earth; only that not unto completion will I remove the house of Jacob, says the LORD. 

#### Amos 9:9 For behold, I give charge, and I shall winnow among all the nations the house of Israel, in which manner grain is winnowed by the winnowing shovel; and in no way shall there fall a broken piece upon the earth. 

#### Amos 9:10 By broadsword {shall come to an end all the sinners of my people}, the ones saying, In no way shall approach nor come upon us the evils. 

#### Amos 9:11 In that day I will raise up the tent of David, the one having fallen, and I will rebuild its fallen things. And the things having been razed of it, I will raise up, and I will rebuild it as the days of the eon; 

#### Amos 9:12 so that {should inquire the ones remaining of the men}, and all the nations, the ones of whom {was called upon my name} by them, says the LORD, the one doing these things. 

#### Amos 9:13 Behold, days come, says the LORD, and {shall overtake the threshing} the gathering of crops; and {shall grow dark the grape} in the sowing; and {shall trickle down the mountains sweetness}, and all the hills shall be planted together. 

#### Amos 9:14 And I will return the captivity of my people Israel, and they shall rebuild the cities having been obliterated, and shall inhabit them; and they shall plant vineyards, and they shall drink their wine; and they shall make gardens, and shall eat their fruit. 

#### Amos 9:15 And I will plant them upon their land. And in no way shall they be pulled out any longer from their land of which I gave to them, says the LORD God.