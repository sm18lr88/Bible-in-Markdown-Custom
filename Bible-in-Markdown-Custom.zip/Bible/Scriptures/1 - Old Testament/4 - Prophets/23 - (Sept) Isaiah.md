#### Isaiah 1:1 The vision which {beheld Isaiah son of Amoz}, which he beheld against Judea, and against Jerusalem, during the kingdom of Uzziah, and Jotham, and Ahaz, and Hezekiah, the ones who reigned over Judea. 

#### Isaiah 1:2 Hear, O heaven, and give ear O earth! For the LORD spoke, saying, {sons I have engendered}, and raised them, but they disregarded me. 

#### Isaiah 1:3 {knows The ox} the one acquiring it, and the donkey knows the stable of its master; but Israel {me does not know}, and my people perceived not. 

#### Isaiah 1:4 Woe, {nation O sinful}, people full of sins, {seed an evil}, {sons lawless}. You abandoned the LORD, and provoked to anger the holy one of Israel; they were separated into the rear. 

#### Isaiah 1:5 Why still should you be struck, proceeding in lawlessness? The whole head is in misery, and the whole heart is in distress. 

#### Isaiah 1:6 From feet unto head there is no {in it wholeness}. Neither wound, nor stripe, nor {wound inflamed} are healed; there is no dressing to place upon it, nor oil, nor bandages. 

#### Isaiah 1:7 Your land is desolate; your cities scorched; your place before you -- strangers devoure it, and it is made desolate, being eradicated by {peoples alien}. 

#### Isaiah 1:8 {shall be abandoned The daughter of Zion} as a tent in a vineyard, and as a storehouse in a cucumber garden, as a city being assaulted. 

#### Isaiah 1:9 And unless the LORD of Hosts left us a seed, {as Sodom we would have become}, and {as Gomorrah likened}. 

#### Isaiah 1:10 Hear the word of the LORD, O rulers of Sodom! Take heed to the law of our God, O people of Gomorrah! 

#### Isaiah 1:11 What are {to me the multitude of your sacrifices}, says the LORD? I am full of whole burnt-offerings of rams, and fat of lambs; and {blood of bulls and he-goats I do not want}. 

#### Isaiah 1:12 And neither should you come to appear to me; for who required these from out of your hands? {to tread my courtyard You shall not proceed}. 

#### Isaiah 1:13 If you should bring fine flour, it is in vain; incense {an abomination to me is}; {your new moons and the Sabbaths and day the great I cannot endure}. 

#### Isaiah 1:14 Your fasting, and idleness, and your new moons, and your holidays {detests soul my}. You became to me as a glut; no longer shall I spare your sins. 

#### Isaiah 1:15 Whenever you should stretch out your hands, I shall turn my eyes from you. And if you should multiply your supplication, I will not listen to you, for your hands {of blood are full}. 

#### Isaiah 1:16 Bathe yourself! {clean Become}! Remove the wickednesses from your souls before my eyes! Cease from your wickednesses! 

#### Isaiah 1:17 Learn {good to do}! Inquire of equity! Rescue the one wronged! Judge for the orphan! and do justice for the widow! 

#### Isaiah 1:18 And come, we should plead, says the LORD. And if {should be your sins} as crimson, {as snow I shall whiten}; and if they should be as scarlet, {as wool I shall whiten}. 

#### Isaiah 1:19 And if you should want, and if you should listen to me, {the good things of the earth you shall eat}. 

#### Isaiah 1:20 But if you should not want, nor should you listen to me, a sword {you shall devour}. For the mouth of the LORD spoke these things. 

#### Isaiah 1:21 O how {became a harlot city the trustworthy Zion}, full of judgment; in which righteousness slept in it, but now murderers. 

#### Isaiah 1:22 Your silver is debased; your peddlers mingle the wine with water. 

#### Isaiah 1:23 Your rulers resist persuasion, they are partners of thieves, loving bribes, pursuing recompense, {for orphans not arbitrating}, and {equity of widows not heeding}. 

#### Isaiah 1:24 On account of this, thus says the master, the LORD of Hosts, Woe the ones being strong of Israel, {will not cease for my rage} among the contrary ones, and {judgment on my enemies I will execute}. 

#### Isaiah 1:25 And I will bring my hand against you, and I will purify you to cleanness. But the ones resisting persuasion I will destroy, and I will remove all lawless ones from you. 

#### Isaiah 1:26 And all the proud I will abase; and I will stand your judges as formerly, and your counselors as at the beginning. And after these things you shall be called, City of Righteousness, {mother-city the trustworthy} Zion. 

#### Isaiah 1:27 For with judgment {shall be delivered her captivity}, and with charity. 

#### Isaiah 1:28 And {shall be broken the lawless ones and the sinners} together; and the ones abandoning the LORD shall be finished off entirely. 

#### Isaiah 1:29 For they shall be ashamed of their idols, which they preferred; and they shall be ashamed over the gardens which they desired. 

#### Isaiah 1:30 For they will be as a terebinth tree throwing off its leaves, and as a park {water not having}. 

#### Isaiah 1:31 And {will be their strength} as the stubble of hemp; and their works as sparks, and {shall be incinerated the lawless ones and the sinners} together, and there will not be one extinguishing. 

#### Isaiah 2:1 The word coming to Isaiah son of Amoz concerning Judea, and concerning Jerusalem. 

#### Isaiah 2:2 For it will be in the last days {will be apparent the mountain of the LORD}, and the house of God will be upon the uppermost part of the mountains, and it shall be raised up high above the hills; and {shall come unto it all the nations}. 

#### Isaiah 2:3 And {shall go nations many} and shall say, Come, for we should ascend unto the mountain of the LORD, and unto the house of the God of Jacob; and he will announce to us his way; and we shall go in it. For from out of Zion shall come forth law, and the word of the LORD from out of Jerusalem. 

#### Isaiah 2:4 And he shall judge in the midst of the nations; and he shall completely refute {people many}. And they shall cut down their swords into plows, and their pikes into sickles. And {shall not take a nation against a nation a sword}, and in no way should they learn yet to wage war. 

#### Isaiah 2:5 And now, O house of Jacob, come and we should go to the light of the LORD. 

#### Isaiah 2:6 For he forsook his people, the house of Jacob; for {was filled up as from the beginning their place} of ones prognosticating, as that of the Philistines; and {children many Philistine} were born to them. 

#### Isaiah 2:7 For they filled up their place with silver and gold, and there was no limit to the number of their treasures; and they filled up the land with horses, and there was no limit to the number of their chariots. 

#### Isaiah 2:8 And they filled up the land with the abominations of the works of their hands; and they did obeisance to the ones which they made by their fingers. 

#### Isaiah 2:9 And {bowed people}, and {was abased each man}; and in no way will I spare them. 

#### Isaiah 2:10 And now, enter to the rock, and hide in the earth from in front of the fear of the LORD, and from the glory of his strength, whenever he should rise up to devastate the earth! 

#### Isaiah 2:11 For the eyes of the LORD are high, but man is low; and {shall be abased the height of men}, and {shall be raised up high the LORD alone} in that day. 

#### Isaiah 2:12 For the day of the LORD of Hosts is upon every one insulting and proud; and upon every one high and elevated -- and they shall be abased; 

#### Isaiah 2:13 and upon every cedar of Lebanon, of the ones high and elevated; and upon every {tree acorn} of Bashan; 

#### Isaiah 2:14 and upon every high mountain; and upon every {hill high}; 

#### Isaiah 2:15 and upon every {tower high}; and upon every {wall high}; 

#### Isaiah 2:16 and upon every boat of the sea; and upon every spectacle of boats of beauty. 

#### Isaiah 2:17 And {shall be abased every man}; and {shall fall the haughtiness of men}; and {shall be raised up high the LORD alone} in that day. 

#### Isaiah 2:18 And {the things made by hand all they shall hide}, 

#### Isaiah 2:19 carrying them into the caves, and into the fissures of the rocks, and into the burrows of the earth, from in front of the fear of the LORD, and from the glory of his strength, whenever he should rise up to devastate the earth. 

#### Isaiah 2:20 For that day {will cast out a man} his abominations, the things made of silver and gold which they made to do obeisance to the vain things, and to the bats, 

#### Isaiah 2:21 to enter into the burrows of the solid rock, and the fissures of the rocks, from in front of the fear of the LORD, and from the glory of his strength, whenever he should rise up to devastate the earth. 

#### Isaiah 2:22 Cease yourself from the man breathing by his nostril; for by what is he considered? 

#### Isaiah 3:1 Behold, indeed the master, the LORD of Hosts, he shall remove from Jerusalem and from Judea the prevailing man and prevailing woman; the strength of bread and the strength of water; 

#### Isaiah 3:2 the giant and the one prevailing, and a man warrior, and magistrate, and prophet, and thinker, and old man, 

#### Isaiah 3:3 and commander of fifty, and wonderful counselor, and wise architect, and discerning listener. 

#### Isaiah 3:4 And I will set young men as their rulers; and mockers will lord over them. 

#### Isaiah 3:5 And {will be downcast the people}; man against man, even a man will be against his neighbor; {will strike the boy} against the old man; the one without honor against the important. 

#### Isaiah 3:6 For {shall take hold of a man} his brother, or a member of the family of his father, saying, {a garment You have}, {chief you become our}; and {food needs my under you let be}! 

#### Isaiah 3:7 And answering in that day, he will say, I will not be your chief, {no for in my house there is bread}, nor a garment; I will not be a chief of this people. 

#### Isaiah 3:8 For Jerusalem is forsaken, and Judea is cast down, and their tongues speak with lawlessness the things against the LORD, resisting persuasion. 

#### Isaiah 3:9 Because now {was abased their glory}, and the shame of their face withstood them, and {their sin as Sodom they announced}, and revealed it. Woe to their soul, because they consulted {counsel wicked} against themselves; 

#### Isaiah 3:10 having said, We should bind the just, for {inconvenient to us he is}; therefore the produce of their works they shall eat. 

#### Isaiah 3:11 Woe to the lawless one; evils according to the works of his hands shall come to pass against him. 

#### Isaiah 3:12 O my people, your exactors glean you, and the ones exacting lord over you; O my people, the ones declaring you blessed mislead you, and {the roads of your feet they disturb}. 

#### Isaiah 3:13 But now {will place in judgment the LORD}, and will stand {in judgment his people}. 

#### Isaiah 3:14 The LORD himself {for judgment shall come} with the elders of the people, and with his rulers. But you, why did you set on fire my vineyard, and the seizure of the poor is in your houses? 

#### Isaiah 3:15 Why do you wrong my people, and {the face of the poor disgrace}, says the LORD, the Lord of the militaries? 

#### Isaiah 3:16 Thus says the LORD, Because {are haughty the daughters of Zion}, and they go with a high neck, and with the beckon of the eyes, and their goings with their feet together, dragging their inner garments, and their feet {together playing}; 

#### Isaiah 3:17 therefore {will abase the LORD} the ruling daughters of Zion; and the LORD will uncover their condition. 

#### Isaiah 3:18 In that day even the LORD will remove the glory of their clothes, and the fringes, and the crescents, 

#### Isaiah 3:19 and the necklace, and the ornament of their face, 

#### Isaiah 3:20 and the array of the ornament of glory, and the armlets, and the bracelets, and the wreaths, and the rings, and the right armbands, 

#### Isaiah 3:21 and the ear-rings, and the objects edged with purple, and the purple ornamentations, 

#### Isaiah 3:22 and the cloths for the house, and the transparencies of Lakonika, 

#### Isaiah 3:23 and the fine linens, and the ones of blue, and scarlet, and the linen {with gold and blue being interwoven}, and the lightweight coverings for divans. 

#### Isaiah 3:24 And there will be {instead of scent an agreeable a cloud of dust}; and instead of a belt, {with a rough cord you shall tie around}; and instead of the {ornament for the head gold}, {baldness you shall have} on account of your works; and instead of the inner garment of purple ornamentation, you shall gird on sackcloth. 

#### Isaiah 3:25 And {son your best} whom you love {by the sword shall fall}; and your strong ones {by the sword shall fall}, and they shall be abased. 

#### Isaiah 3:26 And {shall mourn the cases of your ornamentation}; and you shall be left behind alone; and into the earth you shall be dashed. 

#### Isaiah 4:1 And {shall take hold of seven women man one} in that day, saying, {our own bread We will eat} and {our own garments wear}, only {your name let} be called upon us; remove our scorn! 

#### Isaiah 4:2 In that day {shall shine forth God} in counsel with glory upon the earth to exalt and to glorify the one left behind of Israel. 

#### Isaiah 4:3 And it shall be the one left behind in Zion, and the one left behind in Jerusalem {holy shall be called}; all the ones being written for life in Jerusalem. 

#### Isaiah 4:4 For {shall thoroughly wash the LORD} the filth of the sons and the daughters of Zion; and {the blood of Jerusalem he shall clear out} from its midst by a spirit of judgment, and a spirit of burning. 

#### Isaiah 4:5 And he shall come, and it will be that every place of mount Zion, and all the places surrounding it he shall shadow with a cloud by day, and as smoke and the light of fire burning by night; all the glory shall be sheltered. 

#### Isaiah 4:6 And it will be for a shade from sweltering heat, and for protection, and for a concealment from the hardness of weather and rain. 

#### Isaiah 5:1 I will sing indeed to the one being loved of me a song of my beloved concerning his vineyard. A vineyard became to the one being loved on a horn in {place a plentiful}. 

#### Isaiah 5:2 And {a barrier I put} around it, and I built a palisade, and planted a grapevine, a choice vine; and I built a tower in the midst of it; and {a wine press I dug} in it; and I waited for it to produce the grape, and it produced thorn-bushes. 

#### Isaiah 5:3 And now, O ones dwelling in Jerusalem, and O man of Judah, judge then {me and between} my vineyard! 

#### Isaiah 5:4 What shall I do still to my vineyard that I did not do to it? For I waited for it to produce a grape, but it produced thorn-bushes. 

#### Isaiah 5:5 Now then I will announce to you what I will do to my vineyard. I will remove its barrier, and it will be for ravaging. And I will demolish its wall, and it will be for trampling. 

#### Isaiah 5:6 And I will forsake my vineyard; for in no way should it be pruned, neither shall it be dug. And {shall ascend into it as in an uncultivated land the thorn-bush}. And {to the clouds I will give charge} to not rain {upon it any rain}. 

#### Isaiah 5:7 For the vineyard of the LORD of Hosts {the house of Israel is}, and the man of Judah is the newly planted one being loved. I waited for it to produce equity, but it produced lawlessness; and not righteousness, but a cry. 

#### Isaiah 5:8 Woe to the ones joining together house to house, and {field to field nearing}, that {of their neighbor they should remove anything}; will you not live alone upon the land? 

#### Isaiah 5:9 For it was heard in the ears of the LORD of Hosts about these things. For even if there should become {residences many} in desolation, and they shall be great and good, but there will not be ones dwelling in them. 

#### Isaiah 5:10 For where {work ten teams of oxen} the land will produce {clay vessel one}; and the one sowing {large measures six} shall produce {measures three}. 

#### Isaiah 5:11 Woe to the ones arising in the morning and {liquor pursuing}; the ones waiting late for it; for the wine shall burn with them. 

#### Isaiah 5:12 For with the harp, and psaltery, and tambourines, and pipes, {wine they drink}; but the works of the LORD they do not look at, and the works of his hands they do not contemplate. 

#### Isaiah 5:13 Therefore {captive my people became} because of {not knowing their} the LORD. And a multitude became dead because of hunger and thirst for water. 

#### Isaiah 5:14 And {widened Hades} its breath, and opened wide its mouth to not stop. And {shall go down the honorable ones}, and the great, and the rich, and the one exalting in her. 

#### Isaiah 5:15 And {shall be abased a people}, and {shall be dishonored a man}, and the {eyes elevated} shall be abased. 

#### Isaiah 5:16 And {shall be raised up high the LORD of Hosts} in judgment; and the {God holy} shall be glorified in righteousness. 

#### Isaiah 5:17 And {shall be grazed the ones tearing in pieces} as bulls; and {the things of the barren places of the ones being taken away lambs shall eat}. 

#### Isaiah 5:18 Woe to the ones drawing sins as with {rough cord a long}, and {as with a yoke strap of a heifer lawlessnesses.} 

#### Isaiah 5:19 The ones saying, Let him quickly approach to do whatever! that we should see it; and let {come the counsel of the holy one of Israel}! that we should know it. 

#### Isaiah 5:20 Woe to the ones calling evil good, and good evil; the ones making the darkness light, and the light darkness; the ones making the bitter sweet, and the sweet bitter. 

#### Isaiah 5:21 Woe to the ones wise to themselves, and {before themselves having knowledge}. 

#### Isaiah 5:22 Woe to your strong ones, the ones drinking wine, and the mighty ones, the ones mixing liquor; 

#### Isaiah 5:23 the ones justifying the impious because of bribes, and {for the just justice lifting away}. 

#### Isaiah 5:24 On account of this, in which manner {shall be burnt stubble} by a coal of fire, and shall be burnt up by a flame being sent up, their root {as dust will be}, and their flower {as a cloud of dust shall ascend}; for they did not want the law of the LORD of Hosts; but the oracle of the holy one of Israel they provoked. 

#### Isaiah 5:25 And {was enraged in anger the LORD of Hosts} against his people. And he put a hand against them, and he struck them. And {were provoked the mountains}, and {became their decaying flesh} as dung in the midst of the way. And in all these {was not turned his rage}, but still his hand is high. 

#### Isaiah 5:26 Accordingly he shall lift up an agreed upon sign among the nations far off; and he shall whistle at them from the uttermost part of the earth; and behold, quickly nimbly they come. 

#### Isaiah 5:27 They shall not hunger nor tire, nor shall they slumber nor shall they go to sleep, nor shall they untie their belts from their loins, nor shall they tear away the straps of their sandals; 

#### Isaiah 5:28 whose arrows are sharp, and their bows being stretched tight; the feet of their horses {as solid rock are considered}; the wheels of their chariots as a blast. 

#### Isaiah 5:29 They advance as lions, and stand beside as {cubs lion}; and he shall take hold and shall yell as a wild beast, and he shall cast them out, and there will not be one rescuing them. 

#### Isaiah 5:30 And he shall yell on account of them in that day, as the sound of the sea swelling up. And they shall look into the heaven upward and below; and behold, {darkness a hard} in their perplexity. 

#### Isaiah 6:1 And it came to pass the year of which {died king Uzziah}, I beheld the LORD sitting upon {throne a high}, and being lifted up; and {was full the house} of his glory. 

#### Isaiah 6:2 And seraphim stood round about him; six wings to the one, and six wings to the other one. And with the first two they covered up the front; and with the second two they covered up the feet; and with the third two they flew. 

#### Isaiah 6:3 And they cried out another to another, and said, Holy, holy, holy is the LORD of Hosts; {is full all the earth} of his glory. 

#### Isaiah 6:4 And {lifted up the lintel} from the sound of which they cried out, and the house was filled up of smoke. 

#### Isaiah 6:5 And I said, O, I am miserable, for I am vexed, for {a man being} and {unclean lips having} in the midst of a people {unclean lips having} I live in. And the king, the LORD of Hosts, I beheld with my eyes. 

#### Isaiah 6:6 And {was sent to me one of the seraphim}. And in the hand he had a coal, which {with the tong he took from the altar}. 

#### Isaiah 6:7 And he touched my mouth, and he said, Behold, this touched your lips, and {it shall remove your lawless deeds}, and {your sins it shall purge}. 

#### Isaiah 6:8 And I heard the voice of the LORD, saying, Whom shall I send, and who shall go to this people? And I said, Behold, I am, send me! 

#### Isaiah 6:9 And he said, Go! and say to this people, Hearing, you shall hear, but in no way shall you perceive; and seeing you shall see, but in no way shall you know. 

#### Isaiah 6:10 {was thickened For the heart of this people}; and {with their ears heavily they heard}, and the eyes closed eyelids, lest at any time they should behold with their eyes, and the ears should hear, and the heart should perceive, and they should turn, and I shall heal them. 

#### Isaiah 6:11 And I said, Until when, O LORD? And he said, Until whenever {should be made desolate cities} by not being dwelt in; and houses by reason of not being men; and the land shall be left desolate. 

#### Isaiah 6:12 And after these things {shall distance God} the men; and {shall be multiplied the ones being left behind upon the land}. 

#### Isaiah 6:13 But still upon it is the tenth part, and again it will be for plunder. As a terebinth tree, and as an acorn whenever it should fall from out of its casing -- {seed the holy} is its pillar. 

#### Isaiah 7:1 And it came to pass in the days of Ahaz son of Jotham, the son of Uzziah king of Judah, ascended Rezin king of Aram, and Pekah son of Remaliah, king of Israel, against Jerusalem to wage war with it, and they were not able to assault it. 

#### Isaiah 7:2 And it was announced in the house of David, saying, {joined in harmony Aram} to Ephraim. And it startled his soul, and the soul of his people, in which manner {in a grove a tree by a wind is shaken}. 

#### Isaiah 7:3 And the LORD said to Isaiah, Go forth to meet with Ahaz, you and the one being left behind, Jasub your son, to the {pool upper} by way of the field of the fuller. 

#### Isaiah 7:4 And you shall say to him, Guard to be still, and do not fear! nor your soul be weak from the two trees {firebrands, of these smoking}; for whenever the anger of my rage takes place, again I will heal. 

#### Isaiah 7:5 And as far as the son of Aram, and the son of Remaliah, that they consulted {counsel wicked}, saying, 

#### Isaiah 7:6 We shall ascend unto Judea, and conversing together with them, we shall turn them to us, and we will give to reign over them the son of Tabeal. 

#### Isaiah 7:7 Thus says the LORD of Hosts, In no way should {abide this counsel}, nor will it be so. 

#### Isaiah 7:8 But the head of Aram is Damascus, and the head of Damascus is Rezin; but yet sixty and five years {will fail the kingdom of Ephraim} from the people. 

#### Isaiah 7:9 And the head of Ephraim, is Samaria, and the head of Samaria is the son of Remaliah. And if you should not trust, neither should you perceive. 

#### Isaiah 7:10 And the LORD proceeded to speak to Ahaz, saying, 

#### Isaiah 7:11 Ask for yourself a sign by the LORD your God, in the depth, or in the height. 

#### Isaiah 7:12 And Ahaz said, In no way shall I ask, nor shall I test the LORD. 

#### Isaiah 7:13 And he said, Hear indeed, O house of David! Is it a small thing to you {a struggle to furnish} to men, then how {to the LORD do you furnish a struggle}? 

#### Isaiah 7:14 On account of this, {will give the LORD himself} to you a sign; behold, the virgin {in the womb will conceive}, and shall bear a son, and you shall call his name Immanuel. 

#### Isaiah 7:15 Butter and honey he shall eat, before he knows to prefer wicked or to choose the good. 

#### Isaiah 7:16 For before {knows the male child} good or evil, in resisting persuasion of wickedness he chooses the good. And {shall be abandoned the land} which you fear of in front of the two kings. 

#### Isaiah 7:17 But {shall bring upon you God}, and upon your people, and upon the house of your father, days which {not yet have come} from which day Ephraim removed from Judah the king of the Assyrians. 

#### Isaiah 7:18 And it will be in that day, the LORD will whistle for the flies which shall dominate part of the river of Egypt, and for the bee which is in the place of the Assyrians. 

#### Isaiah 7:19 And they shall come, and they shall all rest in the ravines of the place, and in the burrows of the rocks, and into the caves, and into every breach, and in every tree. 

#### Isaiah 7:20 In that day the LORD shall shave with the razor {having been intoxicated from the other side of the river of the king of the Assyrians the head}, even the hairs of the feet, and {the beard he will remove}. 

#### Isaiah 7:21 And it will be in that day, {shall maintain a man} a heifer of the oxen, and two sheep. 

#### Isaiah 7:22 And it will be from the much drinking of milk {butter and honey shall eat every one being left behind upon the land}. 

#### Isaiah 7:23 And it will be in that day that every place where ever might be a thousand grapevines worth a thousand shekels, they shall be uncultivated and for the thorn-bush. 

#### Isaiah 7:24 With arrow and bow they shall enter there; for it is an uncultivated land, and the thorn-bush will be in all the land. 

#### Isaiah 7:25 And every mountain being plowed shall be plowed; in no way shall {come upon there fear}; for it will be from the uncultivated land and thorn-bush a land for pastured sheep and for trampling of the ox. 

#### Isaiah 8:1 And the LORD said to me, Take to yourself {roll of papyrus new a great}, and write on it with the pen of a man concerning the swiftly {plunder made} of spoils, for it is at hand! 

#### Isaiah 8:2 And {witnesses for me appoint} of trustworthy men -- Uriah the priest, and Zachariah son of Barachiah. 

#### Isaiah 8:3 And I drew near to the prophetess; and {in the womb she conceived}, and gave birth to a son. And the LORD said to me, Call his name, Quickly Despoil, Swiftly Plunder. 

#### Isaiah 8:4 Because before the {knows child} to call his father or mother, one shall take the power of Damascus, and the spoils of Samaria before the king of the Assyrians. 

#### Isaiah 8:5 And the LORD proceeded to speak to me again, saying, 

#### Isaiah 8:6 Because {want not this people} the water of Shiloah going tranquilly, but want to have Rezin and the son of Remaliah king over them, therefore this -- 

#### Isaiah 8:7 behold, the LORD leads against you the {water of the river strong and abundant}, the king of the Assyrians, and his glory. And he shall ascend upon all your ravine, and shall walk upon all your wall. 

#### Isaiah 8:8 And he shall remove from Judea a man who shall be able {his head to lift} or able to complete anything; and {will be his camp} so as to fill the width of your place; {be with us God}. 

#### Isaiah 8:9 Know, O nations, and be vanquished! Take heed until the latter end of the earth! Being strong be vanquished! For if again you should be strong, again you shall be vanquished. 

#### Isaiah 8:10 And whom ever you should consult counsel, the LORD shall efface it; and {word what ever} you should speak, in no way should it adhere to you; for {is with us God}. 

#### Isaiah 8:11 Thus says the LORD, With the strong hand they resist persuasion in the going of the way of this people, saying, 

#### Isaiah 8:12 Lest at any time you should say, It is hard. For all what ever {should say this people} is hard. But the fear of him in no way should you be fearful, nor should you be disturbed. 

#### Isaiah 8:13 The LORD of the forces -- sanctify him! and he will be your fear. 

#### Isaiah 8:14 {even upon him yielding You should be}, he will be to you for a sanctuary; and not as a stone of stumbling for you to meet up with, nor as a rock downfall; but the houses of Jacob are in a snare, and in a hollow lying in wait in Jerusalem. 

#### Isaiah 8:15 On account of this {shall be powerless among them many}, and shall fall, and shall be broken; and they shall approach, and {shall be captured men} being in safety. 

#### Isaiah 8:16 Then the ones {apparent will be setting a seal upon themselves the law to not learn}. 

#### Isaiah 8:17 And one shall say, I shall wait for God, the one turning his face from the house of Jacob, and I will be yielding upon him. 

#### Isaiah 8:18 Behold, I and the children which {gave to me God}, even they will be for signs and miracles in the house of Israel by the LORD of Hosts who dwells on mount Zion. 

#### Isaiah 8:19 And if they should say to you, Seek the ones who deliver oracles, and the ones from the earth speaking out loud, and the empty words which {from the belly they speak out loud}; shall not a nation {to its God inquire}? Why do they inquire concerning the living of the ones dead? 

#### Isaiah 8:20 {the law For for a help he gave}, that they should speak not as this saying, concerning of which there are no gifts to give for it. 

#### Isaiah 8:21 And shall come upon us harshly a famine; and it will be as whenever you should hunger, you shall be fretting, and {wickedly you shall speak} of the ruler and the fathers; and they shall look up into the heaven upward, 

#### Isaiah 8:22 and {to the earth below they shall look}, and behold, darkness, affliction and straits, and darkness so as to not see unto a time. 

#### Isaiah 9:1 {this first quickly Drink}! Quickly act! O place of Zebulun, the land of Naphtali, and the rest on the coast, and on the other side of the Jordan, Galilee of the nations! 

#### Isaiah 9:2 The people going in darkness beheld {light a great}! The ones dwelling in a place and shadow of death, light shall radiate upon you. 

#### Isaiah 9:3 The greatest part of the people you led down in gladness, and they shall be glad before you as the ones being glad in a harvest, and in which manner the ones dividing spoils. 

#### Isaiah 9:4 Because {was removed the yoke, the one upon them being situated}, even the rod, the one upon their neck; for the rod of the extractors he effaced as in the day against Midian. 

#### Isaiah 9:5 For every apparel {assembled by treachery and garment}, {with reparation they shall pay}; and they shall want to even if it became scorched. 

#### Isaiah 9:6 For a child was born to us; a son was given to us, of whom the sovereignty became upon his shoulder; and {is called his name}, {of great counsel Messenger}, wonderful, counselor, {God mighty}, potentate, ruler of peace, father of the {about to be eon}. For I will bring peace upon the rulers, and his health. 

#### Isaiah 9:7 And great is his sovereignty, and of his peace there is no end upon the throne of David, and his kingdom to set it up and to take hold in judgment; even with righteousness from the present and into the eon. The zeal of the LORD of Hosts shall do these things. 

#### Isaiah 9:8 {death sent The LORD} upon Jacob, and it came upon Israel. 

#### Isaiah 9:9 And {shall know all the people of Ephraim}, and the ones settling in Samaria, with insolence and a haughty heart, saying, 

#### Isaiah 9:10 The bricks are fallen, but come, we should dress stones. And we should fell sycamine trees and cedars, and we should build for ourselves a tower. 

#### Isaiah 9:11 And {shall dash down God} the ones rising against mount Zion, against him; and {his enemies he shall efface} -- 

#### Isaiah 9:12 Syria from {of the sun the dawn}, and the Greeks from {of the sun the descent}, the ones devouring Israel with their whole mouth. In all these things {is not turned the rage}, but still there is the {hand high}. 

#### Isaiah 9:13 And the people did not turn until they were struck, and the LORD of the forces they did not seek. 

#### Isaiah 9:14 And the LORD removed from Israel the head and tail, the great and small, in one day; 

#### Isaiah 9:15 the old man, and the ones {persons admiring} -- this is the head; and the prophet teaching lawless things -- this is the tail. 

#### Isaiah 9:16 And {shall be the ones declaring blessed people this} misleading. And they misled so that they should swallow them down. 

#### Isaiah 9:17 On account of this {over their young men shall not be gladdened the LORD}; and upon their orphans and their widows he shall not show mercy. For all are lawless ones and wicked ones, and every mouth speaks unjustly. For all these things {shall not turn away his rage}, but still his hand is high. 

#### Isaiah 9:18 And {shall burn as fire lawlessness}. And as {wild grass dry} it shall be devoured by fire, and shall be burnt in the thickets of the grove, and shall devour together {the things round about the hills all}. 

#### Isaiah 9:19 On account of the rage of the anger of the LORD {burns land the entire}, and {will be the people} as ones incinerated by fire. A man {his brother shall not show mercy on}. 

#### Isaiah 9:20 But one shall turn aside to the right hand, for he shall hunger; and he shall eat of the left, and in no way shall {be filled up a man} eating the flesh of his arm. 

#### Isaiah 9:21 {shall eat For Manasseh} Ephraim, and Ephraim Manasseh; for together they shall assault Judah. For all these things {shall not turn the rage}, but still his hand is high. 

#### Isaiah 10:1 Woe to the ones writing wickedness; for the ones writing {wickedness are writing}; 

#### Isaiah 10:2 turning aside equity of the poor, snatching away a judgment of the needy of my people, so that {would be to them a widow} for ravaging, and an orphan for plunder. 

#### Isaiah 10:3 And what will they do in the day of the visitation? For the affliction {to you from a distance shall come}, and to whom shall you take refuge for help? And where will you leave your glory, 

#### Isaiah 10:4 to not fall into enslavement? For {underneath the ones being done away with they shall fall}. And for all these things {shall not turn his anger}, but still his hand is high. 

#### Isaiah 10:5 Woe to the Assyrians, the rod of my rage, and anger is in their hands. 

#### Isaiah 10:6 {my anger against nation a lawless I will send}, and {to my people I will give orders} to cause spoils and plunder, and to trample the cities, and to make them into dust. 

#### Isaiah 10:7 But he did not {thus ponder}, and the soul did not {thus consider}; but he shall dismiss his mind even to utterly destroy nations -- not a few. 

#### Isaiah 10:8 And if they should say to him, You alone are ruler; 

#### Isaiah 10:9 then he shall say, Did I not take the place above Babylon and Chalanes, where the tower was built? and I took Arabia, and Damascus, and Samaria? 

#### Isaiah 10:10 In which manner I took these, {all the sovereignties I shall take}. Shriek, O carvings in Jerusalem, and in Samaria! 

#### Isaiah 10:11 {in which manner For} I did to Samaria, and its handmade things, so shall I do also to Jerusalem and to her idols. 

#### Isaiah 10:12 And it will be whenever the LORD should complete all his doings on mount Zion and Jerusalem, he will strike against the {mind great}, against the ruler of the Assyrians, and against the haughtiness of the glory of his eyes. 

#### Isaiah 10:13 For he said, {in strength I will act}; and in the wisdom of understanding I will remove boundaries of nations; and {their strength I will despoil}; 

#### Isaiah 10:14 and I will shake the cities being inhabited; and {the world entire I will take by hand} as a nest; and {as being left behind eggs I will lift them away}; and there is no one who shall evade me or contradict me, even opening a mouth and chirping. 

#### Isaiah 10:15 Shall {be glorified the axe} without the one beating with it, no. or shall {be exalted the saw} without the one drawing with it, no. Likewise shall any lift a rod or wood and it shall not be so, no. 

#### Isaiah 10:16 But {sends the LORD of Hosts} for your honor -- dishonor; and for your glory -- fire; by a burning it shall be burnt. 

#### Isaiah 10:17 And {shall be the light of Israel} for a fire; and he shall sanctify her in fire being burned; and it shall devour {as grass the woods} in that day. 

#### Isaiah 10:18 {shall be consumed the mountains}, and the hills, and the forests; and it shall devour from soul unto flesh. And it will be the one fleeing will be as the one fleeing from {flame a burning}. 

#### Isaiah 10:19 And the ones being left behind of them will be a small number, and {child a small} shall be able to write them. 

#### Isaiah 10:20 And it will be in that day, no longer {proceed will the one being left behind of Israel}, and the ones being preserved of Jacob no longer should be yielding upon the ones wronging them. But they will be yielding upon God, the holy one of Israel, in the truth. 

#### Isaiah 10:21 And {will be the one being left behind of Jacob} relying upon the God having strength. 

#### Isaiah 10:22 And if {should become the people of Israel} as the sand of the sea, the vestige of them shall be preserved. 

#### Isaiah 10:23 For the matter is being completed and being rendered concise in righteousness, for {the matter is the one rendering concise the LORD}. The LORD of forces shall act in the {world entire}. 

#### Isaiah 10:24 On account of this, Thus says the LORD of Hosts, Do not fear, my people, O ones dwelling in Zion from the Assyrians! For with a rod he shall strike you, {a calamity For he brings} upon you beholding the way of Egypt. 

#### Isaiah 10:25 For yet a little time and I will cease the anger, but my rage is against their plan. 

#### Isaiah 10:26 And {shall arise against them the LORD God of the forces} according to the calamity of Midian in Place of Affliction. And his rage is the way by the sea into the way according to Egypt. 

#### Isaiah 10:27 And it will be in that day I shall remove his yoke from your shoulder, and the fear of him from you; and {shall be ruined the yoke} from your shoulders. 

#### Isaiah 10:28 For he shall come into the city of Angai, and shall go by to Maggedo, and in Michmash he shall place his weapons. 

#### Isaiah 10:29 And he shall go by the ravine, and shall come into Angai; fear shall take hold of Ramah; the city of Saul shall flee. 

#### Isaiah 10:30 A snorting sound of your voice O daughter of Gallim; {shall take heed Laish}; they shall take heed in Anathoth; 

#### Isaiah 10:31 and Madmenah is startled, and the ones dwelling in Gebim. 

#### Isaiah 10:32 Enjoin them today {in the way to abide}! Enjoin the mountain daughter of Zion, and the hills in Jerusalem! 

#### Isaiah 10:33 Behold, the master, the LORD of Hosts puts in disorder the honorable ones with strength. And the haughty ones with insolence shall be broken, and the haughty ones shall be humbled. 

#### Isaiah 10:34 And {shall fall the haughty ones} by the sword; and Lebanon {with the haughty ones will fall}. 

#### Isaiah 11:1 And {shall come forth a rod} from out of the root of Jesse; and a flower from out of his root shall ascend. 

#### Isaiah 11:2 And {will be caused to rest upon him spirit of the LORD}; a spirit of wisdom and understanding; a spirit of counsel and strength; a spirit of knowledge and piety; 

#### Isaiah 11:3 {shall fill him up a spirit of the fear of God}. {not according to the glory of man He shall judge}, nor {according to the speech shall he reprove}. 

#### Isaiah 11:4 But he shall judge {of the lowly the case}, and shall reprove for the lowly of the earth. And he shall strike the earth by the word of his mouth; and by the breath through his lips he shall do away with the impious. 

#### Isaiah 11:5 And righteousness will be tied around his loin; and {with truth being wrapped around his sides}. 

#### Isaiah 11:6 And {shall be fed together the wolf} with the lamb; and the leopard shall be refreshed together with the kid; and a young calf and a lion and a bull {together shall graze}; and {child a small} shall lead them. 

#### Isaiah 11:7 And the ox and bear shall graze together, and {together will be their offspring}; and the lion {as an ox shall eat straw}. 

#### Isaiah 11:8 And a child, an infant at burrows of asps, and at the bed of the progeny of asps, {his hand will put}. 

#### Isaiah 11:9 And in no way shall they do evil nor be able to destroy any one upon {mountain my holy}. For {is filled up the whole area} to know the LORD, as {water much} to cover up the sea. 

#### Isaiah 11:10 And it will be in that day the root of Jesse, and the one rising up to rule nations -- upon him nations shall hope. And {will be his rest} honor. 

#### Isaiah 11:11 And it will be in that day {will proceed the LORD} to show his hand to be jealous for the {left behind vestige of the people}, which ever should be left behind by the Assyrians, and by Egypt, and by Babylon, and by Ethiopia, and by the Elamites, and by {of the sun the dawn}, and from out of Arabia. 

#### Isaiah 11:12 And he shall lift a sign unto the nations. And he will bring together the ones being destroyed of Israel. And {the ones being dispersed of Judah he will gather} from out of the four wings of the earth. 

#### Isaiah 11:13 And {shall be removed the jealousy of Ephraim}, and the enemies of Judah shall be destroyed. Ephraim shall not be jealous of Judah, and Judah will not afflict Ephraim. 

#### Isaiah 11:14 And they shall fly in the boast of the Philistines west; together they shall despoil even the ones from {of the sun the dawn}, and Edom; and {upon Moab first hands they shall put}; but the sons of Ammon at first shall obey. 

#### Isaiah 11:15 And {shall make desolate the LORD the sea of Egypt}; and he shall put his hand upon the river {wind by a violent}, and he shall strike seven ravines, so as to travel over it in sandals. 

#### Isaiah 11:16 And there shall be a corridor to the one being left behind of my people, to the one being left behind from the Assyrians. And it will be to Israel as in the day when they came forth from out of the land of Egypt. 

#### Isaiah 12:1 And he shall say in that day, I shall bless you, O LORD, because you were provoked to anger against me, and you turned away your rage, and showed mercy on me. 

#### Isaiah 12:2 Behold, my God, my deliverer; I will be yielding upon him, and I will not be fearful. Because {is my glory and my praise the LORD}; and it became to me for deliverance. 

#### Isaiah 12:3 Then draw water with gladness from out of the springs of deliverance! 

#### Isaiah 12:4 And you shall say in that day, Sing praise to the LORD! Yell out his name! Announce among the nations his honorable deeds! Mention that {was exalted his name}! 

#### Isaiah 12:5 Sing praise to the name of the LORD! for {high things he did}. Announce these things in all the earth! 

#### Isaiah 12:6 Exult and be glad, O ones dwelling in Zion! for {is exalted the holy one of Israel} in the midst of her. 

#### Isaiah 13:1 The vision against Babylon which {beheld Isaiah son of Amoz}. 

#### Isaiah 13:2 {upon a mountain plain Lift up a sign}! Raise up high the voice to them! Do not fear! Call for aid with the hand! Open, O rulers! 

#### Isaiah 13:3 I order and I lead them; giants come to fill my rage, rejoicing together and insulting. 

#### Isaiah 13:4 A voice {nations of many} upon the mountains, like {nations many}; a voice of kings and nations being brought together. The LORD of Hosts has given charge to a nation of armed warriors. 

#### Isaiah 13:5 They come from out of a land at a distance, from the extremity of the foundation of the heaven; the LORD and his armed warriors, to ruin all the world. 

#### Isaiah 13:6 Shriek! {is near for the day of the LORD}, and destruction by God shall come. 

#### Isaiah 13:7 Because of this every hand shall be loosened, and every soul of man shall be timid. 

#### Isaiah 13:8 And {shall be disturbed the ambassadors}, and {their pangs they shall have} as a woman giving birth; and they shall lament together, another to another; and they shall be startled; and {countenance as a flame they shall change}. 

#### Isaiah 13:9 For behold the day of the LORD comes; incurable rage and anger to make the world desolate, and {the sinners to destroy} from out of it. 

#### Isaiah 13:10 For the stars of the heaven, and Orion, and all the cosmos of the heaven {of their light shall not give}; and {shall be made dark of the sun the rising}, and the moon shall not give her light. 

#### Isaiah 13:11 And I charge {to the world entire evils}, and to the impious their sins; and I shall destroy the insolence of lawless ones; and {the insolence of the proud I will abase}. 

#### Isaiah 13:12 And {will be the ones being left rare more} than {gold unfired}; and a man {more rare will be} than the stone, the one of Ophir. 

#### Isaiah 13:13 For the heaven shall be enraged, and the earth shall be shaken from out of its foundation, because of the rage of the anger of the LORD of Hosts in the day which ever {should come about his rage}. 

#### Isaiah 13:14 And {will be the ones being left behind} as a young doe fleeing, and as a sheep wandering; and there is no one gathering so as for a man {to his people to return}; and a man {unto his own place shall take flight}. 

#### Isaiah 13:15 For who ever should capture shall be vanquished; and the ones who {being brought together are} shall fall by sword. 

#### Isaiah 13:16 And {their children they shall dash} before them; and {their houses they shall despoil}; and {their women they shall have}. 

#### Isaiah 13:17 Behold, I rouse against you the Medes -- the {silver ones not considering}, nor {of gold need have}. 

#### Isaiah 13:18 {the bows of young men, They shall break}, and {upon your children in no way shall they show mercy}, nor {your children spare shall their eyes}. 

#### Isaiah 13:19 And Babylon will be (the place which is called honorable by the king of the Chaldeans) in which manner {eradicated God} Sodom and Gomorrah. 

#### Isaiah 13:20 It shall not be dwelt in into the eon, nor shall they enter into it through many generations, nor shall {go through it the Arabians}, nor shepherds in any way shall rest in it. 

#### Isaiah 13:21 And {shall rest there wild beasts}, and they shall fill up the houses with a sound; and {shall rest there sirens}, and demons will dance there. 

#### Isaiah 13:22 And satyrs shall dwell there, and {shall build a nest hedgehogs} in their houses. 

#### Isaiah 14:1 Quickly it comes, and shall not pass time, and their days in no way shall drag. And the LORD shall show mercy on Jacob, and will choose yet Israel, and they shall rest upon their land; and the foreigner shall be added to them, and they shall be added to the house of Jacob. 

#### Isaiah 14:2 And {shall take them nations}, and bring them into their place; and they shall inherit them, and they shall be multiplied upon the land of God for manservants and maidservants; and {shall be captives the ones capturing them}; and they shall dominate the ones dominating them. 

#### Isaiah 14:3 And it will be in that day {will rest you the LORD} from the grief, and your rage, and {slavery your hard} of which you slaved for them. 

#### Isaiah 14:4 And you shall take up this wailing against the king of Babylon, and you shall say in that day, O how {has been rested the one exacting}, and {has been rested the taskmaster}! 

#### Isaiah 14:5 The LORD broke the yoke of the sinners, the yoke of the rulers. 

#### Isaiah 14:6 Having struck a nation in rage {calamity with an incurable}; hitting a nation with a calamity of rage, which he spared not, he rested persuading. 

#### Isaiah 14:7 All the earth yells with gladness. 

#### Isaiah 14:8 And the trees of Lebanon shall be gladdened against you, and the cedar of Lebanon, saying, From of which time you were laid low, there ascended not one felling us. 

#### Isaiah 14:9 Hades from below was embittered meeting with you; {were risen up together against you all the giants ruling the earth}, the ones rising from their thrones, all the kings of the nations. 

#### Isaiah 14:10 All shall answer and shall say to you, You also captured as even we; {among us and are you reckoned}? 

#### Isaiah 14:11 {went down into Hades Your glory}, {great gladness your}; underneath you they shall make a bed of putrefaction, and {shall be your covering the worm}. 

#### Isaiah 14:12 O how {fell from out of the heaven the morning star} -- the one {by morning rising}; {was broken unto the earth the one sending to all the nations}. 

#### Isaiah 14:13 But you said in your heart, Unto the heaven I shall ascend; {upon the stars of the heaven I will put my throne}; I shall sit on {mountain a high}, upon the {mountains high} towards the north; 

#### Isaiah 14:14 I will ascend upon the clouds; I will be likened to the highest. 

#### Isaiah 14:15 But now {into Hades you shall go down}, and into the foundations of the earth. 

#### Isaiah 14:16 The ones beholding you shall wonder over you, and shall say, Is this the man provoking the earth, the one shaking kings; 

#### Isaiah 14:17 the one making the inhabitable world desolate, and {its cities demolished}; the ones in enslavement he did not loose. 

#### Isaiah 14:18 All the kings of the nations sleep in honor, every man in his house. 

#### Isaiah 14:19 But you shall be tossed in the mountains as dead, being abhorred with many having died being stabbed by a sword, going down into Hades. 

#### Isaiah 14:20 In which manner a garment {by blood being befouled} shall not be clean, so not even shall you be clean; because {my land you destroyed}, and {my people killed}; in no way should you abide into the eon of time -- {seed O evil}. 

#### Isaiah 14:21 Prepare your children to be slain for the sins of their father! that they should not rise up and inherit the earth, and should fill up the earth with wars. 

#### Isaiah 14:22 And I will rise up against them, says the LORD of Hosts, and I will destroy their name, and vestige, and seed -- thus says the LORD. 

#### Isaiah 14:23 And I will make the Babylonian region desolate so as for {to dwell hedgehogs}. And it will be for nothing, and I will make it a clay pit for destruction. 

#### Isaiah 14:24 Thus says the LORD of Hosts, In which manner I have said, so it will be; and in which manner I have deliberated, so it shall remain; 

#### Isaiah 14:25 even to destroy the Assyrians upon {land my}, and upon my mountains; and they will be for trampling. And {shall be removed from them their yoke}, and their dignity {from their shoulders shall be removed}. 

#### Isaiah 14:26 This is the plan which the LORD planned for all the inhabitable world. And this is the {hand high} upon all the nations. 

#### Isaiah 14:27 For what the {God holy} planned, who shall efface? And {hand his high who shall turn}? 

#### Isaiah 14:28 The year in which {died Ahaz king}, came this saying. 

#### Isaiah 14:29 Be not glad all Philistines, for he broke the yoke of the one hitting you. For from out of the seed of the serpent shall come forth a progeny of asps, and their progeny shall come forth as {serpents flying}. 

#### Isaiah 14:30 And {shall be grazed the poor} by him; and poor men with peace shall rest; and he shall do away {with hunger your seed}; and your vestige he will do away with. 

#### Isaiah 14:31 Shriek, O gates of the cities! Cry out, O cities! {are being disturbed the Philistines All}. For from the north smoke comes, and there is no being. 

#### Isaiah 14:32 And what shall {answer the kings of the nations}? For the LORD laid a foundation in Zion, and through him {shall be delivered peoples many}. 

#### Isaiah 15:1 The word against Moab. {by night shall be destroyed The land of Moab}; for by night {shall be destroyed the wall of the land of Moab}. 

#### Isaiah 15:2 Fret for them! for {shall be destroyed even Dibon}, where your shrine is. There you shall ascend to weep. Upon Nebo of the land of Moab shriek! Upon every head is baldness, all arms being mutilated. 

#### Isaiah 15:3 In their squares gird on sackcloths, and lament upon her roofs! And in her squares, and in her streets all shriek with weeping! 

#### Isaiah 15:4 For {have cried out Heshbon and Elealeh}. Unto Jahaz {was heard their sound}. On account of this the loin of the land of Moab yells. Her soul shall know. 

#### Isaiah 15:5 The heart of the land of Moab yells in her unto Zoar; {heifer for it is as a three years old}. But upon the ascent of Luhith {to you weeping they shall ascend}; by the way of Horonaim she yells, Defeat and quaking. 

#### Isaiah 15:6 The water of Nimrim shall be desolate, and her grass shall fail; {grass for green there will not be}. 

#### Isaiah 15:7 And shall she thus be about to be delivered? For I shall bring {upon the ravine the Arabians}, and they shall take it. 

#### Isaiah 15:8 {joined up with For the yelling} the border of the land of Moab of Eglaim, and her shrieking; {unto the well of Elim her shrieking}. 

#### Isaiah 15:9 For the water of Dimon shall be filled with blood. For I shall bring upon Dimon the Arabians, and I will lift away the seed of Moab, and Ariel, and the remnant of Adama. 

#### Isaiah 16:1 I will send a male lamb lording over the land; {not rock a desolate is the mountain of the daughter of Zion}? 

#### Isaiah 16:2 For you shall be as {winged creature flying about a young} being removed, O daughter of Moab; and thereupon, O Arnon. 

#### Isaiah 16:3 Much counsel, {make and also a protection for her mourning always}; {at midday darkness they flee}; they are startled; do not celebrate. 

#### Isaiah 16:4 {shall sojourn with you The exiles of Moab}; they will be a protection for you from the face of the one pursuing; for {was lifted away your alliance in war}, and the {ruler perished trampling} from the earth. 

#### Isaiah 16:5 And {shall be set right with mercy a throne}; and one shall sit upon it with truth in the tent of David, judging and inquiring of equity, and hastening righteousness. 

#### Isaiah 16:6 We heard the insult of Moab -- insulting exceedingly; the pride and his insult and his vehement anger; not so your divination. 

#### Isaiah 16:7 Moab shall shriek; for in the land of Moab all shall shriek. {among the ones dwelling But} Seth you shall meditate upon, and you shall not be ashamed. 

#### Isaiah 16:8 The plains of Heshbon shall mourn the grapevine of Sibmah. Swallowing down the nations, trampling her grapevines, unto Jazer in no way shall you join together. Wander the wilderness! The ones being sent from her were abandoned, for they passed over the sea. 

#### Isaiah 16:9 On account of this I shall weep as the one weeping of Jazer for the grapevine of Sibmah; {your trees cast down Heshbon and Elealeh}; for upon the harvest and upon the gathering of your crops I shall trample, and all shall fall. 

#### Isaiah 16:10 And {shall be lifted away gladness and the leap for joy} from the vineyards; and in your vineyards in no way shall they be glad; and in no way shall they tread wine in the wine-vats; for the vintage has been ceased. 

#### Isaiah 16:11 On account of this my belly {for Moab as a harp shall sound}, and {the things within me as a wall you renewed}. 

#### Isaiah 16:12 And it shall be for your feeling of shame (for Moab tired upon the shrines) that he shall enter unto the handmade things of hers so as to pray; and in no way should they be able to rescue her. 

#### Isaiah 16:13 This is the saying which the LORD spoke against Moab. 

#### Isaiah 16:14 And now the LORD spoke, saying, In three years, of the years of a hireling, {shall be dishonored the glory of Moab} in all the {richness much}; and {shall be left behind very few}, and not the important. 

#### Isaiah 17:1 The word against Damascus. Behold, Damascus shall be lifted from cities, and will be for a downfall; 

#### Isaiah 17:2 being left behind into the eon for a bed, {for flocks and a resting}, and there will not be one pursuing. 

#### Isaiah 17:3 And no longer shall there be a fortified place to take refuge there for Ephraim; and no longer a kingdom in Damascus, nor a remaining of the Syrians. {no For you better are} than the sons of Israel, even their glory; thus says the LORD of Hosts. 

#### Isaiah 17:4 It shall be in that day an end of the glory of Jacob; and the plenty of his glory shall be shaken. 

#### Isaiah 17:5 And it shall be in which manner as if someone should gather {harvest a standing}, and {the grain of corn should reap}; and it shall be in which manner if someone should gather corn in {ravine a solid rock}; 

#### Isaiah 17:6 and as if {should be left behind in it stubble}, or as {stones olive two or three} {at the top of the tree elevated}, or four or five {upon their tender branches should be left behind}. Thus says the LORD God of Israel. 

#### Isaiah 17:7 In that day {will be relying man} upon the one who made him, and his eyes {to the holy one of Israel shall look}. 

#### Isaiah 17:8 And in no way should they be relying upon the shrines, nor upon the works of their hands which they made with their fingers; and they shall not look to the trees, nor their abominations. 

#### Isaiah 17:9 In that day {shall be your cities} abandoned, in which manner {left the Amorites and the Hivites} before the face of the sons of Israel; and they shall be desolate places. 

#### Isaiah 17:10 Because you forsook the God your deliverer, even your God you remembered not. On account of this you shall plant {plant an untrustworthy}, and {seed an untrustworthy}. 

#### Isaiah 17:11 And in the day whenever you should plant, you shall be misled; but {by morning if you should sow} it shall bloom for a harvest in whatever day of inheritance; and as a father of a man, you shall choose by lot for your sons. 

#### Isaiah 17:12 Woe to the multitude {nations of many}; as a sea swelling up, so you shall be disturbed; and the sound {nations of many as water shall sound}. 

#### Isaiah 17:13 As {water much nations many}; as {water much by force being brought}; and he shall curse one to be far from them, and at a distance from them he shall pursue, as dust of mountains being winnowed before the wind, and as a cloud of dust {of the wheel of a blast being brought}. 

#### Isaiah 17:14 Towards evening there will be mourning; before morning, and he will not be. This is the portion of the ones despoiling us, and the inheritance to the ones having inherited us. 

#### Isaiah 18:1 Woe, O land of boats of wings beyond the rivers of Ethiopia. 

#### Isaiah 18:2 The one sending {by the sea treaties and letters Bibline papyrus} upon the water; {shall go for messengers of light} to {nation an elevated}, and a strange people, and ill-tempered. Who is it beyond, a nation unhoped for, and {being trampled now the rivers of all the land}? 

#### Isaiah 18:3 As a place being inhabited it shall be inhabited; their place as a signal flag {from a mountain should be lifted up}; as {trumpet sound an audible}. 

#### Isaiah 18:4 Because thus said the LORD to me; Safety will be in my city, as the light of sweltering heat at midday, and {as a cloud of dew in the day of harvest it will be}. 

#### Isaiah 18:5 Before the harvest, whenever {should be completely formed the flower}, and the unripe grape should blossom a flower being sour, that he shall remove the {grape-clusters small} with the pruning sickles; and the small vine branches he shall remove and shall cut off. 

#### Isaiah 18:6 And he shall leave them behind together for the winged creatures of the heaven, and for the wild beasts of the earth. And {shall be brought together upon them the winged creatures of the heaven}; and all the wild beasts of the earth {upon her shall come}. 

#### Isaiah 18:7 In that time {shall be offered gifts} to the LORD of Hosts from a people being afflicted and being plucked, and from a people great from the present and into the eon of time; a nation hoping and being trampled, which is in a part of the river of his place, to the place where the name of the LORD of Hosts is -- in {mountain the holy}. 

#### Isaiah 19:1 The vision of Egypt. Behold, the LORD sits upon {cloud a nimble}, and shall come to Egypt. And {shall be shaken the handmade idols of Egypt} before his face, and their heart shall be vanquished in them. 

#### Isaiah 19:2 And Egyptians shall be roused against Egyptians, and {shall wage war against every man} his brother, and every man against his neighbor; city against city, and abode against abode. 

#### Isaiah 19:3 And {shall be disturbed the spirit of the Egyptians} in themselves; and {their plan I shall efface}. And they shall ask of their gods, and of their statues, and the ones {from out of the earth that speak out loud}, and the ones delivering oracles. 

#### Isaiah 19:4 And I will deliver up the Egyptian into the hands of men {masters being hard}; and {kings hard} shall lord over them. Thus says the LORD of Hosts. 

#### Isaiah 19:5 And {shall drink the Egyptians} water by the sea, for the river shall fail and shall dry up. 

#### Isaiah 19:6 And {shall fail the rivers and the aqueducts of the river}; and {shall be dried up all the gathering of water}, and in every marsh of reed and papyrus, 

#### Isaiah 19:7 and {the green all} round about the river, and all the thing being sown throughout the river shall be dried, destroyed by the wind. 

#### Isaiah 19:8 And {shall moan the fishermen}; and {shall moan all the ones throwing a hook into the river}; and the ones throwing dragnets and the casting-net fishermen shall mourn. 

#### Isaiah 19:9 And shame shall take the ones working the {flax shredded}, and the ones working the linen. 

#### Isaiah 19:10 And {will be the ones working them} in grief; and all the ones making beer shall be fretful; and the souls shall cause pain. 

#### Isaiah 19:11 And {will be morons the rulers of Tanis}; and the wise counselors of the king, their counsel will be moronish. How shall you say to the king, {sons of discerning men We are}, sons of kings from the beginning? 

#### Isaiah 19:12 Where are they now, your wise men? and let them announce to you, and say what {planned the LORD of Hosts} against Egypt. 

#### Isaiah 19:13 {failed The rulers of Tanis}, and {are haughty the rulers of Memphis}; and they shall cause Egypt to wander and the tribes. 

#### Isaiah 19:14 For the LORD mixed for them a spirit addicted to a delusion; and they caused Egypt to wander in all its works, as {wanders the one being intoxicated} and the one vomitting together. 

#### Isaiah 19:15 And there will not be {for the Egyptians work}, which shall make head or tail, and beginning or end. 

#### Isaiah 19:16 In that day {will be the Egyptians} as women, in fear and in trembling from in front of the hand of the LORD of Hosts, which he shall put upon them. 

#### Isaiah 19:17 And {will be the place of the Jews} to the Egyptians for a fearful thing; any one who might name it to them, they shall fear, because of the plan which the LORD of Hosts planned against it. 

#### Isaiah 19:18 In that day there will be five cities in Egypt speaking the tongue of the Canaanites, and swearing by an oath to the name of the LORD of Hosts. {City of Asedek shall be called The one city}. 

#### Isaiah 19:19 In that day there will be an altar to the LORD in the region of the Egyptians; and there will be a monument at its border to the LORD. 

#### Isaiah 19:20 And it will be for a sign into the eon to the LORD in the place of Egypt; for they shall cry out to the LORD because of the ones afflicting them; and he shall send to them a man who will deliver them; by judging he shall deliver them. 

#### Isaiah 19:21 And {made known will be the LORD} to the Egyptians; and {shall know the Egyptians} the LORD in that day; and they shall make a sacrifice offering and a gift offering; and they shall vow vows to the LORD, and shall render them. 

#### Isaiah 19:22 And the LORD shall strike the Egyptians with a calamity, and he shall heal them; and they shall be turned towards the LORD; and he shall listen to them, and he shall heal them with healing. 

#### Isaiah 19:23 In that day there will be a way of Egypt to the Assyrians; and {shall enter the Assyrians} into Egypt, and Egypt will go to the Assyrians, and {shall serve the Egyptians} to the Assyrians. 

#### Isaiah 19:24 In that day Israel will be third with the Egyptians and with the Assyrians, being blessed in the land; 

#### Isaiah 19:25 which {blessed the LORD of Hosts}, saying, Blessed be my people, the one in Egypt, and the one among the Assyrians, and my inheritance Israel. 

#### Isaiah 20:1 The year that Tartan entered unto Ashdod, when he was sent by Sargon king of the Assyrians, and he waged war against Ashdod, and overtook it, 

#### Isaiah 20:2 Then the LORD spoke to Isaiah son of Amoz, saying, Go and remove the sackcloth from your loin, and {your sandals untie} from your feet! And he did thus, going naked and barefoot. 

#### Isaiah 20:3 And the LORD said, In which manner {goes Isaiah my servant} naked and barefoot -- three years shall be signs and miracles to the Egyptians and Ethiopians; 

#### Isaiah 20:4 for thus {shall lead the king of the Assyrians} the captivity of Egypt and Ethiopia, young men and old men, naked and barefoot, uncovering the shame of Egypt. 

#### Isaiah 20:5 And they shall be ashamed being vanquished upon the Ethiopians of whom {were relying the Egyptians}, for they were their glory. 

#### Isaiah 20:6 And {shall say the ones dwelling in the island} this in that day, Behold, we were relying to flee to them for help, to the ones who were not able to be delivered from the king of the Assyrians; and how shall we be delivered? 

#### Isaiah 21:1 The vision of the wilderness. As a blast {through a wilderness might go}, from out of the wilderness coming from land; 

#### Isaiah 21:2 so a fearful {vision and hard} was announced to me; the one disregarding disregards; the one acting lawlessly acts lawlessly. {are upon me The Elamites}, and the ambassadors of the Persians {against me come}. Now I shall moan and shall comfort myself. 

#### Isaiah 21:3 Because of this {was filled my loin} with feebleness, and pangs took me as the one giving birth. I transgressed to not hear, I hurried to not see. 

#### Isaiah 21:4 My heart wanders, and lawlessness immerses me; my soul attends to fear. 

#### Isaiah 21:5 Prepare the table! Eat! Drink! Rising up are the rulers. Pull up shields! 

#### Isaiah 21:6 For thus said the LORD to me, Proceeding, {yourself stand} as watchman, and whatever you should behold announce! 

#### Isaiah 21:7 And I saw riders -- {horsemen two}, a rider of a donkey, and a rider of a camel. Listen {hearing with great}! 

#### Isaiah 21:8 And call Uriah to the watchtower of the LORD! And he said, I stood always by day, and over the camp I stood all the night. 

#### Isaiah 21:9 And behold, he comes -- a rider of a double chariot; and responding he said, Has fallen, has fallen, Babylon and all her statues; and her handmade idols were broken unto the ground. 

#### Isaiah 21:10 Hear! O ones being left behind, and, O ones grieving. Hear what I heard from the LORD of Hosts! what the God of Israel announced to you. 

#### Isaiah 21:11 The vision of Edom. {to me He called} from Seir. Guard the parapets! 

#### Isaiah 21:12 I guard in the morning, and the night; if you should seek, seek; and {with me live}! 

#### Isaiah 21:13 In the forest by evening you shall bed down in the way of Dedan; 

#### Isaiah 21:14 for meeting with the one thirsting {water bring}! O ones dwelling in the place of Tema. {with bread loaves Meet} the ones fleeing! 

#### Isaiah 21:15 because of the multitude of the ones being slain, and because of the multitude of the ones wandering, and because of the multitude of the swords, and because of the multitude of the bows of the ones being extended, and because of the multitude of the ones fallen in the battle. 

#### Isaiah 21:16 For thus {said to me the LORD}, Yet a year, as the year of a hireling, {shall fail the glory of Kedar}. 

#### Isaiah 21:17 And the remnant of the {bowmen strong} of the sons of Kedar will be few. For the LORD God of Israel spoke. 

#### Isaiah 22:1 The matter of the ravine of Zion. What happened to you that now you {ascended all} unto the roofs in vain? 

#### Isaiah 22:2 {was filled up the city} of ones yelling. Your slain are not slain ones by swords, nor your dead dead ones by war. 

#### Isaiah 22:3 All your rulers have fled together from the bow, {being tied they are}, and the ones being strong among you {at a distance have fled}. 

#### Isaiah 22:4 On account of this, I said, Let me go! {bitterly I shall weep}. You should not grow strong to comfort me over the destruction of the daughter of my people. 

#### Isaiah 22:5 For it is a day of disturbance, and destruction, and trampling, and an addiction to a delusion by the LORD of Hosts. {in the ravine of Zion They wander}. {from small unto great They wander} upon the mountain. 

#### Isaiah 22:6 But the Elamites took quivers, and {riders men} upon horses, and there was a gathering of a battle array. 

#### Isaiah 22:7 And {will be choice ravines your} filled of chariots, and the horsemen shall obstruct your gates. 

#### Isaiah 22:8 And they shall uncover the gates of Judah, and they shall look in that day unto the choice houses of the city. 

#### Isaiah 22:9 And they shall uncover the hidden places of the houses of the Akra of David. And they saw that {many more there were}, and they turned the water of the ancient pool into the city; 

#### Isaiah 22:10 and that they demolished the houses of Jerusalem for fortification of the walls of the city. 

#### Isaiah 22:11 And you produced for yourselves water between the two walls inside the {pool ancient}, but you did not look to the {in the beginning one making it}; and the one creating it you did not behold. 

#### Isaiah 22:12 And {called the LORD of Hosts in that day for weeping}, and beating the breast, and shaving, and girding up sackcloths. 

#### Isaiah 22:13 But they were making glad and leaping for joy, slaying calves, and sacrificing sheep so as to eat meat and to drink wine, saying, We should eat and drink, for tomorrow we die. 

#### Isaiah 22:14 And {being uncovered these things are} in the ears of the LORD of Hosts, for {shall not be forgiven you this sin} until whenever you should die. 

#### Isaiah 22:15 Thus says the LORD of Hosts, Go into the cubicle, to Somnan the storekeeper, and say to him, 

#### Isaiah 22:16 Why are you here? and what is there to you here? that you quarried for yourself here a memorial, and made for yourself in a high place a memorial, and depicted to yourself {in the rock a dwelling}. 

#### Isaiah 22:17 Behold, indeed, the LORD of Hosts shall cast out and shall obliterate such a man, and shall remove your apparel, and {crown your honorable}, 

#### Isaiah 22:18 and will toss you into {place a great and unmeasured}, and there you shall die; and he will establish {chariot your good} for dishonor, and the house of your ruler for trampling. 

#### Isaiah 22:19 And you shall be removed from your administration, and from your station. 

#### Isaiah 22:20 And it will be in that day, even I will call my servant Eliakim the son of Helkiah; 

#### Isaiah 22:21 and I will put on him your apparel, and {your crown I will give to him}. And might, and your administration I will put into his hands; and he shall be as a father to the ones dwelling Jerusalem, and to the ones dwelling Judah. 

#### Isaiah 22:22 And I will put to him the key of the house of David upon his shoulder. And he shall open, and there will not be one locking. And he shall lock, and there shall not be one opening. And I will give the glory of David to him. And he will rule, and there will not be one disputing. 

#### Isaiah 22:23 And I will establish him as ruler in {place a trustworthy}, and he will be for a throne of glory {house for his father's}. 

#### Isaiah 22:24 And {will be relying upon him every honorable one in the house of his father}, from small unto great; every {vessel small} from vessels of the cups. And they will be hanging upon him in that day. 

#### Isaiah 22:25 Thus says the LORD of Hosts, {shall be moved The man being fixed fast in place a trustworthy}; and {shall be removed and shall fall and shall waste away the glory upon him}; for the LORD spoke. 

#### Isaiah 23:1 The matter of Tyre. Shriek O boats of Carthage! For she perished, and no longer do they come from out of the land of Chittim; she is led captive. 

#### Isaiah 23:2 To whom {likened have become the ones dwelling in the island}; traders of Phoenicia passing through the sea; 

#### Isaiah 23:3 in {water much}; a seed of traders; {as a harvest being carried in the traders of the nations}. 

#### Isaiah 23:4 Be ashamed, O Sidon, said the sea! Even the strength of the sea said, I travailed not, nor gave birth, nor nourished young ones, nor raised up virgins. 

#### Isaiah 23:5 But whenever {audible it should become} in Egypt, {shall overtake them grief} concerning Tyre. 

#### Isaiah 23:6 Go forth to Carthage! Shriek! O ones dwelling in this island. 

#### Isaiah 23:7 {not this Was} your insolence, the one from the beginning, before she was delivered up? 

#### Isaiah 23:8 Who planned these things against Tyre? {she inferior Is} or not strong? Her merchants were the glorious rulers of the earth. 

#### Isaiah 23:9 The LORD of Hosts plans to disable all the insolence of the glorious ones, and to dishonor every glorious thing upon the earth. 

#### Isaiah 23:10 Work your land! for even boats no longer come from out of Carthage. 

#### Isaiah 23:11 And your hand no longer prevails against the sea, O one provoking kings. The LORD of Hosts gave charge concerning Canaan, to destroy her strength. 

#### Isaiah 23:12 And they shall say, No longer in any way should you proceed to insult and to wrong the daughter of Zion; and if you should go forth to Chittim, not even there shall be rest to you. 

#### Isaiah 23:13 And if you depart unto the land of the Chaldeans, even this was made desolate from the Assyrians, not even there {to you will be rest}, for her wall has fallen. 

#### Isaiah 23:14 Shriek! boats of Carthage, for {is destroyed your fortress}. 

#### Isaiah 23:15 And it will be in that day, Tyre shall be forsaken {years for seventy}, as the time {king of one}, as the time of a man. And after seventy years Tyre will be as the song of a harlot. 

#### Isaiah 23:16 Take a harp! Stray! {city O harlot} being forgotten. {well Play the harp}! {much Sing}! that the memory of you takes place. 

#### Isaiah 23:17 And it will be after the seventy years, {a visit will make God} to Tyre, and again she shall be restored to her ancient state; and she shall be a market-place for all the kingdoms of the inhabitable world upon the face of the earth. 

#### Isaiah 23:18 And {will be her trade and wage} holy to the LORD. {not to them It shall be brought}, but to the ones dwelling before the LORD, even all her trade, to eat and to drink, and be filled, and for a compact memorial before the LORD. 

#### Isaiah 24:1 Behold, the LORD lays waste the {inhabitable world whole}, and will make it desolate, and shall uncover its surface, and disperse the ones dwelling on it. 

#### Isaiah 24:2 And {will be the people} as priests; and the servant as the master; and the female attendant {as the lady will be}; the one buying as the one selling; the one borrowing as the one lending; and the one owing as the one who is owed. 

#### Isaiah 24:3 By corruption {shall be corrupted the earth}; and by plunder {shall be plundered the earth}; for the mouth of the LORD spoke these things. 

#### Isaiah 24:4 {mourns The earth}, and {is corrupted the world}; {mourn the lofty ones of the earth}. 

#### Isaiah 24:5 And the earth acted lawlessly on account of the ones inhabiting her; because they transgressed the law of the LORD, and effaced and bartered away the orders -- {covenant the eternal}. 

#### Isaiah 24:6 Therefore this curse shall devour the earth; for {sinned the ones dwelling on it}; on account of this {will be poor the ones dwelling on the earth}, and {will be left behind men a few}. 

#### Isaiah 24:7 {shall mourn The wine}, {shall mourn the grapevine}, {shall moan all the ones being glad in soul}. 

#### Isaiah 24:8 {has ceased The gladness of tambourines}; {have ceased self-sufficiency and riches impious}; {has ceased the sound of the harp}. 

#### Isaiah 24:9 They are ashamed, they did not drink wine; {bitter became liquor} to the ones drinking. 

#### Isaiah 24:10 {was desolate Every city}. One shall lock the house to not enter. 

#### Isaiah 24:11 Shriek for the wine everywhere! {has ceased All gladness of the earth}; {departed all gladness of the earth}; 

#### Isaiah 24:12 and {shall be left behind cities desolate}, and houses being abandoned shall be consumed. 

#### Isaiah 24:13 All these things will be on the earth in the midst of the nations. In which manner as if one should glean an olive tree, thus shall they glean them, even as if {should cease the gathering a crop}, 

#### Isaiah 24:14 And these in a voice shall yell out; but the ones being left behind upon the earth shall be glad together in the glory of the LORD; {shall be disturbed the water of the sea}. 

#### Isaiah 24:15 On account of this the glory of the LORD {among the islands will be} of the sea; the name of the LORD will be honored. 

#### Isaiah 24:16 O LORD God of Israel, from the wings of the earth {miracles we heard} -- hope to the pious; but they shall say, Woe to the ones annulling -- the ones annulling the law. 

#### Isaiah 24:17 Fear, and a pit, and a snare is upon you, O ones dwelling upon the earth. 

#### Isaiah 24:18 And it will be the one fleeing the fear shall fall into the pit; and the one going up from out of the pit shall be captured by the snare; for windows from out of the heaven were opened, and {shall be shaken the foundations of the earth}. 

#### Isaiah 24:19 By disturbance {shall be disturbed the earth}; and with perplexity {shall be perplexed the earth}. 

#### Isaiah 24:20 It leans and {shall be shaken as a storehouse of fruits the earth}; as the one being intoxicated and dizzy; and it shall fall, and in no way be able to rise up. {shall grow strong For upon it lawlessness}. 

#### Isaiah 24:21 And it will be in that day {shall bring God against the cosmos of the heaven the hand}, and against the kings of the earth. 

#### Isaiah 24:22 And they shall gather its congregation, and shall lock them into a fortress and in a jail; through many generations {visited will be they}. 

#### Isaiah 24:23 And {shall melt away the brick}, and {shall fall the wall}, and {shall feel remorse the moon}, and {shall be ashamed the sun}, for the LORD shall reign in Zion, and from out of Jerusalem, and {before the elders he shall be glorified}. 

#### Isaiah 25:1 O LORD my God, I will glorify you, I shall sing praise to your name; for you did wonderful things; {counsel ancient true}. May it be. 

#### Isaiah 25:2 For you made cities into a heap of embankments, cities fortified to not fall of their foundations. {of the impious The city for the eon in no way should be built}. 

#### Isaiah 25:3 On account of this, {shall bless you the people poor}, and cities of men being wronged shall bless you. 

#### Isaiah 25:4 For you became {to every city humble a helper}, and {to the ones depressed on account of lack a protection}; {from men wicked you shall rescue them}; a protection to the ones thirsting, and a fresh wind for men being wronged; 

#### Isaiah 25:5 as {men faint-hearted} thirsting in Zion, for you shall rescue them from {men impious}, to whom {us you delivered}. 

#### Isaiah 25:6 And {shall make a feast the LORD of Hosts} for all the nations; upon this mountain they shall drink in gladness, they shall drink wine. 

#### Isaiah 25:7 They shall anoint with a perfumed liquid on this mountain. You deliver all these things to the nations, for this plan is for all the nations. 

#### Isaiah 25:8 {swallowed Death} prevailing; and again {removed the LORD God} every tear from every face; {the scorn of the people he removed} from all the earth; for the mouth of the LORD spoke. 

#### Isaiah 25:9 And they shall say in that day, Behold, our God upon whom we hoped, even he shall deliver us. This is the LORD. We waited for him, and we exulted and were glad over our deliverance. 

#### Isaiah 25:10 {rest will give God} upon this mountain, and {shall be trampled the land of Moab}, in which manner they tread the threshing-floor with wagons. 

#### Isaiah 25:11 And he shall unfasten his hands, in which manner even as he humbled to destroy. And he shall humble his insolence upon which {his hands he put}. 

#### Isaiah 25:12 And the height of the refuge of your house he will lower; and it shall go down unto the ground. 

#### Isaiah 26:1 In that day they shall sing this song upon the land of Judea, Behold, {city a strong}; and {our deliverance he shall establish} for the wall and rampart. 

#### Isaiah 26:2 Open O gates! Enter! O people guarding righteousness, and guarding truth; 

#### Isaiah 26:3 taking hold of truth, and guarding peace. 

#### Isaiah 26:4 For upon you we hoped, O LORD unto the eon, the {God great eternal}; 

#### Isaiah 26:5 who humbling, he led down the ones dwelling on high. {cities fortified You shall throw down}, and lead them down unto the ground. 

#### Isaiah 26:6 And {will tread them feet gentle} and of humble rostrums. 

#### Isaiah 26:7 The way of the pious {straight becomes}; and {is being prepared the way of the pious}. 

#### Isaiah 26:8 For the way of the LORD is equitable; we hoped upon your name, and upon the remembrance of you 

#### Isaiah 26:10 9 which {desires our soul}. From out of the night {rises early my spirit} to you, O God, because {are light your orders} upon the earth. {righteousness Learn}, O ones dwelling upon the earth!{ceases For the impious}; in no way should he learn righteousness upon the earth; {truth no way should he execute}. Lift away the impious! that he should not behold the glory of the LORD. 

#### Isaiah 26:11 O LORD, {is high your arm}, but they did not know; but in knowing they shall be ashamed; zeal shall take hold {people of an uninstructed}; and now fire {the adversaries shall devour}. 

#### Isaiah 26:12 O LORD our God, {peace give} to us! for all things you rendered to us. 

#### Isaiah 26:13 O LORD our God, acquire us! O LORD, outside of you there is no other we know. {your name We named}. 

#### Isaiah 26:14 But the dead {life in no way shall see}, nor shall physicians in any way raise them up. On account of this you struck, and destroyed; and you lifted away every male of them. 

#### Isaiah 26:15 Add to them bad things, O LORD, add bad things to the glorious ones of the earth! 

#### Isaiah 26:16 O LORD, in affliction we remembered you; in {affliction small} your instruction is with us. 

#### Isaiah 26:17 And as a woman travailing approaches to give birth, and over her birth pangs she cries out, so we were to your beloved. 

#### Isaiah 26:18 Because of the fear of you, O LORD, {in the womb we conceived}, and travailed, and birthed the breath of your deliverance, which you did upon the earth. We shall not fall, but {shall fall all the ones dwelling upon the earth}. 

#### Isaiah 26:19 {shall rise up The dead}, and {shall be raised the ones in the sepulchres}, and {shall be glad the ones in the earth}, for the dew by you {a cure to them is}; but the land of the impious shall fall. 

#### Isaiah 26:20 Proceed, O my people! Enter into your inner chambers! Lock your door! Be concealed a little! as much as this, as much as that, until whenever {should go by the anger of the LORD}. 

#### Isaiah 26:21 For behold the LORD {from the holy place brings anger} upon the ones dwelling upon the earth; and {shall uncover the earth} her blood, and shall not cover up the ones being done away with any more. 

#### Isaiah 27:1 In that day {will bring on God} the {sword holy and the great and the strong} against the dragon, {serpent the fleeing} -- against the dragon, {serpent the crooked}. And he will do away with the dragon, the one in the sea. 

#### Isaiah 27:2 In that day {vineyard there shall be a good}, and a desire to lead a song concerning it. 

#### Isaiah 27:3 I am {city a fortified}, a city being assaulted. In folly I water her, for she shall be captured by night, and by day {shall fall her wall}. 

#### Isaiah 27:4 There is not her who did not take hold of her; therefore because of this the LORD did all as much as he ordered. I am incinerated. 

#### Isaiah 27:5 {shall yell All the ones dwelling in her}, We should make peace with him, we should make peace. 

#### Isaiah 27:6 The ones coming are children of Jacob. {shall burst forth and shall blossom Israel}, and {shall be filled with the inhabitable world} its fruit. 

#### Isaiah 27:7 Is it not as he struck others, even he himself so shall be struck? And as he did away with, also he himself thus shall be done away with? 

#### Isaiah 27:8 {doing combat and berating He shall send them out}. {not you Were} the one meditating with {spirit a harsh}, to do away with them in a spirit of rage? 

#### Isaiah 27:9 On account of this {shall be removed the lawlessness} from Jacob; and this is his blessing; whenever I should remove {from him the sin}; whenever they should furnish all the stones of the shrines for being cut in pieces as {powder fine}; and in no way should {remain their trees}, and their idols shall be in the state of being cut down as a forest far off. 

#### Isaiah 27:10 The {dwelling there flock spared will be} as a flock being left behind; and there will be much time for pasture, and there they shall rest. 

#### Isaiah 27:11 And after much time there will not be in it any green thing on account of drying out. O women coming from a spectacle, come. {no for a people it is having} understanding. On account of this in no way should {pity the one making them}, nor the one shaping them in any way show mercy. 

#### Isaiah 27:12 And it will be in that day the LORD will shut up together from the aqueduct of the river unto Rhinocora. But you gather together the sons of Israel, according to one by one! 

#### Isaiah 27:13 And it will be in that day they shall trump the {trumpet great}, and {shall come the ones being lost in the place of the Assyrians}, and the ones being lost in Egypt. And they shall do obeisance to the LORD upon the {mountain holy} in Jerusalem. 

#### Isaiah 28:1 Woe to the crown of insolence, the hirelings of Ephraim, the flower, the one having fallen of the glory upon the top of the {mountain thick branched}, the ones being intoxicated without wine. 

#### Isaiah 28:2 Behold, strong and hard is the rage of the LORD; as hail being carried down not having protection, with force being carried down; as {water of much a multitude} dragging a place along. In the land he shall cause rest to the hands. 

#### Isaiah 28:3 And by the feet {shall be trampled the crown of insolence}, the hirelings of Ephraim. 

#### Isaiah 28:4 And {shall be the flower} (the one having fallen off of the hope of the glory) upon the tip of the {mountain high} as a forerunner of a fig. The one beholding it, before {into his hand taking it}, will want to swallow it down. 

#### Isaiah 28:5 In that day {will be the LORD of Hosts} the crown of hope, the plaited crown of glory to the one being left behind of my people. 

#### Isaiah 28:6 And they shall be left behind in spirit of equity for judgment, and for the strength restraining doing away with. 

#### Isaiah 28:7 For these {in wine wandering are}; wandering because of the liquor; the priest and prophet are startled because of the liquor; they are swallowed down because of the wine; they are shaken from the intoxication of the liquor; they wandered; this is a visible manifestation. 

#### Isaiah 28:8 A curse shall devour this plan, for this plan is because of the desire for wealth. 

#### Isaiah 28:9 To whom did we announce evils? and to whom did we announce a message? even to the ones being weaned from milk, and the ones being drawn away from the breast. 

#### Isaiah 28:10 Affliction upon affliction; favorably receive hope upon hope; still a little, still a little, 

#### Isaiah 28:11 because of disparagement of the lips; {by tongue another for they shall speak} to this people, 

#### Isaiah 28:12 saying to it, This is the rest to the one hungering, and this is the destruction; and they did not want to hear. 

#### Isaiah 28:13 And {will be to them the oracle of God}, affliction upon affliction, hope upon hope, still a little, still a little; that they should go and should fall to the rear, and shall be exposed to danger, and shall be broken, and shall be captured. 

#### Isaiah 28:14 On account of this hear the word of the LORD, O men being afflicted, and rulers of this people in Jerusalem! 

#### Isaiah 28:15 For you said, We made a covenant with Hades, and {with death treaties}. {a gale being brought If} should go by, in no way should it come to us. We made the lie our hope, and by the lie we shall be sheltered. 

#### Isaiah 28:16 On account of this, thus says the LORD, Behold, I shall put for the foundations of Zion {stone a very costly chosen cornering} of value for its foundations; and the one trusting upon it in no way should be disgraced. 

#### Isaiah 28:17 And I shall place judgment for hope, and my charity by weights. And the ones relying vainly in a lie that in no way should {go by you the gale}; 

#### Isaiah 28:18 even {should not have removed your covenant of death}; and your hope, the one in Hades in no way should adhere. {the blast being brought If} should come, you will be {by it for trampling}. 

#### Isaiah 28:19 Whenever it should go by, it shall take you. Morning by morning it shall go by you, and in the night it will be {hope an evil}. Learn to hear! 

#### Isaiah 28:20 O ones having been restricted, in no way are we able to do combat; but we are ourselves weakened for you to gather. 

#### Isaiah 28:21 As if a mountain of impious men the LORD shall rise up; and it shall be in the ravine of Gibeon; with rage he shall execute his works -- {of bitterness a work}; but his rage {strangely he shall treat}, and his rottenness in strangeness. 

#### Isaiah 28:22 And you, may you not be glad, nor {strengthen in you the bonds}; because {being completed and being rendered concise the things I heard} by the LORD of Host, which he will do upon all the earth. 

#### Isaiah 28:23 Give ear and hearken to my voice! Take heed and hear my words! 

#### Isaiah 28:24 Shall not {the entire day be about the one plowing to plow}? or the one sowing, will he not prepare beforehand to work the ground? 

#### Isaiah 28:25 Does he not whenever he should level the face of it, then sow the small pepperwort or cummin, and again sow wheat, and barley, and spelt, in your boundaries? 

#### Isaiah 28:26 And you shall be corrected in the equity of your God, and shall be glad. 

#### Isaiah 28:27 For not with hardness {cleansed is the pepperwort}, nor {the wheel of a wagon shall} lead about upon the cummin; but {by a rod is shaken off the pepperwort}. 

#### Isaiah 28:28 But the cummin {with bread shall be eaten}, {not for into the eon I am provoked to anger against you}, nor shall the voice of my bitterness trample you. 

#### Isaiah 28:29 And these {by the LORD of Hosts came forth miracles}. Take counsel, exalt vain comfort! 

#### Isaiah 29:1 Woe city of Ariel, which David waged war. Gather together produce year by year! for you shall eat with Moab. 

#### Isaiah 29:2 For I will squeeze Ariel, and {will be her strength and riches} mine. 

#### Isaiah 29:3 And I will encircle as David upon you, and I will throw up {around you a siege mound}, and I will build, and I will set {around you towers}. 

#### Isaiah 29:4 And {shall be abased your words} unto the ground. And unto the ground your words shall go down. And {will be as the ones speaking out loud from out of the earth your voice}; and to the ground your voice shall weaken. 

#### Isaiah 29:5 And {will be as a cloud of dust from a wheel the riches of the impious}; and {will be as dust being borne about the multitude of the ones afflicting you}; and it will be {as a moment immediate}, 

#### Isaiah 29:6 by the LORD of Hosts; {a visitation for there will be} with thunder, and earthquake, and {sound a great}, a blast being borne about, and a flame of fire devouring. 

#### Isaiah 29:7 And {will be as ones dreaming in sleep the riches of all the nations}, as many as march against Ariel, and all the ones soldiering against Jerusalem, and all the ones gathering together against her, and the ones afflicting her. 

#### Isaiah 29:8 And it shall be as the ones in sleep drinking and eating and rising up. {is vain of them the dream}, and in which manner {shall dream the one thirsting and drinking}, and rising up they still thirst, and his soul {in vain hoped}, so will be the riches of all the nations, as many as marched against mount Zion. 

#### Isaiah 29:9 Be loosened! Be amazed and be dizzy! Not from liquor nor from wine. 

#### Isaiah 29:10 For {has given you to drink the LORD} a spirit of vexation. And he will close the eyelids of their eyes, and their prophets, and their rulers, the ones seeing the hidden things. 

#### Isaiah 29:11 And {shall be to you all sayings these} as the words {scroll having a seal set upon it of this}; which if they should give it to a man having knowledge of letters, saying, Read these things! Then he shall say, I am not able to read, for it is sealed. 

#### Isaiah 29:12 And {will be given scroll this} into the hands of a man not having knowledge of letters. And one shall say to him, Read this! And he shall say, I do not have knowledge of letters. 

#### Isaiah 29:13 And the LORD said, {approach unto me this people} with their mouth, and by their lips they esteem me, but their heart is far off at a distance from me; and in vain they worship me, teaching the precepts {of men and instructions}. 

#### Isaiah 29:14 On account of this, behold, I shall proceed to transpose this people; and I will transpose them, and I will destroy the wisdom of the wise; and {the understanding of the discerning I will hide}. 

#### Isaiah 29:15 Woe to the ones deeply {plans making}, and not according to the LORD. Woe to the ones {in secret plans making}. And {shall be in darkness their works}, and they shall say, Who has seen us, and who shall know us or what we do? 

#### Isaiah 29:16 {not as clay for the potter Shall you be considered}? Shall {say the thing shaped} to the one shaping, You did not shape me. Or the thing made by the one making it, {not expertly You did} make me? 

#### Isaiah 29:17 No longer a little while and {shall be transposed Lebanon} as the mountain of fruitful field; and the mountain of fruitful field {as a forest shall be considered}. 

#### Isaiah 29:18 And {shall hear in that day deaf-mutes} the words of the scroll; and the ones in darkness, and the ones in fog -- the eyes of the blind will see, 

#### Isaiah 29:19 and {shall exult the poor} because of the LORD with gladness, and the ones despairing of men shall be filled up with gladness. 

#### Isaiah 29:20 {failed The lawless one}, and {is destroyed the proud one}, and {shall be utterly destroyed the ones acting lawlessly concerning evil}, 

#### Isaiah 29:21 even the ones causing {to sin men} by a word. {all And the ones reproving at the gates to be considered for stumbling men shall make}, for they bent away {by unjust acts the just one}. 

#### Isaiah 29:22 On account of this, thus says the LORD concerning the house of Jacob, whom he separated from Abraham, {not now shall be ashamed Jacob}, nor now {countenance shall Israel change}. 

#### Isaiah 29:23 But whenever {shall behold their children} my works, because of me they shall sanctify my name, and they shall sanctify the holy one of Jacob, and {the God of Israel they shall fear}. 

#### Isaiah 29:24 And {shall know the ones wandering in the spirit} understanding, and the ones grumbling shall learn to obey, and the {tongues stuttering} shall learn to speak peace. 

#### Isaiah 30:1 Woe, O children of defectors! Thus says the LORD, You made counsel, but not through me; and treaties not by my spirit, to add sins upon sins. 

#### Isaiah 30:2 The ones going went down into Egypt (but of me they did not ask) to be helped by Pharaoh, and sheltered by the Egyptians. 

#### Isaiah 30:3 {will be For to you the protection by Pharaoh} for shame, and the ones relying upon Egypt for scorn. 

#### Isaiah 30:4 For {are in Tanis chiefs messengers evil}. 

#### Isaiah 30:5 In folly they labor over a people who shall not benefit them, neither for help, nor for benefit, but for shame, and scorn. 

#### Isaiah 30:6 The vision of the four-footed, of the ones in the wilderness. In the affliction and in the straits are the lion and {cub lion's}; from there also asps and the progeny {asps of flying}; the ones who brought upon donkeys and camels of their riches to a nation who shall not benefit them for help, but for shame and scorn. 

#### Isaiah 30:7 The Egyptians {in vain and with emptiness shall benefit you}. Report to them that, {is vain comfort of yours This}! 

#### Isaiah 30:8 Now then while sitting, write {upon a writing-tablet these things}, and upon a scroll, for {shall be for times of days these things}, and even into the eon. 

#### Isaiah 30:9 For a people are resisting persuasion; {sons lying} who were not willing to hear the law of God. 

#### Isaiah 30:10 The ones saying to the prophets, Do not announce to us! and to the ones {the visions that see}, Do not speak to us, but speak to us, and announce to us another addicting delusion, 

#### Isaiah 30:11 and turn us from this way! Remove from us this road, and remove from us the oracle of Israel! 

#### Isaiah 30:12 On account of this, thus says the LORD, the holy one of Israel, Because you resisted persuasion to these words, and hoped upon a lie, and that you grumbled, and {relying became} upon this word. 

#### Isaiah 30:13 Therefore this will be to you -- this sin will be as a wall {falling immediately city of a fortified} being captured, of which immediately is at hand the calamitous downfall. 

#### Isaiah 30:14 And the calamitous downfall of it will be as the breaking of a receptacle of earthenware of {clay vessel a thin}, so that there should not be found among them even a potsherd in which {coals of fire to lift}, and with which to whistle up {water a little}. 

#### Isaiah 30:15 Thus says the Lord, the LORD, the holy one of Israel, Whenever turning you should moan, then shall you be delivered. And you shall know where you were when you relied upon the vanities; {vain your strength became}, and you did not want to hear. 

#### Isaiah 30:16 But you said, Upon horses we shall flee. On account of this you shall flee and say, {upon light riders we will be}; on account of this {nimble will be the ones pursuing you}. 

#### Isaiah 30:17 On account of {voice one shall flee thousands}; and because of the voice of five {shall flee many} until whenever you should be left behind as a mast upon a mountain, and as a flag borne upon a hill. 

#### Isaiah 30:18 And again {will wait God} so as to pity you. And on account of this he shall be raised up high to show mercy on you, because {judge the LORD your God is}. Blessed are all the ones adhering in him. 

#### Isaiah 30:19 For {people the holy in Zion shall live}. And Jerusalem in weeping wept, saying, Show mercy on me! He shall show mercy on you. {the sound of your cry When he perceived} he heeded you. 

#### Isaiah 30:20 The LORD shall give to you bread of affliction, and {water scant}. And {no longer shall approach to you the ones misleading you}. For your eyes shall discover the ones misleading you, 

#### Isaiah 30:21 and your ears shall hearken to the words of the ones following after you, misleading you. The ones saying, This is the way, we should go by it, whether right or whether left. 

#### Isaiah 30:22 And you shall remove the idols being silver plated; and the ones being gilded {fine dust you shall make into}; and you shall winnow as the water of a woman sitting apart, and {as dung you shall thrust them away}. 

#### Isaiah 30:23 Then there will be rain for the seed of your land; and the bread from the produce of your land will be plenteous and lustrous; and {shall graze your cattle} in that day in a place fertile and broad-spaced. 

#### Isaiah 30:24 Your bulls and oxen working the ground shall eat straw being prepared from barley being winnowed. 

#### Isaiah 30:25 And there shall be upon every {mountain high}, and upon every {hill elevated}, water traveling over in that day, whenever {should be destroyed many}, and whenever {shall fall towers}. 

#### Isaiah 30:26 And {shall be the light of the moon} as the light of the sun; and the light of the sun will be seven-fold in the day whenever the LORD should heal the breaking up of his people, and {the grief of your calamity shall heal}. 

#### Isaiah 30:27 Behold, the name the LORD comes after {time a long}, burning rage with glory. The oracle of his lips is an oracle {of anger full}, and the anger of his rage {as fire shall devour}. 

#### Isaiah 30:28 And his breath, as water {in a ravine being dragged along}, shall come unto the neck, and be divided. He shall disturb nations for {addiction to a delusion a vain}, and {shall pursue them an addiction to a delusion}, and it shall take them according to their face. 

#### Isaiah 30:29 {always Must you} be glad and enter into my holy places always, as the ones solemnizing a holiday? and as ones being glad to enter with a pipe, into the mountain of the LORD, to the God of Israel? 

#### Isaiah 30:30 And {audible will make the LORD} the glory of his voice; and the rage of his arm he will show with rage and anger. And as a flame devouring he shall strike with a thunderbolt violently; even as water and hail being carried together by force. 

#### Isaiah 30:31 For by the voice of the LORD the Assyrians shall be vanquished, even by the calamity in which he should strike them. 

#### Isaiah 30:32 And it will be to him round about, from where was to him hope for help, upon whom he relied upon; they with tambourines and harps shall wage war on him from out of revolt. 

#### Isaiah 30:33 For you {before some days shall be exacted}; not also for you was it prepared to reign? {ravine a deep}, wood being situated near a fire, and {wood much}; the rage of the LORD as a ravine {under sulphur burning}. 

#### Isaiah 31:1 Woe to the ones going down into Egypt for help; the ones {upon horses relying}, and upon chariots, for they are many; and relying upon {horses many exceedingly}. And they did not hearken relying upon the holy one of Israel, and {God they did not seek}. 

#### Isaiah 31:2 And he wisely brought upon them bad things, and his word in no way shall be annulled. And he shall rise up against the houses {men of wicked}, and against {hope their vain} -- 

#### Isaiah 31:3 an Egyptian man, and not God. Their horses are flesh and not help; but the LORD shall bring his hand against them, and {shall tire the ones helping}, and together all will perish. 

#### Isaiah 31:4 For thus said the LORD to me, In which manner whenever {should yell out the lion or the cub} over the game which he took, and shall cry out over it, until whenever {should be filled up the mountains} of his voice, and the prey are vanquished, and by the magnitude of rage they are scared; so {shall go down the LORD of Hosts} to march upon mount Zion, upon her mountains. 

#### Isaiah 31:5 As birds flying, so shall {shield the LORD of Hosts} above Jerusalem; and he shall rescue and shall protect and shall deliver. 

#### Isaiah 31:6 Turn! O ones {deep counsel consulting and lawless}, O sons of Israel. 

#### Isaiah 31:7 For in that day {shall totally reject men} the idols made by their hands -- the things made of silver, and the things of gold, which {made their hands}. 

#### Isaiah 31:8 And Assyria shall fall; not by the sword of man, nor {the sword of man shall} devour him; and he will not flee from in front of the sword; but the young men shall be for vanquishing; 

#### Isaiah 31:9 for as a rock, they shall be taken hold of as for a siege mound, and shall be vanquished; but the one fleeing shall be captured; thus says the LORD, Blessed is the one who has {in Zion a seed}, and members of a family in Jerusalem. 

#### Isaiah 32:1 For behold {king a just} shall reign, and rulers with judgment shall rule. 

#### Isaiah 32:2 And {shall be the man} hiding his words, and they shall be hid as of water being brought; and it shall be shone forth in Zion as a river being brought along, glorious in {land a thirsting}. 

#### Isaiah 32:3 And no longer will they be relying upon men, but the ears they shall give to hear. 

#### Isaiah 32:4 And the heart of the ones being weak shall take heed to hear; and the tongues stuttering, quickly they shall learn to speak peace. 

#### Isaiah 32:5 And no longer shall they tell the moron to rule; and no longer shall {say your officers}, You be quiet! 

#### Isaiah 32:6 For the moron {moronish shall speak}, and his heart {vanities shall purpose}, to complete lawless deeds, and to speak {against the LORD a delusion}, to scatter {souls hungering}, and {for the souls thirsting vain things causing}. 

#### Isaiah 32:7 For the counsel of the wicked {lawless deeds shall plan} to corrupt the lowly by {words unjust}, and to efface the words of the lowly in a case. 

#### Isaiah 32:8 But the pious {the discerning consult}, and this counsel shall abide. 

#### Isaiah 32:9 {women rich Rise up}, and hear my voice! {O daughters in hope Listen to my words}! 

#### Isaiah 32:10 {for the days of a year mention Make} in grief, yet with hope! {has been consumed The gathering of crops}, {has ceased the sowing}, and no longer should it come. 

#### Isaiah 32:11 Be amazed! Let {fret the ones persuading}! Strip! {naked Become}! Gird the loins! 

#### Isaiah 32:12 and {upon the breasts beat}! because of {field the desirable}, and {of the grapevine the produce}. 

#### Isaiah 32:13 The land of my people is a thorn-bush; and grass shall ascend, and from out of every house gladness shall be lifted away. 

#### Isaiah 32:14 The houses are being abandoned; {the riches of the city they shall leave} and {houses desirable}. And {will be the towns} caves unto the eon, a gladness {donkeys for wild}, pastures for shepherds; 

#### Isaiah 32:15 until whenever {should come upon you spirit from on high}; and {shall be wilderness the fruitful field}, and the fruitful field {as a forest shall be considered}. 

#### Isaiah 32:16 And {shall rest in the wilderness judgment}, and righteousness {in Carmel shall dwell}. 

#### Isaiah 32:17 And {shall be the works of righteousness} peace; and {shall reach righteousness} rest, and the ones relying shall be unto the eon. 

#### Isaiah 32:18 And {shall dwell his people} in a city of peace, and shall dwell in it being yielded up; and they shall rest with riches. 

#### Isaiah 32:19 And if hail should come down, {not upon you it will come}. And {will be the ones dwelling in the forests} yielding as the ones in the plain. 

#### Isaiah 32:20 Blessed are the ones sowing by every water where the ox and donkey tread. 

#### Isaiah 33:1 Woe to the ones causing misery, {you but no one makes} miserable; and the one disrespecting you, does not disrespect; {shall be captured the ones disrespecting}, and they shall be delivered up; and as a moth upon a cloak, so they shall be vanquished. 

#### Isaiah 33:2 O LORD, show mercy on us! {upon you for we rely}. {became The seed of the ones resisting persuasion} for destruction; but our deliverance is in time of affliction. 

#### Isaiah 33:3 On account of the sound of the fear of you {were amazed peoples}. {because of the fear of you and were dispersed the nations}. 

#### Isaiah 33:4 But now {shall be gathered your spoils}, small and great; in which manner as if one should gather locusts, so they shall mock you. 

#### Isaiah 33:5 Holy is the God dwelling in heavens. Zion shall be filled up with equity and righteousness. 

#### Isaiah 33:6 {to the law They shall be delivered up}. {is in treasuries Our deliverance}. Located there are wisdom and higher knowledge and piety to the LORD; these are treasuries of righteousness. 

#### Isaiah 33:7 Behold indeed, in the fear of you these shall be fearful. Whom you feared shall yell out because of you; for messengers shall be sent enjoining for peace, bitterly weeping. 

#### Isaiah 33:8 {shall be made desolate For the of these ways}. {has been made to cease Your fear of the nations}, and the covenant is lifted away, and in no way shall you consider them men. 

#### Isaiah 33:9 {mourned The land}. Lebanon is ashamed. {marshes became Sharon}. {of distinction will be Galilee}, and Carmel. 

#### Isaiah 33:10 Now I shall rise up, says the LORD. Now I shall be glorified, now I shall be exalted, 

#### Isaiah 33:11 now you shall see, now you shall perceive, {in vain shall be the strength of your spirit}; fire shall devour you. 

#### Isaiah 33:12 And {shall be the nations} for incinerating as a thorn-bush in a field being tossed and being incinerated. 

#### Isaiah 33:13 {shall hear The ones at a distance} what I did; and {shall know the ones approaching} my strength. 

#### Isaiah 33:14 {departed The in Zion lawless ones}. {shall take Trembling} the impious. Who shall announce to you that a fire is being burned? Who shall announce to you the {place eternal}? 

#### Isaiah 33:15 The one going in righteousness, speaking the straight way, detesting lawlessness and injustice, and {with the hands shaking off bribes}, weighing down the ears that he should not hear a judgment of blood, closing the eyelids of the eyes that he should not behold injustice. 

#### Isaiah 33:16 This one shall live in a high cave {rocks of strong}; bread shall be given to him, and his water is trustworthy. 

#### Isaiah 33:17 {a king with glory You shall see}, and your eyes shall see a land at a distance. 

#### Isaiah 33:18 Your soul shall meditate upon fear. Where are the academics? Where are the ones advising? Where is the one counting the ones being maintained? 

#### Isaiah 33:19 A small and great people which did not take advice, nor had beheld a deep voice, so that {should not hear a people being treated as worthless}, and there is no {to the one hearing understanding}. 

#### Isaiah 33:20 Behold, Zion the city, our deliverance. Your eyes shall see Jerusalem, {city a rich}, tents which in no way shall be shaken, nor shall {be moved the stanchions of her tent} into the eon of time, nor {her rough cords in any way shall} be torn up. 

#### Isaiah 33:21 For the name of the LORD {great to you will be}; with rivers and {aqueducts spacious and broad}. You shall not go this way, nor shall {go a boat being rowed}. 

#### Isaiah 33:22 For my God is great; {shall not pass me by the LORD}; the LORD our judge; the LORD our ruler; the LORD our king; the LORD himself shall deliver us. 

#### Isaiah 33:23 {were torn Your rough cords}, for {does not have strength your mast}, it leans, it shall not let down the shrouds, it shall not lift a signal flag until of which time it should be delivered up for plunder; therefore many lame men {plunder shall cause}. 

#### Isaiah 33:24 And in no way shall {say I am tired the people dwelling in her}, {shall be forgiven for to them sin}. 

#### Isaiah 34:1 Lead forward, O nations, and hearken, O rulers! Hear, O earth and the ones {in it living}; O world, and the people in it! 

#### Isaiah 34:2 Because the rage of the LORD is upon all the nations, and his anger is upon their number, to destroy them and to deliver them up unto slaughter. 

#### Isaiah 34:3 And the slain ones of theirs shall be tossed forth, and the dead ones. And {of them shall ascend the scent}, and {shall be rained upon the mountains} by their blood. 

#### Isaiah 34:4 And {shall melt away all the powers of the heavens}. And {shall coil up the heaven} as a scroll, and all the stars shall fall as leaves fall from a grapevine, and as {fall leaves} from a fig-tree. 

#### Isaiah 34:5 For {was intoxicated my sword} in the heaven. Behold, {upon Edom it shall go down}, and upon the people of the destruction with judgment. 

#### Isaiah 34:6 The sword of the LORD was filled of blood thickened from the fat of lambs, and from the fat of he-goats and rams; for a sacrifice to God is in Bosor, and {slaughter a great} in Edom. 

#### Isaiah 34:7 And {shall be cast down the stout men} with them, and the rams and the bulls. And {will be intoxicated the earth} from the blood, even their embankment; and {of their fat they shall be filled up}. 

#### Isaiah 34:8 For it is a day of judgment of the LORD, and the year of recompense of judgment of Zion. 

#### Isaiah 34:9 And {shall be turned her ravines} into pitch; and her land into sulphur; and {will be her land in pitch burning} 

#### Isaiah 34:10 night and day; and it shall not be extinguished into the eon of time. And {shall ascend her smoke} upward; unto her generations she shall be made desolate, and for {time a long} she shall be made desolate. 

#### Isaiah 34:11 Birds, and hedgehogs, and ibises, and crows shall dwell in her; and {shall be put upon her cord a surveying of desolation}; and satyrs shall live in her. 

#### Isaiah 34:12 Her rulers will not be; for her kings and her great men will be for destruction. 

#### Isaiah 34:13 And {shall grow up in their cities thorny woods}, and also in her fortresses; and they will be properties of sirens, and a courtyard of ostriches. 

#### Isaiah 34:14 And {shall meet with demons} satyrs; and they shall yell another to the other; {there shall rest satyrs}, for they found for themselves a place of rest. 

#### Isaiah 34:15 {there shall nest The hedgehog}, and {preserved the earth} her children with safety; there stags meet together, and beheld the faces of one another. 

#### Isaiah 34:16 {in number They go by}, and {one of them not} perished; the other {the other did not seek}; for the LORD gave charge to them, and his spirit gathered them. 

#### Isaiah 34:17 And he shall cast lots for them, and his hand divided out parts to them to graze. Into the eon of time you shall inherit; for generations of generations shall rest upon it. 

#### Isaiah 35:1 Be glad, {wilderness O thirsting}! Exult, O wilderness, and bloom as a lily! 

#### Isaiah 35:2 And {shall blossom and exult the desolate places of the Jordan}. The glory of Lebanon was given to it, and the honor of Carmel. And my people shall see the glory of the LORD, and the stature of God. 

#### Isaiah 35:3 Be strong! O hands being forsaken, and knees being disabled. 

#### Isaiah 35:4 Take comfort! O faint-hearted in mind. Be strong! Do not fear! Behold, our God {judgment recompenses}, and he will recompense. He himself shall come, and he shall deliver us. 

#### Isaiah 35:5 Then shall {be opened the eyes of the blind}, and the ears of the deaf shall hear. 

#### Isaiah 35:6 Then {shall leap as a stag the lame}, and {will be plain the tongue of the stammering}; for {was torn forth in the wilderness water}, and a ravine in {land a thirsting}. 

#### Isaiah 35:7 And {will be the waterless place} turned into marshes, and {into the thirsting land} a spring of water. There will be there a gladness of birds, properties of reed and marshes. 

#### Isaiah 35:8 There will be there {way a pure}, and {way a holy it shall be called}; and in no way shall {pass by there anything unclean}; nor shall there be there {way an unclean}. But the ones having been scattered shall go upon it, and in no way shall they wander. 

#### Isaiah 35:9 And there will not be {there a lion}. Nor the ferocious wild beasts in any way shall ascend unto it, nor even should be found there. But {shall go in it the ones being ransomed}, 

#### Isaiah 35:10 even ones being gathered together by the LORD. And they shall return, and shall come to Zion with gladness; even {gladness eternal} is upon their head. For upon their head is praise and a leap for joy. And gladness shall overtake them; {ran away grief and distress and moaning}. 

#### Isaiah 36:1 And it came to pass the fourteenth year of the reigning of Hezekiah, {ascended Sennacherib king of the Assyrians} upon the {cities of Judea fortified}, and took them. 

#### Isaiah 36:2 And {sent the king of the Assyrians} Rabshakeh from Lachish unto Jerusalem to king Hezekiah with {force a great}. And he stood by the aqueduct of the {pool upper} in the way of the field of the fuller. 

#### Isaiah 36:3 And there came forth to him, Eliakim, the son of Hilkiah the manager, and Shebna the scribe, and Joah, the son of Asaph, the recorder. 

#### Isaiah 36:4 And {said to them Rabshakeh}, Speak to Hezekiah! Thus says the {king great}, the king of the Assyrians. What are you relying on? 

#### Isaiah 36:5 Does {by a plan with the words of the lips the battle take place}? And now, upon whom are you relying that you resist my persuasion? 

#### Isaiah 36:6 Behold, you are relying upon {rod of reed this fractured} -- upon Egypt; which if {should stay his weight a man} upon it, it shall enter into his hand, and shall puncture it. Thus is Pharaoh king of Egypt, and all the ones relying upon him. 

#### Isaiah 36:7 And if you should say, Upon the LORD our God we rely on. {not Is he} whom Hezekiah removed his high places, and his altars, and told Judah and Jerusalem, In front of this altar do obesiance now! 

#### Isaiah 36:8 But mix in with my master the king of the Assyrians, and I will give to you two thousand horses, if you are able to put riders upon them. 

#### Isaiah 36:9 And how are you all able to turn to the face of the toparchs? {our servants are The ones relying upon the Egyptians for a horse and rider}. 

#### Isaiah 36:10 And now, have {without the LORD we ascended} upon this place to wage war with it? The LORD said to me, Ascend upon this land, and utterly destroy it! 

#### Isaiah 36:11 And {said to him Eliakim and Shebna and Joah}, to Rabshakeh, Speak indeed to your servants in Syriac! for we hear ourselves; and do not speak to us in Jewish! For why do you speak unto the ears of the men standing upon the wall? 

#### Isaiah 36:12 And {said to them Rabshakeh}, Is it to your master, or to you {sent me my master} to speak these words? Is it not to the men, the ones sitting upon the wall, that they should eat their dung and drink their urine with you together? 

#### Isaiah 36:13 And Rabshakeh stood and yelled out {voice with a great} in Jewish, and said, Hearken to indeed the words of the {king great}, the king of the Assyrians! 

#### Isaiah 36:14 Thus says the king, Do not let {deceive you Hezekiah} with words! in no way shall he be able to rescue you. 

#### Isaiah 36:15 And do not let {say to you Hezekiah} that, {shall rescue you God}, and in no way shall {be delivered this city} into the hand of the king of the Assyrians. 

#### Isaiah 36:16 Do not hearken to Hezekiah! Thus says the king of the Assyrians, If you want to be blessed, come forth to me! and you shall {eat each} of his own grapevine and fig-trees, and shall drink water from out of his own well; 

#### Isaiah 36:17 until whenever I should come and should take you into a land as your land; a land of grain, and wine, and bread loaves, and vineyards. 

#### Isaiah 36:18 Let not {deceive you Hezekiah}! saying, God shall rescue us. Have {rescued the gods of the nations each} his own place from out of the hand of the king of the Assyrians? 

#### Isaiah 36:19 Where is the god of Hamath and Arpad? And where is the god of the city of Sepharvaim? Have they been able to rescue Samaria from out of my hand? 

#### Isaiah 36:20 Which of the gods of all these nations is the one who was rescued of his land from out of my hand, that {shall rescue the LORD} Jerusalem from out of my hand? 

#### Isaiah 36:21 And they kept silent, and no one answered him a word by the assignment of the king, saying, No one is to answer. 

#### Isaiah 36:22 And {entered Eliakim the son of Helkiah the manager}, and Shebna the scribe, and Joah, the son of Asaph the recorder, to Hezekiah, having split their inner garments. And they announced to him the words of Rabshakeh. 

#### Isaiah 37:1 And it came to pass in {hearing king Hezekiah}, that he split his garments, and put on sackcloth, and ascended unto the house of the LORD. 

#### Isaiah 37:2 And he sent Eliakim the manager, and Shebna the scribe (with the elders of the priests putting on sackcloths) to Isaiah son of Amoz the prophet. 

#### Isaiah 37:3 And they said to him, Thus says Hezekiah, A day of affliction, and scorning, and rebuke, and anger is today's day. For {come the pangs of giving birth}, {strength but she does not have} to give birth. 

#### Isaiah 37:4 If by any means {may listen to the LORD your God} the words of Rabshakeh, whom {sent the king of the Assyrians his master} to berate {God the living}, and to berate by the words which {heard the LORD your God}, therefore you shall make beseechment to the LORD your God concerning these being left. 

#### Isaiah 37:5 And {came the servants of king Hezekiah} to Isaiah. 

#### Isaiah 37:6 And {said to them Isaiah}, Thus you shall say to your master, Thus says the LORD, You should not be fearful of the words which you heard, which {berated me the ambassadors of the king of the Assyrians}. 

#### Isaiah 37:7 Behold, I shall put upon him a spirit, and hearing a message he shall return unto his place, and he shall fall by the sword in his land. 

#### Isaiah 37:8 And Rabshakeh returned, and overtook the king of the Assyrians while assaulting Libna, for he heard that he departed from Lachish. 

#### Isaiah 37:9 And there came forth Tirhakah king of the Ethiopians to assault him; and hearing he returned and sent messengers to Hezekiah, saying, 

#### Isaiah 37:10 Thus you shall say to Hezekiah king of Judea, Let not {deceive you your God}! upon whom you rely upon him, saying, In no way shall Jerusalem be delivered up into the hand of the king of the Assyrians. 

#### Isaiah 37:11 Behold, have you not heard what {did the kings of the Assyrians}, {the whole earth how they destroyed}? and shall you be rescued? 

#### Isaiah 37:12 Have {rescued them the gods of the nations} whom {destroyed my fathers}, both Gozan, and Haran, and Rezeph, which are in the place of Telassar? 

#### Isaiah 37:13 Where are the kings of Hamath? and where is Arphad? and where is the city Sepharvaim, Henah and Ivah? 

#### Isaiah 37:14 And Hezekiah took the scroll from the messengers, and read it. And he ascended into the house of the LORD, and opened it before the LORD. 

#### Isaiah 37:15 And Hezekiah prayed to the LORD, saying, 

#### Isaiah 37:16 O LORD of Hosts, God of Israel, the one sitting upon the cherubim. You are God alone of every kingdom of the world. You made the heaven and the earth. 

#### Isaiah 37:17 Lean, O LORD, your ear! Hearken, O LORD! Open, O LORD, your eyes! Look in, O LORD, and know and hear all the words of Sennacherib! which he sent to berate {God the living}. 

#### Isaiah 37:18 {in truth For}, O LORD, {made desolate the kings of the Assyrians} the {inhabitable world entire}, and their region. 

#### Isaiah 37:19 And they raised their idols unto the fire, {not for gods they were}, but works of the hands of men, wood and stones -- and they destroyed them. 

#### Isaiah 37:20 But now, O LORD our God, deliver us from out of his hand! that {should know every kingdom of the earth} that you are God alone. 

#### Isaiah 37:21 And {was sent Isaiah son of Amoz} to Hezekiah. And he said to him, Thus says the LORD God of Israel, I heard what you prayed to me concerning Sennacherib king of the Assyrians. 

#### Isaiah 37:22 This is the word which {spoke concerning him God}; {treated you as worthless and sneered at you The virgin daughter of Zion}; {against you her head shook the daughter of Jerusalem}. 

#### Isaiah 37:23 Whom did you berate and provoke? or, to whom did you raise up high your voice and lift {unto the height your eyes} against the holy one of Israel? 

#### Isaiah 37:24 For through messengers you berated the LORD. For you said, With the multitude of chariots I shall ascend unto the height of mountains, and into the ends of Lebanon; and I felled the height of its cedar, and the beauty of the cypress; and I entered unto the height of the portion of the forest; 

#### Isaiah 37:25 and I made a dam, and made desolate the waters and every gathering of water. 

#### Isaiah 37:26 Have you not heard these things {earlier which I did}? From {days ancient} I ordered it. But now I displayed to make {desolate nations in fortified places}, and the ones living in {cities fortified}. 

#### Isaiah 37:27 I weakened the hands, and they were dried up; and they became as {grass dry} upon the roofs, and as wild grass. 

#### Isaiah 37:28 But now {your rest and your exit and your entrance I know}, 

#### Isaiah 37:29 and your rage which you were enraged. And your bitterness ascended to me. And I will put a rein into your nose, and a bit into your lips, and I will return you in the way in which you came by it. 

#### Isaiah 37:30 And this {to you is the sign}, Eat this year what you have sown; and the {year second} the vestige left; and the third year, sow, and reap, and plant vineyards, and eat of their fruit! 

#### Isaiah 37:31 And they shall be the ones being left behind in Judea. They shall germinate a root below, and they shall produce grain upward. 

#### Isaiah 37:32 For from out of Jerusalem shall come forth the ones surviving, and the ones being preserved from out of mount Zion. The zeal of the LORD of Hosts shall do these things. 

#### Isaiah 37:33 Therefore thus says the LORD concerning the king of the Assyrians, In no way shall he enter into this city, nor throw {against it an arrow}, nor shall he put {against it a shield}, nor shall he encircle {against it a siege mound}. 

#### Isaiah 37:34 But in the way in which he came by it, he shall return; and {into this city in no way shall he enter}. Thus says the LORD. 

#### Isaiah 37:35 I will shield over this city to deliver it, because of myself and because of David my servant. 

#### Isaiah 37:36 And {came forth an angel of the LORD}, and he did away with the camp of the Assyrians -- a hundred eighty-five thousand. And rising up in the morning he found all the {bodies dead}. 

#### Isaiah 37:37 And he went forth returning. And {returned Sennacherib king of the Assyrians}, and lived in Nineveh. 

#### Isaiah 37:38 And while he did obeisance in the house of Nisroch his god, Adrammelech and Sharezer his sons struck him with swords; and they came through safe into Armenia. And {took reign Esar-haddon his son} instead of him. 

#### Isaiah 38:1 And it came to pass in that time Hezekiah was infirm unto death. And there came to him Isaiah son of Amoz the prophet; and he said to him, Thus says the LORD, Give orders concerning your house! {die for you}, and shall not live. 

#### Isaiah 38:2 And Hezekiah turned his face to the wall, and prayed to the LORD, 

#### Isaiah 38:3 saying, Remember, O LORD, as I was gone before you with truth, in {heart a true}, and the things pleasing before you I did. And Hezekiah wept {weeping with great}. 

#### Isaiah 38:4 And {came the word of the LORD} to Isaiah, saying, 

#### Isaiah 38:5 Go, and say to Hezekiah, Thus says the LORD, the God of David your father; I heard your prayer, and beheld your tears. Behold, I add to your time fifteen years. 

#### Isaiah 38:6 And from out of the hand of the king of the Assyrians I shall rescue you, and this city; and I shall shield over this city. 

#### Isaiah 38:7 And this {to you is the sign} from the LORD, that {will do God} this thing which he said. 

#### Isaiah 38:8 Behold, I shall turn the shadow of the stairs which {went down the ten stairs of the house of your father the sun}. I will return the sun the ten stairs which {went down the shadow}. 

#### Isaiah 38:9 The prayer of Hezekiah king of Judea when he was infirm and he rose up from his infirmity. 

#### Isaiah 38:10 I said in the height of my days, I shall go to the gates of Hades; I shall forsake the years remaining. 

#### Isaiah 38:11 I said, No longer in any way shall I behold the deliverance of God upon the land of the living. No longer in any way shall I behold a man with ones inhabiting. 

#### Isaiah 38:12 I failed my kin; I forsook the rest of my life; it departed and went forth from me as the one resting up {a tent pitching}. My spirit in me became as the web of one working in wool approaching to cut it off. 

#### Isaiah 38:13 In that day I was delivered over until morning. As a lion so he broke all my bones. For from the day until the night I was delivered over. 

#### Isaiah 38:14 As a swallow, so shall I call out, and as a dove, so shall I meditate. {failed For my eyes} to see into the height of the heaven, to the LORD who rescued me. 

#### Isaiah 38:15 And he removed {of my the grief} soul, and he acted. 

#### Isaiah 38:16 O LORD, {concerning this for} it was announced to you, and you awakened my breath, and being comforted I live. 

#### Isaiah 38:17 Behold, being in peace was bitter for me. For you took up my soul, that it should not perish; and you threw away {behind me all my sins}. 

#### Isaiah 38:18 {not For the ones in Hades shall} praise you; nor the ones dying shall bless you; nor shall {hope the ones in Hades} on your charity. 

#### Isaiah 38:19 The living shall bless you in which manner as I; for from today {children I shall produce} who shall announce your righteousness, 

#### Isaiah 38:20 O LORD of my deliverance; even I will not cease blessing you with the psaltery all the days of my life, before the house of God. 

#### Isaiah 38:21 And Isaiah said to Hezekiah, Take a dried cluster of figs, and grind them, and plaster with it, and {in health you will be}. 

#### Isaiah 38:22 And Hezekiah said, What is the sign that I shall ascend into the house of God. 

#### Isaiah 39:1 In that time {sent Merodach Baladan the son of Baladan the king of Babylonia} letters, and ambassadors, and gifts to Hezekiah; for he heard that he was infirm unto death, and was raised up. 

#### Isaiah 39:2 And {rejoiced over them Hezekiah joy with a great}. And he showed to them the house of the spices, and of the silver, and of the gold, and of the balsam, and of the incenses, and of the perfumed liquid, and all the houses of the items of the treasury, and all as much as was in his treasuries. And there was not one thing which {did not show to them Hezekiah} in his house. 

#### Isaiah 39:3 And {came Isaiah the prophet} to king Hezekiah, and he said to him, What did {say these men}? And from what place have they come to you? And Hezekiah said, From a land at a distance -- they have come to me from Babylon. 

#### Isaiah 39:4 And Isaiah said, What did they see in your house? And Hezekiah said, All the things in my house they beheld; and there is not anything in my house which they did not behold; but even the things in my treasuries. 

#### Isaiah 39:5 And Isaiah said to him, Hear the word of the LORD of Hosts! 

#### Isaiah 39:6 Behold, days come, and they shall take all the things in your house; even as much as {brought together your fathers} until this day -- {unto Babylon it shall come}, and not one thing in any way shall be left behind. {said and God}, 

#### Isaiah 39:7 that, Also of your children whom you engendered they shall take; and they shall be made castrati in the house of the king of the Babylonians. 

#### Isaiah 39:8 And Hezekiah said to Isaiah, {is good the word of the LORD} which you spoke; let there be indeed peace and righteousness in my days! 

#### Isaiah 40:1 Take comfort! take comfort! my people, says your God. 

#### Isaiah 40:2 O priests, speak to the heart of Jerusalem! Comfort her! for {was filled up her humiliation}; {is untied her sin}; for she received from the hand of the LORD double her sins. 

#### Isaiah 40:3 A voice yelling in the wilderness, Prepare the way of the LORD! {straight Make} the roads of our God! 

#### Isaiah 40:4 Every ravine shall be filled, and every mountain and hill shall be lowered; and {shall be all the crooked paths} for straight, and the rough into {plains smooth}. 

#### Isaiah 40:5 And {shall be seen the glory of the LORD}; and {shall see all flesh} the deliverance of God, for the LORD said it. 

#### Isaiah 40:6 A voice saying, Yell! And I said, What shall I yell? All flesh is as grass, and all glory of man is as the flower of grass. 

#### Isaiah 40:7 {is dried The grass}, and the flower fell off, for breath of God breathed in it. Truly the grass is the people. 

#### Isaiah 40:8 {is dried The grass}, the flower fell off, but the word of our God abides into the eon. 

#### Isaiah 40:9 {upon mountain the high Ascend}! O one announcing good news of Zion. Raise up high in the strength of your voice! O one announcing good news of Jerusalem. Raise it up high! Do not fear! Say to the cities of Judah! Behold, your God. 

#### Isaiah 40:10 Behold, the Lord. The LORD {with strength comes}, even the arm with dominion. Behold, his wage is with him, and the work before him. 

#### Isaiah 40:11 As a shepherd, he shall tend his flock; and his arm shall gather the lambs, and {one in the womb the one having he shall comfort}. 

#### Isaiah 40:12 Who measured {with the hand the water}, and the heaven with a span, and all the earth in a handful? Who established the mountains weight, and the groves in a yoke balance scale? 

#### Isaiah 40:13 Who knew the mind of the LORD? and who {his counselor became}? Who shall instruct him? 

#### Isaiah 40:14 Or whom did he take up advice with, and instructed him? Or who showed to him equity? Or {a way of understanding who showed to him}? 

#### Isaiah 40:15 Since all the nations {as a drop from a pail and as the crux of a yoke balance scale were considered}; and {as saliva they are considered}. 

#### Isaiah 40:16 And Lebanon is not fit for burning, and all the four-footed are not fit for a whole offering; 

#### Isaiah 40:17 and all the nations {as nothing are}, and {as nothing were considered} to him. 

#### Isaiah 40:18 To whom did you liken the LORD, and to what representation did you liken him? 

#### Isaiah 40:19 Has not {an image made the fabricator}? or the goldsmith having cast gold, gilt it over, {for a representation and carefully prepared it}? 

#### Isaiah 40:20 {wood For incorruptible chooses the fabricator}, and wisely seeks how to station his image, that it should not be shaken. 

#### Isaiah 40:21 Will you not know? Will you not hear? Was it not announced from the beginning to you? Did you not know the foundations of the earth? 

#### Isaiah 40:22 He is the one controlling the curve of the earth, and the ones dwelling in it are as locusts; He is the one establishing {as a vault the heaven}, and extending it out as a tent to dwell in; 

#### Isaiah 40:23 the one establishing rulers {as nothing to rule}; {the and earth as nothing he made}. 

#### Isaiah 40:24 For in no way shall they plant, nor shall they sow, nor shall they be rooted in the earth of their root. He breathed upon them, and they were dried up; and a blast {as sticks shall take them away}. 

#### Isaiah 40:25 Now then, to whom did you liken me that I shall be exalted, said the holy one? 

#### Isaiah 40:26 Look up into the height with your eyes, and behold! Who introduced all these things? The one bringing forth {by number his cosmos} {all things by name shall call} by great glory, and by the might of strength. Nothing of which you are unaware. 

#### Isaiah 40:27 {not For you should} say, O Jacob, and why did you speak, O Israel, saying, {was concealed My way} from God, and my God {judgment removed}, and departed. 

#### Isaiah 40:28 And now, did you not know? Have you not heard? {God the eternal}, the God carefully preparing the tips of the earth, he shall not hunger nor tire, nor is there a finding out of his intelligence; 

#### Isaiah 40:29 giving {to the ones hungering strength}, and {to the ones not grieving distress}. 

#### Isaiah 40:30 {shall hunger For younger men}, and {shall tire the young}, and the chosen men {without strength will be}. 

#### Isaiah 40:31 But the ones waiting upon God shall change in strength; they shall grow wings as eagles; they shall run and shall not tire; they shall proceed and shall not hunger. 

#### Isaiah 41:1 Dedicate a feast to me, O islands, for the rulers shall change strength. Let them approach and speak together, then {judgment let them announce}! 

#### Isaiah 41:2 Who awakened {from the east righteousness}, called it by his feet, and it shall go? He shall appoint against nations, and {kings he shall recede}, and he shall put {into the earth their swords}, and {as sticks being pushed out their bows}. 

#### Isaiah 41:3 And he shall pursue them; {shall go through in peace the way of his feet}. 

#### Isaiah 41:4 Who exerted energy and did these things? He called her -- the one calling her from {of generations the beginning}; I God, the first and into the coming, I am. 

#### Isaiah 41:5 {beheld Nations} and they feared; the tips of the earth are startled; they approached and came together, 

#### Isaiah 41:6 judging each for the neighbor, and {for the brother helping}; and shall say, 

#### Isaiah 41:7 {was strong The man} -- the fabricator, and the brazier beating with a hammer {together forging}; how long then shall he say, The coupling is good, they strengthened them with nails; they shall establish them, and it shall not be moved. 

#### Isaiah 41:8 But you, O Israel my servant, Jacob whom I chose, seed of Abraham whom I loved; 

#### Isaiah 41:9 whom I took hold of from the uttermost parts of the earth; and from out of its heights I called you; and I said to you, {servant You are my}; I chose you, and I did not abandon you. 

#### Isaiah 41:10 Do not fear! {with you for I am}. Do not wander! for I am your God; the one strengthening you, and I will give help to you, and safeguard you {right hand by my just}. 

#### Isaiah 41:11 Behold, {shall be ashamed and shall be respectful all your adversaries}, for they will be as not existing; and {shall perish all your opponents}. 

#### Isaiah 41:12 You shall seek them, and in no way shall you find the men who shall insult while drunk with wine against you; for they shall be as ones not being; and {shall not be the ones waging war against you}. 

#### Isaiah 41:13 For I am your God, the one holding your right hand, the one saying to you, 

#### Isaiah 41:14 Do not fear, O Jacob, O Israel, very few in number! I gave help to you, says your God, the one ransoming you, O Israel. 

#### Isaiah 41:15 Behold, I made you as wheels of a wagon threshing -- new, toothed; and you shall thresh the mountains, and shall thin out the hills, and {as dust make them}. 

#### Isaiah 41:16 And you shall winnow them, and a wind shall take them, and the gale shall scatter them. But you shall be glad among the holy ones of Israel. 

#### Isaiah 41:17 And {will exult the poor and the ones lacking}; for they shall seek water and none will be; their tongue {from the thirst was dried up}. I the LORD shall heed, the God of Israel, and I will not abandon them. 

#### Isaiah 41:18 But I will open {upon the mountains rivers}, and {in the midst of plains springs}; I will make the wilderness into marshes of waters, and the thirsting ground in aqueducts. 

#### Isaiah 41:19 I will put into the waterless earth the cedar and boxwood, and myrtle, and cypress, and white poplar; 

#### Isaiah 41:20 that they should behold, and should know, and should reflect on, and should have knowledge of together that the hand of the LORD did these things, and the holy one of Israel introduced them. 

#### Isaiah 41:21 {approaches Your judgment}, says the LORD God; {approached your counsels}, says the king of Jacob. 

#### Isaiah 41:22 Let them approach and announce to you! what shall come to pass, or the things prior to what it was you said. And we will attend our mind, and we shall know what the last things and the ones coming are. 

#### Isaiah 41:23 Tell to us! announce the things coming at the latter end! and we shall know that you are gods. {good Do} and do evil! and we shall wonder, and we shall see at the same time; 

#### Isaiah 41:24 for from what place you are, and from what place your work is from; {out of the earth an abomination they chose you}. 

#### Isaiah 41:25 But I raised up the one from the north, and the one from the sun eastward; they shall be called by my name; let {come the rulers}! and as clay of a potter, and as a potter trampling down the clay, so you shall be trampled. 

#### Isaiah 41:26 For who shall announce the things from the beginning, that we should know also the things happening before, and we shall say that they are true? There is not the one speaking beforehand, nor one hearing your words. 

#### Isaiah 41:27 {sovereignty to Zion I will give}, and I will comfort Jerusalem in the way. 

#### Isaiah 41:28 For from the nations, behold, there was no one; and from their idols there was not one announcing. And if I should ask them, From what place are you? in no way should they answer me. 

#### Isaiah 41:29 For they are the ones making you, so you say, and in folly ones misleading you. 

#### Isaiah 42:1 Jacob, my child, I shall take hold of him. Israel, my chosen, {favorably received him my soul}. I have put my spirit upon him, {judgment to the nations he shall bring forth}. 

#### Isaiah 42:2 He shall not cry out, nor shall he send up his voice, nor shall {be heard outside his voice}. 

#### Isaiah 42:3 A reed being crushed he will not break, and {flax smoking} he will not extinguish; but to validity he will bring forth judgment. 

#### Isaiah 42:4 He shall illuminate, and shall not be devastated until whenever he should set {upon the earth judgment}. And upon his name nations shall hope. 

#### Isaiah 42:5 Thus says the LORD God, the one making the heaven, and pitching it; solidifying the earth, and the things in it; and giving breath to the people upon it, and spirit to the ones treading it. 

#### Isaiah 42:6 I the LORD God called you in righteousness, and I shall hold your hand, and I will strengthen you; and I gave you for a covenant of a race, for a light of nations; 

#### Isaiah 42:7 to open the eyes of the blind, to lead out of bonds ones being tied; from out of the house of prison also ones sitting in darkness. 

#### Isaiah 42:8 I am the LORD God; this is my name; {my glory to another I will not give}, nor my virtues to the carvings. 

#### Isaiah 42:9 The things from the beginning, behold, they have come, and the new things which I shall announce, even before the announcing, it was made manifest to you. 

#### Isaiah 42:10 Sing to the LORD {hymn a new}! Glorify his name from the uttermost part of the earth! O ones going down into the sea, and sailing it; the islands, and the ones dwelling in them. 

#### Isaiah 42:11 Be glad, O wilderness and her towns, properties, and the ones dwelling in Kedar! {shall be glad The ones dwelling in the rock}. From the tip of the mountains they shall yell. 

#### Isaiah 42:12 They shall give {to God glory}; {his virtues in the islands they shall report}. 

#### Isaiah 42:13 The LORD God of the forces shall go forth, and shall break war. He shall rouse zeal, and shall yell against his enemies with strength. 

#### Isaiah 42:14 I kept silent from the eon; shall I also continually keep silent and endure? As the woman giving birth perseveres, I will now amaze and dry out at the same time. 

#### Isaiah 42:15 I will make {desolate mountains and hills}, and {all their grass will dry out}. And I will make rivers into islands, and marshes to dry land. 

#### Isaiah 42:16 And I will lead the blind in the way which they knew not, and {roads which they had not seen to tread I will cause them}. I will make for them darkness into light, and crooked into straight. These are the things I will do to them, and I shall not abandon them. 

#### Isaiah 42:17 But they were turned into the rear. You should be ashamed with shame, O ones relying upon the carvings, O ones saying to the molten images, You are our gods. 

#### Isaiah 42:18 O deaf-mutes, hear! and O blind, look up to behold! 

#### Isaiah 42:19 And who is blind, but my servants? And who are deaf-mutes, but the ones dominating them? Who is blind as the one receiving? even {were blinded the servants of God}. 

#### Isaiah 42:20 You beheld many times, and watched not; opening the ears, and heard not. 

#### Isaiah 42:21 The LORD God willed that he should be justified, and should magnify praise. 

#### Isaiah 42:22 And I beheld, and it came to pass the people were being despoiled and plundered; for the snare is in the storerooms everywhere, and in the houses together where they hid them; they became for plunder, and there was not the one rescuing one seized; and there was not the one saying, Give back! 

#### Isaiah 42:23 Who among you shall give ear to these things which shall be heard for the things coming about? 

#### Isaiah 42:24 Who gave {for ravaging Jacob}, and Israel to the ones plundering? Was it not God to whom they sinned? And they did not want {in his ways to go}, nor to hear his law. 

#### Isaiah 42:25 And he brought upon them the anger of his rage; and {strengthened against them the war} and the ones burning them round about; and {did not know each of them}, nor put it unto their soul. 

#### Isaiah 43:1 And now, thus says the LORD God, the one making you, O Jacob, and the one shaping you, O Israel, Do not fear! for I ransomed you, I called you by your name, {mine are you}. 

#### Isaiah 43:2 And if you should pass over through water, {with you I am}; and rivers shall not engulf you. And if you go through fire, in no way should you be incinerated; a flame shall not incinerate you. 

#### Isaiah 43:3 For I am the LORD your God, the holy one of Israel, the one delivering you. I made a barter for you -- Egypt, and Ethiopia, and Seba for you. 

#### Isaiah 43:4 From which time {valuable you were esteemed} before me, you were glorified, and I loved you. And I will give men for you, and rulers for your head. 

#### Isaiah 43:5 Do not fear, for {with you I am}! From the east I will lead your seed, and from the west I will bring you together. 

#### Isaiah 43:6 I will say to the north, Bring! and to the south, Do not restrain! Bring my sons from a land at a distance, and my daughters from uttermost parts of the earth, 

#### Isaiah 43:7 even all, as many as have been called upon to my name. For in my glory I carefully prepared him, and I shaped him, and I made him. 

#### Isaiah 43:8 And I brought out {people a blind}, and the eyes are likewise blind; and deaf ones {the ears having}. 

#### Isaiah 43:9 All the nations were brought together, and {shall be brought together rulers from them}. Who will announce these things? Or the things from the beginning, who will announce? Let them bring forth their witnesses, and let them be justified, and let them hear, and let them speak truth! 

#### Isaiah 43:10 Be witnesses to me! and I witness, says the LORD God, and my servant whom I chose. That you should know, and should trust, and should perceive that I am. Before me {did not exist another God}, and after me it will not be. 

#### Isaiah 43:11 I am God, and {there is no besides me} one delivering. 

#### Isaiah 43:12 I announced it, and I delivered. I berated, and there was not among you an alien god. You are to me witnesses, and I am the LORD God, 

#### Isaiah 43:13 even from the beginning; and there is not one {from my hands taking}. I will do, and who shall turn it? 

#### Isaiah 43:14 Thus says the LORD God, the one ransoming you, the holy one of Israel. Because of you I will send unto Babylon, and I will rouse {the ones fleeing all}, and the Chaldeans {in boats shall be tied}. 

#### Isaiah 43:15 I am the LORD God, your holy one, the one introducing for Israel your king. 

#### Isaiah 43:16 For thus says the LORD, the one making {in the sea a way}, and {in water strong a path}; 

#### Isaiah 43:17 the one leading chariots and horse, and {multitude a mighty}; but they were gone to sleep, and they shall not rise up; they were extinguished as a flax being extinguished. 

#### Isaiah 43:18 Do not remember the first things, and the ancient things do not reckon together! 

#### Isaiah 43:19 Behold, I do new things which now shall arise, and you all shall know them. And I will make {in the wilderness a way}, and {in the waterless place rivers}. 

#### Isaiah 43:20 {shall bless me The wild beasts of the field}, sirens and daughters of ostriches; for I established {in the wilderness water}, and rivers in the waterless place, to give to drink to {race my chosen}, 

#### Isaiah 43:21 my people whom I procured; the ones {my virtues to describe}. 

#### Isaiah 43:22 Not now I called you, O Jacob, nor {to tire you acted}, O Israel. 

#### Isaiah 43:23 You did not bring to me of your sheep, of the one of your whole offering; nor in your sacrifices you glorified me. You were not enslaved in sacrifices, nor {weary did you} with frankincense. 

#### Isaiah 43:24 Nor you acquired for me a sacrifice of silver, nor the fat of your sacrifices I desired. But in your sins you stood in front of me, and in your iniquities. 

#### Isaiah 43:25 I am, I am he, the one wiping away your lawless deeds because of me, and your sins in no way shall I remember. 

#### Isaiah 43:26 But you, remember! And let us plead together! You tell of your lawless deeds first! that you should be justified. 

#### Isaiah 43:27 Your fathers first sinned, and your rulers acted lawlessly against me. 

#### Isaiah 43:28 And {defiled the rulers} my holy things; and I gave Jacob up to be destroyed, and Israel for scorning. 

#### Isaiah 44:1 But now hear! O Jacob my child, and O Israel, whom I chose. 

#### Isaiah 44:2 Thus says the LORD God, the one creating you, and shaping you from the belly. You shall still be helped. Do not fear! {my servant O Jacob}, and the one being loved, Israel whom I chose. 

#### Isaiah 44:3 For I will give water for thirst to the ones going in a waterless place. I will place my spirit upon your seed, and my blessings upon your children. 

#### Isaiah 44:4 And they shall rise up as {in the midst of water grass}, and as willows upon {flowing by water}. 

#### Isaiah 44:5 This one shall say I am of God. And this one shall call himself by the name of Jacob. And another shall inscribe with his hand, I am of God. And {by the name Israel he shall call himself}. 

#### Isaiah 44:6 Thus says God, the king of Israel, and the one rescuing him -- the God of Hosts. I am first, and I am after these things; besides me there is no God. 

#### Isaiah 44:7 Who is as I? Let him stand, and call, and announce, and prepare for me from which time I made man into the eon! And the things coming before their coming to pass let them announce to you! 

#### Isaiah 44:8 Do not cover up yourselves, nor wander! Have you not from the beginning given ear, and I reported it to you? {witnesses You are} if there is a God besides me. 

#### Isaiah 44:9 And they were not hearkening then, the ones shaping and carving all the vain idols, doing their wishes which do not benefit them. But {their own witnesses they are}. They shall not see, and they shall not know, that they should be ashamed -- he who shapes mighty and a carved molten casting for unprofitable things. Behold, all the ones partaking with him shall be ashamed -- 

#### Isaiah 44:10 the ones shaping a god, and all the ones carving unprofitable things. 

#### Isaiah 44:11 And all from where they came from were dried up. Yes, {the deaf-mutes of men let be brought together all}, and let them stand together, and let them feel remorse, and let them be ashamed together! 

#### Isaiah 44:12 For {sharpens the fabricator} the iron tool. With a hammer he works it in coals, and with a drill he sets it. And he works it with the arm of his strength. And he shall hunger and be weak, and in no way shall he drink water. 

#### Isaiah 44:13 {having chosen The fabricator} a piece of wood sets it with a measure, and forms it with a scraper. He made it with a carpenter's square, and with glue he composes it. And he made it as the appearance of a man, and as the beauty of man he sets it in a niche; 

#### Isaiah 44:14 in which he fells {for himself cedars}, and he takes the holm oak and the oak; and he strengthened for himself the tree from the grove which the LORD planted -- a pine; and the rain lengthened it, 

#### Isaiah 44:15 that it might be for men to burn. And taking of it he warms himself, and in burning they bake bread loaves upon it; and with the remaining he works out gods, and does obeisance to them. He made it a carved idol, and he bends to them; 

#### Isaiah 44:16 of which the half of it he incinerates in fire, and upon the half of it {meat he ate} -- roasting he roasted a roast, and he was filled up. And heating himself he said, It is agreeable to me, for I was heated, and I beheld a fire. 

#### Isaiah 44:17 And the rest he makes into {god a carved}; he bends to it and does obeisance, and prays to it, saying, Deliver me, for {my god your are}! 

#### Isaiah 44:18 They do not know to think, for they were blurred to see with their eyes, and to comprehend with their heart. 

#### Isaiah 44:19 And he considered not in his soul, nor knew in intellect that the half of it he incinerated by fire, and baked {upon its coals bread loaves}, and {roasting meat ate}; and the rest of it {into an abomination he made}. And they do obeisance to it. 

#### Isaiah 44:20 Know that {is ashes their heart}! and they err, and no one is able to rescue his soul. Behold! you shall not say that, Is there a lie in my right hand? 

#### Isaiah 44:21 Remember these things, O Jacob and Israel! for {my servant are you}; I shaped you to be my servant. And you, O Israel, do not forget me! 

#### Isaiah 44:22 Behold, I wiped away {as a cloud your lawless deeds}, and {as dimness your sin}. Turn to me! and I shall ransom you. 

#### Isaiah 44:23 Be glad, O heavens! for {showed mercy the God of Israel}. Trump, O foundations of the earth! Yell out, O mountains in gladness, O hills, and all the trees in them! for {ransomed the LORD} Jacob, and Israel shall be glorified. 

#### Isaiah 44:24 Thus says the LORD, the one ransoming you, and the one shaping you from the belly, I am the LORD, the one completing all things. I stretched out the heaven alone, and solidified the earth. 

#### Isaiah 44:25 Who other shall efface the signs of the ones who deliver oracles, and divinations from the heart; to turn the intelligent ones unto the rear, and their counsel being moronish; 

#### Isaiah 44:26 and establishing the discourse of his servant, and {the counsel of his messengers verifying}; the one saying to Jerusalem, You shall be inhabited; and to the cities of Judea, You shall be built, and her desolate places I shall raise up. 

#### Isaiah 44:27 The one saying to the deep, You shall be made desolate, and {your rivers I will dry up}. 

#### Isaiah 44:28 The one telling Cyrus, Think, and all my wants he will do; the one saying to Jerusalem, You shall be built, and {house of my holy I shall lay the foundation}. 

#### Isaiah 45:1 Thus says the LORD God to my anointed Cyrus, whose {I held right hand}, {to heed before him for nations}; and the strength of kings I will tear up; I will open {before him doors}, and gates shall not be closed up. 

#### Isaiah 45:2 I {before you will go}, and {mountains I shall level}. {the doors of brass I shall break}, and bars of iron I break in pieces. 

#### Isaiah 45:3 And I shall give to you treasures -- obscure, concealed, unseen. I will open to you that you should know that I am the LORD your God, the one calling your name, the God of Israel. 

#### Isaiah 45:4 Because of my servant Jacob, and Israel my chosen, I shall call you by your name, and favorably receive you; though you did not know me. 

#### Isaiah 45:5 For I am the LORD God, and there is not yet besides me -- there is not a god. I strengthened you, and you did not know me; 

#### Isaiah 45:6 that {should know the ones from the east sun and the ones from the west} that there is not one besides me. I am the LORD God, and there is not any more. 

#### Isaiah 45:7 I am the one carefully preparing light, and I made darkness; the one making peace, and the one creating bad things. I am the LORD God, the one doing all these things. 

#### Isaiah 45:8 Let {be glad the heaven above}, and {the clouds let} sprinkle righteousness! Let {arise the earth}, and burst forth mercy! And let righteousness burst forth together! I am the LORD, the one creating you. 

#### Isaiah 45:9 What made better mortar of a potter? Will the one plowing plow the earth the entire day? Will {say the mortar} to the potter, What do you do that you do not work, nor have hands? 

#### Isaiah 45:10 Woe the one saying to the father, Why shall you engender me? and to the mother, Why shall you travail? 

#### Isaiah 45:11 For thus says the LORD God, the holy one of Israel, the one making the coming things, Ask me concerning my sons. And concerning the works of my hands, shall you give charge to me! 

#### Isaiah 45:12 I made the earth, and man upon it. I {by my hand solidified the heaven}. I {to all the stars gave charge}. 

#### Isaiah 45:13 I raised him with righteousness as king, and all his ways are straight. He shall build my city, and the captivity of my people he shall return. Not by ransoms, nor by gifts, said the LORD of Hosts. 

#### Isaiah 45:14 Thus says the LORD of Hosts, Egypt tired for you, and the trade of the Ethiopians and the Sabeans, {men haughty over you shall pass}, and they will be your servants; and {after you they shall follow} being tied in manacles, and they shall pass over to you, and shall do obeisance to you, and {to you they shall pray}, for {among you God is}, and there is no God besides you. 

#### Isaiah 45:15 For you are God, and we did not know -- God of Israel, the deliverer. 

#### Isaiah 45:16 {shall be ashamed and shall feel remorse all the ones being an adversary to him}; and they shall go in shame. Be dedicated to me, O islands. 

#### Isaiah 45:17 Israel is delivered by the LORD {deliverance with an eternal}; they shall not be ashamed, nor should they feel remorse unto the eon still. 

#### Isaiah 45:18 For thus says the LORD, the one making the heaven, this God, the one introducing the earth and making it; he separated it, {not empty he did make it}, but {to dwell in he shaped it}; I am the LORD, and there is none beside. 

#### Isaiah 45:19 {not in secret I have spoken}, nor in a place of the earth that is dark. I did not tell to the seed of Jacob, {a vain thing Seek}! I am the LORD, the one speaking righteousness, and announcing truth. 

#### Isaiah 45:20 Gather together and come! Consult together! O ones being delivered from the nations. They are not knowing, the ones lifting {wood carving their}, and praying to a god which does not deliver. 

#### Isaiah 45:21 The ones that shall announce, let them approach that they should know together, who audibly did these things. From the beginning from then it was announced to you. Am I not the LORD God? There is no other besides me -- just and a deliverer. There is none besides me. 

#### Isaiah 45:22 Turn unto me! and you shall be delivered, O ones from the end of the earth. I am God, and there is no other. 

#### Isaiah 45:23 According to myself I swear by an oath, that {shall come forth from out of my mouth righteousness}; my words shall not be perverted. For {shall bend to me every knee}, and {shall swear by an oath every tongue} by God, 

#### Isaiah 45:24 saying, Righteousness and glory {to him shall come}; and {shall be ashamed all the ones of them being separated from the LORD}. 

#### Isaiah 45:25 They shall be justified, and in God they shall be glorified -- all the seed of the sons of Israel. 

#### Isaiah 46:1 Bel fell, Dagon was broken. {became Their carved images} for the wild beasts; and cattle lift them being bound for a load, tiring, fainting, 

#### Isaiah 46:2 and hungering, not being able together; the ones who are not able to be delivered from war; but they themselves {as captives are led away}. 

#### Isaiah 46:3 Hear me, O house of Jacob, and all the rest of Israel! O ones being lifted from the belly, and being corrected from childhood 

#### Isaiah 46:4 until old age; I am, and until whenever you should become aged, I am. I endure you. I made, and I shall spare. I shall take up and I shall deliver you. 

#### Isaiah 46:5 To whom do you liken me? Behold cunningly contrive, O misleading ones! 

#### Isaiah 46:6 And the ones uniting in gold from a money bag, and silver in a yoke balance scale shall establish by weight; and ones hiring a goldsmith made handmade idols, and bowing they do obeisance to it. 

#### Isaiah 46:7 They lift it upon the shoulder, and they go. And if they put it upon its place, it remains. In no way shall it move, and who ever should yell to it, in no way shall it listen; {from hurt in no way shall it deliver him}. 

#### Isaiah 46:8 Remember these things and moan! Change your mind, O ones being misled! Turn in heart! 

#### Isaiah 46:9 Remember the things prior from the eon! For I am God, and there is no other besides me; 

#### Isaiah 46:10 announcing formerly the last things before their taking place, and are completed. And I said, All my counsel will stand, and all as much as I have planned I will do; 

#### Isaiah 46:11 calling {from the east the winged creature}, and from a land at a distance, for the things which I have planned. And indeed I spoke, and indeed I led. I created and I did. I led him, and I prospered his way. 

#### Isaiah 46:12 Hear me, O ones destroying the heart! O ones far from righteousness. 

#### Isaiah 46:13 I brought near my righteousness, in no way is it at a distance, and the deliverance the one by me, I will not be slow about; I have appointed in Zion deliverance to Israel for glory. 

#### Isaiah 47:1 Go down, sit upon the ground, O virgin daughter of Babylon, sit on the ground! There is no throne, O daughter of the Chaldeans. For no longer shall you be added to be called tender and delicate. 

#### Isaiah 47:2 Take a millstone! Grind flour! Uncover your face covering! Expose the gray hairs! Uncover the legs! Be passed over the rivers! 

#### Isaiah 47:3 {shall be uncovered Your shame}; {shall be shone forth your scornings}; {the just one from you I will take}; no longer shall I deliver up to men. 

#### Isaiah 47:4 The one rescuing you -- the LORD of Hosts is his name, the holy one of Israel. 

#### Isaiah 47:5 Sit being vexed! Enter into the darkness, O daughter of the Chaldeans! No longer should you be called, the strength of a kingdom. 

#### Isaiah 47:6 I was provoked by my people. You defiled my inheritance. I gave them into your hand, but you did not grant {to them mercy}. {the old man You oppressed} by the yoke exceedingly. 

#### Isaiah 47:7 And you said, {into the eon I will be ruling}. You comprehended not these things in your heart, nor remembered the latter end. 

#### Isaiah 47:8 But now hear these things! O delicate one, O one sitting down, O one yielding. O one saying in her heart, I am, and there is not another; I shall not sit as a widow, nor shall I know bereavement. 

#### Isaiah 47:9 But now {shall come upon you these two things} suddenly in {day one}; childlessness and widowhood shall come suddenly upon you in your sorcery, in the strength of your enchantments -- exceedingly. 

#### Isaiah 47:10 In the hope of your wickedness, for you said, I am, and there is not another. Know that the understanding of these things and your harlotry {to you will be shame}! For you said in your heart, I am, and there is not another. 

#### Isaiah 47:11 And {shall come upon you destruction}. And in no way shall you know a cesspool is there, and you shall fall into it. And {shall come upon you misery}, and in no way shall you be able {clean to be}. And {shall come upon you suddenly destruction}, and in no way shall you know. 

#### Isaiah 47:12 Stand now! with your enchantments, and in the abundance of your sorcery! which you learned from your youth -- if you shall be able to derive benefit. 

#### Isaiah 47:13 You are tired in your counsels. Let {stand indeed and deliver you the astrologers of the heaven}! {the ones seeing the stars let} announce to you what is about to come upon you! 

#### Isaiah 47:14 Behold, all are as sticks upon a fire, they shall be incinerated, and in no way shall they rescue their soul from out of the flame. For you shall have coals of fire to sit by them; 

#### Isaiah 47:15 these shall be your help. You tired in the revolt from your youth. A man {by himself wanders}, but to you there will be no deliverance. 

#### Isaiah 48:1 Hear these things, O house of Jacob! the ones being called by the name Israel, and {from waters of Judah coming forth}, the ones swearing by an oath to the name of the LORD God of Israel, ones remembering not with truth, nor with righteousness, 

#### Isaiah 48:2 and ones holding to the name of the {city holy}, and {upon the God of Israel taking support}; the LORD of Hosts is his name. 

#### Isaiah 48:3 The former things again I announced, and from out of my mouth it came forth, and audibly it happened. Suddenly I did, and it came about. 

#### Isaiah 48:4 I know that you are hardened, and {is a nerve of iron your neck}, and your forehead is as brass. 

#### Isaiah 48:5 And I announced to you earlier what would happen before it came upon you. Audibly to you I did it, lest at some time or other you should say that, My idols did. And you should say that, The carvings and the molten images gave charge to me! 

#### Isaiah 48:6 You heard all, and you knew not. But even audibly {to you I committed} the new things from the present which are about to take place, and you spoke not. 

#### Isaiah 48:7 Now it takes place, and not earlier; and not in former days, and {not you heard them}. Lest you should say, Yes, I know them. 

#### Isaiah 48:8 Neither you knew, nor were knowing of, nor from the beginning when I opened your ears; for I knew that in disregarding you shall disregard, and {lawless even from out of the belly you would be called}. 

#### Isaiah 48:9 Because of my name I will show to you my rage, and {my noble deeds I will bring} upon you, that I should not utterly destroy you. 

#### Isaiah 48:10 Behold, I have bartered you, not for silver; and I rescued you from out of the furnace of poorness. 

#### Isaiah 48:11 Because of myself I will do, for my name is being profaned; and my glory {to another I will not give}. 

#### Isaiah 48:12 Hear me, O Jacob, and Israel whom I call! I am first, and I am into the eon. 

#### Isaiah 48:13 And my hand laid the foundation for the earth, and my right hand solidified the heaven. I will call them, and they shall stand together. 

#### Isaiah 48:14 And all shall be brought together, and they shall hear. Who announced to them these things? In loving you, I did your will against Babylon, to lift away the seed of the Chaldeans. 

#### Isaiah 48:15 I spoke, and I called. I brought him, and I prospered his way. 

#### Isaiah 48:16 Lead forward to me, and hear these things! {not from the beginning in secret I have spoken}. When it took place, {there I was}. And now the Lord, the LORD, he sent me and his spirit. 

#### Isaiah 48:17 Thus says the LORD, the one rescuing you, the holy one of Israel, I am the LORD your God. I have shown to you how to find the way in which you shall go by it. 

#### Isaiah 48:18 And if you hearkened to my commandments, {would have been as a river your peace}, and your righteousness as a wave of the sea; 

#### Isaiah 48:19 and {would have become even as sand your seed}, and the progeny of your belly as dust of the earth; nor now in any way shall you be utterly destroyed, nor shall {be destroyed your name} before me. 

#### Isaiah 48:20 Come forth from out of Babylon, O one fleeing from the Chaldeans! With a voice of gladness announce it, and audibly let this be made known! Report unto the end of the earth! Say! The LORD rescued his servant Jacob. 

#### Isaiah 48:21 And if they should thirst, {through the wilderness he will lead them}; {water from the rock he shall bring forth} to them; {shall be split the rock} and shall flow water, and {shall drink my people}. 

#### Isaiah 48:22 There is no rejoicing, says the LORD, to the impious. 

#### Isaiah 49:1 Hear, O islands! and take heed, O nations! Through {time a long} it shall be established, says the LORD. From out of the belly of my mother he called my name. 

#### Isaiah 49:2 And he made my mouth as {sword a sharp}, and under the protection of his hand he hid me. He made me as {arrow a chosen}; and in his quiver he hid me. 

#### Isaiah 49:3 And he said to me, {my servant You are}, O Israel, and in you I shall be glorified. 

#### Isaiah 49:4 And I said, Uselessly I tired in vain, and for nothing I gave my strength. On account of this my judgment is from the LORD, and my toil before my God. 

#### Isaiah 49:5 And now, thus says the LORD, the one shaping me from out of the belly, {servant to be his own}, to gather Jacob to him, And Israel I shall have gathered, and I shall be glorified before the LORD, and my God will be my strength. 

#### Isaiah 49:6 And he said, {a great thing for you It is} to be called my servant; to establish the tribes of Jacob, and {the dispersion of Israel to return}. Behold, I have given you for a covenant of a race, for a light of nations, for you to be for deliverance unto the end of the earth. 

#### Isaiah 49:7 Thus says the LORD, the one rescuing you, the God of Israel, Sanctify the one treating {as worthless his life}, the one being abhorred by the nations of the servant of the rulers. Kings shall see him, and {shall rise up rulers}, and they shall do obeisance to him because of the LORD; for {is trustworthy the holy one of Israel}, and I chose you. 

#### Isaiah 49:8 Thus says the LORD, {time In the accepted} I heeded you, and in the day of deliverance I helped you, and I shaped you, and I gave you for a covenant of nations, to establish the earth, and to inherit {inheritances desolate}. 

#### Isaiah 49:9 Saying to the ones in bonds, Come forth! and to the ones in the darkness to be uncovered. In all the ways they shall be grazing, even in all the roads of their pasture. 

#### Isaiah 49:10 They shall not hunger nor thirst, nor shall {strike them a burning wind}, nor sun. But the one who shows mercy on them shall comfort them, and by springs of waters he shall lead them. 

#### Isaiah 49:11 And I will establish every mountain for a way, and every road for a pasture to them. 

#### Isaiah 49:12 Behold, these {from a distance shall come}; these from north, and west, and others from out of the land of the Persians. 

#### Isaiah 49:13 Be glad, O heavens, and exult, O earth! Break asunder, O mountains, with gladness! for {showed mercy on God} his people, and the humble of his people he comforted. 

#### Isaiah 49:14 Zion said, {abandoned me The LORD}, and, {Lord forgot My}. 

#### Isaiah 49:15 Shall {forget a woman} her child, or to not show mercy on on the progeny of her belly? But even if {these things might forget a woman}, I will not forget you, says the LORD. 

#### Isaiah 49:16 Behold, upon my hands I portrayed your walls; and {before me you are always}. 

#### Isaiah 49:17 And quickly you shall be built by whom you were demolished; and the ones making you desolate shall go forth from out of you. 

#### Isaiah 49:18 Lift up round about your eyes, and perceive all! Behold, they were brought together, and they come to you. As I live, says the LORD, that, {them all as an ornament You shall clothe yourself with}, and you shall put them on as an ornament of a bride. 

#### Isaiah 49:19 For your desolate places, and the places utterly destroyed, and the places having fallen down, that now they shall be confining because of the ones dwelling, and {will be far from you the ones swallowing you down}. 

#### Isaiah 49:20 {shall say For in your ears your sons whom you have lost}, {is too narrow for me The place}, make for me a place that I shall dwell! 

#### Isaiah 49:21 And you shall say in your heart, Who engendered to me these? For I am childless and a widow, a sojourner and excluded. But these, who nourished for me? For I was left alone. But these {to me from where were these}? 

#### Isaiah 49:22 Thus says the Lord, the LORD, Behold, I lift {unto the nations my hand}, and unto the islands I shall lift my agreed upon sign. And they shall lead your sons in their bosom; and {your daughters upon their shoulders they shall lift}. 

#### Isaiah 49:23 And {shall be kings} your wet-nurses; and their ruling women your nurses. {upon the face of the earth They shall do obeisance to you}, and the dust of your feet they shall lick. And you shall know that I am the LORD, and {shall not be ashamed the ones waiting for me}. 

#### Isaiah 49:24 Will anyone take {from a giant spoils}? and if {should be captured anyone} unjustly, shall he be delivered? 

#### Isaiah 49:25 For thus says the LORD, If any should capture a giant, he shall take the spoils. And the one taking from the one being strong, shall be delivered. But I {your case will plead}, and I {your sons will rescue}. 

#### Isaiah 49:26 And {shall eat the ones afflicting you} their own flesh; and they shall drink {as wine new their own blood}, and shall be intoxicated. And {shall perceive all flesh} that I am the LORD, the one rescuing you, and assisting the strength of Jacob. 

#### Isaiah 50:1 Thus says the LORD, Of what kind is this scroll of the certificate of divorce of your mother, by which I sent her away? or to which debtor of the ones exacting me have I sold you to him? Behold, for your sins you were sold; and for your lawless deeds I sent away your mother. 

#### Isaiah 50:2 Why is it that I came, and there was no man? I called and there was none hearkening. Is not {strong my hand} to rescue? or am I not able to rescue? Behold, by my rebuke I shall make quite desolate the sea, and I shall make rivers desolate places; and {shall be dried up their fishes} from there not being water; and they shall die for thirst. 

#### Isaiah 50:3 I shall clothe the heaven with darkness, and {as sackcloth I shall make its wrap-around garment}. 

#### Isaiah 50:4 The Lord, the LORD gives to me a tongue of instruction to know when it is necessary to speak a word. He stood me morning by morning. He added an ear for me to hear. 

#### Isaiah 50:5 And the instruction of the LORD opens my ears, and I do not resist persuasion, nor do I dispute. 

#### Isaiah 50:6 My back I have given to whips, and my jaws for slaps, and my face I did not turn from the shame of ones spitting. 

#### Isaiah 50:7 And the Lord, the LORD {a helper to me was}. On account of this I was not ashamed, but I set my face as a solid rock; and I knew that in no way should I be ashamed. 

#### Isaiah 50:8 For {approaches the one justifying me}. Who is the one judging me? Let him oppose me at the same time! Yes, who is the one judging me? Let him approach to me! 

#### Isaiah 50:9 Behold, the LORD shall help me. Who shall inflict evil on me? Behold, {all you as a cloak shall become old}, and as a moth you shall be devoured. 

#### Isaiah 50:10 Who among you is the one fearing the LORD? let him obey the voice of his servant! Let the ones going in darkness, and there is no light for them, yield upon the name of the LORD, and support yourselves upon God! 

#### Isaiah 50:11 Behold, you all {a fire kindle}, and you strengthen the flame; you go to the light of your fire, and the flame which you kindled. On account of me {came to pass these things} to you; {in distress you shall remain the night}. 

#### Isaiah 51:1 Hearken to me! O ones pursuing the just thing, and seeking the LORD. Look unto the solid rock! which you quarried, and into the pit of the well which you dug. 

#### Isaiah 51:2 Look unto Abraham your father! and unto Sarah the one travailing you. For he was one person, and I called him, and blessed him, and loved him, and multiplied him. 

#### Isaiah 51:3 And {you now I will comfort}, O Zion. And I comforted all her desolate places; and I will make her desolate places as a park; and her western places as a park of the LORD. {gladness and a leap for joy They shall find} in her -- acknowledgment and a voice of praise. 

#### Isaiah 51:4 Hear me! Hear me O my people! and O kings {to me give ear}! For a law {from me shall go forth}, and my judgment for a light of nations. 

#### Isaiah 51:5 {approaches quickly My righteousness}, and {shall go forth as light my deliverance}, and on my arm they shall hope. {for me Islands shall wait}, and on my arm they shall hope. 

#### Isaiah 51:6 Lift up {unto the heaven your eyes}, and look unto the earth below! For the heaven is as smoke having been solidified. And the earth as a cloak shall be old, and the ones inhabiting {as these shall die}. But the deliverance of mine {into the eon shall be}, and the righteousness of mine in no way shall fail. 

#### Isaiah 51:7 Hear me, O ones knowing equity! a people of whom my law is in their heart. Do not fear the scorning of men, and {their disparagement not let} vanquish you! 

#### Isaiah 51:8 For as a garment will be eaten upon time, and as wool shall be eaten by a moth; but the righteousness of mine {into the eon will be}; and the deliverance of mine for generations of generations. 

#### Isaiah 51:9 Awaken! Awaken! O Jerusalem, and put on the strength of your arm! Awaken as in the beginning of days, as a generation of an eon! {not you Are} her being quarried in width, being torn up by the dragon? 

#### Isaiah 51:10 {not you Are} her making desolate the sea, {water of the deep the abundance}, the one putting the depths of the sea for a way of a ford to the ones being rescued, 

#### Isaiah 51:11 and the ones being ransomed? For by the LORD they shall be returned, and shall come unto Zion with gladness, and {leap for joy an everlasting}. {upon head For their} praise and gladness shall overtake them. {ran away Grief and distress and moaning}. 

#### Isaiah 51:12 I am, I am he, the one comforting you. Know who is being! that you should be fearful from {man mortal}, and from a son of man -- the ones who as grass were dried up. 

#### Isaiah 51:13 And you forgot God, the one making you, the one making the heaven, and laying the foundation for the earth. And fear continually all the days in front of the rage of the one afflicting you! in which manner he planned to carry you away. And now where is the rage of the one afflicting you? 

#### Isaiah 51:14 For in your being delivered, he shall not stop nor pass time. And he shall not kill for hurt, and in no way shall he lack his bread. 

#### Isaiah 51:15 For I am your God, the one disturbing the sea, and resounding its waves. The LORD of Hosts is my name. 

#### Isaiah 51:16 I will put my words into your mouth. And under the shadow of my hand I will shelter you, in which I established the heaven, and founded the earth. And he shall say to Zion, {my people You are}. 

#### Isaiah 51:17 Awaken! Awaken! Rise up, O Jerusalem! the one drinking from the hand of the LORD the cup of his rage. {the cup For} of the blow, the drinking cup of rage you drank and emptied out. 

#### Isaiah 51:18 And there was no one comforting you from all your children whom you gave birth. And there was none taking hold of your hand, nor of all your sons whom you raised. 

#### Isaiah 51:19 Therefore these things are adverse to you. Who will grieve with you? A calamitous downfall, and defeat, hunger, and sword; who will comfort you? 

#### Isaiah 51:20 Your sons, the ones being perplexed, the ones sleeping upon the top of all the streets, as {beet a half-boiled}; the ones full of the rage of the LORD, fainting from the LORD God. 

#### Isaiah 51:21 On account of this, hear! O one being humbled, and O one being intoxicated not from wine. 

#### Isaiah 51:22 Thus says the LORD God, the one judging his people, Behold, I took from out of your hand the cup of the blow, the drinking cup of my rage; and you shall not proceed to drink it any longer. 

#### Isaiah 51:23 And I give it into the hand of the ones wronging you, and of the ones humbling you; the ones who said to your soul, Bow! that we should go by. And you put {equal to the ground the things in your midst} outside to the ones coming near. 

#### Isaiah 52:1 Awaken! Awaken, O Zion! Put on your strength, O Zion! And you, put on your glory, O Jerusalem, {city the holy}! No longer shall there proceed to go through you uncircumcised and unclean. 

#### Isaiah 52:2 Shake off the dust and rise up! Sit, O Jerusalem! Take off the bond from your neck, O captive daughter of Zion! 

#### Isaiah 52:3 For thus says the LORD, {without charge You were sold}, and {not with silver you shall be ransomed}. 

#### Isaiah 52:4 For thus says the Lord the LORD. To Egypt {went down My people} formerly to sojourn there, and {into Assyria by force they were led}. 

#### Isaiah 52:5 And now, why shall you be here? Thus says the LORD, Because {were taken my people} without charge, wonder and shriek! Thus says the LORD, On account of you, {always my name} is being blasphemed among the nations. 

#### Isaiah 52:6 On account of this, {shall know my people} my name. On account of this in that day, for I am he, the one speaking; I am at hand. 

#### Isaiah 52:7 As an hour upon the mountains, as feet announcing good news, the hearing of peace, as of announcing good news -- good things; for audibly I will produce your deliverance, saying, Zion, {shall reign Your God}. 

#### Isaiah 52:8 The voice of the ones guarding you is exalted, and with the voice together they shall be glad. For eyes to eyes shall see when ever the LORD should show mercy on Zion. 

#### Isaiah 52:9 Let {break asunder with gladness together the desolate places of Jerusalem}! for the LORD showed mercy on her, and rescued Jerusalem. 

#### Isaiah 52:10 And the LORD shall uncover {arm his holy} in the presence of all the nations. And {shall see all the uttermost parts of the earth} the deliverance by our God. 

#### Isaiah 52:11 Leave! Leave! Go forth from there, and the unclean thing do not touch! Go forth from out of the midst of it! Separate yourselves, O ones bearing the vessels of the LORD! 

#### Isaiah 52:12 For {not with disturbance you shall come forth}, nor {in flight into exile shall you go forth}. {shall go before For prior of you the LORD}; and the one assembling you is the God of Israel. 

#### Isaiah 52:13 Behold, {shall perceive my servant}, and he shall be exalted, and he shall be glorified, and he shall be raised up on high exceedingly. 

#### Isaiah 52:14 In which manner {shall be amazed by you many}, so {shall be despised by men the sight of your appearance}, and your glory by the sons of men. 

#### Isaiah 52:15 Thus {shall wonder nations many} over him; and {shall hold kings} their mouth. For to whom it was not announced concerning him, they shall see; and the ones who heard not shall perceive. 

#### Isaiah 53:1 O LORD, who trusted our report? And the arm of the LORD, to whom was it uncovered? 

#### Isaiah 53:2 We announced as of a male child before him, as a root in a land thirsting. There is no appearance to him, nor glory; and we beheld him, and he does not have appearance nor beauty. 

#### Isaiah 53:3 But his appearance was without honor, and wanting by sons of men. A man {for calamity being}, and knowing how to bear infirmity. For he turned his face; he was dishonored and was not considered. 

#### Isaiah 53:4 This one {our sins bore}, and on account of us he was grieved. And we considered him to be for misery, and for calamity by God, and for ill treatment. 

#### Isaiah 53:5 But he was wounded because of our sins, and he was made infirm on account of our lawless deeds. The discipline for our peace was upon him; by his stripe we were healed. 

#### Isaiah 53:6 {all as sheep We were wandered}. A man {in his way was wandered}, and the LORD delivered him up for our sins. 

#### Isaiah 53:7 And he on account of being inflicted by evil opened not his mouth. {as a sheep unto slaughter He was led}, and as a lamb before the one shearing is voiceless, so he did not open his mouth. 

#### Isaiah 53:8 In the humiliation, in his equity, he was lifted away. {his generation Who shall describe}? For {was lifted away from the earth his life}. Because of the lawless deeds of my people he was led unto death. 

#### Isaiah 53:9 And I shall give the wicked for his burial, and the rich for his death. For {lawlessness he did not commit}, nor was treachery in his mouth. 

#### Isaiah 53:10 And the LORD willed to cleanse him of the beating. If you should offer for a sin offering the thing for your life, he shall see {seed a long-lived}. 

#### Isaiah 53:11 And the LORD willed by his hand to remove misery of his soul, to show to him light, and to shape in the understanding; to justify the just one, the good one serving many, and {their sins he shall bear}. 

#### Isaiah 53:12 On account of this he shall inherit many; and of the strong ones he will portion out spoils, because {was delivered up unto death his soul}; and {among the lawless ones he was considered}; and he himself {the sins of many bore}, and because of their lawless deeds he was delivered up. 

#### Isaiah 54:1 Be glad! O sterile, the one not giving birth. Break forth and yell! O one not travailing. For many are the children of the barren, rather than the one having the husband. For thus spoke the LORD. 

#### Isaiah 54:2 Widen the place of your tent, and {the hide coverings of your curtains pitch}! You should spare not. Distance out your measured lands, and {tent pegs strengthen your}! 

#### Isaiah 54:3 {yet unto the right and the left Spread forth}! For your seed {nations shall inherit}, and {cities having been made desolate you shall dwell in}. 

#### Isaiah 54:4 You should not fear that you were disgraced, nor should you feel ashamed that you were berated. For {shame everlasting you shall forget}; and the scorn of your widowhood in no way shall you remember any longer. 

#### Isaiah 54:5 For the LORD, the one making you, the LORD of Hosts is his name; and the one rescuing you, he is the God of Israel. {God of all the earth He shall be called}. 

#### Isaiah 54:6 Not as {woman a forsaken and faint-hearted} has {called you the LORD}; nor as a woman {from youth being detested}, said your God. 

#### Isaiah 54:7 {time A little} I left you behind; and with {mercy great} I will show mercy on you. 

#### Isaiah 54:8 In {rage a little} I turned my face from you; and in {mercy eternal} I will show mercy on you, said the one rescuing you, the LORD. 

#### Isaiah 54:9 From the water upon Noah, this is my plan, in so far as I swore by an oath to him in that time to the earth, to not be enraged against you any longer; nor by your intimidation. 

#### Isaiah 54:10 {the mountains Shall} change over, nor your hills be moved about; so not even {shown by me to you mercy} shall fail, nor the covenant for your peace in any way shall change; {spoke for kindness to you the LORD}. 

#### Isaiah 54:11 Humble and confused, you were not comforted. Behold, I prepare for you carbuncle for your stone, and for your foundations sapphire. 

#### Isaiah 54:12 And I will make the parapets jasper, and your gates stones of crystal, and your enclosure {stones of choice}; 

#### Isaiah 54:13 and all your sons instructed of God, and much peace to your children. 

#### Isaiah 54:14 And {in righteousness you shall be built} at a distance from the unjust. And you shall not be fearful, and trembling shall not approach to you. 

#### Isaiah 54:15 Behold, converts shall come forward to you because of me, and they shall sojourn with you, and unto you they shall take refuge. 

#### Isaiah 54:16 Behold, I created you, not as a brazier blowing in a fire of coals, and bringing forth a utensil for work; but I created you, not for destruction to corrupt. 

#### Isaiah 54:17 Every weapon concocted against you shall not be prosperous; and every voice that shall rise up against you for judgment, all of them you shall vanquish. And the ones liable of you shall be in her; it is the inheritance to the ones attending the LORD, and you shall be righteous to me, says the LORD. 

#### Isaiah 55:1 Woe the ones thirsting. Go unto water! And as many as do not have money, proceeding, buy and eat! And go and buy without money! even valuable wine and fatling. 

#### Isaiah 55:2 What do you value for money not in bread loaves, and your effort not unto fullness? Hearken to me! and you shall eat good things, and shall revel in good things to your soul. 

#### Isaiah 55:3 Take heed with your ears, and follow after my ways! Listen to me! and you shall live with good things for your soul. And I shall ordain with you {covenant an eternal} -- the sacred things of David, the trustworthy ones. 

#### Isaiah 55:4 Behold, {a testimony to nations I made him}, a ruler and one assigning to nations. 

#### Isaiah 55:5 Behold, nations which do not know you shall call upon you, and peoples which have no knowledge of you {upon you shall take refuge}, because of the LORD your God, even the holy one of Israel -- for he glorified you. 

#### Isaiah 55:6 Seek the LORD! and in the finding {him call upon}! whenever he should approach to you. 

#### Isaiah 55:7 Let {leave the impious one} his ways, and {man the lawless} his plans! And let him return unto the LORD! and he shall be shown mercy, even from our God, for {unto much he will forgive your sins}. 

#### Isaiah 55:8 {not For are plans my} as your plans; nor as your ways are my ways, says the LORD. 

#### Isaiah 55:9 But as the distance the heaven is from the earth, so {is at a distance my way} from your ways, and your considerations from my mind. 

#### Isaiah 55:10 For as whenever {should come down the rain or snow} from heaven, and in no way shall it return until whenever it should saturate the earth, and the earth should bring forth, and should sprout, and should give seed to the one sowing, and bread for food; 

#### Isaiah 55:11 so shall it be with my word, which ever shall come forth from out of my mouth -- in no way shall it return to me empty until whenever it should finish as much as I wanted; and I will prosper your ways and my precepts. 

#### Isaiah 55:12 For with gladness you shall go forth, and in joy you shall be led. For the mountains and the hills shall leap out favorably receiving you in joy, and all the trees of the field shall clap with their tender branches. 

#### Isaiah 55:13 And instead of a pile, {shall ascend the cypress}. And instead of the briar {shall ascend the myrtle}. And the LORD will be for a name and for {sign an eternal}, and it shall not cease. 

#### Isaiah 56:1 Thus says the LORD, Guard equity, and do righteousness! {is near for my deliverance} to come, and my mercy to be uncovered. 

#### Isaiah 56:2 Blessed is the man doing these things, and the man holding to them, and guarding Sabbaths, so as to not profane them, and observing his hands so as to not do unjustly. 

#### Isaiah 56:3 {not Let say the foreigner}! the one joining to the LORD, saying, By separation {will separate me surely The LORD} from his people. And {not let say the eunuch} that, I am {tree a dry}! 

#### Isaiah 56:4 For thus says the LORD to the eunuchs, As many as should keep my Sabbaths, and should choose what I want, and should hold to my covenant, 

#### Isaiah 56:5 I will give to them in my house, and in my wall {place a famous}, better than sons and daughters. {name an eternal I will give to them}, and it shall not cease. 

#### Isaiah 56:6 And I will give it to the foreigners joining to the LORD, to serve him, and to love the name of the LORD, to be to him for manservants and maidservants, and all the ones keeping my Sabbaths, to not profane, and the ones holding to my covenant. 

#### Isaiah 56:7 I will bring them unto {mountain my holy}, and I will gladden them in {house of prayer my}. Their whole-burnt offerings and their sacrifices will be accepted upon my altar. For my house {a house of prayer shall be called} for all the nations, 

#### Isaiah 56:8 said the LORD, the one gathering the ones having been dispersed of Israel. For I will gather unto him a congregation. 

#### Isaiah 56:9 All {beasts wild}, come! Let {eat all the wild beasts of the forest}! 

#### Isaiah 56:10 See how they all have been blinded! they knew not. All {dogs are dumb}, they shall not be able to bark; ones dreaming of a bed, being fond of slumber. 

#### Isaiah 56:11 Yes, the {dogs impudent in the soul not knowing fullness}; and they are wicked, not knowing understanding; all {their own ways followed after}; each according to his own advantage from his uttermost, saying, 

#### Isaiah 56:12 Come we should take wine and be drunk with wine to intoxication, and {shall be such as this day tomorrow} -- great, rather exceedingly. 

#### Isaiah 57:1 Behold! how the just one perishes, and no one looks out for the heart; and {men just} are lifted away, and no one contemplates. For from the face of injustice {has been lifted away the just one}. 

#### Isaiah 57:2 {will be in peace His burial}, he has been lifted from out of the midst. 

#### Isaiah 57:3 But you lead forward here, {sons O lawless}, seed of adulterers, and of a harlot! 

#### Isaiah 57:4 In what have you reveled in? And against whom have you opened your mouth? And against whom have you slackened your tongue? {not Are you} children of destruction? a seed without honor? 

#### Isaiah 57:5 ones calling for aid upon the idols under {trees bushy}? slaying their children in the ravines between the rocks? 

#### Isaiah 57:6 That is your portion, this is your lot. To those you poured out libations, and to these you offered sacrifices; over these things then shall I not be provoked to anger? 

#### Isaiah 57:7 Upon {mountain the high and elevated}, there is your bed, and there you hauled to sacrifice your sacrifices. 

#### Isaiah 57:8 And behind the doorposts of your door you placed your memorials. Did you think that if you should separate from me {more anything you would have}. You loved the ones going to bed with you; 

#### Isaiah 57:9 and you multiplied your harlotry with them, and {many you made} of them far from you. And you sent ambassadors over your borders, and you were abased unto Hades. 

#### Isaiah 57:10 {in your many ways You tired}. and You said not, I shall cease growing in strength. For you practiced these things. On account of this {did not earnestly beseech of me you}. 

#### Isaiah 57:11 In venerating whom were you afraid of, that you lied against me, and did not remember me, nor took me into your consideration, nor into your heart? And I beholding you will overlook, yet {me you did not fear}. 

#### Isaiah 57:12 And I will report of your righteousness; and your evils shall not benefit you. 

#### Isaiah 57:13 Whenever you should yell out, then let them rescue you in your affliction! {these things For all} the wind shall take, and {shall carry away the gale}. But the ones holding on in me shall acquire the earth, and they shall inherit {mountain my holy}. 

#### Isaiah 57:14 And they shall say, Clear {from in front of him the ways}, and lift the impediments from the way of my people! 

#### Isaiah 57:15 Thus says the highest, the one in the highest, dwelling the eon. Holy in the holies; the name to him -- the LORD; {highest in the holies the one resting}; and to the faint-hearted giving long-suffering, and giving life to the ones being broken in heart. 

#### Isaiah 57:16 {not into the eon I shall punish you}, nor {always shall I be provoked to anger with you}; for a spirit from me shall go forth, and {breath all I made}. 

#### Isaiah 57:17 On account of sin a little in anything I grieved him, and I struck him, and I turned my face from him; and I was grieved, and he went gloomy in his ways. 

#### Isaiah 57:18 {his ways I have seen}, and I healed him, and comforted him, and gave to him {comfort true}. 

#### Isaiah 57:19 Peace upon peace to the ones far off, and to the ones being near. And the LORD said, I will heal them. 

#### Isaiah 57:20 But the unjust thus shall swell as waves, and {to rest will not be able}. 

#### Isaiah 57:21 There is no rejoicing to the impious, said God. 

#### Isaiah 58:1 Yell out in strength! and you should not spare. As a trumpet, raise up high your voice, and announce to my people their sins, and to the house of Jacob their lawless deeds! 

#### Isaiah 58:2 {me day by day They seek}, and {to know my ways they desire}, as a people {righteousness executing}, and {judgment of their God not abandoning}. They ask me now {judgment for a just}, and {to approach to God they desire}, 

#### Isaiah 58:3 saying, Why is it that we fasted, and you did not look? Why did we humble our souls, and you did not know? For in the days of your fasts you find the things of your wants, and all the ones under your hands you goad. 

#### Isaiah 58:4 {for litigations and fights You fast}, and you beat {with your fists the humble}. Why {to me do you fast} as you do today? {to be heard in a cry is it for your voice}? 

#### Isaiah 58:5 {not this fast I did choose}, nor a day {to humble for a man} his soul; nor even should you bend {as a hook your neck}, nor {sackcloth and ashes should you spread under you}, nor thus shall you call {fast an acceptable}. 

#### Isaiah 58:6 {not such I Did choose} a fast, says the LORD. But untie every bond of injustice! Part {perverseness violent} of exchanges! Send out {the ones having been devastated by a free release}, and {every writ unjust tear apart}! 

#### Isaiah 58:7 Break {with ones hungering your bread}, and {poor the homeless bring} into your house! If you behold one naked, clothe him! And concerning the members of your family of your seed, you shall not disdain them. 

#### Isaiah 58:8 Then {shall be torn through the morning your light}, and the things for your cures quickly shall arise; and {shall go before in front of you your righteousness}, and the glory of God shall screen you. 

#### Isaiah 58:9 Then you shall yell, and the LORD shall hearken to you. Yet while you are speaking he shall say, Behold, I am at hand. If you remove from yourself conspiracy, and stretching forth of the hands, and {discourse grumbling}; 

#### Isaiah 58:10 and should give to ones hungering the bread from your soul, and {the soul being humble should fill up}, then {shall rise in the darkness your light}, and your darkness shall be as midday. 

#### Isaiah 58:11 And {will be your God} with you always, and you shall be filled up just as {desires your soul}. And your bones shall be fattened, and will be as {garden a saturated}, and as a spring which {failed not water}. 

#### Isaiah 58:12 And {shall be built to you the desolate places everlasting}, and {will be foundations your everlasting} in generations of generations; and you shall be called a builder of barriers. And the stones, the ones between your roads shall cease. 

#### Isaiah 58:13 If you should turn your foot from the Sabbaths, so as to not do your wants on the {day holy}, and shall call the Sabbaths delightful, holy to your God; if you shall not lift your foot to work, nor shall you speak a word in anger from out of your mouth, 

#### Isaiah 58:14 then shall you be relying upon the LORD, and he will bring {upon your the good things} land, and he will feed you the inheritance of Jacob your father. For the mouth of the LORD spoke these things. 

#### Isaiah 59:1 Is not {strong the hand of the LORD} to deliver? or {weighed down his ear} to not listen? 

#### Isaiah 59:2 But your sins make a part between you and God; and on account of your sins he turned his face from you, to not show mercy. 

#### Isaiah 59:3 For your hands are tainted with blood, and your fingers with sins; and your lips spoke lawlessness, and your tongue {injustice meditated upon}. 

#### Isaiah 59:4 No one speaks just things, nor is there {equity true}. They rely upon vanities, and they speak empty things; for they sire misery and give birth to lawlessness. 

#### Isaiah 59:5 {eggs of asps They hatch}, and {a web of a spider weave}. And the one about {their eggs to eat}, breaking a rotten egg found also in it a cobra. 

#### Isaiah 59:6 Their web shall not be made into a garment, nor shall they clothe themselves from their works, for their works are works of lawlessness. 

#### Isaiah 59:7 And their feet {unto wickedness run}, quick to pour out blood, and their thoughts are thoughts of murder. Destruction and misery are in their ways. 

#### Isaiah 59:8 And the way of peace they do not know, and there is no equity in their ways. For their roads {are perverted which they travel through}, and they do not know peace. 

#### Isaiah 59:9 On account of this {left equity} from them, and in no way shall {overtake them righteousness}. In their waiting light, {came to them darkness}; waiting for daylight, {in midnight they walked}. 

#### Isaiah 59:10 They shall grope as blind men for a wall, and {as ones not possessing eyes they shall grope}. They shall fall in midday as at midnight; {as ones dying they shall moan}. 

#### Isaiah 59:11 As a bear and as a dove together they shall go. We awaited judgment, and there is no deliverance; {far it is removed} from us. 

#### Isaiah 59:12 {is great For our lawlessness} before you, and our sins withstood us. For our lawless deeds are in us, and our offences we knew. 

#### Isaiah 59:13 We were impious, and lied, and departed from our God. We spoke unjustly, and we resisted persuasion. We sired, and meditated {from our heart words unjust}. 

#### Isaiah 59:14 And we left behind equity, and righteousness {far off removed}. For {was consumed in their ways the truth}, and {by a straight way they were not able to go}. 

#### Isaiah 59:15 And the truth was lifted away, and they changed their thought of the perceiving. And the LORD beheld, and it did not please him, for there was no equity. 

#### Isaiah 59:16 And he beheld, and there was no man. And he contemplated, and there was no one assisting. And he defended them with his arm, and {with his charity he supported them}. 

#### Isaiah 59:17 And he clothed himself with righteousness as a chest plate; and he put a helmet of deliverance upon his head. and he put around himself a cloak of vengeance -- even a wrap-around garment, 

#### Isaiah 59:18 as one recompensing a reward of scorn to the adversaries. 

#### Isaiah 59:19 And {shall fear the ones from the west} the name of the LORD; and the ones from the east sun shall fear the {name honorable}. {shall come For as river a violent the anger of the LORD}; it shall come with rage. 

#### Isaiah 59:20 And {shall come from Zion the one rescuing}, and he shall turn impiety from Jacob. 

#### Isaiah 59:21 And this {to them is by me covenant}, said the LORD. The spirit -- mine, which is upon you, and my words which I put in your mouth, in no way shall fail from your mouth, nor from out of the mouth of your seed; said the LORD, from the present and unto the eon. 

#### Isaiah 60:1 Be enlightened! Be enlightened, O Jerusalem! {is come for your light}, and the glory of the LORD {upon you has risen}. 

#### Isaiah 60:2 Behold, darkness shall cover the earth, and a dimness upon nations; {upon but you shall appear the LORD}, and his glory {upon you shall be seen}. 

#### Isaiah 60:3 And {shall go nations} by your light, and kings in your brightness. 

#### Isaiah 60:4 Lift {round about your eyes}, and behold {gathering together all your children}! {come All your sons} from far off, and your daughters {upon shoulders shall be carried}. 

#### Isaiah 60:5 Then you shall see, and shall be fearful, and shall be startled in the heart; for {shall turn unto you the riches of the sea}, and of nations, and of peoples; and they shall come to you. 

#### Isaiah 60:6 Herds of camels, and {shall cover you camels of Midian and Ephah}; {all from out of Sheba they come} bringing gold and frankincense; and {the deliverance of the LORD they shall announce as good news}. 

#### Isaiah 60:7 And all the sheep of Kedar shall be gathered together to you, and rams of Nebaioth shall come to you; and {shall be offered acceptable sacrifices} upon my altar, and the house of my prayer shall be glorified. 

#### Isaiah 60:8 Who thus as clouds fly, even as doves with young? 

#### Isaiah 60:9 {for me Islands waited}, and boats of Tarshish are among the first to lead your children from far off, and {silver and gold their} is with them, on account of the {name of the LORD holy}, and on account of the holy one of Israel to be glorious. 

#### Isaiah 60:10 And {shall build foreigners} your walls, and their kings shall stand beside you. For on account of my anger I struck you, and on account of mercy I loved you. 

#### Isaiah 60:11 And {shall be open your gates} continually; day and night they shall not be locked; to bring in to you the force of nations, and their kings leading. 

#### Isaiah 60:12 For the nations and the kings which will not serve to you shall perish; and the nations {unto desolation shall be made desolate}. 

#### Isaiah 60:13 And the glory of Lebanon {to you shall come} with cypress and pine and cedar together, to glorify {place my holy}. And the place of their feet I will glorify. 

#### Isaiah 60:14 And they shall go to you being in awe -- sons of the ones humbling you. And {shall do obeisance at the soles of your feet all the ones who provoked you}. And you shall be called, City of the LORD, Zion of Holy Israel. 

#### Isaiah 60:15 Because you became abandoned and detested, and there was no one helping, even I will make you {leap for joy an everlasting}, a gladness to generations of generations. 

#### Isaiah 60:16 And you shall nurse milk of nations, and {wealth of kings you shall eat}. And you shall know that I am the LORD, the one delivering you, and rescuing you -- the God of Jacob. 

#### Isaiah 60:17 And instead of brass, I shall bring to you gold; and instead of iron, I shall bring to you silver; and instead of wood, I shall bring to you brass; and instead of stones -- iron; and I shall appoint your rulers for peace, and your overseers for righteousness. 

#### Isaiah 60:18 And {shall not be heard any longer injustice} in your land, nor destruction, nor misery within your borders. And {shall be called Deliverance your walls}, and your gates, Carving. 

#### Isaiah 60:19 And {will not be to you any longer the sun} for the light of day, nor the rising moon shall give light to you at night. But {will be to you the LORD light an eternal}, even the God of your glory. 

#### Isaiah 60:20 {shall not For go down the sun} to you, and the moon {to you shall not subside}. {will be For to you the LORD light an eternal}. And {shall be fulfilled the days of your mourning}. 

#### Isaiah 60:21 And your people are all righteous, and {through the eon they shall inherit the earth}, keeping the thing planted, even the works of their hands for glory. 

#### Isaiah 60:22 The very few will be for thousands, and the least for {nation a great}. I the LORD in due time shall gather them. 

#### Isaiah 61:1 Spirit of the LORD is upon me, because he anointed me to announce good news to the poor. He has sent me to heal the ones being broken in the heart; to proclaim {to captives a release}, and {to the blind recovery of sight}; 

#### Isaiah 61:2 to call {year of the LORD the acceptable}, and day of recompense; to comfort all the ones mourning; 

#### Isaiah 61:3 to give to the ones mourning for Zion glory instead of ashes; an anointing of gladness to them that mourn; according to an apparel of glory instead of a spirit of indifference. And they shall be called generations of righteousness, a thing planted of the LORD for glory. 

#### Isaiah 61:4 And they shall build up {wildernesses everlasting} being made quite desolate prior. They shall rise up and shall revive cities of wildernesses having been made quite desolate for generations. 

#### Isaiah 61:5 And {shall come foreigners} tending your sheep, and Philistines as plowmen and vine dressers. 

#### Isaiah 61:6 And you {priests of the LORD shall be called}. Ministers of our God -- it shall be said to you. {strength of nations You shall devour}, and in their riches you shall be admired. 

#### Isaiah 61:7 Thus of a second time they shall inherit the land, and {gladness everlasting} is above their head. 

#### Isaiah 61:8 For I am the LORD, the one loving righteousness, and detesting seizures by injustice. And I will give their effort to the just ones, and {covenant an eternal I shall ordain} with them. 

#### Isaiah 61:9 And {shall be known among the nations their seed}, and their progeny in the midst of the peoples. All seeing them will recognize them, for these are a seed being blessed by God. 

#### Isaiah 61:10 And in gladness they shall be glad over the LORD. Let {exult my soul} over the LORD! For he clothed me with a cloak of deliverance, and an inner garment of gladness. As a groom, he put on me a mitre; and as a bride, he adorned me with an ornament. 

#### Isaiah 61:11 And as the earth growing its flower, and as a garden {its seeds sprouts forth}, so {will raise up the Lord the LORD} righteousness and a leap for joy before all the nations. 

#### Isaiah 62:1 On account of Zion I will not keep silent; and on account of Jerusalem I will not spare, until whenever {comes forth as light my righteousness}, and my deliverance {as a lamp shall be burned}. 

#### Isaiah 62:2 And {shall see nations} your righteousness, and all kings your glory. And he shall call you {name by your new} which the mouth of the LORD shall name it. 

#### Isaiah 62:3 And you will be a crown of beauty in the hand of the LORD, and a diadem of the kingdom in the hand of your God. 

#### Isaiah 62:4 And no longer shall you be called -- One Being Forsaken. And your land shall not be called -- Desolation. For you shall be called -- My will; and your land -- Being Lived In. For the LORD took pleasure in you, and your land shall be lived in together. 

#### Isaiah 62:5 And as {living with a young man} a virgin, so shall {dwell your sons} with you. And it will be in which manner {shall be glad a groom} over a bride, so the LORD will be glad over you. 

#### Isaiah 62:6 And upon your walls, O Jerusalem, I placed keepers for the entire day and the entire night; ones who through the end shall not keep silent making mention of the LORD. 

#### Isaiah 62:7 {not there is For to you one likened}, whenever he should set things right, and should make Jerusalem prancing upon the earth. 

#### Isaiah 62:8 {swore by an oath The LORD} according to his right hand, and according to the strength of his arm, I shall not give your grain, and your foods to your enemies; and neither shall {drink sons alien} your wine, for which you troubled to make. 

#### Isaiah 62:9 But the ones gathering shall eat them, and they shall praise the LORD; and the ones gathering shall drink them in {properties holy my}. 

#### Isaiah 62:10 Go through my gates, and open a way for my people! And the stones of the ones from the way scatter away! Lift the agreed upon sign unto the nations! 

#### Isaiah 62:11 For behold, the LORD made it audible unto the end of the earth. Say to the daughter of Zion! Behold, the deliverer {to you is come}, having his own wage with him, and his work before his face. 

#### Isaiah 62:12 And he shall call them, {People Holy} being ransomed by the LORD. But you shall be called {Being Anxiously Sought After A City}, and not Being Abandoned. 

#### Isaiah 63:1 Who is this, the one coming from out of Edom, with {dyed red garments} from out of Bozrah? This one beautiful in his apparel, {force with a mighty}? I reason righteousness and the case of deliverance. 

#### Isaiah 63:2 Why are your {red clothes}, and your garments as from a trampled wine vat, 

#### Isaiah 63:3 full of that being trampled? And of the nations there is not a man with me. And I trampled them in my rage, and I broke them in pieces as ground, and led their blood unto the ground. And all my garments are defiled. 

#### Isaiah 63:4 For a day of recompense came upon them, and a year of ransoming is at hand. 

#### Isaiah 63:5 And I looked, and there was no helper. And I paid attention, and no one assisted. And {rescued them arm my}, and my rage attended to it. 

#### Isaiah 63:6 And I trampled them in my anger, and I led down their blood unto the ground. 

#### Isaiah 63:7 {the mercy of the LORD I remembered}; the virtues of the LORD in all which he recompenses to us. The LORD -- {judge a good} to the house of Israel; he brings upon us according to his mercy, and according to the magnitude of his righteousness. 

#### Isaiah 63:8 And he said, {my people Children in no way will disrespect}. And he became to them for deliverance, 

#### Isaiah 63:9 from out of all their affliction. Not an ambassador, nor an angel, but he, the LORD delivered them, because of loving them. And he spared them -- he ransomed them, and he took them, and raised them all the days of the eon. 

#### Isaiah 63:10 But they resisted persuasion, and provoked {spirit his holy}. And {turned against them the LORD} for enmity; he waged war against them. 

#### Isaiah 63:11 And he remembered {days everlasting}; the bringing up from the land the shepherd of the sheep. Where is the one putting {in them the spirit holy}? 

#### Isaiah 63:12 the one leading {by the right hand Moses}, the one being the arm of his glory? He prevailed over water in front of him; he made for himself {name an everlasting}. 

#### Isaiah 63:13 He led them through the deep as a horse through a wilderness, and they tired not. 

#### Isaiah 63:14 And as cattle led through a plain, {descended spirit of the LORD}, and guided them. Thus you led your people to make for yourself {name a glorious}. 

#### Isaiah 63:15 Turn from heaven, and look from {house your holy}, and from your glory! Where is your zeal and your strength? Where is the abundance of your mercy and your compassions, that you withheld from us? 

#### Isaiah 63:16 For you are our father. For Abraham did not know us, and Israel did not recognize us. But you, O LORD our father, rescue us! From the beginning your name {upon us is}. 

#### Isaiah 63:17 Why did you wander us, O LORD, from your way? You hardened our hearts to not fear you? Return on account of your servants! on account of the tribes of your inheritance. 

#### Isaiah 63:18 that {a little we should inherit mountain of your holy}. Our adversaries trampled your sanctuary. 

#### Isaiah 63:19 We became as from the beginning when you did not rule us, nor was {called your name} upon us. 

#### Isaiah 64:1 If you should open the heaven, {trembling will take hold from you mountains}, and they shall melt away; 

#### Isaiah 64:2 as beeswax from fire shall melt away. And {shall incinerate fire} the adversaries, and {for distinction will be your name} among the adversaries. From in front of you nations shall be disturbed. 

#### Isaiah 64:3 Whenever you should do the honorable things trembling shall take hold of mountains. 

#### Isaiah 64:4 From the eon we heard not, nor our eyes beheld a God besides you, and your works which you shall do to the ones waiting for mercy. 

#### Isaiah 64:5 For he shall meet with the ones doing justice, and your ways shall be remembered. Behold, you have been provoked to anger, and we sinned; on account of this we were wandered. 

#### Isaiah 64:6 And {became as unclean all we}. {is as a menstrual rag sitting apart All our righteousness}. And we flowed away as leaves on account of our lawless deeds; thus the wind shall bear us away. 

#### Isaiah 64:7 And there is no one calling upon your name, nor one remembering to take hold of you. For you turned your face from us, and you delivered us up because of our sins. 

#### Isaiah 64:8 And now, O LORD, {our father you are}; and we are mortar, {works of your hands are all we}. 

#### Isaiah 64:9 You should not be provoked to anger with us very much, and {should not for a long time be remembered our sins}. And now, look upon us, O LORD, for {your people all we are}! 

#### Isaiah 64:10 The city of your holiness became desolate. Zion {as desolate became}. Jerusalem for a curse. 

#### Isaiah 64:11 The house our holy place, and the glory which {blessed our fathers}, became scorched, and all our honorable things are cast down. 

#### Isaiah 64:12 And over all these things you endured, O LORD, and kept silent, and humbled us very much. 

#### Isaiah 65:1 {apparent I became} to the ones {for me not seeking}. I was found by the ones {for me not asking}. I said, Behold, I am -- to the nation, the ones who did not call of me by name. 

#### Isaiah 65:2 I spread forth my hands the entire day to a people resisting persuasion and speaking contrary; the ones not having gone {way the good}, but after their sins. 

#### Isaiah 65:3 This people, the one provoking me, {before me is always}. They sacrifice in the gardens, and they burn incense upon the bricks to the demons which are not. 

#### Isaiah 65:4 And in the tombs in the caves they sleep for the sake of dreams; the ones eating meat of a pig, and the broth of sacrifices. {are tainted All their vessels}. 

#### Isaiah 65:5 The ones saying, Be at a distance from me, you should not approach me, for I am clean. This is the smoke of my rage; a fire burns with it all the days. 

#### Isaiah 65:6 Behold, it is written in my presence, I shall not keep silent until whenever I recompense. And I will recompense unto their bosom 

#### Isaiah 65:7 their sins, and the ones of their fathers, says the LORD, the ones that burnt incense upon the mountains, and {upon the hills berated me}. I will recompense their works into their bosom. 

#### Isaiah 65:8 Thus says the LORD, In which manner {shall be found the grape-stone} in the cluster of grapes, and they shall say, You should not lay it waste, for there is a blessing in it; so I will do because of the ones serving me -- {this one because of} in no way shall I destroy all. 

#### Isaiah 65:9 And I shall lead out the one of {of Jacob the seed}, and the one of Judah. And he shall inherit {mountain holy my}, and {shall inherit it my chosen and my servants}, and they shall dwell there. 

#### Isaiah 65:10 And there shall be in the grove folds of flocks; and the ravine of Achor shall be for a resting place of herds for my people, the ones who sought me. 

#### Isaiah 65:11 But you are the ones having abandoned me, and having forgotten {mountain my holy}, and are preparing {to the demon a table}, and filling {to good luck a mixture}. 

#### Isaiah 65:12 I will deliver you unto the sword. {all by slaughter You shall fall}, for I called you and you hearkened not; I spoke, and you disregarded, and you did the wicked thing before me, and what I did not want you chose. 

#### Isaiah 65:13 On account of this, Thus says the LORD, Behold, the ones serving to me shall eat, but you shall hunger. Behold, my servants shall drink, but you shall thirst. Behold, the ones serving me shall be glad, but you shall be ashamed. 

#### Isaiah 65:14 Behold, the ones serving me shall exult in gladness, but you shall cry out because of the misery of your heart; and from the destruction of your spirit you shall shriek. 

#### Isaiah 65:15 For you shall leave behind your name for a glut to my chosen, {you and shall do away with the LORD}. But to the ones that serve to me, they shall be called {name by a new}, 

#### Isaiah 65:16 which shall be blessed upon the earth. For they shall bless the {God true}. And the ones swearing by an oath upon the earth shall swear by an oath on the {God true}. For they shall forget {affliction their first}, and it shall not ascend unto their heart. 

#### Isaiah 65:17 For there will be the {heaven new}, and the {earth new}. And in no way shall they remember the former things, nor in any way shall it come upon their heart. 

#### Isaiah 65:18 But {gladness and a leap for joy they shall find in her}. For behold, I make Jerusalem a leap for joy, and over my people for gladness. 

#### Isaiah 65:19 And I shall exult over Jerusalem, and shall be glad over my people. And no longer shall there be heard in her a voice of weeping, nor a voice of crying; 

#### Isaiah 65:20 nor in any way shall there be yet an untimely miscarriage, nor an old man who shall not fill up his time. {will be For the young man} a hundred years old, and the {dying sinner at a hundred years old accursed will be}. 

#### Isaiah 65:21 And they shall build residences, and they shall dwell in them. And they shall plant vineyards, and they shall eat their produce, and {the wine shall drink}. 

#### Isaiah 65:22 In no way shall they build and another dwell therein. And in no way shall they plant and another eat of it. For according to the days of the {of a tree life} will be the days of my people, for the works of their hands shall grow old. 

#### Isaiah 65:23 And my chosen shall not tire in empty things, nor shall they produce children for a curse; for {a seed being blessed by God it is}, and their progeny with them. 

#### Isaiah 65:24 And it will be before their crying out, I will hearken unto them; yet during their speaking I will say, What is it? 

#### Isaiah 65:25 Then wolves and lambs shall graze together; and the lion {as an ox shall eat straw}; and the serpent shall eat of the earth as bread; they shall not do wrong nor lay waste upon {mountain my holy}, says the LORD. 

#### Isaiah 66:1 Thus says the LORD, The heaven is my throne, and the earth a footstool for my feet. What kind of house shall you build to me? and what kind of place for my rest? 

#### Isaiah 66:2 For all these things I made by my hand, and {are mine all these}, says the LORD. And upon whom shall I look upon, but only upon the humble and unassuming, and the one trembling at my words? 

#### Isaiah 66:3 But the lawless one, the one sacrificing a calf to me is as the one striking a man; and the one sacrificing of the flock is as the one killing a dog; and the one offering fine flour is as the one offering the blood of a pig; the one offering frankincense for a memorial is as blasphemous. And they chose their ways, and their abominations which their soul wanted. 

#### Isaiah 66:4 And I will choose their mockeries, and {their sins I will recompense} against them. For I called them, and they did not hearken to me; I spoke and they heard not; and they acted wickedly before me, and {that which I did not want chose}. 

#### Isaiah 66:5 Hear the word of the LORD! O ones trembling at his word. Let {speak your brethren} to the ones detesting you, and abhorring you, that the name of the LORD should be glorified, and should be seen in their gladness, but those shall be ashamed. 

#### Isaiah 66:6 A voice of a cry from out of the city; a voice from out of the temple; the voice of the LORD recompensing a recompense to the adversaries. 

#### Isaiah 66:7 Before her travailing to give birth, before the coming of the misery of the pangs, she fled and gave birth to a male. 

#### Isaiah 66:8 Who heard such? and who has seen thus? Has {travailed the earth} in one day? or even {given birth a nation} at once, that {travailed and gave birth to Zion} her children? 

#### Isaiah 66:9 But I gave this expectation, and you did not remember me, said the LORD. And behold, I {the one bearing and the one sterile made}, said your God. 

#### Isaiah 66:10 Be glad, O Jerusalem, and let {assemble for a festival in her all the ones loving her}! And the ones dwelling her rejoice in joy, all as many as mourn for her! 

#### Isaiah 66:11 that you should nurse and be filled up from the breast of her comfort; that sucking out you should indulge at the introduction of her glory. 

#### Isaiah 66:12 For thus says the LORD, Behold, I turn aside to them as a river of peace, and as a rushing stream inundating the glory of the nations. Their children {upon shoulders shall be carried}, and {upon knees shall be comforted}. 

#### Isaiah 66:13 As if any mother shall comfort, so also I shall comfort you; and in Jerusalem you shall be comforted. 

#### Isaiah 66:14 And you shall see, and {shall rejoice your heart}, and your bones {as pasturage shall rise up}; and {shall be known the hand of the LORD} to the ones fearing him, and he shall threaten the ones resisting persuasion. 

#### Isaiah 66:15 For behold the LORD {as a fire shall come}, even as a blast by his chariots, to recompense {in rage punishment}, and being contemptuously rejected in a flame of fire. 

#### Isaiah 66:16 For by the fire of the LORD {shall be judged all the earth}, and by his broadsword all flesh. Many shall be slain by the LORD. 

#### Isaiah 66:17 The ones purifying themselves and cleansing themselves in the gardens, and {in the thresholds the ones eating the meat of a pig and the abominations and the mouse}, together shall be consumed, said the LORD. 

#### Isaiah 66:18 And I {their works and their device know}. And I come to bring together all the nations, and the tongues. And they shall come and shall see my glory. 

#### Isaiah 66:19 And I will leave upon them a sign. And I will send out from them ones having been delivered unto the nations -- unto Tarshish, and Pul, and Lud, and Meshach, and Tubal, and unto Greece, and unto the islands -- the ones at a distance, the ones who have not heard of my name, nor have seen my glory. And they shall announce my glory among the nations. 

#### Isaiah 66:20 And they shall lead your brethren from out of all the nations, as a gift to the LORD, with horses, and chariots, in royal chariots drawn by mules with awnings, into the holy city Jerusalem. And the LORD said, As {may offer the sons of Israel} their sacrifices to me with psalms in the house of the LORD, 

#### Isaiah 66:21 that from them I will take priests and Levites, said the LORD. 

#### Isaiah 66:22 {in which manner For} the {heaven new} and the {earth new} which I make wait before me, says the LORD, so I shall establish your seed, and your name. 

#### Isaiah 66:23 And it will be month by month, and Sabbath by Sabbath, {shall come all flesh} to do obeisance before me in Jerusalem, said the LORD. 

#### Isaiah 66:24 And they shall go forth, and shall see the carcasses of men, the ones violating against me. For their worm shall not come to an end, and their fire shall not be extinguished. And they will be for a sight to all flesh.