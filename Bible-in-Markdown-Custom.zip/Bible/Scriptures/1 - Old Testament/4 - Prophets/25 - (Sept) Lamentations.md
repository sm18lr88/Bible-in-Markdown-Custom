#### Lamentations 1:1 And it came to pass after {was taken captive Israel}, and Jerusalem was made desolate, Jeremiah sat down weeping, and he wailed this lamentation over Jerusalem, and he said, How does {sit alone the city being filled with peoples}; she became as a widow, becoming filled among the nations; ruling in the regions, she became for tribute. 

#### Lamentations 1:2 In weeping, she wept in the night, and her tears are upon her cheeks, and no one existed comforting her from all of the ones loving her. All the ones being fond of her discarded her, they became to her for enemies. 

#### Lamentations 1:3 Judea was displaced because of her humiliation, and because of the multitude of her servitude. She stays among the nations, she did not find rest. All the ones pursuing her overtook her in the midst of the ones afflicting. 

#### Lamentations 1:4 The ways of Zion mourn by reason of there not being ones coming to the holiday feast. All her gates have been obliterated. Her priests are groaning, her virgins are being led captive, and she is being embittered in herself. 

#### Lamentations 1:5 {became The ones afflicting her} the head, and her enemies are straightened; for the LORD humbled her over the multitude of her impieties. Her infants went into captivity in front of the one afflicting. 

#### Lamentations 1:6 And went forth from the daughter of Zion all her beauty. {became Her rulers} as rams not finding pasture, and going with no strength in front of the one pursuing. 

#### Lamentations 1:7 Jerusalem remembered the days of her humiliation, and her repulsions. All her desirable things, as many as were from {days ancient} during the falling of her people into the hands of the one afflicting, and there was no one helping her. Seeing, her enemies laughed upon her displacement. 

#### Lamentations 1:8 {a sin sinned Jerusalem}; on account of this {for tossing about she became}. All the ones glorifying her humbled her, for they beheld her indecency. And indeed she is moaning herself and turns to the rear. 

#### Lamentations 1:9 Her uncleanness is before her feet, she did not remember her end, and she brought down enormously. There is no comforting her. Behold O LORD my humiliation, for {was magnified the enemy}! 

#### Lamentations 1:10 {his hand spread forth The one afflicting} upon all the desirable things of hers. For she saw nations entering into her sanctuary -- the ones which I charged {not to enter them} into your assembly. 

#### Lamentations 1:11 All her people are groaning seeking bread. They gave the desirable things of hers for food to restore their soul. Behold, O LORD, and look upon! for she became as one being disgraced. 

#### Lamentations 1:12 {the ones to you All coming near} in the way turn and see if there is a pain as my pain which happened to me. The one uttering a sound to me humbled me -- the LORD in a day of anger of his rage. 

#### Lamentations 1:13 From out of his height he sent fire in my bones, and he led it down. He opened and spread out a net for my feet. He turned me to the rear. He appointed me for being removed from view; an entire day for grieving. 

#### Lamentations 1:14 He was vigilant concerning my acts of impiety; {in my hands they are closely joined}; they ascended unto my neck. {is weakened My strength}, for the LORD put {in my hands griefs}; I shall not be able to stand. 

#### Lamentations 1:15 {lifted away all my strong men The LORD} from the midst of me. He called upon me a time to break my choice men. {the wine vat trod The LORD} for the virgin daughter of Judah. 

#### Lamentations 1:16 Over these things I weep; my eye led down water, For far from me is the one comforting me, the one restoring my soul. {were sons My} obliterated, for {conquered the enemy}. 

#### Lamentations 1:17 Zion opened and spread out her hands; there is no one comforting her. The LORD gave charge to Jacob; round about him are the ones afflicting him. Jerusalem was as a woman sitting apart unclean in the midst of them. 

#### Lamentations 1:18 {just is The LORD}; for {his mouth I greatly embittered}. Hear indeed all peoples, and behold my pain! My virgins and my young men were gone into captivity. 

#### Lamentations 1:19 I called my lovers, but they misled me. My priests and my elders {in the city failed}, for they sought food for themselves, that they should restore their lives. 

#### Lamentations 1:20 Behold, O LORD, for I am afflicted! My belly was disturbed, and my heart was turned within me; greatly embittering I was embittered. Outside {made me childless the sword}, as if a death in the house. 

#### Lamentations 1:21 Hear indeed! for I moan. There is not one comforting me. All my enemies heard the bad things concerning me, and they rejoice that you did it. You brought on the day; you called the time, they became alike to me. 

#### Lamentations 1:22 May {enter all their evils} before your face. And glean them! in which manner they made a gleaning for all of my sins. for {are many my moanings}, and my heart frets. 

#### Lamentations 2:1 O How {darkened his anger the LORD} for the daughter of Zion. He hurled down from out of heaven unto the earth the glory of Israel, and he remembered not the stool of his feet in a day of wrath of his rage. 

#### Lamentations 2:2 {sunk the LORD}, not sparing, all the beautiful things of Jacob. He demolished in his rage the fortresses of the daughter of Judah. He cleaved unto the ground. He profaned her king and her ruler. 

#### Lamentations 2:3 He broke in pieces in anger of his rage all the horn of Israel. He turned back his right hand from the face of the enemy, and he lit in Jacob {as fire a flame}, and it devoured all the things round about. 

#### Lamentations 2:4 He stretched tight his bow as an enemy. He stiffened his right hand as an opponent, and he killed all the desirable things of my eyes in the tent of the daughter of Zion. He poured out {as fire his anger}. 

#### Lamentations 2:5 {became The LORD} as an enemy. He sunk Israel, he sunk all his palaces. He utterly destroyed his fortresses, and multiplied to the daughter of Judah the one humbling and the one being humbled. 

#### Lamentations 2:6 And he opened and spread out {as a grapevine his tent}. {was corrupted his holiday feast}. The LORD forgot what he appointed in Zion -- the holiday feast and the Sabbath; and {provoked the threatening of his anger} king and priest. 

#### Lamentations 2:7 The LORD thrust away his altar, he brushed off his sanctuary, he broke by the hand of the enemy the wall of her palaces; {a sound they gave} in the house of the LORD, as in the day of holiday. 

#### Lamentations 2:8 The LORD devised to ruin the wall of the daughter of Zion. He stretched out a measure, he did not return his hand from trampling; and {mourned the area around the wall}, and the wall with one accord was weakened. 

#### Lamentations 2:9 {are stuck into the ground Her gates}; he destroyed and broke her gate bars. Her king and her rulers are in the nations. There is no law, and indeed her prophets beheld not a vision by the LORD. 

#### Lamentations 2:10 They sat upon the ground; {kept silent the elders of the daughter of Zion}. They brought dust upon their head; they girded on sackcloths; they led down to the ground the heads of virgins in Jerusalem. 

#### Lamentations 2:11 {failed with tears My eyes}; {is disturbed my heart}; {is poured out onto the ground my glory} over the destruction of the daughter of my people, in the failing infant and ones nursing in the squares of the city. 

#### Lamentations 2:12 To their mothers they said, Where is the grain and wine? while they were enfeebled as wounded men in the squares of the city, in the pouring out of their souls into the bosom of their mothers. 

#### Lamentations 2:13 What shall I testify? or what shall I liken to you, O daughter of Jerusalem? Who shall deliver you, O virgin daughter of Zion? For {was enlarged the cup of your destruction}; Who shall heal you? 

#### Lamentations 2:14 Your prophets saw for you vanities and folly, and they uncovered not upon your iniquity, to turn your captivity; and they beheld for you {concerns vain} and purgations. 

#### Lamentations 2:15 {clap over you hands All the ones passing in the way}; they whistle and shake their head over the daughter of Jerusalem, Is she the city, they shall say, the crown of glory of gladness of all the earth? 

#### Lamentations 2:16 {opened wide against you their mouth All your enemies}. They whistled and gnashed their teeth. They said, We swallowed her down. Besides, this is the day which we expected; we found it, we saw it. 

#### Lamentations 2:17 The LORD did what he pondered. He completed his word which he gave charge from days of old. He demolished, and spared not, and he gladdened {over you the enemy}, He raised up high the horn of the one afflicting you. 

#### Lamentations 2:18 {yelled out Their heart} to the LORD, saying, O walls of Zion, lead down {as a rushing stream tears} day and night! And give soberness to yourself; neither let {keep quiet the pupil of your eye}! 

#### Lamentations 2:19 Rise up to meditate in the night! At the beginnings of your watch pour out {as water your heart} before the face of the LORD! Lift to him your hands for the lives of your infants, of the ones fainting from hunger at the corner of all the streets! 

#### Lamentations 2:20 Behold, O LORD, and look upon what you gleaned thus! Shall {eat the women} the fruit of their belly? Shall {be murdered infants nursing breasts}? Shall you kill in the sanctuary of the LORD the priest and prophet? 

#### Lamentations 2:21 {went to bed on the ground in the street The boy and old man}; my virgins and my young men went into captivity by broadsword; by famine you killed; in the day of your anger you cut up, you spared not. 

#### Lamentations 2:22 You called as in a day of holiday for my sojourners round about; and there was not in the day of anger of the LORD one being rescued and being left behind, as I prevailed, and I filled {my enemies all}. 

#### Lamentations 3:1 I am a man, one seeing poorness by a rod of his rage upon me. 

#### Lamentations 3:2 He took me; he led me away into darkness, and not light. 

#### Lamentations 3:3 Only against me he turned his hand the entire day. 

#### Lamentations 3:4 He aged my flesh and my skin; {my bones he broke}. 

#### Lamentations 3:5 He built against me, and he encircled my head, and troubled me. 

#### Lamentations 3:6 In dark places he settled me as dead ones of the eon. 

#### Lamentations 3:7 He built against me, and I shall not come forth. He weighed down my brass chain. 

#### Lamentations 3:8 Yes indeed, for though I shall cry out and yell, he shut out my prayer. 

#### Lamentations 3:9 He blocked up my ways; he obstructed my roads; he disturbed me. 

#### Lamentations 3:10 {a bear lying in wait He is} for me, as a lion in a secret place. 

#### Lamentations 3:11 He pursued me after I revolted, and caused me to cease. He established me for being obliterated. 

#### Lamentations 3:12 He stretched tight his bow, and he set up a stone target for me as the aim for the arrow. 

#### Lamentations 3:13 He brought {into my kidneys the poison from his quivers}. 

#### Lamentations 3:14 I became laughter to all my people, their psalm for the entire day. 

#### Lamentations 3:15 He filled me with bitterness; he intoxicated me with bile, 

#### Lamentations 3:16 and he knocked out {by a small stone my teeth}; he fed me ashes, 

#### Lamentations 3:17 and he thrust away {from peace my soul}. I forgot good things. 

#### Lamentations 3:18 And I said, {perished My victory}, and my hope from the LORD. 

#### Lamentations 3:19 I remembered because of my poorness, and of my persecution, of my bitterness, and of my bile. 

#### Lamentations 3:20 I shall be remembered, and {shall converse with me my soul}. 

#### Lamentations 3:21 This I will arrange into my heart; on account of this I will wait. 

#### Lamentations 3:22 The mercies of the LORD, for they finished not, for {failed not his charities}. 

#### Lamentations 3:23 The ones new in the morning; great is your trust. 

#### Lamentations 3:24 {is my portion The LORD}, said my soul, on account of this I will wait for him. 

#### Lamentations 3:25 The LORD is good to the ones waiting on him, the soul which shall seek him. 

#### Lamentations 3:26 It is good, and he shall wait and shall be still for the deliverance of the LORD. 

#### Lamentations 3:27 It is good for a man whenever he should lift a yoke from his youth. 

#### Lamentations 3:28 He will sit down alone, and will keep silent, for he lifted it upon himself. 

#### Lamentations 3:29 He shall put {in dust his mouth}; if perhaps there is hope. 

#### Lamentations 3:30 He will give {to the one hitting him his cheek}. He will be filled of scornings. 

#### Lamentations 3:31 For not into the eon shall the LORD thrust away. 

#### Lamentations 3:32 For the one he humbled he shall pity, according to the multitude of his mercy. 

#### Lamentations 3:33 He was not answered from his heart, and he humbled sons of man, 

#### Lamentations 3:34 to humble under his feet all the prisoners of the earth, 

#### Lamentations 3:35 to turn aside a judgment of a man over against the face of the highest, 

#### Lamentations 3:36 to condemn mankind in judging him, the LORD did not say it. 

#### Lamentations 3:37 Who thus spoke, and it came to pass, but the LORD did not give charge? 

#### Lamentations 3:38 From out of the mouth of the highest shall not come forth bad and good? 

#### Lamentations 3:39 Why does {grumble man a living}; a man concerning his sin? 

#### Lamentations 3:40 {was searched out Our way} and examined, and we should turn unto the LORD. 

#### Lamentations 3:41 We should lift up our hearts with our hands to the height in heaven. 

#### Lamentations 3:42 We sinned, we were impious, and you atoned not. 

#### Lamentations 3:43 You enveloped in rage, and banished us. You killed and spared not. 

#### Lamentations 3:44 You enveloped {with a cloud yourself} because of prayer to close my eyelids. 

#### Lamentations 3:45 And to be thrust away you put us in the midst of the peoples. 

#### Lamentations 3:46 {opened wide against us their mouth All our enemies}. 

#### Lamentations 3:47 Fear and stupefaction was to us; haughtiness and destruction. 

#### Lamentations 3:48 {releases of waters shall lead down My eye} upon the destruction of the daughter of my people. 

#### Lamentations 3:49 My eye was swallowed down and I shall not be quiet, to not be sober, 

#### Lamentations 3:50 until of which time {should look through and should behold the LORD} from out of heaven. 

#### Lamentations 3:51 My eye shall glean upon my soul because of all the daughters of the city. 

#### Lamentations 3:52 In hunting {hunted me as a sparrow my enemies} freely. 

#### Lamentations 3:53 They put to death {in the pit my life}, and they placed a stone upon me. 

#### Lamentations 3:54 {overflowed Water} upon my head. I said, I am thrust away. 

#### Lamentations 3:55 I called upon your name, O LORD, from out of {pit the lowermost}. 

#### Lamentations 3:56 My voice you heard; you should not hide your ears to my supplication. 

#### Lamentations 3:57 {for my help You approached} in the day in which I called upon you. You said to me, Do not fear! 

#### Lamentations 3:58 You adjudicated, O LORD, the punishments of my soul. You ransomed my life. 

#### Lamentations 3:59 You saw, O LORD, my disturbances. You judged my case. 

#### Lamentations 3:60 You beheld all their vengeance, and all their devices against me. 

#### Lamentations 3:61 You heard their scorning, all their devices against me; 

#### Lamentations 3:62 the lips of ones rising up against me, and their meditations against me the entire day; 

#### Lamentations 3:63 their sitting down, and their rising up. Look upon their eyes! 

#### Lamentations 3:64 You shall recompense to them a recompense, O LORD, according to the works of their hands. 

#### Lamentations 3:65 You shall recompense to them, while shielding {of my heart the trouble}. 

#### Lamentations 3:66 You shall pursue them in anger, and shall completely consume them beneath the heaven, O LORD. 

#### Lamentations 4:1 O how {shall be darkened the gold}, and {changed the silver good}; {were discharged stones holy} at the top of all the streets, 

#### Lamentations 4:2 even the {sons of Zion esteemed} being encouraged by gold, O how they are considered as {receptacles earthenware}, works of the hands of the potter. 

#### Lamentations 4:3 And indeed, dragons stripped the breasts, they nursed their cubs; the daughters of my people were for irretrievability as a sparrow in the wilderness. 

#### Lamentations 4:4 {cleaves The tongue of one nursing} to its throat in thirst. Infants ask for bread, {one snapping it there is not} for them. 

#### Lamentations 4:5 The ones eating the delicacies were removed in the streets. The ones having been suckled in scarlet were embracing dung. 

#### Lamentations 4:6 And {was magnified the lawlessness of the daughter of my people} over the lawlessness of Sodom, the place being eradicated as with promptness, and they did not toil in her hands. 

#### Lamentations 4:7 {were clean Her Nazarites}; {more than snow they radiated}; {more than milk they were purified}. {were above stone of sapphire Their broken pieces}, 

#### Lamentations 4:8 {darkened above lamp black their appearance}, they are not recognized in the streets; {was fixed their skin} against their bones; they are dried up, they were as wood. 

#### Lamentations 4:9 Better were the ones slain by the broadsword than the ones slain by hunger; they went being pierced by want of produce of the fields. 

#### Lamentations 4:10 The hands {women of pitying} boiled their children; they became for food to them in the destruction of the daughter of my people. 

#### Lamentations 4:11 The LORD completed his rage; he poured out the rage of his anger, and lit a fire in Zion, and it devoured her foundations. 

#### Lamentations 4:12 {believed not The kings of the earth}, all the ones dwelling, the ones living, that {shall enter an enemy and one afflicting} through the gates of Jerusalem, 

#### Lamentations 4:13 because of the sins of her prophets, and iniquities of her priests, the ones pouring out {blood just} in her midst. 

#### Lamentations 4:14 {were shaken Her watchmen} in the streets; they were tainted with blood in {not being able their}; they touched their garments with it. 

#### Lamentations 4:15 Separate from the unclean! Call them! Separate, separate, do not touch! for they were lit, and indeed, they were shaken. Say among the nations! In no way should they proceed to sojourn there. 

#### Lamentations 4:16 The person of the LORD was their portion; he shall not proceed to look upon them. The person of the priests they did not receive; {old men they did not show mercy on}. 

#### Lamentations 4:17 Yet in our being, {failed our eyes}. {for our help was in vain watching Our}. We watched unto a nation not delivering. 

#### Lamentations 4:18 They hunted our small ones to not go into our squares. {approached Our time}; {were fulfilled our days}; {is at hand our end}. 

#### Lamentations 4:19 {nimble were The ones pursuing us}, more than eagles of heaven. Upon the mountains they perched; in a wilderness they lie in wait for us. 

#### Lamentations 4:20 The breath of our face, the anointed one, the LORD was seized in our corruptions, of whom we said, In his shadow we shall live among the nations. 

#### Lamentations 4:21 Rejoice and be glad O daughter of Edom! the one dwelling upon the land of Uz! And indeed unto you shall go through the cup of the LORD. You shall be intoxicated and shall pour forth. 

#### Lamentations 4:22 {is vanished Your lawlessness}, O daughter of Zion. He shall not proceed unto the resettling you. He visited your lawlessness, O daughter of Edom; he revealed concerning your acts of impiety. 

#### Lamentations 5:1 Remember, O LORD, what happened to us! Look upon and behold our scorn! 

#### Lamentations 5:2 Our inheritance was converted over to aliens; our houses to strangers. 

#### Lamentations 5:3 {orphans We were}; there does not exist a father; our mothers are as widows. 

#### Lamentations 5:4 {our water for money We drank}; our wood {in barter came}. 

#### Lamentations 5:5 Unto our neck we were pursued; we tired; we were not rested. 

#### Lamentations 5:6 Egypt gave a hand; Assyria for their plenty. 

#### Lamentations 5:7 Our fathers sinned, and they do not exist; we {their violations of the law underwent}. 

#### Lamentations 5:8 Servants lorded over us; {one ransoming there is not} from out of their hand. 

#### Lamentations 5:9 With our lives we will carry in our bread from in front of the broadsword of the wilderness. 

#### Lamentations 5:10 Our skin {as an oven was darkened}; they were made to shrivel from the face of blasts of famine. 

#### Lamentations 5:11 {women in Zion They abased}, virgins in the cities of Judah. 

#### Lamentations 5:12 Rulers {by their hands were hanged}; elders were not extolled; 

#### Lamentations 5:13 chosen men {weeping took up}, and young men {in wood bearing weakened}. 

#### Lamentations 5:14 And old men {from the gate ceased}; chosen men {from their psalms ceased}. 

#### Lamentations 5:15 {rested up Joy of our heart}; {turned into mourning our dance}. 

#### Lamentations 5:16 {fell The crown of our head}; and woe to us for we sinned. 

#### Lamentations 5:17 On account of this {became grief grievous in our heart}; on account of this, {darkened our eyes}. 

#### Lamentations 5:18 Upon mount Zion, for it was obliterated, foxes went through in it. 

#### Lamentations 5:19 But you, O LORD, {into the eon shall dwell}; your throne is unto generation and generation. 

#### Lamentations 5:20 Why for victory shall you forget us? Will you forsake us unto the duration of days? 

#### Lamentations 5:21 Turn us to you! O LORD, and we shall be turned; and renew our days as before! 

#### Lamentations 5:22 For in thrusting away, you thrusted us away; you were provoked to anger against us, unto exceedingly.