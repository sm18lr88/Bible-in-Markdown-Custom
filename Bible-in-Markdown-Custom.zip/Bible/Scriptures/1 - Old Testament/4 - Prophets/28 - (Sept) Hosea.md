#### Hosea 1:1 The word of the LORD which came to Hosea, the son of Beeri, in the days of Uzziah, and Jotham, and Ahaz, and Hezekiah kings of Judah, and in the days of Jeroboam son of Joash king of Israel. 

#### Hosea 1:2 The beginning of the word of the LORD by Hosea. And {said the LORD} to Hosea, Proceed, take to yourself a wife of harlotry, and children of harlotry! because by fornicating {shall fornicate the land} away from going after the LORD. 

#### Hosea 1:3 And he went and took Gomer daughter of Diblaim; and she conceived, and bore to him a son. 

#### Hosea 1:4 And {said the LORD} to him, Call his name Jezreel! because yet a little and I will avenge the blood of Jezreel on the house of Judah, and I will cause to cease the kingdom of the house of Israel. 

#### Hosea 1:5 And it will be in that day I will break the bow of Israel in the valley of Jezreel. 

#### Hosea 1:6 And she conceived again, and she bore a daughter. And he said to him, Call the name of her, Not Being Shown Mercy! for in no way shall I proceed still to show mercy on the house of Israel; but by resisting I will resist them. 

#### Hosea 1:7 But the sons of Judah I will show mercy on, and I will deliver them by the LORD their God, and I will not deliver them by bow, nor by broadsword, nor by battle, nor by horses, nor by horsemen. 

#### Hosea 1:8 And she weaned Not Being Shown Mercy. And she conceived and bore a son. 

#### Hosea 1:9 And he said, Call his name, Not My People! because you are not my people, and I am not of you. 

#### Hosea 1:10 And shall be the number of the sons of Israel as the sand of the sea in which shall not be measured out nor shall be counted out. And it will be in the place of which it was said to them, {not my people You are}; they shall be called, Sons of the living God. 

#### Hosea 1:11 And shall be gathered the sons of Judah, and the sons of Israel together. And they shall appoint to themselves {sovereign one}. And they shall ascend from out of the land. For great is the day of Jezreel. 

#### Hosea 2:1 Speak to your brethren, My People, and to your sister, Being Shown Mercy! 

#### Hosea 2:2 Plead with your mother! Plead! for she is not my wife, and I am not her husband. And I will lift away her harlotry from in front of me, and her adultery from between her breasts; 

#### Hosea 2:3 so that I shall strip her naked, and restore her as the day of her birth; and I will set her as desolate, and I will arrange her as {land a waterless}, and I will kill her by thirst. 

#### Hosea 2:4 And {on her children in no way shall I show mercy}, for {children of harlotry it is}. 

#### Hosea 2:5 For {fornicated their mother}; {disgraced them the one bearing them}. For she said, I will go after my lovers, the ones giving to me my bread loaves, and my water, and my garments, and my linen bands, and my olive oil, and all as much as is fit for me. 

#### Hosea 2:6 On account of this, behold, I shut up her way with barbs, and I will block her ways, and her road in no way should she find. 

#### Hosea 2:7 And she shall pursue her lovers, and in no way shall she overtake them; and she shall seek them, and in no way shall she find them. And she shall say, I shall go and return to {husband my former}, for {good to me it was} then rather than now. 

#### Hosea 2:8 And she did not know that I gave to her the grain, and the wine, and the olive oil, and {silver multiplied} to her. But she {silver and gold things made} to Baal. 

#### Hosea 2:9 On account of this I will return and carry away my grain according to its season, and my wine in its time; and I will remove my garments and my linen bands so as to not cover her indecency. 

#### Hosea 2:10 And now I will uncover her uncleanness before her lovers, and not one shall rescue her from out of my hand. 

#### Hosea 2:11 And I will turn away all her gladness of her holiday feasts, and her new moons, and her Sabbaths, and all her festivals. 

#### Hosea 2:12 And I will remove her grapevine, and her fig-trees -- as much as she said, {my wages These are} which {gave to me my lovers}. And I will appoint them for a testimony. And {shall devour them the wild beasts of the field}, and the birds of the heaven, and the reptiles of the earth. 

#### Hosea 2:13 And I will take vengeance upon her for the days of the Baals, in which she sacrificed to them, and put on her ear-rings, and her hanging necklaces, and went after her lovers; but me she forgot, says the LORD. 

#### Hosea 2:14 On account of this, behold, I will wander her, and I will order her as desolate, and I will speak unto her heart. 

#### Hosea 2:15 And I will give to her her possessions from there, and the valley of Achor to open wide her understanding. And she shall be humbled there according to the days of her infancy, and according to the days of her ascending from out of the land of Egypt. 

#### Hosea 2:16 And it will be in that day, says the LORD, she shall call me, My husband, and shall not call me any longer, Baalim. 

#### Hosea 2:17 And I will lift away the names of the Baalim from her mouth, and in no way should {be remembered any longer their names}. 

#### Hosea 2:18 And I will ordain to them a covenant in that day with the wild beasts of the field, and with the birds of the heaven, and the reptiles of the earth. And {bow and broadsword and war I will break} from the earth, and I will settle upon hope. 

#### Hosea 2:19 And I shall espouse you to myself into the eon; and I shall espouse you to myself in righteousness, and in equity, and in mercy, and in compassions. 

#### Hosea 2:20 And I will espouse you to myself in trust. And you shall recognize the LORD. 

#### Hosea 2:21 And it will be in that day, says the LORD, I will give heed to the heaven, and the heaven shall give heed to the earth. 

#### Hosea 2:22 And the earth shall heed the grain, and the wine, and the olive oil; and they shall give heed to Jezreel. 

#### Hosea 2:23 And I will sow her to myself upon the earth; and I will love the one not being loved. And I will say to the one not my people, {my people You are}; and he shall say, {the LORD my God You are}. 

#### Hosea 3:1 And the LORD said to me, You go again and love a woman loving evil and an adulteress! even as {loves the LORD} the sons of Israel, and they look away unto strange gods, and are fond of cakes with dried grapes. 

#### Hosea 3:2 And I hired her to myself for fifteen pieces of silver, and a homer of barley, and a skin flask of wine. 

#### Hosea 3:3 And I said to her, {days Many} you shall sit down by me, and in no way should you commit harlotry, nor should you be to a man, and I will be unto you. 

#### Hosea 3:4 For {days many} {shall sit down the sons of Israel} with there not being a king, nor there being a ruler, nor there being a sacrifice, nor there being an altar, nor a priesthood, nor manifestations. 

#### Hosea 3:5 And after these things {shall return the sons of Israel}, and they shall seek the LORD their God, and David their king; and they shall be amazed over the LORD, and over his good things at the latter end of the days. 

#### Hosea 4:1 Hear the word of the LORD, O sons of Israel! For there is a case to the LORD against the ones dwelling the land, because there is no truth, nor mercy, nor full knowledge of God upon the land. 

#### Hosea 4:2 Curse, and lie, and murder, and fraud, and adultery -- it poured upon the earth, and {blood with blood they mingled}. 

#### Hosea 4:3 On account of this {shall mourn the land}, and shall be diminished with all the ones dwelling it; with the wild beasts of the field, and with the winged creatures of the heaven; and the fishes of the sea shall fail, 

#### Hosea 4:4 so that no one should adjudicate, nor {reprove should any one}; but my people are as a priest disputing; 

#### Hosea 4:5 and he shall weaken by day, and {shall weaken also the prophet} with you. {to night I likened your mother}. 

#### Hosea 4:6 {are likened My people} as ones not having knowledge. For since {full knowledge thrusted away you}, {will thrust you away even I} so as to not officiate as priest to me. And as you forgot the laws of your God, I shall forget your children. 

#### Hosea 4:7 According to their multitude, so they sinned against me. {their glory for dishonor I will appoint}. 

#### Hosea 4:8 The sins of my people they shall eat, and in their iniquities shall take their lives. 

#### Hosea 4:9 And it will be as the people, so also the priest; and I will avenge upon him his ways, and his deliberations I will recompense to him. 

#### Hosea 4:10 And they shall eat, but in no way should be filled up. They committed harlotry, and in no way should they be straightened. Because {the LORD they abandoned to watch for}. 

#### Hosea 4:11 Harlotry, and wine, and strong drink, took the heart of my people. 

#### Hosea 4:12 By their symbols they asked, and by their rods they reported to him. In a spirit of harlotry they were wandered, and they fornicated from their God. 

#### Hosea 4:13 Upon the tops of the mountains they were sacrificed, and upon the hills they were sacrificed underneath the oak, and white poplar, and {tree the overshadowing}, for good protection. Because of this {shall fornicate your daughters}, and your brides shall commit adultery. 

#### Hosea 4:14 And in no way shall I pay a visit unto your daughters whenever they should commit harlotry, nor unto your daughters-in-law whenever they should commit adultery. For they themselves {with the harlots blended together}, and {with the ones initiating rites were sacrificed}. And the people not perceiving closely joined with the harlot. 

#### Hosea 4:15 But you, O Israel, be not ignorant! And Judah, enter not into Gilgal, and ascend not unto the house of On, and swear not an oath, saying, {lives The LORD}! 

#### Hosea 4:16 For {as a heifer being in heat Israel was heated}. Now {will feed them the LORD} as a lamb in a broad space. 

#### Hosea 4:17 {was a partner of idols Ephraim}, he made obstacles to himself. 

#### Hosea 4:18 He took up with Canaanites, ones committing harlotry. They fornicated and loved dishonor of their neighing. 

#### Hosea 4:19 {a tumultuous wind You are} in her wings, and they shall be disgraced because of their altars. 

#### Hosea 5:1 Hear these things, O priests! And take heed, O house of Israel! And {O house of the king give ear}! For {against you is judgment}. For {a snare you were} in the Height, and as a net being stretched out upon Tabor, 

#### Hosea 5:2 which the ones catching the game firmly fastened; but I am your corrector. 

#### Hosea 5:3 I knew Ephraim, and Israel is not removed from me. For now Ephraim fornicated; Israel was defiled. 

#### Hosea 5:4 They gave not their deliberations to turn towards their God. For a spirit of harlotry is in the midst of them, and the LORD they knew not. 

#### Hosea 5:5 And {shall be humbled the insolence of Israel} unto his face; and Israel and Ephraim shall weaken in their iniquities; and {shall be weak also Judah} with them. 

#### Hosea 5:6 With sheep and calves they shall go to seek after the LORD, and in no way should they find him; he has turned aside from them. 

#### Hosea 5:7 For {the LORD they abandoned}; for {children alien} were born to them. Now {shall devour them the blight} and their lots of heritage. 

#### Hosea 5:8 Trump the trumpet upon the hills! Sound out upon the high places! Proclaim in the house of On! Benjamin is startled. 

#### Hosea 5:9 Ephraim {for extinction became} in the days of reproof. Among the tribes of Israel I showed to be trustworthy. 

#### Hosea 5:10 {became The rulers of Judah} as ones altering boundaries. Upon them I will pour out {as water my impulse}. 

#### Hosea 5:11 Ephraim tyrannized over his opponent; he trampled judgment, for he began to go after the vain things. 

#### Hosea 5:12 And I will be as a disturbance to Ephraim, and as a spur to the house of Judah. 

#### Hosea 5:13 And Ephraim beheld his disease, and Judah his grief. And Ephraim went to Assyria, and sent ambassadors to king Jareb; and he was not able to rescue; and in no way should there be a discontinuance of your grief. 

#### Hosea 5:14 For I am as a panther to Ephraim, and as a lion to the house of Judah. And I will seize by force, and I will go, and I will take, and there shall not be one rescuing. 

#### Hosea 5:15 I shall go and return unto my place until of which time they should be removed from view; and they shall seek my face. 

#### Hosea 6:1 In their affliction they will rise early to me, saying, We should go and return to the LORD our God, for he snatched us away, and he will heal us. He shall strike, and he shall dress our wounds. 

#### Hosea 6:2 He will heal us after two days, on the {day third} we shall rise up, and we shall live before him. 

#### Hosea 6:3 And we shall know, and shall pursue to know the LORD. As dawn readied, we shall find him; and he shall come to us as rain early and late to the earth. 

#### Hosea 6:4 What shall I do to you, O Ephraim? What shall I do to you, O Judah? For your mercy is as {cloud an early morning}, and as {dew early morning} going away. 

#### Hosea 6:5 On account of this I mowed you by the prophets; I killed them by the discourse of my mouth; and your judgment as light shall go forth. 

#### Hosea 6:6 For mercy I want, and not sacrifice; and full knowledge of God rather than whole burnt-offerings. 

#### Hosea 6:7 But they are as a man violating covenant. There they showed disdain of me. 

#### Hosea 6:8 Gilead is a city working vanities, disturbing water. 

#### Hosea 6:9 And your strength is as a man who is a maruader. {hid The priests}; {in the way they murdered} of Shechem; for {lawlessness they committed} in the house of Israel. 

#### Hosea 6:10 I beheld a cause for shuddering there, even the harlotry of Ephraim; {are defiled Israel and Judah}. 

#### Hosea 6:11 Begin to gather the vintage for yourself in my returning the captivity of my people! 

#### Hosea 7:1 In my healing Israel, then {was uncovered the injustice of Ephraim}, and the evil of Samaria. For they worked falsehoods; and a thief {to him entered}, {stripping him and a robber} in his way; 

#### Hosea 7:2 so that they be together in concert as men singing in their heart that {all their evils I remember}. Now {encircled them their deliberations}; {before my face they took place}. 

#### Hosea 7:3 In their evils they gladdened a king, and in their lies rulers. 

#### Hosea 7:4 All committing adultery are as an oven burning for baking; burning from the flame, from mixing together of the fat until its being leavened wholly. 

#### Hosea 7:5 In the days of our kings {began the rulers} to be enraged from wine; he stretched out his hands with pestilent ones. 

#### Hosea 7:6 For {were kindled as an oven their hearts} in their breaking down all the night; {of sleep Ephraim was filled}; in the morning it was kindled as {of a fire a flame}. 

#### Hosea 7:7 They were all heated as an oven, and they devoured their judges; all their kings are fallen; there was not one among them calling to me. 

#### Hosea 7:8 Ephraim {in his peoples is intermixed}; Ephraim became a cake baked in hot ashes not being turned over. 

#### Hosea 7:9 And {ate strangers} his strength, but he did not know it; and gray hairs broke out to him, and he did not know it. 

#### Hosea 7:10 And {shall be humbled the insolence of Israel} unto his face; but they turned not towards the LORD their God; and they sought not after him in all these things. 

#### Hosea 7:11 And Ephraim was as {dove a mindless}, not having a heart; Egypt he called upon, and unto Assyria they went. 

#### Hosea 7:12 As whenever they shall go I will put over them my net; as the birds of heaven, I will lead them down; I will correct them in the hearing of their affliction. 

#### Hosea 7:13 Woe to them, for they leaped back from me. Wretched are they, for they were impious against me. But I ransomed them; but they spoke ill against me with lies, 

#### Hosea 7:14 and yelled out not to me with their hearts, but only shrieked in their beds; for grain and wine they mutilated themselves. 

#### Hosea 7:15 They were corrected by me; I strengthened their arms; and against me they devised wicked things. 

#### Hosea 7:16 They returned unto nothing; they became as a bow being stretched tight; {shall fall by the broadsword their rulers} because of the stupidity of their tongue; this is their disparagement in the land of Egypt. 

#### Hosea 8:1 Into their bosom as land, as an eagle against the house of the LORD, because they violated my covenant, and against my law they were impious. 

#### Hosea 8:2 For me they shall cry out, O God, we have known you. 

#### Hosea 8:3 For Israel threw away good things; {an enemy they pursued}. 

#### Hosea 8:4 For themselves they made one to reign, and not through me. They ruled, and they did not make it known to me. With their silver and their gold they made to themselves idols, so that they should be utterly destroyed. 

#### Hosea 8:5 Cast off your calf, O Samaria! {is provoked My rage} against them. For how long will they in no way be able to cleanse themselves in Israel? 

#### Hosea 8:6 And {it the fabricator made}, and {not God it is}. Because {was wandering you your calf}, O Samaria. 

#### Hosea 8:7 For being destroyed by the wind they sowed, and their final end looks out for them; a sheaf not having strength to produce flour; and if even it should produce, strangers shall devour it. 

#### Hosea 8:8 Israel was swallowed down; now it became among the nations as {item a useless}. 

#### Hosea 8:9 For they ascended unto Assyria; {flourished again according to himself Ephraim}; {bribes he loved}. 

#### Hosea 8:10 On account of this they shall be delivered up among the nations; now I will take them, and they shall abate a little to anoint a king and rulers. 

#### Hosea 8:11 For Ephraim multiplied altars; for {sins became to him altars his beloved}. 

#### Hosea 8:12 I will write extra to him; his laws {as strange things were considered}, {altars the beloved}. 

#### Hosea 8:13 For if they should sacrifice a sacrifice, and should eat meats, the LORD shall not favorably receive them. Now he will remember their iniquities, and he shall avenge their sins. They {unto Egypt returned}. 

#### Hosea 8:14 And Israel forgot the one making him. And they built sacred precincts, and Judah multiplied cities being walled up. And I will send out fire unto his cities, and it shall devour his foundations. 

#### Hosea 9:1 Rejoice not, O Israel, nor be glad as the peoples! For you went whoring from the LORD your God. You loved gifts upon every threshing-floor of grain. 

#### Hosea 9:2 The threshing-floor and wine vat did not know them, and the wine lied to them. 

#### Hosea 9:3 They did not dwell in the land of the LORD; Ephraim dwelt in Egypt, and among the Assyrians {unclean things they shall eat}. 

#### Hosea 9:4 They offered not a libation to the LORD of wine, and were not delicious to him; their sacrifices were as bread of mourning to them; all the ones eating them shall be defiled. For their bread loaves for their lives shall not enter into the house of the LORD. 

#### Hosea 9:5 What will you do in the day of festival, and in the day of the holiday feast of the LORD? 

#### Hosea 9:6 On account of this, behold, they are gone from the misery of Egypt, and {shall look out for them Memphis}, and {shall entomb them Machmas}. Their silver -- ruin shall inherit it; thorn-bushes in their tents. 

#### Hosea 9:7 {have come The days of vengeance}; {have come the days of your recompense}; and Israel shall be afflicted as if the prophet, the one moved out of place, as a man carried by the wind. Because of the multitude of your iniquities {was multiplied your frenzy}. 

#### Hosea 9:8 The watchman of Ephraim was with God; the prophet {snare is a crooked} upon all his ways; {frenzy in the house of God they firmly fastened}. 

#### Hosea 9:9 They were corrupted according to the days of the hill. He shall remember their iniquities, he will punish their sins. 

#### Hosea 9:10 As a grape in the wilderness I found Israel; as a fig in {fig-tree the early} I beheld their fathers. They entered to Baal Peor, and they were separated for shame, and {became the things being abhorred} as the things being loved. 

#### Hosea 9:11 Ephraim as a bird was spread forth away, their glory of births and pangs and from conceptions. 

#### Hosea 9:12 For if even they should nourish their children, they shall be made childless of men; for {even a woe to them there is}; my flesh from them. 

#### Hosea 9:13 Ephraim, in which manner I saw, {as game rendered their children}; to lead out {for piercing their children}. 

#### Hosea 9:14 Give to them, O LORD! What will you give to them? Give to them a womb being childless and {breasts dry}! 

#### Hosea 9:15 All their evils are in Gilgal, for there I detested them. Because of the evils of their practices {out of my house I will cast them}. No way shall I proceed to love them. All their rulers resist persuasion. 

#### Hosea 9:16 Ephraim toiled, his roots were dried, {fruit any longer in no way should he bear}; therefore if they should bear, I shall kill the desires of their bellies. 

#### Hosea 9:17 {shall thrust them away God}, for they hearkened not to him; and they will be wanderers among the nations. 

#### Hosea 10:1 {is a grapevine having good vine branches Israel} her fruit prospering. According to the multitude of her fruits he multiplied the altars. According to the good things of his land he built monuments. 

#### Hosea 10:2 They portioned their hearts, now they shall be obliterated; he shall raze their altars, {shall languish their monuments}. 

#### Hosea 10:3 Because now they shall say, There is no king for us, for we feared not the LORD; but the king, what shall he do to us? 

#### Hosea 10:4 Speaking words, {excuses lying}; he shall ordain a covenant. {shall rise as wild grass Judgment} upon an uncultivated field. 

#### Hosea 10:5 To the calf of the house of On {shall sojourn the ones dwelling Samaria}; for {mourned his people} for it; and as they greatly embittered him, they shall rejoice over his glory, for he was displaced from him. 

#### Hosea 10:6 And {it for Assyria having tied}, they carried away tribute to king Jareb by a gift; Ephraim shall receive shame; Israel shall be ashamed in his counsel. 

#### Hosea 10:7 Samaria threw off her king as a stick upon the face of the water. 

#### Hosea 10:8 And {shall be lifted away the shrines of On}, even the sins of Israel. Thorn-bushes and thistles shall ascend upon their altars; and they shall say to the mountains, Cover us! and to the hills, Fall upon us! 

#### Hosea 10:9 From of which time the hills existed Israel sinned; there they stood. No way should it overtake them in the hill -- war {upon the children of iniquity came}. 

#### Hosea 10:10 To correct them -- and {shall be brought together peoples} against them in their being corrected for {two iniquities their}. 

#### Hosea 10:11 Ephraim -- a heifer being taught, loving altercation; but I shall come upon the best of her neck; I will conduct Ephraim; I will pass silently over Judah; {shall grow in strength against him Jacob}. 

#### Hosea 10:12 Sow to yourselves for righteousness! Gather the vintage for the fruit of life! Light for yourselves the light of knowledge! Inquire of the LORD until {comes the offspring of righteousness} to you! 

#### Hosea 10:13 Why did you pass over {in silence impiety}, and {of her iniquity gathered the vintage}? You ate {fruit false}, for you hoped in your chariots, in the abundance of your power. 

#### Hosea 10:14 And {shall rise up destruction} among your people, and all your places being walled around shall be undone. As the ruler Shalman departed out of the house of Jeroboam in the days of battle, {the mother upon children they dashed}; 

#### Hosea 10:15 so I will do to you, O house of Israel, in front of your evils. 

#### Hosea 11:1 Early they were disowned, {was disowned the king of Israel}; for Israel is an infant, and I loved him, and from out of Egypt I called back his children. 

#### Hosea 11:2 As I called them back, so they moved from in front of me; they {to the Baalim sacrificed}; and to the carved images they burned incense. 

#### Hosea 11:3 And I bound Ephraim; I took him upon my arm; and they knew not that I have healed them. 

#### Hosea 11:4 In corruption of men I stretched them with the bonds of my affections. And I will be to them as {slapping a man} upon his cheek; and I shall look to him; I will prevail to him. 

#### Hosea 11:5 Ephraim dwelt in Egypt, and Assyria he was his king, for he did not want to return. 

#### Hosea 11:6 And he weakened by the broadsword in his cities, and he rested with his hands; and they shall eat of their own deliberations. 

#### Hosea 11:7 And his people are hanging from the thing of his house; and God {against his esteemed shall be enraged}, and in no way should he exalt him. 

#### Hosea 11:8 How shall I deal with you, O Ephraim? Shall I shield you, O Israel? How shall I deal with you -- as Admah? Shall I appoint you even as Zeboim? {shall be converted My heart} in the same thing; {was disturbed my repentance}. 

#### Hosea 11:9 No way shall I act according to the anger of my rage. No way should I abandon Ephraim to be wiped away. Because {God I am}, and not man; {among you the holy one}, and I will not enter into the city. 

#### Hosea 11:10 {after the LORD I shall go}; as a lion he shall bellow; for he shall roar, and {shall be startled children of the waters}. 

#### Hosea 11:11 They shall be startled as a bird from out of Egypt, and as a dove from out of the land of the Assyrians; and I will restore them unto their houses, says the LORD. 

#### Hosea 11:12 {encircled me with a lie Ephraim}, and {with impious deeds the house of Israel and Judah}; but now {knew them God}, and {people a holy they shall be called} of God. 

#### Hosea 12:1 But Ephraim is an evil spirit. He pursued the burning wind the entire day. {empty and vain things He multiplied}. And {a covenant with the Assyrians he ordained}, and {olive oil in Egypt traded}. 

#### Hosea 12:2 And there is a case with the LORD against Judah, to punish Jacob; according to his ways and according to his practices he will recompense to him. 

#### Hosea 12:3 In the belly he caught the heel of his brother; and in his toils he grew in strength with God. 

#### Hosea 12:4 And he grew in strength with the angel, and he prevailed; they wept and beseeched me; in the house of On they found me. There it was spoken to them. 

#### Hosea 12:5 But the LORD God almighty will be his memorial. 

#### Hosea 12:6 And you {to your God shall return}; {mercy and judgment guard}, and approach to your God always! 

#### Hosea 12:7 Canaan, in his hand is a yoke of iniquity; {to tyrannize he loved}. 

#### Hosea 12:8 And Ephraim said, But I am rich, I have found respite for myself. All produce of his toils shall not be found in him, because of iniquities in which he sinned. 

#### Hosea 12:9 But I, the LORD your God, led you out of the land of Egypt; still I will settle you in tents as in the days of the holiday feast. 

#### Hosea 12:10 And I will speak by prophets, and I {visions multiplied}, and by the hands of prophets I was likened. 

#### Hosea 12:11 If {not Gilgal is}, then even {false were in Gilgal rulers sacrificing}, and their altars are as tortoise like heaps upon an uncultivated field. 

#### Hosea 12:12 And Jacob withdrew into the plain of Syria, and Israel served for a wife, and for a wife he guarded sheep. 

#### Hosea 12:13 And by a prophet the LORD led Israel from out of the land of Egypt, and by a prophet he was guarded. 

#### Hosea 12:14 Ephraim was enraged and provoked to anger, therefore his blood {upon him shall be poured out}, and {scorning his shall recompense the LORD to him}. 

#### Hosea 13:1 According to the word Ephraim {ordinances conceived} himself in Israel, and appointed to Baal, and died. 

#### Hosea 13:2 And now they proceeded to sin, and made for themselves molten castings of their silver, according to the image of idols, the works of fabricators being completed for them. They say, Sacrifice men, for the calves have ceased! 

#### Hosea 13:3 On account of this, they will be as {cloud an early morning}, and as {dew early morning} going away, as dust being blown away from the threshing floor, and as a vapor from tears. 

#### Hosea 13:4 But I the LORD your God, I led you from out of the land of Egypt, and {a god besides me you shall not know}, and {one delivering there is not} besides me. 

#### Hosea 13:5 I tended you in the wilderness in {land an uninhabited}. 

#### Hosea 13:6 According to their pastures, so they were filled unto fullness, and they exalted their hearts; because of this they forgot me. 

#### Hosea 13:7 And I will be to them as a panther, and as a leopard, according to the way of the Assyrians. 

#### Hosea 13:8 I will meet them as a bear being perplexed, and I will tear up the enclosure of their heart; and {shall devour them there the cubs of the forest}; and wild beasts of the field shall pull them apart. 

#### Hosea 13:9 In your corruption, O Israel, who will help? 

#### Hosea 13:10 Where is this your king? and let him preserve you in all your cities! Let him judge you! whom you said, Give to me a king and a ruler! 

#### Hosea 13:11 And I gave to you a king in my anger, and I sufficed in my rage. 

#### Hosea 13:12 A confederacy of injustice; Ephraim -- {being hidden his sin}. 

#### Hosea 13:13 Pangs as one giving birth shall come to him; he is {son your intelligent}, because now in no way should he stand in the destruction of children. 

#### Hosea 13:14 From the hand of Hades I shall rescue them; from death I will ransom them. Where is your punishment, O death? Where is your sting, O Hades? Consolation is hidden from my eyes. 

#### Hosea 13:15 For this, {between brethren he will separate}; {will bring up a burning wind the LORD} from out of the wilderness upon him, and he shall dry up his arteries; he shall make quite desolate his springs; he shall totally dry up his land, and all {items his desirable}. 

#### Hosea 13:16 Samaria shall be obliterated, for she withstood against her God. By the broadsword they shall fall, and the ones under their breasts shall be dashed, and the ones {in the womb having one of them} shall be torn up. 

#### Hosea 14:1 Return, O Israel, to the LORD your God! for you are weakened by your iniquities. 

#### Hosea 14:2 Take after your own words, and return to the LORD! Speak to him! so that you should not receive for your iniquities, and so that you should receive good things, and we will recompense the fruit of our lips. 

#### Hosea 14:3 Assyria in no way shall deliver us; upon a horse we shall not ascend; no longer in any way should we say, Our gods -- to the works of our hands. The one among you shall show mercy on the orphan. 

#### Hosea 14:4 I will repair their dwellings; I will love them confessedly, for {turned away my anger} from them; 

#### Hosea 14:5 and I will be as dew to Israel; he shall bloom as a lily, and shall cast his roots as Lebanon. 

#### Hosea 14:6 {shall go forth His branches}, and he will be as {olive a fruitful}, and his smell as Lebanon. 

#### Hosea 14:7 They shall return and sit under his protection; they shall live and shall be fixed firmly in grain, and they shall blossom as a grapevine. The memorial of him is as the wine of Lebanon. 

#### Hosea 14:8 To Ephraim, what is there to him yet and to idols? I humbled him, and I shall strengthen him. I am as a juniper being dense. From me your fruit has been found. 

#### Hosea 14:9 Who is wise, and perceives these things? discerning, and recognizes them? For straight are the ways of the LORD, and the just shall go by them; but the impious shall weaken in them.