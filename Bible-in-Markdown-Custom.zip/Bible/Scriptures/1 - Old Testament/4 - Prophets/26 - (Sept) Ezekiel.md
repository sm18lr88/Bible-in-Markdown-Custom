#### Ezekiel 1:1 And it came to pass in the thirtieth year, in the fourth month, the fifth of the month, and I was in the midst of the captivity by the river Chebar, and {were opened the heavens}, and I beheld visions of God. 

#### Ezekiel 1:2 On the fifth of the month, this is the {year fifth} of the captivity of king Jehoiakim, 

#### Ezekiel 1:3 and {came the word of the LORD} to Ezekiel, the son of Buzi the priest, in the land of the Chaldeans by the river Chebar; and {came upon me the hand of the LORD}. 

#### Ezekiel 1:4 And I beheld, and behold, a wind lifting up came from the north, and {cloud a great} with it, and brightness round about it, and fire flashing. And in the midst of it was as the vision of molten bronze in the midst of the fire, and brightness in it. 

#### Ezekiel 1:5 And in the midst was as a likeness of four living creatures. And this is their vision -- a likeness of a man was unto them. 

#### Ezekiel 1:6 And there were four faces to the one, and four wings to the one. 

#### Ezekiel 1:7 And their legs were straight; and {feathered their feet}; and there were sparks as flashing brass; and {were light their wings}. 

#### Ezekiel 1:8 And the hand of a man was beneath their wings, upon {four parts their}. And their faces and their wings, of the four, were being next to the other of the other. 

#### Ezekiel 1:9 And their wings were not turned in their proceeding; each {opposite their face went}. 

#### Ezekiel 1:10 And the likeness of their faces was as the face of a man, and a face of a lion from out of the right to the four; and the face of a calf from out of the left to the four; and the face of an eagle to the four. 

#### Ezekiel 1:11 And their wings were stretching out above; to the four each, two being yoked together to one another, and two covered up upon their body. 

#### Ezekiel 1:12 And each to the other {in front of him went}. Where ever {was the spirit} going, they went, and they did not turn. 

#### Ezekiel 1:13 And in the midst of the living creatures was a vision as of coals of fire burning, as the appearance of lamps twisting in the midst of the living creatures. And brightness was of the fire, and from out of the fire went forth as lightning. 

#### Ezekiel 1:14 And the living creatures were running and returning as the appearance of the lightning. 

#### Ezekiel 1:15 And I beheld, and behold, there was {wheel one} upon the earth being next to the living creatures, next to the four. 

#### Ezekiel 1:16 And the sight of the wheels and their action was as the sight of Tharsis stone. And there was {likeness one} to the four; and their work was as if it may be a wheel in a wheel. 

#### Ezekiel 1:17 Upon {four parts their} they went; they did not turn in their going, 

#### Ezekiel 1:18 and yet their backs and height was to them. And I beheld them, and their backs full of eyes, round about to the four. 

#### Ezekiel 1:19 And in the going, the living creatures went, the wheels being next to them. And in the lifting away {the living creatures from the earth lifted away the wheels}. 

#### Ezekiel 1:20 Where ever {was the cloud} there the spirit was to go; {went the living creatures}, and the wheels also lifted away with them; because spirit of life was in the wheels. 

#### Ezekiel 1:21 In their going, the wheels went; and in their standing, the wheels stood; and in their lifting away from the earth, the wheels lifted away with them; for spirit of life was in the wheels. 

#### Ezekiel 1:22 And the likeness above the head of the living creatures was as a firmament, as the vision of ice being stretched out over their wings on top. 

#### Ezekiel 1:23 And under the firmament their wings were stretching out flapping, the other to the other; to each two covering their bodies. 

#### Ezekiel 1:24 And I heard the sound of their wings in their going, as the sound {water of much}, as the sound of a worthy one in their going; a sound of the word as a sound of a camp; and in their standing {rested their wings}. 

#### Ezekiel 1:25 And behold, a sound far above the firmament, 

#### Ezekiel 1:26 of the one being above their head, as a vision of stone of sapphire with a likeness of a throne upon it; and upon the likeness of the throne was a likeness as a form of a man from above. 

#### Ezekiel 1:27 And I beheld as an appearance of molten bronze, as a vision of fire within it round about from the vision of the loin and up; and from the vision of the loin unto below I beheld as a vision as of fire, and its brightness round about. 

#### Ezekiel 1:28 As the vision of a bow whenever it might be in the cloud in a day of rain, thus was the position of the brightness round about. This is the vision of the likeness of the glory of the LORD. And I beheld, and I fell upon my face, and I heard a voice speaking. 

#### Ezekiel 2:1 And he said to me, O son of man, stand upon your feet, and I shall speak to you! 

#### Ezekiel 2:2 And came upon me a spirit. And it took me up, and lifted me away, and stood me upon my feet. And I heard him speaking to me. 

#### Ezekiel 2:3 And he said to me, O son of man, I shall send you to the sons of Israel, of the ones rebelling against me; the ones who rebelled against me. They and their fathers disregarded me, until today's day. 

#### Ezekiel 2:4 And {sons harsh and hard-hearted} -- I shall send you to them. And you shall say to them, Thus says the Lord the LORD. 

#### Ezekiel 2:5 If it is so that they should hearken or be terrified, for {house it is a rebellious}, yet shall they know that {a prophet you are} in the midst of them. 

#### Ezekiel 2:6 And you, O son of man, should not be afraid of them, nor be startled by their face, for they shall be heated, and shall rise up together against you round about. And {in the midst of scorpions you dwell}. {their words You should not fear}, and before their face you should not be startled, for {house it is a rebellious}. 

#### Ezekiel 2:7 And you shall speak my words to them, for surely they shall hear or be terrified; for {house a rebellious it is}. 

#### Ezekiel 2:8 And you, O son of man, hearken to the one speaking to you! Be not rebellious as the {house rebellious}! Gape wide your mouth, and eat what I give to you! 

#### Ezekiel 2:9 And I beheld, and behold, a hand stretched out to me, and in it a roll of a scroll. 

#### Ezekiel 2:10 And he unrolled it in my presence, and was in it things being written on the front and the rear; and it had written on it a lamentation, and a strain, and a woe. 

#### Ezekiel 3:1 And he said to me, O son of man, eat what ever you should find! Eat this roll, and go and speak to the sons of Israel! 

#### Ezekiel 3:2 And he opened wide my mouth, and fed me this roll. 

#### Ezekiel 3:3 And he said to me, O son of man, your mouth shall eat, and your belly shall be filled of this roll, of the one being given to you. And I ate it, and it became in my mouth as {honey sweet}. 

#### Ezekiel 3:4 And he said to me, O son of man, proceed and enter to the house of Israel, and speak my words to them! 

#### Ezekiel 3:5 For not as to a people of thick lips and speaking an unknown language are you sent to the house of Israel; 

#### Ezekiel 3:6 nor to {peoples many} of foreign languages, or foreign tongues, nor {dense in tongue being}, whose {you hear not words}. But if to such I sent you, these would have listened to you. 

#### Ezekiel 3:7 But the house of Israel in no way shall want to listen to you; for they do not consent to listen to me. For all the house of Israel is contentious and hard-hearted. 

#### Ezekiel 3:8 And behold, I have imputed your face mighty against their faces; and your victory shall prevail against their victory. 

#### Ezekiel 3:9 And it shall be always more strong than a rock. You should not fear from them, nor should you be terrified before their face; for {house a rebellious it is}. 

#### Ezekiel 3:10 And he said to me, O son of man, all the words which I have spoken with you, take into your heart, and {with your ears hearken}! 

#### Ezekiel 3:11 And proceed, enter unto the captivity, to the sons of your people! And you shall speak to them, and you shall say to them, Thus says the Lord, the LORD; Surely they shall hear, surely they shall give way. 

#### Ezekiel 3:12 And {took me up spirit}, and I heard from behind me a sound {quake of a great}, saying, Blessed be the glory of the LORD from out of his place. 

#### Ezekiel 3:13 And I heard a sound of the wings of the living creatures flapping one to the other; and the sound of the wheels next to them, and the sound of the {quake great}. 

#### Ezekiel 3:14 And the spirit lifted me away, and took me; and I went elevated by impulse of my spirit; and the hand of the LORD came {upon me fortified}. 

#### Ezekiel 3:15 And I entered to the captivity elevated; and I went around the ones dwelling by the river Chebar, the ones being there; and I stayed there seven days, behaving in the midst of them. 

#### Ezekiel 3:16 And it came to pass after the seven days, and {came the word of the LORD} to me, saying, 

#### Ezekiel 3:17 O son of man, {watchman I have appointed you} to the house of Israel, and you shall hear {from out of my mouth the word}; and you shall threaten them by me. 

#### Ezekiel 3:18 In my saying to the lawless one, To death you shall be put to death; and you do not give orders to him, nor spoke to give orders to the lawless one, to turn from {ways his unjust}, so that he should live; that lawless one {in his iniquity shall die}, and his blood {from out of your hand I shall require}. 

#### Ezekiel 3:19 And if you should give orders to the lawless one, and he should not turn from his lawlessness, nor {way his unjust}; that lawless one {in his iniquity shall die}, and you {your soul shall rescue}. 

#### Ezekiel 3:20 And in the turning of a just man from his righteousness, and he should commit a transgression, and I give torment to his face, and he dies, but you did not give orders to him; then in his sins he dies, for in no way {be remembered shall his righteousness} which he did, and his blood {from out of your hand I shall require}. 

#### Ezekiel 3:21 {you But if} give orders to the just man to not sin, and he should not sin, the just man {to life shall live}, for you warned him, and you {your own soul shall have rescued}. 

#### Ezekiel 3:22 And {came to pass there upon me the hand of the LORD}. And he said to me, Rise up, and go forth into the plain! and there it shall be spoken to you. 

#### Ezekiel 3:23 And I rose up and went forth to the plain. And behold, there the glory of the LORD stood as the glory which I beheld by the river Chebar. And I fell upon my face. 

#### Ezekiel 3:24 And {came upon me spirit}, and stood me upon my feet, and spoke to me, and said to me, Enter and be locked up in the midst of your house! 

#### Ezekiel 3:25 And you, O son of man, behold, {were appointed for you bonds}, and they shall tie you with them, and in no way shall you come forth from the midst of them. 

#### Ezekiel 3:26 And {your tongue I shall tie} to your throat, and you shall become mute, and you will not be to them for a man reproving; for {house a rebellious it is}. 

#### Ezekiel 3:27 And in my speaking to you, I shall open your mouth, and you shall say to them, Thus says the Lord the LORD; The one hearing, let him hear! and the one resisting persuasion, let him resist persuasion! for {house a rebellious it is}! 

#### Ezekiel 4:1 And you, O son of man, take unto yourself a brick! and you shall put it before your face,; and you shall diagram upon it the city of Jerusalem. 

#### Ezekiel 4:2 And you shall put {against it an encompassment about}; and you shall build {against it battlements}; and you shall put around upon it a siege mound; and you shall put {upon it camps}, and shall order the range of weapons round about. 

#### Ezekiel 4:3 And you, take to yourself a frying pan of iron! And you shall make it a wall of iron between you and between the city. And you shall prepare your face against it, and it will be for a siege, and you shall besiege it. {is a sign This} to the sons of Israel. 

#### Ezekiel 4:4 And you shall go to sleep upon {side your left}, and you shall put the iniquities of the house of Israel upon it, according to the number of the days which you shall sleep upon it. And you shall take their iniquities. 

#### Ezekiel 4:5 And I have appointed to you the two things for their iniquities for a number of days -- ninety and three hundred days; and you shall take the iniquities of the house of Israel. 

#### Ezekiel 4:6 And you shall complete these, and then go to sleep upon {side your right}, and you shall take the iniquities of the house of Judah -- forty days; a day for a year is established to you. 

#### Ezekiel 4:7 And for the siege of Jerusalem you shall prepare your face, and {your arm you shall stiffen}, and you shall prophesy against it. 

#### Ezekiel 4:8 And I, behold, I have appointed for you bonds, and you shall not be turned from your one side unto your other side, until of which time {should be completed the days of your siege}. 

#### Ezekiel 4:9 And you, take to yourself wheat, and barley, and beans, and lentils, and millet, and wild oats! And put them into {container one earthenware}, and make them {for yourself into bread loaves}! And according to the number of the days which you slept upon your side -- ninety and three hundred days -- you shall eat them. 

#### Ezekiel 4:10 And your food which you shall eat by weight is twenty shekels a day; from time to time you shall eat them. 

#### Ezekiel 4:11 And {water by measure you shall drink}; the sixth of the hin {from time to time you shall drink}. 

#### Ezekiel 4:12 And a cake baked in hot ashes of barley -- you shall eat them baked in dung, {of the dung of a human you shall hide them in the coals} before their eyes. 

#### Ezekiel 4:13 Thus says the LORD God of Israel; So shall {eat the sons of Israel} unclean among the nations which I cast them. 

#### Ezekiel 4:14 And I said, By no means, O LORD God of Israel, since my soul has not been defiled in uncleanness; and {decaying flesh and that taken by wild beasts I have not eaten} from my birth until the present; nor has {entered into my mouth any meat profane}. 

#### Ezekiel 4:15 And he said to me, Behold, I give to you dung of oxen instead of the dung of humans, and you shall make bread loaves upon them. 

#### Ezekiel 4:16 And he said to me, O son of man, behold, I shall break the reliance of bread in Jerusalem, and they shall eat bread by weight and in lack; and {water by measure and unto extinction they shall drink}; 

#### Ezekiel 4:17 so that {lacking they should be} of bread and water; and {shall be obliterated a man and his brother}; and they shall melt away in their iniquities. 

#### Ezekiel 5:1 And you, O son of man, take to yourself {broadsword a sharp} for a razor of a barber! You shall acquire it to yourself, and you shall bring it upon your head, and upon your beard. And you shall take a yoke balance scale of weights, and you shall part them. 

#### Ezekiel 5:2 A fourth part {in fire you shall kindle} in the middle of the city, according to the fullness of the days of the siege. And you shall take a fourth part and shall incinerate it in the midst of it. and a fourth part you shall cut in pieces with the broadsword round about it. And a fourth part you shall disperse to the wind; for {a sword I shall empty out} after them. 

#### Ezekiel 5:3 And you shall take from there a few in number, and shall wrap them in your wrapping. 

#### Ezekiel 5:4 And from out of these you shall take still more, and shall toss them into the midst of the fire, and shall incinerate them by fire; {from it shall come forth and fire}, and you shall say to all the house of Israel, 

#### Ezekiel 5:5 Thus says Adonai the LORD; This is Jerusalem; {in the midst of the nations I have placed her}, and the ones round about her place. 

#### Ezekiel 5:6 And you shall tell of my ordinances to the lawless one of the nations, and my laws to the lawless of the places round about her; because {my ordinances they thrust away}, and in my laws they did not go by them. 

#### Ezekiel 5:7 On account of this, thus says Adonai the LORD; Because your opportunity for lawlessness is from the nations round about you, and in my laws you did not go, and my ordinances you did not observe, but not even according to the ordinances of the nations round about you did you observe; 

#### Ezekiel 5:8 on account of this, Thus says Adonai the LORD; Behold, I am against you, and I shall execute {in the midst of you judgment} before the nations. 

#### Ezekiel 5:9 And I shall do among you what I have not done, and I shall not do likened to them again against all your abominations. 

#### Ezekiel 5:10 On account of this, fathers shall eat the children in your midst, and children shall eat fathers. And I shall execute {among you judgments}; and I shall scatter all the rest of you unto every wind. 

#### Ezekiel 5:11 On account of this, as I live, says Adonai the LORD; Assuredly, because {my holy things you defiled} in all your loathsome things, and in all your abominations, I also thrust you away; {will not spare my eye}, and I shall not show mercy. 

#### Ezekiel 5:12 The fourth part of you {by plague shall be consumed}; and a fourth part of you {by famine shall be finished off} in your midst; and a fourth part of you {unto every wind will be dispersed}; and a fourth part of you {by the broadsword shall fall} round about you; and a sword I shall empty out after them. 

#### Ezekiel 5:13 And {shall be exhausted my rage}, and my anger against them. And I shall enjoin, and you shall know, because I the LORD have spoken in my zeal in my exhausting my anger against them. 

#### Ezekiel 5:14 And I shall make you into a wilderness, even your daughters round about you, in the presence of all traveling through. 

#### Ezekiel 5:15 And you will be bemoaned and wretched among the nations round about you, in my executing among you judgments in anger and in rage, and in vengeance of rage. I the LORD have spoken. 

#### Ezekiel 5:16 In my sending the arrows of famine upon them, then they will be in want, and I shall send them to ruin you. And {famine I shall gather} unto you, and I shall break the reliance of your bread. 

#### Ezekiel 5:17 And I shall send out against you famine and {wild beasts ferocious}, and I shall punish you; and plague and blood shall go through upon you; and a sword I shall bring upon you. I the LORD have spoken. 

#### Ezekiel 6:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 6:2 O son of man, fix your face upon the mountains of Israel, and prophesy against them! 

#### Ezekiel 6:3 And you shall say, O mountains of Israel, hear the word of Adonai the LORD! Thus says Adonai the LORD to the mountains, and to the hills, and to the ravines, and to the groves; Behold, I bring upon you a broadsword, and {will be utterly destroyed your high places}. 

#### Ezekiel 6:4 And {will be broken down your altars and your sacred precincts}. And I will throw down your slain before your idols. And I shall offer the corpses of the sons of Israel in front of their idols. 

#### Ezekiel 6:5 And I shall scatter your bones round about your altars. 

#### Ezekiel 6:6 In all your house the cities shall be made quite desolate, and the high places shall be obliterated, so that {shall be utterly destroyed your altars}, and {shall be broken and caused to cease your idols}, and {shall be lifted away your sacred precincts}, and {shall be wiped away your works}. 

#### Ezekiel 6:7 And {shall fall slain ones} in your midst, and you shall realize that I am the LORD. 

#### Ezekiel 6:8 And I shall leave behind some in the taking place of your ones escaping from the broadsword among the nations, and in your being dispersed in the places. 

#### Ezekiel 6:9 And {shall remember me the ones escaping of yours} among the nations of which they were taken captive there. I have sworn against their heart, against the one fornicating from me; and with their eyes fornicating after their practices. And they shall smite against their faces for the evils which they did in all their abominations. 

#### Ezekiel 6:10 And they shall realize that I the LORD {not for nothing have spoken to do against them all these evils}. 

#### Ezekiel 6:11 Thus says the LORD; Clap with the hand, and stamp with the foot, and say, Well done, over all the abominations of the house of Israel! By the broadsword, and by plague, and by famine they shall fall. 

#### Ezekiel 6:12 The one far away {by plague shall come to an end}. And the one near {by the broadsword shall fall}. And the one being left behind, and the one being compassed by siege {by famine will be finished off}. And I shall exhaust my anger against them. 

#### Ezekiel 6:13 And you shall know that I am the LORD in {being your slain} in the midst of your idols, round about your altars, upon every {hill high}, and on all the tops of the mountains, and underneath {tree every shady}, underneath every {oak bushy}, of which they offered there a scent of pleasant aroma to all their idols. 

#### Ezekiel 6:14 And I shall stretch out my hand against them, and I shall make the land for extinction; even {for ruin from the wilderness of Diblath} of all their habitation. And you shall realize that I am the LORD. 

#### Ezekiel 7:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 7:2 And you, O son of man, thus says Adonai the LORD to the land of Israel; End is come; the end is come upon the four wings of the land. 

#### Ezekiel 7:3 {is come The end} now; the end to you. And I shall send my rage. I am against you, and I shall punish you in your ways, and I shall impute against you all your abominations. 

#### Ezekiel 7:4 {will not spare My eye} over you, nor shall I show mercy. For {your way against you I shall impute}, and your abominations {in the midst of you will be}. And you shall know that I am the LORD. 

#### Ezekiel 7:5 For thus says Adonai the LORD; An evil, one evil; Behold, it is at hand. 

#### Ezekiel 7:6 The end is come, {is come the end} awakened against you. 

#### Ezekiel 7:7 Behold, {is come the wreathen circle} upon you, the one dwelling the land. {is come The time}, {has approached the day}, not with tumult nor with pangs. 

#### Ezekiel 7:8 Now nearly I will pour out my anger upon you, and I will complete my rage against you, and I will judge you in your ways, and I will impute against you all your abominations. 

#### Ezekiel 7:9 {shall not spare My eye}, nor shall I show mercy. According to your ways {against you I will impute}, and your abominations {in your midst will be}. And you shall realize that I am the LORD, the one striking. 

#### Ezekiel 7:10 Behold, the day of the LORD is come, the rod has bloomed. 

#### Ezekiel 7:11 The insolence has risen up, and it will break the reliance of the lawless one, and not with a tumult nor with anxiety. 

#### Ezekiel 7:12 {is come The time}; behold, the day. {the one acquiring things Let not} rejoice! and {the one selling things let not} wail! for wrath for all the magnitude of it. 

#### Ezekiel 7:13 For the one acquiring {to the thing selling shall not return}; and still in the life of their living, that the vision is for all their multitude -- it shall not return, and a man in the eyes {his life shall not hold}. 

#### Ezekiel 7:14 Trump with the trumpet, and judge all things! But there is not one going to the war, for my wrath is upon all her multitude. 

#### Ezekiel 7:15 The broadsword from outside, and the famine and plague from inside. The one in the plain {by a broadsword shall come to an end}, and the ones in the city {by famine and plague shall end}. 

#### Ezekiel 7:16 And {shall be escaped the ones escaping of them}, and they will be upon the mountains as a pigeon meditating. And {all I will kill}, each in his iniquities. 

#### Ezekiel 7:17 All hands shall be enfeebled, and all thighs shall be tainted in wetness. 

#### Ezekiel 7:18 And they shall gird on sackcloths, and {shall cover them stupefaction}. And upon every face shame will be upon them, and upon every head baldness. 

#### Ezekiel 7:19 Their silver shall be tossed in the squares, and their gold shall be spurned. Their silver and their gold shall not be able to rescue them in a day of wrath of the LORD. Their souls in no way shall be satisfied, and their bellies shall not be filled; because the torment for their iniquities took place. 

#### Ezekiel 7:20 A choice ornament for pride -- they made them; and images of their abominations they made from them. Because of this I have given them to them for uncleanness. 

#### Ezekiel 7:21 And I will deliver them into the hands of strangers to tear them in pieces; and to the pestilent ones of the earth for spoils. And they shall profane them. 

#### Ezekiel 7:22 And I will turn my face from them, and they shall defile my overseeing, and they shall enter to them unguardedly, and profane them. 

#### Ezekiel 7:23 And they shall produce befouling, because the land is full of judgments of blood, and the city full of lawlessness. And I will bring evils of nations, and they shall inherit their houses. 

#### Ezekiel 7:24 And I will turn the neighing of their strength; and {shall be defiled their holy things}. 

#### Ezekiel 7:25 Making an atonement shall come, and one shall seek peace, and it will not be. 

#### Ezekiel 7:26 Woe upon woe will be, and message upon message will be; and {shall be sought a vision} from a prophet, and the law shall be lost of the priest, and counsel from the elders; the king shall mourn, 

#### Ezekiel 7:27 and the ruler shall put on extinction, and the hands of the people of the land shall be disabled. According to their ways I will do to them, and in their judgments I will punish them; and they shall know that I am the LORD. 

#### Ezekiel 8:1 And it came to pass in the sixth year, in the sixth month, the fifth of the month, I was sitting in my house, and the elders of Judah were sitting down before me. And came upon me the hand of Adonai the LORD. 

#### Ezekiel 8:2 And I beheld, and behold, a likeness of a man; from his loin, and unto below as fire; and from his loin and above him as the vision of brightness, as an appearance of molten bronze. 

#### Ezekiel 8:3 And he stretched out a likeness of a hand, and he took me up by the decorative hem of my top. And {took me spirit} in between the earth and between the heaven, and led me unto Jerusalem in a vision of God, unto the thresholds of the {gate inner} looking to the north of which was the monument of the acquirer. 

#### Ezekiel 8:4 And behold, {was there glory of the LORD God of Israel}, according to the vision which I beheld in the plain. 

#### Ezekiel 8:5 And he said to me, O son of man, look up with your eyes towards the north. And I looked up with my eyes towards the north. And behold, from the north at the gate, the one towards the east of the altar, was the image of jealousy; this was in the entering it. 

#### Ezekiel 8:6 And he said to me, O son of man, do you see what these do? {lawless deeds the great} which the house of Israel does here to keep at a distance from my holy places? And still you shall see {lawless deeds greater}. 

#### Ezekiel 8:7 And he brought me unto the thresholds of the courtyard. And I saw, and behold, {opening one} in the wall. 

#### Ezekiel 8:8 And he said to me, O son of man, dig in the wall! And I dug in the wall. And behold, a door. 

#### Ezekiel 8:9 And he said to me, Enter, and see the {lawless deeds evil} which these do here! 

#### Ezekiel 8:10 And I entered and I saw. And behold, every likeness of a crawling thing and a beast, vain abominations, and all the idols of the house of Israel, being diagramed upon the wall round about wholly. 

#### Ezekiel 8:11 And seventy men of the elders of the house of Israel, and Jaazaniah the son of Shaphan standing before their face; and each {his incense pan had} in the hand; and the vapor of the incense ascended. 

#### Ezekiel 8:12 And he said to me, You have seen, O son of man, what the elders of the house of Israel do in darkness, each of them in {room hidden their}; because they said, {does not see the LORD}; the LORD has abandoned the earth. 

#### Ezekiel 8:13 And he said to me, Still you will see {lawless deeds greater} which these do. 

#### Ezekiel 8:14 And he brought me unto the thresholds of the gate of the house of the LORD, of the one looking to the north. And behold, there women were sitting down wailing Tammuz. 

#### Ezekiel 8:15 And he said to me, You have seen, O son of man, and still you shall see {practices greater} than these. 

#### Ezekiel 8:16 And he brought me into the courtyard of the house of the LORD, the inner courtyard. And upon the thresholds of the temple of the LORD between the columned porch and between the altar were about twenty and five men with their posteriors towards the temple of the LORD, and their faces before the east. And these did obeisance according to the east to the sun. 

#### Ezekiel 8:17 And he said to me, You have seen, O son of man, is it a small thing to the house of Judah to commit the lawless deeds which they have done here? For they filled the land of lawlessness, and returned to provoke me to anger. And behold, these stretch out the vine branch as ones sneering. 

#### Ezekiel 8:18 And I shall deal with them with rage. {shall not spare My eye}, nor shall I show mercy, and should they call in my ears {voice with a great}, even I will not listen to them. 

#### Ezekiel 9:1 And he shouted aloud into my ears {voice with a great}, saying, {has approached The punishment of the city}. And each had the items for the devastation in his hand. 

#### Ezekiel 9:2 And behold, there were six men coming from the way of the {gate high}, of the one looking to the north. And each had a hewing axe for devastation in his hand; and one man in the midst of them was clothed in a foot length robe, and there was a belt of sapphire upon his loin. And they entered and stood next to the altar of brass. 

#### Ezekiel 9:3 And the glory of the God of Israel ascended from the cherubim, (the glory being upon them,) into the open air of the house. And he called the man being clothed with the foot length robe, who had {upon his loin the belt}. 

#### Ezekiel 9:4 And the LORD said to him, Go through the midst of the city, and the midst of Jerusalem, and put the sign upon the foreheads of the men! of the ones groaning, and of the ones being grievously afflicted over all the lawless deeds, the ones taking place in the midst of them. 

#### Ezekiel 9:5 And he said to these in my hearing, Go into the city behind him and smite! And you should not spare your eyes, and you should not show mercy. 

#### Ezekiel 9:6 An older man, and a young man, and a virgin, and infants, and women -- kill unto wiping out! But upon all upon whom there is the sign, you should not approach. And {from my holy places begin}! And they began with the men of the elders who were inside in the house. 

#### Ezekiel 9:7 And he said to them, Defile the house, and fill the ways of the dead, and {the ones going forth smite}! 

#### Ezekiel 9:8 And it came to pass in their smiting, that I fell upon my face, and I yelled out, and said, Alas, Adonai, O LORD, do you wipe away the remnant of Israel in the pouring out of your rage upon Jerusalem? 

#### Ezekiel 9:9 And he said to me, The iniquity of the house of Israel and Judah has been magnified very exceedingly. For {was filled the land peoples of many}, and the city was filled with iniquity and uncleanness. For they say, The LORD has abandoned the earth, {does not inspect it the LORD}. 

#### Ezekiel 9:10 And {shall not spare my eye}, nor shall I show mercy. {their ways against their heads I have imputed}. 

#### Ezekiel 9:11 And behold, the man, the one being clothed with the foot length robe, and having {tied around the belt} his loin, even answered saying, I have done as you gave charge to me. 

#### Ezekiel 10:1 And I beheld, and behold, upon the firmament above the head of the cherubim was {stone of sapphire a likeness of a throne} over them. 

#### Ezekiel 10:2 And he said to the man clothed by the robe, Enter into the midst of the wheels, of the ones underneath the cherubim, and fill your hands full of coals of fire from out of the midst of the cherubim, and scatter them upon the city! And he entered before me. 

#### Ezekiel 10:3 And the cherubim stood at the right of the house, in the entering of the man. And the cloud filled the {courtyard inner}. 

#### Ezekiel 10:4 And {departed the glory of the LORD} from the cherubim into the open air of the house. And {was filled the house} with the cloud, and the courtyard was filled of the brightness of the glory of the LORD. 

#### Ezekiel 10:5 And the sound of the wings of the cherubim was heard unto {courtyard the outer}, as the sound of God Saddai speaking. 

#### Ezekiel 10:6 And it came to pass in his giving charge to the man, to the one being clothed in the {robe holy}, saying, Take fire from out of the midst of the wheels, from the place between the cherubim! And he entered and stood next to the wheels. 

#### Ezekiel 10:7 And {stretched out the cherub} his hand into the midst of the fire, of the one being in the midst of the cherubim. And he took, and put it unto the hands of the one being clothed by the {robe holy}. And he took it and came forth. 

#### Ezekiel 10:8 And I beheld the cherubim having likenesses of the hands of men from beneath their wings. 

#### Ezekiel 10:9 And I beheld, and behold, four wheels stood next to the cherubim, {wheel one} being next to {cherub one}, and {wheel one} being next to {cherub one}. And the appearance of the wheels was as the appearance {stone of carbuncle}. 

#### Ezekiel 10:10 And their appearance was as the likeness one to the four, in which manner whenever {might be a wheel} in the midst of a wheel. 

#### Ezekiel 10:11 In their going {in four parts their they went}; they did not turn in their going. For unto which ever place {looked the head one} behind it they went, and they did not turn in their going. 

#### Ezekiel 10:12 And all their flesh, and their backs, and their hands, and their wings, and the wheels were full of eyes round about to the four wheels of them. 

#### Ezekiel 10:13 And these wheels were called Gelgel in my hearing. 

#### Ezekiel 10:14 And there were four faces to the one; the face of the one was the face of the cherub. And the {face the second} was a face of a man; and the third face a lion; and the fourth face an eagle. 

#### Ezekiel 10:15 And {departed the cherubim}. This is the living creature which I saw by the river Chebar. 

#### Ezekiel 10:16 And in the {going cherubim}, {went the wheels}, and these were next to them. And in the lifting away of the cherubim, of their wings to raise up on high from the earth, {did not turn their wheels}; and indeed they were by the ones next to them. 

#### Ezekiel 10:17 In their standing, their wheels stood; and in their rising up on high, the wheels rose up on high with them; because spirit of life was in them. 

#### Ezekiel 10:18 And {went forth the glory of the LORD} from the open air of the house, and mounted upon the cherubim. 

#### Ezekiel 10:19 And {lifted up the cherubim} their wings, and rose up on high from the earth before me, in their going forth, and the wheels were next to them. And they stood upon the thresholds of the gate of the house of the LORD, of the one before. And the glory of the God of Israel was upon them up above. 

#### Ezekiel 10:20 This {the living creature is} which I saw underneath the God of Israel by the river Chebar; and I knew that they are cherubim. 

#### Ezekiel 10:21 Four faces to the one, and four wings to the one; and having a likeness of hands of men from beneath their wings, 

#### Ezekiel 10:22 and the likeness of their faces -- these {the faces are} which I saw underneath the glory of the God of Israel by the river Chebar, in the vision of them. And these -- each of them {according to their face went}. 

#### Ezekiel 11:1 And {took me up spirit}, and led me unto the gate of the house of the LORD, the one over against the one looking according to the east. And behold, upon the threshold of the gate were about twenty and five men. And I saw in the midst of them Jaazaniah the son of Azur, and Pelatiah the son of Benaiah, the ones guiding the people. 

#### Ezekiel 11:2 And he said to me, O son of man, these are the men considering vain things, and deliberating {counsel evil} in this city. 

#### Ezekiel 11:3 The ones saying, Have they not recently built the houses? This is the kettle, and we are the meats. 

#### Ezekiel 11:4 On account of this, prophesy against them! Prophesy, O son of man! 

#### Ezekiel 11:5 And there fell upon me spirit of the LORD. And he said to me, You say! Thus says the LORD; As you said, O house of Israel, and the deliberations of your spirit I know. 

#### Ezekiel 11:6 You multiplied your dead in this city, and you filled up her ways of slain ones. 

#### Ezekiel 11:7 On account of this, thus says Adonai the LORD; Your dead whom you struck in the midst of her, these are the meats, and she is the kettle. And you I will lead out from the midst of her. 

#### Ezekiel 11:8 {the broadsword You fear}, and the broadsword I will bring upon you, says Adonai the LORD. 

#### Ezekiel 11:9 And I will lead you from the midst of her. And I will deliver you into the hands of strangers. And I will execute {among you judgments}. 

#### Ezekiel 11:10 By the broadsword you shall fall. Upon the borders of Israel I will judge you, and you will realize that I am the LORD. 

#### Ezekiel 11:11 She {to you shall not be} for a kettle, and you in no way shall become in the midst of her for meat. 

#### Ezekiel 11:12 Unto the borders of Israel I will judge you, and you shall know, for I am the LORD. For {in my commandments you did not go}, and of my judgments you went not, and according to the judgments of the nations, of the ones around you, you went. 

#### Ezekiel 11:13 And it came to pass in my prophesying, that Pelatiah the son of Benaiah died. And I fell upon my face, and I yelled out {voice with a great}, and said, Alas, Adonai O LORD, unto consummation do you appoint the remnant of Israel? 

#### Ezekiel 11:14 And {came the word of the LORD} to me, saying, 

#### Ezekiel 11:15 O son of man, your brethren, and the men of your captivity, and all the house of Israel have come to completion, about whom {said to them the ones dwelling in Jerusalem}, You are far at a distance from the LORD; {to us has been given the land} for an inheritance. 

#### Ezekiel 11:16 On account of this, you say! Thus says Adonai the LORD, that, I will thrust them into the nations, and I will disperse them into every land, and I will be to them for {sanctuary a small} in the places where ever they shall enter into there. 

#### Ezekiel 11:17 On account of this, you say! Thus says Adonai the LORD, that, I will take them from out of the nations, and I will gather them from out of the places of which I scattered them among them, and I will give to them the land of Israel. 

#### Ezekiel 11:18 And they shall enter there, and they shall lift away all her abominations, and all her lawless deeds from out of her. 

#### Ezekiel 11:19 And I will give to them {heart another}, and {spirit a new I will put} in them; and I will pull out the {heart stone} from their flesh, and I will give to them a heart of flesh; 

#### Ezekiel 11:20 so that {by my orders they shall go}, and {my ordinances they shall guard}, and they shall execute them. And they will be to me for a people, and I will be to them for God. 

#### Ezekiel 11:21 And for the heart of their abominations, and of their lawlessnesses, as their heart went, {their ways against their heads I have imputed}, says Adonai the LORD. 

#### Ezekiel 11:22 And {lifted up the cherubim} their wings, and the wheels were next to them, and the glory of the God of Israel was upon them, up above them. 

#### Ezekiel 11:23 And {ascended the glory of the LORD} from the midst of the city, and stood upon the mountain which was before the city. 

#### Ezekiel 11:24 And spirit took me up, and led me into the land of the Chaldeans, unto the captivity, in a vision by spirit of God. And I ascended from the vision which I beheld. 

#### Ezekiel 11:25 And I spoke to the captivity all the words of the LORD which he showed to me. 

#### Ezekiel 12:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 12:2 O son of man, {in the midst of their iniquities you dwell}, the ones who have eyes to see, and do not see; and {ears have} to hear, and do not hear. For {house a rebelling it is}. 

#### Ezekiel 12:3 And you, O son of man, prepare for yourself items of captivity, and be as captured by day in their presence! And you shall be as captured from out of your place into another place before them, so that they should see, for {house a rebelling it is}. 

#### Ezekiel 12:4 And you shall bring forth your items, items {of captivity for a day} before their eyes. And you shall go forth at evening before them as {goes forth a captive} before them. 

#### Ezekiel 12:5 Dig for yourself into the wall! and you shall go completely through it. 

#### Ezekiel 12:6 {before them upon a shoulder You shall be taken up}, and {being hidden you shall go forth}. {your face You shall cover up}, and in no way should you behold the ground. Because {as a portent I have put you} to the house of Israel. 

#### Ezekiel 12:7 And I did so according to all as much as he gave charge to me. And I brought forth items {of captivity for the day}, and at evening I dug through {myself the wall} by hand; and being hidden I came forth; {upon a shoulder I was taken up} in the presence of them. 

#### Ezekiel 12:8 And {came the word of the LORD} to me in the morning, saying, 

#### Ezekiel 12:9 O son of man, said not to you the house of Israel, {house the rebelling}, What are you doing? 

#### Ezekiel 12:10 Say to them, Thus says Adonai the LORD; To the ruler and one guiding in Jerusalem, even to all the house of Israel, the ones who are in the midst of them. 

#### Ezekiel 12:11 Say that, I {portents do}. In which manner I have done, so will it be to them -- unto displacement and in captivity they shall go. 

#### Ezekiel 12:12 And the ruler in the midst of them {upon a shoulder shall be lifted}, and being hid he shall come forth through the wall, and he shall dig through to come forth himself through it; {his face he shall cover up}, so that he should not be seen by an eye, and he {the ground shall not see}. 

#### Ezekiel 12:13 And I will spread forth my net upon him, and he shall be seized in {encompassing about my}. And I will lead him into Babylon, into the land of Chaldeans. And {it he shall not see}, and {there he shall come to an end}. 

#### Ezekiel 12:14 And all the ones round about him, his helpers, and all the ones assisting him, I will scatter to all the wind, and {a broadsword I will pour out} after them. 

#### Ezekiel 12:15 And they shall know, for I am the LORD, in my scattering them among the nations. And I will scatter them in the places. 

#### Ezekiel 12:16 And I will leave of them a few men in number from the broadsword, and from famine, and from plague; so even they may tell in detail all their lawless deeds among the nations of which they entered there; and they shall know that I am the LORD. 

#### Ezekiel 12:17 And {came the word of the LORD} to me, saying, 

#### Ezekiel 12:18 O son of man, {your bread with grief you shall eat}, and {your water with torment and affliction you shall drink}. 

#### Ezekiel 12:19 And you shall say to the people of the land, Thus says Adonai the LORD, to the ones dwelling in Jerusalem upon the land of Israel; {their bread loaves with lack they shall eat}, and {their water with obliteration they shall drink}, so that {should be extinct the land} with its fullness in impiety of all the ones dwelling in it. 

#### Ezekiel 12:20 And their cities being dwelt in shall be made quite desolate, and the land {for extinction will be}; and you shall realize that I am the LORD. 

#### Ezekiel 12:21 And {came the word of the LORD} to me, saying, 

#### Ezekiel 12:22 O son of man, what is this parable to you concerning the land of Israel, saying, The days are far off; {has perished all vision}? 

#### Ezekiel 12:23 On account of this, say to them! Thus says Adonai the LORD; Even I will turn back this parable, and no longer should {speak this parable the house of Israel}. For you shall say to them, {have approached The days}, and the matter of every vision. 

#### Ezekiel 12:24 For there will no longer be any {vision false}, nor one using oracles for favor in the midst of the sons of Israel. 

#### Ezekiel 12:25 For I the LORD will speak my words, and I will act; and I will not lengthen the time still. For in your days, {house O rebelling}, I shall speak the word, and I will act, says Adonai the LORD. 

#### Ezekiel 12:26 And {came the word of the LORD} to me, saying, 

#### Ezekiel 12:27 O son of man, behold, the house of Israel, the one rebelling. In saying they say, The vision which this man sees is for {days many}, and {for times long this one prophesies}. 

#### Ezekiel 12:28 On account of this, say to them! Thus says Adonai the LORD; I shall not lengthen any longer all my words which ever I should speak, for I shall speak a word, and I shall act, says Adonai the LORD! 

#### Ezekiel 13:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 13:2 Son of man, prophesy against the prophets of Israel, the ones prophesying! And you shall speak to the prophets, to the ones prophesying from their own heart. And you shall prophesy, and shall say to them, Hear the word of the LORD! 

#### Ezekiel 13:3 Thus says Adonai the LORD; Woe to the ones prophesying from their own heart, to the ones going after their own spirit, and altogether they do not see. 

#### Ezekiel 13:4 As foxes in the desolate places, so are your prophets, O Israel. 

#### Ezekiel 13:5 They stood not in firmness, and they gathered not flocks unto the house of Israel; they did not rise up in war, the ones saying, In the day of the LORD. 

#### Ezekiel 13:6 Ones seeing false visions, using {oracles vain}, the ones saying, Thus says the LORD, and the LORD has not sent them. And they began to raise up a false word. 

#### Ezekiel 13:7 Have you not {vision a false seen}, and {divinations vain spoken}? And you speak, says the LORD, and I spoke not. 

#### Ezekiel 13:8 On account of this, say! Thus says Adonai the LORD; Because your words are false, and your divinations vain, on account of this, behold, I am against you, says Adonai the LORD. 

#### Ezekiel 13:9 And I will stretch out my hand against the prophets, of the ones seeing false visions, and the ones declaring vain things in instruction of my people. They will not be, nor {among the writing of the house of Israel shall they be written}, and into the land of Israel they shall not enter; and they shall know that I am Adonai the LORD. 

#### Ezekiel 13:10 Because they misled my people, saying, Peace; and there was no peace; and this one builds a wall, and they plaster it -- it shall fall. 

#### Ezekiel 13:11 Say to the ones plastering it, that, It shall fall, and there shall be {rain flooding}, and I will appoint {stones rock throwing} against their chambers, and they shall fall; and {wind a removing}, and it shall be broken asunder. 

#### Ezekiel 13:12 And behold, {has fallen the wall}, (and shall they not say to you, Where is your plaster by which you plastered it?) 

#### Ezekiel 13:13 On account of this, Thus says Adonai the LORD, that, I will tear forth {breath a removing} with rage, and {rain a flooding in my anger there will be}, and the stones for rock throwing in rage I will bring unto completion. 

#### Ezekiel 13:14 And I will raze the wall which you plastered, and it shall fall. And I will put it upon the ground, and {shall be uncovered its foundations}, and it shall fall. And you shall be exhausted with reproofs; and you shall realize that I am the LORD. 

#### Ezekiel 13:15 And I will exhaust my rage against the wall, and upon the ones plastering it, and it shall fall. And I said to you, {is not The wall}, nor the ones plastering it -- 

#### Ezekiel 13:16 the prophets of Israel, the ones prophesying against Jerusalem, and the ones seeing her peace, and there is no peace, says Adonai the LORD. 

#### Ezekiel 13:17 And you, O son of man, firmly fix your face against the daughters of your people! the ones prophesying from their own heart. And you prophesy against them! 

#### Ezekiel 13:18 And you shall say, Thus says Adonai the LORD; Woe to the ones sewing together pillows under every elbow of the hand, and making coverings for every head of every stature to pervert souls. The souls are perverted of my people, and {souls they protected}. 

#### Ezekiel 13:19 And they profaned me before my people for a handful of barley, and for pieces of bread loaves, to kill the souls who must not die, and to protect souls who must not live, in you declaring to a people listening to vain maxims. 

#### Ezekiel 13:20 On account of this, Thus says Adonai the LORD; Behold, I am against your pillows upon which you {there confederate souls}; and I will tear them from your arms, and I will send out the souls, the ones whom you distorted their souls for dispersing. 

#### Ezekiel 13:21 And I will tear up your coverings, and I will rescue my people from out of your hand, and no longer will they be in your hands for a confederacy; and you shall realize that I am the LORD. 

#### Ezekiel 13:22 Because you pervert the heart of the just wrongfully, for I did not pervert him; and you strengthened the hands of the lawless one altogether, to not turn him from {way his evil}, so as to enliven him. 

#### Ezekiel 13:23 Because of this, {false visions in no way shall you see}, and {divinations in no way shall you divine} still. And I will rescue my people from out of your hand, and you shall know that I am the LORD. 

#### Ezekiel 14:1 And there came to me men from the elders of the people of Israel, and they sat before my face. 

#### Ezekiel 14:2 And came to pass the word of the LORD to me, saying, 

#### Ezekiel 14:3 Son of man, these men set their thoughts in their hearts, and {the punishment of their iniquities set} before their face. Shall in answering I answer them, no. 

#### Ezekiel 14:4 On account of this, speak to them! And you shall say to them, Thus says Adonai the LORD; A man, a man from out of the house of Israel who ever should put his considerations upon his heart, and {punishment for his iniquities should arrange} before his face, and should come to the false prophet; I the LORD will answer him by them, in the things which are within in his mind, 

#### Ezekiel 14:5 so that he should bend away the house of Israel according to their hearts, the ones being separated from me in their thoughts. 

#### Ezekiel 14:6 Because of this, say to the house of Israel! Thus says Adonai the LORD; Turn and turn away from your practices, and from all {impious deeds your}, and turn your faces! 

#### Ezekiel 14:7 For a man, a man from the house of Israel, and from the foreigners of the ones converting in Israel, who ever should separate from me, and set his thoughts upon his heart, and {punishment for his iniquities should arrange} before his face, and should come to the false prophet to ask him concerning me, I the LORD will answer to him in the things which he presses in them. 

#### Ezekiel 14:8 And I will firmly fix my face against that man, and I will appoint him for a desolate place and for extinction, and I will lift him away from the midst of my people; and you shall realize that I am the LORD. 

#### Ezekiel 14:9 And the prophet, if he should be mislead and should say a word, I the LORD have misled that prophet; and I will stretch out my hand against him, and I will remove him from out of the midst of my people Israel. 

#### Ezekiel 14:10 And they shall bear their iniquity according to the offence of the one asking; likewise also the offence of the prophet it will be; 

#### Ezekiel 14:11 so that {should not be misled still the house of Israel} from me; and that they should not be defiled still in all their transgressions; and they will be to me for a people, and I will be to them for God, says Adonai the LORD. 

#### Ezekiel 14:12 And {came the word of the LORD} to me, saying, 

#### Ezekiel 14:13 O son of man, a land, if it should sin against me to fall into transgression, then I shall stretch out my hand against it, and I will break its reliance on bread, and I will send upon it famine, and I will lift away {from it man and beast}. 

#### Ezekiel 14:14 And if {might be three men these} in the midst of it, Noah, and Daniel, and Job, these in their righteousness shall be delivered, says Adonai the LORD. 

#### Ezekiel 14:15 And if {wild beasts ferocious I bring} upon the land, and punish it, and it shall be for extinction, and there shall not be one traveling through because of the countenance of the wild beasts, 

#### Ezekiel 14:16 and {three men these} were in the midst of it; as I live, says Adonai the LORD, shall sons or daughters be delivered, no. Only these alone shall be delivered, but the land will be for ruin. 

#### Ezekiel 14:17 Or even {a broadsword if I bring} against that land, and I should say, Let the broadsword go through the land! and I shall lift away from out of them man and beast. 

#### Ezekiel 14:18 And if {three men these} were in the midst of it, as I live, says Adonai the LORD, that in no way shall {be rescued sons nor daughters}, but these alone shall be delivered. 

#### Ezekiel 14:19 Or also {a plague if I should send} as a successor upon that land, and I shall pour out my rage upon it in blood, to utterly destroy from out of it man and beast, 

#### Ezekiel 14:20 and Noah, and Daniel, and Job be in the midst of it, as I live, says Adonai the LORD, neither sons or daughters shall be delivered, but they in their righteousness shall rescue their souls. 

#### Ezekiel 14:21 Thus says Adonai the LORD; But if also {four punishments my} -- the ferocious broadsword, and famine, and {wild beasts ferocious}, and plague, I should send out upon Jerusalem to utterly destroy from out of it man and beast; 

#### Ezekiel 14:22 and behold, these being left behind in it -- the ones escaping from it, the ones who shall lead out of it sons and daughters; behold, they shall go forth to you, and you shall see their ways, and their thoughts; and you shall be repentant over the hurts which I brought upon Jerusalem, for all which I brought upon it. 

#### Ezekiel 14:23 That they shall comfort you, because you shall see theirs ways and their thoughts. and you shall realize that {not in vain I have done all} as much as I did by it, says Adonai the LORD. 

#### Ezekiel 15:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 15:2 And you, O son of man, what ever may become of the wood of the vine from out of all the woods of the branches of the ones being in the woods of the forest? 

#### Ezekiel 15:3 Shall they take of its wood to perform for work? Shall they take from out of it stanchions to hang {upon it all items}? 

#### Ezekiel 15:4 Behold, fire is given for consumption yearly; in the cleansing of it {consumes the fire}, and the wood vanishes in the end. Shall it be profitable for work? 

#### Ezekiel 15:5 Not even of it still being whole -- it will not be useful for work; for if also the fire {it should consume} unto completion, shall it be made for work, no. 

#### Ezekiel 15:6 On account of this, thus says Adonai the LORD; In which manner the wood of the vine among the trees of the forest, which I have given it to the fire for consumption, so I have given the ones dwelling in Jerusalem. 

#### Ezekiel 15:7 And I will put my face against them; from out of the fire they shall come forth, and fire shall devour them; and they shall know that I am the LORD in my firmly fixing my face against them. 

#### Ezekiel 15:8 And I will appoint the earth for extinction, because they fell into transgression, says Adonai the LORD. 

#### Ezekiel 16:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 16:2 O son of man, testify to Jerusalem of her lawless deeds! 

#### Ezekiel 16:3 And you shall say, Thus says Adonai the LORD to Jerusalem; Your root and your birth are of the land of Canaan. Your father was an Amorite, and your mother a Hittite. 

#### Ezekiel 16:4 And concerning your birth in which day you were born, {was not severed your naval}, and {in water you were not bathed} for safety, nor {with salt were you salted}, and {with swaddling-cloths you were not swaddled}, 

#### Ezekiel 16:5 nor {spare over you did my eye} to do for you one of all of these things, to suffer anything for you; and you were thrown away upon the face of the plain because of the deformity of your life in the day you were birthed. 

#### Ezekiel 16:6 And I went unto you, and I beheld you being befouled in your blood. And I said to you from out of your blood -- Live! Even I said to you with your blood -- Life. 

#### Ezekiel 16:7 Be multiplied! {as the rising of the field I have made you}. And you were multiplied, and magnified, and entered into cities of cities. Your breasts erected, and your hair rose up; but you were naked and indecent. 

#### Ezekiel 16:8 And I went by you, and beheld you. And behold, it was your time, and a time of resting up. And I opened and spread out my wings over you, and I covered your indecency, and I swore an oath to you, and entered into a covenant with you, says Adonai the LORD, and you became mine. 

#### Ezekiel 16:9 And I bathed you in water, and washed your blood from you, and anointed you with oil. 

#### Ezekiel 16:10 And I clothed you in colored garments, and tied on you blue cloth; and I tied {around you linen}, and put around you a braided belt, 

#### Ezekiel 16:11 and adorned you with ornamentation, and put bracelets around your hands, and a necklace around your neck. 

#### Ezekiel 16:12 And I gave a ring for your nose, and disks for your ears, and a crown of boasting for your head. 

#### Ezekiel 16:13 And you were adorned in gold and silver, and your wraps were fine linen, and braids, and colored garments. {fine flour and olive oil and honey You ate}, and you became {good very vehemently}. And you prospered for royalty. 

#### Ezekiel 16:14 And {went forth your name} among the nations in your beauty; because it was being completed with attractiveness, in the beauty which I ordered up for you, says Adonai the LORD. 

#### Ezekiel 16:15 And you relied in your beauty, and you committed harlotry because of your name; and you poured out your harlotry upon all in the byway -- it was to him. 

#### Ezekiel 16:16 And you took from your garments, and you made for yourself idols strung together. And you fornicated upon them. And in no way should you enter nor should it be. 

#### Ezekiel 16:17 And you took the items of your boasting from my gold, and from my silver of which I gave you; and you made for yourself {images male}, and you fornicated with them. 

#### Ezekiel 16:18 And you took {clothes colored your}, and covered them. And my oil and my incense you put before their face. 

#### Ezekiel 16:19 And my bread loaves which I gave to you, fine flour and olive oil and honey, which I fed you -- even you put them before their face for a scent of pleasant aroma. Yes, it became so, says Adonai the LORD. 

#### Ezekiel 16:20 And you took your sons and your daughters whom you bore, and sacrificed these to them unto consumption, as {a little you fornicated}. 

#### Ezekiel 16:21 And you slew your children, and gave them up in your pacifying them to them. 

#### Ezekiel 16:22 This is beyond all your harlotry, and your abominations. And you did not remember the days of your infancy, when you were naked and indecent, being befouled in your blood, and you lived. 

#### Ezekiel 16:23 And it came to pass after all your evils -- woe, woe to you, says Adonai the LORD, 

#### Ezekiel 16:24 that you built for yourself a building for a harlot; and you made for yourself a public notice in every square. 

#### Ezekiel 16:25 And upon every corner of the way you built your places of harlotry, and laid waste your beauty. And {led through your legs every one passing by}, and you multiplied your harlotry. 

#### Ezekiel 16:26 And you fornicated after the sons of Egypt, of the ones adjoining you, the fleshy ones. And in many ways you fornicated to provoke me to anger. 

#### Ezekiel 16:27 And behold, I stretch out my hand against you, and I will lift away your laws, and deliver you up to the souls detesting you, daughters of Philistines, the ones turning aside from out of your way, of which you were impious. 

#### Ezekiel 16:28 And you fornicated with the sons of Assyria, and neither thus were you satisfied. Yes, you fornicated, and you were not satisfied. 

#### Ezekiel 16:29 And you multiplied your harlotries with the land of Canaan, and to the Chaldeans; and not even in these were you satisfied. 

#### Ezekiel 16:30 What shall I do to your heart, says Adonai the LORD, while you do all these things, works of a woman harlot speaking openly. And you fornicated thrice among your daughters -- 

#### Ezekiel 16:31 in your building your place of harlotry at the top of every street; and {your base you made} in every square; and you became not even as a harlot bringing together hires. 

#### Ezekiel 16:32 The wife committing adultery is likened to you, the one {from her husband taking wages}, 

#### Ezekiel 16:33 and to all the ones fornicating with her she gave {in addition wages}. And you have given wages to all your lovers; and you loaded them to come to you round about in your harlotry. 

#### Ezekiel 16:34 And became in you a perverseness beyond the other women in the harlotry of your harlotry, and with you, which they shall commit harlotry. For in your giving {in addition wages}, (and wages were not given to you,) {has taken place in you a perverseness}. 

#### Ezekiel 16:35 On account of this, O harlot, hear the word of the LORD! 

#### Ezekiel 16:36 Thus says Adonai the LORD; Because you poured out your brass money, therefore {shall be uncovered your shame} in your harlotry with your lovers, and into all the thoughts of your lawlessnesses, and in the blood of your children which you have given to them. 

#### Ezekiel 16:37 On account of this, behold, I {against you will gather} all your lovers in which you intermixed with them, and all whom you loved, with all the ones whom you detested. And I will bring them together against you round about. And I will uncover your evils to them, and they shall see all your shame. 

#### Ezekiel 16:38 And I will punish you with the punishment of adulterous one, and one pouring out of blood. And I will appoint you for blood of rage and zeal. 

#### Ezekiel 16:39 And I will deliver you into their hands. And they shall raze your place of harlotry, and demolish your base, and take off your garments, and take the items of your boasting, and shall leave you naked and indecent. 

#### Ezekiel 16:40 And they shall lead {against you multitudes}, and shall stone you with stones, and shall butcher you with their swords. 

#### Ezekiel 16:41 And they shall burn your houses by fire, and they shall execute among you acts of vengeance before {women many}. And I will turn you from harlotry, and {for wages in no way will I give you up} any longer. 

#### Ezekiel 16:42 And I will slacken my rage against you, and {shall be removed my jealousy} from you. And I will rest, and in no way will I be anxious any longer. 

#### Ezekiel 16:43 Because you did not remember the day of your infancy, and you caused me to fret in all these things; and behold, I {your ways upon your head have imputed}, says Adonai the LORD; and so you shall not commit impiety above all your lawless deeds. 

#### Ezekiel 16:44 These are all as much as they spoke against you in a parable, saying, As the mother, so also the daughter. 

#### Ezekiel 16:45 {the daughter of your mother you are}, the one thrusting away her husband, and her children; and sister of your brethren, of the ones thrusting away their husbands and their children. Your mother was a Hittite, and your father an Amorite. 

#### Ezekiel 16:46 {sister Your older}, she is Samaria, even her daughters dwelling on your left. And {sister your younger}, the one dwelling on your right is Sodom and her daughters. 

#### Ezekiel 16:47 And neither as in their ways were you gone, nor according to their lawless deeds acted even a little, but you take precedence over them in all your ways. 

#### Ezekiel 16:48 As I live, says Adonai the LORD, Has {done Sodom your sister}, she and her daughters, in which manner you did, you and your daughters? 

#### Ezekiel 16:49 Besides this, the violation of Sodom your sister -- pride; in fullness of bread and in prosperity they lived extravagantly, she and her daughters; this existed in her and her daughters, and {the hand of the poor and needy they did not assist}. 

#### Ezekiel 16:50 And they bragged, and committed violations of the law before me. And I removed them as you saw. 

#### Ezekiel 16:51 And Samaria {according to the halves of your sins did not sin}. But you multiplied your lawless deeds above them, and justified your sisters in all your lawless deeds which you did. 

#### Ezekiel 16:52 And you, carry your torment! by which you corrupted your sisters in your sins which you acted lawlessly above them, and justified them above yourself. And you, be ashamed and take your dishonor! in that you justified your sisters. 

#### Ezekiel 16:53 And I will return their rejection, the rejection of Sodom and her daughters; and I will return the rejection of Samaria and her daughters; and I will return your rejection in the midst of them; 

#### Ezekiel 16:54 so that you should carry your torment, and be disgraced from all which you did in your provoking me to anger. 

#### Ezekiel 16:55 And your sister Sodom and her daughters shall be restored as they were from the beginning. And Samaria and her daughters shall be restored as they were from the beginning. And you and your daughters shall be restored as you were from the beginning. 

#### Ezekiel 16:56 And was not Sodom your sister for a report in your mouth in the days of your pride, 

#### Ezekiel 16:57 before the uncovering of your evils, in which manner {now the scorn you are} of the daughters of Syria, and all the ones round about you, even the daughters of the Philistines, of the ones compassing you round about? 

#### Ezekiel 16:58 As for your impious and your lawless deeds, you have carried them, says the LORD. 

#### Ezekiel 16:59 Thus says Adonai the LORD; And I will do among you as you did, as you disgraced this oath to violate my covenant. 

#### Ezekiel 16:60 And I will remember my covenant, of the one with you in the days of your infancy. And I will reestablish with you {covenant an everlasting}. 

#### Ezekiel 16:61 And you shall remember your way, and you shall be despised in your taking up your sisters, your older ones with your younger ones; and I will give them to you for edifying, but not out of your covenant. 

#### Ezekiel 16:62 And I will reestablish my covenant with you, and you shall realize that I am the LORD; 

#### Ezekiel 16:63 so that you should remember and should be ashamed, and it might not be for you still to open your mouth because of the face of your dishonor in my atoning you according to all as much as you did, says Adonai the LORD. 

#### Ezekiel 17:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 17:2 O son of man, Describe a tale, and speak a parable to the house of Israel! 

#### Ezekiel 17:3 And you shall say, Thus says Adonai the LORD; The {eagle great} having large wings, {long stretching out}, full of claws, who has the leading to enter into Lebanon -- even he took the choice cedar. 

#### Ezekiel 17:4 The tips of the tender part he plucked off, and he brought them into the land of Canaan, {into a city being walled he put them}. 

#### Ezekiel 17:5 And he took from the seed of the land, and he put it into the ground fit for sowing as a plant by {water much}; {for attention he arranged it}. 

#### Ezekiel 17:6 And it arose and became a vine being weakened and small in greatness {to be apparent for its vine branches upon it}; and its roots {underneath it were}. And it became a vine, and produced layers of vines, and stretched out its tendrils. 

#### Ezekiel 17:7 And there was {eagle another great} having large wings, and many claws. And behold, her grapevine was being twisted unto him, and her roots unto him, and her vine branches she sent out to him, to water her with the casting away from her planting. 

#### Ezekiel 17:8 In {ground good} upon {water much} she was fattened to produce buds and to bear fruit, to be made into {vine a great}. 

#### Ezekiel 17:9 On account of this, say! Thus says Adonai the LORD; Shall it prosper, no. Shall not the roots of her tenderness, and the fruits rot? Yes, {shall be dried up all her things shooting up early}, and not by {arm a great}, nor by {people many} to pull her out by her roots. 

#### Ezekiel 17:10 And behold, she was fattened; should she prosper? Shall she not in her being touched by {wind the burning} be dried up in dryness? With the casting of her east wind she shall be dried up. 

#### Ezekiel 17:11 And {came the word of the LORD} to me, saying, 

#### Ezekiel 17:12 Say indeed to the {house rebelling}, Do you not know what these are? You speak to them! Behold, {comes the king of Babylon} unto Jerusalem, and he shall take her king, and her rulers. And he shall lead them to himself unto Babylon. 

#### Ezekiel 17:13 And he shall take of the seed of the kingdom, and shall ordain with him a covenant, and shall bring him by an oath; and {the governors of the land he shall take}, 

#### Ezekiel 17:14 to become a {kingdom weak}, so that altogether it should not lift itself up; but to keep its covenant and to establish her. 

#### Ezekiel 17:15 And he shall revolt from him to send messengers unto Egypt, to give to him horses and {people many}. Shall he prosper, no. Shall {be preserved the one acting opposite}, no. And {one violating covenant shall} be preserved, no. 

#### Ezekiel 17:16 As I live, says Adonai the LORD, Surely in the place of the king, of the one giving him reign, who disgraced my oath, and violated my covenant, {with him in the midst of Babylon he shall come to an end}. 

#### Ezekiel 17:17 And not by {power great} nor by {multitude a great} shall {make with him Pharaoh war}, in throwing up a palisade and with construction of a range of weapons to remove {souls many}. 

#### Ezekiel 17:18 And he disgraced the swearing of an oath violating the covenant; and behold, he appointed his hand, and all these things he did to him, he shall not escape. 

#### Ezekiel 17:19 On account of this say! Thus says Adonai the LORD; As I live, surely swearing by my oath which he disgraced, and my covenant which he violated, that I will impute it on his head. 

#### Ezekiel 17:20 And I will spread forth upon him my net, and he shall be captured in his being encompassed about. And I will lead him into Babylon. And I shall litigate with him there concerning his iniquity of which he transgressed against me. 

#### Ezekiel 17:21 In all his exiles, in every battle array of his, {by the broadsword they shall fall}, and the remaining {unto every wind I shall scatter}. And you shall realize that I the LORD have spoken. 

#### Ezekiel 17:22 For thus says Adonai the LORD; And I will take, even I of the chosen of the cedar, from its top; and I will give of the head of her shoots; {of her heart I will pluck off}, and I will plant upon {mountain a high}. 

#### Ezekiel 17:23 And I will hang him on {mountain an elevated} of Israel; and I will plant it, and there shall be brought forth a bud, and he shall produce fruit, and he will be for {cedar a great}; and there shall rest underneath him every bird; and every winged creature {under the shadow of his tender branches shall rest}; and his vine branches shall be restored. 

#### Ezekiel 17:24 And {shall know all the trees of the plain} that I am the LORD, the one humbling {tree the high}, and raising up high {tree the low}; and drying {tree the green}, and again flourishing {tree the dry}. I the LORD, I have spoken and I shall act. 

#### Ezekiel 18:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 18:2 O son of man, What to you is this parable concerning the land of Israel, saying, The fathers ate an unripe grape, and the teeth of the children have a toothache? 

#### Ezekiel 18:3 As I live, says Adonai the LORD, Shall {still be the saying of this parable} in Israel? 

#### Ezekiel 18:4 For all the souls are mine; in which manner the soul of the father, also the soul of the son; they are mine. The soul sinning, this one shall die. 

#### Ezekiel 18:5 But the man who will be just, the one executing equity and righteousness, 

#### Ezekiel 18:6 {upon the mountains he shall not eat to idols}, and his eyes in no way shall be lifted up to the thoughts of the house of Israel; and the wife of his neighbor in no way shall he defile, and to the wife {in menstruation being} he shall not draw near, 

#### Ezekiel 18:7 and {a man in no way shall he tyrannize over}, and collateral taken as a pledge being owed he shall give back, and things for seizure he shall not seize by force, and {his bread to the one hungering he shall give}, and {the naked he shall cover} with a garment; 

#### Ezekiel 18:8 {his money with interest he shall not give}, and {by usury shall not take money}; {from injustice he shall turn his hand}; {judgment a just he shall execute} between a man and his neighbor; 

#### Ezekiel 18:9 and {by my orders he shall go}, and {my ordinances shall guard} to do them -- {just this one is}; to life he shall live, says Adonai the LORD. 

#### Ezekiel 18:10 And if he engenders {son a mischievous}, one pouring out blood and committing sins, and 

#### Ezekiel 18:12 11 {in the way father of his just he went not}, but also upon the mountains he ate to idols, and the wife of his neighbor he defiled,and {the poor and needy tyrannized over}, and seized by force, and {collateral taken as a pledge did not give back}, and for the idols put his eyes {lawlessness to do}, 

#### Ezekiel 18:13 and with interest gave a thing, and by usury took; this one {to life shall not live}; all these lawless deeds he did; unto death he shall be put to death; his blood {upon him will be}. 

#### Ezekiel 18:14 And if he should engender a son, and he should behold all the sins of his father which he did, and should fear and should not do according to these, 

#### Ezekiel 18:15 {upon the mountains and has not eaten}, and {his eyes put not} onto the thoughts of the house of Israel, and {the wife of his neighbor defiled not}, 

#### Ezekiel 18:16 and {a man tyrannized not over}, and took not collateral for security, and by seizure seized not by force; {his bread to the hungry but gave}, and {the naked covered} with a garment, 

#### Ezekiel 18:17 and {from injustice turned his hand}, {interest and usury and did not take money from}, {righteousness and executed}, and {by my orders went}; he shall not come to an end by the iniquities of his father; to life he shall live. 

#### Ezekiel 18:18 But if his father by affliction afflicted, and by seizure seized by force, and {contrary did} in the midst of his people, then he shall die in his iniquity. 

#### Ezekiel 18:19 And you shall say, Why is it that {does not take the son} the iniquity of his father? Because the son {equity and righteousness and mercy has done}. All my laws he preserved, and he did them; to life he shall live. 

#### Ezekiel 18:20 But the soul sinning, it shall die. And the son shall not take the iniquity of the father. And the father shall not take the iniquity of the son. The righteousness of the just one {upon him shall be}, and the lawlessness of the lawless one {upon him shall be}. 

#### Ezekiel 18:21 And the lawless one, if he should turn from all his lawless deeds which he did, and should keep all my commandments, and should do equity and righteousness and mercy; to life he shall live, and he shall not die. 

#### Ezekiel 18:22 All of his transgressions, as many as he did, they shall not be remembered to him; in his righteousness which he did he shall live. 

#### Ezekiel 18:23 By volition do I want the death of the lawless one, says Adonai the LORD? No, But as to turn him from {way his evil} and to enliven him. 

#### Ezekiel 18:24 But in the turning the just from his righteousness, and he should commit iniquity, according to all the iniquities which {did the lawless one}; if he should do thus, he shall not live. In all the things of his righteousness, which he did, in no way shall they be remembered; in his transgression in which he fell, and in his sins in which he sinned, in them he shall die. 

#### Ezekiel 18:25 And you said, {is not straight The way of the LORD}. Hear indeed house of Israel! Is my way not straight? Is it that your ways are straight? 

#### Ezekiel 18:26 In the turning of the just from his righteousness, and he should commit transgression, and he should die in the transgression which he did; {in it he shall die}. 

#### Ezekiel 18:27 And in the {turning lawless one} from his lawlessness which he did, and he shall act with equity and righteousness, this one {his soul kept}. 

#### Ezekiel 18:28 For he saw and turned from all his impiety which he did; to life he shall live, in no way shall he die. 

#### Ezekiel 18:29 And {says the house of Israel}, {is not straight The way of the LORD}. Is my way not straight, O house of Israel? Is it your way that is not straight? 

#### Ezekiel 18:30 Therefore {each according to his way I shall judge you}, O house of Israel, says Adonai the LORD. Be restored and turn from all your impiety, and {shall not be to you punishment of iniquity}! 

#### Ezekiel 18:31 Throw away from yourself all your impiety which you were impious against me, and make to yourself {heart a new} and {spirit a new}! And why do you die, O house of Israel? 

#### Ezekiel 18:32 For I do not want the death of the one dying, says Adonai the LORD. Return then! and you shall live. 

#### Ezekiel 19:1 And you, take up a lamentation against the ruler of Israel! 

#### Ezekiel 19:2 And you shall say, Why {your mother among cubs in the midst of lions became}? In the midst of lions she multiplied her cubs. 

#### Ezekiel 19:3 And {leaped one of her cubs}; {a lion he became} and learned to seize by force; {the prey of men he ate}. 

#### Ezekiel 19:4 And {heard concerning him nations}; and he was seized in their corruption, and they led him in a wicker cage into the land of Egypt. 

#### Ezekiel 19:5 And she beheld that he was thrust away from her, and {perished her support}, and she took another from her cubs; {to be a lion she ordered him}. 

#### Ezekiel 19:6 And he paced in the midst of lions; {a lion he became}, and learned to seize prey, and {men he devoured}. 

#### Ezekiel 19:7 And he fed in his boldness, and {their cities made} quite desolate; and he obliterated the land and the fullness of it by the voice of his roaring. 

#### Ezekiel 19:8 And {assailed against him nations} round about of the places; and they spread forth upon him their nets; and in their corruption he was seized. 

#### Ezekiel 19:9 And they put him in a cage, even in a wicker cage, and they led him to the king of Babylon. And they brought him into prison, so that {should not be heard his voice} any more upon the mountains of Israel. 

#### Ezekiel 19:10 Your mother was as a vine, as a flower of a pomegranate {by water being planted}; her fruit and her bud took place because of {water much}. 

#### Ezekiel 19:11 And she became a rod of strength over a tribe of ones leading; and she was raised up high in her greatness in the midst of the trunks; and she beheld her greatness in the multitude of her branches. 

#### Ezekiel 19:12 But she was broken off in pieces in rage; {upon the ground she was tossed}, and {wind the burning} dried her choice branches. {were punished and were dried The rods of her strength}; fire consumed her. 

#### Ezekiel 19:13 And now they have planted her in the wilderness, in {land a waterless} and one thirsting. 

#### Ezekiel 19:14 And {came forth fire} from out of a rod {choice ones of her} and devoured her; and {was not in her a rod of strength}. {a tribe for a parable of lamentation She is}, and will be for a lamentation. 

#### Ezekiel 20:1 And it came to pass in the {year seventh}, in the fifth month, tenth of the month, there came men from the elders of the house of Israel to ask of the LORD. And they sat before my face. 

#### Ezekiel 20:2 And {came the word of the LORD} to me, saying, 

#### Ezekiel 20:3 O son of man, speak to the elders of Israel! and you shall say to them, Thus says Adonai the LORD; Are {to ask me you come}? As I live, I shall not be answering to you, says Adonai the LORD. 

#### Ezekiel 20:4 Shall I punish them with punishment, O son of man? {of the lawless deeds of their fathers Testify to them}! 

#### Ezekiel 20:5 And you shall say to them, Thus says the LORD; From which day I took up the house of Israel, and made known to the seed of the house of Jacob, and was known by them in the land of Egypt, and took hold of {with my hand them}, saying, I am the LORD your God. 

#### Ezekiel 20:6 In that day I took hold of them by my hand, to lead them from out of the land of Egypt, into the land which I prepared for them; a land flowing milk and honey, the honeycomb is beyond every land. 

#### Ezekiel 20:7 And I said to them, Let each {the abominations of his eyes throw away}! and in the practices of Egypt be not defiled! I am the LORD your God. 

#### Ezekiel 20:8 And they revolted from me, and wanted not to listen to me. Each {the abominations of their eyes threw not away}, and the practices of Egypt they abandoned not. And I spoke to pour out my rage upon them; to complete my anger among them in the midst of Egypt. 

#### Ezekiel 20:9 And I acted so that my name should not be thoroughly profaned before the nations which they are in the midst of them, to the ones whom I made known to them of their presence, to lead them from out of the land of Egypt. 

#### Ezekiel 20:10 And I led them from the land of Egypt, and I led them into the wilderness. 

#### Ezekiel 20:11 And I gave them my orders, and {my ordinances I made known} to them; how if {should do them a man} then he shall live by them. 

#### Ezekiel 20:12 And my Sabbaths I gave to them, to be for a sign between me and between them, for them to know that I am the LORD, the one sanctifying them. 

#### Ezekiel 20:13 And {greatly embittered me the house of Israel} in the wilderness. In my orders they did not go, and my ordinances they thrust away, which {shall do them a man} and shall live by them. And {my Sabbaths they profaned} exceedingly. And I spoke to pour out my rage upon them in the wilderness, to completely consume them. 

#### Ezekiel 20:14 And I acted so that my name should not be thoroughly profaned before the nations which I led them out before their eyes. 

#### Ezekiel 20:15 And I lifted my hand against them in the wilderness, the thorough one, to not bring them into the land which I gave to them, a land flowing milk and honey; (the honeycomb is beyond all the land). 

#### Ezekiel 20:16 Because {my ordinances they thrusted away}, and in my orders they went not by them; and {my Sabbaths they profaned}, and {after the thoughts of their hearts they went}. 

#### Ezekiel 20:17 And {spared them my eye} to not wipe them away, and I did not commit them unto consumption in the wilderness. 

#### Ezekiel 20:18 And I said to their children in the wilderness, {in the laws of your fathers Do not go}, and {their ordinances do not keep}, and {in their practices do not intermingle}, and be not defiled! 

#### Ezekiel 20:19 I am the LORD your God; {by my orders go}, and {my ordinances keep}, and do them! 

#### Ezekiel 20:20 And my Sabbaths -- sanctify them! and it will be for a sign between me and you, to know that I am the LORD your God. 

#### Ezekiel 20:21 And they rebelled against me. And their children {by my orders went not}. And my ordinances they guarded not to do them, which {does if a man} then he shall live by them. And my Sabbaths they profaned. And I spoke to pour out my rage upon them, and to complete my anger against them in the wilderness. 

#### Ezekiel 20:22 And I turned my hand against them, and I acted because of myself, so that my name {thoroughly should not be} profaned before the nations; from whom I led them out before their eyes. 

#### Ezekiel 20:23 And I lifted up my hand against them in the wilderness, to disperse them among the nations, and to scatter them in the places; 

#### Ezekiel 20:24 because {my ordinances they did not observe}, and {my orders they thrusted away}, and {my Sabbaths profaned}, and {after the thoughts of their fathers were their eyes}. 

#### Ezekiel 20:25 And I gave them up to orders that were not good, and ordinances in which they shall not live by them. 

#### Ezekiel 20:26 And I will defile them in their decrees in my traveling by every one opening wide the womb, so that I should obliterate them, that thay shall know that I am the LORD. 

#### Ezekiel 20:27 On account of this, speak to the house of Israel, O son of man! And you shall say to them, Thus says Adonai the LORD; Until this time {provoked me to anger your fathers} in their transgressions, in which they fell against me. 

#### Ezekiel 20:28 And I brought them into the land which I lifted up my hand to give it to them. And they beheld every {hill high}, and every {tree shady}. And they sacrificed there to their gods. And they arranged there the wrath of the gift offerings. And they arranged there a scent of their pleasant aroma offering. And they offered a libation there of their libation offerings. 

#### Ezekiel 20:29 And I said to them, What is Abama, that you enter there? And they called upon its name, Abama, until today's day. 

#### Ezekiel 20:30 On account of this, say to the house of Israel! Thus says Adonai the LORD; Shall {in the lawless deeds of your fathers you defile yourselves}? and {after their abominations do you fornicate}? 

#### Ezekiel 20:31 And in the first-fruits of your gifts, and in your offerings, in the passing through your children in fire, you defiled yourselves in all your thoughts until today's day. And shall I answer you, O house of Israel, no. As I live, says Adonai the LORD, Shall I answer you, and shall {ascend upon your spirit this thing}, no. 

#### Ezekiel 20:32 And it will not be in which manner that you say, We will be as the nations, and as the tribes of the earth, to serve wood and stone idols. 

#### Ezekiel 20:33 On account of this, as I live, says Adonai the LORD, with {hand a fortified} and with {arm a high}, and with rage being poured forth, I will reign over you. 

#### Ezekiel 20:34 And I will lead you from out of the peoples, and I will take you from out of the places of which you were dispersed in them, with {hand a fortified} and with {arm a high}, and with rage being poured forth. 

#### Ezekiel 20:35 And I will lead you into the wilderness of the peoples, and I will litigate for you there face to face. 

#### Ezekiel 20:36 In which manner I litigated for your fathers in the wilderness of the land of Egypt, so will I judge you, says Adonai the LORD. 

#### Ezekiel 20:37 And I will lead you by my rod, and I will bring you in by number. 

#### Ezekiel 20:38 And I shall choose from you the impious, and the ones revolting; because {from out of their sojourning I will lead them}, and {into the land of Israel they shall not enter}. And you shall realize that I am the LORD. 

#### Ezekiel 20:39 And to you, O house of Israel, thus says Adonai the LORD; {each his evil practices Let remove}! And after these things, if you listen to me, and {name my holy shall not profane} any longer by your gifts, and by your practices, 

#### Ezekiel 20:40 that upon {mountain my holy}, upon {mountain the high} of Israel, says Adonai the LORD, there {shall serve to me all the house of Israel} unto the end upon the land. And there I will favorably receive them, and there I shall watch your first-fruits, and the first-fruits of your offerings in all your sanctified things. 

#### Ezekiel 20:41 In a scent of pleasant aroma I will favorably receive you, in my leading you from out of the peoples, and to take you from out of the places in which you were dispersed in them. And I shall be sanctified in you before the eyes of the peoples. 

#### Ezekiel 20:42 And you shall realize that I am the LORD, in my bringing you into the land of Israel, into which I lifted my hand to give it to your fathers. 

#### Ezekiel 20:43 And you shall remember {there your ways}, and your practices which you defiled yourselves by them. And you shall beat your faces over all your evils. 

#### Ezekiel 20:44 And you shall realize that I am the LORD in my doing thus to you, so that my name should not be profaned, not according to {ways your evil}, nor according to {practices your corrupting}, O house of Israel, says Adonai the LORD. 

#### Ezekiel 20:45 And {came the word of the LORD} to me, saying, 

#### Ezekiel 20:46 O son of man, firmly fix your face against Teman, and look upon Daror, and prophesy against the grove leading to Negev! 

#### Ezekiel 20:47 And you shall say to the grove of Negev, Hear the word of the LORD! Thus says the LORD; Behold, I kindle in you a fire, and it shall devour in you every {tree green}, and every {tree dry}. {shall not be extinguished The flame being lit up}, and {shall be incinerated by it every face from the east wind unto the north}. 

#### Ezekiel 20:48 And {shall realize all flesh} that I am the LORD. I kindled it, and it shall not be extinguished. 

#### Ezekiel 20:49 And I said, By no means, O LORD, O Lord, these shall say to me, {not a parable Is being spoken this}? 

#### Ezekiel 21:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 21:2 On account of this, prophesy O son of man, and firmly fix your face against Jerusalem, and look upon their holy places, and prophesy against the land of Israel! 

#### Ezekiel 21:3 And you shall say to the land of Israel, Thus says Adonai the LORD; Behold, I am against you, and I will pull my knife from out of its sheath, and I will utterly destroy from you the lawless one and unjust one. 

#### Ezekiel 21:4 Because I will utterly destroy {from out of you the unjust one and the lawless one}, so shall {come forth my knife} from out of its sheath against all flesh, from the east unto the north. 

#### Ezekiel 21:5 And {shall realize all flesh} that I the LORD pulled out my knife from out of its sheath; and it shall not turn back any longer. 

#### Ezekiel 21:6 And you, O son of man, groan in the breaking of your loins. And in griefs you shall moan before their eyes. 

#### Ezekiel 21:7 And it will be if they should say to you, For what reason do you moan? that you shall say, For the message, for it comes, and {shall be devastated every heart}, and {shall be disabled all hands}, and {shall expire all flesh}, and every spirit, and all thighs shall be tainted by wetness. Behold, it comes and it shall be, says the LORD God. 

#### Ezekiel 21:8 And {came the word of the LORD} to me, saying, 

#### Ezekiel 21:9 O son of man, prophesy! And you shall say, Thus says Adonai the LORD; Say, O broadsword, O broadsword, sharpen and be enraged! 

#### Ezekiel 21:10 so that you should slay victims for slaughter. Be sharpened! so that you should become shiny. Prepare for paralysis! Slay! Treat with contempt! Put aside every tree! 

#### Ezekiel 21:11 And he made it ready {to hold for his hand}. {is made very sharp The broadsword}, it is ready to put it into the hand of one piercing. 

#### Ezekiel 21:12 Shout aloud and shriek, O son of man! for it happened unto my people. It is come upon all the ones guiding Israel. They shall sojourn upon the broadsword. It happened unto my people. On account of this, clap with your hand! 

#### Ezekiel 21:13 for justice has been done. And what if even the tribe be thrust away? It will not be, says Adonai the LORD. 

#### Ezekiel 21:14 And you, O son of man, prophesy, and clap hand upon hand! And repeat the broadsword! The third broadsword is of slain ones, {broadsword of the slain the great}. And you shall amaze them, 

#### Ezekiel 21:15 so that {should be devastated the heart}, and {should be multiplied the ones being weakened} at every gate of theirs. They have been delivered up as victims for slaughter by the broadsword. Well done keen one being for slaughter. Well done one being for shining. As lightning go forth! 

#### Ezekiel 21:16 Sharpen from the right and from the left! wherever your face should be aroused. 

#### Ezekiel 21:17 {also I And} will clap my hand to my hand, and I will slacken my rage; I the LORD, have spoken. 

#### Ezekiel 21:18 And {came the word of the LORD} to me, saying, 

#### Ezekiel 21:19 And you, O son of man, set in order to yourself two ways! {to enter for the broadsword of the king of Babylon}. From out of {place one} shall come forth the two companies; and {a hand at the top of the street of the city upon the corner of the street set in order}, 

#### Ezekiel 21:20 for the {to enter broadsword} upon Rabbath of the sons of Ammon, and upon Judah, and upon Jerusalem in an assault. 

#### Ezekiel 21:21 For {shall stand the king of Babylon} upon the ancient way, upon the corner of the two streets to use oracles for divination, to stir up the rod, and to ask among the carved images, and {livers to watch}. 

#### Ezekiel 21:22 From his right became the oracle against Jerusalem, to throw up a siege mound, to open wide the mouth in yelling, to raise up high a voice with a cry, to throw up a siege mound against her gates, and to throw up an embankment, and to build a range of weapons. 

#### Ezekiel 21:23 And he to them was as one using oracles for divination before them, and he himself calling to mind their iniquity to be seized. 

#### Ezekiel 21:24 On account of this, Thus says Adonai the LORD Because you called to mind your iniquities in the uncovering of your impiety to see your sins, in all your lawlessnesses, and in all your practices; because you called to mind, in these you shall be captured. 

#### Ezekiel 21:25 And you, O profane lawless one guiding Israel, whose {is come day} in time of iniquity -- an end, 

#### Ezekiel 21:26 thus says Adonai the LORD; Remove the turban, and put aside the crown! This {not such will be}. You abased the high, and raised up high the low. 

#### Ezekiel 21:27 Injustice, Injustice, I will appoint it. Neither this {such will be} until of which time {shall come the one who is fit}, and I will deliver up to him. 

#### Ezekiel 21:28 And you, O son of man, prophesy! And you shall say, Thus says Adonai the LORD to the sons of Ammon, and concerning their scorning. And you shall say, O broadsword, O broadsword, being unsheathed for victims for slaughter, and being unsheathed for consummation, arise so as to shine! 

#### Ezekiel 21:29 In {vision your vain}, and in your using {oracles lying} to deliver yourself upon the necks of the slain lawless ones which is come the day in the time of iniquity -- the end. 

#### Ezekiel 21:30 Return to your sheath! In this place which you were engendered in {land your own}, I will judge you. 

#### Ezekiel 21:31 And I will pour out upon you my anger. In the fire of my anger I will breathe against you, and I will deliver you into the hands {men of barbaric} contriving corruption. 

#### Ezekiel 21:32 By fire you will be a thing devoured; your blood will be in the midst of your land; in no way shall there be memory of you; for I the LORD have spoken. 

#### Ezekiel 22:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 22:2 And you, O son of man, shall you judge the city of blood? Yes, hold her forth for an example for all her lawless deeds! 

#### Ezekiel 22:3 And you shall say, Thus says the Lord the LORD; O city shedding blood in the midst of herself, {should come so that her time}, and prepares thoughts against herself, to defile herself. 

#### Ezekiel 22:4 In your blood which you shed, you have fallen; and in your ideas which you produced you defiled yourself; and {drew near your days}, and brought on the time of your years. On account of this I have given you for scorning by the nations, and for mocking by all the regions, 

#### Ezekiel 22:5 the ones near to you, and the ones far at a distance from you. And they shall mock against you, {unclean O one famously}, and great in lawless deeds. 

#### Ezekiel 22:6 Behold, the ones guiding the house of Israel each {with his relatives blends together} against you, so as to shed blood. 

#### Ezekiel 22:7 {father and mother They spoke evil of} among you. And against the foreigner they behaved with injustice among you. Orphan and widow they tyrannize among you. 

#### Ezekiel 22:8 And my holy things they treat with contempt, and my Sabbaths they profaned among you. 

#### Ezekiel 22:9 The men were robbers among you, so that they shed blood among you. And {upon the mountains to idols they were eating} among you. {unholiness They committed} in your midst. 

#### Ezekiel 22:10 {the shame of the father They uncovered} among you; and {in her uncleannesses the woman sitting apart they abased} among you. 

#### Ezekiel 22:11 Each with the wife of his neighbor acted lawlessly; and each {his daughter-in-law defiled} in impiety; and each {his sister the daughter of his father abased} among you. 

#### Ezekiel 22:12 {bribes They took} among you so that they should shed blood. Interest and usury they received among you; and you completed the consummation of your evil by tyranny; {me and you forgot}, says Adonai the LORD. 

#### Ezekiel 22:13 And if I should strike my hand against my hand against the evils which you have been exhausted in the things which you did, and against the blood shed by you being in your midst, 

#### Ezekiel 22:14 shall {stand your heart}, no. Shall {hold your hands} in the days in which I do unto you, no. I the LORD have spoken, and I will do it. 

#### Ezekiel 22:15 And I will disperse you among the nations, and I will scatter you among the regions, and {shall vanish your uncleanness} from you. 

#### Ezekiel 22:16 And I will allot among you before the eyes of the nations, and you shall know that I am the LORD. 

#### Ezekiel 22:17 And {came the word of the LORD} to me, saying, 

#### Ezekiel 22:18 O son of man, behold, {has become to me the house of Israel} an intermingling of all brass, and iron, and tin, and lead; {in the midst of a furnace of silver being intermingled they are}. 

#### Ezekiel 22:19 On account of this, say! Thus says Adonai the LORD; Because you became all for {admixture one}, on account of this I will take you in the midst of Jerusalem. 

#### Ezekiel 22:20 As {is taken silver}, and brass, and iron, and tin, and lead in the midst of the furnace, to blow {into it fire}, for the casting in a furnace. So I will take you in my anger, and in my rage, and I will gather and cast you in a furnace. 

#### Ezekiel 22:21 And I will blow upon you in the fire of my anger, and you shall be cast in a furnace in the midst of it. 

#### Ezekiel 22:22 In which manner {is cast in a furnace silver} in the midst of the furnace, so shall you be cast in a furnace in the midst of it. And you shall realize that I the LORD poured out my rage upon you. 

#### Ezekiel 22:23 And {came the word of the LORD} to me, saying, 

#### Ezekiel 22:24 O son of man, say to her! You are the land, the land not having rain, nor rain came upon you in the day of anger. 

#### Ezekiel 22:25 Of whom the ones guiding in her midst are as {lions roaring seizing by force prey}; {souls devouring} by domination, and {honor taking}; and your widows are multiplied in your midst. 

#### Ezekiel 22:26 And her priests annulled my law, and they profaned my holy things. Between holy and profane they distinguished not, and between unclean and the clean they distinguished not; and from my Sabbaths they covered up their eyes, and I was profaned in their midst. 

#### Ezekiel 22:27 Her rulers in her midst are as wolves seizing prey to shed blood, to destroy lives, so that their desire for wealth should overabound. 

#### Ezekiel 22:28 And her prophets anointing them shall fall seeing vanities, using {oracles lying}, saying, Thus says Adonai the LORD, but the LORD has not spoken. 

#### Ezekiel 22:29 The people of the land are pressuring iniquity, and tearing in pieces the prey, {the poor and needy tyrannizing}, and {to the foreigner not behaving with equity}. 

#### Ezekiel 22:30 And I sought of them a man behaving rightly, and standing before my face soundly in the time of the anger, so as to not {unto the end wipe her away} -- but I did not find. 

#### Ezekiel 22:31 And I poured out upon her my rage, by the fire of my anger, to complete it. {their ways unto their heads I have imputed}, says Adonai the Lord. 

#### Ezekiel 23:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 23:2 O son of man, {two women there were}, daughters {mother of one}. 

#### Ezekiel 23:3 And they fornicated in Egypt; in their youth they committed harlotry. There {fell their breasts}; there they lost their virginity. 

#### Ezekiel 23:4 And their names -- Aholah the elder, and Aholibah her sister. And they were born to me, and gave birth to sons and daughters. And their names -- Samaria is Aholah, and Jerusalem is Aholibah. 

#### Ezekiel 23:5 And Aholah fornicated from me, and doted upon her lovers, upon the Assyrians being next to her; 

#### Ezekiel 23:6 ones being clothed in blue, leaders and commandants, young men, {choice all} horsemen riding upon horses. 

#### Ezekiel 23:7 And she offered her harlotry unto them; the choice sons of the Assyrians -- all; and upon all upon whom she doted herself. With all her thoughts she defiled herself. 

#### Ezekiel 23:8 And her harlotry, the one with Egypt she did not abandon, for {with her they went to bed} in her youth, and they caused her loss of virginity, and they poured out their harlotry upon her. 

#### Ezekiel 23:9 On account of this I delivered her up into the hands of her lovers, into the hands of the sons of the Assyrians, upon whom she doted. 

#### Ezekiel 23:10 They uncovered her shame. {sons and daughters her They took}, and {her by the broadsword they killed}. And she became a discussion for women; and they executed acts of vengeance in her. 

#### Ezekiel 23:11 And {saw her sister Aholibah}, and she corrupted her undertaking above her sister, and her harlotry above the harlotry of her sister. 

#### Ezekiel 23:12 {upon the sons of the Assyrians She doted}, the leaders, and commandants near her, ones being clothed elegantly, horsemen riding upon horses, young men, all choice. 

#### Ezekiel 23:13 And I beheld that they were defiled; it was {way one} for the two of them. 

#### Ezekiel 23:14 And she added unto her harlotry, and she saw men having been portrayed upon the wall, images of Chaldeans having been portrayed with a stylus; 

#### Ezekiel 23:15 having {tied colored belts} upon their loins; deeply dyed apparel upon their heads; {with the appearance of officials all}, a likeness of sons of Babylon of the Chaldeans, of the land of their fatherland. 

#### Ezekiel 23:16 And she doted upon them with the vision of her eyes; and she sent out messengers to them, into the land of the Chaldeans. 

#### Ezekiel 23:17 And {came to her sons of Babylon}, to her marriage-bed resting up, and they defiled her with their harlotry. And she was defiled by them, and {separated her soul} unto them. 

#### Ezekiel 23:18 And she uncovered her harlotry, and uncovered her shame. And {separated my soul} from her in which manner {separated my soul} from her sister. 

#### Ezekiel 23:19 And you multiplied your harlotry to call to mind the day of your youth in which you committed harlotry in Egypt. 

#### Ezekiel 23:20 And you doted upon the Chaldeans, which their flesh is as flesh of donkeys, and {as genitals of horses their genitals}. 

#### Ezekiel 23:21 And you overlooked the lawlessness of your youth, which you did in Egypt in your lodging, of which place the breasts of your youth fell. 

#### Ezekiel 23:22 On account of this, O Aholibah, thus says Adonai the LORD; Behold, I awaken your lovers against you, of whom {is separated your soul} unto them. And I will bring them against you round about; 

#### Ezekiel 23:23 sons of Babylon and all the Chaldeans -- Pekod, and Shoa, and Koa, and all the sons of the Assyrians with them; {young men choice}, governors and commandants, all tribunes, and famous ones riding upon horses. 

#### Ezekiel 23:24 And they shall come upon you all from the north with weapons, and chariots, and wheels, and a multitude of peoples, and chest plates, and shields, and helmets -- they shall be placed around about you, and they shall throw upon you a watch round about. And I will impute {before their face judgment}, and they shall punish you in their judgments. 

#### Ezekiel 23:25 And I will put my jealousy against you. And they shall deal with you in an anger of rage. {your nose and your ears They shall remove}; and {your remnant with a broadsword they shall throw down}. They {your sons and your daughters shall take}, and your remnant shall be devoured by fire. 

#### Ezekiel 23:26 And they shall strip {off you your clothes}, and shall take the items of your boasting. 

#### Ezekiel 23:27 And I will turn your impious deeds from you, and your harlotry from the land of Egypt, and in no way shall you lift up your eyes unto them; and {Egypt in no way shall you remember} any more. 

#### Ezekiel 23:28 For thus says Adonai the LORD; Behold, I deliver you into the hands which you detest, from which {is separated your soul} from them. 

#### Ezekiel 23:29 And they shall deal with you in hatred, and they shall take all the things of your toils, and you will be naked and disgraced. And {shall be uncovered the shame of your harlotry}, even your impiety, and your harlotry. 

#### Ezekiel 23:30 He did to you these things in your fornicating after the nations, and you defiled yourself in their ideas. 

#### Ezekiel 23:31 {in the way of your sister You went}; and I will put her cup into your hands. 

#### Ezekiel 23:32 Thus says Adonai the LORD; The cup of your sister you shall drink -- deep and spacious; it shall be for laughter and sneering abounding to complete intoxication. 

#### Ezekiel 23:33 And {of feebleness you shall be filled}; a cup of extinction, and a cup of your sister Samaria. 

#### Ezekiel 23:34 And you shall drink it and strain it out. And his potsherds you shall devour, and {your breasts you shall pull about}. And your holiday feasts, and your new moons I will pervert, for I have spoken, says Adonai the LORD. 

#### Ezekiel 23:35 On account of this, Thus says Adonai the LORD; Because you forgot me, and threw me behind your body, then you receive for your impiety and your harlotry! 

#### Ezekiel 23:36 And the LORD said to me, O son of man, Will you judge Aholah and Aholibah? for you shall report to them their lawless deeds. 

#### Ezekiel 23:37 For they committed adultery, and blood is on their hands; even with their thoughts they committed adultery. And their children which they bore to me, {led them they} through fire. 

#### Ezekiel 23:38 While also they did these things to me, they defiled my holy things in that day, and {my Sabbaths they profaned}. 

#### Ezekiel 23:39 even in their slaying their children to their idols, and entering into my holy places in that day to profane them. And behold, thus they did in the midst of my house. 

#### Ezekiel 23:40 And they sent forth to the men, to the ones having come from far off, to which {messengers they sent out} to them. And together in their coming straight you bathed and tinged {with antimony your eyes}, and adorned yourself with ornamentation, 

#### Ezekiel 23:41 and you sat down upon a bed being a spread out, and a table being adorned before it; and my incense and my oil you put before them, and they were glad in them. 

#### Ezekiel 23:42 And a sound of harmony they played music to men from out of a multitude of men having come being drunk from out of the wilderness. And they put bracelets upon their hands, and a crown of boasting upon their heads. 

#### Ezekiel 23:43 And I said, {not with these Do they commit adultery}? And works of a harlot also she fornicated? 

#### Ezekiel 23:44 And they entered unto her. In which manner men enter to a woman harlot, so they entered to Aholah, and to Aholibah the {women lawless}, to commit lawlessness. 

#### Ezekiel 23:45 And {men just they are}, and they shall punish them in punishment of adulteresses. And in judgment they shed blood, for they are adulteresses, and blood is in their hands. 

#### Ezekiel 23:46 Thus says Adonai the LORD; Lead {against them a multitude}, and put {among them disturbance and ravaging}; 

#### Ezekiel 23:47 and let them stone with stones of multitudes, and let them pierce them through with their swords! Their sons and their daughters they shall kill, and their houses they shall burn. 

#### Ezekiel 23:48 And I will return the impiety of the land, and {shall be corrected all the women}, and in no way shall they do according to their impious deeds. 

#### Ezekiel 23:49 And {shall be imputed your impiety} upon you, and the sins of your ideas you shall bear, and you shall know that I am the LORD. 

#### Ezekiel 24:1 And {came the word of the LORD} to me in the {year ninth}, in the {month tenth}, tenth of the month, saying, 

#### Ezekiel 24:2 O son of man, write for yourself the name of the day from this day, from which {fastened the king of Babylon} upon Jerusalem, even from {day today's}! 

#### Ezekiel 24:3 And speak {against the house rebelling a parable}! And you shall say to them, Thus says Adonai the LORD; Set up the kettle! Set up and pour {into it water}! 

#### Ezekiel 24:4 And put into it its pieces! every {piece good} -- the leg, and shoulder, tearing off the flesh from the bones, 

#### Ezekiel 24:5 {from choice cattle having taken}, then fire up the bones underneath them; boiled erupted and cooked are her bones in her midst. 

#### Ezekiel 24:6 On account of this, thus says Adonai the LORD; O city of bloodshed, a kettle in which there is poison in it, and the poison did not come forth out of her; {by her limb they brought forth}; {fell not unto her a lot}. 

#### Ezekiel 24:7 For her blood {in her midst became}; upon a smooth rock I arranged it; I have not poured it upon the ground to cover {upon it earth}. 

#### Ezekiel 24:8 But to let {ascend rage} for a punishment, to be punished I put her blood upon a smooth rock, so as to not cover it. 

#### Ezekiel 24:9 On account of this, thus says Adonai the LORD; Woe, O city of blood, I also shall magnify the firebrand, 

#### Ezekiel 24:10 and I will multiply the wood, and kindle the fire, so that {should melt away the meats}, and {should be lessened the broth}, and the bones shall be parched; 

#### Ezekiel 24:11 and it should stand upon her coals, so that it should be burnt through and {should be heated her brass utensils}, and {should melt away in the midst of her her uncleanness}, and {should fail her poison}, 

#### Ezekiel 24:12 and in no way shall there come forth from out of her much of her poison. 

#### Ezekiel 24:13 {shall be a disgrace Her poison} in the {of your uncleanness boiling}, and because you were defiled yourself, and you were not cleansed from your uncleanness, then what if you should not be cleansed any more until of which time I shall fill up my rage in you? 

#### Ezekiel 24:14 I the LORD have spoken, and it shall come, and I will do; I will not warn nor show mercy, and in no way will I comfort; according to your ways, and according to your thoughts I will judge you, says Adonai the LORD. 

#### Ezekiel 24:15 And {came the word of the LORD} to me, saying, 

#### Ezekiel 24:16 O son of man, behold, I take from you the desirable things of your eyes in battle array; but in no way shall you beat your chest, nor in any way shall you weep, nor in any way should {come to you tears}. 

#### Ezekiel 24:17 You shall moan being silent; {a moaning of bloodshed of a loin it is}; {for mankind a mourning you shall not make}. {shall not be The hair on your head} braided upon you, and your sandals shall be on your feet; and in no way shall you be comforted by their lips, and the bread of men in no way shall you eat. 

#### Ezekiel 24:18 And I spoke to the people in the morning, in which manner he gave charge to me. And {died my wife} at evening. And I did in the morning in which manner orders were given to me. 

#### Ezekiel 24:19 And {said to me the people}, Will you not report to us what these things are which you do? 

#### Ezekiel 24:20 And I said to them, The word of the LORD came to me, saying, 

#### Ezekiel 24:21 Say to the house of Israel! Thus says Adonai the LORD; Behold, I will profane my holy places, the neighing of your strength, the desirable things of your eyes, and for what {spare your souls}; and your sons and your daughters whom you abandoned {by the broadsword will fall}. 

#### Ezekiel 24:22 And you shall do in which manner I have done. From their mouth you shall not be comforted, and the bread of men you shall not eat. 

#### Ezekiel 24:23 And your hair shall be upon your head, and your sandals on your feet; neither shall you lament, nor shall you weep; and you shall melt away in your iniquities, and {shall comfort each} his brother. 

#### Ezekiel 24:24 And Ezekiel will be to you for a portent; and according to all as many things as he did you shall do. Whenever these things should come, then you shall realize that I am the LORD. 

#### Ezekiel 24:25 And you, O son of man, shall it not be in the day whenever I take their strength from them, the haughtiness of their boasting, the desirable things of their eyes, and the haughtiness of their soul, their sons, and their daughters, 

#### Ezekiel 24:26 that in that day {shall come the one escaping} to you, to announce to you in your ears? 

#### Ezekiel 24:27 In that day {shall be opened wide your mouth} to the one having escaped, and you shall speak, and in no way shall you be mute any longer. And you will be to them for a portent; and they shall realize that I am the LORD. 

#### Ezekiel 25:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 25:2 O son of man, firmly fix your face against the sons of Ammon, and prophesy against them! 

#### Ezekiel 25:3 And you shall say to the sons of Ammon, Hear the word of Adonai the LORD! Thus says Adonai the LORD; Because you rejoiced over my holy places, for it was profaned; and over the land of Israel, for it was obliterated; and over the house of Judah, for they went into captivity. 

#### Ezekiel 25:4 On account of this, behold, I deliver you up to the sons of Kedem for an inheritance. And they shall encamp among your chattel among you; and they shall put {among you their tents}; they shall eat your fruits, and they shall drink of your fatness. 

#### Ezekiel 25:5 And I will give the city of Ammon for pastures of camels, and the sons of Ammon for a pasture of sheep. And you shall realize that I am the LORD. 

#### Ezekiel 25:6 For thus says the LORD; Because you clapped your hand, and stamped your foot, and rejoiced in your soul over the land of Israel; 

#### Ezekiel 25:7 on account of this, behold, I will stretch out my hand against you, and I will appoint you for ravaging among the nations; and I will utterly destroy you from out of the peoples, and I will destroy you from out of the regions by destruction; and you shall realize that I am the LORD. 

#### Ezekiel 25:8 Thus says Adonai the LORD; Because {said Moab and Seir}, Behold, in the manner of all the nations is the house Judah. 

#### Ezekiel 25:9 On account of this, behold, I will disable the shoulder of Moab from the cities of his extremities, the choice land, the house of Beth-jeshimoth above the spring of the city by the sea. 

#### Ezekiel 25:10 Of the sons of Kedem {in addition to the sons of Ammon I have given them} for an inheritance, so that there should not be a memory of the sons of Ammon among the nations. 

#### Ezekiel 25:11 And in Moab I will execute vengeance, and they shall realize that I am the LORD. 

#### Ezekiel 25:12 Thus says Adonai the LORD; Because Edom did in their avenging with vengeance against the house of Judah, and resented them, and took vengeance for punishment upon them; 

#### Ezekiel 25:13 on account of this, thus says Adonai the LORD; Even I will stretch out my hand against Edom. And I will utterly destroy from her man and beast. And I will make it desolate. And from out of Teman and of Ledan the ones being pursued {by the broadsword shall fall}. 

#### Ezekiel 25:14 And I will execute my vengeance against Edom by the hand of my people Israel. And they shall deal with Edom according to my anger, and according to my rage. And they shall recognize my vengeance, says Adonai the LORD. 

#### Ezekiel 25:15 On account of this, thus says Adonai the LORD; Because {did the Philistines} with vengeance, and raised up vengeance rejoicing from their soul to wipe them away unto the eon. 

#### Ezekiel 25:16 On account of this, thus says Adonai the LORD; Behold, I shall stretch out my hand against the Philistines. And will utterly destroy the Cherethim, and I will destroy the ones remaining, the ones dwelling on the coast. 

#### Ezekiel 25:17 And I will execute among them {vengeance great} in rebukes of rage, and they shall realize that I am Adonai the LORD in the executing of my vengeance upon them. 

#### Ezekiel 26:1 And it took place in the eleventh year, day one of the month, {came the word of the LORD} to me, saying, 

#### Ezekiel 26:2 O son of man, because Sor said against Jerusalem, Well done, she was broken; she had destroyed the nations; she was turned to me -- she that was full was made desolate. 

#### Ezekiel 26:3 On account of this, thus says Adonai the LORD; Behold, I am against you, O Sor, and I will lead against you {nations many} as {ascends the sea} with her waves. 

#### Ezekiel 26:4 And they shall throw down the walls of Sor; and they shall throw down your towers; and I will winnow her dust from her, and I will make her into a smooth rock. 

#### Ezekiel 26:5 {for a refreshing of dragnets She will be} in the midst of the sea; for I have spoken, says Adonai the LORD, and she will be for plunder to the nations. 

#### Ezekiel 26:6 And her daughters in the plain {by sword shall be done away with}; and they shall know that I am the LORD. 

#### Ezekiel 26:7 For thus says Adonai the LORD; Behold, I bring against you, O Sor, Nebuchadnezzar king of Babylon from the north ({king of kings he is}) with horses, and chariots, and horsemen, and a gathering {nations of many}, exceedingly. 

#### Ezekiel 26:8 This one {your daughters in the plain by the sword will do away with}; and he will appoint against you an advance guard, and he will enclose you, and he will put {around you a trench}, and he will enclose upon you with a siege mound round about, and a surrounding of shields, and {his lances before you he shall appoint}. 

#### Ezekiel 26:9 {your walls and your towers He will demolish} with his own weapons. 

#### Ezekiel 26:10 From the multitude of his horses {shall cover you their dust}; and from the sound of his horsemen and the wheels of his chariots {shall be shaken your walls} at his entering your gates, as one entering into a city from the plain. 

#### Ezekiel 26:11 With the hoofs of his horses they shall trample all your squares; {your people by sword they shall do away with}; and the support of your strength {to the ground they shall bring down}. 

#### Ezekiel 26:12 And he shall plunder your force, and shall despoil your possessions, and shall throw down your walls, and {houses your desirable shall demolish}. And your stones, and your wood, and your dust {into the midst of the sea he will cast}. 

#### Ezekiel 26:13 And he will rest up the multitude of your musicians. And the sound of your psalteries in no way shall be heard any longer. 

#### Ezekiel 26:14 And I will make you for a smooth rock. {a place for freshening dragnets You will be}. In no way shall you be rebuilt any more; for I the LORD spoke, says Adonai the LORD. 

#### Ezekiel 26:15 For thus says the LORD to Sor, Shall not at the sound of your downfall in the moaning of the wounded in the unsheathing of the sword in your midst {shake the islands}? 

#### Ezekiel 26:16 And {shall go down from their thrones all the rulers of the sea}, and they shall remove their mitres, and {clothes their colored they shall take off}. {by a change of state They shall be startled} upon the earth. They shall be seated and shall fear their destruction, and they shall moan over you. 

#### Ezekiel 26:17 And they shall take {over you a lamentation}, and shall say to you, O how you were destroyed and deposed from the sea, O {city praiseworthy}, who was strong in her sea, and the ones inhabiting her, the one putting her fear in all her inhabitants. 

#### Ezekiel 26:18 And {shall fear the islands} from the day of your downfall; and {shall be disturbed the islands} in the sea from your expedition. 

#### Ezekiel 26:19 For thus says the Lord the LORD; Whenever I should appoint you a city for being made desolate, as the cities not being dwelt in, in my leading {upon you the deep}, and {shall cover you up water much}, 

#### Ezekiel 26:20 that I will bring you down to the ones having gone down into the pit, to the people of the eon. And I shall settle you into the depths of the earth, as {desolation an eternal} with ones going down into the pit, so that you should not be inhabited upon the land of life. 

#### Ezekiel 26:21 {you for destruction I will appoint}, and you shall not exist any longer. And you shall seek and not find into the eon, says Adonai the LORD. 

#### Ezekiel 27:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 27:2 And you, O son of man, take {against Sor a lamentation}. 

#### Ezekiel 27:3 And you shall say to Sor, to the one dwelling upon the entrance of the sea, to the market-place of the peoples from {islands many}, Thus says Adonai the LORD to Sor, You said, I invested myself with my beauty. 

#### Ezekiel 27:4 In the heart of the sea are your borders, your sons invested to you beauty. 

#### Ezekiel 27:5 Cedar of Senir was used to build by you; they used fascia planks of cypress from Lebanon; {was taken to make masts for you fir}. 

#### Ezekiel 27:6 From out of Bashan they made your oars; {your temples they made} from out of ivory; houses of the woods from the islands of the Chittim. 

#### Ezekiel 27:7 Linen with embroidery from out of Egypt was to you for a strewn bed, to put {upon you glory}, and to clothe you in blue and purple from the islands of Elishah; and they became your wraps. 

#### Ezekiel 27:8 And your rulers, the ones dwelling in Sidon, and Arvad became your oarsmen. Your wise men, O Sor, the ones who were among you, these were your navigators. 

#### Ezekiel 27:9 The elders of the Biblians, and their wise men who were among you, these grew in strength for your counsel. And all the boats of the sea and their oarsmen came to you from the descent of the west. 

#### Ezekiel 27:10 Persians and Lidians and Libyans were {among your force men}, of your warriors -- {shields and helmets they hung} among you; these gave you glory. 

#### Ezekiel 27:11 Sons of Arvad, and your force were upon your walls round about. But also Medes in your towers were guards. {their quivers They hung} upon your moorings, round about these they perfected your beauty. 

#### Ezekiel 27:12 Carthaginians were your merchants because of the abundance of all your strength. Silver, and gold, and brass, and iron, and tin, and lead they put in your market. 

#### Ezekiel 27:13 The Greek and the whole world, and the places extending; these traded with you in lives of men; and items of brass they gave for your trade. 

#### Ezekiel 27:14 From out of the house of Torgarmah, horses and horsemen and mules they gave for your market. 

#### Ezekiel 27:15 The sons of the Rhodians were your merchants; from the islands they multiplied your trade, even teeth of ivory; and to the ones bringing you repaid with your wages, 

#### Ezekiel 27:16 of men for your trading from the multitude of your consolidation; balsam and purple and linen, and colored works from out of Tharsis; and Ramoth and Chohor gave for your market. 

#### Ezekiel 27:17 Judah, and the sons of Israel, these were your merchants in the sale of grain and perfumed liquids; and foremost honey and olive oil and balm they gave unto your consolidation. 

#### Ezekiel 27:18 Damascus was your trade in the abundance of your works, from an abundance of your power; wine from Helbon, and {wool shining} from Miletus. 

#### Ezekiel 27:19 Dan and Javan and Moozel were for your market; iron for working implements and wheels {among your consolidation are}. 

#### Ezekiel 27:20 Dedan were your merchants with {animals choice} for chariots. 

#### Ezekiel 27:21 Arabia and all the rulers of Kedar, these were your merchants trading {through your hand camels}, and lambs, and rams in which they traded with you. 

#### Ezekiel 27:22 Your merchants were Sheba and Raamah, these were your merchants with foremost of spices, and {stones precious}; and {gold they gave} for your market. 

#### Ezekiel 27:23 Haran and Canneh and Eden, these were your merchants; Sheba and Assyria and Chilmad were your merchants; 

#### Ezekiel 27:24 bringing trade of blue, and {treasures choice} being bound in rough cords, and cypress. 

#### Ezekiel 27:25 Boats among them were your merchants in the abundance of your consolidations. And you were filled up and weighed down exceedingly in the heart of the seas. 

#### Ezekiel 27:26 {into water much led you Your oarsmen}; the wind of the south broke you in the heart of the sea. 

#### Ezekiel 27:27 Your force, and your wage, and your consolidations, and your oarsmen, and your navigators, and your counselors, and your consolidations from out of your consolidations, and all the men, your warriors among you; and {whole gathering your} in the midst of you shall fall in the heart of the sea in the day of your downfall. 

#### Ezekiel 27:28 At the sound of your cry your navigators {with fear shall be afraid}. 

#### Ezekiel 27:29 And {shall go down from their boats all your oarsmen}, and the crewmen, and the captains of the sea; {upon the ground they shall stand}. 

#### Ezekiel 27:30 And they shall shout over you with their voice, and shall cry out bitterly, and shall place earth upon their head, and {of ashes shall spread a bed}. 

#### Ezekiel 27:31 And they shall shave because of you unto baldness; and they shall gird on sackcloth, and shall weep over you in bitterness of life, even lamenting bitterly. 

#### Ezekiel 27:32 {shall take Their sons over you a lamentation} and a wailing, Sor, Who is as Tyre observing silence in the middle of the sea? 

#### Ezekiel 27:33 How much {did you find wage} from the sea? You filled up nations from your abundance, and from your consolidation you enriched all the kings of the earth. 

#### Ezekiel 27:34 But now you are broken in the sea; {is in the depth of the water your consolidation and all your gathering} in your midst. {fell All your oarsmen}. 

#### Ezekiel 27:35 All the ones dwelling the islands shall be gloomy over you, and their kings {with a change of state shall be amazed}, and {shall burst into tears their countenance}. 

#### Ezekiel 27:36 Merchants from the nations whistled at you; {for destruction you became}, and no longer will you be into the eon. 

#### Ezekiel 28:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 28:2 And you, O son of man, say to the ruler of Tyre! Thus says Adonai the LORD; because {was raised up high your heart}, and you said, {the God am I}, {the dwelling of God I inhabited} in the heart of the sea. But you are a man, and not God, and you made your heart as the heart of God. 

#### Ezekiel 28:3 {wiser than Are you} Daniel, or {the wise did not} correct you with their higher knowledge? 

#### Ezekiel 28:4 Is it by your higher knowledge, or in your intelligence you produced for yourself power, and you procured gold and silver among your treasures? 

#### Ezekiel 28:5 Or by {much higher knowledge your} and in your trade did you multiply your power, and raise up high your heart by your power? 

#### Ezekiel 28:6 On account of this, thus says Adonai the LORD; Since you imputed your heart as the heart of God; 

#### Ezekiel 28:7 for this, behold, I bring upon you strange pestilent ones from the nations. And they shall empty out their swords against you; against the beauty of your higher knowledge; and they shall spread your beauty unto destruction. 

#### Ezekiel 28:8 And they shall bring you down, and you shall die by death of the slain in the heart of the sea. 

#### Ezekiel 28:9 In saying, will you say, {God am I}, in the presence of the ones doing away with you? But you are a man, and not God in the hand of ones piercing you. 

#### Ezekiel 28:10 In deaths of the uncircumcised you shall die by the hands of strangers; for I spoke, says Adonai the LORD. 

#### Ezekiel 28:11 And came the word of the LORD to me, saying, 

#### Ezekiel 28:12 O son of man, take a lamentation over the ruler of Tyre, and say to him! Thus says Adonai the LORD; You are a seal of likeness full of wisdom, and a crown of beauty. 

#### Ezekiel 28:13 {in the luxury of the paradise of God You were}; {every stone precious you bound on} -- sardius, and topaz, and emerald, and carbuncle, and sapphire, and jasper, and silver, and gold, and amber, and agate, and amethyst, and chrysolite, and beryl, and onyx. And with gold you filled up your treasuries and your storehouses among you. 

#### Ezekiel 28:14 From which day you were created and were carefully prepared with the cherub being anointed by God, and encamping in the tent, even I put you on {mount the holy} of God; you existed among the midst of the stones of fire. 

#### Ezekiel 28:15 You were unblemished in your days of which day you were created, until of which time {were found the offences} in you. 

#### Ezekiel 28:16 From the abundance of your trade you filled your storerooms with lawlessness, and sinned. And you were wounded from the mountain of God, and {led you the cherub overshadowing} from out of the midst of the stones of fire. 

#### Ezekiel 28:17 {was raised up high Your heart} over your beauty; {was corrupted your higher knowledge} with your beauty because of the multitude of your sins. {upon the earth I tossed you}; {before kings I put you} to be made an example. 

#### Ezekiel 28:18 Because of the multitude of your sins and the iniquities of your trade you profaned your temples; and I will lead fire from out of your midst, this shall devour you; and I will put you for ashes upon the earth before all the ones seeing you. 

#### Ezekiel 28:19 And all the ones knowing you among the nations shall be gloomy over you; {for destruction you became}, and you shall not exist any longer into the eon. 

#### Ezekiel 28:20 And {came the word of the LORD} to me, saying, 

#### Ezekiel 28:21 O son of man, firmly fix your face against Sidon, and prophesy against it! 

#### Ezekiel 28:22 And say! Thus says Adonai the LORD; Behold, I am against you Sidon; and I shall be glorified in you. And you shall know that I am the LORD, in my executing {among you judgments}; and I shall be sanctified among you. 

#### Ezekiel 28:23 And I shall send out against you death and blood in your squares; and there shall fall men being wounded by swords among you, surrounding you; and they shall know that I am the LORD. 

#### Ezekiel 28:24 And there will not be any longer in the house of Israel a barb of bitterness, nor a thorn of grief from all the ones surrounding them, of the ones dishonoring them; and they shall know that I am Adonai the LORD. 

#### Ezekiel 28:25 Thus says Adonai the LORD; And I will gather the house of Israel from out of the nations of which they were dispersed there. And I will be sanctified among them before the peoples, and the nations. And they shall dwell upon their land which I gave to my servant Jacob. 

#### Ezekiel 28:26 And they shall dwell upon it in hope. And they shall build houses, and shall plant vineyards, and shall dwell in hope, whenever I execute judgment on all the ones dishonoring them, among the ones round about them; and they shall know that I am the LORD their God, and the God of their fathers. 

#### Ezekiel 29:1 In the {year tenth}, in the tenth month, day one of the month, {came the word of the LORD} to me saying, 

#### Ezekiel 29:2 O son of man, firmly fix your face against Pharaoh king of Egypt, and prophesy against him, and against entire Egypt! 

#### Ezekiel 29:3 Speak and say! Thus says Adonai the LORD; Behold, I am against you, O Pharaoh king of Egypt, the {dragon great}, the one lying in wait in the midst of his rivers. The one saying, {are mine The rivers}, and I made them. 

#### Ezekiel 29:4 And I will put snares into your jaws, and I will cleave the fishes of your river to your wings. And I will lead you from out of the midst of your river, and all the fishes of the river {to your scales I will cleave}. 

#### Ezekiel 29:5 And I will throw you down quickly, and all the fishes of your river. Upon the face of the plain you shall fall, and no way shall you be brought together; and no way shall you be screened. To the wild beasts of the earth, and to the winged creatures of the heaven I have given you for a thing to be devoured. 

#### Ezekiel 29:6 And {shall know all the ones dwelling Egypt} that I am the LORD, because you became a rod of reed to the house of Israel. 

#### Ezekiel 29:7 When they took hold of you with their hand, then you were fractured; and when {prevailed against them every hand}. And when they rested upon you, you were broken, and you broke {of them of all the loin}. 

#### Ezekiel 29:8 On account of this, thus says Adonai the LORD; Behold, I bring upon you the broadsword; and I will destroy men from you, and beasts. 

#### Ezekiel 29:9 And {will be the land of Egypt} for destruction and desolation. And they shall know that I am the LORD, because of your saying, The rivers are mine and I made them. 

#### Ezekiel 29:10 On account of this, behold, I am against you, and against all your rivers. And I will give the land of Egypt unto desolation, broadsword, and destruction, from Migdol and Syene even unto the borders of the Ethiopians. 

#### Ezekiel 29:11 In no way shall there go through by it the foot of a man; and the foot of a beast in no way shall go through it, and it shall not be inhabited forty years. 

#### Ezekiel 29:12 And I will appoint her land for destruction in the midst of a land being made desolated, and her cities {in the midst of cities being made desolated shall be} for extinction forty years. And I will scatter Egypt among the nations, and I will winnow them among the places. 

#### Ezekiel 29:13 Thus says Adonai the LORD; After forty years I will gather the Egyptians from the nations of which they were dispersed there. 

#### Ezekiel 29:14 And I will return the captivity of the Egyptians, and I will settle them in the land of Phathros, in the land from where they were taken; and it will be {rule a humble} there, 

#### Ezekiel 29:15 more than all the rules, it shall be least to not be raised up high any more over the nations. And {very few them I will make}, so as for {to not be them} many among the nations. 

#### Ezekiel 29:16 And no longer will they be any more {to the house of Israel for a hope}, calling to mind lawlessness in their following after them. And they shall know that I am Adonai the LORD. 

#### Ezekiel 29:17 And it came to pass in the seventh and twentieth year, day one of the {month first}, came the word of the LORD to me, saying, 

#### Ezekiel 29:18 O son of man, Nebuchadnezzar king of Babylon reduced to slavery his force {service for a great} against Tyre. Every head was bald and every shoulder loose of hair. And a wage did not exist to him, and his force was against Tyre, for the service of which they served against it. 

#### Ezekiel 29:19 On account of this, thus says Adonai the LORD; Behold, I give to Nebuchadnezzar king of Babylon the land of Egypt; and he shall despoil her spoils, and he shall plunder her plunder; and it will be the wage for his force. 

#### Ezekiel 29:20 In return for his ministration of which he served against Tyre, I have given to him the land of Egypt, because of as much as he worked to me, says Adonai the LORD. 

#### Ezekiel 29:21 In that day there shall rise up a horn to all the house of Israel, and I will give to you a mouth being opened in the midst of them; and they shall know that I am the LORD. 

#### Ezekiel 30:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 30:2 O son of man, Prophesy and say! Thus says Adonai the LORD; Oh, Oh the day; 

#### Ezekiel 30:3 for {is near the day of the LORD}, even {approaches the day of the LORD}. {a day of cloud and a time of nations It will be}. 

#### Ezekiel 30:4 And {shall come a sword} against the Egyptians, and there will be a disturbance in the land of Ethiopia, and they shall fall being slain in Egypt, and they shall take her abundance, and {shall be cast down her foundations}. 

#### Ezekiel 30:5 Persians, and Cretans and Lydians, and Libyans, and Ethiopians, and all the intermixed peoples, and of the sons of my covenant {by the sword shall fall} with them. 

#### Ezekiel 30:6 Thus says Adonai the LORD; And {shall fall the supports of Egypt}, and {shall go down the insolence of her strength} from Migdol unto Syene; {by the sword they shall fall} in her, says Adonai the LORD. 

#### Ezekiel 30:7 And it shall be made desolate in the midst of places being obliterated; and her cities {in the midst of cities being made desolate will be}. 

#### Ezekiel 30:8 And they shall know that I am the LORD, whenever I shall appoint fire against Egypt, and {shall be broken all the ones helping her}. 

#### Ezekiel 30:9 In that day shall come forth messengers hastening to obliterate the hope of Ethiopia; and there will be a disturbance among them in the day of Egypt; for behold, it is come. 

#### Ezekiel 30:10 Thus says Adonai the LORD; And I will destroy the multitude of the Egyptians by the hand of Nebuchadnezzar king of Babylon; 

#### Ezekiel 30:11 he and his people with him, the pestilent ones from nations being sent to destroy the land. And they shall all empty out their swords against Egypt, and shall fill the land with slain. 

#### Ezekiel 30:12 And I will make their rivers desolate. And I will render the land by the hand of evil ones; and I will obliterate the land, and its fullness, by the hands of strangers. I the LORD have spoken. 

#### Ezekiel 30:13 For thus says the LORD God; And I will destroy the abominations, and I will rest the great ones from Memphis, and the rulers from the land of Egypt, and they will not be any longer. And I will put fear in the land of Egypt. 

#### Ezekiel 30:14 And I will destroy the land of Pathros, and I will put fire upon Tanis, and I will execute punishment in Diospolis. 

#### Ezekiel 30:15 And I will pour out my rage upon Sin, the strength of Egypt. And I will destroy the multitude of Memphis. 

#### Ezekiel 30:16 And I will appoint fire unto Egypt. And {with a disturbance shall be disturbed Sin}. And in Diospolis there will be inundation, and {shall be dispersed waters}. 

#### Ezekiel 30:17 Young men of Heliopolis and Bubastum {by the sword shall fall}, and the women {into captivity shall go}. 

#### Ezekiel 30:18 And in Tehaphnehes {shall darken the day} in my breaking there the chiefdoms of Egypt. And {shall perish there the insolence of her strength}. And {her a cloud shall cover}, and her daughters {captives shall be led}. 

#### Ezekiel 30:19 And I will execute judgment on Egypt. And they shall know that I am the LORD. 

#### Ezekiel 30:20 And it took place in the eleventh year, in the first month, the seventh of the month, {came the word of the LORD} to me, saying, 

#### Ezekiel 30:21 O son of man, {the arms of Pharaoh king of Egypt I broke}; and behold, it was not earnestly beseeched to give to him healing, to put upon him a dressing, to be given strength to take hold of the sword. 

#### Ezekiel 30:22 On account of this, thus says Adonai the LORD; Behold, I am against Pharaoh king of Egypt, and I will break his arms, the strong, and the ones being broken; and I will throw down his sword from out of his hand. 

#### Ezekiel 30:23 And I will scatter Egypt into the nations, and I will winnow them into the places. 

#### Ezekiel 30:24 And I will strengthen the arms of the king of Babylon, and I will put my broadsword into his hand. And he shall bring it upon Egypt, and he shall plunder her plunder, and he shall despoil her spoils. 

#### Ezekiel 30:25 And I will strengthen the arms of the king of Babylon, and the arms of Pharaoh shall fall; and they shall know that I am the LORD, in {putting the broadsword my} into the hands of the king of Babylon, and he shall stretch it against the land of Egypt. 

#### Ezekiel 30:26 And I will scatter Egypt into the nations, and I shall winnow them into the places; and they shall know that I am the LORD. 

#### Ezekiel 31:1 And it came to pass in the eleventh year, in the third month, day one of the month, {came the word of the LORD} to me, saying, 

#### Ezekiel 31:2 O son of man, say to Pharaoh king of Egypt, and to his multitude! To whom did you liken yourself in your haughtiness? 

#### Ezekiel 31:3 Behold, Assyria was a cypress in Lebanon, and goodly in shoots, and dense in the protection, and high in size; and {into the midst of the clouds came his top}. 

#### Ezekiel 31:4 Water nourished him, the deep made him rise up high; {the rivers she led} round about his plants, and {her collections of water she sent forth} unto all the trees of the field. 

#### Ezekiel 31:5 Because of this, {was raised up high his greatness} over all the trees of the field, and {were multiplied tender branches his}, and {were raised up high his shoots} over {water much}, in his stretching out. 

#### Ezekiel 31:6 In his shoots nested all the birds of the heaven, and underneath his tender branches {procreated all the wild beasts of the plain}; in his shadow dwelt all the multitude of nations. 

#### Ezekiel 31:7 And he became good in his height because of the multitude of his tender branches; for {existed his roots} among {water much}. 

#### Ezekiel 31:8 And {cypresses such} in the paradise of God, and the pines were not likened to his shoots; and fir trees were not likened to his branches; every tree in the paradise of God was not likened to him in his beauty. 

#### Ezekiel 31:9 Because of the multitude of his tender branches {good I made him} by the multitude of his tender branches. And {were jealous of him the trees of the paradise of the delicacy of God}. 

#### Ezekiel 31:10 On account of this, thus says Adonai the LORD; Because you became great to greatness, and you put your top into the midst of clouds; and {was lifted up his heart} unto his height; 

#### Ezekiel 31:11 even I delivered him up into the hands of the ruler of the nations; and he caused his destruction. 

#### Ezekiel 31:12 And {utterly destroyed him strangers}, pestilent ones from the nations. And they threw him down upon the mountains. In all the ravines {fell his tender branches}; and {were broken his trunks} in every plain of the land. And {went down from his protection all the peoples of the nations}, and they dashed him. 

#### Ezekiel 31:13 {upon his downfall rested All the birds of the heaven}; and upon his trunks existed all the wild beasts of the field, 

#### Ezekiel 31:14 so that {should not be exalted in their greatness all the trees by the water}, and do not put their top into the midst of clouds; and {stand not in their height against him all the ones drinking water}. All were given unto death in {of the earth the depth}, in the midst of the sons of men going down into the pit. 

#### Ezekiel 31:15 Thus says Adonai the LORD; In which day he went down into Hades, {mourned him the abyss}. And I attended to her rivers, and restrained the abundance of water. And {was darkened over him Lebanon}; all the trees of the plains {by him were enfeebled}. 

#### Ezekiel 31:16 From the sound of his downfall {shook the nations} when I brought him down unto Hades with the ones going down into the pit. And {comforted him in earth lowermost all the trees of the delicacy}, and the chosen ones and the best ones of Lebanon, all the ones drinking water. 

#### Ezekiel 31:17 For also even they went down with him into Hades with the ones slain by the sword; and his seed dwelling under his protection {in the middle of their life were destroyed}. 

#### Ezekiel 31:18 To whom are you likened in power, and in glory, and in greatness among the trees of the delicacy? Go down with the trees of the delicacy into {of the earth the depth}! {in the midst of uncircumcised You shall sleep}, with ones slain by sword. Thus Pharaoh and all the multitude of his strength, says Adonai the LORD. 

#### Ezekiel 32:1 And it took place in the twelfth year, in the twelfth month, day one of the month, {came the word of the LORD} to me, saying, 

#### Ezekiel 32:2 O son of man, take up a lamentation for Pharaoh king of Egypt! And you shall say to him, {to a lion of nations You were likened}, and as a dragon, the one in the sea. And you gored in your rivers, and disturbed water with your feet, and trampled your rivers. 

#### Ezekiel 32:3 Thus says Adonai the LORD; And I will put {upon you my net} by an assembly {peoples of many}; and I will lead you by my hook. 

#### Ezekiel 32:4 And I will stretch you upon the earth; the plains shall be filled. And I shall set upon you all the birds of the heaven; and I will fill up by you all the wild beasts of all the earth. 

#### Ezekiel 32:5 And I will put your flesh upon the mountains, and I will fill up ravines of your blood. 

#### Ezekiel 32:6 And I will water the earth from your excrement; from your multitude upon the mountains {the ravines I will fill up} with you. 

#### Ezekiel 32:7 And I will cover up {in your being extinguished the heaven}, and I will darken his stars; {the sun by a cloud I will cover}, and the moon -- in no way shall {appear her light}. 

#### Ezekiel 32:8 All the things shining light in the heaven shall darken over you, and I will appoint darkness over your land, says the Lord the LORD. 

#### Ezekiel 32:9 And I will provoke to anger the heart of many peoples, whenever I lead you as a captivity into the nations, into a land which you knew not. 

#### Ezekiel 32:10 And {shall be gloomy over you nations many}, and their kings {by a change of state shall be amazed} in the flying of my broadsword unto their faces, the ones waiting for their downfall from the day of your downfall. 

#### Ezekiel 32:11 For thus says the Lord the LORD; The broadsword of the king of Babylon shall come upon you. 

#### Ezekiel 32:12 With swords of giants even I shall throw down your strength, pestilent ones from all nations. And they shall destroy the insolence of Egypt, and {shall be broken all her strength}. 

#### Ezekiel 32:13 And I will destroy all her cattle from {water great}; and in no way shall {disturb it a foot of man} any more; and the track of cattle in no way shall trample it. 

#### Ezekiel 32:14 Then shall {be still their waters}, and their rivers {as oil shall go forth}, says Adonai the LORD. 

#### Ezekiel 32:15 Whenever I shall give Egypt unto destruction, and {shall be made desolate the land} with the fullness of it; whenever I shall scatter all the ones dwelling in it, even they shall know that I am the LORD. 

#### Ezekiel 32:16 There is a lamentation and they shall lament it; and the daughters of the nations shall lament it over Egypt; and over all her strength they shall lament her, says the Lord the LORD. 

#### Ezekiel 32:17 And it happened in the twelfth year, in the fifteenth of the month, {came the word of the LORD} to me saying, 

#### Ezekiel 32:18 O son of man, lament over the multitude of Egypt, for {shall bring down her the daughters}; even the nations dead into the depths of the earth, to the ones going down into the pit. 

#### Ezekiel 32:19 From {waters good-looking} descend and sleep with the uncircumcised! 

#### Ezekiel 32:20 Among the midst of ones slain by sword they shall fall with him, and {shall sleep all of his strength}. 

#### Ezekiel 32:21 And {shall say to you the giants}, into the depth of the pit {not best you are}; you go down and sleep with uncircumcised! in the midst of the ones slain by the sword. 

#### Ezekiel 32:22 There is Assyria and all his gathering around his grave; all slain having fallen by the sword; 

#### Ezekiel 32:23 the ones given his graves in the sides of the pit, and {existed his gathering} surrounding his tomb. All the slain having fallen by the sword, the ones giving them fear upon the land of life. 

#### Ezekiel 32:24 There is Elam and all his force surrounding his tomb; all the slain having fallen by the sword, and the ones going down uncircumcised into {of the earth the depth}, the ones putting the fear of them upon the land of life; and they took their torment with the ones going down into the pit. 

#### Ezekiel 32:25 In the midst of the slain. 

#### Ezekiel 32:26 There they put Meshech and Tubal, and all his strength surrounding his tomb; all his slain ones, all the uncircumcised ones, slain ones by the sword, the ones putting their fear upon the land of life. 

#### Ezekiel 32:27 And they sleep with the giants having fallen from the eon, the ones who went down into Hades with weapons of warfare; and they put their swords under their heads, and {came their lawless deeds} upon their bones, for they were frightened giants during their life. 

#### Ezekiel 32:28 And you {in the midst of the uncircumcised shall be destroyed}, and shall sleep with the ones being slain by sword. 

#### Ezekiel 32:29 There is Edom and her kings, and all the rulers. Assyria, the ones giving their strength to the wound of the sword; these {with the slain sleep}, with the ones going down into the pit. 

#### Ezekiel 32:30 There are the rulers of the north, all these, all the commandants of Assyria, the ones going down with the slain, with the fear of them. And in their strength being ashamed they sleep uncircumcised with ones slain of the sword; and they carry away their torment with the ones going down into the pit. 

#### Ezekiel 32:31 Those {shall see king Pharaoh}, and he shall be comforted over all their strength. Slain by the sword, Pharaoh and all his force, says the Lord the LORD. 

#### Ezekiel 32:32 For I have put the fear of him upon the land of life; yet he shall sleep in the midst of the uncircumcised with ones slain by the sword, even Pharaoh, and all his multitude, says the Lord the LORD. 

#### Ezekiel 33:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 33:2 O son of man, speak to the sons of your people, and you shall say to them, The land upon which ever I bring the broadsword, that {should take the people of the land} {man one} from out of them, and put him for themselves as a watchman. 

#### Ezekiel 33:3 And if one should behold the broadsword coming upon the land, and he should trump the trumpet, and should signify to the people, 

#### Ezekiel 33:4 and {shall hear the one hearing} the sound of the trumpet, and should not take guard, and {comes the broadsword} and overtakes him, his blood {upon his own head shall be}. 

#### Ezekiel 33:5 For {the sound of the trumpet hearing} he did not take guard; his blood {upon him shall be}. But this one that guarded {his life rescued}. 

#### Ezekiel 33:6 And the watchman, if he should behold the broadsword coming, and should not signify by the trumpet, and the people should not take guard; and coming, the broadsword should take from out of them a soul, this soul {on account of its lawlessness is taken}, but the blood of the hand of the watchman I will require. 

#### Ezekiel 33:7 And you, O son of man, {as watchman I have appointed you} to the house of Israel, and you shall hear {from out of my mouth a word}, and you shall announce to them from me. 

#### Ezekiel 33:8 And in my saying to the sinner, To death you shall die; and you should not speak to guard the impious from his way, he, the lawless one, {of his lawlessness shall die}, but his blood {of your hand I will require}. 

#### Ezekiel 33:9 But you, if you should forewarn the impious of his way to turn from it, and he should not turn from his way, this one {in his impiety shall die}; but you {soul your own rescued}. 

#### Ezekiel 33:10 And you, O son of man, say to the house of Israel! Thus you spoke, saying, Our delusions and our lawless deeds {upon us are}, and in them we melt away, and how then shall we live? 

#### Ezekiel 33:11 Say to them! As I live, says Adonai the LORD, I do not want the death of the impious, but as for {to turn the impious} from his way, and {to live for him}. By turning you turn from {way your evil}! For why do you die, O house of Israel? 

#### Ezekiel 33:12 And you O son of man, say to the sons of your people! The righteousness of the just in no way should rescue him, in which ever day he should wander. And the lawlessness of the impious in no way shall afflict him in which ever day he should turn from his lawlessness. But the just no way shall be able to be delivered in the day of his sin. 

#### Ezekiel 33:13 In my saying to the righteous that {to life he shall live}; and this one has relied upon his righteousness, and should commit lawlessness, all his righteousness in no way shall be called to mind; in his iniquity in which he committed, in it he shall die. 

#### Ezekiel 33:14 And in my saying to the impious, To death you shall be put to death; and he shall turn from his sin, and shall execute equity and righteousness, 

#### Ezekiel 33:15 and {collateral he should give back}, and {for any seizures he should pay back}, {in the orders of life and he should travel}, to not do unjustly; to life he shall live, and in no way shall he die. 

#### Ezekiel 33:16 All his sins which he sinned in no way shall be called to mind, for {equity and righteousness he observed}; by them he shall live. 

#### Ezekiel 33:17 And {shall say the sons of your people}, {is not right the way of the LORD}; but this, their way is not right. 

#### Ezekiel 33:18 In the turning of the righteous from his righteousness, and he should commit lawless deeds, he shall die in them. 

#### Ezekiel 33:19 And in the {turning sinner} from his lawlessness, and should observe equity and righteousness; by them he shall live. 

#### Ezekiel 33:20 And you said, {is not straight The way of the LORD}. {each by his ways I will judge you O house of Israel}. 

#### Ezekiel 33:21 And it came to pass in the twelfth year, in the tenth month, the fifth of the month of our captivity, there came to me one having escaped from Jerusalem, saying, {is captured the city}. 

#### Ezekiel 33:22 And the hand of the LORD came upon me at evening before he came; and he opened my mouth as he came to me in the morning; and in opening my mouth it was not held together any longer. 

#### Ezekiel 33:23 And {came the word of the LORD} to me, saying, 

#### Ezekiel 33:24 O son of man, the ones inhabiting the places being made desolate upon the land of Israel, speaking they say, {one was Abraham}, and he held down the land; and we, we are many; {to us was given the land} for a possession. 

#### Ezekiel 33:25 On account of this say to them! Thus says the Lord the LORD; {upon food with blood Since you chew}, and {your eyes lift} unto your abominations, and {blood you pour out} -- then {the land shall you inherit}? 

#### Ezekiel 33:26 And you stood with your broadswords, you did loathsome things, and each {the wife of his neighbor tainted} -- then {the land shall you inherit}? 

#### Ezekiel 33:27 Thus say to them! Thus says the Lord the LORD; As I live, assuredly the ones in the places being made desolate {swords shall fall by}, and the ones upon the face of the plain {to the wild beasts of the field shall be given} for a thing to be devoured, and the ones behind the places being walled, and the ones in the caves {by plague I will kill}. 

#### Ezekiel 33:28 And I will make the land a wilderness; and {shall perish the insolence of her strength}; and {shall be made desolate the mountains of Israel} on account of there not being anyone traveling through. 

#### Ezekiel 33:29 And they shall know that I am the LORD; and I will make their land wilderness, and it shall be made desolate on account of all their abominations which they did. 

#### Ezekiel 33:30 And you, O son of man, the sons of your people, the ones speaking concerning you by the walls and in the gatehouses of the houses, and {speaks each} to his brother, saying, We should come together and should hear the goings forth from the LORD. 

#### Ezekiel 33:31 And they come to you as {going with one another a people}, and they sit down before you, and they hear your sayings, but in no way will they do them, for the lie is in their mouth, and {after their defilements their heart goes}. 

#### Ezekiel 33:32 And should you become to them as the sound {psaltery of a sweet sounding well-tuned}, and they shall hear your words, but no way shall they do them. 

#### Ezekiel 33:33 And when ever it should come to pass, they shall say, Behold, it is come; and they shall know that a prophet was in their midst. 

#### Ezekiel 34:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 34:2 O son of man, prophesy against the shepherds of Israel! Prophesy, and say to the shepherds! Thus says the Lord the LORD; O shepherds of Israel, shall {graze the shepherds} themselves? Do not {the sheep graze the shepherds}? 

#### Ezekiel 34:3 Behold, {the milk you devour}, and the wool you put around yourselves, and the robust you slay, and my sheep you do not graze. 

#### Ezekiel 34:4 The ones being weak you strengthen not, and the ill having a sickness you rejuvenated not, and the broken you did not bind up, and the one wandering you did not turn back, and the lost you did not seek after, and the strong you worked in trouble. 

#### Ezekiel 34:5 And {were scattered my sheep} on account of there not being shepherds; and my sheep became for a thing devoured by all the wild beasts of the field. 

#### Ezekiel 34:6 And {were scattered my sheep} in every mountain, and upon every {hill high}; and {upon the face of all the earth they were scattered}; and there was not one seeking after them, nor turning them back. 

#### Ezekiel 34:7 On account of this, O shepherds, hear the word of the LORD! 

#### Ezekiel 34:8 As I live, says the Lord the LORD, Assuredly instead {became my sheep} for plunder, and {became my sheep} for a thing to be devoured by all the wild beasts of the plain, because of there not being any shepherds; and {sought not after the shepherds} my sheep; and {grazed the shepherds} themselves, but my sheep they grazed not. 

#### Ezekiel 34:9 On account of this, O shepherds, hear the word of the LORD! 

#### Ezekiel 34:10 Thus says the Lord the LORD; Behold, I am against the shepherds, and I will require my sheep from out of their hands. And I will turn them away to not tend my sheep, and {shall not graze any longer the shepherds them}. And I shall rescue my sheep from out of their mouth, and they will not be themselves any longer for a thing devoured. 

#### Ezekiel 34:11 For thus says the Lord the LORD; Behold, I shall seek after my sheep, and I shall visit them. 

#### Ezekiel 34:12 As if {seeks the shepherd} his flock in the day whenever there might be dimness and cloud in the midst of his sheep having been parted, so shall I seek after my sheep. And I will drive them away from every place of which they were scattered there, in the day of cloud and dimness. 

#### Ezekiel 34:13 And I will lead them from out of the nations, and I will gather them from the regions, and I will bring them into their land, and I will graze them upon the mountains of Israel, and in the ravines, and in every dwelling of the land. 

#### Ezekiel 34:14 {in pasture good I will graze them} on the {mountain high} of Israel, and {will be their havens} there. And they shall sleep there, and they shall rest in {luxury good}; and {in pasture a plentiful they shall graze} upon the mountains of Israel. 

#### Ezekiel 34:15 I will graze my sheep, and I will rest them. Thus says the Lord the LORD. 

#### Ezekiel 34:16 The lost I will seek, and the one wandering I will return, and the one being broken I will bind, and the faltering I will strengthen, and the strong I will guard; and I will graze them with equity. 

#### Ezekiel 34:17 And you, my sheep, thus says the Lord the LORD; Behold, I separate between sheep and sheep, rams and he-goats. 

#### Ezekiel 34:18 And is it not enough to you that {the good pasture you fed on}, and the rest of your pasture you trampled with your feet? and the place of water you drank, and the rest with your feet you disturbed? 

#### Ezekiel 34:19 And my sheep {the things trampled by your feet fed on}; and {the disturbed water under your feet they drank}. 

#### Ezekiel 34:20 On account of this, thus says the Lord the LORD; Behold, I separate between {sheep the strong} and weak. 

#### Ezekiel 34:21 With the sides and your shoulders you pushed away, and with your horns you gored, and all the faltering you squeezed out, until of which time you thrust them outside! 

#### Ezekiel 34:22 And I will deliver my sheep, and no way should they be yet for plunder; and I will judge between ram to ram. 

#### Ezekiel 34:23 And I shall raise up for them {shepherd one}; and he will tend them as my servant David. He will tend them, and he will be their shepherd. 

#### Ezekiel 34:24 And I the LORD will be to them for God, and my servant David in the midst of them a ruler. I the LORD have spoken. 

#### Ezekiel 34:25 And I will ordain with them a covenant of peace. And I will obliterate {wild beasts the ferocious} from the land; and they shall dwell in the wilderness, and shall sleep in the forests. 

#### Ezekiel 34:26 And I will put them surrounding my mountain; and I will give rain according to its time -- a rain of blessing. 

#### Ezekiel 34:27 And the trees, the ones in the plain will yield their fruit, and the earth shall yield her strength. And they shall dwell upon their land in a hope of peace. And they shall know that I am the LORD in my breaking the chain of their yoke; and I will rescue them from out of the hand of the ones reducing them to slavery. 

#### Ezekiel 34:28 And they shall not be any longer for plunder by the nations. And the wild beasts of the land no longer in any way shall eat them. And they shall dwell in hope, and there will not be one frightening them. 

#### Ezekiel 34:29 And I will raise up to them a plant of peace, and no longer shall they be ones being destroyed by hunger upon the land; and in no way they shall bear any longer the scorning of nations. 

#### Ezekiel 34:30 And they shall know that I am the LORD their God with them, and they are my people, O house of Israel, says the Lord the LORD. 

#### Ezekiel 34:31 And you are my sheep; even sheep of my pasture -- {men you are}, and I am the LORD your God, says the Lord the LORD. 

#### Ezekiel 35:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 35:2 O son of man, turn your face against mount Seir, and prophesy unto it! 

#### Ezekiel 35:3 And say to it! Thus says the Lord the LORD; Behold, I am against you mount Seir, and I will stretch out my hand against you, and I will make you into a wilderness, and you shall be made desolate. 

#### Ezekiel 35:4 And {your cities desolate I will make}, and you will be a wilderness, and you shall know that I am the LORD. 

#### Ezekiel 35:5 Because you became {enemy an eternal}, and sat in place against the house of Israel with treachery, by the hand of enemies with a sword, in time of iniquity, at the last. 

#### Ezekiel 35:6 On account of this, as I live, says the Lord the LORD; Since {unto blood you sinned}, even blood shall pursue you. And blood you detested, even blood shall pursue you. 

#### Ezekiel 35:7 And I will appoint mount Seir for a wilderness, and for being made desolate; and I will destroy from it men and beasts. 

#### Ezekiel 35:8 And I will fill up {of the slain your hills and your ravines}; and in all your plains ones being slain by the sword shall fall among you. 

#### Ezekiel 35:9 {desolation an eternal I will establish you}, and your cities no way shall be inhabited any longer. And you shall know that I am the LORD. 

#### Ezekiel 35:10 On account of your saying, The two nations, and the two places will be mine, and I shall inherit them, and the LORD is there. 

#### Ezekiel 35:11 On account of this, as I live, says the LORD; Even I will do to you according to your hatred, and according to your zeal which you did in your detesting them; and I shall be known to you whenever I judge you. 

#### Ezekiel 35:12 And you shall know that I am the LORD. I heard the voice of your blasphemies. That you said, The {mountains of Israel wilderness to us have been given} for a thing to be devoured. 

#### Ezekiel 35:13 And you spoke great words against me with your mouth; and you called out loud against me -- your words I heard. 

#### Ezekiel 35:14 Thus says the LORD; In the gladness of all the earth, {a wilderness I will make you}. 

#### Ezekiel 35:15 As you were glad in the inheritance of the house of Israel, that it was obliterated, thus I shall do you. For you will be a wilderness, O mount Seir, and all Edom shall be completely consumed. And you shall know that I am the LORD God. 

#### Ezekiel 36:1 And you, O son of man, prophesy against the mountains of Israel! and say to the mountains of Israel! Hear the word of the LORD! 

#### Ezekiel 36:2 Thus says the Lord the LORD; Because {said against you the enemy}, Well done, {desolate places the eternal for now our possession became}. 

#### Ezekiel 36:3 On account of this, prophesy and say! Thus says the Lord the LORD; Because of you being dishonored, and being detested by the ones round about you, for you to be for a possession to the rest of the nations, and you ascended {of discussion as a tongue}, and a scorn to nations. 

#### Ezekiel 36:4 On account of this, O mountains of Israel, hear the word of the LORD. Thus says the LORD to the mountains, and to the hills, and to the rushing streams, and to the ravines, and to the places being made quite desolate, and being obliterated, and to the cities being abandoned, and became for plunder and for trampling to the {being left behind nations surrounding}. 

#### Ezekiel 36:5 On account of this, thus says the Lord the LORD; Assuredly by fire of my rage I spoke against the remaining nations, and against all Edom; for they gave my land to themselves for a possession with gladness, dishonoring lives, to obliterate in plunder. 

#### Ezekiel 36:6 On account of this, prophesy over the land of Israel! and say to the mountains, and to the hills, and to the ravines, and to the groves! Thus says the LORD; Behold, I in my zeal and in my rage spoke against your scorning which nations bore to you. 

#### Ezekiel 36:7 On account of this, thus says the Lord the LORD; I shall lift my hand against the nations, the ones surrounding you; these {their dishonor shall bear}. 

#### Ezekiel 36:8 But your {O mountains of Israel grape and your fruit shall eat my people}; for they are hoping to come. 

#### Ezekiel 36:9 For behold, I am for you, and I will look upon you, and you shall be worked and sown. 

#### Ezekiel 36:10 And I will multiply upon you men, all the house of Israel to the end. And {shall be inhabited the cities}, and the place being made desolate shall be built. 

#### Ezekiel 36:11 And I will multiply upon you men and cattle; and they shall be multiplied, and they shall be increased. And I will settle you as the time in your beginning. And {good I will do you} as the things prior of you. And you shall know that I am the LORD. 

#### Ezekiel 36:12 And I will engender unto you men against my people Israel; and they shall inherit you, and you will be to them for a possession, and in no way shall you be added still to be made childless of them. 

#### Ezekiel 36:13 Thus says the Lord the LORD; Because they said to you, O her devouring men, and {made childless by your nation you were}. 

#### Ezekiel 36:14 On account of this {men no longer shall you devour}, and {your nation you shall not make} childless any more, says the Lord the LORD. 

#### Ezekiel 36:15 And {shall not be heard any longer against you dishonor of nations}. And the scorning of peoples no way shall you bear any more, and your nation shall not be childless still, says the Lord the LORD. 

#### Ezekiel 36:16 And {came the word of the LORD} to me, saying, 

#### Ezekiel 36:17 O son of man, the house of Israel dwelt upon their land, and they defiled it by their way, and by their uncleannesses; and according to the uncleanness of a woman sitting apart was their way before my face. 

#### Ezekiel 36:18 And I poured out my rage upon them for the blood of which they poured out upon the land; and in their abominations they tainted it. 

#### Ezekiel 36:19 And I scattered them into the nations, and winnowed them into the places. According to their way and according to their sin I judged them. 

#### Ezekiel 36:20 And they entered unto the nations of which they entered there. And they profaned {name my holy} in the saying of them, {the people of the LORD These are}, and {from out of his land they went forth}. 

#### Ezekiel 36:21 And I spared them on account of {name my holy}, which {profaned the house of Israel} among the nations of which they entered there. 

#### Ezekiel 36:22 On account of this, say to the house of Israel! Thus says the Lord the LORD; Not to you do I act, O house of Israel, but because of {name my holy} which you profaned among the nations of which you entered there. 

#### Ezekiel 36:23 And I will sanctify {name my great} being profaned among the nations, which you profaned in the midst of them. And {shall know the nations} that I am the LORD, says the Lord the LORD, in my being sanctified among you before their eyes. 

#### Ezekiel 36:24 And I will take you from out of the nations, and I will gather you from out of all the lands, and I will bring you into your land. 

#### Ezekiel 36:25 And I will sprinkle upon you clean water, and you shall be cleansed from all your uncleannesses; and {from all your idols I will cleanse you}. 

#### Ezekiel 36:26 And I will put in you {heart a new}, and {spirit a new I will put} in you, and I will remove the {heart stone} from your flesh, and I will give to you a heart of flesh. 

#### Ezekiel 36:27 And {my spirit I will put} in you, and I shall make it that {by my ordinances you shall go}, and {my judgments you shall keep}, and you shall observe them. 

#### Ezekiel 36:28 And you shall dwell upon the land which I gave to your fathers; and you will be to me for a people, and I will be to you for God. 

#### Ezekiel 36:29 And I will deliver you from out of all your uncleannesses. And I will call for the grain, and I will multiply it, and I will not appoint {unto you famine}. 

#### Ezekiel 36:30 And I will multiply the fruit of the tree, and the produce of the field, so that you should not take still the scorn of famine among the nations. 

#### Ezekiel 36:31 And you shall remember {ways your evil}, and your practices, the ones not good. And you shall loathe in front of them in your lawless deeds, and for your abominations. 

#### Ezekiel 36:32 Not for your sakes do I do this, says the Lord the LORD, {made known it is to you}. Be ashamed and feel remorse for your ways, O house of Israel! 

#### Ezekiel 36:33 Thus says the Lord the LORD; In the day in which I shall cleanse you from out of all your lawless deeds, even I will settle the cities and {shall be built up desolate places}. 

#### Ezekiel 36:34 And the land having been obliterated shall be worked; for reason that being obliterated according to the eyes of all traveling by. 

#### Ezekiel 36:35 And they shall say, That land, the one being obliterated was become as a garden of luxury; and the cities -- the desolate and ones having been obliterated, and having been razed, {fortified they sat}. 

#### Ezekiel 36:36 And {shall know the nations}, as many as might be left behind round about you, that I the LORD built up the places having been demolished; and I planted the places having been obliterated. For I the LORD spoke, and I will act. 

#### Ezekiel 36:37 Thus says the Lord the LORD; Again for this I shall be sought by the house of Israel to deal with them; I will multiply them -- {as sheep men}, 

#### Ezekiel 36:38 as {sheep holy}, as sheep of Jerusalem in her holiday feasts; thus {will be the cities desolate} full of sheep of men. And they shall know that I am the LORD. 

#### Ezekiel 37:1 And {came upon me the hand of the LORD}, and it led me by spirit of the LORD, and put me in the midst of the plain, and this was full of bones of humans. 

#### Ezekiel 37:2 And he led me unto them, round about in a circuit. And behold, {many exceedingly} were upon the face of the plain -- {dry exceedingly}. 

#### Ezekiel 37:3 And he said to me, O son of man, shall {live bones these}? and I said, O Lord, O LORD, you know these things. 

#### Ezekiel 37:4 And he said to me, Prophesy over these bones! and you shall say to them, O {bones dry}, hear the word of the LORD. 

#### Ezekiel 37:5 Thus says the Lord the LORD to these bones; Behold, I shall bring into you a spirit of life. 

#### Ezekiel 37:6 And I shall put upon you nerves, and I will lead {upon you flesh}, and I shall stretch out upon you skin, and I will put my spirit into you, and you shall live, and you shall know that I am the LORD. 

#### Ezekiel 37:7 And I prophesied as he gave charge to me. And came to pass a sound in my prophesying, and behold, a quake; and came forward the bones to bone to its joint. 

#### Ezekiel 37:8 And I beheld, and behold, upon them nerves and flesh germinated, and {ascended upon them skin} above; but {breath there was no} in them. 

#### Ezekiel 37:9 And he said to me, Prophesy over the wind! Prophesy, O son of man, and say to the wind! Thus says the Lord the LORD; From out of the four winds, come wind and breathe onto these dead, and let them live! 

#### Ezekiel 37:10 And I prophesied in so far as he gave charge to me, and {entered into them the wind}, and they lived; and they stood upon their feet, {gathering great a very exceedingly}. 

#### Ezekiel 37:11 And the LORD spoke to me, saying, O son of man, these bones {all the house of Israel are}. And they say, {dry are bones Our}; {is destroyed hope our}; we are perished. 

#### Ezekiel 37:12 On account of this prophesy and say! Thus says the Lord the LORD; Behold, I shall open your tombs, and I shall lead you from out of your tombs, and I will bring you into the land of Israel. 

#### Ezekiel 37:13 And you shall know that I am the LORD, by my opening your graves, for me to lead you from out of your graves, O my people. 

#### Ezekiel 37:14 And I will put my spirit into you, and you shall live. And I will put you upon your land, and you shall know that I the LORD have spoken, and I will act, says the LORD. 

#### Ezekiel 37:15 And {came the word of the LORD} to me, saying, 

#### Ezekiel 37:16 And you, O son of man, take to yourself {rod one}, and write upon it, Judah, and the sons of Israel of the ones set before by him! And {rod a second you shall take to yourself}, and you shall write on it, To Joseph, the rod of Ephraim, and all the sons of Israel, of the ones set before by him. 

#### Ezekiel 37:17 And you shall join them to one another to yourself, {into rod one to bind them}; and they will be in your hand. 

#### Ezekiel 37:18 And it will be whenever {shall speak to you the sons of your people}, saying, Will you not report to us what these things are to you? 

#### Ezekiel 37:19 And you shall say to them, Thus says the LORD God; Behold, I shall take the tribe of Joseph, the one through the hand of Ephraim, and the tribes of Israel, the ones lying near to him, and I will appoint them unto the tribe of Judah, and they shall be for {rod one}, and they shall be one in the hand of Judah. 

#### Ezekiel 37:20 And {shall be the rods upon which you wrote upon them} in your hand before them. 

#### Ezekiel 37:21 And you shall say to them, Thus says the Lord the LORD; Behold, I take all the house of Israel from out of the midst of the nations which they entered there; and I will gather them from all of the ones surrounding them; and I will bring them into the land of Israel. 

#### Ezekiel 37:22 And I will make them one nation in my land on the mountains of Israel; and {ruler one} will be for all these for king. And they will not be any longer for two nations, nor shall they be divided any longer into two kingdoms; 

#### Ezekiel 37:23 that they should not be defiled any longer by their idols, and in their stumblings, and in all their impieties. And I will rescue them from all their lawless deeds which they sinned by them, and I will cleanse them. And they will be to me for a people, and I will be to them for God. 

#### Ezekiel 37:24 And my servant David will be ruler in the midst of them; and there will be {shepherd one} for all. For by my orders they shall go, and my judgments they shall keep, and they shall do them. 

#### Ezekiel 37:25 And they shall dwell upon their land of which I gave to my servant Jacob, of which place {dwelt there their fathers}. And they shall dwell upon it, they and their sons and the sons of their sons unto the eon; and David my servant ruling them into the eon. 

#### Ezekiel 37:26 And I will ordain with them a covenant of peace; {covenant an eternal it will be} with them. And I will put them and multiply them; and I will put my holy things in their midst into the eon. 

#### Ezekiel 37:27 And {will be my shelter} among them; and I will be to them God, and they will be my people. 

#### Ezekiel 37:28 And {shall know the nations} that I am the LORD sanctifying them, in the being of my holy things in their midst into the eon. 

#### Ezekiel 38:1 And {came the word of the LORD} to me, saying, 

#### Ezekiel 38:2 O son of man, firmly fix your face against Gog, and the land of Magog, ruler of Rosh, Meshech, and Tubal, and prophesy against him! 

#### Ezekiel 38:3 And say! Thus says the Lord the LORD; Behold, I am against you ruler of Rosh, Meshech, and Tubal. 

#### Ezekiel 38:4 And I will lead you about, and I will put a bridle into your jaws. And I will gather you, and all your force -- horses and horsemen, {putting on chest- plates all}; {gathering a great} -- small shields and helmets and swords; 

#### Ezekiel 38:5 Persians, and Ethiopians, and Libyans; all with helmets and small shields. 

#### Ezekiel 38:6 Gomer and all the ones around him; the house of Togarmah from the extreme north, and all the ones around him; and {nations many} with you. 

#### Ezekiel 38:7 Be prepared! Prepare yourself! you and all your gathering being brought together with you. And you will be to me for an advance guard. 

#### Ezekiel 38:8 After {days many more} he shall be prepared, and upon the latter end of years he shall come unto the land returning from swords being gathered from many nations upon the land of Israel, which was desolate wholly. And this one {from out of nations comes forth}; and they shall dwell in peace all together. 

#### Ezekiel 38:9 And you shall ascend as rain, and shall come as a cloud to cover up the land -- and you shall be, and all the ones around you, and {nations many} with you. 

#### Ezekiel 38:10 Thus says the Lord the LORD; And it will be in that day {will ascend things} upon your heart, and you shall consider {devices wicked}. 

#### Ezekiel 38:11 And you shall say, I will ascend upon the land having been thrown away; I will come upon ones being still at rest, and living in peace, all dwelling in a land in which no {exists wall}, nor bars, and {doors there are no} among them; 

#### Ezekiel 38:12 to plunder plunder, and to despoil spoils, to turn my hand against the place having been made desolate which was settled, and against a nation being gathered from many nations, having produced possessions, dwelling upon the navel of the earth. 

#### Ezekiel 38:13 Sheba, and Dedan, and merchants of Carthage, and all their towns shall say to you, For plunder {to plunder you come}, and to despoil spoils. You gathered together your gathering to take silver and gold, to carry away property, to despoil {spoils great}. 

#### Ezekiel 38:14 On account of this, prophesy O son of man, and say to Gog! Thus says the LORD; Will you not in that day, in the settling of my people Israel in peace, arise? 

#### Ezekiel 38:15 And you shall come from out of your place, from the extreme of the north, and {nations many} with you, {riders having horses all}, {gathering a great}, and a great force. 

#### Ezekiel 38:16 And you shall ascend against my people Israel as a cloud to cover the land. At the latter end of the days it will be. And I will lead you against my land, that {shall know all the nations} me, in my being sanctified among you before them. 

#### Ezekiel 38:17 Thus says the Lord the LORD; O Gog, you are concerning of whom I spoke about {days in former}, by the hand of my servants the prophets of Israel, the ones prophesying in those days and years, to lead you unto them. 

#### Ezekiel 38:18 And it will be in that day, in the day which ever {should come Gog} against the land of Israel, says the Lord the LORD, {shall ascend my rage}. 

#### Ezekiel 38:19 And my zeal in fire of my anger I spoke. Assuredly, in that day there will be {quake a great} upon the land of Israel. 

#### Ezekiel 38:20 And {shall shake before my face the fishes of the sea}, and the birds of the heaven, and the wild beasts of the plain, and all the reptiles crawling upon the earth, and all the men upon the face of the earth. And {shall tear the mountains}, and {shall fall the ravines}, and every wall upon the land shall fall. 

#### Ezekiel 38:21 And I will call upon him every fear, says the LORD. The sword of a man {against his brother will be}. 

#### Ezekiel 38:22 And I will judge him by plague, and blood, and {rain flooding}, and stones of hail; and fire and sulphur I will rain upon him, and upon all the ones with him, and upon {nations many} with him. 

#### Ezekiel 38:23 And I will be magnified, and I will be sanctified, and I will be glorified, and I shall be known before many nations, and they shall know that I am the LORD. 

#### Ezekiel 39:1 And you, O son of man, prophesy against Gog, and say, Thus says the Lord the LORD; Behold, I am against you Gog ruler of Rosh, Meshech, and Tubal! 

#### Ezekiel 39:2 And I will gather you, and I will lead you down, and I will haul you from the extreme north, and I will lead you upon the mountains of Israel. 

#### Ezekiel 39:3 And I will destroy your bow from {hand your left}, and your arrows from {hand your right}. 

#### Ezekiel 39:4 And I will throw you down upon the mountains of Israel; and you shall fall, you and all the ones around you. And the nations, the ones with you shall be given to a multitude of birds, to every winged creature; and {to all the wild beasts of the plain I have given you} to be devoured. 

#### Ezekiel 39:5 Upon the face of the plain you shall fall, for I spoke, says the Lord the LORD. 

#### Ezekiel 39:6 And I will send fire upon Magog, and {shall be inhabited the islands} in peace. And they shall know that I am the LORD. 

#### Ezekiel 39:7 And {name my holy} will be known in the midst of my people Israel; and {shall not be profaned name my holy} any longer. And {shall know the nations} that I am the LORD, the holy one in Israel. 

#### Ezekiel 39:8 Behold, it is come, and you shall know that it will be, says the Lord the LORD; this is the day in which I spoke. 

#### Ezekiel 39:9 And {shall come forth the ones dwelling the cities of Israel}, and they shall kindle a fire with the weapons -- small shields, and shafts, and bows, and arrows, and rods of the hands, and lances; and they shall kindle with them a fire for seven years. 

#### Ezekiel 39:10 And no way shall they take trees from out of the plain, nor shall they fell trees from out of the groves; but only the weapons shall they incinerate with fire. And they shall plunder the ones plundering them, and shall despoil the ones despoiling them, says the LORD. 

#### Ezekiel 39:11 And it will be in that day I will appoint Gog a place of renown -- a memorial in Israel, a cemetery of the ones coming by the sea. And they shall enclose the cleft of the ravine, and they shall bury Gog there, and all his multitude. And it shall be called then, The Cemetery of Gog. 

#### Ezekiel 39:12 And {shall bury them the house of Israel}, that {should be cleansed the land} in seven months. 

#### Ezekiel 39:13 And {shall bury them all the people of the land}; and it will be to them for a famous place in which day I was glorified, says the Lord the LORD. 

#### Ezekiel 39:14 And {for men continually they shall give orders} for coming over the land to bury the ones being left upon the face of the earth, to cleanse it. After the seven months, and they shall seek. 

#### Ezekiel 39:15 And every one traveling over the land, and seeing the bone of a man, shall build {by it a sign}, until whenever {shall bury it the ones burying} in the cemetery of Gog. 

#### Ezekiel 39:16 For even the name of the city is Cemetery; and {shall be cleansed the land}. 

#### Ezekiel 39:17 And you son of man, thus says the Lord the LORD; Speak to every {bird winged}, and to all the wild beasts of the plain! saying, Gather together and come! Be gathered together from all the surrounding places unto my sacrifice! which I sacrificed to you, {sacrifice a great} upon the mountains of Israel, and you shall eat meats, and drink blood. 

#### Ezekiel 39:18 {meats of giants You shall eat}, and {blood of rulers of the earth you shall drink}, rams, and calves, and he-goats, and the calves all growing fat. 

#### Ezekiel 39:19 And you shall eat fat unto fullness, and you shall drink blood unto intoxication from my sacrifice in which I sacrificed to you. 

#### Ezekiel 39:20 And you shall be filled from my table -- horse, and rider, and giant, and every male warrior, says the Lord the LORD. 

#### Ezekiel 39:21 And I will put my glory among you, and {shall see all the nations} my judgment which I did, and my hand which I brought upon them. 

#### Ezekiel 39:22 And {shall know the house of Israel} that I am the LORD their God, from this day and beyond. 

#### Ezekiel 39:23 And {shall know all the nations} that {on account of their sin was captured the house of Israel}, because they annulled covenant against me, and I turned my face from them, and delivered them into the hands of their enemies, and they all fell by the sword. 

#### Ezekiel 39:24 Because of their uncleannesses, and because of their violations of the law I did it to them, and I turned my face from them. 

#### Ezekiel 39:25 On account of this, thus says the Lord the LORD; Now I will return the captivity in Jacob, and I will show mercy on the house of Israel, and I will be jealous on account of {name my holy}. 

#### Ezekiel 39:26 And they shall take their own dishonor, and the iniquity which they transgressed in their settling upon their land in peace, and there will not be one frightening, 

#### Ezekiel 39:27 in my returning them from out of the nations, and my gathering them from out of the places of the nations; and I shall be sanctified among them before the nations. 

#### Ezekiel 39:28 And they shall know that I am the LORD their God in my appearing to them among the nations, in my gathering them upon their land. And I shall not abandon them any more -- not one there. 

#### Ezekiel 39:29 And I shall not turn {any longer my face} from them, because I poured out my rage upon the house of Israel, says the Lord the LORD. 

#### Ezekiel 40:1 And it came to pass in the fifth and twentieth year of our captivity, in the first month, the tenth of the month, in the fourteenth year after the capturing the city, in that day {came upon me the hand of the LORD}, 

#### Ezekiel 40:2 and it led me in a vision of God into the land of Israel, and put me upon {mountain high an exceedingly}. And upon it was as the construction of a city before me. 

#### Ezekiel 40:3 And he brought me there, and behold, a man. And his appearance was as the appearance {brass of shining}, and in his hand was a string measure of builders, and a reed measure. And he set them at the gate. 

#### Ezekiel 40:4 And {said to me the man}, You see, O son of man! With your eyes behold, and with your ears hear, and arrange in your heart all as much as I show to you! For on account of showing to you you entered here. And I will show all things, as much as you see in the house of Israel. 

#### Ezekiel 40:5 And behold, there was an enclosure from outside the house round about, and in the hand of the man was a reed, the measure {cubits of six} by a cubit and a palm. And he measured the area around the wall; the width equal to the reed, and the height of it equal to the reed. 

#### Ezekiel 40:6 And he entered into the gate, the one looking according to the east, by seven steps. And he measured the vestibule -- six by six; the columned porch of the gate was equal to the reed in width. 

#### Ezekiel 40:7 And the vestibule was equal to the reed in length, and equal to the reed in width; and the columned porch in the midst of the chambers -- {cubits six}. And the {vestibule second} was equal to the reed in width, and equal to the reed in length; and the columned porch -- {cubits five}. 

#### Ezekiel 40:8 And the {vestibule third} equal to the reed in length, and equal to the reed in width. 

#### Ezekiel 40:9 And the columned porch of the gatehouse neighboring the columned porch of the gate -- {cubits eight}, and the portals -- {cubits two}, and the columned porches of the gate were inside. 

#### Ezekiel 40:10 And the columned porch of the gate within, and the vestibule of the gate in front, were three on this side and three on that side; and {measure there was one} to the three; {measure one} to the columned porches on this side and that side. 

#### Ezekiel 40:11 And he measured the width of the door of the gatehouse -- {cubits ten}; and the breadth of the gatehouse -- {cubits thirteen}. 

#### Ezekiel 40:12 And {cubit one} assembling in front of the vestibules; and {cubit one} border on this side and on that side. And the vestibule -- {cubits six} on this side, and {cubits six} on that side. 

#### Ezekiel 40:13 And he measured the gate from the wall of the vestibule unto the wall of the vestibule; the width -- {cubits twenty five}, this gate unto gate. 

#### Ezekiel 40:14 And the open space of the columned porch of the gate -- sixty cubits, and to the vestibules of the gate round about. 

#### Ezekiel 40:15 And the open space of the gate outside to the open space of the columned porch of the gate inside -- {cubits fifty}. 

#### Ezekiel 40:16 And there were {windows hidden} unto the vestibules, and unto the columned porches inside the gate of the courtyard round about, and likewise of the pediments windows round about inside; and {for the columned porch there were palms} on this side and that side. 

#### Ezekiel 40:17 And he brought me into the {courtyard inner}. And behold, there were cubicles and peristyles of the courtyard round about; thirty cubicles in the peristyles. 

#### Ezekiel 40:18 And the stoas were according to the back of the gates; {was according to the length of the gates the peristyle underneath}. 

#### Ezekiel 40:19 And he measured the width of the courtyard from the open space of the {gate outer} unto the inner; unto the open space of the gate inner looking outside -- {cubits a hundred} of the one looking according to the east; and he led me unto the north. 

#### Ezekiel 40:20 And behold, there was a gate looking to the north belonging to the {courtyard outer}; and he measured it, the length of it, and the width; 

#### Ezekiel 40:21 and the vestibule -- three on this side and three on that side; and the portal, and the pediments, and its palms. And it was according to the measures of the gate looking according to the east; {cubits was fifty its length}, and {cubits twenty-five its breadth}. 

#### Ezekiel 40:22 And its windows, and the pediments, and its palms were as the gate looking according to the east. And in seven steps they ascended unto it; and the pediments were within. 

#### Ezekiel 40:23 And there was a gate to the {courtyard inner} looking towards the gate of the north, in the manner of the gate looking according to the east. And he measured the courtyard from gate unto gate -- {cubits a hundred}. 

#### Ezekiel 40:24 And he led me according to the south. And behold, there was a gate looking to the south; and he measured it, and the vestibules, and the portals, and the pediments according to these measures. 

#### Ezekiel 40:25 And its windows and the pediments round about were as the windows of the columned porch; {cubits was fifty its length}, and {cubits twenty-five} its breadth. 

#### Ezekiel 40:26 And there were seven steps for it, and pediments within, and its palms were one on this side and one on that side upon the portals. 

#### Ezekiel 40:27 And there was a gate opposite of the gate of the {courtyard inner} to the south. And he measured the courtyard from gate unto gate -- {cubits a hundred} was the breadth towards the south. 

#### Ezekiel 40:28 And he brought me into the {courtyard inner} of the gate, of the one towards the south. And he measured the gate according to these measures; 

#### Ezekiel 40:29 and the vestibules, and the portals, 

#### Ezekiel 40:30 and the pediments, according to these measures. And there were windows to it; and to the pediment round about -- {cubits fifty} the length, and its breadth -- {cubits twenty-five}. 

#### Ezekiel 40:31 And its pediments to the {courtyard outer} -- palms to the portals and with eight steps ascending upon it. 

#### Ezekiel 40:32 And he brought me into the {courtyard inner} a way according to the east. And he measured the door according to these measures; 

#### Ezekiel 40:33 and the vestibules, and the portals, and the pediments according to these measures; and its windows and the pediments round about. {cubits Fifty} was the length, and its breadth twenty-five cubits. 

#### Ezekiel 40:34 And there were pediments opening the {courtyard inner}, and palms of its portals on this side and that side, and eight steps ascending upon it. 

#### Ezekiel 40:35 And he brought me unto the door, the one towards the north; and he measured according to these measures; 

#### Ezekiel 40:36 and the vestibules, and the portals, and the pediments; and its windows round about. {cubits Fifty} was the length, and the breadth {cubits twenty-five}. 

#### Ezekiel 40:37 And the portals of {courtyard outer}, and palms of portals on this side and that side, and eight steps. 

#### Ezekiel 40:38 And its cubicles and its doorways, and its pediments were at the {gate second} outflow, 

#### Ezekiel 40:39 so that they should slay in it the things for a sin offering, and the things for an ignorance offering. 

#### Ezekiel 40:40 And in back of the overflow of the whole burnt-offerings, of the part looking to the north, were two tables; and according to the back of the other and to the columned porch of the gate were two tables according to the east. 

#### Ezekiel 40:41 Four tables were on this side, and four on that side, according to the back of the gate; upon them they slay the things offered for sacrifices. And over against the eight tables of the things offered for sacrifices. 

#### Ezekiel 40:42 And there were four tables of the whole burnt-offerings, {stones having been made of dressed} -- a cubit and a half was the width, and {cubits two} and a half was the length; and a cubit was the height; upon them they placed the items with which they slew the whole burnt-offerings there, and the animals which are offered in sacrifice. 

#### Ezekiel 40:43 And {a palm sized they shall have waved border dressed stone} inside round about; and over the tables on top were roofs to cover up from the rain and the dryness. 

#### Ezekiel 40:44 And he brought me into the {courtyard inner}; and behold, there were two inner chambers in the {courtyard inner}; one according to the back of the gate of the one to the north bearing according to the south. And one according to the back of the gate of the one towards the south of the one looking towards the north. 

#### Ezekiel 40:45 And he said to me, This inner chamber, the one looking towards the south is to the priests, the ones keeping the guard of the house. 

#### Ezekiel 40:46 And the inner chamber, the one looking towards the north is to the priests, to the ones keeping the guard of the altar; those are the sons of Zadok, the ones approaching of the sons of Levi towards the LORD to officiate to him. 

#### Ezekiel 40:47 And he measured the courtyard length -- {cubits a hundred}, and the breadth {cubits a hundred} upon {four parts its}; and the altar before the house. 

#### Ezekiel 40:48 And he brought me unto the columned porch of the house; and he measured the portal of the columned porch -- {cubits five} was the width on this side, and {cubits five} on that side; and the breadth of the doorway -- {cubits fourteen}, and side-pieces of the door of the columned porch -- {cubits three} on this side, and {cubits three} on that side. 

#### Ezekiel 40:49 And the length of the columned porch -- {cubits twenty}, and the breadth -- {cubits twelve}; and upon ten stairs they ascended unto it; and there were columns upon the columned porch, one from here and one from here. 

#### Ezekiel 41:1 And he brought me into the temple, and he measured the columned porch -- {cubits six} the breadth of the columned porch on this side, and the width {cubits six} on that side -- the breadth of the tent. 

#### Ezekiel 41:2 And the breadth of the gatehouse -- {cubits ten}; and the side-pieces of the gatehouse -- {cubits five} on this side and {cubits five} on that side; and he measured its length -- {cubits forty}, and the breadth -- {cubits twenty}. 

#### Ezekiel 41:3 And he entered into the {courtyard inner}, and he measured the portal of the doorway -- {cubits two}; and the doorway -- {cubits six}; and the side-pieces of the doorway -- {cubits seven} on this side. 

#### Ezekiel 41:4 And he measured the length of the gates -- {cubits twenty}, and the breadth -- {cubits twenty} in front of the temple. And he said to me, This is the holy of the holies. 

#### Ezekiel 41:5 And he measured the wall of the house -- {cubits six}; and the breadth of the side -- {cubits four} round about. 

#### Ezekiel 41:6 And the sides, side by side -- thirty and of threes; and a space in the wall of the house at the sides round about, to be for the ones taking hold to see, so as to thoroughly not touch the walls of the house. 

#### Ezekiel 41:7 And the breadth of the higher of the sides was according to the appendage protruding out of the wall, to the higher one round about the house, so as to flatten out wider above; so that from out of the parts below they should ascend unto the upper rooms, and from out of the middles unto the third stories. 

#### Ezekiel 41:8 And the thraels of the house height round about was a space of the sides equal to the reed {cubits of six} intervals. 

#### Ezekiel 41:9 And the breadth of the wall of the side from outside -- {cubits five}; and the spaces left over between the sides of the house. 

#### Ezekiel 41:10 And between the inner chambers a breadth {cubits of twenty}, the circumference of the house round about. 

#### Ezekiel 41:11 And the doors of the inner chambers were unto the space left over of the {door one} of the one towards the north, and the {door one} towards the south; and the breadth of the place left over -- {cubits five} width round about. 

#### Ezekiel 41:12 And the separate space in front of the left over space of the place towards the west -- {cubits seventy} width of the wall of the separating; and {cubits five} the breadth round about, and its length -- {cubits ninety}. 

#### Ezekiel 41:13 And he measured over against the house -- {length cubits a hundred}, and the spaces left over, and the places separating, and its walls -- {length cubits a hundred}. 

#### Ezekiel 41:14 And the breadth in front of the temple, and the spaces left over opposite -- {cubits a hundred}. 

#### Ezekiel 41:15 And he measured the length of the place separating in front of the spaces left over of the spaces from behind that house; and the spaces left over on this side and that side -- {cubits a hundred} length; and the temple, and the corners, and the columned {porch outer} were decorated with fretwork. 

#### Ezekiel 41:16 And the windows were latticed narrow openings round about to the three stories, so as to look through; and the house and the places near were boarded round about, even from the floor unto the windows; and the windows unfolded thrice for looking through. 

#### Ezekiel 41:17 And unto the {house inner} and the outer, and upon the entire wall round about the inside and the outside, 

#### Ezekiel 41:18 were carved cherubim, and palms between cherub and cherub, two faces to the cherub. 

#### Ezekiel 41:19 The face of a man towards the palm on this side, and the face of a lion towards the palm that side -- {was carved all the house} round about. 

#### Ezekiel 41:20 From the floor unto fretwork, cherubim and palms having been carved. 

#### Ezekiel 41:21 And the holy place, and the temple, unfolded four-cornered. In front of the holy places was the vision as the appearance 

#### Ezekiel 41:22 {altar of a wooden}, {cubits three} was its height, and {cubits two} the length, and the breadth -- {cubits two}; and {horns it had}, and its base and its walls were wooden. And he said to me, This is the table before the face of the LORD. 

#### Ezekiel 41:23 And there were two doorways to the temple; and to the holy place two doorways to the two doorways to the turnings; 

#### Ezekiel 41:24 two doorways to the one, and two doorways to the {door second}. 

#### Ezekiel 41:25 And a carving was upon them, and upon the doorways of the temple -- cherubim and palms according to the carving of the holy places; and there were seasoned timbers in front of the columned porch outside. 

#### Ezekiel 41:26 And there were {windows hidden}; and he measured on this side and that side unto the roofing of the columned porch; and the sides of the house were joined together. 

#### Ezekiel 42:1 And he brought me into the {courtyard outer}, according to the east, opposite of the gate of the one towards the north. And he brought me, and behold, {inner chambers there were five} being next to the space left over, and next to the place separating near the north, 

#### Ezekiel 42:2 {cubits a hundred} in length towards the north, and the breadth {cubits fifty}, 

#### Ezekiel 42:3 being diagramed in which manner the gates of the {courtyard inner}, and in which manner the peristyles of the {courtyard outer}, were being set in rows facing {stoas three rank}. 

#### Ezekiel 42:4 And over against the inner chambers was a promenade {cubits ten} width by {cubits a hundred} in length, for the inner way {cubit one}; and their doorways towards the north. 

#### Ezekiel 42:5 And the {promenades upper} were likewise; for {protruded the peristyle} from out of it, from out of the {beneath peristyle}, and the interval; thus a peristyle and an interval and thus. 

#### Ezekiel 42:6 For they were triple, and {columns they did not have} as the columns of the inner chambers; on account of this they protruded from the ones beneath, and the ones in the middle from the ground. 

#### Ezekiel 42:7 And the doorway outside in which manner the inner chambers of the courtyard of the one outside, the ones looking before the inner chambers of the ones towards the north -- {in length cubits fifty}. 

#### Ezekiel 42:8 For the length of the inner chambers of the ones looking into the {courtyard outer} -- {cubits fifty}; and these are the ones facing these others. The whole {cubits was a hundred}. 

#### Ezekiel 42:9 And the doors of these inner chambers of the entrance of the one towards the east is for one to enter through them from the {courtyard outer} 

#### Ezekiel 42:10 according to the light opening of the one at the beginning of the promenade; and towards the south, and the face of the south according to the face of the space left over, and according to the face of the space separating, and the inner chambers. 

#### Ezekiel 42:11 And the promenade in front of them, was according to the measures of the inner chambers of the ones towards the north; and according to the length of them, and according to the breadth of them, and according to all their exits, and according to their lights, and according to their doorways 

#### Ezekiel 42:12 of the inner chambers of the ones towards the south; according to the doorways at the beginning of the promenade upon a light interval of a reed according to the east of the entering them. 

#### Ezekiel 42:13 And he said to me, The inner chambers, the ones towards the north, and the inner chambers, the ones towards the south, being in front of the intervals, these are the inner chambers of the holy place, in which {eat there the priests approaching to the LORD}, the holy things of the holies; and there they shall put the holy things of the holies, and the sacrifice offering, and the things for a sin offering, and the things for an ignorance offering; because the place is holy. 

#### Ezekiel 42:14 There shall not enter there except the priests, and they shall not come forth from out of the holy place into the {courtyard outer}, so that {always holy might be the ones leading forward}; so that they should not touch their uniform in which they officiate in them, for it is holy, and they shall put on {garments other} whenever they should touch the people. 

#### Ezekiel 42:15 And {was completed the measurement of the house} from inside; and he led me out according to the way of the gate looking according to the east; and he measured the plan of the house round about in arrangement. 

#### Ezekiel 42:16 And he stood at the back of the gate looking according to the east, and he measured five hundred with the reed measure. 

#### Ezekiel 42:17 And he turned towards the north and measured in front of the north side {cubits five hundred} with the reed measure. 

#### Ezekiel 42:18 And he turned towards the west, and he measured in front of the west side, {cubits five hundred} with the reed measure. 

#### Ezekiel 42:19 And he turned towards the south, and he measured in front of the south, five hundred with the reed measure. 

#### Ezekiel 42:20 The four parts of it, and he set in order their enclosure round about -- five hundred towards the east, and five hundred cubits in breadth to separate between the holy places, and between the area around the wall in arrangement of the house. 

#### Ezekiel 43:1 And he led me unto the gate towards the east, and he led me out. 

#### Ezekiel 43:2 And behold, glory of the God of Israel came according to the way towards the east. And there was a voice of the camp as {voice the repeating} of many. And the ground shone forth as brightness in the glory round about. 

#### Ezekiel 43:3 And the vision which I beheld was according to the vision which I beheld when I entered to anoint the city; and the vision of the chariot which I beheld was according to the vision which I beheld upon the river Chebar, and I fell upon my face. 

#### Ezekiel 43:4 And the glory of the LORD entered into the house according to the way of the gate of the one looking according to the east. 

#### Ezekiel 43:5 And {took me up spirit}, and brought me into the {courtyard inner}; and behold, {was full of glory of the LORD the house}. 

#### Ezekiel 43:6 And I stood, and behold, there was a voice from the house speaking to me, and the man stood next to me, 

#### Ezekiel 43:7 and he said to me, You see, O son of man, the place of my throne, and the place of the track of my feet, in which {shall encamp my name} in the midst of the house of Israel into the eon. And {shall not profane any longer the house of Israel name my holy}, they and the ones leading them in their harlotry, and by the murders of the ones leading them in the midst of them; 

#### Ezekiel 43:8 in their putting my threshold among their thresholds, and my doorways next to their doorways. And they appointed my wall as holding me {together and them}. And they profaned {name my holy} by their lawless deeds which they did. And I obliterated them in my rage and by carnage. 

#### Ezekiel 43:9 And now, let {thrust away their harlotry and the murders the ones leading them from me}! and I will encamp in the midst of them into the eon. 

#### Ezekiel 43:10 And you, O son of man, show to the house of Israel the house, (and they shall abate from their sins) and the vision of it, and the disposition of it, 

#### Ezekiel 43:11 (and they shall take their punishment for all of which they did). And you shall diagram the house, and its preparation, and its exits, and its entrances, and its support. And all its orders, and all its laws, and all it rules you shall make known to them. And you shall diagram it before them, and they shall keep all my ordinances, and all my orders, and they shall do them. 

#### Ezekiel 43:12 And the diagram of the house upon the top of the mountain, all its limits round about the holy of holies -- this is the rule of the house. 

#### Ezekiel 43:13 And these are the measures of the altar by cubit of the cubit and a palm; the recess depth a cubit, and a cubit the breadth, and the molding upon the lip round about a span; and this is the height of the altar. 

#### Ezekiel 43:14 From the depth of the beginning of its hollow part to the atonement-seat, the one from beneath -- {cubits two}, and the breadth a cubit; and from the {atonement-seat small} to the {atonement-seat great} -- {cubits four}, and the breadth a cubit. 

#### Ezekiel 43:15 And the altar hearth -- {cubits four}; and from the altar hearth and up above the horns, a cubit. 

#### Ezekiel 43:16 And the altar hearth was {cubits twelve} in length by {cubits twelve}, four-cornered upon the four parts of it. 

#### Ezekiel 43:17 And the atonement-seat {cubits was fourteen} in length by {cubits fourteen} in breadth upon {four parts its}; and its molding encircling it round about -- a half cubit; and its encircling base was a cubit round about; and its steps looked according to the east. 

#### Ezekiel 43:18 And he said to me, O son of man, thus says the LORD God; These are the orders for the altar in the day of its being made to offer upon it whole burnt-offerings, and to pour on it blood. 

#### Ezekiel 43:19 And you shall give to the priests, to the Levites, to the ones from out of the seed of Zadok, to the ones approaching to me, says the LORD God, to officiate to me, a calf from the oxen for a sin offering. 

#### Ezekiel 43:20 And they shall take from its blood, and shall place it upon four horns of the altar, and upon the four corners of the atonement-seat, and upon the base round about; and they shall cleanse and atone it. 

#### Ezekiel 43:21 And they shall take the calf, the one for a sin offering, and they shall incinerate it in the place being separated of the house from outside of the holies. 

#### Ezekiel 43:22 And the {day second} you shall take a kid of the goats, unblemished for a sin offering; and they shall atone the altar in so far as they atoned with the calf. 

#### Ezekiel 43:23 And after completing the making an atonement, they shall bring {calf from out of the oxen an unblemished}, and {ram from out of the sheep an unblemished}. 

#### Ezekiel 43:24 And you shall offer them before the LORD, and {shall cast the priests upon them salt}, and they shall offer them as whole burnt-offerings to the LORD. 

#### Ezekiel 43:25 Seven days you shall offer a kid for a sin offering each day, and a calf from out of the oxen, and a ram from out of the sheep; {unblemished they shall offer them}. 

#### Ezekiel 43:26 Seven days and they shall atone the altar and cleanse it; and they shall fill their hands. 

#### Ezekiel 43:27 And they shall complete the days. And it will be from the {day eighth} and beyond, and {shall offer the priests} upon the altar your whole burnt-offerings, and the ones for your deliverance offering; and I will favorably receive you, says the LORD God. 

#### Ezekiel 44:1 And he returned me by the way of the {gate of the holies outer}, of the one looking according to the east; and this was locked. 

#### Ezekiel 44:2 And the LORD said to me, This gate having been locked will not be opened, and no one will go through it, for the LORD God of Israel will go through it, and it will be locked. 

#### Ezekiel 44:3 For the one leading, this one shall sit down in it to eat bread before the LORD. {by the way of the columned porch of the gate He shall enter}, and according to its way he shall go forth. 

#### Ezekiel 44:4 And he brought me according to the way of the gate, of the one towards the north over against the house. And I beheld, and behold, {was full of glory the house of the LORD}, and I fell upon my face. 

#### Ezekiel 44:5 And the LORD said to me, O son of man, arrange it upon your heart, and behold with your eyes, and {with your ears hear}! all as much as I {to you speak} concerning all the orders of the house of the LORD, and all its laws. And arrange your heart for the entrance of the house according to all its exits in all the holy places! 

#### Ezekiel 44:6 And you shall say to the one rebelling, to the house of Israel, Thus says the Lord the LORD; Let it be enough to you from all your lawless deeds, O house of Israel! 

#### Ezekiel 44:7 for you to bring in sons of foreigners, uncircumcised in heart, and uncircumcised in flesh, to be in my holy places, and to profane them in your offering my bread loaves, and fat, and blood; and you violated my covenant in all your lawless deeds. 

#### Ezekiel 44:8 And you kept not the orders of my sanctuary. But you ordered to keep guards in my holy places for yourselves. 

#### Ezekiel 44:9 On account of this, thus says the LORD God; All sons of foreigners, with an uncircumcised heart, and uncircumcised in flesh, shall not enter into my holy places, of all foreigners in the midst of the house of Israel. 

#### Ezekiel 44:10 Only the Levites who hoped upon me in {wandering Israel} from me after {ideas their own}, even they shall bear their iniquities; 

#### Ezekiel 44:11 yet they will be among my holy ones ministering as doorkeepers at the gates of the house, and ministering in the house. These shall slay the whole burnt-offerings and the sacrifices for the people; and these shall stand before the people to minister to them. 

#### Ezekiel 44:12 Because they ministered to them before the face of their idols, and it became to the house of Israel for a punishment of iniquity. Because of this I lifted my hand against them, says the Lord the LORD. 

#### Ezekiel 44:13 And they shall bear their lawlessness, and they shall not approach unto me to officiate as priest to me, nor to lead forward to all the holy things of the holies. And they shall bear their dishonor in the delusion in which they wandered. 

#### Ezekiel 44:14 And I will order them to keep the watches of the house for all its works, and for all as much as they should do. 

#### Ezekiel 44:15 The priests, the Levites, the sons of Zadok, the ones that kept watches of my holy things in the {wandering house of Israel} from me; these shall lead forward to me to minister to me; and they shall stand before my face to offer to me fat and blood, says the Lord the LORD. 

#### Ezekiel 44:16 These shall enter into my holy places, and these shall come forward to my table to minister to me, and to guard my watches. 

#### Ezekiel 44:17 And they shall be in their entering into the gates of the {courtyard inner} {apparels flaxen linen that they shall put on}, and they shall not put on wool in their ministering from the {gate inner} of the courtyard. 

#### Ezekiel 44:18 And {turbans flaxen linen they shall have} upon their heads, and {pants flaxen linen shall have} upon their loins, and they shall not gird with force. 

#### Ezekiel 44:19 And in their going forth into the {courtyard outer} to the people, they shall take off their apparels in which they ministered in them. And they shall put them in the inner chambers of the holies, and shall put on {apparels other}; and in no way shall they sanctify the people in their own apparels. 

#### Ezekiel 44:20 And their heads they shall not shave, and their hair they shall not make bare; by covering they shall cover their heads. 

#### Ezekiel 44:21 And {wine in no way shall drink any priest} in their entering into the {courtyard inner}. 

#### Ezekiel 44:22 And {a widow and one being cast out they shall not take} for themselves for a wife, but only a virgin from out of the seed of the house of Israel; but if there shall be a widow of a priest they shall take her. 

#### Ezekiel 44:23 And {my people they shall teach} between the holy and the profane; and {between unclean and clean they shall make known to them}. 

#### Ezekiel 44:24 And {over a judgment of blood these shall attend} to litigate my ordinances; they shall do justice, and {my judgments they shall judge}; and {my laws and my orders in all my holiday feasts they shall keep}; and {my Sabbaths they shall sanctify}. 

#### Ezekiel 44:25 And unto a dead soul of a man they shall not enter to defile themselves; but only unto a father, and unto a mother, and unto a son, and unto a daughter, and unto a brother, and unto his sister who has not become a man's wife shall he be defiled. 

#### Ezekiel 44:26 And after his being cleansed, {seven days he shall count out to himself}. 

#### Ezekiel 44:27 And whichever day they should enter into the {courtyard inner} to minister in the holy place, he shall bring an atonement, says the LORD God. 

#### Ezekiel 44:28 And it will be to them for an inheritance -- I am an inheritance to them; and a possession shall not be given to them among the sons of Israel -- I am their possession. 

#### Ezekiel 44:29 And the sacrifices, even the ones for a sin offering, and the ones for an ignorance offering, these they shall eat; and every separation offering in Israel will be theirs. 

#### Ezekiel 44:30 And the first-fruits of all, and the first-born of all, and {the cut-away portions all} from out of all your first-fruits {for the priests shall be}; and your first produce you shall give to the priest, to put a blessing upon your houses. 

#### Ezekiel 44:31 And all decaying flesh, and that taken by wild beasts from the birds and from the cattle {shall not eat the priests}. 

#### Ezekiel 45:1 And in your measuring the land for inheritance, you shall separate the first-fruit to the LORD, a holy space of the land -- five and twenty thousand in length, and the breadth ten thousand; it will be holy in all its limits round about. 

#### Ezekiel 45:2 And there shall be from out of this a sanctuary -- five hundred by five hundred four-cornered round about, and fifty cubits shall be their space round about. 

#### Ezekiel 45:3 And from out of this measurement you shall measure a length five and twenty thousand, and the breadth ten thousand; and in it will be the sanctuary, the holy of the holies. 

#### Ezekiel 45:4 Being sanctified of the land there shall be a portion to the priests, to the ones ministering in the holy place, and it will be for the ones approaching to minister to the LORD. And it will be to them a place for houses being separated for their sanctification. 

#### Ezekiel 45:5 Twenty and five thousand in length, and a breadth of twenty thousand shall be to the Levites, to the ones ministering in the house, to them for possession cities to dwell in. 

#### Ezekiel 45:6 And for the possession of the city you shall appoint five thousand for the breadth, and the length five and twenty thousand. In which manner the first-fruit of the holies is to all the house of Israel, so it shall be. 

#### Ezekiel 45:7 And a portion shall be to the one leading from out of this, and from this into the first-fruits of the holies for a possession of the city in front of the first-fruits of the holies, and in front of the possession of the city, the parts towards the west, and from the parts towards the west towards the east. And the length as one of the portions from the limits of the parts towards the west, unto the limits, the parts towards the east of the land. 

#### Ezekiel 45:8 And it will be to him for a possession in Israel. And {shall not tyrannize any longer the ones guiding my people}; but {the land shall inherit the house of Israel} according to their tribes. 

#### Ezekiel 45:9 Thus says the LORD God; Let it be enough to you, O ones guiding Israel! {injustice and misery Let} be removed, and {equity and righteousness observe}! Lift away the tyrannies from my people, says the LORD God! 

#### Ezekiel 45:10 {yoke balance scale a just and measure a just and choenix measure a just There shall be to you} for your measure. 

#### Ezekiel 45:11 And the choenix in like manner will be one to receive the tenth of the homer, a choenix and a tenth of the homer -- the ephah {the homer shall be equal to}. 

#### Ezekiel 45:12 And the weight twenty oboli five shekels; twenty five shekels, and five and ten shekels {for the mina let it be to you}. 

#### Ezekiel 45:13 And this is the first-fruit which you shall separate; the sixth part of the measure of the homer of the wheat, and the sixth part of the ephah of the cor of the barley. 

#### Ezekiel 45:14 And the order concerning the olive oil -- a cup of olive oil out of ten cups, for the ten cups are a homer. 

#### Ezekiel 45:15 And a sheep from the two hundred sheep as a cut-away portion of all the families of Israel for a sacrifice, and whole burnt-offerings, and for a sacrifice of deliverance offering to atone for you, says the LORD God. 

#### Ezekiel 45:16 And all the people shall give this first-fruit to the one guiding Israel. 

#### Ezekiel 45:17 And {through the one guiding will be the whole burnt offerings}, and the sacrifices, and the libation-offerings in the holidays, and in the new moons, and in the Sabbaths, and in all the holidays of the house of Israel -- he shall offer the sacrifices for sin, and the sacrifice offering, and the whole burnt-offerings, and the offerings of deliverance to atone for the house of Israel. 

#### Ezekiel 45:18 Thus says the LORD God; In the first month, day one of the month, you shall take a calf from out of the oxen, unblemished, to atone the holy place. 

#### Ezekiel 45:19 And {shall take the priest} of the blood, and he shall put it upon the doorposts of the house, and upon the four corners of the temple, and upon the altar, and upon the doorposts of the gate of the {courtyard inner}. 

#### Ezekiel 45:20 And so shall you do in the {month seventh}, day one of the month, for each senseless and simple one; and you shall atone for the house. 

#### Ezekiel 45:21 And in the first month, the fourteenth of the month; it will be to you the passover holiday -- seven days {unleavened breads you shall eat}. 

#### Ezekiel 45:22 And {shall offer the one guiding} in that day for himself, and for all the people of the land, a calf for a sin offering. 

#### Ezekiel 45:23 And seven days of the holiday he shall offer whole burnt-offerings to the LORD -- seven calves, and seven rams, unblemished, daily seven days. And for a sin offering a kid of the goats daily; and a sacrifice offering. 

#### Ezekiel 45:24 And {a cake for the calf and a cake for the ram he shall prepare}; and {of olive oil a hin} for the cake. 

#### Ezekiel 45:25 And in the seventh month, the fifteenth of the month, during the holiday, he shall offer according to the same, seven days, and as the sacrifices for the sin offering, and as the whole burnt-offerings, and as the gift offering, and as the olive oil. 

#### Ezekiel 46:1 Thus says the LORD God; The gate in the {courtyard inner}, the one looking towards the east will be locked six days of the operative times; but on the day of the Sabbaths it will be open, and on the day of the new moons it will be open. 

#### Ezekiel 46:2 And {shall enter the one guiding} according to the way of the columned porch of the gate outward, and shall stand at the thresholds of the gate; and {shall offer the priests} the things of his whole burnt-offerings and the things of his deliverance offering; and he shall do obeisance upon the threshold of the gate, and he shall come forth; and the gate in no way shall be locked until evening. 

#### Ezekiel 46:3 And {shall do obeisance the people of the land} at the thresholds of that gate during the Sabbaths and during the new moons before the LORD. 

#### Ezekiel 46:4 And {the whole burnt-offerings shall offer the one guiding} to the LORD on the day of the Sabbaths -- six {lambs unblemished} and {ram an unblemished}; 

#### Ezekiel 46:5 and a gift cake offering for the ram, and for the lambs a sacrifice gift offering of his hand, and {of olive oil a hin} for the cake offering. 

#### Ezekiel 46:6 And in the day of the new moons, {calf an unblemished}, and six lambs, and a ram -- they shall be unblemished; 

#### Ezekiel 46:7 and a cake offering for the ram, and a cake offering for the calf will be for a gift offering, and for the lambs, as whatever {should furnish his hand}, and {of olive oil a hin} for the cake. 

#### Ezekiel 46:8 And in the entering, the one guiding {by the way of the columned porch of the gate shall enter}, and by its way he shall come forth. 

#### Ezekiel 46:9 And whenever {should enter the people of the land} before the LORD during the holidays, the one entering by the way of the gate towards the north, to do obeisance, shall go forth by the way of the gate towards the south; and the one entering by the way of the gate towards the south shall go forth by the way of the gate towards the north. He shall not return by the gate by which he entered, but straightway from it he shall he go forth. 

#### Ezekiel 46:10 And the one guiding in the midst of them in their entering shall enter, and in their going forth, he shall come forth. 

#### Ezekiel 46:11 And in the holidays and in the festivals there shall be the gift cake offering for the calf, and a cake offering for the ram, and for the lambs -- as {should furnish his hand}, and of olive oil -- a hin to the cake. 

#### Ezekiel 46:12 And if {should offer the one guiding} an acknowledgment offering of a whole burnt-offering of deliverance to the LORD, then one should open to him the gate, the one looking according to the east, and he should offer his whole burnt-offering, and the things for his deliverance offering, in which manner he did on the day of the Sabbaths. And he shall come forth and lock the doors after his going forth. 

#### Ezekiel 46:13 And {lamb of a year old an unblemished he shall offer} for a whole burnt-offering to the LORD daily; morning by morning he shall prepare it. 

#### Ezekiel 46:14 And {a gift offering he shall prepare} for it, morning by morning, the sixth of a measure, and olive oil the third of a hin to intermingle with the fine flour as a gift offering to the LORD, {order a continual}. 

#### Ezekiel 46:15 You shall prepare the lamb, and the gift offering, and the olive oil; you shall offer morning by morning a whole burnt-offering continually. 

#### Ezekiel 46:16 Thus says the LORD God; If {shall give the one guiding} a gift to one of his sons out of his inheritance, this {to his sons shall be} a possession by inheritance. 

#### Ezekiel 46:17 And if he should give a gift to one of his servants, then it will be his until the year of the release; and then he shall give back to the one guiding; except the inheritance of his sons, to them it will be for a possession. 

#### Ezekiel 46:18 And in no way shall {take the one guiding} from the inheritance of the people to tyrannize over them. From out of his own possession he shall give to inherit to his sons, so that {should not be dispersed people my} each from out of his possession. 

#### Ezekiel 46:19 And he brought me into the way of the one according to the back of the gate, into the inner chamber of the holy places of the priests, the one looking towards the north. And behold, there was a place there having been separated. 

#### Ezekiel 46:20 And he said to me, This place is of which {boil there the priests} the sacrifices for an ignorance offering, and the sacrifices for a sin offering; and there they bake the gift offering thoroughly so as to not bring them forth into the {courtyard outer}, to sanctify the people. 

#### Ezekiel 46:21 And he led me into the {courtyard outer}; and led me around upon the four parts of the courtyard. And behold, there was a courtyard according to each of the sides of the courtyard. 

#### Ezekiel 46:22 Upon the four sides of the courtyard {courtyards were small}, {in length cubits forty}, and a breadth {cubits of thirty} -- {measure one} to the four. 

#### Ezekiel 46:23 And there were inner chambers round about them to the four; and cooking places existed from beneath the inner chambers round about. 

#### Ezekiel 46:24 And he said to me, These are the houses of the cooks of which {shall boil there the ones ministering to the house} the things which are offered in sacrifice by the people. 

#### Ezekiel 47:1 And he brought me unto the thresholds of the house; and behold, water went forth from beneath the open space of the house according to the east, for the front of the house looked according to the east. And the water went down from the south of the house of the right upon the south of the altar. 

#### Ezekiel 47:2 And he led me according to the way of the gate, of the one towards the north; and he led me by the way outside to the gate of the courtyard, of the one looking according to the east; and behold, the water carried down from the {side right}. 

#### Ezekiel 47:3 And there was {exiting a man} right opposite there; and a measure was in his hand; and he measured a thousand. 

#### Ezekiel 47:4 And he went through in the water, the water of release, and he measured a thousand, and he went through the water unto the knees. And he measured a thousand, and he went through the water unto his loin. 

#### Ezekiel 47:5 And he measured a thousand, and he was not able to go through any more, for {overflowed the water} as the impetus of a rushing stream of which shall not be passed over. 

#### Ezekiel 47:6 And he said to me, Do you see, O son of man? And he led me, and returned me unto the edge of the river. 

#### Ezekiel 47:7 In my turning, and behold, upon the edge of the river were {trees many exceedingly} on this side and that side. 

#### Ezekiel 47:8 And he said to me, This water going forth unto Galilee, the one towards the east, and goes down unto Arabia, and comes as far as unto the sea, unto the water of the outlet, and it shall heal the waters. 

#### Ezekiel 47:9 And it will be every life of the living creatures of the ones swarming upon all upon which ever {should come there the river} shall live. And there will be there {fishes many exceedingly}; for {is come there water this}, and it shall heal and shall enliven. Everything upon which ever {should come the river} there shall live. 

#### Ezekiel 47:10 And {shall stand there fishermen} from En-gedi unto En-eglaim. {a refreshing of dragnets It will be for}. {by itself It will be}, and its fishes will be as the fishes of the {sea great}, {multitude great an exceedingly}. 

#### Ezekiel 47:11 And in its outlet, and in its turning, and in its overflowing, in no way shall they heal, {for salt they have been given}. 

#### Ezekiel 47:12 And by the river shall ascend by its edge on this side and that side every {tree eatable}; in no way shall anything be old upon it, nor shall {fail its fruit} of the newness of it -- it shall put forth first; for their waters are of the holy place. These waters go forth, and {will be their fruit} for food, and their ascending parts for health. 

#### Ezekiel 47:13 Thus says the LORD God; These are the borders you shall inherit of the land for the twelve tribes of the sons of Israel, an addition of a piece of measured land. 

#### Ezekiel 47:14 And you shall inherit it, each as his brother in which I lifted my hand to give to their fathers; and {shall fall land this} to you by inheritance. 

#### Ezekiel 47:15 And these are the borders of the land of the one towards the north, from the {sea great}, the way Hethlon of the entrance of Zedad; 

#### Ezekiel 47:16 Hamath, Berothah, Sibraim, the places between the limits of Damascus and between the limits of Hamath, the courtyards of Hatticon, which are upon the limits of Hauran. 

#### Ezekiel 47:17 These are the borders from the sea, from the courtyard of Enan, the limits of Damascus, and the places towards the north, and the limits of Hamath the places towards the north. 

#### Ezekiel 47:18 And the places towards the east between Hauran, and between Damascus, and between Gilead, and between the land of Israel, the Jordan separates unto the sea the one towards the east of Palm-grove; these are the borders towards the east. 

#### Ezekiel 47:19 And these are the borders towards the south and southwest from Teman, and Palm-grove unto the water of Mariboth Kadesh, reaching forth unto the {sea great} -- this part is the south and southwest. 

#### Ezekiel 47:20 This part of the {sea great} defines the bounds unto before the entrance of Hamath, unto its entrance. These are the borders towards the west. 

#### Ezekiel 47:21 And you shall divide this land to them, to the tribes of Israel. 

#### Ezekiel 47:22 You shall cast it by lot to yourself, and to the foreigners sojourning in your midst, whomever engendered sons in your midst. And they will be yours as native-born among the sons of Israel; with you they shall eat by inheritance in the midst of the tribes of Israel. 

#### Ezekiel 47:23 And they will be in the tribe of converts among the converts, the ones with them. There you shall give an inheritance to them, says the LORD God. 

#### Ezekiel 48:1 And these are the names of the tribes from the top towards the north, according to the part of the descent of the splitting unto the entrance of Hamath, the courtyard of Enan, the border of Damascus to the north according to the part of Hamath's courtyard; and {will be theirs the parts towards the east} unto towards the west -- for Dan, one portion. 

#### Ezekiel 48:2 And from the borders of the one of Dan, the ones towards the east, unto the borders towards the west -- Asher, one portion. 

#### Ezekiel 48:3 And from the borders of Asher, from the borders towards the east, unto the borders towards the west -- Naphtali, one portion. 

#### Ezekiel 48:4 And from the borders of Naphtali, from the borders of the east, unto the borders towards the west -- Manasseh, one portion. 

#### Ezekiel 48:5 And from the borders of Manasseh, from the borders towards the east, unto the borders towards the west -- Ephraim, one portion. 

#### Ezekiel 48:6 And from the borders of Ephraim, from the borders towards the east, unto the borders towards the west -- Reuben, one portion. 

#### Ezekiel 48:7 And from the borders of Reuben, from the borders towards the east, unto the borders towards the west -- Judah, one portion. 

#### Ezekiel 48:8 And from the borders of Judah, from the borders towards the east, shall be the first-fruit of the offering, five and twenty thousand in breadth, and the length as one of the portions measured from the borders towards the east and unto the borders towards the west; and {will be the holy place} in the middle of them. 

#### Ezekiel 48:9 As for the first-fruit which they shall separate to the LORD, it shall be in length five and twenty thousand, and in breadth ten thousand. 

#### Ezekiel 48:10 Of these will be the first-fruit of the holy things for the priests towards the north, five and twenty thousand, and towards the west, ten thousand, and towards the east, ten thousand; and towards the south, twenty and five thousand; and the mountain of the holy places will be in the middle of it. 

#### Ezekiel 48:11 It shall be for the priests, the ones having been sanctified, the sons of Zadok, the ones keeping the watches of the house, who did not wander in the delusion of the sons of Israel, in which manner {wandered the Levites}. 

#### Ezekiel 48:12 And {shall be to them the first-fruit} having been given from out of the first-fruits of the land, a holy of holies from the borders of the Levites. 

#### Ezekiel 48:13 And to the Levites, shall be the parts next to the borders of the priests -- in length, five and twenty thousand, and in breadth, ten thousand; the whole length shall be five and twenty thousand, and the breadth ten thousand. 

#### Ezekiel 48:14 No part {shall be sold of it}, nor measured out for sale, nor shall there be removed any of the first produce of the land, for it is holy to the LORD. 

#### Ezekiel 48:15 But concerning the five thousand extra in the width upon the five and twenty thousand, {an area around the wall it will be} to the city for the dwelling in, and for its space. And {will be the city} in the midst of it. 

#### Ezekiel 48:16 And these are its measurements from the borders towards the north, five hundred and four thousand, and from the borders towards the south, five hundred and four thousand, and from the borders towards the east, five hundred and four thousand, and from the borders towards the west, four thousand five hundred. 

#### Ezekiel 48:17 And there shall be a space to the city towards the north, two hundred and fifty, and towards the south, two hundred and fifty, and towards the east, two hundred and fifty, and towards the west two hundred and fifty. 

#### Ezekiel 48:18 And the extra of the length next to the first-fruits of the holy places will be ten thousand towards the east, and ten thousand towards the west; and they will be the first-fruits of the holy place; and {will be its produce} for bread loaves to the ones working for the city. 

#### Ezekiel 48:19 And the ones working the city shall work it from out of all the tribes of Israel. 

#### Ezekiel 48:20 The whole first-fruit shall be five and twenty thousand by five and twenty thousand, four-cornered; you shall separate it as the first-fruit of the holy place, from the possession of the city. 

#### Ezekiel 48:21 And the extra to the one guiding on this side and on that side, from the first-fruits of the holy place; and for the possession of the city, there shall be a space unto five and twenty thousand in length, unto the borders of the ones towards the east, and towards the west, unto five and twenty thousand unto the borders towards the west, next to the portions of the one guiding; and {will be the first-fruit of the holy places and the sanctuary of the house} in the midst of it. 

#### Ezekiel 48:22 And by the borders of the Levites from the possession of the city in the midst of the one guiding it will be; between the borders of Judah and between the borders of Benjamin, and to the one guiding it will be. 

#### Ezekiel 48:23 And the extra of the tribes, from the borders towards the east, unto the borders towards the west -- Benjamin, one portion. 

#### Ezekiel 48:24 And from the borders of the ones of Benjamin, from the borders towards the east, unto the borders towards the west -- Simeon, one portion. 

#### Ezekiel 48:25 And from the borders of the ones of Simeon, from the borders towards the east, unto the borders towards the west -- Issachar, one portion. 

#### Ezekiel 48:26 And from the borders of the ones of Issachar, from the borders towards the east, unto the borders towards the west -- Zebulun, one portion. 

#### Ezekiel 48:27 And from the borders of the ones of Zebulun, from the borders towards the east, unto the borders towards the west -- Gad, one portion. 

#### Ezekiel 48:28 And from the borders of the ones of Gad, from the borders towards the southwest; and {will be his borders} from Teman and the water of Mariboth Kadesh, an inheritance unto the {sea great}. 

#### Ezekiel 48:29 This is the land which you shall throw by lot to the tribes of Israel, and these are their divisions, says the LORD God. 

#### Ezekiel 48:30 And these are the outlets of the city, the ones towards the north -- four thousand and five hundred in measure. 

#### Ezekiel 48:31 And the gates of the city by the names of the tribes of Israel. {gates Three} towards the north; the gate of Reuben -- one, and the gate of Judah -- one, and the gate of Levi -- one. 

#### Ezekiel 48:32 And the ones towards the east, four thousand and five hundred; and {gates three}; the gate of Joseph -- one, and the gate of Benjamin -- one, and the gate of Dan -- one. 

#### Ezekiel 48:33 And the ones towards the south, four thousand and five hundred in measure, and {gates three}; the gate of Simeon -- one, and the gate of Issachar -- one, and the gate of Zebulun -- one. 

#### Ezekiel 48:34 And the ones towards the west, four thousand and five hundred in measure, {gates three}; the gate of Gad -- one, and the gate of Asher -- one, and gate of Naphtali -- one. 

#### Ezekiel 48:35 The circumference, ten and eight thousand. And the name of the city from which ever day it takes place, shall be its name.