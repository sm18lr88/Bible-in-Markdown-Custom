#### Jeremiah 1:1 The saying of God which came unto Jeremiah the son of Hilkiah, of the priests who dwelt in Anathoth in the land of Benjamin. 

#### Jeremiah 1:2 As {came the word of God} to him in the days of Josiah son of Amon king of Judah, {year thirteenth in the} of his kingship. 

#### Jeremiah 1:3 And it took place in the days of Jehoiakim son of Josiah, king of Judah, until the eleventh year of Zedekiah son of Josiah king of Judah, until the captivity of Jerusalem in the fifth month. 

#### Jeremiah 1:4 And {came the word of the LORD} to me, saying, 

#### Jeremiah 1:5 Before my shaping you in the belly I knew you; and before your coming forth from out of the womb I sanctified you; {prophet unto nations I appointed you}. 

#### Jeremiah 1:6 And I said, O Being One, Master, O LORD, behold, I do not know how to speak, for {younger I am}. 

#### Jeremiah 1:7 And the LORD said to me, Do not say that! {younger I am}. For to all whom ever I should send you, you shall go; and according to all as much as I should give charge to you, you shall speak. 

#### Jeremiah 1:8 You should not be fearful from in front of them, for {with you I am}, to rescue you, says the LORD. 

#### Jeremiah 1:9 And the LORD stretched his hand to me, and touched my mouth. And the LORD said to me, Behold, I have placed my words in your mouth. 

#### Jeremiah 1:10 Behold, I have ordained you today over nations, and over kingdoms, to root out, and to raze, and to loosen, and to rebuild, and to plant. 

#### Jeremiah 1:11 And came to pass the word of the LORD to me, saying, What do you see, Jeremiah? And I said, {staff A walnut}. 

#### Jeremiah 1:12 And the LORD said to me, {well You have seen}; for I am vigilant over my words to do them. 

#### Jeremiah 1:13 And {came to pass the word of the LORD} of a second time to me, saying, What do you see? and I said, A kettle being fired up, and the face of it towards the face of the north. 

#### Jeremiah 1:14 And the LORD said to me, From the face of the north shall burn away the evils upon all the ones dwelling in the land. 

#### Jeremiah 1:15 For behold, I call together all the kingdoms of the north, says the LORD; and they shall come, and {shall put each} his throne upon the thresholds of the gates of Jerusalem, and upon all the walls round about, and upon all the cities of Judah. 

#### Jeremiah 1:16 And I shall speak to them with judgment concerning all their evil, as they abandoned me, and they sacrificed to strange gods, and did obeisance to the works of their hands. 

#### Jeremiah 1:17 And you, gird your loin and rise up, and speak to them all as much as I should give charge to you! You should not be fearful from in front of them, nor should you be terrified before them, for {with you I am} to rescue you, says the LORD. 

#### Jeremiah 1:18 Behold, I have made you in today's day as {city a fortified}, and as {wall of brass a fortified} all together against the kings of Judah, and its rulers, and to the people of the land. 

#### Jeremiah 1:19 And they shall wage war against you; but in no way shall they be able to prevail against you, because {with you I am} to rescue you, said the LORD. 

#### Jeremiah 2:1 And came to pass the word of the LORD to me, saying, 

#### Jeremiah 2:2 Go, and yell into the ears of Jerusalem! saying, Thus says the LORD, I remembered the mercy of your youth, and the love of your consecration, for you to follow after the holy one of Israel, says the LORD; 

#### Jeremiah 2:3 Holy Israel to the LORD, the beginning of his offspring. All the ones devouring him shall offend; evils shall come upon them, says the LORD. 

#### Jeremiah 2:4 Hear the word of the LORD, O house of Jacob, and every family of the house of Israel! 

#### Jeremiah 2:5 Thus says the LORD, What {find fathers did your in me trespass} that they left far from me, and went after the vain things, and acted in folly? 

#### Jeremiah 2:6 And they said not, Where is the LORD, the one directing us from out of the land of Egypt, the one steering us in the wilderness, in {land a vast and untrodden}, in a land waterless and unfruitful, in a land in which no {traveled through in it man}, and no {dwelt man} there? 

#### Jeremiah 2:7 And I led you unto Carmel, to eat the fruits of it, and the good things of it. And you entered, and defiled my land; and my inheritance you made into an abomination. 

#### Jeremiah 2:8 The priests said not, Where is the LORD? And the ones resisting the law have not made acknowledgment to me; and the shepherds were impious to me; and the prophets prophesied by Baal, and {after unprofitable things they went}. 

#### Jeremiah 2:9 On account of this, still I will arbitrate for you, says the LORD; and for the sons of your sons I will arbitrate. 

#### Jeremiah 2:10 For go into the islands of the Chittim, and see! And {unto Kedar send}, and comprehend exceedingly! And see! if {have taken place such things} 

#### Jeremiah 2:11 if {changed nations} their gods, and these are not gods! But my people changed their glory by which they do not derive benefit. 

#### Jeremiah 2:12 {is amazed The heaven} by this, and shuddered over it much, exceedingly, says the LORD. 

#### Jeremiah 2:13 For two and wicked things {did my people} to me; they abandoned the spring of water of life, and they dug for themselves cisterns having been broken, the ones which are not able {water to hold}. 

#### Jeremiah 2:14 {a servant Is Israel} or {native-born is he}? Why did {for plunder he become}? 

#### Jeremiah 2:15 Upon him {roar the lions}, and {gave out their voice the ones who ordered his land for extinction}. And his cities they razed so as for no one to dwell. 

#### Jeremiah 2:16 And the sons of Memphis and Tahapanhes knew you, and were mocking you. 

#### Jeremiah 2:17 Were not these things done to you for your forsaking me, says the LORD your God? 

#### Jeremiah 2:18 And now, what is it to you and the way of Egypt, to drink the water of Sihor? And what is it to you in the way of the Assyrians, to drink water of the rivers? 

#### Jeremiah 2:19 {shall correct you Your defection}, and your evil shall reprove you. And know and see that {is bitter to you your forsaking me}! says the LORD your God. And I thought not well in you, says the LORD your God. 

#### Jeremiah 2:20 For from the eon you broke your yoke, and tore up your bonds. And you said, I will not serve, but I will go upon every {hill high}, and underneath every {tree shady}; there I will disperse in my harlotry. 

#### Jeremiah 2:21 But I planted you a grapevine bearing fruit -- all true. How are you turned into bitterness -- {grapevine a strange}? 

#### Jeremiah 2:22 If you should wash in bleach, and should multiply {to yourself soap}, still you are spotted in your iniquities before me, says the LORD. 

#### Jeremiah 2:23 How will you say, I was not defiled, and {after Baal I went not}? Behold your ways in the cemetery, and know what you did! {in the evening Her voice shrieks}. 

#### Jeremiah 2:24 Her ways widen over waters of the wilderness; in the desires of her soul she was being carried by the wind; she was delivered up to them, who will turn her? All the ones seeking her shall not tire; in her humiliation they shall find her. 

#### Jeremiah 2:25 Turn your foot from {way the rough}, and your throat from thirst! But she said, I will be manly. For I loved strangers, and {after them went}. 

#### Jeremiah 2:26 As shame of a thief whenever he should be captured, so shall {be ashamed the sons of Israel}; they, and their kings, and their rulers, and their priests, and their prophets. 

#### Jeremiah 2:27 {to the tree They said} that, {father my are You}; and to the stone, You engendered me. And they turned {against me their backs}, and not their faces. And in the time of their evils they shall say, Rise up and deliver us! 

#### Jeremiah 2:28 And where are your gods which you made for yourself? Shall they rise up and deliver you in the time of your ill-treatment, no. For according to the number of your cities were your gods, O Judah; and according to the number of the corridors of Jerusalem, they sacrificed to Baal. 

#### Jeremiah 2:29 Why do you speak to me? You all acted impious, and you all acted lawlessly against me, says the LORD. 

#### Jeremiah 2:30 In vain I struck your children. {correction They received not}. A sword devoured your prophets, as a lion annihilating. And you feared not. 

#### Jeremiah 2:31 Hear the word of the LORD! Thus says the LORD, Did {a wilderness I become} to Israel, or a land being made barren? Why said my people, We will not be lorded over, and we shall not come to you any longer? 

#### Jeremiah 2:32 Will {forget the bride} her bridal ornament, and the virgin her breastband? But my people forgot me for days which there is no number. 

#### Jeremiah 2:33 What {yet good device will you} apply in your ways to seek affection? It will not be thus. But even you did wicked to defile your ways. 

#### Jeremiah 2:34 And in your hands was found blood {souls of innocent}. {not in ditches I found them}, but upon every oak. 

#### Jeremiah 2:35 And you said, I am innocent, but turn his rage from me! Behold, I judge against you, in your saying, I sinned not. 

#### Jeremiah 2:36 For you are disdained very much of the repeating a second time of your ways. And from Egypt you shall be disgraced, as you were disgraced by Assyria. 

#### Jeremiah 2:37 For even from here you shall go forth, and your hands will be upon your head. For the LORD thrusted away your hope, and you shall not be prosperous in it. 

#### Jeremiah 3:1 If {should send away a husband} his wife, and she should go forth from him, and becomes {man to another}, shall by returning she return to him yet again? Shall not by defiling {be defiled that woman}? But you fornicated with {shepherds many}, and you have returned to me, says the LORD. 

#### Jeremiah 3:2 Lift your eyes unto the upright way, and see where you have not been defiled! {upon the ways You have sat} for them as a crowbar having been made desolate, and defiled the land in your harlotries, and in your evils. 

#### Jeremiah 3:3 And you had {shepherds many} for your occasion for stumbling; the appearance of a harlot became to you; you cast shame to all. 

#### Jeremiah 3:4 Was it not until now you called me even, Father? and, Head of your virginity? 

#### Jeremiah 3:5 Shall it abide into the eon, or shall it be guarded for victory? Behold, you spoke and did these evils, and have prevailed. 

#### Jeremiah 3:6 And the LORD said to me in the days of Josiah the king, You saw what {did to me the house of Israel}. She went upon every {mountain high}, and underneath every tree of the woods, and she committed harlotry there. 

#### Jeremiah 3:7 And I said after her committing harlotry all these things, {to me Turn}! And she turned not. And {saw her breach-of-contract the covenant-breaker Judah}. 

#### Jeremiah 3:8 And I beheld (for on account of all of which she was overtaken by them {committed adultery the house of Israel}, and I sent her out and gave to her a scroll certificate of divorce into her hands) that {feared not the covenant-breaker Judah}, and went and committed harlotry even herself. 

#### Jeremiah 3:9 And {was nothing to her her harlotry}; and she committed adultery with the wood and the stone. 

#### Jeremiah 3:10 And in all these things {turned not to me the covenant-breaker Judah} with {whole heart her}, but with a lie. 

#### Jeremiah 3:11 And the LORD said to me, {justified her soul Israel} above the covenant-breaker Judah. 

#### Jeremiah 3:12 Go and read these words towards the north! And you shall say, Return to me, O house of Israel, says the LORD! And in no way shall I firmly fix my face against you. For {merciful I am}, says the LORD, and I shall not be infuriated with you into the eon. 

#### Jeremiah 3:13 Only know your iniquity! For it is against the LORD your God you acted impious, and dispersed your ways unto strangers underneath every tree of the woods; but my voice you obeyed not, says the LORD. 

#### Jeremiah 3:14 Return, {sons O revolting}, says the LORD! For I shall lord over you. And I shall take you, one from out of a city, and two from out of a family, and I will bring you into Zion. 

#### Jeremiah 3:15 And I will appoint to you shepherds according to my heart, and they shall tend you, tending with higher knowledge. 

#### Jeremiah 3:16 And it will be if you should be multiplied, and should grow upon the land, says the LORD, in those days, they shall not say any more, Ark of the covenant of holy Israel. It shall not ascend upon the heart, nor be named, nor shall it be examined, and it shall not be done any more. 

#### Jeremiah 3:17 In those days and in that time they shall call Jerusalem, The throne of the LORD; and shall be brought together unto her all the nations; and they shall not go any more after the {thoughts of their heart wicked}. 

#### Jeremiah 3:18 In those days {shall come together the house of Judah} with the house of Israel. And they shall come together from the land of the north, and from all the places upon the earth which I caused {to inherit their fathers}. 

#### Jeremiah 3:19 And I said, May it be, O LORD, for you said, I shall arrange you among children, and I shall give to you {land a choice} (the inheritance of God almighty) of nations. And I said, {father you shall call me}; and {from me you shall not be turned}. 

#### Jeremiah 3:20 Only as {annuls a wife} against the one being with her, so {annulled against me the house of Israel}, says the LORD. 

#### Jeremiah 3:21 A voice from the lips was heard of weeping and supplication of the sons of Israel. For they transgressed in their ways; they forgot God their holy one. 

#### Jeremiah 3:22 Turn! {sons O turning}, and I shall heal your brokenness. Behold, thus we shall be to you, for you {the LORD our God are}. 

#### Jeremiah 3:23 Really {for a lie were the hills and the powers of the mountains}. Only through the LORD our God is the deliverance of Israel. 

#### Jeremiah 3:24 But the shame consumed the efforts of our fathers from our youth; their sheep and their calves, their sons and their daughters. 

#### Jeremiah 3:25 We were gone to bed in our shame, and {covered us our dishonor}. For before our God {sinned we and our fathers} from our youth until this day, and we hearkened not of the voice of the LORD our God. 

#### Jeremiah 4:1 If Israel should return, says the LORD, to me, he shall be returned. And if he should remove his abominations from his mouth, and {from in front of me should show reverence}, 

#### Jeremiah 4:2 and should swear by an oath, The LORD lives, with truth, in equity and in righteousness; then they shall bless {by him nations}. And by him they shall give praise to God in Jerusalem. 

#### Jeremiah 4:3 For thus says the LORD to the men of Judah, and to the ones dwelling in Jerusalem, Plow to yourselves fields prepared for plowing! and you should not sow among thorn-bushes. 

#### Jeremiah 4:4 Circumcise yourselves to your God, and circumcise the hardness of your heart, O men of Judah, and O ones dwelling in Jerusalem! lest {should go forth as fire my rage}, and shall be kindled, and there will not be one extinguishing from in front of the wickednesses of your practices. 

#### Jeremiah 4:5 Announce in Judah, and hearken in Jerusalem! Say! Signify with a trumpet unto the land! Cry out great! Say! Be gathered together! and, We should enter into the {cities walled}. 

#### Jeremiah 4:6 In taking up your things, flee unto Zion! Hasten, do not stand! for {evils I bring} from the north, and {destruction great}. 

#### Jeremiah 4:7 {ascended The lion} from out of his lair, utterly destroying nations. He lifted away and came forth from out of his place, to make the earth for desolation; and your cities shall be demolished, so as to not dwell them. 

#### Jeremiah 4:8 Concerning these things gird yourselves with sackcloths, and lament, and shout! because {shall not be turned the rage of the anger of the LORD} from you. 

#### Jeremiah 4:9 And it will be in that day, says the LORD, {shall perish the heart of the king}, and the heart of the rulers; and the priests shall be amazed, and the prophets shall wonder. 

#### Jeremiah 4:10 And I said, O master, O LORD, Surely indeed in beguiling you beguiled this people, and Jerusalem, saying, Peace will be to you; whereas {shall touch the sword} unto their soul. 

#### Jeremiah 4:11 In that time they shall say to this people, and to Jerusalem, There is a spirit of addiction to a delusion in the wilderness; the way of the daughter of my people is not to purity, nor to holiness. 

#### Jeremiah 4:12 A spirit of fullness shall come to me; but now I shall speak my judgments against them. 

#### Jeremiah 4:13 Behold, as a cloud he shall ascend, and {as a blast his chariots}. Lighter than eagles are his horses. Woe to us, for we are in misery. 

#### Jeremiah 4:14 Wash {from evils your heart}, O Jerusalem! that you should be delivered. For how long shall {exist in you the devices of your miseries}? 

#### Jeremiah 4:15 Because a voice of one announcing from out of Dan shall come; and {shall be heard the misery from out of mount Ephraim}. 

#### Jeremiah 4:16 Remind nations! Behold, announce in Jerusalem! Confederacies are come from out of a land far off, and they uttered {against the cities of Judah their voices}. 

#### Jeremiah 4:17 As ones guarding a field they have come upon her round about; for you neglected me, says the LORD. 

#### Jeremiah 4:18 Your ways and your practices did these things to you; this is your evil, for it is bitter, for it touched unto your heart. 

#### Jeremiah 4:19 My belly, my belly aches, and the senses of my heart. {is irresistibly led My soul}. {is being thrown into a spasm My heart}. I shall not keep silent, for {the sound of a trumpet heard my soul}, a cry of war, 

#### Jeremiah 4:20 and of misery. Conflict is being called upon, for {is in misery all the land} suddenly. {languishes The tent}; {have been pulled apart my hide coverings}. 

#### Jeremiah 4:21 For how long shall I see ones fleeing, hearing the sound of a trumpet? 

#### Jeremiah 4:22 For the ones leading my people {me do not know}; {sons foolish they are}, and not discerning. They are wise to do evil, but the {good doing} they have not recognized. 

#### Jeremiah 4:23 I looked upon the earth, and behold -- nothing; and into the heaven, and {not were its lights}. 

#### Jeremiah 4:24 I beheld the mountains, and they was trembling, and all the hills were being disturbed. 

#### Jeremiah 4:25 I looked, and behold, {did not exist a man}, and all the birds of the heaven were terrified. 

#### Jeremiah 4:26 I beheld, and behold, Carmel was desolate, and all the cities being set on fire by fire from the countenance of the LORD; and from the countenance of the anger of his rage they were removed from view. 

#### Jeremiah 4:27 Thus says the LORD, {desolate will be All the earth}; {unto completion but in no way will I do it}. 

#### Jeremiah 4:28 Upon these things let {mourn the earth}, and let {be darkened the heaven above}! Because I have spoken, and I shall not change my mind. I advanced it, and I will not turn from it. 

#### Jeremiah 4:29 From the sound of a horseman, and tightly stretched bow, {withdrew every place}; they have entered into the caves, and {in the sacred groves they were hid}; and {upon the rocks they ascended}. Every city they abandoned; {does not dwell in them man}. 

#### Jeremiah 4:30 And you, what shall you do? If you should put on scarlet, and should be adorned with an ornament of gold; and if you should rub antimony on your eyes, {is in vain your finery}; {thrusted you away your lovers}, {life your they seek}. 

#### Jeremiah 4:31 For {a sound as women travailing I heard}; your moaning as one giving birth for the first time. The voice of the daughter of Zion shall faint, and {shall weaken her hands}; saying, Woe am I, for {fails my soul} over the ones being done away with. 

#### Jeremiah 5:1 Run about in the streets of Jerusalem, and see! And know, and seek in her squares! if there should be found a man; if there is one having equity, and seeking trust -- and I will be kind to them, says the LORD. 

#### Jeremiah 5:2 As the LORD lives, they say, On account of this do they not {with lies swear by an oath}? 

#### Jeremiah 5:3 O LORD, your eyes look unto trust. You whipped them, and they were not pained. You finished them off entirely, but they did not want to take correction. They solidified their faces above a rock, and they did not want to turn towards you. 

#### Jeremiah 5:4 And I said, perhaps they are poor, because they are not able. For they do not know the way of the LORD, and the equity of God. 

#### Jeremiah 5:5 I will go to the stout men and speak to them, for they recognized the way of the LORD, and the equity of God. And behold, with one accord they broke the yoke, they tore up the bonds. 

#### Jeremiah 5:6 On account of this {smote them a lion} from out of the forest; and the wolf {unto their houses annihilated them}; and a leopard acted vigilant over their cities. All the ones going forth from them shall be hunted; for they multiplied their impiety, they strengthened in their rejection. 

#### Jeremiah 5:7 What kind {for these things of kindness should happen to you}? Your sons abandoned me, and they swore by an oath by the ones not being gods. And I have filled them, and they committed adultery, and {in the houses of harlots rested up}. 

#### Jeremiah 5:8 {horses sex-crazed They became}; each {over the wife of his neighbor snorting}. 

#### Jeremiah 5:9 Shall {over these things not I visit}? says the LORD. or {a nation to such} shall not {take vengeance my soul}? 

#### Jeremiah 5:10 Ascend upon her battlements, and raze! {unto completion But you should not do it}. Destroy her supports! for {of the LORD they are not}. 

#### Jeremiah 5:11 For in disrespecting they disrespected against me, says the LORD, even the house of Israel, and the house of Judah. 

#### Jeremiah 5:12 They have lied to their LORD, and they said, {not so are These things}; there shall not come upon us bad things, and the sword and hunger we will not see. 

#### Jeremiah 5:13 Our prophets were into the wind, and the word of the LORD does not exist among them. Thus it shall be to them. 

#### Jeremiah 5:14 On account of this, thus says the LORD almighty, Because you spoke this word, behold, I have given my words into your mouth as fire, and this people as wood, and it shall devour them. 

#### Jeremiah 5:15 Behold, I bring upon you a nation at a distance, O house of Israel, says the LORD. {nation A strong}, a nation from the eon, a nation of which you shall not hear the voice of its language. 

#### Jeremiah 5:16 All strong men; his quiver is as a tomb being open. 

#### Jeremiah 5:17 And they shall devour your harvest, and your bread loaves. And they shall devour your sons, and your daughters. And they shall devour your sheep, and your calves. And they shall devour your vineyards, and your fig groves, and your olive groves. And they shall thresh {cities your fortified}, (upon which you rely upon them,) by the broadsword. 

#### Jeremiah 5:18 And it will be in those days, says the LORD your God, in no way will I appoint you unto completion. 

#### Jeremiah 5:19 And it will be whenever you should say, For what reason did {do the LORD our God} to us all these things? That you shall say to them, Because you abandoned me, and served strange gods in your land. Thus shall you serve strangers in a land not of yours. 

#### Jeremiah 5:20 Announce these things unto the house of Jacob, and let it be heard in of Judah! 

#### Jeremiah 5:21 Hearken indeed to these things, {people O moronish and heartless}! They have eyes, and they do not see; they have ears, and they do not hear. 

#### Jeremiah 5:22 Will {me you not fear}, says the LORD? or before my face will you not show veneration? the one ordering the sand for a limit to the sea {order as an eternal}, and the sea shall not pass over it; and it shall be disturbed but it will not be prevailing; and {shall resound its waves}, but shall not pass over it. 

#### Jeremiah 5:23 But to this people there became {heart an unhearing}, and a resistance of persuasion. They turned aside and departed. 

#### Jeremiah 5:24 And they have not said in their heart, We should indeed fear the LORD our God, the one giving to us {rain the early and late} according to its season of the fullness of the order of harvest, and he guarded it for us. 

#### Jeremiah 5:25 Your lawless deeds turned aside these things. And your sins removed the good things from you. 

#### Jeremiah 5:26 For {were found among my people impious men}. And {a snare they set} to corrupt men; and they conceive their plan. 

#### Jeremiah 5:27 As a snare having been set is full of birds, so their houses are full of treachery. On account of this they were magnified, and enriched. 

#### Jeremiah 5:28 They became fat and violated equity. They judged not the case of the orphan, and {for the case of the widow they judged not}. 

#### Jeremiah 5:29 Shall I not {for these watch}, says the LORD? or to {a nation such} shall I not avenge my soul? 

#### Jeremiah 5:30 A change of state and causes for shuddering was taken place upon the earth. 

#### Jeremiah 5:31 The prophets prophesied unjustly, and the priests clapped their hands; and my people have loved it so. And what will you do in the times after these things? 

#### Jeremiah 6:1 Grow in strength, O sons of Benjamin, from the midst of Jerusalem! And in Tekoa signify by trumpet! And over Beth-haccerem lift a sign! For bad things look from the north, and {destruction great} is happening. 

#### Jeremiah 6:2 And {shall be removed your haughtiness}, O daughter of Zion. 

#### Jeremiah 6:3 {unto her shall come Shepherds} and their flocks; and they shall pitch {against her tents} round about. And {shall tend each} with his hand. 

#### Jeremiah 6:4 Make preparations against her for war! Rise up! for we should ascend upon her at midday. Woe to us, for {has declined the day}, for {fail the shadows of the day}. 

#### Jeremiah 6:5 Rise up! for we should ascend at night, and utterly destroy her foundations. 

#### Jeremiah 6:6 For thus says the LORD of the forces, Cut down her trees! Discharge {against Jerusalem a force}, O {city lying}! Complete tyranny is in her. 

#### Jeremiah 6:7 As {cools a well} its water, so {cools evil} her. Impiety and misery shall be heard in her before her face always. 

#### Jeremiah 6:8 In misery and with a whip you shall be corrected, O Jerusalem, lest {should depart my soul} from you; lest I should make you an untrodden land, which shall not be settled in. 

#### Jeremiah 6:9 For thus says the LORD of the forces, Glean! Glean {as a grapevine the remnants of Israel}! Return as one gathering the vintage returns unto his basket! 

#### Jeremiah 6:10 To whom should I speak, and testify, and he shall hearken? Behold, {are uncircumcised their ears}, and they are not able to hear. Behold, the word of the LORD became to them as a scorning; in no way shall they be willing to hear it. 

#### Jeremiah 6:11 And {my rage I filled}, and I waited, but not finished them off entirely. I will pour out upon the simple ones outside, and upon the gathering of young men together; for man and woman shall be seized; the elder with the one full of days. 

#### Jeremiah 6:12 And {shall be transferred their houses} to others, with fields and their wives together. For I will stretch out my hand against the ones dwelling this land, says the LORD. 

#### Jeremiah 6:13 For from their small and unto great all have completed lawless deeds; from the priest and unto false prophet, all acted falsely. 

#### Jeremiah 6:14 And they repaired the destruction of my people treating it with contempt, and saying, Peace. And where is peace? 

#### Jeremiah 6:15 They were shamed for they failed; but neither as ones being disgraced were they disgraced; and their dishonor they knew not. On account of this they shall fall in their downfall, and in time of their visitation they shall perish, said the LORD. 

#### Jeremiah 6:16 Thus says the LORD, Stand upon the ways, and behold! and ask {roads of the LORD of eternal}! and see what kind is the {way good}! and proceed in it! and you will find purification to your souls. And they said, We will not go. 

#### Jeremiah 6:17 I have placed over you watchmen; hearken to the sound of the trumpet! But they said, We will not hearken. 

#### Jeremiah 6:18 On account of this, {heard the nations}, and the ones tending their flocks. 

#### Jeremiah 6:19 Hearken, O earth! Behold, I will bring upon this people bad things -- the fruit of their rejection. For my word they heeded not, and my law they have thrust away. 

#### Jeremiah 6:20 Why {to me frankincense from out of Sheba do you bring}, and cinnamon from out of a land far off? Your whole burnt-offerings are not acceptable, and your sacrifices have not delighted me. 

#### Jeremiah 6:21 On account of this, thus says the LORD, Behold, I impute upon this people weakness, and {shall weaken in it fathers and sons} together; neighbor and his near one shall perish. 

#### Jeremiah 6:22 Thus says the LORD, Behold, a people comes from the north, and nations shall be awakened from the end of the earth. 

#### Jeremiah 6:23 Bow and pike they shall hold. It is audacious, and will not show mercy. Its sound is as the sea swelling up. Upon horses and chariots it shall deploy as fire for war against you, O daughter of Zion. 

#### Jeremiah 6:24 We heard the report of them; {were disabled our hands}; affliction holds us down; pangs as a woman giving birth. 

#### Jeremiah 6:25 Do not go forth into a field, and {in the ways do not proceed}! For a broadsword of the enemies sojourns round about. 

#### Jeremiah 6:26 Daughter of my people, gird on sackcloth! Strew ashes! {mourning as of a beloved one You shall observe for yourself} by beating the breast pitiably. For suddenly {shall come misery} upon you. 

#### Jeremiah 6:27 {as an approver I have appointed you} among peoples being tried; and you shall know in my trying their way. 

#### Jeremiah 6:28 All are unhearing, going crookedly; as brass and iron {all being corrupted they are}. 

#### Jeremiah 6:29 {failed The bellows} at the fire; {failed the lead}; {in vain the silversmith works silver}; their wickednesses do not melt away. 

#### Jeremiah 6:30 {silver rejected Call them}! for {rejected them the LORD}. 

#### Jeremiah 7:1 The word which came to Jeremiah from the LORD, saying, Stand upon the gate of the house of the LORD, and read there this word! And say, 

#### Jeremiah 7:2 Hear the word of the LORD all Judea! 

#### Jeremiah 7:3 Thus says the LORD of the forces, the God of Israel, Set right your ways and your practices! and I will settle you in this place. 

#### Jeremiah 7:4 Rely not upon yourselves with {words lying}, for thoroughly they will not benefit you in your saying, The temple of the LORD, {the temple of the LORD it is}. 

#### Jeremiah 7:5 For if in setting right, you should set right your ways, and your practices, and in doing you should execute equity between a man and between his neighbor, 

#### Jeremiah 7:6 and {the foreigner and orphan and widow you should not tyrannize over}; and {blood innocent you should not pour out} in this place; and {after strange gods you should not go} for your hurt; 

#### Jeremiah 7:7 then I will settle you in your place, in the land which I gave to your fathers from the eon, and unto the eon. 

#### Jeremiah 7:8 But since you rely upon {words lying}, from where you will not be benefitted; 

#### Jeremiah 7:9 and you murder, and you commit adultery, and steal, and swear upon an oath unjustly, and burn incense to Baal, and go after strange gods whom you do not know, 

#### Jeremiah 7:10 it is to be wickedness to you. And you came and stood before me in the house which {is called my name} upon in it. And you said, We have kept a distance to do all these abominations. 

#### Jeremiah 7:11 {is not a cave of robbers My house}, of which {is called my name} upon in it there before you. And behold, I have seen, says the LORD. 

#### Jeremiah 7:12 For go unto my place! the one in Shiloh, where I encamped my name before it there prior. And see what I did to it because of the countenance of evil of my people Israel! 

#### Jeremiah 7:13 And now, because you have done all these works, and I spoke to you, and {not you heard me}; and I called you, and you were not responding; 

#### Jeremiah 7:14 I also will do to this house (of which {is called my name} upon in it, upon which you relied upon it, and the place which I gave to you and to your fathers,) as I did to Shiloh. 

#### Jeremiah 7:15 And I will throw you away from my face, as I threw away your brethren, all the seed of Ephraim. 

#### Jeremiah 7:16 And you, do not pray for this people! and do not petition to show them mercy! and do not make a vow! and do not come forward to me concerning them! for I will not listen to you. 

#### Jeremiah 7:17 Or do you not see what they do in the cities of Judah, and in the streets of Jerusalem? 

#### Jeremiah 7:18 Their sons collect together wood, and their fathers kindle a fire, and their women knead dough to make cakes to the military of the heaven; and they offered libations to strange gods, that they should provoke me to anger. 

#### Jeremiah 7:19 Do {not me they provoke} to anger, says the LORD? Do they not provoke themselves that {should be disgraced their faces}? 

#### Jeremiah 7:20 On account of this, thus says the LORD, Behold, {anger and rage my} is poured upon this place, and upon the men, and upon the cattle, and upon every tree of the field, and upon the produce of the land; and it shall be kindled and not extinguished. 

#### Jeremiah 7:21 Thus says the LORD, {your whole burnt-offerings Gather together} with your sacrifices, and eat meats! 

#### Jeremiah 7:22 For I spoke not to your fathers, and I did not give charge to them in the day I led them from out of the land of Egypt concerning whole burnt-offerings and sacrifices. 

#### Jeremiah 7:23 But only this saying gave I charge to them, saying, Hearken to my voice! and I will be to you for a God, and you will be to me for a people. And go in all my ways! in which ever I should give charge to you, so even it might be good to you. 

#### Jeremiah 7:24 And they did not listen to me, and they did not take heed with their ear, but they went by the thoughts {heart of their evil}; and they became for the rear, and not for the front. 

#### Jeremiah 7:25 From which day {went forth their fathers} from out of the land of Egypt, and until this day, even I sent to you all my servants of the prophets by day; and at dawn also I sent. 

#### Jeremiah 7:26 And they did not listen to me, and {did not take heed their ear}, and they hardened their neck above their fathers. 

#### Jeremiah 7:27 And you shall say to them this word, and they will not listen to you. And you shall call them, and they will not respond to you. 

#### Jeremiah 7:28 And you shall say to them, This is the nation which hearkened not to the voice of the LORD their God, nor received instruction. {failed Trust} from their mouth. 

#### Jeremiah 7:29 Shear your head, and throw away! And take upon your lips wailing! for the LORD rejected and thrust away the generation doing these things. 

#### Jeremiah 7:30 For {did the sons of Judah} wicked before me, says the LORD. They arranged their abominations in the house which {is called my name} upon it, to defile it. 

#### Jeremiah 7:31 And they built the shrine of Tophet, which is in the ravine of the son of Hinnom, to incinerate their sons and their daughters by fire; which I did not give charge to them, and did not consider in my heart. 

#### Jeremiah 7:32 On account of this, Behold, days come, says the LORD, and they shall not say any more, Shrine of Tophet, and Ravine of the Son of Hinnom, but, The Ravine of the ones Being done away with. And they shall entomb in Tophet, on account of {not existing a place}. 

#### Jeremiah 7:33 And {will be the dead of this people} for food to the birds of heaven, and to the wild beasts of the earth; and there will not be one frightening them away. 

#### Jeremiah 7:34 And I will depose from out of the cities of Judah, and from out of the corridors of Jerusalem the voice of ones being glad, and the voice of ones rejoicing, the voice of the groom, and the voice of the bride; for {for desolation will be all the land}. 

#### Jeremiah 8:1 In that time, says the LORD, They shall bring forth the bones of the kings of Judah, and the bones of its rulers, and the bones of the priests, and the bones of their prophets, and the bones of the ones dwelling in Jerusalem, from out of their burying-places. 

#### Jeremiah 8:2 And they shall freshen them to the sun, and to the moon, and to all the stars, and to all the military of the heaven, which they loved, and which they served, and whom they went after them, and whom they held to, and to whom they did obeisance to them. They shall not be lamented, and they shall not be entombed. And they will be for an example on the face of the earth. 

#### Jeremiah 8:3 For they took death rather than life, even to all the ones remaining to the ones being left behind from that generation, in every place of which ever I shall push them there. 

#### Jeremiah 8:4 For thus says the LORD, Shall the one falling, not be raised up? or the one turning, not return? 

#### Jeremiah 8:5 Why turned this people {rejection in an impudent}, and they hold firmly to their resolve, and they do not want to return? 

#### Jeremiah 8:6 Give ear indeed, and hearken! {not rightly Will they} speak? There is not a man repenting from his evil, saying, What did I do? {stopped The one running} from his race, as a horse sweating in his snorting. 

#### Jeremiah 8:7 Even the stork in the heaven knew her time, and the turtle-dove and the swallow of the field. The sparrows guard the times of their entrances. But my people knew not the judgments of the LORD. 

#### Jeremiah 8:8 How shall you say that, {wise are We}, and the law of the LORD {with us is}? For {vain became rush reed pen the lying} to the scribes. 

#### Jeremiah 8:9 {are ashamed The wise men}, terrified, and convicted; for the word of the LORD they rejected; what wisdom is in them? 

#### Jeremiah 8:10 On account of this, I give their wives to others, and their fields to the heirs. For from small unto great all {a fondness of money pursue}. And from prophet unto priest all commit lies. 

#### Jeremiah 8:11 And treating the broken daughter of my people with dishonor, saying, Peace peace; and there was not peace. 

#### Jeremiah 8:12 They have been shamed, for {an abomination they did}. And with shame they were not ashamed, and to be ashamed they did not know. On account of this they shall fall in the midst of ones falling. In the time of his visit they shall fall, says the LORD. 

#### Jeremiah 8:13 And they shall gather of their produce, says the LORD. There is no grape on the grapevines, and there are no figs on the fig-trees, and the leaves have flown down. 

#### Jeremiah 8:14 For why do we sit? Come together, and we should enter into the {cities fortified}, and we should be disowned there; for God disowned us, and gave us to drink water of bile, for we sinned before him. 

#### Jeremiah 8:15 We have gathered together for peace, and there were no good things in the time of healing, but behold, anxiety. 

#### Jeremiah 8:16 From out of Dan we shall hear the sound {swift horses of his}. From the sound of snorting of the ones riding his horses {shall be shaken all the land}. And he shall come and devour the land, and the fullness of it -- the city, and the ones dwelling in it. 

#### Jeremiah 8:17 For behold, I send out against you serpents putting to death, ones which are not charmed; and they shall bite you; 

#### Jeremiah 8:18 incurably with the grief of your heart being perplexed. 

#### Jeremiah 8:19 Behold, the sound of the cry of the daughter of my people from a land far off. {the LORD not Is} in Zion? or {king no is} there? For they provoked me to anger by their idolatrous carvings, and by {vanities strange}. 

#### Jeremiah 8:20 {went Summer}; {passed harvest}, and we have not been delivered. 

#### Jeremiah 8:21 Upon destruction of the daughter of my people I have been enveloped in darkness; in perplexity {prevailed over me pangs} as a woman giving birth. 

#### Jeremiah 8:22 And {balm no is} in Gilead? and {physician no Is} there? Why did {not ascend a healing} for the daughter of my people? 

#### Jeremiah 9:1 Who will give my head water, and my eyes a spring of tears, that I shall weep for {my people this} day and night, the ones being slain of the daughter of my people? 

#### Jeremiah 9:2 Who shall give to me {of the wilderness a post house at the end}? for I shall leave my people, and I shall go forth from them, for they all commit adultery; a convocation of ones annulling covenant. 

#### Jeremiah 9:3 And they stretched tight their tongue as a bow; a lie and no trust grows in strength upon the earth. For {from evils unto evils they went}, and {me not they knew}, says the LORD. 

#### Jeremiah 9:4 {each of his neighbor Let take guard}, and {upon their brethren let them not rely}! For every brother {with the heel shall stomp}, and every friend {deceitfully shall go}. 

#### Jeremiah 9:5 Each {against his friend shall mock}. {truth In no way shall they speak}. {has learned Their tongue} to speak falsely. They wronged, and stopped not to turn back. 

#### Jeremiah 9:6 Interest upon interest, treachery upon treachery; they have not wanted to behold me, says the LORD. 

#### Jeremiah 9:7 On account of this, Thus says the LORD of the forces, Behold, I shall set them on fire, and try them. What will I act before the face of the wickedness of the daughter of my people? 

#### Jeremiah 9:8 {arrow is a piercing Their tongue}; {deceitful the words of their mouth}; {to his neighbor one speaks peaceably}, and in himself he has hatred. 

#### Jeremiah 9:9 Shall {upon these I not visit}, says the LORD? or, {on a people such not shall take vengeance my soul}? 

#### Jeremiah 9:10 Concerning the mountains, take up a lamenting! and for the roads of the wilderness, a wailing! For they failed by there not being men. They heard not the sound of the existence of winged creatures of the heaven. And the cattle receded -- they were set out. 

#### Jeremiah 9:11 And I will give Jerusalem for displacement, and for a home of dragons. And the cities of Judah {for extinction I will appoint}, so as to not be dwelt in. 

#### Jeremiah 9:12 Who is the {man discerning}? then let him perceive this! And the word of the mouth of the LORD is with him, let him announce to you on account of why {was destroyed the land}! It was lit on fire as a wilderness, so as to not travel through it. 

#### Jeremiah 9:13 And the LORD said to me, On account of their abandoning my law which I put before their face, and they have not hearkened to my voice; 

#### Jeremiah 9:14 but went after the things pleasing their heart -- the evil thing; and after the idols which {taught them to worship their fathers}. 

#### Jeremiah 9:15 On account of this, thus says the LORD of the forces, the God of Israel, Behold, I will feed them distresses, and I will cause them to drink water of bile. 

#### Jeremiah 9:16 And I will disperse them among the nations which {not they knew}, nor their fathers. And I will send {as a successor upon them the sword}, until they are completely consumed by it. 

#### Jeremiah 9:17 Thus says the LORD, Call the wailing women and let them come! And to the wise women send, and let them utter their voice! 

#### Jeremiah 9:18 And let them take upon you a lamentation! And let {lead down your eyes} tears! And {your eyelids let} flow water! 

#### Jeremiah 9:19 For a voice of lament was heard in Zion, saying, O how we became in misery. We were disgraced very much, for we abandoned the land, and threw away our tents. 

#### Jeremiah 9:20 Hear indeed, O women, the word of God! And let {receive your ears} the words of his mouth! And teach your daughters a lamentation! and let every woman teach her neighbor wailing! 

#### Jeremiah 9:21 For {ascended death} through your windows; it entered into your land to obliterate infants outside, and young men from the squares. 

#### Jeremiah 9:22 And {will be the dead of men} for an example upon the face of the plain of your land; and as grass after being mowed, and there will not be one gathering. 

#### Jeremiah 9:23 Thus says the LORD, Let not {boast the wise man} in his wisdom! And let not {boast the strong man} in his strength! And let not {boast the rich man} in his riches! 

#### Jeremiah 9:24 But in this {let him boast boasting}! To perceive and to know me, that I am the LORD, the one having mercy, and judgment, and righteousness upon the earth. For {is in these things my will}, says the LORD. 

#### Jeremiah 9:25 Behold, days come, says the LORD, and I will visit upon all having been circumcised of their uncircumcision; 

#### Jeremiah 9:26 upon Egypt, and upon Judah, and upon Edom, and upon the sons of Ammon, and upon the sons of Moab, and upon every one shaving round about his face -- of the ones dwelling in the wilderness. For all the nations are uncircumcised in flesh, and all the house of Israel uncircumcised of their heart. 

#### Jeremiah 10:1 Hear the word of the LORD! which he spoke to you, O house of Israel. 

#### Jeremiah 10:2 Thus says the LORD, {according to the ways of the nations Do not learn}! And from the signs of the heaven do not fear! for {are fearing them nations}. 

#### Jeremiah 10:3 For the laws of the nations are vain. An idol is a tree {from out of the forest being cut}, the work of a fabricator, even a molten casting. 

#### Jeremiah 10:4 {in silver and gold being bedecked It is}. By a hammer and nail they stiffen them, 

#### Jeremiah 10:5 and they do not move. {a silver turned piece It is} -- they do not speak. Being lifted they shall be lifted, for they shall not mount themselves. You should not fear them, for in no way should they do evil, and {good there is no} in them. 

#### Jeremiah 10:6 There is not one likened to you, O LORD. Great are you, and great is your name in strength. 

#### Jeremiah 10:7 Who shall not fear you, O king of nations? For to you it is becoming. For among all the wise of the nations, and among all their kingdoms, there is not one likened to you. 

#### Jeremiah 10:8 At the same time {foolish and unthinking they are}. {a teacher of vanities Their tree is}. 

#### Jeremiah 10:9 {silver Amalgamated} from Tarshish; {shall come gold} from Uphaz; and by the hand of goldsmiths {works of craftsmen they are all}. {blue and purple They shall put on them}. 

#### Jeremiah 10:11 Thus you shall say to them, The gods who {the heaven and the earth did not make} let them be destroyed from the earth, and from beneath this heaven! 

#### Jeremiah 10:12 The LORD is the one making the earth by his strength; erecting the world by his wisdom; and by his intellect he stretched out the heaven, 

#### Jeremiah 10:13 and the multitude of water in the heaven; and he led clouds from the end of the earth; {lightnings for the rain he made}, and he brought out winds from his treasuries. 

#### Jeremiah 10:14 {was made moronish Every man} from knowledge; {was disgraced every goldsmith} over his carved idols; for {false they cast} in a furnace; there is no breath in them. 

#### Jeremiah 10:15 They are vanities, {works mocking}. In the time of their visitation they shall be destroyed. 

#### Jeremiah 10:16 {is not Such} the portion of Jacob, for the one shaping all things is he, and Israel is the rod of his inheritance -- the LORD of forces is his name. 

#### Jeremiah 10:17 He gathered {from outside his support} dwelling in choice vessels. 

#### Jeremiah 10:18 For thus says the LORD, Behold, I trip up the ones dwelling this land. And I will squeeze them out so that it should be found. 

#### Jeremiah 10:19 Woe over your destruction, {is painful your wound}. And I said, Really this is my wound, and it overtook me. 

#### Jeremiah 10:20 My tent is in miserable condition, it was destroyed; and all of my hide coverings were pulled apart. My sons and my sheep are no more; there is no more place for my tent, nor a place for my hide coverings. 

#### Jeremiah 10:21 For the shepherds were unwise, and {the LORD they do not seek}. On account of this {comprehended not all the sheep of the pasture}, and are dispersed. 

#### Jeremiah 10:22 {a sound of a report Behold there comes}, and {quake a great} from out of the land of the north, to order the cities of Judah for extinction, and a bed for ostriches. 

#### Jeremiah 10:23 I know, O LORD, that {is not of man the way} his own; nor shall a man go and keep {straight his goings}. 

#### Jeremiah 10:24 Correct us, O LORD, only with equity, and not in rage! that {not us few you should make}. 

#### Jeremiah 10:25 Pour out your rage upon the nations! the ones not knowing you; and upon kingdoms which {your name called not upon}. For they devoured Jacob, and completely consumed Israel, and {his pasture made desolate}. 

#### Jeremiah 11:1 The word coming from the LORD to Jeremiah, saying, 

#### Jeremiah 11:2 Hear the words of this covenant! And you shall speak to the men of Judah, and to the ones dwelling in Jerusalem. 

#### Jeremiah 11:3 And you shall say to them, Thus says the LORD God of Israel, Accursed is the man who shall not hearken to the words of this covenant, 

#### Jeremiah 11:4 of which I gave charge to your fathers in the day I led them from out of the land of Egypt, from out of the furnace of iron, saying, Hearken to my voice, and do all as much as I give charge to you! And you will be to me for a people, and I will be to you for God. 

#### Jeremiah 11:5 So that I should establish my oath which I swore by an oath to your fathers, to give to them a land flowing milk and honey, as this day. And I answered and said, May it be, O LORD. 

#### Jeremiah 11:6 And the LORD said to me, Read all these words in the cities of Judah, and outside of Jerusalem! saying, Hear the words of this covenant, and do them! 

#### Jeremiah 11:7 For bearing witness together I bore witness to your fathers in the day in which I led them out of the land of Egypt until this day. Rising early I bore witness saying, Hear my voice! And they did not hear, and they inclined not their ear; but they went each in the deformity {heart of his evil}. And {entered unto them all the words of this covenant} of which I commanded to be done. 

#### Jeremiah 11:8 But they did not do. 

#### Jeremiah 11:9 And the LORD said to me, {is found A conspiracy} among the men of Judah, and among the ones dwelling in Jerusalem. 

#### Jeremiah 11:10 They returned unto the iniquities of their fathers, of the ones prior, the ones not wanting to listen to my words. And behold, they went after strange gods, to serve them; and {effaced the house of Israel} and the house of Judah, my covenant which I ordained with their fathers. 

#### Jeremiah 11:11 On account of this, thus says the LORD, Behold, I bring upon them evils of which they shall not be able to come forth from out of them. And they shall cry out to me, and I will not listen to them. 

#### Jeremiah 11:12 And {shall go the cities of Judah and the ones dwelling in Jerusalem}, and they shall cry out to their gods to whom they burn incense to them; the ones who shall not deliver them in the time of their evils. 

#### Jeremiah 11:13 For according to the number of your cities were your gods, O Judah. And according to the number of the streets of Jerusalem you arranged shrines to burn incense to Baal. 

#### Jeremiah 11:14 And you, pray not for this people, and do not petition concerning them with supplication and prayer! For I will not listen in the time in which they call upon me, in the time of their affliction. 

#### Jeremiah 11:15 What {did the one being loved in my house do abomination}? Shall vows and {meats holy} remove from you your evils, or by these will you evade? 

#### Jeremiah 11:16 {olive tree a beautiful well-shaded to the sight called The LORD your name}. In the sound of its being lopped {was lit a fire} unto it; {were made useless her tender branches}. 

#### Jeremiah 11:17 And the LORD of the forces, the one having planted you, spoke {against you evils}; against the evils of the house of Israel, and the house of Judah. For they did it to themselves, provoking me to anger in their burning incense to Baal. 

#### Jeremiah 11:18 O LORD, make it known to me! and I shall know. Then I knew their practices. 

#### Jeremiah 11:19 But I am as a little lamb, guileless, being led for a sacrifice, not knowing. Against me they devised a device, saying, Come, and we should put wood for his bread, and we should obliterate him from the land of the living; and his name in no way shall be remembered any longer. 

#### Jeremiah 11:20 O LORD of the forces, judging just things, trying the kidneys and the hearts, may I behold {exacted by you the punishment} on them. For to you I revealed my right action. 

#### Jeremiah 11:21 On account of this, Thus says the LORD against the men of Anathoth, the ones seeking my life, the ones saying, In no way should you prophesy in the name of the LORD, and if you do not agree you shall die by our hands. 

#### Jeremiah 11:22 On account of this, thus says the LORD of the forces, Behold, I will make a visit unto them. Their young men {by the sword shall die}; their sons and their daughters shall come to an end in famine. 

#### Jeremiah 11:23 And {left there will not be} of them. For I will bring evils upon the ones dwelling in Anathoth, in the year of their visitation. 

#### Jeremiah 12:1 You are righteous, O LORD, that I may plead to you. {only concerning judgments I will speak to you}. Why is it that the way of the impious prospers? {prospered All the ones disrespecting in wickedness}. 

#### Jeremiah 12:2 You planted them, and they were rooted. They produced children, and they produced fruit. {near are You} their mouth, and at a distance from their kidneys. 

#### Jeremiah 12:3 And you, O LORD, know me. You have tried my heart before you. Gather them as a flock for a sacrifice, and purify them for the day of slaughter! 

#### Jeremiah 12:4 For how long will {mourn the land}, and all the grass of the field be dried, because of the evils of the ones dwelling in it? {were removed from view The cattle and the winged creatures}; for they said, {shall not see God} our ways. 

#### Jeremiah 12:5 Your feet run, and they cause you to faint. How will you make preparations to ride upon horses? and {in the land of your peace you have relied}. How will you do in the neighing of the Jordan? 

#### Jeremiah 12:6 For even your brethren and the house of your father, even they disregarded you; and they yelled out; {at your rear they assembled}; you should not trust in them when they speak with you good words. 

#### Jeremiah 12:7 I have abandoned my house; I let go of my inheritance; I gave the one being loved of my soul into the hands of her enemies. 

#### Jeremiah 12:8 {became My inheritance} to me as a lion in the forest; she uttered {against me her voice}; on account of this I detested her. 

#### Jeremiah 12:9 Is not the cave of a hyena my inheritance to me, the cave round about her against her? Proceed, bring together all the wild beasts of the field, and let them come to eat her! 

#### Jeremiah 12:10 {shepherds Many} corrupted my vineyard, they tainted my portion; they made {portion my desirable} for {wilderness an untrodden}. 

#### Jeremiah 12:11 It was appointed for extinction by destruction; on account of me {in extinction was obliterated all the land}, for there is no man putting it to heart. 

#### Jeremiah 12:12 Upon every mountain pass in the wilderness {came the ones causing misery}. For the sword of the LORD shall devour from one tip of the land unto the other tip of the land; there is no peace to all flesh. 

#### Jeremiah 12:13 You sowed wheat, and {thorn-bushes harvested}. Their lots shall not benefit them. Be ashamed of your boasting, because of scorn before the LORD! 

#### Jeremiah 12:14 For thus says the LORD, Concerning all the {neighbors wicked} of the ones touching my inheritance, which I portioned to my people Israel -- behold, I draw them away from their land, and Judah I will cast out from the midst of them. 

#### Jeremiah 12:15 And it will be after {casting out my them}, I will return, and I will show mercy on them, and I will settle them each in his inheritance, and each in his land. 

#### Jeremiah 12:16 And it will be if in learning they should learn the way of my people, to swear by an oath to my name, saying, As the LORD lives; as they taught my people to swear by an oath to Baal, then they shall be edified in the midst of my people. 

#### Jeremiah 12:17 But if they should not return, then I shall lift away that nation by removal and destruction, says the LORD. 

#### Jeremiah 13:1 Thus says the LORD, Proceed and acquire for yourself {loincloth a flaxen linen}, and put it around your loin! and {water you shall not go through}. 

#### Jeremiah 13:2 And I acquired the loincloth according to the word of the LORD, and I put it around my loin. 

#### Jeremiah 13:3 And came to pass the word of the LORD to me of a second time, saying, 

#### Jeremiah 13:4 Take the loincloth, the one around your loin, and arise, and proceed unto the Euphrates, and hide it there in the hole of the rock! 

#### Jeremiah 13:5 And I went, and hid it by the Euphrates, as {gave charge to me the LORD}. 

#### Jeremiah 13:6 And it came to pass after {days many}, and the LORD said to me, Arise! Proceed unto the Euphrates, and take from there the loincloth! the one which I gave charge to you to hide it there. 

#### Jeremiah 13:7 And I went unto the Euphrates, and I dug, and I took the loincloth from out of the place where I hid it there. And behold, it was ruined, which in no way should it be used for anything. 

#### Jeremiah 13:8 And came to pass the word of the LORD to me, saying, 

#### Jeremiah 13:9 Thus says the LORD, Thus shall I corrupt the insolence of Judah, and the insolence of Jerusalem; 

#### Jeremiah 13:10 this great insolence of the ones not wanting to obey my words, and having gone in straightness {heart of their wicked}, and having gone after strange gods, to serve to them, and to do obeisance to them; and they will be as this loincloth which shall not be used yet for anything. 

#### Jeremiah 13:11 For just as {cleaves the loincloth} around the loin of a man, so I cleaved to myself the house of Israel, and all the house of Judah, says the LORD; to be to me for {people a famous}, and for a boasting. And for glory; and they did not hearken to me. 

#### Jeremiah 13:12 And you shall say to the people this word, Thus says the LORD, the God of Israel. Every leather bag shall be filled of wine. And it will be if they should say to you, Is it in not knowing that we shall not know that every leather bag shall be filled with wine? 

#### Jeremiah 13:13 And you shall say to them, Thus says the LORD, Behold, I shall fill all the ones dwelling this land, and their kings, the ones sitting down of the sons of David upon their throne, and the priests, and the prophets, and Judah, and all the ones dwelling in Jerusalem with strong drink. 

#### Jeremiah 13:14 And I will disperse them, a man and his brother, and their fathers, and their sons in the same way; I will not long after them, says the LORD, and I will not spare, and I will not pity at their ruin. 

#### Jeremiah 13:15 Hear, and give ear, and do not be encouraged! for the LORD spoke. 

#### Jeremiah 13:16 Give to the LORD your God glory! before the darkening, and before the stumbling of your feet upon {mountains dark}. And you shall await for light, and there is the shadow of death, and they shall be put into darkness. 

#### Jeremiah 13:17 But if you should not hearken, secretly {shall weep your soul} from in front of insolence; and {shall lead down your eyes} tears. For {was broken up the flock of the LORD}. 

#### Jeremiah 13:18 Say to the king! and to the ones being in power, Be humbled, and sit down! for {was demolished from your head crown of glory your}. 

#### Jeremiah 13:19 The cities, the ones towards the south were closed up, and there was not one opening. Judah was resettled, they completed in it {resettlement a complete}. 

#### Jeremiah 13:20 Lift up your eyes, O Jerusalem, and behold the ones coming from the north! Where is the flock which was given to you, the sheep of your glory? 

#### Jeremiah 13:21 What shall you say whenever they should visit you, and you taught them {against yourself lessons for rule}? Shall not pangs control you as a woman giving birth? 

#### Jeremiah 13:22 And if you shall say in your heart, Why have {met up with me these things}? On account of the magnitude of your iniquity {were uncovered your posteriors}, to make an example of your heels. 

#### Jeremiah 13:23 If {shall change the Ethiopian} his skin, and the leopard her colors, then you shall be able {good to do} while learning the bad. 

#### Jeremiah 13:24 And I scattered them as sticks being carried by the wind into a wilderness. 

#### Jeremiah 13:25 Thus your lot and portion for your resisting me, says the LORD; as you forgot me and hoped upon lies. 

#### Jeremiah 13:26 And I will uncover your rear unto your face, and {shall be seen your dishonor}. 

#### Jeremiah 13:27 Your adultery, and your snorting, and the alienation of your harlotry upon the hills, and in the fields I have seen -- your abominations. Woe to you, O Jerusalem, for you were not cleansed to follow after me. For how long yet? 

#### Jeremiah 14:1 And came to pass the word of the LORD to Jeremiah concerning the drought. 

#### Jeremiah 14:2 Judea mourned, and her gates are emptied, and are enveloped in darkness upon the earth; and the cry of Jerusalem ascended. 

#### Jeremiah 14:3 And her great men sent their younger ones for water. They came upon the wells and did not find water. They returned their receptacles empty. 

#### Jeremiah 14:4 And the works of the land failed, for there was no rain. {were ashamed The farmers}, they covered their head. 

#### Jeremiah 14:5 And the hinds in the field gave birth, and abandoned it, for there was no pasturage. 

#### Jeremiah 14:6 {donkeys The wild} stood upon the groves, and drew wind as dragons; {failed their eyes}, for there was no grass. 

#### Jeremiah 14:7 Since our sins opposed us, O LORD, do for us because of your name! For {are many our sins} before you. Against you we sinned. 

#### Jeremiah 14:8 You are the endurance of Israel, O LORD, delivering in time of evils. Why did you become as a sojourner upon the earth, and as a native-born turning aside for lodging? 

#### Jeremiah 14:9 Will you be as a man sleeping, or as a man not being able to deliver? But you {among us are}, O LORD, and your name is called upon us; you should not forget us. 

#### Jeremiah 14:10 Thus says the LORD to this people, They loved to move their feet, and spared not, and God prospered not the way among them. Now {shall be remembered the iniquity}, and he visited their sins. 

#### Jeremiah 14:11 And the LORD said to me, Do not pray for this people for good! 

#### Jeremiah 14:12 For if they should fast, I will not listen to their supplication. And if they should bring whole burnt-offerings, and sacrifices, I will not think well of them. For by sword and by famine {unto death I will finish them off entirely}. 

#### Jeremiah 14:13 And I said, O Being One, O LORD. Behold, the prophets prophesy and say, You shall not see a sword, nor shall hunger be among you; for truth and peace I shall appoint upon the land, and in this place. 

#### Jeremiah 14:14 And the LORD said to me, {lies the prophets prophesy} in my name. I did not send them, and I did not give charge to them, and I did not speak to them. For {visions lying}, and divinations, and omens, and the resolves of their own heart they prophesy to you. 

#### Jeremiah 14:15 On account of this, thus says the LORD, concerning the prophets, of the ones prophesying {in my name lies}, and I did not send them, who say, Sword and famine will not be upon this land. By {death a diseased} {shall die and by hunger they shall be finished off entirely the prophets}, 

#### Jeremiah 14:16 even the people to whom they prophesy to them. And they will be tossed in the streets of Jerusalem from in front of the sword, and of the famine. And there will not be one entombing them, even their wives, and their sons, and their daughters. And I shall pour out against them for their evils. 

#### Jeremiah 14:17 And you shall say to them this word, Lead down {into your eyes tears} day and night, and let them not stop! For {defeat by a great was defeated the daughter of my people}, even by {beating grievous an exceedingly}. 

#### Jeremiah 14:18 If I should go forth into the plain, then behold, ones slain by sword. And if I should enter into the city, then behold, the misery of famine. For priest and prophet were gone into a land which they did not know. 

#### Jeremiah 14:19 Did by rejecting you reject Judah? and {from Zion removed itself has your soul}? Why did you smite us, and there is no healing for us? We waited for peace, but there was no good; for a time of healing, but behold, only disturbance. 

#### Jeremiah 14:20 We knew, O LORD, our sins, the iniquities of our fathers. For we sinned before you. 

#### Jeremiah 14:21 Abate, on account of your name! You should not destroy the throne of your glory. Remember! you should not efface your covenant, the one with us! 

#### Jeremiah 14:22 Is there one among the idols of the nations causing rain, and shall {the heaven an idol give} its fullness, no. Is it not you being he, O LORD our God. And we shall wait on you, for you made all these. 

#### Jeremiah 15:1 And the LORD said to me, If {should stand Moses and Samuel} before my face {is not my soul} for them. Send out this people from my face, and let them go forth! 

#### Jeremiah 15:2 And it will be if they should say to you, Where shall we go forth? then you shall say to them, Thus says the LORD, As many as for death, to death; and as many as for sword, to sword; and as many as for famine, to famine; and as many as for captivity, to captivity. 

#### Jeremiah 15:3 And I will avenge against them four forms, says the LORD; the sword unto slaughter, and the dogs for tearing in pieces, and the wild beasts of the earth, and the winged creatures of the heaven for solid food and corruption. 

#### Jeremiah 15:4 And I will deliver them up for distresses to all the kingdoms of the earth, because of Manasseh son of Hezekiah king of Judah, for all which he did in Jerusalem. 

#### Jeremiah 15:5 Who will spare over you, O Jerusalem? And who will show timidity against you? Or, who shall return to say, Peace to you? 

#### Jeremiah 15:6 You turned from me, says the LORD; {back you shall go}. And I will stretch out my hand, and I shall utterly destroy you; and no longer shall I spare them. 

#### Jeremiah 15:7 And I will scatter them in a dispersion in the gates of my people. They were made childless; they destroyed my people because of their evils. 

#### Jeremiah 15:8 {were multiplied Their widows} above the sand of the sea; I brought {against the mother young men}, misery in midday. I cast upon her sudden trembling and anxiety. 

#### Jeremiah 15:9 {was emptied The one giving birth to seven}. {suffered misfortune Her soul}; {set her sun} even in the middle of the day. She was disgraced and berated. Of the ones remaining of them {to the sword I will give} before their enemies, says the LORD. 

#### Jeremiah 15:10 Woe, O mother, as how you bore me a man adjudicating and litigating in all the earth. I derived no benefit, nor did {benefit me anyone}. My strength failed among the ones cursing me. 

#### Jeremiah 15:11 May it be, O LORD master, of their prospering in a time of their affliction for good against the enemy. 

#### Jeremiah 15:12 Shall it be known that iron and a wrap-around garment of brass is your strength, no. 

#### Jeremiah 15:13 And of your treasures I will give an equivalent, on account of all your sins, and in all your borders. 

#### Jeremiah 15:14 I will reduce you to slavery round about your enemies, in the land which you knew not. For a fire has been kindled because of my rage; {against you it shall be kindled}. 

#### Jeremiah 15:15 O LORD, remember me, and visit me, and acquit me from the ones pursuing me -- not for leniency! Know how I took {on account of you scorning}! 

#### Jeremiah 15:16 even by the ones disregarding your words. Finish them off entirely! and {will be your word} to me for gladness and the joy of my heart. For {has been called your name} upon me, O LORD almighty. 

#### Jeremiah 15:17 I sat not in their sanhedrin playing about, but I was cautious from in front of your hand. Alone I sat, for {with bitterness I was filled}. 

#### Jeremiah 15:18 Why do the ones grieving me prevail over me? My wound is substantial, from where shall I be healed? In becoming, it became to me as {water false}, not having trust. 

#### Jeremiah 15:19 Because of this, thus says the LORD, If you should return, and I should restore you, {before my face you shall stand}. And if you should lead out the esteemed from the unworthy, {as my mouth you will be}. And they shall return to you; and you shall not return to them. 

#### Jeremiah 15:20 And I will appoint you to this people as {wall a fortified} of brass. And they shall wage war against you, but in no way shall they be able to prevail against you; because {with you I am} to deliver you, and to rescue you, says the LORD. 

#### Jeremiah 15:21 And I will deliver you from the hand of the wicked ones, and I will ransom you from the hand of pestilent ones. 

#### Jeremiah 16:1 And {came the word of the LORD} to me saying, 

#### Jeremiah 16:2 You should not take a wife, and there shall not be engendered to you a son nor daughter in this place. 

#### Jeremiah 16:3 For thus says the LORD, Concerning the sons and the daughters of the ones being engendered in this place, and concerning their mothers giving them birth, and concerning their fathers engendering them in this land; 

#### Jeremiah 16:4 by {death a diseased} they shall die; they shall not be lamented, and they shall not be entombed; for {an example upon the face of the earth they will be}. By the sword they shall fall, and in hunger they shall be finished off entirely. And {shall be their corpses} for food to the wild beasts of the earth, and to the winged creatures of the heaven. 

#### Jeremiah 16:5 Thus says the LORD, You should not enter into their revelry, and you should not go in to lament, and you should not mourn them. For I have removed my peace from this people, says the LORD, even mercy and charity. 

#### Jeremiah 16:6 And {shall die great and small} in this land. They shall not be buried, and they shall not be lamented, they shall not beat their chest for them, nor {cuts shall they make}, and they shall not be shaven; 

#### Jeremiah 16:7 and in no way should {be broken bread} in their mourning for consolation over one having died; they shall not give a drink for them of a cup for consolation over his father or his mother. 

#### Jeremiah 16:8 {into a residence with a banquet shall not enter You} to sit down with them to eat and to drink. 

#### Jeremiah 16:9 For thus says the LORD God of Israel, Behold, I depose from out of this place before your eyes, and in your days a voice of joy, and a voice of gladness, the voice of the groom, and the voice of the bride. 

#### Jeremiah 16:10 And it will be whenever you should announce to this people all these matters, then they shall say to you, Why did the LORD speak against us all these evils? What is our injustice, and what is our sin which we sinned before the LORD our God? 

#### Jeremiah 16:11 And you shall say to them, Because {abandoned me your fathers}, says the LORD; and they set out after strange gods, and they served to them, and did obeisance to them; and they abandoned me, and {my law they did not keep}. 

#### Jeremiah 16:12 And you were wicked above your fathers. And behold, you {go each} after the things pleasing your heart -- the evils, to not obey me. 

#### Jeremiah 16:13 And I will throw you away from this land, into a land which you knew not -- you and your fathers. And you shall serve there strange gods day and night, the ones that shall not grant mercy to you. 

#### Jeremiah 16:14 On account of this, behold, days come, says the LORD, and {not they shall say still}, As the LORD lives, the one leading up the sons of Israel from out of the land of Egypt. 

#### Jeremiah 16:15 But they shall say, As the LORD lives, who led the house of Israel from the land of the north, and from all the places where they were pushed out there. And I shall restore them unto their land which I gave to their fathers. 

#### Jeremiah 16:16 Behold, I send {fishermen many}, says the LORD, and they shall fish them. And after these I shall send many hunters, and they shall hunt them upon every mountain, and upon every hill, and from out of the holes of the rocks. 

#### Jeremiah 16:17 For my eyes are upon all their ways, and {were not hid their offences} before my eyes. 

#### Jeremiah 16:18 And I shall recompense double their iniquities, and their sins upon which they profaned my land by the decaying flesh of their abominations, and by their lawless deeds in which they filled my inheritance. 

#### Jeremiah 16:19 O LORD my strength and my help and my refuge in a day of evils. To you nations shall come from the ends of the earth. And they shall say, O how false {acquired our fathers the idols}, and there is no {in them benefit}. 

#### Jeremiah 16:20 Shall {make for himself a man} gods, and these are not gods? 

#### Jeremiah 16:21 On account of this, behold, I will make manifest to them {in this time my hand}; and I shall make known to them my power; and they shall know that my name is the LORD. 

#### Jeremiah 17:1 Thus says the LORD. The sin of Judah is being written with {stylus an iron} with clawed adamantine being carved upon the tablet of their heart, and upon the horns of their shrines. 

#### Jeremiah 17:2 even in the remembering of their sons of their shrines and their sacred groves upon tree woods, upon the {hills high}. 

#### Jeremiah 17:3 O mountain in the plain, of your wealth and all of you treasures {for plunder I shall give}; your heights for sin in all your boundaries. 

#### Jeremiah 17:4 And you shall be forsaken from your inheritance which I gave to you. And {to serve you I will make} to your enemies in the land which you knew not. For {fire you kindled} in my wrath; unto the eon it shall blaze. 

#### Jeremiah 17:5 Thus says the LORD, Cursed is the man who {hope has} upon man, and shall fix firmly the flesh of his arm, and {from the LORD should separate his heart}. 

#### Jeremiah 17:6 And he will be as the tamarisk in the wilderness; he shall not see whenever {come good things}. But he shall encamp in salty lands, and in a wilderness in a land brackish which is not dwelt. 

#### Jeremiah 17:7 And being blessed is the man who relies upon the LORD, and the LORD will be his hope. 

#### Jeremiah 17:8 And he shall be as a tree prospering by waters; and upon a moist place he shall shoot his roots; and he will not be fearful whenever {comes sweltering heat}; and there will be for him tree trunks of the woods. In the year of drought he shall not be fearful, and he shall not stop producing fruit. 

#### Jeremiah 17:9 {is deep The heart} beyond all things, and man is, who shall know him? 

#### Jeremiah 17:10 I the LORD am examining hearts, trying kidneys, to give to each according to his ways, and according to the fruits of their practices. 

#### Jeremiah 17:11 {speaks out loud The partridge}, gathering together what she did not give birth. So the man having his riches but not with equity; in the first half of his days his riches will leave him, and at the last half of his days he will be a fool. 

#### Jeremiah 17:12 {is a throne of glory being raised up high from the beginning Our sanctuary}. 

#### Jeremiah 17:13 The waiting of Israel, O LORD, all the ones forsaking you, let them be disgraced! Ones revolting, {upon the ground let them be written}! for they abandoned the spring of life -- the LORD. 

#### Jeremiah 17:14 Heal me, O LORD! and I shall be healed. Deliver me! and I shall be delivered. For {my boasting you are}. 

#### Jeremiah 17:15 Behold, they say to me, Where is the word of the LORD? Let it come! 

#### Jeremiah 17:16 But I tired not following closely after you; and the day of man I desired not. You have knowledge of the things having gone forth through my lips; {before your face it is}. 

#### Jeremiah 17:17 You should not be to me for alienation; but one sparing me in {day the evil}. 

#### Jeremiah 17:18 May {be disgraced the ones pursuing me}, and may I not be disgraced myself. May they be terrified, but may I not be terrified myself. Bring upon them {day the wicked}! In double destruction destroy them! 

#### Jeremiah 17:19 Thus says the LORD to me, Proceed and stand in the gates of the sons of the people! by which {enter kings of Judah}, and by which they go forth by them, and in all the gates of Jerusalem. 

#### Jeremiah 17:20 And you shall say to them, Hear the word of the LORD, O kings of Judah, and all Judea, and all Jerusalem! O ones entering by these gates. 

#### Jeremiah 17:21 Thus says the LORD, Guard your souls, and do not lift burdens on the day of the Sabbaths! and you should not carry in through the gates of Jerusalem. 

#### Jeremiah 17:22 And do not bring forth burdens from out of your residences on the day of the Sabbaths! And {any work you shall not do}. Sanctify the day of the Sabbaths! as I gave charge to your fathers. 

#### Jeremiah 17:23 And they hearkened not, and leaned not their ear. And they hardened their neck over their fathers to not hear me, and to not take instruction. 

#### Jeremiah 17:24 And it will be, if you should hearken to me, says the LORD, to not carry in burdens through the gates of this city in the day of the Sabbaths, and to sanctify the day of the Sabbaths to not do any work in it, 

#### Jeremiah 17:25 that there shall enter through the gates of this city kings and rulers sitting upon the throne of David, and mounting upon {chariots and horses their}, they and their rulers, the men of Judah, and the ones dwelling in Jerusalem. And {shall be settled this city} into the eon. 

#### Jeremiah 17:26 And they shall come from out of the cities of Judah, and round about Jerusalem, and from out of the land of Benjamin, and from out of the plain, and from out of the mountain, and from out of the country to the south, bringing whole burnt-offerings, and sacrifices, and incenses, and manna, and frankincense; bringing praise into the house of the LORD. 

#### Jeremiah 17:27 And it will be if you should not hearken to me to sanctify the day of the Sabbaths, to lift no burdens, and to not enter through the gates of Jerusalem in the day of the Sabbaths; then I will kindle a fire in her gates; and it shall devour the plazas of Jerusalem, and it shall not be extinguished. 

#### Jeremiah 18:1 The word coming to Jeremiah from the LORD, saying, 

#### Jeremiah 18:2 Rise up and go down unto the house of the potter! and there you shall hear my words. 

#### Jeremiah 18:3 And I went down unto the house of the potter. And behold, he was making a work upon the stones. 

#### Jeremiah 18:4 And {failed the vessel} which he was making with his hands. And again he made it {vessel into another} as was pleasing before him to make. 

#### Jeremiah 18:5 And came to pass the word of the LORD to me, saying, 

#### Jeremiah 18:6 Shall as this potter I not be able to make you, O house of Israel, says the LORD? Behold, as the mortar in the hand of the potter, so are you in my hands, O house of Israel. 

#### Jeremiah 18:7 At end I shall speak unto a nation or unto a kingdom to lift them away, and to destroy them. 

#### Jeremiah 18:8 But should {turn that nation} from their evils, then I shall change my mind concerning the bad things which I devised to do to them. 

#### Jeremiah 18:9 And at end I shall speak unto a nation and unto a kingdom to rebuild and to plant, 

#### Jeremiah 18:10 and they do the wicked things before me, to not hear my voice, then I will change my mind concerning the good things which I spoke to do for them. 

#### Jeremiah 18:11 And now say to the men of Judah, and to the ones dwelling in Jerusalem! Thus says the LORD, Behold, I shape against you bad things, and I devise against you a device! Let {turn indeed each} from {way his evil}, and {good make your practices} and your ways! 

#### Jeremiah 18:12 And they said, We will be manly, for after our turning, we shall go and each {the things pleasing heart his evil shall do}. 

#### Jeremiah 18:13 On account of this, Thus says the LORD, Ask indeed among the nations! who heard such causes for shuddering which {did exceedingly virgin Israel}? 

#### Jeremiah 18:14 Shall {fail from the rock nipples}, or snow from the Lebanon range? Will {turn aside water forcibly by a wind being brought}? 

#### Jeremiah 18:15 For {forgot me my people}. {in vain They burned incense}, and they shall weaken in their ways -- {roads eternal}; to mount roads not having a way for going; 

#### Jeremiah 18:16 to order up their land for extinction, and {hissing the everlasting}. All the ones traveling through it shall be amazed, and shall shake their head. 

#### Jeremiah 18:17 As {wind a burning} I will scatter them in front of their enemies. The back and not the front I will show to them in a day of their destruction. 

#### Jeremiah 18:18 And they said, Come, we should devise against Jeremiah a device, for {shall not perish the law} from the priest, nor counsel from the discerning, nor the word from the prophet. Come, for we should strike him in the tongue, and we shall not hear all his words. 

#### Jeremiah 18:19 Hear me, O LORD, and hear the voice of my right action! 

#### Jeremiah 18:20 Shall {be recompensed for good things evils}, no. For they conversed together things against my soul. Remember my standing in front of you! to speak {for them good}, to turn your rage from them. 

#### Jeremiah 18:21 On account of this, give their sons to famine, and gather them into the hands of swords! Let {become their women} childless and widows, and {their men let} become men being done away with in death, and their young men falling by sword in war! 

#### Jeremiah 18:22 Let there become a cry in their houses! You shall bring upon them robbers suddenly; for they took in hand a word to seize me, and {snares they hid} against me. 

#### Jeremiah 18:23 And you, O LORD, knew all together their plan against me for death. You should not acquit their iniquities; and {their sins from in front of you you should not wipe away}. Let {come their weakness} before you! In the time of your rage deal with them! 

#### Jeremiah 19:1 Then the LORD said to me, Proceed and acquire a pitcher! one being shaped of earthenware from the elders of the people and of the priests. 

#### Jeremiah 19:2 And you shall go forth into the cemetery of the sons of Hinnom, which is at the thresholds of the gate of Charsith, and read there all the words! which ever I shall speak to you. 

#### Jeremiah 19:3 And you shall say to them, Hear the word of the LORD, O kings of Judah, and O ones dwelling Jerusalem! Thus says the LORD of the forces, the God of Israel, Behold, I bring upon this place evils, so that all hearing them, {shall resound his ears}. 

#### Jeremiah 19:4 Because they abandoned me, and separated from this place; and they burned incense in it to strange gods who {did not know they} and their fathers; and the kings of Judah filled this place {blood of innocent}. 

#### Jeremiah 19:5 And they built high places to Baal to incinerate their sons in fire, which I did not give charge nor spoke, and did not consider in my heart. 

#### Jeremiah 19:6 On account of this, days come, says the LORD, and they shall not call this place still, Downfall, and Cemetery of the son of Hinnom, but Cemetery of the Slaughter. 

#### Jeremiah 19:7 And I will slay the counsel of Judah, and the counsel of Jerusalem in this place; and I will throw them down by the sword before their enemies, and by the hands of the ones seeking their lives. And I will give their dead for food to the winged creatures of the heaven, and to the wild beasts of the earth. 

#### Jeremiah 19:8 And I will order this city into extinction, and for a hissing. All coming upon it shall look downcast, and shall whistle over all its calamity. 

#### Jeremiah 19:9 And they shall eat the flesh of their sons, and the flesh of their daughters; and each {the flesh of his neighbor shall eat} in the citadel, and in the assault in which {shall assault them their enemies}, and the ones seeking their life. 

#### Jeremiah 19:10 And you shall break the pitcher before the eyes of the men, of the ones going forth with you. 

#### Jeremiah 19:11 And you shall say to them, Thus says the LORD, So I will break this people, and this city, as {was broken container the earthenware}, which is not able to be repaired again. And in Tophet they shall bury, for there is not a place to bury. 

#### Jeremiah 19:12 Thus I will do, says the LORD, to this place, and to the ones dwelling in it, to yield up this city as the one having fallen into ruin. 

#### Jeremiah 19:13 And the houses of Jerusalem, and the houses of the kings of Judah will be as a place having fallen into ruin because of the uncleannesses in all the houses in which they burned incense upon the roofs to all the military of the heaven, and offered libations to strange gods. 

#### Jeremiah 19:14 And Jeremiah came from Downfall, where {sent him the LORD} there to prophesy. And he stood in the courtyard of the house of the LORD, and he said to all the people, 

#### Jeremiah 19:15 Thus says the LORD of the forces, the God of Israel, Behold, I bring upon this city, and upon all her cities, and upon her towns, all the evils which I spoke against her, for they hardened their neck to not listen to my commandments. 

#### Jeremiah 20:1 And Pashur heard (the son of Immer the priest, and this one was being ordained leader of the house of the LORD) Jeremiah prophesying these words. 

#### Jeremiah 20:2 And he struck him, and put him into the dungeon which was by the gate of the house of Benjamin, the upper, which was in the house of the LORD. 

#### Jeremiah 20:3 And it came to pass in the next morning, and Pashur led out Jeremiah from the dungeon. And {said to him Jeremiah}, {not Pashur called the LORD your name}, but instead, Refugee. 

#### Jeremiah 20:4 Because thus says the LORD, Behold, I give you for displacement with all your friends. And they shall fall by the sword of their enemies, and your eyes shall see it. And you and all Judah I will give into the hands of the king of Babylon; and they shall displace them, and shall cut them in pieces with swords. 

#### Jeremiah 20:5 And I will put all the strength of this city, and all its toils, and all the treasures of the king of Judah into the hands of his enemies, and they shall lead them into Babylon. 

#### Jeremiah 20:6 And you and all the ones dwelling in your house shall go into captivity; and in Babylon you shall die, and there you shall be entombed, you and all your friends to whom you prophesied lies to them. 

#### Jeremiah 20:7 You deceived me, O LORD, and I was deceived. You held and prevailed. I became for laughter. Every day I continue being sneered at. 

#### Jeremiah 20:8 For {bitter word with my I shall laugh}, {rebellion and misery I will call upon}; for {became the word of the LORD} for scorning to me, and for taunting all day. 

#### Jeremiah 20:9 And I said, in no way shall I name the name of the LORD, and in no way shall I speak yet in his name. And it became as {fire a burning}, blazing in my bones; and I am weakened from all sides, and I am not able to bear up. 

#### Jeremiah 20:10 For I heard the fault of many gathering together round about, saying, Rise up together against him! And, We should rise up together against him -- all {men friends his}. Give heed to his thought! if he should be deceived, and we shall prevail against him, then we shall take our vengeance on him. 

#### Jeremiah 20:11 But the LORD is with me as {warrior a strengthening}. On account of this they pursued, but {to comprehend they were not able}. They were shamed exceedingly; for they did not comprehend their dishonor, which through the eon will not be forgotten. 

#### Jeremiah 20:12 O LORD, trying just things, perceiving the kidneys and heart; may I behold the {by you punishment} on them. For to you I uncovered my pleas in defense. 

#### Jeremiah 20:13 Sing to the LORD! Praise him! for he rescued the soul of the needy from out of the hand of the most substantial ones. 

#### Jeremiah 20:14 Cursed is the day in which I was birthed in it, the day in which {gave birth to me my mother}; let it not be longed for! 

#### Jeremiah 20:15 Cursed is the man announcing good news to my father, saying, There was birthed to you a male child, {making merry they are}. 

#### Jeremiah 20:16 {Let be that man} as the cities which the LORD eradicated in rage, and he did not repent! Let him hear the cry in the morning, and the shout at midday! 

#### Jeremiah 20:17 For he did not kill me in the womb of my mother, for {to be to me my mother} my burying-place, and the womb {conception an everlasting}. 

#### Jeremiah 20:18 Why is this that I came forth from out of the womb to see toils and miseries; and {continue in shame my days}? 

#### Jeremiah 21:1 The word coming from the LORD to Jeremiah, when {sent to him king Zedekiah} Pashur son of Melchiah, and Zephaniah son of Maaseiah the priest, saying, 

#### Jeremiah 21:2 You ask {for us the LORD}! for the king of Babylon has set by us; if the LORD will do according to all his wonders, and the king shall go forth from us. 

#### Jeremiah 21:3 And {said to them Jeremiah}, Thus you shall say to Zedekiah, 

#### Jeremiah 21:4 Thus says the LORD, the God of Israel, Behold, I turn back the weapons of warfare which are in your hands, and by which you wage war with them against the Chaldeans, the ones hemming you in who are outside the wall; and I will gather them into the midst of this city. 

#### Jeremiah 21:5 And I shall wage war myself against you with a hand being stretched out, and with {arm a fortified} with rage and {anger great}. 

#### Jeremiah 21:6 And I will strike all the ones dwelling in this city, men and the cattle. By {death a great} even they shall die. 

#### Jeremiah 21:7 And after these things, thus says the LORD, I will deliver up Zedekiah king of Judah, and his servants, and the people, the one surviving in this city from death, and from famine, and from the sword, into the hands of their enemies, of the ones seeking their lives. And they shall cut them in pieces by the mouth of the sword; I will not spare against them, and in no way shall I pity them. 

#### Jeremiah 21:8 And {to this people you shall say}, Thus says the LORD, Behold, I put before your face the way of life, and the way of death. 

#### Jeremiah 21:9 The one being settled in this city shall die by the sword and by famine; and the one going forth to join with the Chaldeans, the ones hemming you in, shall live; and {will be his life} for spoils, he shall live. 

#### Jeremiah 21:10 For I firmly fixed my face against this city for bad, and not for good, says the LORD. Into the hands of the king of Babylon it shall be delivered up, and he shall incinerate it by fire. 

#### Jeremiah 21:11 O house of the king of Judah, hear the word of the LORD! 

#### Jeremiah 21:12 O house of David, Thus says the LORD; Arbitrate {in the morning judgment}, and straighten out, and rescue the one being torn in pieces from the hand of the one wronging him! so that {should not be lit as a fire my anger}, and it should be kindled, and there will not be one extinguishing it. 

#### Jeremiah 21:13 Behold, I am against you, O one dwelling the valley of Sor; the plain country of the ones saying, Who shall terrify us? Or who shall enter to our home? 

#### Jeremiah 21:14 And I will look about upon you, and I will kindle a fire in her forest. And it shall devour all the things round about her. 

#### Jeremiah 22:1 Thus says the LORD, Go, and go down to the house of the king of Judah! And you shall speak there this word. 

#### Jeremiah 22:2 And you shall say, Hear the word of the LORD, O king of Judah, O one sitting down upon the throne of David, you and your servants, and your people, and the ones entering by these gates! 

#### Jeremiah 22:3 Thus says the LORD, Execute equity and righteousness, and rescue the one being plundered from out of the hand of the one wronging him! And the foreigner, and orphan, and widow, do not tyrannize! And do not be impious! And {blood innocent you should not pour out} in this place. 

#### Jeremiah 22:4 For if doing you should do this word, then {shall enter in the gates of this house kings} sitting down upon the throne of David, and mounting upon chariots, and horses, they and their children, and their people. 

#### Jeremiah 22:5 But if you should not do these words, according to myself I swear by an oath, says the LORD, that {for desolation will be this house}. 

#### Jeremiah 22:6 For thus says the LORD against the house of the king of Judah. You are Gilead to me, head of Lebanon. Should I not make you desolate, cities not being dwelt in? 

#### Jeremiah 22:7 And I will bring upon you an annihilating man, and his hewing axe. And they shall cut down {chosen cedars your}, and shall put them into the fire. 

#### Jeremiah 22:8 And {shall go nations many} through this city. And they shall say each to his neighbor, Why did the LORD do thus to {city this great}? 

#### Jeremiah 22:9 And they shall say, Because they abandoned the covenant of the LORD their God, and did obeisance to strange gods, and they served to them. 

#### Jeremiah 22:10 Do not weep for the one having died, nor lament him! Weep! by weeping for the one going forth, for he shall not return again, nor shall he see the land of his fatherland. 

#### Jeremiah 22:11 For thus says the LORD against Shallum, son of Josiah king of Judea, who reigned for Josiah his father, who came forth from out of this place, He shall not return there again. 

#### Jeremiah 22:12 But in the place where I displaced him, there he shall die, and this land he shall not see again. 

#### Jeremiah 22:13 O the one building his house with no righteousness, and his rooms without equity; for to him the neighbor works without pay, and his wage in no way shall he give over to him. 

#### Jeremiah 22:14 You built to yourself a house well-proportioned, with upper rooms ventilated, separated by windows, and being boarded by cedar, and being coated in vermilion. 

#### Jeremiah 22:15 Should you reign, because you are provoked with Ahaz your father? Shall they not eat and shall they not drink? It is best for you to execute equity and {righteousness fair}. 

#### Jeremiah 22:16 They did not know, they did not judge with equity to the humble, nor with equity to the needy. {this not Is} because of {not knowing your} me, says the LORD? 

#### Jeremiah 22:17 Behold, {are not your eyes} nor your heart good, but they are for your desire for wealth, and for the {blood innocent pouring out}, and for offences, and for murder, to do them. 

#### Jeremiah 22:18 On account of this, thus says the LORD against Jehoiakim son of Josiah king of Judah, Woe against this man. In no way should they lament him, saying, O brother. Nor shall they weep over him, saying, Alas, O lord. 

#### Jeremiah 22:19 As the burial of a donkey he shall be buried; being scraped away he shall be tossed beyond the gate of Jerusalem. 

#### Jeremiah 22:20 Ascend unto Lebanon, and cry out! And {unto Bashan give out your voice}, and yell unto the end of the sea! for {were defeated all your lovers}. 

#### Jeremiah 22:21 I spoke to you in your transgression, and you said, I will not hearken. This is your way from your youth, you hearkened not to my voice. 

#### Jeremiah 22:22 All your shepherds shall tend the wind, and your lovers {into captivity shall go forth}; for then you shall be ashamed, and shall be disgraced because of all the ones being fond of you. 

#### Jeremiah 22:23 O one dwelling in Lebanon, nesting among the cedars, you shall groan in the {coming to you griefs}, pangs as one giving birth. 

#### Jeremiah 22:24 As I live, says the LORD, Though in coming to pass {should become Coniah son of Jehoiakim king of Judah} a seal upon {hand my right}, from there will I pull you out. 

#### Jeremiah 22:25 And I will deliver you up into the hands of the ones seeking your life, whom you are cautious from in front of them, even into the hands of Nebuchadnezzar king of Babylon, and into the hands of the Chaldeans. 

#### Jeremiah 22:26 And I will throw you and your mother, the one giving birth to you, into a land of which you were not birthed there; and there you shall die. 

#### Jeremiah 22:27 And unto the land which they made a vow in their souls, there in no way shall they return. 

#### Jeremiah 22:28 Coniah is disgraced as a vessel which there is no need of; for he was cast forth and cast into a land which he did not know. 

#### Jeremiah 22:29 O land, O land, hear the word of the LORD! 

#### Jeremiah 22:30 Thus says the LORD, Write up this man {banished by public proclamation as a man}! For in no way should there be anything grown from out of his seed, a man sitting down upon the throne of David, ruling again in Judah. 

#### Jeremiah 23:1 O the shepherds, the ones scattering and destroying the sheep of my pasture. 

#### Jeremiah 23:2 On account of this, thus says the LORD, the God of Israel, against the shepherds, the ones tending my people; You scattered my sheep, and pushed them out, and did not visit them. Behold, I shall take vengeance upon you, against {wicked practices your}. 

#### Jeremiah 23:3 And I will take in the ones remaining of my people upon all the earth of which place I pushed them there; and I shall place them into their pasture, and they shall grow and be multiplied. 

#### Jeremiah 23:4 And I shall raise up to them shepherds tending them, and they shall not be fearful any more, nor shall they be terrified, nor shall they be seeking after, says the LORD. 

#### Jeremiah 23:5 Behold, days come, says the LORD, and I will raise up to David {dawn a just}; and {shall reign a king}, and shall perceive, and shall execute equity and righteousness upon the earth. 

#### Jeremiah 23:6 In his days Judah shall be delivered, and Israel shall encamp complying. And this is his name, which {shall call him the LORD} -- Josedek. 

#### Jeremiah 23:7 On account of this, behold, days come, says the LORD, and they will not say any longer, As the LORD lives, who led the house of Israel from out of the land of Egypt. 

#### Jeremiah 23:8 But as the LORD lives, who led up and gathered all together the seed of Israel from the land of the north, and from all the places of which they were pushed there; and he restored them unto their land. 

#### Jeremiah 23:9 In the prophets {was broken my heart}; in me {were shaken all my bones}; I became as a man being broken, and as a man constrained by wine, from the countenance of the LORD, and from the countenance of the beauty of his glory. 

#### Jeremiah 23:10 For {of adulterers is full the land}. For from the countenance of these things {mourned the land}; {were dried up the pastures of the wilderness}; and {became their race} wicked, and their strength not thus. 

#### Jeremiah 23:11 For priest and prophet were tainted; and in my house I saw their wickedness, says the LORD. 

#### Jeremiah 23:12 On account of this let {become their way} to them for a slip in dimness! And they shall be tripped up and shall fall in it. Because I shall bring upon them bad things in the year of their visitation, says the LORD. 

#### Jeremiah 23:13 And among the prophets of Samaria I beheld violations of the laws; they prophesied by Baal, and they misled my people Israel. 

#### Jeremiah 23:14 And among the prophets of Jerusalem I have seen causes for shuddering -- committing adultery and going by lies, and taking hold of hands of wicked ones {to not be turned for each} from {way his wicked}. They {became to me all} as Sodom, and the ones dwelling in it as Gomorrah. 

#### Jeremiah 23:15 On account of this, thus says the LORD of the forces to the prophets; Behold, I will feed them grief, and I shall give them to drink {water bitter}; for from the prophets of Jerusalem {came forth contamination} to all the land. 

#### Jeremiah 23:16 Thus says the LORD the almighty, Do not hearken to the words of the prophets! of the ones prophesying to you. For they frame in folly {for themselves a vision}. From their heart they speak, and not from the mouth of the LORD. 

#### Jeremiah 23:17 They say to the ones thrusting away the word of the LORD, Peace will be to you; and to all the ones going by their wants, and to all going in a delusion of his heart, {shall not come upon you Evils}. 

#### Jeremiah 23:18 For who stood in the garrison of the LORD, and beheld and heard his word? Who gave ear and heard? 

#### Jeremiah 23:19 Behold, a quaking by the LORD, and anger shall go forth in a rumbling. {contracting upon the impious It shall come}. 

#### Jeremiah 23:20 And {shall not turn away the rage of the LORD} until whenever he should execute it, and until whenever he should establish it according to the enterprise of his heart. At the latter end of the days they shall comprehend them. 

#### Jeremiah 23:21 I did not send the false prophets, yet they ran. I did not speak to them, and they prophesied. 

#### Jeremiah 23:22 And if they stood with my support, and they hearkened to my words, then my people would have turned from {wicked practices their}. 

#### Jeremiah 23:23 {a God being near I am}, says the LORD, and not a God at a distance. 

#### Jeremiah 23:24 Shall any be hid in secret, and I not see him, says the LORD, no. Is it not that {the heaven and the earth I shall fill}, says the LORD? 

#### Jeremiah 23:25 I heard what {speak the prophets} who prophesy {by my name lies}, saying, I dreamed a dream. 

#### Jeremiah 23:26 For how long shall it be in the heart of the prophets prophesying lies, and in their prophesying the wants of their heart? 

#### Jeremiah 23:27 The ones devising ways to forget my name by their dreams, which {was described each} to his neighbor; as {forgot their fathers} my name in service to Baal. 

#### Jeremiah 23:28 The prophet by which the dream is, let him describe his dream! and the one by which my word is truly with him, let him describe my word in truth! What is the straw to the grain? Thus are my words, says the LORD. 

#### Jeremiah 23:29 Are not my words as fire blazing, says the LORD? and as a hewing axe beating the rock? 

#### Jeremiah 23:30 Behold, I am against the prophets, says the LORD God, the ones stealing my words each from his neighbor. 

#### Jeremiah 23:31 Behold, I am against the prophets, says the LORD, the ones casting out prophecies of the tongue, and slumbering of their own slumber. 

#### Jeremiah 23:32 Behold, I am against the prophets prophesying {dreams false}, and of whom described them, and misled my people by their lies, and in their delusions; and I {not sent them}, and I did not give charge to them, and {a benefit not they derived} for this people, says the LORD. 

#### Jeremiah 23:33 And if {should ask you this people}, or priest, or prophet, saying, What is the concern of the LORD? then you shall say to them, You are the concern, and I will dash you down, says the LORD, 

#### Jeremiah 23:34 and the prophet, and the priest, and the people, the ones who should say, The concern of the LORD; even I will punish that man, and his house. 

#### Jeremiah 23:35 Thus you shall say each to his neighbor, and each to his brother, What did the LORD answer? And what did the LORD speak? 

#### Jeremiah 23:36 And the concern of the LORD name not again! for the concern to the man will be his word. And you distorted the words of the living God. 

#### Jeremiah 23:37 Thus you shall say to the prophet, What spoke the LORD our God? 

#### Jeremiah 23:38 On account of this, thus says the LORD, Because you said this word, The concern of the LORD, that I sent to you, saying, You shall not say, The concern of the LORD. 

#### Jeremiah 23:39 On account of this, behold, I will take and dash you down, and the city which I have given to you and to your fathers. 

#### Jeremiah 23:40 And I shall put upon you {scorn eternal} and {dishonor eternal}, which shall not be forgotten. 

#### Jeremiah 24:1 {showed to me The LORD} two reed baskets of figs, being situated in front of the temple of the LORD, after {resettled Nebuchadnezzar king of Babylon} Jeconiah the son of Jehoiakim, king of Judah, and the rulers, and the craftsmen, and the bondmen, from out of Jerusalem, and led them into Babylon. 

#### Jeremiah 24:2 The {reed basket one} was of {figs better exceedingly} as the {figs early}; and the {reed basket other} was of {figs bad exceedingly} which shall not be eaten because of their badness. 

#### Jeremiah 24:3 And the LORD said to me, What do you see, Jeremiah? And I said, Figs, the {figs better better are exceedingly}, and the bad ones {bad exceedingly} which cannot be eaten because of their badness. 

#### Jeremiah 24:4 And came to pass the word of the LORD to me saying, 

#### Jeremiah 24:5 Thus says the LORD God of Israel, As {figs these better}, so shall I recognize the Jews being resettled whom I have sent out of this place into the land of the Chaldeans for good. 

#### Jeremiah 24:6 And I shall firmly fix my eyes upon them for good, and I shall restore them into this land. And I will rebuild them, and in no way demolish; and I will plant them, and in no way will I pluck them up. 

#### Jeremiah 24:7 And I will give them a heart for them to know me, that I am the LORD. And they will be to me for a people, and I will be to them for God. For they shall turn towards me with {entire heart their}. 

#### Jeremiah 24:8 And as the {figs bad} which shall not be eaten because of their badness, thus says the LORD, So will I deliver up Zedekiah king of Judah, and his great men, and the rest of Jerusalem being left behind in this land, and the ones dwelling in Egypt. 

#### Jeremiah 24:9 And I will appoint them for being dispersed into all the kingdoms of the earth, and they will be for scorning, and for a parable, and for hatred, and for a curse in every place where I shall push them there. 

#### Jeremiah 24:10 And I will send against them the famine, and the plague, and the sword, until whenever they should fail from the land which I gave to them, and to their fathers. 

#### Jeremiah 25:1 The word coming to Jeremiah concerning all the people of Judah, in the {year fourth} of Jehoiakim son of Josiah king of Judah; it was {year the first} to Nebuchadnezzar king of Babylon; 

#### Jeremiah 25:2 which {spoke Jeremiah the prophet} to all the people of Judah, and to the ones dwelling in Jerusalem, saying, 

#### Jeremiah 25:3 In the thirteenth year of Josiah, son of Amon, king of Judah, and until this day for twenty and three years, that {came the word of the LORD} to me, and I spoke to you rising early and speaking, and you listened not. 

#### Jeremiah 25:4 And I sent to you my servants the prophets, {them at dawn sending} (and you did not listen, and you did not take heed with your ears), 

#### Jeremiah 25:5 saying, Turn indeed each from {way his wicked}, and from {wicked practices your}! and you shall dwell upon the land which I gave to you and to your fathers from the eon and unto the eon. 

#### Jeremiah 25:6 Go not after strange gods to serve them! and to do obeisance to them, so that you should not provoke me to anger by the works of your hands so as for me to afflict you. 

#### Jeremiah 25:7 And you hearkened not to me. 

#### Jeremiah 25:8 On account of this, thus says the LORD, Since you trusted not my words, 

#### Jeremiah 25:9 behold, I send and I shall take the family of the north, and I will lead them upon this land, and against the ones dwelling it, and against all the nations round about it. And I will make them quite desolate. And I will appoint them for extinction, and for hissing, and for {scorn everlasting}. 

#### Jeremiah 25:10 And I will destroy from them the voice of joy, and the voice of gladness, the voice of the groom, and the voice of the bride, the scent of perfumed liquid, and the light of a lamp. 

#### Jeremiah 25:11 And {will be all the land} for extinction, and {shall serve these nations} to the king of Babylon seventy years. 

#### Jeremiah 25:12 And in the fulfilling the seventy years, I will take vengeance upon the king of Babylon, and upon that nation of their unrighteousness, says the LORD, and upon the land of the Caldeans. And I will appoint them for {extinction everlasting}. 

#### Jeremiah 25:13 And I will bring upon that land all my words which I spoke against it, all the things being written in this scroll; 

#### Jeremiah 25:14 as many things as Jeremiah prophesied against all the nations, for they laid service against them when they were {nations many} and {kings great}. And I will recompense to them according to their works, according to the actions of their hands. 

#### Jeremiah 25:15 Thus said the LORD God of Israel, Take the cup {wine of this undiluted} from out of my hand! and you shall give to drink all the nations to whom I send you unto them. 

#### Jeremiah 25:16 And they shall drink, and vomit forth, and shall be driven mad from in front of the sword of which I shall send in the midst of them. 

#### Jeremiah 25:17 And I took the cup from out of the hand of the LORD, and I gave to drink all the nations to whom {sent me the LORD} unto them; 

#### Jeremiah 25:18 Jerusalem, and the cities of Judah, and the king of Judah, and his rulers -- to appoint them for desolation, and for an untrodden land, and for a hissing, and for a curse as this day; 

#### Jeremiah 25:19 even Pharaoh king of Egypt, and his children, and his great men, and all his people, 

#### Jeremiah 25:20 and all his consolidations, and all the kings of the land of Uz, and all the kings of the Philistines, and Ashkelon, and Gaza, and Ekron, and the remaining of Ashdod, 

#### Jeremiah 25:21 and Edom, and Moab, and the sons of Ammon, 

#### Jeremiah 25:22 and all the kings of Tyre, and the kings of Sidon, and the kings of the ones on the other side of the sea, 

#### Jeremiah 25:23 and Dedan and Tema, and Buz, and all being shaven around his face, 

#### Jeremiah 25:24 and all the kings of Arabia, and all the consolidations of the ones resting up in the wilderness, 

#### Jeremiah 25:25 and all the kings of Zimri, and all the kings of Elam, and all the kings of the Medes, 

#### Jeremiah 25:26 and all the kings from the east wind, the ones at a distance, and of the ones near, each with his brother, and all the kingdoms, the ones upon the face of the earth; and the king of Sheshach shall drink with them. 

#### Jeremiah 25:27 And you shall say to them, thus said the LORD almighty, Drink, be intoxicated, and vomit forth, and fall, and in no way rise up from in front of the sword! of which I send in the midst of you. 

#### Jeremiah 25:28 And it will be whenever they should not want to take the cup from out of your hand so as to drink, then you shall say, Thus said the LORD of the forces, By drinking you shall drink. 

#### Jeremiah 25:29 For in the city upon which {is named my name} by it, I begin to afflict. And you by cleansing in no way shall be cleansed, for {a sword I shall call} upon all the ones settling down upon the earth, says the LORD of the forces. 

#### Jeremiah 25:30 And you shall prophesy against them all these words, and shall say, The LORD from on high shall execute from {place his holy} he shall give his voice; {a word he will execute} against his place; and thus as ones gathering vintage shall be answered, and against the ones settling upon the earth shall come ruin, 

#### Jeremiah 25:31 upon a part of the earth. For judgment is by the LORD among the nations; he himself pleads to all flesh; but the impious shall be given to the sword, says the LORD. 

#### Jeremiah 25:32 Thus said the LORD of the forces, Behold, evils come from nation upon nation, and {tempest a great} goes forth from end of the earth. 

#### Jeremiah 25:33 And there will be slain by the LORD in that day from a part of the earth, even unto into a part of the earth; in no way shall they be lamented, and in no way shall they be gathered, and in no way shall they be buried, for {dung upon the face of the earth they will be}. 

#### Jeremiah 25:34 Shout, O shepherds, and cry out! And beat the chest, O rams of the flocks! For {were filled your days} for slaughter, and you shall fall as the {rams choice}. 

#### Jeremiah 25:35 And {shall perish flight} from the shepherds, and safety shall flee from the rams of the flocks. 

#### Jeremiah 25:36 A sound of a cry of the shepherds, and a shout of the rams, for the LORD annihilated their pastures. 

#### Jeremiah 25:37 And {shall cease the rest places of peace} from the face of the anger of the rage of the LORD. 

#### Jeremiah 25:38 He abandoned {as a lion his lodging}, for {became their land} an untrodden place from in front of the {sword great}. 

#### Jeremiah 26:1 In the beginning of the reign of king Jehoiakim son of Josiah came this word from the LORD. 

#### Jeremiah 26:2 Thus said the LORD, Stand in the courtyard of the house of the LORD! and you shall execute an order to all Judah, to the ones coming to do obeisance in the house of the LORD, all the words which I ordered to you to execute to them; you should not remove a thing. 

#### Jeremiah 26:3 Perhaps they shall hear, and shall be turned each from {way his evil}, and I will cease from the bad things which I devise to do to them because of {evil practices their}. 

#### Jeremiah 26:4 And you shall say, Thus said the LORD, If you should not hearken to me to go by my laws which I put before your face, 

#### Jeremiah 26:5 to listen to the words of my servants the prophets whom I sent to you at dawn, (for I sent, and you hearkened not to me;) 

#### Jeremiah 26:6 then I will appoint this house as Shiloh, and this city I will appoint for a curse to all the nations of the earth. 

#### Jeremiah 26:7 And they heard (the priests, and the false prophets, and all the people) Jeremiah speaking these words in the house of the LORD. 

#### Jeremiah 26:8 And it came to pass of Jeremiah ceasing speaking all which the LORD ordered to him to say to all the people, that they seized him -- the priests, and the false prophets, and all the people, saying, To death he shall die, 

#### Jeremiah 26:9 for you prophesied in the name of the LORD, saying, {as Shiloh will be This house}, and this city shall be made desolate of ones dwelling it. And {held an assembly all the people} against Jeremiah in the house of the LORD. 

#### Jeremiah 26:10 And {heard the rulers of Judah} these words, and they ascended from the house of the king unto the house of the LORD; and they sat in the thresholds {gate of the LORD of the new}. 

#### Jeremiah 26:11 And {said the priests and the false prophets} to the rulers, and to all the people, The judgment of death belongs to this man, for he prophesied against this city, as you heard with your ears. 

#### Jeremiah 26:12 And Jeremiah said to all the rulers, and to all the people, saying, The LORD sent me to prophesy against this house and against this city all the words which you heard. 

#### Jeremiah 26:13 And now, {better you make your ways}, and your works, and hearken to the voice of the LORD your God! and the LORD will cease from the evils which he spoke against you. 

#### Jeremiah 26:14 And behold, I am in your hands; do to me as is advantageous to you, and as best for you! 

#### Jeremiah 26:15 But only in knowing know! that if you do away with me, {blood innocent you have imputed} against you, and against this city, and against the ones dwelling in it. For in truth {has sent me the LORD} to you to speak into your ears all these words. 

#### Jeremiah 26:16 And {said the rulers and all the people} to the priests and to the false prophets; There is not due to this man a judgment of death, for upon the name of the LORD our God he spoke to us. 

#### Jeremiah 26:17 And there rose up men of the elders of the land, and they said to all the gathering of people, saying, 

#### Jeremiah 26:18 Micah the Morasthite was a prophet in the days of Hezekiah king of Judah, and he spoke to all the people of Judah, saying, Thus said the LORD of the forces; Zion {as a field shall be plowed}, and Jerusalem {for a storehouse of fruits will be}, and the mountain of the house shall be turned into a sacred grove. 

#### Jeremiah 26:19 Did, by doing away, {do away with him Hezekiah king of Judah and all Judah}? Was it not they feared the LORD, and they beseeched in front of the LORD, and the LORD ceased from the evils which he spoke against them? And we did {evils great} against our souls. 

#### Jeremiah 26:20 And there was another man prophesying in the name of the LORD, Urijah son of Shemaiah from Kirjath-jearim; and he prophesied concerning this city, and concerning this land according to all the words of Jeremiah. 

#### Jeremiah 26:21 And {heard king Jehoiakim and all the rulers} all his words, and sought to kill him. And Urijah heard and feared and fled and entered into Egypt. 

#### Jeremiah 26:22 And {sent the king} men into Egypt, Elnathan son of Achbor, and men with him into Egypt. 

#### Jeremiah 26:23 And they led him from there, and brought him to the king; and he struck him by the sword, and tossed him into the tomb of the sons of his people. 

#### Jeremiah 26:24 Only the hand of Ahikam son of Shaphan was with Jeremiah, so as to not deliver him into the hands of the people so as to not do away with him. 

#### Jeremiah 27:1 In the beginning of the kingdom of Jehoiakim son of Josiah king of Judah came to pass this word to Jeremiah from the LORD, saying, 

#### Jeremiah 27:2 Thus said the LORD, Make to yourself bonds and collars, and put them around your neck! 

#### Jeremiah 27:3 And you shall send them to the king of Edom, and to the king of Moab, and to the king of the sons of Ammon, and to the king of Tyre, and to the king of Sidon, by the hands of their messengers, of the ones coming in Jerusalem to Zedekiah king of Judah. 

#### Jeremiah 27:4 And you shall order them {to their lords to say}, Thus said the LORD of the forces, the God of Israel; Thus you shall say to your lords, 

#### Jeremiah 27:5 I made the earth, and the men, and the cattle, the ones upon the face of the earth, by {strength my great} and by {arm my high}, and I shall give it to whom ever it seems fit in my eyes. 

#### Jeremiah 27:6 And now I gave all the earth to Nebuchadnezzar king of Babylon to serve to him, and the wild beasts of the field to work for him. 

#### Jeremiah 27:7 And to his son, and to the son of his son, unto the coming time of his land, and also of him. And {shall serve to him nations many}, and {kings great}. 

#### Jeremiah 27:8 And the nation, and the kingdom, as many as should not serve Nebuchadnezzar king of Babylon, and as many as should not put their neck under the yoke of the king of Babylon, by the sword, and by pestilence, and by famine I shall visit them, said the LORD, until they should falter by his hand. 

#### Jeremiah 27:9 And you, hearken not to your false prophets! and of the ones using oracles for you, and of the ones dreaming to you, and of the ones of your omens, and of the ones of your administers of potions, saying, In no way should you work for the king of Babylon. 

#### Jeremiah 27:10 For {a lie they prophesy} to you, to distance you from your land, and that I should cast you out, and you shall perish. 

#### Jeremiah 27:11 And the nation which ever should bring its neck under the yoke of the king of Babylon, and should work for him, I will leave it upon its land, says the LORD, and it shall work her, and it will dwell in her. 

#### Jeremiah 27:12 And to Zedekiah king of Judah I spoke according to all these words, saying, Bring your neck under the yoke of the king of Babylon, 

#### Jeremiah 27:13 and work for him and for his people! and you shall live. Why should you die and your people by sword, and by famine, and by pestilence, as the LORD spoke against nations, which served not to the king of Babylon? 

#### Jeremiah 27:14 You should not hearken to the words of the prophets saying to you, You should not serve to the king of Babylon; for unjustly they prophesy to you. 

#### Jeremiah 27:15 I did not send them, says the LORD, and they prophesy in my name unjustly for the destroying you. And you shall perish, and your prophets, the ones prophesying to you by an unjust lie. 

#### Jeremiah 27:16 And to the priests and to all this people I spoke, saying, Thus said the LORD, Do not hearken to the words of the prophets prophesying to you! saying, Behold, the items of the house of the LORD shall return from out of Babylon now quickly. For {unjustly they prophesy} to you. 

#### Jeremiah 27:17 Do not hearken to them, but you serve to the king of Babylon! and you should live. Why shall it be to her, to the city for desolation? 

#### Jeremiah 27:18 If they are prophets, and if {is the word of the LORD} in them, let them meet me, that they should not carry in the vessels, the ones being left behind in the house of the LORD, and in the house of the king of Judah, and in Jerusalem, into Babylon. 

#### Jeremiah 27:19 For thus said the LORD concerning the pillars, and concerning the sea, and concerning the bases, and for the remaining items, the ones being left behind in this city, 

#### Jeremiah 27:20 which {did not take the king of Babylon} when he resettled Jeconiah son of Jehoiakim king of Judah from out of Jerusalem to Babylon, and all the rulers of Judah and Jerusalem. 

#### Jeremiah 27:21 For thus says the LORD of the forces, the God of Israel, concerning the vessels being left behind in the house of the LORD, and in the house of the king of Judah, and Jerusalem. 

#### Jeremiah 27:22 {into Babylon They shall enter}, and there they shall be until the day of their visitation, and I will lead them and I will return them into this place. 

#### Jeremiah 28:1 And it came to pass in the fourth year of the reigning of Zedekiah king of Judah, in {month the fifth}, {said to me Hananiah} (son of Azur the false prophet, the one from Gibeon) in the house of the LORD in front of the eyes of the priests and all the people, saying, 

#### Jeremiah 28:2 Thus said the LORD of the forces, the God of Israel, I broke the yoke of the king of Babylon. 

#### Jeremiah 28:3 Yet in two years of days I will return unto this place all the items of the house of the LORD, 

#### Jeremiah 28:4 and Jeconiah, and the resettlement of Judah; for I shall break the yoke of the king of Babylon. 

#### Jeremiah 28:5 And {said Jeremiah the prophet} to Hananiah before the eyes of the priests, and before the eyes of all of the people standing in the house of the LORD; 

#### Jeremiah 28:6 and Jeremiah said, Truly, thus may the LORD do, the LORD establish your word which you prophesy to return the items of the house of the LORD, and all the resettlement from out of Babylon to this place. 

#### Jeremiah 28:7 Only hear this word which I say into your ears, and into the ears of all the people. 

#### Jeremiah 28:8 The prophets, the ones being prior to me, and prior to you from the eon, and prophesied against {land much}, and over {kingdoms great} concerning war, and concerning affliction, and concerning pestilence. 

#### Jeremiah 28:9 The prophet prophesying for peace, in the coming to pass of the word, they shall know the prophet whom {sent to them the LORD} in trust. 

#### Jeremiah 28:10 And Hananiah took the collars from the neck of Jeremiah, and he broke them. 

#### Jeremiah 28:11 And Hananiah said before the eyes of all the people, saying, Thus said the LORD, Thus I will break the yoke of the king of Babylon in two years of days from the necks of all the nations. And Jeremiah set out unto his way. 

#### Jeremiah 28:12 And came to pass the word of the LORD to Jeremiah after Hananiah broke the collars from his neck, saying, 

#### Jeremiah 28:13 Proceed and say to Hananiah! saying, Thus said the LORD, {collars wooden you broke}, but I will make instead of these collars of iron. 

#### Jeremiah 28:14 For thus said the LORD of the forces, the God of Israel, A yoke of iron I have put upon the neck of all the nations to work for the king of Babylon, to serve to him. And indeed the cattle of the land I gave to him. 

#### Jeremiah 28:15 And Jeremiah said to Hananiah, Hear, O Hananiah! {has not sent you The LORD}, and you {to rely made this people} upon wrongdoing. 

#### Jeremiah 28:16 On account of this, Thus said the LORD, Behold, I send you out from the face of the land. In this year you shall die, for {against the LORD you spoke}. 

#### Jeremiah 28:17 And he died in the {month seventh}. 

#### Jeremiah 29:1 And these are the words of the book which {sent Jeremiah the prophet} from Jerusalem to the elders of the resettlement, and to the priests, and to the false prophets, and to all the people whom Nebuchadnezzar resettled from Jerusalem unto Babylon, 

#### Jeremiah 29:2 (after the coming forth of Jeconiah the king, and the queen, and the eunuchs, and every free man, and bondman, and craftsman from out of Jerusalem;) 

#### Jeremiah 29:3 by the hand of Elasah son of Shaphan, and Gemariah son of Hilkiah, whom {sent Zedekiah king of Judah} to the king of Babylon into Babylon, saying, 

#### Jeremiah 29:4 Thus said the LORD of the forces, the God of Israel, unto the resettlement which he resettled from Jerusalem to Babylon; 

#### Jeremiah 29:5 Build houses, and dwell, and plant gardens, and eat of their fruits! 

#### Jeremiah 29:6 And take wives, and produce children, sons and daughters! And take for your sons wives, and for your daughters give husbands! and they shall bear sons and daughters, and they shall be multiplied, and shall not be diminished. 

#### Jeremiah 29:7 And seek for peace of the land into which I resettled you there! And pray for them to the LORD! for in their peace there will be peace to you. 

#### Jeremiah 29:8 For thus said the LORD of the forces, the God of Israel, Let not dissuade you the false prophets among you! And let not dissuade you your clairvoyants! And hearken not to your dreams which you dream! 

#### Jeremiah 29:9 For by wrongdoing they prophesy to you in my name, and {not I sent them}, says the LORD. 

#### Jeremiah 29:10 For thus said the LORD, Whenever {is about to be filled in Babylon seventy years}, I will visit you, and I will set my words upon you, to return your people unto this place. 

#### Jeremiah 29:11 And I will devise for you a device of peace, and not evils, to give to you these things. 

#### Jeremiah 29:12 And pray to me! and I will hearken to you. 

#### Jeremiah 29:13 And seek after me! and you shall find me. For whenever you should seek after me with {entire heart your}, 

#### Jeremiah 29:14 then I shall appear unto you. 

#### Jeremiah 29:15 For you said, {placed to us The LORD prophets} in Babylon. 

#### Jeremiah 29:16 Thus says the LORD to the king, the one sitting upon the throne of David, and to all the people, the one dwelling in this city, to your brethren, the ones not going forth with you into captivity. 

#### Jeremiah 29:17 Thus says the LORD of the forces, Behold, I shall send to them a sword, and famine, and pestilence. And I shall establish them as {fig a bad} which one shall not {to eat be able} because of the badness. 

#### Jeremiah 29:18 And I shall pursue them with a sword, and famine, and pestilence. And I shall give them for movement in all the kingdoms of the earth, and for a curse, and for perplexity, and for a hissing, and for scorning to all the nations to whom I cast them. 

#### Jeremiah 29:19 For they hearkened not to my words, says the LORD, which I sent to them through my servants the prophets, rising early and sending; and they hearkened not, says the LORD. 

#### Jeremiah 29:20 You then hearken to the words of the LORD! even all the displacement which I sent from Jerusalem into Babylon. 

#### Jeremiah 29:21 Thus said the LORD against Ahab son of Kolaiah, and against Zedekiah son of Maaseiah, the ones prophesying to you {in my name lies}. Behold, I give them into the hands of the king of Babylon. And he shall strike them before your eyes. 

#### Jeremiah 29:22 And they shall take from them a curse in all the resettlement of Judah in Babylon, saying, Let {do to you the LORD} as {to Zedekiah he did}, and as Ahab! whom {fried the king of Babylon} in fire. 

#### Jeremiah 29:23 Because of {which they did the lawlessness} in Jerusalem, and they committed adultery with the women of their fellow-countrymen, and {a word they executed} by my name which I did not order to them; and I am witness, says the LORD. 

#### Jeremiah 29:24 And to Shemaiah the Nehelamite you shall say, 

#### Jeremiah 29:25 I did not send you in my name. And to Zephaniah son of Maaseiah the priest he said, 

#### Jeremiah 29:26 The LORD appointed you priest instead of Jehoiada the priest, to become supervisor in the house of the LORD to every man prophesying, and to every man being maniacal, and you shall put him in the prison, and in the dungeon. 

#### Jeremiah 29:27 And now, why did you not join in reviling Jeremiah, the one from Anathoth, the one prophesying to you? 

#### Jeremiah 29:28 For on account of this, he sent to us in Babylon, saying, Freedom is far off -- build houses, and inhabit them, and plant gardens, and eat their fruit! 

#### Jeremiah 29:29 And Zephaniah read the scroll into the ears of Jeremiah the prophet. 

#### Jeremiah 29:30 And came to pass the word of the LORD to Jeremiah, saying, 

#### Jeremiah 29:31 Send to all the resettlement, saying, Thus said the LORD against Shemaiah the Nehelamite, Since {prophesied to you Shemaiah}, and I did not send him, and {rely he made you} upon wrongdoing; 

#### Jeremiah 29:32 on account of this, thus said the LORD, Behold, I shall visit against Shemaiah, and against his kind; and there will not be to him a man in the midst of you to behold the good things which I shall do to you, says the LORD; for {defection he spoke} against the LORD. 

#### Jeremiah 30:1 The word coming to Jeremiah from the LORD, saying, 

#### Jeremiah 30:2 Thus said the LORD God of Israel, saying, Write all the words which I executed to you upon a scroll! 

#### Jeremiah 30:3 For behold, days come, says the LORD, and I will return the resettlement of my people Israel and Judah, said the LORD. And I will return them into the land which I gave to their fathers, and they will dominate it. 

#### Jeremiah 30:4 And these are the words which the LORD spoke unto Israel and Judah. 

#### Jeremiah 30:5 Thus said the LORD, The sound of fear you shall hear -- fear, and there is no peace. 

#### Jeremiah 30:6 Ask and see if {gave birth a man}! for I have seen every man, and his hands are upon his loin, as her giving birth; and {are turned their faces} to jaundice. 

#### Jeremiah 30:7 Woe, for great is that day, and there is not such, and {a time of severity it is} to Jacob, but from this he shall be delivered. 

#### Jeremiah 30:8 In that day, said the LORD of the forces, I will break the yoke from their neck, and their bonds I will tear up, and they shall not work themselves any longer for strangers. 

#### Jeremiah 30:9 And they shall work to the LORD their God; and {David their king I will raise up} to them. 

#### Jeremiah 30:10 But you, do not fear! O my servant Jacob, says the LORD. And in no way should you be terrified, O Israel. For behold, I shall deliver you from a land far off, and your seed from a land of their captivity. And Jacob shall be returned, and he shall rest, and he shall abound in all the good things, and there shall not be one fearing. 

#### Jeremiah 30:11 For {with you I am}, says the LORD, to deliver you. For I shall appoint a consumation in all the nations in which I scattered you, but you in no way will I appoint for consumation. But I shall correct you with equity and cleansing of which I shall cleanse you. 

#### Jeremiah 30:12 Thus said the LORD, I raised up destruction; {is painful your calamity}; 

#### Jeremiah 30:13 there is not one judging your case; {for a painful state you were treated medically}; {benefit to you there is no}; 

#### Jeremiah 30:14 all your friends forgot you; in no way shall they ask, for {with a beating by the enemy I smote you}, {discipline even substantial}; {over all your iniquities multiplied your sins}. 

#### Jeremiah 30:15 Why yell over your destruction? {is incurable Your misery}. On account of the magnitude of your iniquity, and on account of {sins your recalcitrant} I did to you these things. 

#### Jeremiah 30:16 On account of this all the ones devouring you shall be eaten, and all your enemies {into captivity shall come}. And {will be the ones dispersing you} for dispersion, and all the ones having despoiled you I shall give for plunder. 

#### Jeremiah 30:17 For I will lead up your cure, {from wound a grievous I will treat you}; says the LORD, for {Her Having Been Sown you are called}; Zion, for {seeking no there is} her. 

#### Jeremiah 30:18 Thus said the LORD; Behold, I shall return the resettlement of Jacob, and his captivity I will show mercy, and {shall be built the city} upon her height, and the people {according to his equity shall sit}. 

#### Jeremiah 30:19 And there shall come forth from them ones singing, and a sound of ones playing. And I shall make them superabundant, and in no way shall they be made less. 

#### Jeremiah 30:20 And {shall enter his sons} as formerly, and their testimonies are in front of me straight up. And I shall visit upon all the ones afflicting them. 

#### Jeremiah 30:21 And {will be his stronger ones} over them, and his ruler {from him shall come forth}. And I will bring them together, and they shall return to me. For who is this who gave his heart to return to me, says the LORD? 

#### Jeremiah 30:22 And you shall be to me for a people, and I shall be to you for Lord. 

#### Jeremiah 30:23 For the anger of the LORD went forth; rage went forth; {anger turning upon the impious shall come}. 

#### Jeremiah 30:24 In no way shall {turn the anger of the rage of the LORD} until he should execute, and until he should ordain the enterprise of his heart. Upon the last of the days you shall know them. 

#### Jeremiah 31:1 In that time, said the LORD, I will be for a God to the race of Israel, and they will be to me for a people. 

#### Jeremiah 31:2 Thus said the LORD, They found it hot in the wilderness with ones being destroyed by sword. Proceed! and you should not destroy Israel. 

#### Jeremiah 31:3 The LORD {at a distance shall be seen} by him, saying, {affection With an everlasting} I loved you; on account of this I drew you for pitying. 

#### Jeremiah 31:4 For I will build you, and you shall be built, O virgin Israel. You shall still take your tambourine, and go forth with a congregation playing. 

#### Jeremiah 31:5 For you planted vineyards on the mountains of Samaria. In planting plant! and in praising praise! 

#### Jeremiah 31:6 For it is the day of calling, of ones pleading on the mountains of Ephraim, saying, Rise up, and ascend in Zion to the LORD your God! 

#### Jeremiah 31:7 For thus said the LORD to Jacob, Be glad and snort over the head of nations! {audibly Do it}, and praise! Say! The LORD delivered his people, the remnant of Israel. 

#### Jeremiah 31:8 Behold, I lead them from the north, and I will gather them from the ends of the earth, in a holiday passover. And you shall produce children, {multitude a great}, and they shall return here. 

#### Jeremiah 31:9 In weeping they went forth, and in comfort I will lead them. Lodging upon aqueducts of waters in {way the straight}, and in no way shall they wander in it. For I became to Israel for a father, and Ephraim {my first-born is}. 

#### Jeremiah 31:10 Hear the words of the LORD, O nations, and announce unto islands far off! Say! The one winnowing Israel will gather him, and he shall guard him as the one grazing his flock. 

#### Jeremiah 31:11 For the LORD ransomed Jacob and rescued him from out of the hand of ones more substantial than he. 

#### Jeremiah 31:12 And they shall come and shall be glad in mount Zion. And they shall come upon the good things of the LORD, upon a land of grain, and wine, and olive oil, and fruits, and cattle, and sheep. And {shall be their soul} as the tree containing fruit. And they shall not hunger any longer. 

#### Jeremiah 31:13 Then {shall rejoice virgins} in a gathering of young men; and old men shall rejoice. And I will turn their mourning into joyfulness, and I will comfort them, and I will make them ones being glad. 

#### Jeremiah 31:14 I will magnify and intoxicate the soul of the priests, sons of Levi. And my people {of my good things shall be filled up}. Thus said the LORD. 

#### Jeremiah 31:15 A voice in Rama was heard -- wailing, and weeping, and grieving; Rachel weeping for her sons; and she did not want to be comforted, for they are not. 

#### Jeremiah 31:16 Thus said the LORD, Stop your voice from weeping, and your eyes from tears, for there is a wage for your works, says the LORD, and they shall return from out of the land of the enemies; 

#### Jeremiah 31:17 And there shall be hope to the last of you, says the LORD. And {shall return the sons} to their borders. 

#### Jeremiah 31:18 In hearing I heard Ephraim grieving, saying, You corrected me, and I was corrected. I, as a calf, was not taught. Turn me! and I will turn. For you are the LORD my God. 

#### Jeremiah 31:19 For after my captivity, I changed my mind; and after my knowing, I moaned over the day of shame. And I showed you plainly that I took scorning of my youth. 

#### Jeremiah 31:20 {son a beloved Ephraim is} to me, a child for reveling in, for because my words are in him; in remembering I will remember him; on account of this I hastened unto him; by showing mercy I shall show mercy on him, says the LORD. 

#### Jeremiah 31:21 Establish to yourself overseers! Execute punishment! Give your heart to your shoulders in the way in which you were going! Return, O virgin Israel! Return unto your cities mourning! 

#### Jeremiah 31:22 Until when shall you return, O daughter being disgraced? For the LORD created safety for {planting a new}; in your safety {shall go about men}. 

#### Jeremiah 31:23 Thus said the LORD of the forces, the God of Israel, Still they shall say this word in the land of Judah, and in his cities, whenever I shall return his resettlement; Being blessed is the LORD upon {just mountain his holy}; 

#### Jeremiah 31:24 even the ones dwelling in the cities of Judah, and in all his land together with the farmer, and he shall be lifted with the flock. 

#### Jeremiah 31:25 For I intoxicated the soul thirsting; and every soul hungering I filled up. 

#### Jeremiah 31:26 On account of this I awoke, and beheld; and my sleep {agreeable to me was}. 

#### Jeremiah 31:27 Behold, days come, says the LORD, and I shall sow Israel and Judah with the seed of man, and the seed of beast. 

#### Jeremiah 31:28 And it will be as I was vigilant over them even to demolish and to inflict evil, so I will be vigilant over them to build and to plant, says the LORD. 

#### Jeremiah 31:29 In those days in no way shall they say, The fathers ate an unripe grape, and teeth of the children had tooth-chills. 

#### Jeremiah 31:30 But each in his own sin shall die. And the one eating the unripe grape, {shall have tooth-chills their teeth}. 

#### Jeremiah 31:31 Behold, days come, says the LORD, and I shall ordain to the house of Israel, and to the house of Judah, {covenant a new}. 

#### Jeremiah 31:32 Not according to the covenant which I ordained with their fathers, in the day in which I took hold of their hand to lead them from out of the land of Egypt; for they did not adhere to my covenant, and I neglected them, says the LORD. 

#### Jeremiah 31:33 For this is my covenant which I shall ordain with the house of Israel after those days, says the LORD; I will put my laws into their mind, and {upon their hearts I will write them}; and I will be to them for God, and they will be to me for a people. 

#### Jeremiah 31:34 And in no way shall {teach each} his neighbor, and each his brother, saying, Know the LORD! For all shall know me, from their small unto their great, says the LORD. For I will be kind to their iniquities, and their sins in no way shall I remember any more. 

#### Jeremiah 31:35 Thus said the LORD, the one appointing the sun for light of the day, moon and stars for light of the night, and the roar in the sea, and {resonated its waves}; the LORD almighty is his name. 

#### Jeremiah 31:36 If {should cease laws these} from in front of me, says the LORD, then the race of Israel shall cease to become a nation in front of me all the days. 

#### Jeremiah 31:37 Thus says the LORD, If {should be raised up the heaven} in elevation, and if {should be lowered the floor of the earth} below, yet I shall not reject the race of Israel, says the LORD, for all which they did. 

#### Jeremiah 31:38 Behold, days come, says the LORD, and {shall be built a city} to the LORD from the tower of Hananeel unto the gate of the corner. 

#### Jeremiah 31:39 And {shall go forth its measurement} before it unto the hills of Gareb; and it shall be surrounded round about of choice stones, 

#### Jeremiah 31:40 and all the valley Phagarim and ashes, and all Asaremoth unto the rushing stream Kidron, unto the corner gate of the horses eastward, shall be a sanctuary to the LORD; and no longer shall it be plucked up, and in no way shall it be demolished unto the eon. 

#### Jeremiah 32:1 The word having come from the LORD to Jeremiah in the {year tenth} of Zedekiah king of Judah -- this is {year the eighteenth} of Nebuchadnezzar king of Babylon. 

#### Jeremiah 32:2 And the force of the king of Babylon built a palisade against Jerusalem. And Jeremiah was being guarded in the courtyard of the guard, which is in the house of the king of Judah. 

#### Jeremiah 32:3 By which {imprisoned him king Zedekiah}, saying, Why do you prophesy, saying, Thus said the LORD, Behold, I give this city into the hand of the king of Babylon, and he shall take it; 

#### Jeremiah 32:4 and Zedekiah in no way shall escape from out of the hand of the Chaldeans, for by being delivered up he shall be delivered up into the hands of the king of Babylon, and he shall speak with his mouth to his mouth, and his eyes {his eyes shall see}. 

#### Jeremiah 32:5 And Zedekiah shall enter into Babylon, and there he shall stay until of which time I should look upon him, says the LORD. But if you should wage war against the Chaldeans you shall not be prosperous. 

#### Jeremiah 32:6 And Jeremiah spoke. And {came the word of the LORD} to Jeremiah, saying, 

#### Jeremiah 32:7 Behold, Hanameel son of Shallum brother of your father comes to you, saying, Acquire to yourself my field, the one in Anathoth! for {to you it is equitable} to take it for a possession. 

#### Jeremiah 32:8 And {came to me Hanameel the son of Shallum the brother of my father} according to the word of the LORD in the courtyard of the guard. And he said to me, Acquire to yourself my field! the one in Anathoth in the land of Benjamin; for {to you it is equitable} to acquire, for you are older. And I knew that {the word of the LORD it was}. 

#### Jeremiah 32:9 And I acquired the field from Hanameel the son of the brother of my father, the field in Anathoth. And I set for him seven {shekels and ten silver}. 

#### Jeremiah 32:10 And I wrote in a scroll, and set a seal upon it, and took the testimony of witnesses, and set the silver in a yoke balance scale. 

#### Jeremiah 32:11 And I took the scroll of the possession being read and having the seal set upon, 

#### Jeremiah 32:12 and I gave it to Baruch, son of Neriah, son of Maaseiah, before the eyes of Hanameel son of the brother of my father, and before the eyes of the ones standing witnessing and writing in the scroll of the possession, and according to the eyes of all the Jews sitting down in the courtyard of the guard. 

#### Jeremiah 32:13 And I ordered Baruch in front of their eyes, saying, 

#### Jeremiah 32:14 Thus said the LORD almighty, the God of Israel, Take the scroll of this possession! even this scroll being sealed and being read. And you shall put it into {receptacle an earthenware}, that it should remain {days many more}. 

#### Jeremiah 32:15 For thus said the LORD of the forces, the God of Israel, Still there shall be created fields, and houses, and vineyards in this land. 

#### Jeremiah 32:16 And I prayed to the LORD after my giving the scroll of the possession to Baruch son of Neriah, saying, 

#### Jeremiah 32:17 O Being One, O LORD God, you made the heaven and the earth {strength by your great}, and {arm by your high and elevated}; in no way shall {be concealed from you anything}; 

#### Jeremiah 32:18 the one having mercy unto thousands, and recompensing sins of fathers into the bosom of their children after them. {God The great and strong}; the LORD of the forces, is his name, 

#### Jeremiah 32:19 of great counsel, and mighty in works. Your eyes are opened upon all the ways of the sons of men, to give each according to his way, and according to the fruit of his practices. 

#### Jeremiah 32:20 The one who did signs and miracles in the land of Egypt unto this day, and in Israel, and among the earth-born; and you made for yourself a name, as this day. 

#### Jeremiah 32:21 And you led your people Israel out of the land of Egypt with signs, and with miracles, by {hand a fortified}, and by {arm a high}, and by {visions great}. 

#### Jeremiah 32:22 And you gave to them this land which you swore by an oath to their fathers; a land flowing milk and honey. 

#### Jeremiah 32:23 And they entered and took it. And they hearkened not to your voice, and {by your orders they did not go}. All which you charged to them, they did not do. And they caused {to come to pass to them all these bad things}. 

#### Jeremiah 32:24 Behold, a multitude is come unto the city to seize it, and the city was given into the hands of Chaldeans waging war against it, by the face of the sword, and famine, and pestilence. As you said so it happened; and behold, you see. 

#### Jeremiah 32:25 And you say to me, Acquire to yourself the field with silver, and take testimony of witnesses! And the city was given into the hands of Chaldeans. 

#### Jeremiah 32:26 And came to pass the word of the LORD to me, saying, 

#### Jeremiah 32:27 I am the LORD God of all flesh. Shall {from me be hidden anything}? 

#### Jeremiah 32:28 On account of this, thus said the LORD; In granting, {shall be delivered up this city} into the hands of Chaldeans, and into the hands of the king of Babylon, and he shall take it. 

#### Jeremiah 32:29 And {shall come the Chaldeans} waging war against this city; and they shall burn this city by fire, and shall incinerate the houses in which they burned incense upon their roofs to Baal, and offered libations to other gods, to greatly embitter me. 

#### Jeremiah 32:30 For {were the sons of Israel and the sons of Judah} alone doing the wicked thing in front of my eyes from their youth. The sons of Israel were the ones greatly embittering me in the works of their hands, says the LORD. 

#### Jeremiah 32:31 For {for my anger and for my rage was this city} from which day they built it, and unto this day, to rid it from my face; 

#### Jeremiah 32:32 because of all the wickedness of the sons of Israel and Judah, which they did to embitter me, they, and their kings, and their rulers, and their priests, and their prophets, the men of Judah, and the ones dwelling in Jerusalem. 

#### Jeremiah 32:33 And they turned {to me their back}, and not their face. And I taught them at dawn, and they hearkened not to take instruction. 

#### Jeremiah 32:34 And they put their defilements in the house which {was called my name} upon by them in their uncleannesses. 

#### Jeremiah 32:35 And they built the shrines to Baal, the ones in the ravine of the son of Hinnom, to offer their sons and their daughters to Molech; which I ordered not to them, and it ascended not unto my heart to do this abomination, to seduce Judah to sin. 

#### Jeremiah 32:36 And now, thus said the LORD God of Israel against this city, which you say, It shall be delivered up into the hands of the king of Babylon by the sword, and by famine, and by pestilence. 

#### Jeremiah 32:37 Behold, I will gather them from out of all the land of which I scattered them there in my anger, and in my rage, and {fit of temper a great}. And I will return them unto this place; and I will settle them having secured them. 

#### Jeremiah 32:38 And they will be to me for a people, and I will be to them for God. 

#### Jeremiah 32:39 And I will give to them {way another} and {heart another}, to fear me all the days, and for good to them and their children after them. 

#### Jeremiah 32:40 And I will ordain with them {covenant an everlasting} which in no way shall I turn behind them. And {my fear I will put} in their heart, to not separate them from me. 

#### Jeremiah 32:41 And I will visit them to do good to them. And I will plant them in this land in trust, even with all my heart, and with all my soul. 

#### Jeremiah 32:42 For thus said the LORD, As I brought upon this people all {bad things great these}, so I will bring upon them all the good things which I spoke unto them. 

#### Jeremiah 32:43 And there shall be acquired still fields in the land, in which you say, It is untrodden of men and beast; and they were delivered up into the hands of Chaldeans. 

#### Jeremiah 32:44 And they shall acquire fields with silver; and you shall write in a scroll, and shall set a seal upon it, and shall take testimony of witnesses in the land of Benjamin, and round about Jerusalem, and in the cities of Judah, and in the cities of the mountain, and in the cities of the Sephela, and in the cities of the Negev. For I shall return their resettlement, says the LORD. 

#### Jeremiah 33:1 And came to pass the word of the LORD to Jeremiah a second time, (and he was still bound in the courtyard of the guard,) saying, 

#### Jeremiah 33:2 Thus said the LORD, the one making the earth and shaping it, to re-erect it; the LORD is his name. 

#### Jeremiah 33:3 Cry out to me! and I will answer you, and I will report to you great and mighty things which {not you knew them}. 

#### Jeremiah 33:4 For thus said the LORD God of Israel, concerning the houses of this city, and concerning the houses of the king of Judah being demolished for a siege mound and battlements, 

#### Jeremiah 33:5 to do combat against the Chaldeans, and to fill it of the dead, of the men whom I struck in my anger, and in my rage, and turned my face from this city on account of all their wickednesses. 

#### Jeremiah 33:6 Behold, I lead to her a closing of her wound and a cure. And I will treat them, and I will make manifest to them to hear, and I will make to them peace and trust. 

#### Jeremiah 33:7 And I will return the resettlement of Judah and the resettlement of Israel; and I will build them as prior. 

#### Jeremiah 33:8 And I will cleanse them from all their iniquities which they sinned against me. And in no way shall I remember their sins which they sinned against me, and separated from me. 

#### Jeremiah 33:9 And it will be to me for a name for gladness, and for praise, and for magnificence to all the people of the earth, who shall hear all the good things which I do for them. And they shall fear and shall be pricked on account of all the good things, and on account of all the peace which I make for them. 

#### Jeremiah 33:10 Thus said the LORD, There shall still be heard in this place (in which you say, It is desolate of men and animals, in the cities of Judah, and outside Jerusalem in the places having been made desolate by the not being a man and beast,) 

#### Jeremiah 33:11 a voice of gladness, and a voice of joyfulness, a voice of a groom, and a voice of a bride, a voice of men saying, Make acknowledgment to the LORD almighty! for the LORD is gracious, for into the eon is his mercy. And they shall carry in gifts to the house of the LORD. For I shall return all the resettlement of that land as prior, said the LORD. 

#### Jeremiah 33:12 Thus said the LORD of the forces, There shall yet be in {place this desolate} (by reason of not being a man and cattle in all of its cities) a lodging for shepherds bedding flocks. 

#### Jeremiah 33:13 In the cities of the mountainous area, and in the cities of the Sephela, and in the cities of the Negev, and in the land of Benjamin. And in the places round about Jerusalem, and in the cities of Judah yet shall go sheep by the hand of one counting, said the LORD. 

#### Jeremiah 33:14 Behold days come, says the LORD, and I will raise up the {word good} which I spoke over the house of Israel and over the house of Judah. 

#### Jeremiah 33:15 In those days and in that time, {to sprout I will cause} to David a bud of righteousness. And {shall reign a king}, and he shall be perceiving, and shall cause equity and righteousness in the land. 

#### Jeremiah 33:16 In those days Judah shall be delivered, and Jerusalem shall dwell securely. And this is the name they shall call him, The LORD our Justice. 

#### Jeremiah 33:17 For thus says the LORD, It shall not be deficient to David for a man sitting upon the throne of Israel. 

#### Jeremiah 33:18 And from the priests and Levites it shall not be deficient for a man to be before me offering whole burnt-offerings, and an incense gift, and doing a sacrifice all the days. 

#### Jeremiah 33:19 And came to pass the word of the LORD to Jeremiah, saying, 

#### Jeremiah 33:20 Thus says the LORD, If {as being annuled you should make my covenant}, the covenant with the day and my covenant with the night, so as for there to not be a day and a night in their time, 

#### Jeremiah 33:21 then my covenant being annuled will be with David my servant, so as to not be of him a son reigning upon his throne nor with the Levites and priests of my ministration. 

#### Jeremiah 33:22 As if {shall not be counted the military of heaven}, and {shall not be measured the sand of the sea}, thus I shall multiply the seed of David my firebrand, and of the Levites of my ministration. 

#### Jeremiah 33:23 And came to pass the word of the LORD to Jeremiah, saying, 

#### Jeremiah 33:24 Do you not know what this people spoke, saying, Two kin which {chose the LORD}, he pushed them out? And {my people they provoked} that you should not be a nation before them. 

#### Jeremiah 33:25 Thus says the LORD, If {may not be my covenant} to the day and to the night, and laws of the heaven and of the earth, then I ordained not. 

#### Jeremiah 33:26 Thus the seed of Jacob and David my servant I would have banished, so as {to not receive for me} of his seed rulers among the seed of Abraham, and of Isaac, and of Jacob. For I shall return their captivity, and I shall show mercy on them. 

#### Jeremiah 34:1 The word coming to Jeremiah from the LORD when Nebuchadnezzar king of Babylon, and all his encamped army, and to all the kingdoms of the earth, to the ones under the dominion of his hand, all the peoples waged war against Jerusalem, and against all the cities of Judah, saying, 

#### Jeremiah 34:2 Thus said the LORD, the God of Israel, Proceed to Zedekiah king of Judah! and you shall say to him, Thus said the LORD, In delivering up, I shall deliver up this city into the hands of the king of Babylon, and he shall seize it, and shall burn it with fire. 

#### Jeremiah 34:3 And you in no way shall be delivered from out of his hand; and by seizure you shall be seized, and into his hands you shall be given; and your eyes {his eyes shall see} and his mouth {with your mouth shall speak}, and into Babylon you shall enter. 

#### Jeremiah 34:4 But hear the word of the LORD, Zedekiah, O king of Judah! Thus says the LORD to you, you shall not die by the broadsword. 

#### Jeremiah 34:5 In peace you shall die, and as they burned odors for your fathers reigning prior of you, so they shall burn also for you, saying, O Lord. And they shall lament you, for {the word I spoke}, said the LORD. 

#### Jeremiah 34:6 And Jeremiah spoke to king Zedekiah all these words in Jerusalem. 

#### Jeremiah 34:7 And the force of the king of Babylon waged war against Jerusalem, and against the cities of Judah, the ones remaining, and against Lachish, and against Azekah, for these were left among the cities of Judah -- {cities fortified}. 

#### Jeremiah 34:8 The word coming to Jeremiah by the LORD, after the completing by king Zedekiah the covenant with the people, the one in Jerusalem, to call indeed for a release; 

#### Jeremiah 34:9 {to send out for each} his manservant, and each his maidservant, the Hebrew man and the Hebrew woman free, so that no {should slave man from Judah}. 

#### Jeremiah 34:10 And {heeded all the great men}, and all the people, the ones entering into the covenant to send each his manservant and each his maidservant free, to not serve any more to them. And they heeded, and let them go. 

#### Jeremiah 34:11 And they were turned after these things, and they led the bondmen and the maidservants whom they sent free, and they subjected them again as manservants and maidservants. 

#### Jeremiah 34:12 And came to pass the word of the LORD to Jeremiah, saying, 

#### Jeremiah 34:13 Thus said the LORD God of Israel, I ordained a covenant with your fathers in the day in which I rescued them from out of the land of Egypt, from out of the house of slavery, saying, 

#### Jeremiah 34:14 Whenever {should be fulfilled six years}, you shall send free {brother your Hebrew}, who shall be sold to you; and he shall work for you six years, and then you shall send him out free. And they did not hear me, and did not lean their ear. 

#### Jeremiah 34:15 And they turned today to do the right thing before my eyes, {to call for a release for each} for his neighbor; and they completed a covenant in front of me, in the house of which {is called name my} upon in it. 

#### Jeremiah 34:16 And you turned and profaned my covenant, to return each his manservant, and each his maidservant, whom you sent out as ones free in their soul, and you subjected them again to be to you for manservants and maidservants. 

#### Jeremiah 34:17 On account of this, thus said the LORD, You hearkened not to me to call a release -- each for his brother, and each for his neighbor. Behold, I call a release to you -- to the sword, and to the plague, and to the famine; and I will give you for dispersion unto all the kingdoms of the earth. 

#### Jeremiah 34:18 And I will give the men, the ones passing my covenant, the ones not establishing my covenant, which they made in front of me, the calf which they cut in two parts, and I went through in the midst of its parts, 

#### Jeremiah 34:19 of the rulers of Judah, and rulers of Jerusalem, and mighty ones, and priests, and all the people of the land; 

#### Jeremiah 34:20 and I will give them to their enemies, and into the hand of ones seeking their life. And {will be their decaying flesh} food to the winged creatures of the heaven, and to the wild beasts of the earth. 

#### Jeremiah 34:21 And Zedekiah king of Judea, and his rulers I will give into the hands of their enemies, and into the hands of ones seeking their life, and into the hands of the force of the king of Babylon -- to the ones running from them. 

#### Jeremiah 34:22 Behold, I order it, says the LORD; and I will return them into this city. And they shall wage war against her, and shall take her, and shall incinerate her in fire; and the cities of Judah -- I will make them for untrodden of ones dwelling. 

#### Jeremiah 35:1 The word coming to Jeremiah by the LORD in the days of Jehoiakim son of Josiah king of Judah, saying, 

#### Jeremiah 35:2 Proceed unto the family of the Rechabites, and call them, and you shall bring them into the house of the LORD, into one of the courtyards, and give them {to drink wine}. 

#### Jeremiah 35:3 And he led Jaazaniah son of Jeremiah, son of Habaziniah, and his brethren, and his sons, and all the family of the Rechabites; 

#### Jeremiah 35:4 and they brought them into the house of the LORD, into the cubicle of the sons of Hanan son of Igdaliah, a man of God, which is near the house of the rulers, above the house of Maaseiah the son of Shallum, the one guarding the way. 

#### Jeremiah 35:5 And I set in front of them a clay vessel of wine, and cups, and I said, Drink wine! 

#### Jeremiah 35:6 And they said, In no way should we drink wine, for Jonadab son of Rechab our father gave charge to us, saying, In no way shall you drink wine, you and your sons unto the eon. 

#### Jeremiah 35:7 And {houses in no way way shall you build}, nor {seed in any way shall you sow}, and a vineyard shall not be to you; for in tents you shall dwell all your days, so that you should live {days many} upon the land, upon which you spend your time upon it. 

#### Jeremiah 35:8 And we hearkened to the voice of Jonadab son of Rechab our father in all things which he gave charge to us, to not drink wine all the days of our life, we, and our wives, and our sons, and our daughters; 

#### Jeremiah 35:9 for to not build houses to dwell in there, and a vineyard and a field, and seed -- it happened not to us. 

#### Jeremiah 35:10 And we lived in tents, and we hearkened, and did according to all as much as {gave charge to us Jonadab our father}. 

#### Jeremiah 35:11 And it came to pass when {ascended Nebuchadnezzar king of Babylon} upon the land, and we said, In ascending we shall enter into Jerusalem from in front of the Chaldeans, and from in front of the force of the Assyrians. And we lived there. 

#### Jeremiah 35:12 And came to pass the word of the LORD to me, saying, 

#### Jeremiah 35:13 Thus says the LORD of the forces, the God of Israel, Go and say to the man of Judah! and to the ones dwelling Jerusalem. In no way will you take instruction to hear my word, says the LORD. 

#### Jeremiah 35:14 {established the word The sons of Jonadab son of Rechab}, the one given charge to his children to not drink wine; and they drank not unto this day, for they hearkened to the command of their father. And I spoke to you early, and I spoke and you did not hearken. 

#### Jeremiah 35:15 And I sent to you my servants the prophets rising early in the morning and sending, saying, Let {turn each} from {way his evil}! And {better do} in your practices! and you shall not go after {gods other} to serve them. And you shall live upon the land which I gave to you, and to your fathers. And you leaned not your ears, and you hearkened not. 

#### Jeremiah 35:16 But {established the sons of Jonadab son of Rechab} the commandment of their father, which he gave charge to them. But this people {not heard me}. 

#### Jeremiah 35:17 On account of this, Thus said the LORD of the forces, the God of Israel, Behold, I bring upon Judah, and upon the ones dwelling Jerusalem all the bad things which I spoke against them. For I spoke to them and they hearkened not. And I called them, and they did not answer. 

#### Jeremiah 35:18 And to the house of the Rechabites, Jeremiah said, Thus said the LORD, Since {hearkened to the sons of Jonadab son of Rechab} the commandment of their father, to do in so far as {gave charge to them their father}; on account of this thus says the LORD of the forces, the God of Israel, 

#### Jeremiah 35:19 No way shall there fail a man of the sons of Jonadab son of Rechab standing in front of me all the days. 

#### Jeremiah 36:1 And in the {year fourth} of Jehoiakim son of Josiah king of Judah, came to pass the word of the LORD to me, saying, 

#### Jeremiah 36:2 Take to yourself a papyrus leaf scroll! and write upon it! all the words which I spoke to you against Israel, and against Judah, and against all the nations from which day I spoke to you, from the days of Josiah king of Judah, and unto this day. 

#### Jeremiah 36:3 Perhaps {will hear the house of Judah} all the bad things which I devise to do to them; that they should turn from {way their wicked}; and I will be propitious to their iniquities, and to their sins. 

#### Jeremiah 36:4 And Jeremiah called Baruch son of Neriah. And Baruch wrote from the mouth of Jeremiah all the words of the LORD of which he gave a divine message to him on a papyrus paper scroll. 

#### Jeremiah 36:5 And Jeremiah gave charge to Baruch, saying, I am guarded, and I am not able to enter into the house of the LORD. 

#### Jeremiah 36:6 And you shall enter, and shall read with this papyrus paper scroll into the ears of the people in the house of the LORD in the day of the fast. And in the ears of all Judah, of the ones coming from out of their cities, you shall read to them. 

#### Jeremiah 36:7 Perhaps {will fall their need for mercy} in front of the LORD, and they will turn from {way their evil}. For great is the rage and the anger of the LORD which he spoke against this people. 

#### Jeremiah 36:8 And {did Baruch son of Neriah} according to all which {gave charge to him Jeremiah}, to read in the scroll the words of the LORD in the house of the LORD. 

#### Jeremiah 36:9 And it came to pass in the {year fifth} of Jehoiakim son of Josiah king of Judah, in the {month ninth}, they held an assembly fast in front of the LORD, all the people of Jerusalem, and the house of Judah. 

#### Jeremiah 36:10 And Baruch read in the scroll the words of Jeremiah in the house of the LORD, in the house of Gemariah son of Shaphan the scribe, in the {courtyard upper}, in the thresholds {gate of the house of the LORD of the new}, in the ears of all the people. 

#### Jeremiah 36:11 And {heard Micaiah son of Gemariah son of Shaphan} all the words of the LORD from out of the scroll. 

#### Jeremiah 36:12 And he went down unto the house of the king, unto the house of the scribe. And behold, there all the rulers sat -- Elishama the scribe, and Delaiah son of Shemaiah, and Elnathan son of Achbor, and Gemariah son of Shaphan, and Zedekiah son of Hananiah, and all the rulers. 

#### Jeremiah 36:13 And {announced to them Michaiah} all the words which he heard {reading Baruch} in the scroll, in the ears of the people. 

#### Jeremiah 36:14 And {sent all the rulers} to Baruch, son of Neriah, the son of Jehudi, son of Nethaniah, son of Shelemiah, son of Cushi, saying, The scroll in which you read by it into the ears of the people, take it into your hand and come! And {took Baruch son of Neriah} the scroll in his hand, and went down to them. 

#### Jeremiah 36:15 And they said to him, Again read for our ears! And Baruch read in their ears. 

#### Jeremiah 36:16 And it happened as they heard all the words, {gave advice each} to his neighbor, and they said to Baruch, By announcing, we should announce to the king all these words. 

#### Jeremiah 36:17 And they asked Baruch, saying, From what place did you write all these words? 

#### Jeremiah 36:18 And Baruch said, From the mouth of Jeremiah. He announced to me all these words, and I wrote upon a scroll. 

#### Jeremiah 36:19 And {said the rulers} to Baruch, Proceed and be hid, you and Jeremiah! Let not a man know where you are! 

#### Jeremiah 36:20 And they entered to the king, into the courtyard, and {the scroll they put} to guard in the house of Elishama the scribe. And they announced to the king all these words. 

#### Jeremiah 36:21 And {sent the king} Jehudi to take the scroll. And he took it from out of the house of Elishama the scribe, and Jehudi read in the ears of the king, and in the ears of all the rulers sitting around the king. 

#### Jeremiah 36:22 And the king was sitting in {house the winter} in {month the ninth}, with a grate of fire in front of him. 

#### Jeremiah 36:23 And it came to pass Jehudi having read three columns or four, he shred them with the razor of the scribe, and tossed into the fire, the one upon the grate, until {vanished all the papyrus leaf} in the fire, the one upon the grate. 

#### Jeremiah 36:24 And they were not amazed, and they tore not their garments -- the king and all his servants, the ones hearing all these words. 

#### Jeremiah 36:25 And Elnathan and Delaiah and Gemariah suggested to the king to not incinerate the papyrus paper. 

#### Jeremiah 36:26 And he did not hearken to them. And {gave charge the king} to Jerahmeel son of the king, and to Saraiah son of Azriel, and Shelemiah son of Abdeel, to seize Baruch the scribe, and Jeremiah the prophet -- and they were hidden. 

#### Jeremiah 36:27 And came to pass the word of the LORD to Jeremiah, after the {incinerating king} the papyrus paper with all the words which Baruch wrote from the mouth of Jeremiah, saying, 

#### Jeremiah 36:28 Again take to yourself {papyrus paper scroll another}, and write all the words being on the papyrus paper scroll which {incinerated king Jehoaikim}! 

#### Jeremiah 36:29 And to Jehoaikim, the king of Judah, you shall say, Thus said the LORD, You incinerated this scroll, saying, Why did you write upon it, saying, In entering {shall enter the king of Babylon}, and shall utterly destroy this land, and he shall obliterate from it man and beast. 

#### Jeremiah 36:30 On account of this thus said the LORD against Jehoiakim king of Judah, There will not be to him one sitting down upon the throne of David; and his decaying flesh will be for tossing in the sweltering heat of the day, and in the icy coldness of the night. 

#### Jeremiah 36:31 And I will visit against him, and against his family, and against his children their lawlessnesses. And I will bring upon them, and upon the ones dwelling in Jerusalem, and upon the land of Judah, all the evils which I spoke to them; and they heard not. 

#### Jeremiah 36:32 And Jeremiah took {papyrus paper scroll another}, and he gave it to Baruch son of Neriah the scribe. And he wrote upon it from the mouth of Jeremiah all the words of the scroll which {incinerated Jehoiakim king of Judah} in fire, and still were added to it {words many} as these. 

#### Jeremiah 37:1 And {reigned Zedekiah son of Josiah} instead of Coniah the son of Jehoiakim, whom {gave reign Nebuchadnezzar king of Babylon} to reign in the land of Judah. 

#### Jeremiah 37:2 And {hearkened not he}, and his servants, and the people of the land, of the words of the LORD which he spoke by the hand of Jeremiah. 

#### Jeremiah 37:3 And {sent king Zedekiah} Jehucal son of Shelemiah, and Zephaniah son of Maaseiah the priest to Jeremiah, saying, Pray concerning us to the LORD our God! 

#### Jeremiah 37:4 And Jeremiah came and went through the middle of the city, and they did not put him into prison. 

#### Jeremiah 37:5 And the force of Pharaoh came forth from out of Egypt. And {heard the Chaldeans} the report of them, and they ascended unto Jerusalem. 

#### Jeremiah 37:6 And came to pass the word of the LORD to Jeremiah, saying, 

#### Jeremiah 37:7 Thus said the LORD, the God of Israel; Thus shall you say to the king of Judah, the one sending to you to inquire of me; Behold, the force of Pharaoh coming forth to you for help, they shall return into the land of Egypt. 

#### Jeremiah 37:8 and {shall return themselves the Chaldeans}, and they shall wage war against this city, and shall seize it, and shall burn it with fire. 

#### Jeremiah 37:9 For thus said the LORD, You should not undertake the thought in your souls, saying, {running shall depart from us The Chaldeans}. For in no way shall they depart. 

#### Jeremiah 37:10 And if you should strike all the force of the Chaldeans, the ones waging war against you, and there should be left behind a certain amount having been stabbed, each in his place, these shall rise up and shall burn this city by fire. 

#### Jeremiah 37:11 And it came to pass when {ascended the force of the Chaldeans} from Jerusalem from in front of the force of Pharaoh, 

#### Jeremiah 37:12 Jeremiah came forth from Jerusalem to go into the land of Benjamin to buy from there land in the midst of the people. 

#### Jeremiah 37:13 And he was himself in the gate of Benjamin. And there was there a man by whom he rested up, Irijah, son of Shelemiah, son of Hananiah. And he seized Jeremiah, saying, {to the Chaldeans You are fleeing}. 

#### Jeremiah 37:14 And he said, It is a lie, {am not unto the Chaldeans I fleeing}. But he did not listen to him. And Irijah seized Jeremiah, and brought him to the rulers. 

#### Jeremiah 37:15 And {were embittered the rulers} over Jeremiah, and they struck him, and they sent him into the house of the prison of Jonathan the scribe. For this they made into a house of a prison. 

#### Jeremiah 37:16 And Jeremiah came into the house of the pit, and into the confinement, and he stayed there {days many}. 

#### Jeremiah 37:17 And Zedekiah sent and called him. And {asked him the king} secretly, and said to him, Is there a word from the LORD? And he said, It is into the hands of the king of Babylon you shall be delivered up. 

#### Jeremiah 37:18 And Jeremiah said to the king, How did I wrong you, and your servants, and this people, that you put me into {house a prison}? 

#### Jeremiah 37:19 And where are your prophets, the ones prophesying to you, saying that, In no way shall {come the king of Babylon} unto this land? 

#### Jeremiah 37:20 And now hear indeed O lord, O king! Let {fall mercy} for me in front of you! And in no way should you return me unto the house of Jonathan the scribe, and in no way should I die there. 

#### Jeremiah 37:21 And {ordered the king}, and they put him in the house of the guard, and they gave to him {bread loaf one} a day from outside of which they baked, until {failed the bread loaves} from the city. And Jeremiah stayed in the courtyard of the guard. 

#### Jeremiah 38:1 And {heard Shephatiah son of Mattan}, and Gedaliah son of Pashur, and Jucal son of Shelemiah, and Pashur son of Malchiah, the words which Jeremiah spoke unto the people, saying, 

#### Jeremiah 38:2 Thus said the LORD, The one dwelling in this city shall die by the broadsword, and by famine, and by pestilence; and the one going forth to the Chaldeans shall live; and {shall be his life} for gain, and he shall live. 

#### Jeremiah 38:3 For thus said the LORD, In being delivered up, {shall be delivered up this city} into the hands of the force of the king of Babylon, and he shall seize it. 

#### Jeremiah 38:4 And {said the rulers} to the king, Do away with {indeed that man}, for he enfeebles the hands of the men waging war of the ones being left in this city, and the hands of all the people, by speaking to them according to these words. For this man does not speak oracles for peace to this people, but only evils. 

#### Jeremiah 38:5 And {said king Zedekiah}, Behold, he is in your hands; for {was not able the king} to resist them. 

#### Jeremiah 38:6 And they took Jeremiah, and they tossed him into the pit of Malchiah, son of the king, which was in the courtyard of the guard. And they let him down with rough cords into the pit. And in the pit there was no water, but only mire, and he was in the mire. 

#### Jeremiah 38:7 And {heard Ebed-melech the Ethiopian man eunuch} (and he was in the courtyard of the king) that they cast Jeremiah into the pit; and the king was sitting down at the gate of Benjamin. 

#### Jeremiah 38:8 And Ebed-melech went forth from the house of the king, and he spoke to the king, and said, 

#### Jeremiah 38:9 My master, O King, {did wickedly these men all} in which they did against Jeremiah the prophet, dropping him into the pit, that he should die in it from the face of hunger, for there are no longer bread loaves in the city. 

#### Jeremiah 38:10 And {gave charge the king} to Ebed-melech, saying, Take with yourself from here thirty men, and lead him from out of the pit, that he should not die. 

#### Jeremiah 38:11 And Ebed-melech took the men, and he entered into the house of the king, the subterranean part, and he took from there old rags and old rough cords; and he tossed them to Jeremiah in the pit. 

#### Jeremiah 38:12 And he said to him, Put these underneath the rough cords! And Jeremiah did so. 

#### Jeremiah 38:13 And they drew him with the rough cords, and led him up from out of the pit. And Jeremiah stayed in the courtyard of the guard. 

#### Jeremiah 38:14 And {sent the king} and called him to himself into the house Asaliseel, the one in the house of the LORD. And {said to him the king}, I shall ask you a word, and you shall not hide from me the saying. 

#### Jeremiah 38:15 And Jeremiah said to the king, If I should announce to you, will you not to death put me to death? and if I shall advise you, in no way shall you hear me. 

#### Jeremiah 38:16 And {swore by an oath the king} to him secretly, saying, As the LORD lives, who appointed us this life, Shall I kill you, and shall I put you into the hands of these men, the ones seeking your life, No! 

#### Jeremiah 38:17 And {said to him Jeremiah}, Thus said the LORD of the forces, the God of Israel, If by going forth you should go forth to the governors of the king of Babylon, {shall live your soul}, and this city in no way shall be incinerated by fire; and you shall live, and your family. 

#### Jeremiah 38:18 But if you do not go forth, {shall be given this city} into the hands of the Chaldeans, and they shall burn it with fire, and in no way shall you be delivered from their hands. 

#### Jeremiah 38:19 And {said the king} to Jeremiah, I {a matter have} with the Jews having fled to the Chaldeans, lest they give me into their hands, and they shall deride me. 

#### Jeremiah 38:20 And Jeremiah said, In no way shall they deliver you up. Hearken to the word of the LORD! which I say to you, and {better it will be} for you, and {shall live your soul}! 

#### Jeremiah 38:21 And if {do not want you} to come forth, this is the word which {showed to me the LORD}. 

#### Jeremiah 38:22 Behold, all the women being left behind in the house of the king of Judah having been led out to the rulers of the king of Babylon; and these women shall say, {deceived you and prevailed over you the men at peace with you}, and they will depose you in slips of your feet; they turned from you. 

#### Jeremiah 38:23 And your wives, and your children they shall lead out to the Chaldeans; and you in no way shall you be delivered, for by the hand of the king of Babylon you shall be seized, and this city shall be incinerated. 

#### Jeremiah 38:24 And {said to him Zedekiah}, to Jeremiah, {no man Let} know of these words! and you shall in no way die. 

#### Jeremiah 38:25 And if the rulers should hear that I spoke to you, and they should come to you, and should say to you; Announce to us what you spoke to the king, you should not hide it from us, then in no way will we do away with you; and what did {say to you the king}? 

#### Jeremiah 38:26 And you shall say to them, I tossed my plead for mercy before the eyes of the king, to not return me to the house of Jonathan for me to die there. 

#### Jeremiah 38:27 And came all the rulers to Jeremiah, and they asked him. And he announced to them according to all these words which {gave charge to him the king}. And they were silent, for {was not heard the matter}. 

#### Jeremiah 38:28 And Jeremiah stayed in the courtyard of the guard until a time of which Jerusalem was seized. 

#### Jeremiah 39:1 And it came to pass in the {year ninth} of Zedekiah king of Judah, in the {month tenth}, came Nebuchadnezzar king of Babylon and all his force against Jerusalem, and they assaulted it. 

#### Jeremiah 39:2 And in the eleventh year of Zedekiah, in the {month fourth}, ninth of the month, {was broken asunder the city}. 

#### Jeremiah 39:3 And {entered all the governors of the king of Babylon} and sat at the gate, the one in the middle, Nergal-sharezer, Samgar, and Nebo-sarsechim, and Nebu-sarkes and Nergal, Sharezer, Rab-mag, and the rest of the governors of the king of Babylon. 

#### Jeremiah 39:4 And it came to pass as {saw them Zedekiah king of Judah}, and all the men warriors, that they fled and went forth at night from the city according to the way of the garden of the king through the gate between the wall and the fortification around the wall. And they went forth by the way of Araba. 

#### Jeremiah 39:5 And {pursued the force of the Chaldeans} after them. And they seized Zedekiah on the other side of Jericho, and they led him to Nebuchadnezzar king of Babylon to Riblah the city in the land of Hamath. And he spoke against him with judgment. 

#### Jeremiah 39:6 And {slew the king of Babylon} the sons of Zedekiah in Riblah before his eyes; and all the rulers of Judah he slew. 

#### Jeremiah 39:7 And the eyes of Zedekiah he blinded. And he bound him with shackles, and he led him unto Babylon. 

#### Jeremiah 39:8 And the house of the king, and the houses of the people {set on fire the Chaldeans} with fire, and the wall of Jerusalem they demolished. 

#### Jeremiah 39:9 And the extra of the people, and the ones being left behind in the city, and the ones falling in -- these, they fell to the king of Babylon. 

#### Jeremiah 39:10 And the rest of the people, and the ones being left behind {removed Nabuzar-adan the chief guard} unto Babylon. And of the poor of the people, the ones who were not anything, {left behind Nabuzar-adan the chief guard} in the land of Judah. And he gave to them vineyards and fields in that day. 

#### Jeremiah 39:11 And {gave charge Nebuchadnezzar king of Babylon} concerning Jeremiah in the hand of Nebuzar-adan the chief guard, saying, 

#### Jeremiah 39:12 Take him and put your eyes upon him! and you should not do to him anything bad; but as it should be said to you, thus you shall do for him! 

#### Jeremiah 39:13 And {sent Nabuzar-adan the chief guard}, and Nabushasban and Rab-sares and Nergel and Sharezer and Rab-mag and all the governers of the king of Babylon. 

#### Jeremiah 39:14 And they sent and took Jeremiah from out of the courtyard of the guard, and they gave him to Gedaliah son of Ahikam son of Shaphan, and they led him out. And he sat in the midst of the people. 

#### Jeremiah 39:15 And to Jeremiah came the word of the LORD in the courtyard of the guard, saying, 

#### Jeremiah 39:16 Go and speak to Ebed-melech the Ethiopian! saying, Thus said the LORD God of Israel, Behold, I bring my words upon this city for bad things, and not for good things. And they shall be before you in that day. 

#### Jeremiah 39:17 And I shall deliver you in that day, says the LORD, and I will not give you into the hands of the men whom you fear from their face. 

#### Jeremiah 39:18 For by delivering, I shall deliver you, and by the broadsword in no way shall you fall. And {will be your life} for gain, for you relied upon me, says the LORD. 

#### Jeremiah 40:1 The word coming to Jeremiah from the LORD afterwards with his being sent by Nabuzar-adan the chief guard from out of Ramah in the taking him in manacles in the midst of the resettlement of Judah, of the ones being led into Babylon. 

#### Jeremiah 40:2 And {took him the chief guard}, and said to him, The LORD your God spoke these evils against this place. 

#### Jeremiah 40:3 And the LORD did as he said, for you all sinned against him, and hearkened not to his voice, and {happened to you this word}, 

#### Jeremiah 40:4 And now behold, I untied you from the manacles, of the ones upon your hands. If it is good before you to go with me into Babylon, come! and I will put my eyes upon you. But if not run from here! Behold, all the land before you is for good; and for what is pleasing in your eyes to go there, go! 

#### Jeremiah 40:5 And return to Gedaliah son of Ahikam son of Shaphan! whom {established the king of Babylon} in the land of Judah. And live with him in the midst of the people! for all the things good in your eyes to go to -- then go! And {gave to him the chief guard} a feast and gifts, and sent him. 

#### Jeremiah 40:6 And he came to Gedaliah in Mizpah, and stayed in the midst of the people, of the one being left behind in the land. 

#### Jeremiah 40:7 And {heard all the leaders of the force in the field}, they and their force, that {established the king of Babylon} Gedaliah in the land, and that they deposited to his care men and their wives, and the simple people, and for the needy of the land which he resettled not in Babylon. 

#### Jeremiah 40:8 And came to Gedaliah in Mizpah, even Ishmael son of Nethaniah, and Johanan son of Kareah, and Seraiah son of Tanhumeth, and the sons of Ephai the Netophathite, and Jezaniah son of the Maachathite -- they and their men. 

#### Jeremiah 40:9 And {swore by an oath to them Gedaliah} and to their men, saying, Lest you should fear from the face of the servants of the Chaldeans, dwell in the land, and work for the king of Babylon! and it will be better for you. 

#### Jeremiah 40:10 And behold, I sit in Mizpah to stand against the face of the Chaldeans, to whom ever should come against us. And you bring together wine, and autumn fruits, and olive oil, and lay them in your receptacles, and dwell in the cities which you held! 

#### Jeremiah 40:11 And all the Jews, the ones in Moab, and among the sons of Ammon, and the ones in Edom, and the ones in all the land, heard that {granted the king of Babylon} a vestige to Judah, and that he placed over them Gedaliah son of Ahikam. 

#### Jeremiah 40:12 And {were returned all the Jews} from every place into which they were dispersed. And they came to Gedaliah in the land of Judah in Mizpah. And they gathered wine and autumn fruits -- much, exceedingly, and olive oil. 

#### Jeremiah 40:13 And Johanan son of Kareah, and all the governors of the force, the ones in the fields, came to Gedaliah in Mizpah. 

#### Jeremiah 40:14 And they said to him, Do you with knowledge know that Baalis king of the sons of Ammon sent against you Ishmael son of Nethaniah, to strike your life? and {did not trust them Gedaliah son of Ahikam}. 

#### Jeremiah 40:15 And Johanan son of Kareah said to Gedaliah secretly in Mizpah, I will go indeed, and I shall strike Ishmael son of Nethaniah, and let no one know! lest he should strike your soul, and should scatter all Judah, the ones being brought together to you, and they shall destroy the rest of Judah. 

#### Jeremiah 40:16 And Gedaliah said to Johanan son of Kareah, You should not do this thing, for {lies you speak} concerning Ishmael. 

#### Jeremiah 41:1 And it came to pass in the {month seventh} came Ishmael son of Nethaniah son of Elishama, from the family of the king, and leaders of the king, and ten men with him to Gedaliah in Mizpah; and they ate {there bread together}. 

#### Jeremiah 41:2 And Ishmael rose up, and the ten men who were with him, and they struck Gedaliah by sword, and they killed him, whom {established the king of Babylon} over the land, 

#### Jeremiah 41:3 and all the Jews being with him in Mizpah, and all the Chaldeans being found there. And {the men warriors Ishmael stuck}. 

#### Jeremiah 41:4 And it came to pass in the {day second} of his striking Gedaliah, that no man knew of it; 

#### Jeremiah 41:5 And there came men of Shechem from Shiloh, and from Samaria -- eighty men, being shaven of beards, and having {being torn the garments}, and beating their chests, and gifts and frankincense was in their hands to carry into the house of the LORD. 

#### Jeremiah 41:6 And {came forth to meet them Ishmael son of Nethaniah} from Mizpah, and they went and wept. And he said to them, Enter to Gedaliah! 

#### Jeremiah 41:7 And it happened in their entering in the midst of the city, that he slew them at the well -- he and the men, the ones with him. 

#### Jeremiah 41:8 And ten men were found there. And they said to Ishmael, You should not do away with us, for there are with us treasures in the field, wheat and barley, and honey, and olive oil. And he passed by and did not do away with them in the midst of their brethren. 

#### Jeremiah 41:9 And the well into which Ishmael tossed all whom he struck {well was a great}. This is the one which {made king Asa} from fear in front of Baasha king of Israel. This well {filled Ishmael son of Nethaniah} of slain ones. 

#### Jeremiah 41:10 And Ishmael returned all the people being left behind in Mizpah, and the daughters of the king who were deposited in the care of the chief guard by Gedaliah son of Ahikam. And he set out unto the other side of the sons of Ammon. 

#### Jeremiah 41:11 And {heard Johanan son of Kareah}, and all the leaders of the force with him, all the evil things which {did Ishmael son of Nethaniah}. 

#### Jeremiah 41:12 And he led all their encamped army, and set out to wage war against him; and he found him at the water of the great pool in Gibeon. 

#### Jeremiah 41:13 And it came to pass when {saw all the people with Ishmael} Johanan son of Kareah, and all the leaders of the force with him, they were glad, 

#### Jeremiah 41:14 and they returned to Johanan. 

#### Jeremiah 41:15 But Ishmael escaped with eight men, and set out towards the sons of Ammon. 

#### Jeremiah 41:16 And Johanan took, and all the leaders of the force with him, all the remnant of the people whom he returned from Ishmael son of Nethaniah from Mizpah -- after his striking Gedaliah son of Ahikam -- mighty men in war, and the women, and the rest of the things, and the eunuchs, whom he returned from Gibeon. 

#### Jeremiah 41:17 And they set out and stayed in Chimham, the one by Beth-lehem, to go into Egypt, 

#### Jeremiah 41:18 from the face of the Chaldeans. For they feared from their face, for Ishmael struck Gedaliah whom {established the king of Babylon} in the land. 

#### Jeremiah 42:1 And {went forward all the leaders of the force}, and Johanan son of Kareah, and Jezaniah son of Hoshaiah, and all the people from small and unto great. 

#### Jeremiah 42:2 And they said to Jeremiah the prophet, Let there fall now our need for mercy in front of you! And pray to the LORD your God concerning the rest of these! for we are left few from many, as your eyes see. 

#### Jeremiah 42:3 And let {announce to us the LORD your God}! the way in which we shall go by it, and the word which we shall do. 

#### Jeremiah 42:4 And {said to them Jeremiah the prophet}, I heard, behold, I will pray to the LORD our God according to your words. And it will be the word which {shall answer the LORD}, I will announce to you; in no way shall I hide from you a word. 

#### Jeremiah 42:5 And they said to Jeremiah, Let the LORD be to us for a {witness just and trustworthy}! if we do not according to every word which ever {should send you the LORD your God} to us -- thus we will do. 

#### Jeremiah 42:6 And whether if good or if bad be the voice of the LORD our God, of whom we send you to him, we shall hearken; that {better to us it should be} -- for we shall hearken to the voice of the LORD our God. 

#### Jeremiah 42:7 And it came to pass after ten days, {came the word of the LORD} to Jeremiah. 

#### Jeremiah 42:8 And he called Johanan son of Kareah, and the leaders of the force, and all the people, from small and unto great. 

#### Jeremiah 42:9 And he said to them, Thus said the LORD, the God of Israel, of whom you sent me to him that {should fall your supplication} before him. 

#### Jeremiah 42:10 If staying you should stay in this land, then I will build you, and in no way shall I demolish; and I will plant you, and in no way pluck. For I have caused rest over the hurts which I did to you. 

#### Jeremiah 42:11 You should not be fearful from the face of the king of Babylon, of whom you fear from his face. You should not be fearful, says the LORD. For {with you I am}, to rescue you, and to deliver you from out of his hand. 

#### Jeremiah 42:12 And I will grant to you an act of kindness, and I will show mercy on you, and I will return you unto your land. 

#### Jeremiah 42:13 And if you say to yourselves, In no way should we stay in this land, to not hearken to the voice of the LORD your God, 

#### Jeremiah 42:14 saying, Far be it, for {into the land of Egypt we shall enter}, and in no way should we know war, and {the sound of a trumpet in no way should we hear}, and {in bread loaves in no way should we hunger}, and we shall live there. 

#### Jeremiah 42:15 On account of this, hear the word of the LORD, O remnant of Judah! Thus said the LORD of the forces, the God of Israel, If you should put your face unto Egypt, and should enter in there to dwell; 

#### Jeremiah 42:16 then it shall be the broadsword which you shall fear from its face -- it shall find you in Egypt; and the famine of which you {a reckoning have} from in front of it, it shall overtake you in Egypt, and there you shall die. 

#### Jeremiah 42:17 And it will be all the men, the ones putting their face to enter into the land of Egypt to dwell there, they shall fail by the broadsword, and by the famine, and pestilence. And there will not be for them any one delivering from the evils which I bring upon them. 

#### Jeremiah 42:18 For thus said the LORD of the forces, the God of Israel, As {dripped my rage} upon the ones inhabiting Jerusalem, so shall {drip my rage} upon you, on your entering into Egypt. And you shall be for an untrodden land, and under one's hands, and for a curse, and for scorning; and in no way shall you behold any longer this place, 

#### Jeremiah 42:19 which the LORD spoke against you, the ones remaining of Judah. You should not enter into Egypt. And now, in knowing, you shall know that I witnessed to you today, 

#### Jeremiah 42:20 that you did wickedly in your souls, sending me to the LORD your God, saying, Pray concerning us! to the LORD, and according to all what ever {should say to you the LORD our God}, thus you tell us and we will act. 

#### Jeremiah 42:21 And I announced to you, and you hearkened not to the voice of the LORD your God, according to all which he sent to you. 

#### Jeremiah 42:22 And now by the broadsword, and by famine, and by pestilence you shall end in the place in which you wanted to enter to dwell there. 

#### Jeremiah 43:1 And it came to pass as Jeremiah ceased speaking to the people all the words of the LORD their God, which {sent the LORD their God} to them, even all these words. 

#### Jeremiah 43:2 And {said Azariah son of Hoshaiah}, and Johanan son of Kareah, and all the {men proud}, the ones speaking to Jeremiah, {lies You speak}, {did not send you The LORD our God} to us, to say, You should not enter into Egypt to live in there; 

#### Jeremiah 43:3 but Baruch son of Neriah unites with you against us, that you should give us into the hands of the Chaldeans, to put us to death, and to resettle us in Babylon. 

#### Jeremiah 43:4 And Johanan son of Kareah, and all the leaders of the force, and all the people hearkened not to the voice of the LORD to dwell in the land of Judah. 

#### Jeremiah 43:5 And Johanan took, and all the leaders of the force, the whole of the rest of Judah, of the ones returning from all of the nations which they were scattered there, to dwell in the land of Judah; 

#### Jeremiah 43:6 the mighty men, and the women, and the infants remaining, and the daughters of the king, and the souls which {left behind Nabuzar-adan the chief guard} with Gedaliah son of Ahikam, and Jeremiah the prophet, and Baruch son of Neriah. 

#### Jeremiah 43:7 And they entered into Egypt, for they hearkened not to the voice of the LORD; and they entered into Tahpanhes. 

#### Jeremiah 43:8 And came to pass the word of the LORD to Jeremiah in Tahpanhes, saying, 

#### Jeremiah 43:9 Take to yourself {stones great}, and hide them in the thresholds in the gate of the residence of Pharaoh in Tahpanhes, in front of the eyes of the men of Judah. 

#### Jeremiah 43:10 And you shall say, Thus said the LORD of the forces, the God of Israel, Behold, I send for, and I will bring Nebuchadnezzar king of Babylon my servant. And he shall put his throne upon these stones which you hid; and he shall lift the shields upon them. 

#### Jeremiah 43:11 And he shall enter, and shall strike the land of Egypt; whom for death unto death, and whom for resettlement unto resettlement, and whom for broadsword unto broadsword. 

#### Jeremiah 43:12 And he shall kindle a fire in the houses of their gods, and shall set them on fire, and shall resettle them, and shall fumigate the land of Egypt as {fumigates the shepherd} his garment; and he shall go forth in peace. 

#### Jeremiah 43:13 And he shall break the columns of Heliopolis, the ones in Egypt. And the houses of the gods of Egypt he shall incinerate with fire. 

#### Jeremiah 44:1 The word coming to Jeremiah to all the Jews dwelling in the land of Egypt, and to the ones settling in Migdol, and in Tahpanhes, and in Memphis, and in the land of Pathros, saying, 

#### Jeremiah 44:2 Thus said the LORD of the forces, the God of Israel, You have seen all the evils which I brought upon Jerusalem, and upon the cities of Judah. And behold, they are desolate today of ones dwelling, 

#### Jeremiah 44:3 because of the face of their wickedness of which they did to greatly embitter me; going to burn incense {gods to other} which {knew not they}, even you, and your fathers. 

#### Jeremiah 44:4 And I sent to you my servants the prophets early. And I sent saying, You shall not do this thing, this contamination of which I detested. 

#### Jeremiah 44:5 And they did not hearken to me, and they did not lean their ear to turn from their evils to not burn incense {gods to other}. 

#### Jeremiah 44:6 And {dripped upon them my anger}, and my rage, and it was kindled in the cities of Judah, and outside Jerusalem. And they became for desolation and for an untrodden place, as this day. 

#### Jeremiah 44:7 And now thus said the LORD almighty, the God of Israel, Why do you do {evils great} against your souls? to cut off from you, man and woman, infant and one nursing, from the midst of Judah, to not leave behind for yourselves not one person; 

#### Jeremiah 44:8 to embitter me greatly in the works of your hands, to burn incense to other gods in the land of Egypt, into which you entered to dwell there, that you should be cut off, and that you should become as a curse and for scorning among all the nations of the earth. 

#### Jeremiah 44:9 Have you yourselves forgotten the evils of your fathers, and the evils of the kings of Judah, and the evils of your rulers, and the evils of your wives, which they did in the land of Judah, and outside of Jerusalem? 

#### Jeremiah 44:10 And they did not cease unto this day. And they feared not, and held not to my orders which I put in front of them, and in front of their fathers. 

#### Jeremiah 44:11 On account of this, thus said the LORD of the forces, the God of Israel; Behold, I set my face against you for evil, to destroy all Judah. 

#### Jeremiah 44:12 And I shall take the remnant of Judah, the ones that established their face to enter into the land of Egypt to dwell there, and they shall fail all in the land of Egypt. And they shall fall by broadsword, and {by famine they shall fail}, from small unto great. And they will be for scorning, and for destruction, and for a curse. 

#### Jeremiah 44:13 And I will visit against the ones settling in the land of Egypt, as I visited against Jerusalem by broadsword, and by famine, and by plague. 

#### Jeremiah 44:14 And there shall not be one escaping, not one of the ones remaining of Judah, of the ones sojourning in the land of Egypt, to return into the land of Judah upon which they hope in their souls to return there. In no way shall they return, except the ones escaping. 

#### Jeremiah 44:15 And they answered to Jeremiah -- all the men knowing that {burned incense their wives gods to other}, and all the women, {gathering a great}, and all the people settling down in the land of Egypt in the land of Pathros, saying, 

#### Jeremiah 44:16 The word which you spoke to us in the name of the LORD, we will not hearken to you. 

#### Jeremiah 44:17 For in doing we will do all the matter which shall come forth out of our mouth to burn incense to the queen of heaven, and to offer to her libations, as we did ourselves, and our fathers, and our kings, and our rulers in the cities of Judah, and outside Jerusalem. And we were filled of bread loaves, and we were better off, and {bad things we did not see}. 

#### Jeremiah 44:18 And as we stopped burning incense to the queen of the heaven, and offering a libation to her of a libation, {were made less all we}, and by broadsword and by famine we failed. 

#### Jeremiah 44:19 And seeing that we burned incense to the queen of heaven, and offered to her libations, did we without our husbands make to her cakes, and offer libations to her? 

#### Jeremiah 44:20 And Jeremiah said to all the people, to the mighty men, and to the women, and to all the people responding to him with words, saying, 

#### Jeremiah 44:21 Did not, concerning the incense of which you burned in the cities of Judah, and outside Jerusalem, you and your fathers, and your kings, and your rulers, and the people of the land, the LORD remember? even it ascended unto his heart. 

#### Jeremiah 44:22 And {was not able the LORD} still to bear up from in front of the wickedness of your deeds, and from your abominations which you did; and {became your land} for desolation, and for an untrodden place, and for a curse, as this day; 

#### Jeremiah 44:23 from in front of which you burned incense, and which you sinned against the LORD, and hearkened not to the voice of the LORD, and to his orders, and to his law; and by his testimonies you did not go; and {took hold of you these evils} as this day. 

#### Jeremiah 44:24 And Jeremiah said to the people, and to the women, Hear the the word of the LORD all Judah, the ones in the land of Egypt! 

#### Jeremiah 44:25 Thus said the LORD God of Israel, You and your women {with your mouth spoke}, and {by your hands fulfilled}, saying, In offering, we shall offer our acknowledgment offerings which we acknowledged, to burn incense to the queen of heaven, and to offer to her libations. In adhering you adhered to your acknowledgment offerings, and the offerings which you offered. 

#### Jeremiah 44:26 On account of this, hear the word of the LORD all Judah settling down in the land of Egypt! Behold, I swore by an oath to {name my great}, said the LORD. {shall be no longer My name} in the mouth of all Judah to say, Live O Lord the LORD, in all the land of Egypt. 

#### Jeremiah 44:27 For behold, I have been vigilant against them, to inflict hurt on them, and to not do good. And {shall fail all Judah dwelling in the land of Egypt} by broadsword, and by famine, until whenever they shall cease. 

#### Jeremiah 44:28 And the ones escaping from the broadsword shall return into the land of Judah being few in number. And {shall know all the remnant of Judah}, the ones sojourning in the land of Egypt to sojourn there, whose word will adhere, mine or theirs. 

#### Jeremiah 44:29 And this is the sign, says the LORD, to you, That I myself will visit upon you in this place, that you should know that {shall adhere my words} unto you for evils. 

#### Jeremiah 44:30 Thus said the LORD, Behold, I give Pharaoh Hophra king of Egypt into the hands of his enemy, and into the hands of ones seeking his life; as I have given Zedekiah king of Judah into the hands of Nebuchadnezzar king of Babylon, his enemy, and the one seeking his life. 

#### Jeremiah 45:1 The word which {spoke Jeremiah the prophet} to Baruch son of Neriah, when he wrote these words in the scroll from the mouth of Jeremiah, in the {year fourth} of Jehoiakim son of Josiah king of Judah, saying, 

#### Jeremiah 45:2 Thus said the LORD the God of Israel, concerning you, O Baruch. 

#### Jeremiah 45:3 For you said, Alas, for the LORD added toil upon my misery. I went to bed in my moanings, {rest I did not find}. 

#### Jeremiah 45:4 You said to him! Thus said the LORD, Behold, What I built up I demolish, and what I planted I pluck, even all the land of mine. 

#### Jeremiah 45:5 And you seek to yourself great things. You should not seek. For behold, I bring bad things upon all flesh, says the LORD. But I will give to you your life for gain in every place wherever you should proceed there. 

#### Jeremiah 46:1 And came to pass the word of the LORD to Jeremiah the prophet against all nations, 

#### Jeremiah 46:2 against Egypt, against the force of Pharaoh Necho king of Egypt, who was at the river Euphrates in Carchemish, which {struck Nebuchadnezzar king of Babylon}, which was in the {year fourth} of Jehoiakim son of Josiah king of Judah. 

#### Jeremiah 46:3 Take up weapons and shields, and lead forward to battle! 

#### Jeremiah 46:4 Saddle the horses, mount up the horsemen, and put on your helmets! Furbish the spears, and put on your chest plates! 

#### Jeremiah 46:5 Why is it that they are terrified and retreat to the rear? because their strong ones shall be beaten; {a flight into exile they fled}, and they shall not return compassing round about, says the LORD. 

#### Jeremiah 46:6 Let not {flee the nimble}, and let not {be rescued the strong} by the north! The ones by the river Euphrates are weakened and have fallen. 

#### Jeremiah 46:7 What is this {as a river that shall ascend}, even as rivers swell up by water? 

#### Jeremiah 46:8 The waters of Egypt {as a river shall ascend}; and he said, I will ascend and cover up the earth; and I will destroy the city and the ones dwelling in it. 

#### Jeremiah 46:9 Mount upon the horses and prepare the chariots! Let come forth the warriors of Ethiopia, and Libyans armed with shields! And ascend, O Lydians, stretch tight the bow! 

#### Jeremiah 46:10 And that day will be to the LORD God of the forces a day of vengeance, to take vengeance on his enemies. And {shall devour the sword}, and be filled, and be intoxicated from their blood. For there is a sacrifice to the LORD of Hosts upon a land of the north at the river Euphrates. 

#### Jeremiah 46:11 Ascend to Gilead, and take balm to the virgin daughter of Egypt! In vain you multiplied your cures; {benefit there is no} to you. 

#### Jeremiah 46:12 {heard The nations} your voice, and {with your cry was filled the earth}. For warrior against warrior is weakened together, {fell both}. 

#### Jeremiah 46:13 What the LORD spoke by the hand of Jeremiah the prophet concerning the coming of Nebuchadnezzar king of Babylon to smite the land of Egypt. 

#### Jeremiah 46:14 Announce in Egypt, and {audible make} in Migdol, and exhort in Memphis! And in Tahpanhes say! Attend to and prepare! for {devoured the sword} your yew tree. 

#### Jeremiah 46:15 Why did he flee after {calf your chosen}? He remained not, for the LORD disabled him. 

#### Jeremiah 46:16 And your multitude weakened and fell; and each {to his neighbor said}, We should rise up and return to our people and unto our fatherland, from the face {sword of the Grecian}. 

#### Jeremiah 46:17 Call the name Pharaoh Necho king of Egypt, Saon Esbeie Moed. 

#### Jeremiah 46:18 As I live, says the king, the LORD of the forces, for as Tabor is in the mountains, and as Carmel is by the sea, he shall come. 

#### Jeremiah 46:19 {items for settlement Make for yourself}, O one dwelling, O daughter of Egypt. For Memphis {for extinction will be}, and shall be called, Woe, by there not existing ones dwelling in her. 

#### Jeremiah 46:20 {is a heifer being bedecked Egypt}, a broken branch from the north came upon her. 

#### Jeremiah 46:21 And her hirelings in her are as calves well fed, being maintained in her; for also they turned and fled with one accord. They did not stand, for the day of destruction came upon them, and the time of their punishment. 

#### Jeremiah 46:22 Her voice is as a serpent hissing, for {in sand they shall go}. With axes they shall come upon her as ones felling wood. 

#### Jeremiah 46:23 You cut down her forest! says the LORD. For in no way should their number be imagined; for it is multiplied above the locust, and there is no number to them. 

#### Jeremiah 46:24 {shall be disgraced The daughter of Egypt}. She is delivered into the hands of the people from the north. 

#### Jeremiah 46:25 Says the LORD of the forces, the God of Israel, Behold, I punish Amon her son by Egypt, and upon her gods, and upon her kings, and upon Pharaoh, and upon the ones relying upon him. 

#### Jeremiah 46:26 And I will give them into the hand of the ones seeking their life, and into the hand of Nebuchadnezzar king of Babylon, and into the hand of his servants. And after these things it shall be as in the {days old}, says the LORD. 

#### Jeremiah 46:27 But you should not be fearful, my servant Jacob, nor should you be terrified Israel. For behold, I deliver you from far off, and your seed from their captivity. And Jacob shall return, and shall be tranquil, and shall sleep, and there will not be one troubling him. 

#### Jeremiah 46:28 You should not fear, my child, Jacob, says the LORD, For {with you am I}. For I will appoint consummation among every nation in which I led you out of there. But you in no way will I appoint to cease, and I will correct you in judgment; but {as innocent I will not acquit you}. 

#### Jeremiah 47:1 And {came the word of the LORD} to Jeremiah the prophet against the Philistines, before the striking of Pharaoh of Gaza. 

#### Jeremiah 47:2 Thus says the LORD, Behold, waters ascend from the north, and will be for a rushing stream, flooding. And it shall flood the land, and the fullness of it; the city and the ones dwelling in it. And {shall cry out the men}, and {shall shout all together the ones dwelling in the land} 

#### Jeremiah 47:3 from the sound of his thrust, from the hoofs of his feet, and from the quake of his chariots, the sound of his wheels. {did not turn Fathers} unto their sons because of the feebleness of their hands, 

#### Jeremiah 47:4 in the day, in the coming one, to destroy all the Philistines, and to obliterate Tyre and Sidon and all the rest of their helpers, for the LORD will utterly destroy the Philistines of the remnants of the islands of Cappadocia. 

#### Jeremiah 47:5 {is come Baldness} upon Gaza; Ashkelon was thrown away, and the remnant of the Anakim. 

#### Jeremiah 47:6 How long will you smite, sword of the the LORD? Until when will you not be still? Restore it unto your sheath! Cause it to rest and be lifted away! 

#### Jeremiah 47:7 How shall it be quiet, and the LORD gave charge to it against Ashkelon, and against the places by the sea, for the remnant to be roused. 

#### Jeremiah 48:1 To Moab, thus said the LORD of the forces, the God of Israel; Woe unto Nebo, for it was destroyed; Kiriathaim was taken; {was shamed the fortification}; it was vanquished. 

#### Jeremiah 48:2 {is not still prancing Moab}. In Heshbon he devised for her bad things. Come and we should cut her from being a nation, and by cessation she shall cease; {behind you shall proceed a sword}. 

#### Jeremiah 48:3 For there is a voice of men crying out of Horonaim, ruin and {destruction great}. 

#### Jeremiah 48:4 Moab is destroyed. Announce in Zogora! 

#### Jeremiah 48:5 for Luhith is filled with weeping. It shall ascend weeping in the way of Horonaim. {a cry of destruction You heard}. 

#### Jeremiah 48:6 Flee and escape with your lives! and you shall be as {donkey a wild} in the wilderness. 

#### Jeremiah 48:7 Since you had relied on your fortresses and in your treasures, then you shall be seized. And Chemosh shall go forth in resettlement -- his priests and his rulers together. 

#### Jeremiah 48:8 And {shall come ruin} upon every city; and a city in no way shall be delivered. And {shall be destroyed the canyon}, and {shall be utterly destroyed the plain}, as the LORD said. 

#### Jeremiah 48:9 Put signs upon Moab, for by an infection she shall be kindled; and all her cities {for an untrodden land shall be}, because of the not being one dwelling in her. 

#### Jeremiah 48:10 Cursed is the one doing the work of the LORD indifferently, and cursed is the one lifting away his sword from blood. 

#### Jeremiah 48:11 Moab rested from boyhood, and is relying upon his glory. He has not poured dregs from receptacle unto receptacle, and into settlement he has not set out. On account of this {stood his taste} with him, his scent dissipated not. 

#### Jeremiah 48:12 On account of this, behold, days come, says the LORD, and I will send to him ones leaning him down, and they shall lean him down, and {his vessels they shall thin out}, and his horns shall break. 

#### Jeremiah 48:13 And Moab shall be disgraced from Chemosh, as {was disgraced the house of Israel} from Beth-el their hope, having relied upon themselves. 

#### Jeremiah 48:14 How will you say, We are strong, and each man strong for war. 

#### Jeremiah 48:15 Moab is destroyed. His city and {choice young men his} went down to slaughter, says the king -- the LORD of the forces is his name. 

#### Jeremiah 48:16 Near is the day of Moab to come, and his harm {quickly very}. 

#### Jeremiah 48:17 Move him, all ones round about him! All seeing his name, say! O how is {broken staff the renowned}, the rod of magnificence. 

#### Jeremiah 48:18 Come down from glory, and sit {in wetness being sat down}, O daughter of Dibon! for Moab is destroyed; one ascended unto you laying waste your fortress. 

#### Jeremiah 48:19 Upon the way stand and look! O one sitting down in Aroer. And ask the one fleeing and escaping! And say, What happened? 

#### Jeremiah 48:20 Moab was disgraced, for he is broken. Shriek and cry out! Announce in Arnon! that Moab is destroyed 

#### Jeremiah 48:21 and judgment is come unto the land of Misor, upon Holon, and upon Jahazah, and upon Mephaath, 

#### Jeremiah 48:22 and upon Dibon, and upon Nebo, and upon the house of Diblathaim, 

#### Jeremiah 48:23 and upon Kiriathaim, and upon the house of Gamul, and upon the house of Meon, 

#### Jeremiah 48:24 and upon Kerioth, and upon Bozrah, and upon all the cities of Moab -- the ones at a distance, and the ones near. 

#### Jeremiah 48:25 {was broken The horn of Moab}, and his forearm was destroyed, says the LORD. 

#### Jeremiah 48:26 Intoxicate him! for {against the LORD he was magnified}. And Moab shall strike with his hand, and will be for laughter, even himself, 

#### Jeremiah 48:27 and to us for a joke it was to you, O Israel, and among your stealth he was found, for you waged war along with him. 

#### Jeremiah 48:28 {left the cities and lived in rocks The ones dwelling in Moab}; they became as doves nesting in rocks, at the mouth of a pit. 

#### Jeremiah 48:29 I heard the insolence of Moab (he insulted exceedingly) and his insult and his pride; and {was raised up high his heart}. 

#### Jeremiah 48:30 But I know, says the LORD, of his works; is it not enough for him? Is it not thus he did? 

#### Jeremiah 48:31 On account of this {for Moab shriek} on all sides! Yell over men of Keir Heres of squalid conditions! 

#### Jeremiah 48:32 As weeping of Jazer, I shall weep over you. O grapevine of Sibmah, your vine branches went through the sea; {city of Jazer they touched}. Upon your autumn fruits and upon your grape gatherers ruin fell. 

#### Jeremiah 48:33 {was seized Cause for joy}, and gladness from Carmel, even from the land of the Moabites; and wine in your wine vats {by morning they treaded not}, nor at evening. They did not make a joyful acclamation. 

#### Jeremiah 48:34 From a cry of Heshbon unto Elealeh, even unto Jahaz, they gave out their voice; from Zoar unto Horonaim, even as a heifer of three years. For also the water of Nimrim {for burning will be}. 

#### Jeremiah 48:35 And I will destroy Moab, says the LORD, the one ascending unto the shrine and burning incense to his gods. 

#### Jeremiah 48:36 On account of this the heart of Moab {as pipes shall resonate}; and my heart {against men of Keir Heres as a pipe shall resonate}. On account of this, what he procured perished from man. 

#### Jeremiah 48:37 Every head in every place shall be shaved, and every beard shall be shaved, and all hands shall beat their chest, and upon every loin there shall be sackcloth, 

#### Jeremiah 48:38 even upon all the roofs of Moab, and upon its squares. For I broke Moab, says the LORD, as a receptacle of which there is no need of it. 

#### Jeremiah 48:39 O how he reconciled. O how {turned his back Moab}. {was shamed and became Moab} for laughter, and an object of anger to all the ones round about her. 

#### Jeremiah 48:40 For thus said the LORD, As an eagle, he shall spread and stetch out his wings for Moab. 

#### Jeremiah 48:41 Kerioth was taken, and the fortresses were seized. And {shall be the heart of the might of Moab} in that day as the heart of a woman in travail. 

#### Jeremiah 48:42 And Moab shall be destroyed from being a multitude, for {against the LORD it magnified itself}. 

#### Jeremiah 48:43 A snare, and fear, and a pit, are upon you, O one settled of Moab, says the LORD. 

#### Jeremiah 48:44 The one fleeing from the face of fear shall fall into the cesspool; and the one ascending from out of the cesspool even shall be seized in the snare. For I shall bring these things upon Moab in the year of her visitation, says the LORD. 

#### Jeremiah 48:45 In the shadow of Heshbon they stopped -- of the force fleeing. For fire came forth from Heshbon, and a flame from the midst of Sihon, and it devoured the side of Moab, and the top of the sons of Saon. 

#### Jeremiah 48:46 Woe to you Moab. {were destroyed the people of Chemosh}. For they took your sons and your daughters for captivity. 

#### Jeremiah 48:47 And I shall return the captivity of Moab in the last days, says the LORD. Unto this is the judgment of Moab. 

#### Jeremiah 49:1 To the sons of Ammon, thus said the LORD, {no sons Are there} in Israel? or {inheriting no one is there} of them? Why did Milcom inherit Gad, and their people {in their cities dwell}? 

#### Jeremiah 49:2 On account of this, behold, days come, says the LORD, and I shall cause to be heard upon Rabbah of the sons of Ammon a tumult of war. And they shall be for an untrodden land, and for destruction. And her shrines {by fire shall be incinerated}, and Israel shall inherit his rule, says the LORD. 

#### Jeremiah 49:3 Shout, O Heshbon! for Ai was destroyed. Cry out, O daughters of Rabbah! Gird on sackcloths! Be possessed, and lament over Milcom! For in resettlement {shall proceed his priests and his rulers} together. 

#### Jeremiah 49:4 Why do you exult in Emakeim, O daughter of the audacity, the one relying upon her treasures; the one saying, Who shall come to me? 

#### Jeremiah 49:5 Behold, I will bring upon you fear, said the LORD of the forces, from all of your adjacent places. And you shall be scattered each unto his front, and there shall not be one gathering the runaways. 

#### Jeremiah 49:6 And after these things I will return the captivity of the sons of Ammon, says the LORD. 

#### Jeremiah 49:7 To Edom, thus says the LORD, There is no more wisdom in Teman. {was destroyed The counsel of experts}. {was undone Their wisdom}. 

#### Jeremiah 49:8 {was beguiled Their place}. Deepen to yourselves into sitting, O ones dwelling in Dedan, for {difficult he made}; I led him in the time which I visited against him. 

#### Jeremiah 49:9 For grape gatherers came to you -- the ones who shall not leave behind to you vestiges. As thieves in the night they shall put their hands. 

#### Jeremiah 49:10 For I dragged down Esau; I uncovered their hidden things; {to hide in no way shall they be able}; they were destroyed by the hand of his brother, and his neighbor; and he is not. 

#### Jeremiah 49:11 Let {be left behind your orphan} that he should live, and I shall enliven, and your widows {upon me shall hope}. 

#### Jeremiah 49:12 For thus says the LORD, Behold, the ones which were not by law to drink the cup, drank; and you for being acquitted in no way shall be acquitted; for by drinking you shall drink. 

#### Jeremiah 49:13 For according to myself I swear by an oath, says the LORD, that for an untrodden land, and for scorning, and for a curse, you will be in the midst of her; and all her cities shall be wildernesses into eon. 

#### Jeremiah 49:14 In hearing, I heard from the LORD, and {messengers unto nations he sent}, saying, Gather together, and come to her! Rise up for war! 

#### Jeremiah 49:15 Behold, {to be small I have appointed you} among nations, despicable among men. 

#### Jeremiah 49:16 Your play took in hand against you; audacity of your heart deposed holes of rocks, it seized the strength {hill of a high}. For if you should raise up high {as an eagle your nest}, says the LORD, from there I will lower you. 

#### Jeremiah 49:17 And Edom will be for an untrodden land. All the ones coming upon her shall be amazed, and shall whistle over all her calamities. 

#### Jeremiah 49:18 As {were eradicated Sodom and Gomorrah and her sojourners}, said the LORD, in no way shall {sit there a man}, nor in any way should {dwell there a son of man}. 

#### Jeremiah 49:19 Behold, as a lion he shall ascend from out of the midst of the Jordan unto the place of Aitham. For quickly I will drive them from her. And {the young men against her you set}! For who is as I? And who shall oppose me? And who is this shepherd who shall stand in front of me? 

#### Jeremiah 49:20 On account of this, hear the plan of the LORD! which he planned against Edom; and his device which he devised against the ones dwelling Teman. Surely {shall be scraped away the least of the sheep}. Surely {shall be made impassable for them their resting-place}? 

#### Jeremiah 49:21 From the sound of their downfall {was shaken the earth}. Your cry in the sea was heard. 

#### Jeremiah 49:22 Behold, as an eagle he shall ascend, and shall see, and shall stretch out the wings against her fortresses. And {will be the heart of the strong ones of Edom} in that day as the heart of a woman travailing. 

#### Jeremiah 49:23 To Damascus. Hamath was disgraced and Arpad; for they heard {report an evil}. They were startled; they were enraged; {to rest in no way shall they be able}. 

#### Jeremiah 49:24 Damascus was enfeebled; she was turned to flight; trembling took hold of her; straitness and grief constrained her as one being in travail. 

#### Jeremiah 49:25 O how was she not abandoned, {city praised}, the town being loved. 

#### Jeremiah 49:26 On account of this, {shall fall young men} in your squares; and all the men, your warriors, shall fall in that day, says the LORD of the forces. 

#### Jeremiah 49:27 And I will kindle a fire in the wall of Damascus, and it shall devour the plaza of the son of Hadad. 

#### Jeremiah 49:28 To Kedar and to the queen of the courtyard which {struck Nebuchadnezzar king of Babylon}. Thus said the LORD, Rise up and ascend unto Kedar, and strike the sons of Kedem! 

#### Jeremiah 49:29 {their tents and their sheep They shall take}, their garments and all their vessels; and {their camels they shall take} for themselves. And you call upon them destruction round about! 

#### Jeremiah 49:30 Flee exceedingly! Deepen into sitting! sitting down in the courtyard, says the LORD. For {planned against you Nebuchadnezzar king of Babylon} a plan, and devised against you a device. 

#### Jeremiah 49:31 Rise up and ascend upon {nation a stable}! one sitting down for respite, which there are no doors nor bars -- alone they rest up. 

#### Jeremiah 49:32 And {will be their camels} for plunder, and the multitude of their cattle will be for destruction. And I shall winnow them with every wind, being shaven in front of them; from every side of them I will bring their enemy routing them, said the LORD. 

#### Jeremiah 49:33 And {will be the courtyard} for a pastime of ostriches, and an untrodden place unto the eon; in no way shall {be seated there a man}, nor in any way should {dwell there a son of man}. 

#### Jeremiah 49:34 And came to pass the word of the LORD to Jeremiah the prophet against Elam, in the beginning of the reign of Zedekiah king of Judah, saying, 

#### Jeremiah 49:35 Thus says the LORD of the forces, Behold, I break the bow of Elam, the source of their dominions. 

#### Jeremiah 49:36 And I shall bring upon Elam four winds from the four uttermost parts of the heaven; and I will scatter them in all these winds; and there will not be a nation which shall not come -- the ones being pushing out of Elam. 

#### Jeremiah 49:37 And I shall terrify them before their enemies, of the ones seeking their life. And I will bring upon them evil according to the anger of my rage, says the LORD. And I will send {as successor after them my sword}, until the completely consuming them. 

#### Jeremiah 49:38 And I will put my throne in Elam, and I will send out from there a king and great men, says the LORD. 

#### Jeremiah 49:39 And it will be at the latter ends of the days I will return the captivity of Elam, says the LORD. 

#### Jeremiah 50:1 The word of the LORD which he spoke against Babylon, and against the land of the Chaldeans, by the hand of Jeremiah the prophet. 

#### Jeremiah 50:2 Announce among the nations, and {audible make it}! Lift up a sign and {audible make it}! And you should not hide it. Say! Babylon is captured. Bel was disgraced. Merodach was delivered up. {were shamed their carvings}. {were delivered up Their idols}. 

#### Jeremiah 50:3 For ascended upon her a nation from the north. This one put her land for extinction, and there will not be one dwelling in her from man and beast. 

#### Jeremiah 50:4 They shook and went; in those days, and in that time, says the LORD, {shall come the sons of Israel}; they and the sons of Judah together. Proceeding and weeping they shall go {the LORD their God seeking}. 

#### Jeremiah 50:5 {unto Zion They shall ask the way}; for here {their face they shall set}, and they shall come and shall take refuge with the LORD; {covenant for the everlasting} shall not be forgotten. 

#### Jeremiah 50:6 {sheep perishing became My people}; their shepherds pushed them out; {upon the mountains they led them astray}; from mountain unto hill they set out, they forgot their fold. 

#### Jeremiah 50:7 All the ones finding them consumed them. Their enemies said, We should not spare them, because they sinned against the LORD, the pasture of righteousness to the one gathering their fathers -- the LORD. 

#### Jeremiah 50:8 Be separated from out of the midst of Babylon, and from the land of the Chaldeans! And go forth and become as dragons in front of sheep! 

#### Jeremiah 50:9 For behold, I raise up against Babylon gatherings {nations of great} from out of the land of the north, and they shall deploy against her. From there she shall be captured as the arrow {warrior of an expert} shall not return empty. 

#### Jeremiah 50:10 And {will be the Chaldeans} for plunder; all the ones despoiling her will be filled up, says the LORD. 

#### Jeremiah 50:11 For you were glad, and gloried over plundering of my inheritance. For you leaped as young bullocks in a pasture, and gored as bulls. 

#### Jeremiah 50:12 {shamed Your mother is exceedingly}; {felt shame the one giving birth to you}. Behold, the last of the nations shall be desolate and untrodden. 

#### Jeremiah 50:13 From the anger of the LORD it shall not be dwelt in, and {will be for extinction all}. And all traveling through Babylon shall look downcast, and shall whistle at all her calamity. 

#### Jeremiah 50:14 Deploy against Babylon round about, all stretching the bow! Shoot against her! Spare not against her your bows! for against the LORD she sinned. 

#### Jeremiah 50:15 And secure her! {were disabled Her hands}; {fell the parapets}; {was razed her wall}. For {vengeance by God it is}. Take vengeance against her. As she did, you do to her! 

#### Jeremiah 50:16 Utterly destroy the seed from out of Babylon! the one holding the sickle in the time of harvest, from in front of the Grecian sword. Each unto his people shall return, and each unto his land shall flee. 

#### Jeremiah 50:17 {sheep is a wandering Israel}; lions pushed him out. The {first devoured him king of Assyria}, and this one afterwards devoured his bones -- the king of Babylon. 

#### Jeremiah 50:18 On account of this, thus says the LORD of the forces, the God of Israel, Behold, I take vengeance against the king of Babylon and his land, as I took vengeance against the king of Assyria. 

#### Jeremiah 50:19 And I will restore Israel unto his pasture. And he shall feed on Carmel, and in Bashan, and on mount Ephraim, and in Gilead, and {shall be satisfied his soul}. 

#### Jeremiah 50:20 In those days, and in that time, says the LORD, they shall seek the unrighteousness of Israel, and it will not exist. And they shall seek the sins of Judah, and in no way shall they be found. For {kindness I will be} to the ones being left behind. 

#### Jeremiah 50:21 Upon the land, Bitterly, mount up against her! And against the ones dwelling in her punish by sword, and obliterate! says the LORD. And do according to all as much as I give charge to you! 

#### Jeremiah 50:22 The sound of war and {destruction great} in the land of Chaldeans. 

#### Jeremiah 50:23 O how {was broken in pieces and defeated the hammer of all the earth}? O how {became for extinction Babylon} among the nations? 

#### Jeremiah 50:24 They shall attack you. and you shall be captured, O Babylon, and you did not know. You shall be found and taken, for against the LORD you opposed. 

#### Jeremiah 50:25 The LORD opened his treasury, and brought forth the items of his anger; for it is a work for the LORD God of the forces, in the land of Chaldeans. 

#### Jeremiah 50:26 For {have come her times}. Open her storehouses! Search her as a cave, and utterly destroy her! Let {not be her vestige}! 

#### Jeremiah 50:27 Dry up all her fruits, and go down for slaughter! Woe to them, for {is come their day}, and a time of their punishment. 

#### Jeremiah 50:28 A sound of ones fleeing and escaping from out of the land of Babylon, to announce unto Zion the vengeance by the LORD our God -- vengeance of his temple. 

#### Jeremiah 50:29 Exhort {against Babylon many}! to every one stretching tight the bow. Camp upon her round about! Let there not be her escaping! Recompense to her according to her works! According to all as much as she did, you do to her! For {against the LORD she withstood} God, the holy one of Israel. 

#### Jeremiah 50:30 On account of this {shall fall her young men} in her squares, and all the men, her warriors, shall be tossed down in that day, says the LORD. 

#### Jeremiah 50:31 Behold, I am against you, O proud one, says the LORD God of the forces; for {is come your day}, and the time of your punishment. 

#### Jeremiah 50:32 And {shall be weakened your insolence} and shall fall, and there shall not be one raising it. And I will kindle a fire in her forest, and it shall devour all the things round about her. 

#### Jeremiah 50:33 Thus says the LORD of the forces, {have been tyrannized The sons of Israel and the sons of Judah together}. All the ones capturing them tyrannized them; for they did not want to send them out. 

#### Jeremiah 50:34 But the one ransoming them is strong; the LORD almighty is his name. {equitably He will judge} against his opponents, that {should be removed the land}; and he provokes the ones dwelling in Babylon. 

#### Jeremiah 50:35 A sword upon the Chaldeans, says the LORD, and upon the ones dwelling Babylon, and upon her great men, and upon her experts. 

#### Jeremiah 50:36 A sword upon her clairvoyants, and they shall be fools. A sword upon her warriors, and they shall be disabled. 

#### Jeremiah 50:37 A sword upon their horses, and upon their chariots, and upon the consolidation (the one in the midst of her,) and they will be as women. A sword upon her treasures, and they shall be plundered. 

#### Jeremiah 50:38 {upon her water It relied}; and they shall be disgraced. For {a land of carved images it is}, and in the islands they gloried over. 

#### Jeremiah 50:39 On account of this {shall dwell the effigies} among the islands, and there shall dwell in them daughters of sirens. In no way should it be inhabited any longer unto the eon, nor shall it be encamped unto generation and generation. 

#### Jeremiah 50:40 As God eradicated Sodom and Gomorrah and the places adjoining them, said the LORD, in no way shall {dwell there man}, and in no way shall {sojourn there a son of man}. 

#### Jeremiah 50:41 Behold, a people come from the north, and {nation a great}, and {kings many} shall be awakened from the end of the earth. 

#### Jeremiah 50:42 {a bow and a knife They are holding}. They are audacious, and in no way shall they show mercy. Their voice {as the sea shall sound}. Upon horses they shall ride, being prepared as fire for war against you, O daughter of Babylon. 

#### Jeremiah 50:43 {heard The king of Babylon} the report of them, and {were disabled his hands}; affliction held him firmly, pangs as a woman giving birth. 

#### Jeremiah 50:44 Behold, as if a lion, he shall ascend from the Jordan into the place Aithan. For quickly I will drive them from her, and {every young man against her I will set}. For who is as I, and who shall oppose me, and who is this shepherd who shall stand in front of me? 

#### Jeremiah 50:45 On account of this, hear the plan of the LORD! which he has planned against Babylon; and his devices which he devised against the ones dwelling the land of the Chaldeans. Surely {will be utterly destroyed the little lambs of their sheep}. Surely {shall be removed the pasture} from them. 

#### Jeremiah 50:46 For from the sound of the conquest of Babylon {shall be shaken the earth}, and her cry among nations shall be heard. 

#### Jeremiah 51:1 Thus says the LORD, Behold, I awaken against Babylon, and against the Chaldeans dwelling there {wind burning an utterly destroying}. 

#### Jeremiah 51:2 And I shall send against Babylon arrogant ones. And they shall insult her, and lay waste her land. Woe upon Babylon round about in the day of her affliction. 

#### Jeremiah 51:3 Upon her let {stretch the one stretching} his bow, and put on what is his weapons! And spare not against her young men, and obliterate all her force! 

#### Jeremiah 51:4 And {shall fall slain} in the land of the Chaldeans, and men being pierced through will fall from outside of her. 

#### Jeremiah 51:5 For {have not been widowed Israel and Judah} from their God, from the LORD almighty. For their land was filled with injustice from the holy things of Israel. 

#### Jeremiah 51:6 Flee from out of the midst of Babylon, and let {rescue each} his life! You should not be reeling in her iniquity, for {the time of her punishment it is} by the LORD; a recompense he shall recompense to her. 

#### Jeremiah 51:7 A cup of gold is Babylon in the hand of the LORD, intoxicating all the earth; {from her wine drank the nations}; on account of this they are shaken. 

#### Jeremiah 51:8 And suddenly Babylon fell, and was broken. Lament her! Take balm for her hurt! if by any means she should be healed. 

#### Jeremiah 51:9 We medically treated Babylon, and she would not be healed. We should abandon her, and {go forth each} unto his land, for {has approached unto heaven her judgment}. You lifted unto the stars. 

#### Jeremiah 51:10 The LORD brought forth his judgment. Come, for we should announce in Zion the works of the LORD our God. 

#### Jeremiah 51:11 Prepare the bows! fill the quivers! The LORD aroused the spirit of the king of the Medes. For {is against Babylon his anger}, to utterly destroy her. For {vengeance from the LORD it is}; vengeance of his people. 

#### Jeremiah 51:12 Against the walls of Babylon lift up a sign! Set watches! Prepare shields! for {took in hand and he will do the LORD} what he spoke against the ones dwelling Babylon, 

#### Jeremiah 51:13 O ones encamping upon {waters many}, and upon the multitude of her treasures, {is come your limit truly} into your intestines. 

#### Jeremiah 51:14 For the LORD swore by an oath according to his arm, saying, For I shall fill you of men as locusts, and {shall utter a sound against you the ones going down}; 

#### Jeremiah 51:15 the one making the earth with his strength, preparing the world in his wisdom; with his understanding he stretched out the heaven. 

#### Jeremiah 51:16 At his voice he set a great echo of water in the heaven, and he led clouds from the end of the earth. {lightnings for the rain He made}, and he led light from out of his treasuries. 

#### Jeremiah 51:17 {has acted moronish Every man} because of knowledge; {was disgraced every goldsmith} because of their carved images. For {false gods they cast}; there is no breath in them. 

#### Jeremiah 51:18 They are vain works, being scorned. In the time of their visitation they shall be destroyed. 

#### Jeremiah 51:19 Not such is the portion to Jacob; for the one shaping all things, he is his inheritance; the LORD of the forces is his name. 

#### Jeremiah 51:20 You scatter for me items of war; and I shall scatter {by you nations}; and I will lift away {from you kings}. 

#### Jeremiah 51:21 And I will scatter by you the horse and his rider. And I will scatter by you chariots and their riders. 

#### Jeremiah 51:22 And I will scatter by you husband and wife. And I will scatter by you the old man and child. And I will scatter by you the young man and virgin. 

#### Jeremiah 51:23 And I will scatter by you the shepherd and his flock. And I will scatter by you the farmer and his farm. And I will scatter by you governors and your commandants. 

#### Jeremiah 51:24 And I will recompense to Babylon and to all the Chaldeans dwelling there all their evils which they did against Zion before your eyes, says the LORD. 

#### Jeremiah 51:25 Behold, I am against you, {mountain O corrupting}, corrupting all the earth. And I will stretch out my hand against you. And I will roll {downwards from you the rocks}, and I will make you as a mountain being set on fire. 

#### Jeremiah 51:26 And in no way shall they take from you a stone for a corner, and a stone for a foundation. For into {extinction eternal} you will be, says the LORD. 

#### Jeremiah 51:27 Lift up a sign upon the earth! Trump among the nations with a trumpet! Sanctify {against her the nations}! Exhort {against her kingdoms} -- Ararat by me, and to the Ashchenazi! Set against her a range of weapons! Haul against her the horses as {of locusts a multitude}! 

#### Jeremiah 51:28 Haul up {against her nations}! the king of the Medes and all the earth; his leaders, and all of his commandants. 

#### Jeremiah 51:29 {was shaken The earth}, and toiled because {rose up against Babylon the device of the LORD}, to appoint the land of Babylon for extinction, and to not inhabit it. 

#### Jeremiah 51:30 {failed The warrior of Babylon} to wage war, they shall sit there in the citadel. {was enfeebled Their domination}; they became as women; he set on fire her tents; {were broken her bars}. 

#### Jeremiah 51:31 One is pursuing to meet one pursuing to pursue; and one announcing to meet one announcing to announce to the king of Babylon that {is captured his city}. 

#### Jeremiah 51:32 Of the last of his fords were taken, and his assemblages were burned by fire, and his men warriors are coming forth. 

#### Jeremiah 51:33 For thus says the LORD of the forces, the God of Israel; The houses of the king of Babylon {as a threshing-floor in season shall be threshed}; still a little and {shall come her harvest}. 

#### Jeremiah 51:34 He devoured me, {portioned me Nebuchadnezzar king of Babylon}; {overtook me darkness a fine}; he swallowed me down as a dragon; he filled his belly of my delicacies. 

#### Jeremiah 51:35 {pushed me My troubles and my miseries} into Babylon, {shall say the one dwelling Zion}; and, My blood is upon the {dwelling there Chaldeans}, {shall say Jerusalem}. 

#### Jeremiah 51:36 On account of this thus says the LORD, Behold, I shall judge your opponent, and I will avenge your punishment, and I will make desolate her sea, and dry up her spring. 

#### Jeremiah 51:37 And Babylon will be for extinction, a dwelling of dragons, an extinction hissing, and it shall not be inhabited. 

#### Jeremiah 51:38 As lions they were aroused together, and as cubs of lions. 

#### Jeremiah 51:39 In their heat I will give to them a drink, and I shall intoxicate them so that they should be stupefied, and should sleep {sleep an everlasting}, and no way should they be roused, says the LORD. 

#### Jeremiah 51:40 I shall bring them down as lambs to slaughter, and as rams with kids. 

#### Jeremiah 51:41 O how Sheshach is captured, and {is hunted the boasting of all the earth}. O how Babylon became for extinction among the nations. 

#### Jeremiah 51:42 {ascended upon Babylon The sea} with the sound of its waves, and she was covered up. 

#### Jeremiah 51:43 {became Her cities} for extinction, {land a waterless and untrodden}. There shall not dwell in her not one thing, nor should there rest up in her a son of man. 

#### Jeremiah 51:44 And I shall take vengeance against Babylon, and I will bring forth what she swallowed down from out of her mouth; and in no way should {gather to her any more the nations}. And even the wall of Babylon shall fall. 

#### Jeremiah 51:45 Come forth from his midst my people, and let each deliver his own life from the anger of the rage of the LORD! 

#### Jeremiah 51:46 Lest at any time {should be consumed your heart}, and you should be afraid on account of the report which shall be heard in the land, and {shall come in a year the report}, and after the year another report; misery and iniquity over the land, and one dominating over the one dominating. 

#### Jeremiah 51:47 On account of this, behold, days come, and I shall take vengeance upon the carvings of Babylon, and all their land shall be made ashamed, all her slain shall fall in the midst of her. 

#### Jeremiah 51:48 And shall be glad over Babylon the heavens and the earth, and all the ones in them. For from the north comes to him ones utterly destroying, says the LORD. 

#### Jeremiah 51:49 And even as Babylon {to fall acted} of the ones slain of Israel, also in Babylon {shall fall the slain of all the earth}. 

#### Jeremiah 51:50 O ones being rescued from the broadsword, go and do not stand! Make mention, O ones far off, of the LORD, and let Jerusalem ascend upon your heart! 

#### Jeremiah 51:51 We were ashamed for we heard our scorning. {covered up Dishonor} our face. For {entered foreigners} into our holy places, into the house of the LORD. 

#### Jeremiah 51:52 On account of this, behold, days come, says the LORD, and I will take vengeance against her carved images. And in all her land {shall fall the slain}. 

#### Jeremiah 51:53 For though Babylon should ascend as the heaven, and though she should fortify the height of her strength; from me shall come ones utterly destroying her, says the LORD. 

#### Jeremiah 51:54 The sound of a cry in Babylon, and {destruction great} in the land of Chaldeans. 

#### Jeremiah 51:55 For the LORD utterly destroyed Babylon. And he destroyed from her {voice a great} sounding as {waters many}; he gave {for ruin her voice}. 

#### Jeremiah 51:56 For {came upon Babylon misery}; {captured her warriors}; {was terrified their bow}; for God recompenses to them. 

#### Jeremiah 51:57 The LORD recompenses to her the recompense, and he shall intoxicate {by intoxication her governors}, and her wise men, and her commandants, says the king -- the LORD almighty is his name. 

#### Jeremiah 51:58 Thus says the LORD almighty, The wall of Babylon was widened; by razing it shall be razed, and {gates her high} by fire shall be set on fire; and {shall tire peoples} in vanity, and nations {in their rule shall fail}. 

#### Jeremiah 51:59 The word which the LORD gave charge to Jeremiah the prophet to say to Seraiah son of Neriah, son of Maaseiah when he went with Zedekiah the king of Judah into Babylon in the {year fourth} of his kingdom. And Seraiah was ruler of the gifts. 

#### Jeremiah 51:60 And Jeremiah wrote all the evils which shall come upon Babylon in a scroll; all these words being written against Babylon. 

#### Jeremiah 51:61 And Jeremiah said to Seraiah, Whenever you should come into Babylon, and shall see, and shall read all these words; 

#### Jeremiah 51:62 then you shall say, O LORD, you spoke against this place, to utterly destroy it, and to not be in it any dwelling from man unto beast, for {an extinction into the eon it will be}. 

#### Jeremiah 51:63 And it will be whenever you shall cease to read this scroll, that you shall fasten upon it a stone, and shall toss it into the midst of the Euphrates, 

#### Jeremiah 51:64 and shall say, So shall Babylon descend, and in no way shall she rise up from in front of the evils which I bring upon her, and it shall vanish. Until this are the words of Jeremiah. 

#### Jeremiah 52:1 Being the twentieth and one year of Zedekiah in his taking reign, and {eleven years he reigned} in Jerusalem. And the name of his mother was Hamutal daughter of Jeremiah of Libnah. 

#### Jeremiah 52:2 And he did the wicked thing before the LORD according to all as much as Jehoiakim did. 

#### Jeremiah 52:3 For the wrath of the LORD was in Jerusalem and in Judah, until of which time the throwing them off from his face, and Zedekiah separated against the king of Babylon. 

#### Jeremiah 52:4 And it came to pass in the {year ninth} of his kingdom, in {month the tenth}, on the tenth of the month, {came Nebuchadnezzar king of Babylon}, and all his force against Jerusalem. And they encamped by it, and they built against it a rampart round about. 

#### Jeremiah 52:5 And {came the city} into conflict until the eleventh year to king Zedekiah. 

#### Jeremiah 52:6 In {month the fourth}, the ninth of the month, even {was solidified the famine} in the city, and there were no bread loaves to the people of the land. 

#### Jeremiah 52:7 And {was cut through the city}, and all the men warriors fled and went forth by night according to the way of the gate in the middle of the wall, and the area around the wall, which was next to the garden of the king; (and the Chaldeans were upon the city round about) and they went by the way into the wilderness. 

#### Jeremiah 52:8 And {pursued the force of the Chaldeans} after the king, and overtook him on the other side of Jericho. And all his servants were dispersed away from him. 

#### Jeremiah 52:9 And they seized the king, and led him to the king of Babylon in Riblah in the land of Hamath; and he spoke to him with judgment. 

#### Jeremiah 52:10 And {slew the king of Babylon} the sons of Zedekiah in front of his eyes. And all the rulers of Judah he slew in Riblah. 

#### Jeremiah 52:11 And the eyes of Zedekiah were blinded; and he bound him in shackles, and {led him the king of Babylon} into Babylon, and put him into {house the mill} until the day of which he died. 

#### Jeremiah 52:12 And in the {month fifth}, the tenth of the month, came Nabuzar-ardan the chief guard (the one standing in front of the king of Babylon) unto Jerusalem. 

#### Jeremiah 52:13 And he burnt the house of the LORD, and the house of the king, and all the houses of the city; even all {houses the great} he burnt with fire. 

#### Jeremiah 52:14 And every wall of Jerusalem round about was demolished by the force of the Chaldeans with the chief guard. 

#### Jeremiah 52:15 And from the needy of the people, and the rest of the people, and the ones being left behind in the city, and the ones falling in, the ones who fell to the king of Babylon, and the extra of the multitude {moved the chief guard}. 

#### Jeremiah 52:16 And {some from the poor of the land left behind the chief guard} for vine dressers and for farmers. 

#### Jeremiah 52:17 And the columns, the ones of brass, the ones in the house of the LORD, and the bases, and the {sea brass}, the one in the house of the LORD {broke the Chaldeans}. And they took of their brass unto Babylon. 

#### Jeremiah 52:18 And the rim, and the bowls, and the meat hooks, and all the items of brass in which they officiated by them; 

#### Jeremiah 52:19 even the silver things, and the snuffers, and the oil flasks, and the lamp-stands, and the incense pans, and the cups -- which was gold by gold, and which was silver by silver {took the chief guard}; 

#### Jeremiah 52:20 and the {columns two}, and the {sea one}, and the {calves twelve} of brass underneath the sea, which {made king Solomon} for the house of the LORD. {was not known The weight of their brass}. 

#### Jeremiah 52:21 And the columns -- eighteen cubits was the height of the {column one}, and a string measure of twelve cubits surrounded it, and its thickness {fingers was of four} round about. 

#### Jeremiah 52:22 And the molding upon them was of brass, and {was five cubits the length}, superior of the molding of the one. And a latticed work and pomegranates were upon the molding round about, all of brass; according to these things was {column the second} and pomegranates. 

#### Jeremiah 52:23 And there were the pomegranates -- ninety-six to the one part; and there were in all the pomegranates upon the lattice work round about a hundred. 

#### Jeremiah 52:24 And {took the chief guard} Seraiah the {priest foremost}, and Zephaniah the priest being second, and the three of the ones guarding the way. 

#### Jeremiah 52:25 And from the city he took {eunuch one} who was supervisor of the men of the warriors, and seven {men famous} of the ones in front of the king, of the ones being found in the city, and the scribe of the forces, the one acting as scribe to the people of the land, and sixty men from out of the people of the land, of the ones being found in the midst of the city. 

#### Jeremiah 52:26 And {took them Nabuzar-ardan the chief guard}, and he led them to the king of Babylon in Riblah. 

#### Jeremiah 52:27 And {struck them the king of Babylon} in Riblah in the land of Hamath. And Judah was transferred from its land. 

#### Jeremiah 52:28 This is the people whom Nebuchadnezzar transferred in {year the seventh}, of Jews -- three thousand and twenty-three. 

#### Jeremiah 52:29 In {year the eighth and tenth} of Nebuchadnezzar he transferred from Jerusalem {souls eight hundred thirty two}. 

#### Jeremiah 52:30 In {year the third and twentieth} of Nebuchadnezzar, {transferred the chief guard} of Jews {souls seven hundred forty-five}. All the souls four thousand and six hundred. 

#### Jeremiah 52:31 And it came to pass in the thirtieth and seventh year of the resettling of Jehoiakim king of Judah, in the twelfth month, on the fifth and twentieth day of the month, {took Evil-merodach king of Babylon}, in the year in which he took reign, the head of Jehoiakim king Judah, and led him from out of the house of which he was guarded. 

#### Jeremiah 52:32 And he spoke to him graciously. And he put his throne above the thrones of the kings, of the ones with him in Babylon. 

#### Jeremiah 52:33 And he changed {apparel his prison}. And he ate bread always in front of him all the days which he lived. 

#### Jeremiah 52:34 And the rate {to him given always} by the king of Babylon continued from day to day until the day of which he died.