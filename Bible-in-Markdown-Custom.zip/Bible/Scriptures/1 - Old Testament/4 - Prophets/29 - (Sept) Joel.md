#### Joel 1:1 The word of the LORD which came to Joel the son of Pethuel. 

#### Joel 1:2 Hear these things, O elders, and give ear all dwelling the land! Have {taken place such things} in your days, or in the days of your fathers? 

#### Joel 1:3 Concerning them, {to your children describe}, and your children to their children, and their children unto {generation another}! 

#### Joel 1:4 The things remaining of the caterpillar {devoured the locust}; and the things remaining of the locust {devoured the grasshopper}; and the things remaining of the grasshopper {devoured the blight}. 

#### Joel 1:5 Sober up, O ones being intoxicated from their wine! Weep and wail all drinking the wine unto intoxication! for it was lifted away from your mouth. 

#### Joel 1:6 For a nation ascended upon my land, one strong and innumerable. His teeth {teeth are as lion's}, and his molars as cubs. 

#### Joel 1:7 He appointed my grapevine for extinction, and my fig-trees for a splinter. In searching he searched it, and tossed it down; he whitened its branches. 

#### Joel 1:8 Wail to me more than a bride being girded with sackcloth for the husband of her virginity. 

#### Joel 1:9 {have been lifted away The sacrifice and the libation offering} from the house of the LORD. Mourn, O priests! ministers of the LORD, 

#### Joel 1:10 for {languish the plains}. Mourn, O earth, for {languishes the grain}! {was dried up the wine}, {lessened the olive oil}. 

#### Joel 1:11 {were withered The farmers}. Wail for your possessions, for the wheat and barley; for {he has destroyed the gathering of crops} from out of the field! 

#### Joel 1:12 The grapevine was dried up, and the fig-trees were lessened; pomegranate, and palm, and apple and all the trees of the field were dried up; for {shamed joy the sons of men}. 

#### Joel 1:13 Gird and beat yourselves, O priests! Wail, O ones ministering at the altar! Enter, sleep in sackcloths! O ones ministering to God. for {are at a distance from the house of your God the sacrifice offering and libation offering}. 

#### Joel 1:14 Sanctify a fast! Proclaim a sacred service! Bring together elders! all the ones dwelling the land, into the house of the LORD your God. And cry out to the LORD fervently! 

#### Joel 1:15 Woe, woe, woe for the day, for {is near the day of the LORD}, and as misery from misery, it shall come. 

#### Joel 1:16 Were not {in front of your eyes foods lifted away}? from out of the house of your God gladness and joy? 

#### Joel 1:17 {leap Heifers} in their stables, {are obliterated treasures}, {were razed wine vats}, for {was dried up the grain}. 

#### Joel 1:18 What shall we put aside for ourselves? {weep The herds of oxen}, for no {exists pasture} to them; and the flocks of the sheep were obliterated. 

#### Joel 1:19 To you, O LORD, we shall yell. For fire consumed the beautiful things of the wilderness, and a flame incinerated all the trees of the field. 

#### Joel 1:20 And the cattle of the plain look up to you, for {were dried up the releases of waters}, and fire devoured the beautiful things of the wilderness. 

#### Joel 2:1 Trump with trumpet in Zion! Proclaim in {mountain my holy}! and confound all the ones dwelling in the land! for {is at hand the day of the LORD} -- for it is near. 

#### Joel 2:2 A day of darkness and dimness, a day of cloud and fog, as the dawn, there shall be poured upon the mountains {people a vast and strong}, likened to it has not happened from the eon, and after it there shall not be added unto years, for generations of generations. 

#### Joel 2:3 The things before him {fire a consuming}; and behind him {being lighted a flame}. As a paradise of delicacy is the earth before his face, and the things behind him a plain of extinction; and ones escaping will not be to him. 

#### Joel 2:4 As a sight of horses so the appearance of them; and as horsemen so they shall pursue. 

#### Joel 2:5 As the sound of chariots upon the tops of the mountains they shall leap, even as the sound of a flame of fire devouring stubble, and as {people a vast and strong} being deployed for battle. 

#### Joel 2:6 From in front of him {shall be destroyed the people}; every face as a burnt earthen pot. 

#### Joel 2:7 As warriors, they shall run; and as men of war, they shall ascend upon the walls; and each in his way shall go, and no way shall they turn aside from their roads. 

#### Joel 2:8 And each {from his brother shall not be at a distance}; {being burdened with their shields they shall go}, and with arrows they shall fall, and no way shall they be ended. 

#### Joel 2:9 {the city They shall take hold of}, and upon the walls they shall run; unto the houses they shall ascend, and through the windows they shall enter as thieves. 

#### Joel 2:10 Before his face {shall be confounded the earth}, and {shall be shaken the heaven}; the sun and the moon shall darken, and the stars shall let down their brightness. 

#### Joel 2:11 And the LORD shall give forth his voice from in front of his force; for {great is exceedingly his camp}; for {are strong works his words}; for great is the day of the LORD, {apparent exceedingly}, and who will be fit for it? 

#### Joel 2:12 And now, says the LORD, Return to me with {entire heart your} in fasting, and weeping, and beating of the breast! 

#### Joel 2:13 And tear your hearts and not your garments! And return to the LORD your God! for {merciful and pitying he is}, lenient and full of mercy, and changing his mind concerning the evils. 

#### Joel 2:14 Who knows if he shall turn and change his mind, and leave behind him a blessing; even a sacrifice offering and a libation offering to the LORD our God? 

#### Joel 2:15 Trump a trumpet in Zion! Sanctify a fast! Proclaim a sacred service! 

#### Joel 2:16 Gather together people! Sanctify an assembly! Choose elders! Gather together infants nursing breasts! Let {go forth the groom} from out of his bedroom, and the bride from out of her nuptial chamber! 

#### Joel 2:17 {between the footing and the altar shall weep The priests ministering} to the LORD. And they shall say, Spare, O LORD, your people! and, You should not give your inheritance unto scorn for the {to rule them nations}; so that {they should not say among the nations}, Where is their God? 

#### Joel 2:18 But the LORD was jealous of his land, and spared his people. 

#### Joel 2:19 And the LORD answered and said to his people, Behold, I shall send out to you the grain, and the wine, and the olive oil, and you shall be filled up of them. And I will not give you up any longer for scorning among the nations. 

#### Joel 2:20 And the one from the north I will drive out from you, and I will push him into {land a waterless}, and I will obliterate his face into the {sea foremost}, and the ones of his rear unto the {sea latter}. And {shall ascend his rottenness}, and {shall ascend his groaning}, for he magnified his works. 

#### Joel 2:21 Be of courage, O land! Rejoice and be glad! for the LORD magnified to act. 

#### Joel 2:22 Be of courage, O cattle of the plain! for {have burst forth the plains of the wilderness}; for the tree bore its fruit; fig-tree and grapevine yielded their strength. 

#### Joel 2:23 And O children of Zion, rejoice and be glad in the LORD your God! for he gave to you the foods for righteousness, and he shall rain to you {rain early} and late, as before. 

#### Joel 2:24 And {shall be filled the threshing-floors} of grain, and {shall be overflowing the vats} of wine and oil. 

#### Joel 2:25 And I will recompense to you for the years which {devoured the blight}, and the grasshopper and locust, and the caterpillar, by {force my great} which I sent out unto you. 

#### Joel 2:26 And you shall eat with solid food, and shall be filled up, and shall praise the name of the LORD your God, who did {among you wonders}. And in no way shall {be disgraced my people} into the eon. 

#### Joel 2:27 And you shall realize that {in the midst of Israel I am}, even I the LORD your God, and there is not any besides me. And in no way shall {be disgraced any longer my people} into the eon. 

#### Joel 2:28 And it will be after these things, I will pour out from my spirit upon all flesh; and {shall prophesy your sons and your daughters}, and your older men {dreams shall dream}, and your young men {visions shall see}. 

#### Joel 2:29 And even upon the manservants, and upon the maidservants, in those days I will pour out from my spirit. 

#### Joel 2:30 And I shall execute miracles in the heaven, and upon the earth -- blood, and fire, and vapor of smoke. 

#### Joel 2:31 The sun shall convert into darkness, and the moon into blood, before the coming of the {day of the LORD great and apparent}. 

#### Joel 2:32 And it will be all who ever shall call upon the name of the LORD shall be delivered. For in mount Zion and in Jerusalem shall be one rescuing, as {said the LORD}; and one announcing good news of which the LORD was called upon. 

#### Joel 3:1 For behold, I in those days and in that time, whenever {shall return the captivity of Judah and Jerusalem}, 

#### Joel 3:2 I will gather all the nations, and I will lead them into the valley of Jehoshaphat. And I will litigate with them there for my people, and my inheritance Israel, whom I dispersed among the nations, even the one {my land who divided}. 

#### Joel 3:3 And {over my people they cast lots}; and gave the boys to harlots, and {the young women sold} for wine, and drank. 

#### Joel 3:4 And what are you to me, O Tyre and Sidon, and all Galilee of the Philistines? Do {a recompense you recompense to me}? or {have resentment do you} to me? Swiftly and quickly I will recompense your recompense upon your heads; 

#### Joel 3:5 because {my silver and my gold you took}, and the chosen things of mine; the good things you carried into your temples. 

#### Joel 3:6 And the sons of Judah, and the sons of Jerusalem you rendered to the sons of the Greeks, so that you should push them from out of their borders. 

#### Joel 3:7 And behold, I will awaken them from out of the place of which you rendered them there; and I will recompense your recompense onto your heads. 

#### Joel 3:8 And I will render your sons and your daughters into the hands of sons of Judah; and they shall render them into captivity, into a nation far at a distance, for the LORD spoke. 

#### Joel 3:9 Proclaim these things among the nations! Sanctify a war! Awaken the warriors! Lead forward and ascend all men of war! 

#### Joel 3:10 Cut up your plows into broadswords, and your sickles into spears! Let the powerless say that, I am strong! 

#### Joel 3:11 Gather together and enter all nations round about! And gather together there! Let the gentle one be a warrior! 

#### Joel 3:12 Awaken and ascend all nations into the valley of Jehoshaphat! for there I will sit to separate all the nations round about. 

#### Joel 3:13 Send out sickles! for {stands by the gathering of the crops}. Enter in! Tread! for {is full the wine vat}. {overflow The wine-vats}, for {are multiplied their evils}. 

#### Joel 3:14 Sounds resounded in the valley of punishment, for {is near the day of the LORD} in the valley of punishment. 

#### Joel 3:15 The sun and the moon shall darken, and the stars shall let down their brightness. 

#### Joel 3:16 But the LORD {from Zion shall shout aloud}, and {from out of Jerusalem shall utter his voice}. And {shall be shaken the heaven and the earth}, but the LORD shall spare his people, and shall strengthen the sons of Israel. 

#### Joel 3:17 And you shall know that I am the LORD your God encamping in Zion, {mountain holy my}. And Jerusalem will be holy, and foreigners shall go through her no longer. 

#### Joel 3:18 And it will be in that day {will trickle down the mountains} sweetness, and the hills shall flow milk, and all the releases of Judah shall flow waters; and a spring {from out of the house of the LORD shall come forth}, and it shall water the rushing stream of the rushes. 

#### Joel 3:19 Egypt {for extinction will be}, and Edom for a plain of extinction, because of iniquities of the sons of Judah, because they poured out blood of the just in their land. 

#### Joel 3:20 But Judea {into the eon shall dwell}, and Jerusalem for generations of generations. 

#### Joel 3:21 And I will require their blood, and no way acquit. And the LORD shall encamp in Zion.