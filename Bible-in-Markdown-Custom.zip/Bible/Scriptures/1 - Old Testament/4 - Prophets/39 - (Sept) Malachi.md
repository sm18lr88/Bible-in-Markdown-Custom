#### Malachi 1:1 The concern of the word of the LORD over Israel by the hand of his messenger. 

#### Malachi 1:2 I loved you, says the LORD. And you said, {in what You loved us}? {not brother Was Esau Jacob's}? says the LORD; and I loved Jacob. 

#### Malachi 1:3 And Esau I detested, and I ordered up his borders for extinction, and his inheritance for domiciles of the wilderness. 

#### Malachi 1:4 Because {will say, Edom}, He was eradicated, and we should return and should rebuild places having been made desolate. Thus says the LORD almighty, They shall build, and I shall eradicate; and it shall be called by them, Borders of lawlessness, and, a people against whom the LORD deployed unto the eon. 

#### Malachi 1:5 And your eyes shall see, and you shall say, The LORD was magnified up above the borders of Israel. 

#### Malachi 1:6 A son glorifies a father, and a servant his master. And if {father am I}, where is my glory? And if {the LORD am I}, where is the fear of me, says the LORD almighty? You, the priests, are the ones treating {as worthless my name}. And you said, {in what We treated as worthless your name}? 

#### Malachi 1:7 In bringing to my altar {bread loaves polluted}. And you say, {in what We polluted}? In your saying, The table of the LORD is polluted; and the things being placed upon it are thereby treated with contempt. 

#### Malachi 1:8 For if you should bring a blind animal for sacrifice, is it not evil? And if you should bring the lame or ill, is it not evil? Bring it indeed to him, to the one leading you; shall he favorably receive you, shall he receive your person, says the LORD almighty, no. 

#### Malachi 1:9 And now, atone the face of your God, and beseech him! By your hands these have taken place. Shall I receive from your person your things, says the LORD almighty, no. 

#### Malachi 1:10 Because even among you {shall be closed the doors}, and you shall not light my altar gratuitously. There is not of me anything wanting among you, says the LORD almighty. A sacrifice I shall not favorably receive from out of your hands. 

#### Malachi 1:11 For from the rising of the sun, and unto the descent, my name was glorified among the nations; and in every place incense is brought in my name -- even {sacrifice a pure}. For great is my name among the nations, says the LORD almighty. 

#### Malachi 1:12 But you profane it in your saying, The table of the LORD is polluted; and {placed upon it are treated with contempt foods his}. 

#### Malachi 1:13 And you said, Behold, it is troublesome. And you blew them away, says the LORD almighty; and you carried in the prey, and the lame, and the troubled. And thus you brought in the sacrifice. Shall I favorably receive them from your hands, says the LORD almighty, no. 

#### Malachi 1:14 And accursed be the man who was mighty, and {existed among his flock a male}, and his vow was upon him, and he sacrifices a thing being corrupted to the LORD. For {king great I am}, says the LORD almighty, and my name is prominent among the nations. 

#### Malachi 2:1 And now this commandment is to you, O priests. 

#### Malachi 2:2 If you should not hearken, and if you should not put it into your heart, to give glory to my name, says the LORD almighty, then I will send upon you the curse, and I will accurse your blessing -- even I will curse it, and it will not be among you, for you put it not to your heart. 

#### Malachi 2:3 Behold, I separate to you the shoulder, and I will disperse dung of the large intestine upon your faces, dung of the large intestine of your holiday feasts; and I will take you away at the same time. 

#### Malachi 2:4 And you shall realize that I sent out to you this commandment, to be my covenant with the Levites, says the LORD almighty. 

#### Malachi 2:5 My covenant was with him, the one of life and of peace; and I gave to him fear to fear me, and from the presence of my name to put him in readiness. 

#### Malachi 2:6 The law of truth was in his mouth, and injustice was not found in his lips. In peace he straightened out to go with me; and many he turned from iniquity. 

#### Malachi 2:7 For lips of priests shall guard knowledge, and {the law they shall seek} from his mouth; for {a messenger of the LORD almighty he is}. 

#### Malachi 2:8 But you turned aside from the way, and you weakened many in following the law; you corrupted the covenant of Levi, says the LORD almighty. 

#### Malachi 2:9 And I have given you over as ones being treated with contempt, and ones being disregarded among all the nations, because you guarded not my ways, but you took persons in the law. 

#### Malachi 2:10 Is there not {father one} of all of you? Did not {God one} create you? For what reason did you abandoned each his brother, to profane the covenant of your fathers? 

#### Malachi 2:11 Judah abandoned, and an abomination took place in Israel and in Jerusalem; for Judah profaned the holy things of the LORD in which he loved, and applied unto alien gods. 

#### Malachi 2:12 The LORD will utterly destroy the man doing these things, until whenever he should be humbled from out of the tents of Jacob, and from out of the ones bringing a sacrifice to the LORD almighty. 

#### Malachi 2:13 And these things which I detested you did. You covered {in tears the altar of the LORD} in weeping and moaning because of troubles, yet thinking it worthy to look upon your sacrifice, or to take as acceptable from out of your hands. 

#### Malachi 2:14 And you said, For what reason? In that the LORD testified between you and between the wife of your youth, whom you abandoned. And she is your partner, and the wife of your covenant. 

#### Malachi 2:15 But did he not {good do}, even a vestige of his spirit? And you said, What other than a seed does God seek? But guard in your spirit, and the wife of your youth do not abandon! 

#### Malachi 2:16 But if by detesting, you should send her forth, says the LORD God of Israel, then {shall cover impiety} over your thoughts, says the LORD God almighty. And keep guard in your spirit, and in no way should you abandon them, 

#### Malachi 2:17 O ones provoking the LORD with your words. And you said, {in what We provoked him}? In your saying, Every one doing wicked is good before the LORD, and in them he thinks well of; and, Where is the God of righteousness? 

#### Malachi 3:1 Behold, I send out my messenger who shall prepare the way before my face. And {shall suddenly come into his temple the LORD whom you seek}, even the messenger of the covenant, whom you want. Behold, he comes, says the LORD almighty. 

#### Malachi 3:2 And who will endure the day of his entrance? Or who shall stand at his apparition? For he enters as fire of a foundry furnace, and as lye of ones washing. 

#### Malachi 3:3 And he shall sit as one casting in a furnace, and one cleansing as it were silver. And he shall cleanse the sons of Levi, and he shall pour them as the gold and as the silver; and they will be to the LORD ones bringing sacrifices in righteousness. 

#### Malachi 3:4 And {shall please the LORD, the sacrifice of Judah and Jerusalem}, as in the days of the eon; and as the years before. 

#### Malachi 3:5 And I will come forward to you in judgment; and I will be {witness a quick} against the administers of potions, and against the adulterers, and against the ones swearing by an oath in my name for a lie, and against the ones depriving a wage of a hireling, and tyrannizing over the widow, and the ones smiting orphans, and the ones turning aside a right judgment of a foreigner, even they are the ones not fearing me, says the LORD almighty. 

#### Malachi 3:6 For I am the LORD your God; I change not. 

#### Malachi 3:7 But you sons of Jacob are not kept at a distance from the sins of your fathers; you turned aside from my laws, and guarded not. Return to me! and I shall be turned towards you, says the LORD almighty. But you said, In what way should we turn? 

#### Malachi 3:8 Shall {stomp on a man} God, no. For you stomp on me. And you said, {in what We stomped on you}? In that the tenth parts, and the first-fruits {with you are}. 

#### Malachi 3:9 And looking away, you look away, and me you stomp on. 

#### Malachi 3:10 The year is completed, and you carried in all the resources into the storehouses, and there will be the ravaging in your houses. Restore indeed in this, says the LORD almighty! And see if I should not open to you the torrents of the heaven, and pour out to you my blessing until it is enough. 

#### Malachi 3:11 And I will draw apart to you for food, and in no way will I utterly destroy the fruit of the land; and in no way should it be weakened upon your grapevine in the field, says the LORD almighty. 

#### Malachi 3:12 And {shall declare you happy all the nations}. For you will be {land a wanted}, says the LORD almighty. 

#### Malachi 3:13 You weighed down against me by your words, says the LORD. And you said, {in what We spoke ill against you}? 

#### Malachi 3:14 You said, {is vain The one serving God}. and, What more is it that we kept his injunctions, and that we go as supplicants before the face of the LORD almighty? 

#### Malachi 3:15 And now we declare {blessed aliens}; and {are built up all the ones doing lawless deeds}; and they opposed God, and were preserved. 

#### Malachi 3:16 {these things spoke The ones fearing the LORD} each to his neighbor. And the LORD heeded, and hearkened, and wrote a scroll of memorial before him to the ones fearing the LORD, and venerating his name. 

#### Malachi 3:17 And they will be to me, says the LORD almighty, in the day which I prepare for a procurement. And I will select them in which manner {selects a man} his son, the one serving to him. 

#### Malachi 3:18 Then shall you be turned, and you shall see between the just one and the wrongdoer; and between the one serving God and the one not serving to him. 

#### Malachi 4:1 For behold, a day comes burning as an oven; and it shall blaze against them, and {will be all the foreigners}, and all the ones doing lawless deeds, as stubble. And {shall light them the day coming}, says the LORD of the forces; and in no way shall there be left of them root nor vine branch. 

#### Malachi 4:2 And to you, O ones fearing my name, shall arise sun of righteousness, and healing is in his wings; and you shall come forth and shall leap as young calves {from out of bonds being spared}. 

#### Malachi 4:3 And you shall trample the lawless ones; and they will be ashes underneath your feet in the day which I prepare, says the LORD almighty. 

#### Malachi 4:4 Remember the law of Moses my manservant, in so far as I gave charge to him in Horeb for all Israel -- orders and judgments! 

#### Malachi 4:5 And behold, I shall send to you Elijah the prophet before the coming day of the LORD -- the great and apparent; 

#### Malachi 4:6 the one who shall restore the heart of the father to the son, and the heart of a man to his neighbor, lest coming I strike the earth entirely.