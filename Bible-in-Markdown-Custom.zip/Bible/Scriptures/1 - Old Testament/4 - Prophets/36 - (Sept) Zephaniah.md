#### Zephaniah 1:1 The word of the LORD which came to Zephaniah the son of Cushi, son of Gedaliah, son of Amariah, son of Hezekiah, in the days of Josiah son of Amon, king of Judah. 

#### Zephaniah 1:2 In want, let all want from the face of the earth, says the LORD! 

#### Zephaniah 1:3 Let {be wanting man and cattle}; let {be wanting the birds of the heaven}, and the fishes of the sea. And {shall be sickened the impious}. And I will lift away the lawless deeds from the face of the land, says the LORD. 

#### Zephaniah 1:4 And I will stretch out my hand upon Judah and upon all the ones dwelling in Jerusalem. And I will remove from out of this place the names of Baal, and the names of the priests with the consecrated things; 

#### Zephaniah 1:5 even the ones doing obeisance upon the roofs to the military of the heaven, and the ones doing obeisance and the ones swearing by an oath also according to the LORD; and the ones swearing an oath according to their king; 

#### Zephaniah 1:6 and the ones turning aside from the LORD; and the ones not seeking the LORD; and the ones not holding to him. 

#### Zephaniah 1:7 Be cautious before the presence of the LORD God! for {is near the day of the LORD}! For the LORD prepared his sacrifice, and he has sanctified his chosen. 

#### Zephaniah 1:8 And it will be in the day of the sacrifice of the LORD, that I will take vengeance upon the rulers, and upon the house of the king, and upon all the ones putting on {garments alien}. 

#### Zephaniah 1:9 And I will {take vengeance upon all visibly} at the gateways in that day, upon the ones filling the house of the LORD their God with impiety and treachery. 

#### Zephaniah 1:10 And it will be in that day, says the LORD, the sound of a cry from the gate of men piercing, and shrieking of women from the second quarter, and {conflict great} from the hills. 

#### Zephaniah 1:11 Wail! O ones dwelling the place being cut in pieces, for {are like all the people} Canaan, and {were utterly destroyed all the ones lifting up silver}. 

#### Zephaniah 1:12 And it will be in that day, I will search out Jerusalem with a lamp, and I will take vengeance upon the men, of the ones paying no attention to their injunctions; and the ones saying in their hearts, In no way shall the LORD do good, nor shall he inflict evil. 

#### Zephaniah 1:13 And {will be their power} for ravaging, and their houses for extinction. And they shall build houses, but in no way shall they dwell in them. And they shall plant vineyards, and in no way shall they drink of their wine. 

#### Zephaniah 1:14 For {is near day of the LORD the great}, and near {quickly very}. The sound of the day of the LORD {bitter and harsh is ordered up}. 

#### Zephaniah 1:15 {is a mighty day of anger That day}; a day of affliction and distress; a day of misery and extinction; a day of dimness and darkness; a day of cloud and fog; 

#### Zephaniah 1:16 a day of trumpet and a cry against the {cities fortified}, and against the {corners high}. 

#### Zephaniah 1:17 And I will squeeze out the men, and they shall go as blind men, for against the LORD they led into sin, and he shall pour out their blood as dust, and their flesh as dung. 

#### Zephaniah 1:18 And their silver and their gold in no way shall be able to rescue them in the day of the anger of the LORD. And by fire his zeal shall consume all the land. For completion and diligence he will execute it upon all the ones dwelling the land. 

#### Zephaniah 2:1 Be gathered and bound together, O {nation uninstructed}! 

#### Zephaniah 2:2 before your becoming as a flower passing the day; before the coming upon you the wrath of the LORD; before the coming upon you the day of the wrath of the rage of the LORD. 

#### Zephaniah 2:3 Seek the LORD all you humble ones of the earth! {equity Work}, and {righteousness seek}, and answer them accordingly! so that you should be sheltered in the day of the wrath of the LORD. 

#### Zephaniah 2:4 For Gaza will be for plundering, and Ashkelon for extinction, and Ashdod at midday shall be cast forth, and Ekron shall be rooted out. 

#### Zephaniah 2:5 Woe, the ones dwelling the measured out land of the sea -- sojourners of Cretans. The word of the LORD is against you, O Canaan, land of the Philistines; and I will destroy you of your dwelling. 

#### Zephaniah 2:6 And Crete shall be a pasture of flocks, and a haven for sheep. 

#### Zephaniah 2:7 And {will be the measured out piece of land by the sea} for the remnant of the house of Judah; upon them they shall pasture in the houses of Ashkelon; in the afternoon they shall rest up from in front of the sons of Judah; for {shall visit them the LORD their God}; and he shall return their captivity. 

#### Zephaniah 2:8 I heard the scorns of Moab, and the ill-treatment by the sons of Ammon, in which they berated my people, and magnified themselves over my borders. 

#### Zephaniah 2:9 On account of this, as I live, says the LORD of the forces, the God of Israel, that Moab {as Sodom will be}, and the sons of Ammon as Gomorrah, and Damascus ceasing. And it will be as a heap of salt into the eon. And the remnants of my people shall plunder them, and the remnants of my nation shall inherit them. 

#### Zephaniah 2:10 This is to them for their insolence, because they berated and magnified themselves over the LORD almighty. 

#### Zephaniah 2:11 The LORD shall appear against them, and he shall utterly destroy all the gods of the nations of the earth. And they shall do obeisance to him, each from his place -- all the islands of the nations. 

#### Zephaniah 2:12 And you, O Ethiopians, {the slain of my broadsword are}. 

#### Zephaniah 2:13 And he will stretch out his hand against the north. And he shall destroy the Assyrian, and he shall establish Nineveh for {extinction a waterless}, as a wilderness. 

#### Zephaniah 2:14 And {shall feed in the midst of her flocks}, and all the wild beasts of the earth, and chameleons; and hedgehogs {in her fretwork shall make a bed}, and wild beasts to sound out loud in her ditches, and crows in her gatehouses. For {was as the cedar her height}. 

#### Zephaniah 2:15 This is the {city heedless}, the one dwelling upon hope, who says in her heart, I am, and there is none after me any longer. O how it was for extinction, a pasture of wild beasts. Every one traveling through her shall whistle and shall shake his hands. 

#### Zephaniah 3:1 O the prominent and ransomed city, the dove. 

#### Zephaniah 3:2 She did not listen to your voice; she did not take instruction; {upon the LORD she had not relied}, and to her God she did not approach. 

#### Zephaniah 3:3 Her rulers among her are as lions roaring. Her judges are as wolves of Arabia; they did not remain behind into the morning. 

#### Zephaniah 3:4 Her prophets {carried by the wind are men} -- despisers. Her priests profane the holy things, and they are impious against the law. 

#### Zephaniah 3:5 But the { LORD righteous} is in the midst of her, and in no way shall he do an unjust thing. Morning by morning he executes his judgment in light, and it was not concealed. And he does not know injustice by exaction, and neither {by altercation injustice}. 

#### Zephaniah 3:6 I tore down the proud; {were obliterated their corners}; I shall make quite desolate their ways thoroughly, so as to not travel through. {vanished their cities} by reason of no one to exist nor to dwell in them. 

#### Zephaniah 3:7 I said, Furthermore fear me, and receive instruction! and in no way shall you be utterly destroyed from before her eyes, for all as much vengeance as I brought upon her. Prepare! Rise early! {is ruined all their gleaning}. 

#### Zephaniah 3:8 On account of this wait for me, says the LORD, for the day of my rising up, for a testimony! For my judgment shall be for a gathering of nations, to take kings, to pour out upon them {anger of my all}, the anger of my rage. For {by the fire of my zeal shall be consumed all the earth}. 

#### Zephaniah 3:9 For then I will transfer upon the peoples one tongue for her generation, for all to call upon the name of the LORD, to serve him under {yoke one}. 

#### Zephaniah 3:10 From the limits of the rivers of Ethiopia I will welcome the ones of mine having been dispersed; they shall bring sacrifices to me. 

#### Zephaniah 3:11 In that day in no way shall you be disgraced from all of your practices which you were impious against me. For then I shall remove from you the careless attitudes of your insolence, and no longer should you proceed to make great brag over {mountain my holy}. 

#### Zephaniah 3:12 And I will leave behind among you {people a gentle}, and humble; and they shall show reverence at the name of the LORD -- 

#### Zephaniah 3:13 the remnant of Israel; and they shall not commit iniquity, and they shall not speak vanity, and in no way should there be found in their mouth {tongue a deceitful}. For they shall feed, and shall lay in bed, and there will not be one frightening them. 

#### Zephaniah 3:14 Rejoice, O daughter of Zion! Proclaim out loud, O daughter of Jerusalem! Be glad and delight yourself with {entire heart your}, O daughter of Jerusalem! 

#### Zephaniah 3:15 The LORD removed your offences; he has ransomed you from out of the hand of your enemies. The king of Israel -- the LORD in the midst of you. You shall not see the bad things any longer. 

#### Zephaniah 3:16 In that time the LORD shall say to Jerusalem, Be of courage, O Zion, do not neglect your hands! 

#### Zephaniah 3:17 The LORD your God among you; the mighty one shall deliver you; he shall bring upon you gladness, and shall revive you in his affection; and he shall be glad over you with delight as in the day of the holiday feast. 

#### Zephaniah 3:18 And I will gather your ones being broken. Woe, any taken {upon her scorning}. 

#### Zephaniah 3:19 Behold, I will act among you, because of you in that time. And I will deliver her being pressured; and {her being thrust away will take}; and I will establish them for boasting and fame in all the earth. 

#### Zephaniah 3:20 And their enemies shall be disgraced in that time, whenever {well with you I should do}, and in the time whenever I should take you in. For I will make you famous and for boasting among all the peoples of the earth, in my returning your captivity before your eyes, says the LORD.