#### Ecclesiastes 1:1 The sayings of an ecclesiastic, son of David, king of Israel in Jerusalem. 

#### Ecclesiastes 1:2 Folly of follies, said the ecclesiastic, folly of follies; all things are folly. 

#### Ecclesiastes 1:3 What is abundance to man in all his trouble in which he is troubled under the sun? 

#### Ecclesiastes 1:4 A generation goes, and a generation comes, and the earth {into the eon is established}. 

#### Ecclesiastes 1:5 And {rises the sun}, and {goes down the sun}, and {unto its place it draws}. 

#### Ecclesiastes 1:6 In its rising it goes forth to the south, and it circles to the north; {circles circling going the wind}, and at its circuits {returns the wind}. 

#### Ecclesiastes 1:7 All the rushing streams go into the sea, and the sea is not filled up. To the place where the rushing streams went, there they shall return to go again. 

#### Ecclesiastes 1:8 All {words wearied shall not be able a man} to speak; and {shall not be filled up the eye} to see, and {shall not be filled the ear} of hearing. 

#### Ecclesiastes 1:9 What is the thing taking place? the same thing as shall be taking place. And what is the thing being done? the same thing that shall be done; and there is not anything newly made under the sun. 

#### Ecclesiastes 1:10 Who shall speak and shall say? Behold this is new! Already it has happened in the eons to the ones having taken place from before us. 

#### Ecclesiastes 1:11 There is no remembrance to the first things; and indeed to the last things being, there will not be a remembrance of them, with the ones being born at the latter end. 

#### Ecclesiastes 1:12 I an ecclesiastic became king over Israel in Jerusalem. 

#### Ecclesiastes 1:13 And I gave my heart to inquire and to survey by wisdom concerning all things happening under the heaven. For {distraction a wicked gave God} to the sons of men to be distracting to him. 

#### Ecclesiastes 1:14 I beheld all the actions, the ones being done under the sun; and behold, all was folly and a resolve of spirit. 

#### Ecclesiastes 1:15 The thing being perverted is not able to be embellished. And deficiency is not able to be counted. 

#### Ecclesiastes 1:16 I spoke in my heart to say, Behold, I was magnified, and was added wisdom over all who came before me in Jerusalem. And I give my heart to know wisdom and knowledge. 

#### Ecclesiastes 1:17 And my heart beheld much wisdom and knowledge, parables, and higher knowledge. {knew I For} even indeed this is resolve of spirit. 

#### Ecclesiastes 1:18 For in abundance of wisdom is abundance of knowledge; and the one adding knowledge shall add pain. 

#### Ecclesiastes 2:1 I said in my heart, Come now indeed, I will test you with gladness, and therefore know good! And behold, also even this is folly. 

#### Ecclesiastes 2:2 To laughter, I said, Deviation. and to gladness, Why do you do this? 

#### Ecclesiastes 2:3 And I surveyed if my heart would draw {with wine my flesh}; and my heart guided me in wisdom; and to hold upon gladness until I should see what kind was the good to the sons of men, which they shall do under the sun {numbered days of life with their}. 

#### Ecclesiastes 2:4 I magnified my action; I built to myself houses; I planted my vineyards. 

#### Ecclesiastes 2:5 I made to myself gardens and parks; and I planted in them a tree for every fruit. 

#### Ecclesiastes 2:6 I made to myself pools of waters to water by them the grove bursting forth rees. 

#### Ecclesiastes 2:7 I acquired manservants, and maidservants; and native-born servants were born to me; and indeed a possession {herd and flock of a great} became to me above all the ones being before me in Jerusalem. 

#### Ecclesiastes 2:8 I brought together to myself also indeed silver, and indeed gold, and prized possessions of kings and of the places. I prepared to myself male singers and female singers, and amusements of the sons of man; and male wine servers and female wine servers. 

#### Ecclesiastes 2:9 And I became magnified, and proceeded in wisdom past all the ones being before me in Jerusalem; and indeed my wisdom was established to me. 

#### Ecclesiastes 2:10 And all whatever {asked for my eyes} was not at a distance from them. I did not detain my heart from any gladness, for my heart was gladdened in all my effort. And this was my portion of all my effort. 

#### Ecclesiastes 2:11 And I looked upon all my actions, the things which I did by my hands, and on the effort in which I made an effort to do. And behold, all things were folly and a resolve of spirit, and there is no advantage under the sun. 

#### Ecclesiastes 2:12 And I looked around to behold wisdom and deviation and folly; for who is the man who will come after counsel, with as much as they did it? 

#### Ecclesiastes 2:13 And I beheld that there is an advantage to wisdom over folly; as the advantage of the light over the darkness. 

#### Ecclesiastes 2:14 The wise man -- his eyes are in his head; but the fool {in darkness goes}. And I knew, even indeed I, that {event one} shall meet with all them. 

#### Ecclesiastes 2:15 And I said in my heart, As the event of the fool is, even indeed to me it shall meet up with me; and why have I discerned wisdom? And this extra I said in my heart, because the fool from out of abundance speaks, for even indeed this is folly. 

#### Ecclesiastes 2:16 For there is no remembrance of the wise man with the fool in the eon; in so far as already the {days coming} all things are forgotten; and how shall {die the wise man} with the fool? 

#### Ecclesiastes 2:17 And I was detested with life; for evil was upon me -- the action of doing a thing under the sun. For all is folly and a resolve of spirit. 

#### Ecclesiastes 2:18 And I detested all my effort which I made an effort under the sun. For I must leave it to the man coming after me. 

#### Ecclesiastes 2:19 And who knows if he will be a wise man or a fool? And if he exercises authority in all my effort in which I made an effort in, and in which I gained discernment under the sun. Even indeed this is folly. 

#### Ecclesiastes 2:20 And I turned to dismiss my heart upon all effort in which I made an effort under the sun. 

#### Ecclesiastes 2:21 For there is a man that made his effort in wisdom, and in knowledge, and in courage; and a man in whom did not make an effort -- in him he will give to him his portion. And indeed this is folly and {wickedness great} 

#### Ecclesiastes 2:22 What happens to the man in all his effort, and in resolve of his heart in which he makes an effort under the sun? 

#### Ecclesiastes 2:23 For in all his days are pains and rage of his distraction; and indeed in night {does not go to bed heart his}. And indeed this is folly. 

#### Ecclesiastes 2:24 There is not a good thing to man unless to eat and to drink, and to show his soul good in his effort. And indeed this I knew, that {from the hand of God it is}. 

#### Ecclesiastes 2:25 For who shall eat, and who shall drink besides him? 

#### Ecclesiastes 2:26 For to the man, to the one good before his face, he gave wisdom, and knowledge, and gladness. And to the one sinning, he gave distraction to be added and to bring together; so as to give to the good man before the face of God. For even indeed this is folly and resolve of spirit. 

#### Ecclesiastes 3:1 To all the time and season, to every thing under the heaven. 

#### Ecclesiastes 3:2 A season to give birth, and a season to die; a season to plant, and a season to pluck out the thing being planted; 

#### Ecclesiastes 3:3 a season to kill, and a season to heal; a season to demolish, and a season to build; 

#### Ecclesiastes 3:4 a season to weep, and a season to laugh; a season to lament, and a season to dance; 

#### Ecclesiastes 3:5 a season to throw stones, and a season to gather stones; a season to embrace, and a season to be far from embrace; 

#### Ecclesiastes 3:6 a season to seek, and a season to lose; a season to keep, and a season to cast out; 

#### Ecclesiastes 3:7 a season to tear, and a season to sew; a season to be quiet, and a season to speak; 

#### Ecclesiastes 3:8 a season to be fond of, and a season to detest; a season of war, and a season of peace. 

#### Ecclesiastes 3:9 What advantage of the one doing things in which he makes an effort? 

#### Ecclesiastes 3:10 I saw with the distraction which God gave to the sons of men to be distracting to him. 

#### Ecclesiastes 3:11 All which he made is good in his season; and indeed with the eon he gave in their heart, so that {should not find man} the action which God did from beginning till end. 

#### Ecclesiastes 3:12 I knew that there is not good in them, except to be glad and to do good in his life. 

#### Ecclesiastes 3:13 And indeed, every man who shall eat and shall drink and should behold good in all his effort -- {a gift of God it is}. 

#### Ecclesiastes 3:14 I knew that all things as many as God did, they shall be into the eon. Unto them it is not to add, and from them it is not to remove. And God did that they should fear from in front of him. 

#### Ecclesiastes 3:15 The thing becoming, already is; and as much as there is to be, already has become; and God shall seek the thing pursuing. 

#### Ecclesiastes 3:16 And still I beheld under the sun the place of the of judgment -- there the impious one; and a place of the just -- there was the pious one. 

#### Ecclesiastes 3:17 I said in my heart, With the just and with the impious, God will judge, for there is a season for every thing, and for every action there. 

#### Ecclesiastes 3:18 I said in my heart, concerning the speech of the sons of man, that {will examine them God}, and to show that they are beasts. 

#### Ecclesiastes 3:19 And indeed to them the event of the sons of man, and the event of the beast is {event one} to them; as the death of this one, so also the death of this other one; and {breath one} to all. And what abounded the man more than the cattle? Nothing. For all things are folly. 

#### Ecclesiastes 3:20 All things go to {place one}; all things came from the dust, and all things return to the dust. 

#### Ecclesiastes 3:21 And who has known the spirit of the sons of man, if it ascends itself upward? and the spirit of the beast, if it goes down itself below into the earth? 

#### Ecclesiastes 3:22 And I saw that there is no good, except where {shall be glad man} in his actions; for it is his portion. For who will lead him to see in what ever should take place after him? 

#### Ecclesiastes 4:1 And I turned and I beheld all the extortions, the ones happening under the sun. And behold, the tear of the ones being extorted, and there is not one comforting them. And by the hand of ones extorting them was by strength, and there is not one comforting them. 

#### Ecclesiastes 4:2 And I praised all of the ones having died of the ones already dying more than the living, as many as live until the present. 

#### Ecclesiastes 4:3 And better above these two which not yet was born, which knew not all the {action evil} being done under the sun. 

#### Ecclesiastes 4:4 And I beheld all the effort, and all courage of action; for the same zeal of man is from his companion. And indeed this is folly and resolve of spirit. 

#### Ecclesiastes 4:5 The fool embraces his hands, and eats his flesh. 

#### Ecclesiastes 4:6 Better {full a handful} of rest, than {full two handfuls} of trouble and resolve of spirit. 

#### Ecclesiastes 4:7 And I turned, and I saw folly under the sun. 

#### Ecclesiastes 4:8 There is one alone, and there is not a second; and indeed, {son nor indeed a brother there is no} to him. And there is no limit to all his effort; and indeed his eye is not satisfied of riches; and saying, Why do I make an effort, and deprive my soul of goodness? And indeed, this {folly and distraction an evil is}. 

#### Ecclesiastes 4:9 Better the two than the one, in which there is to them {wage a good} in their effort. 

#### Ecclesiastes 4:10 For if they should fall, the one shall raise his partner. But woe to him, to the one, whenever he should fall and there should not be a second to raise him. 

#### Ecclesiastes 4:11 And if {should go to bed two} and heat themselves, then the one, how shall he heat himself? 

#### Ecclesiastes 4:12 And if one prevails against the one, the two shall stand against him. And the {cord three-stranded} shall not be quickly ripped apart. 

#### Ecclesiastes 4:13 Better {child a needy and wise}, than {king an older and foolish} who does not know to take heed any longer. 

#### Ecclesiastes 4:14 For from out of the house of the prisoners he shall come forth to reign, for even indeed in his kingdom he was needy. 

#### Ecclesiastes 4:15 I beheld all of the living, of the ones walking under the sun, with the young of the second generation who will stand in place of him. 

#### Ecclesiastes 4:16 There is no limit to all the people, to all as many as was before them; and indeed, the last shall not be glad in himself. For even indeed this is folly and resolve of spirit. 

#### Ecclesiastes 5:1 Guard your foot whenever you should go into the house of God and are near to hear! {be above the gift of the fools sacrifice Let your}, for they are not knowing to do bad. 

#### Ecclesiastes 5:2 Do not hasten with your mouth, and {your heart let not} hasten to bring forth a word before the presence of God! For God is in the heaven upward, and you are upon the earth; Upon this let {be your words} few! 

#### Ecclesiastes 5:3 For {comes through a dream} in a multitude of testing; and the voice of a fool in a multitude of words. 

#### Ecclesiastes 5:4 As when you vow a vow to God, you should not pass time to render it, for {is not his will} in foolish vows. You then, as much as you should have vowed, render! 

#### Ecclesiastes 5:5 Better {to not make a vow for you}, than for you to make a vow and not repay. 

#### Ecclesiastes 5:6 You should not give your mouth to lead {into sin your flesh}; and you should not say before the presence of God that, It is in ignorance; lest {should be provoked to anger God} at your voice, and should utterly destroy the things made by your hands. 

#### Ecclesiastes 5:7 For in a multitude of dreams, and follies, and {words many}, that with God you should fear. 

#### Ecclesiastes 5:8 If {extortion of the needy and seizure by lawsuit and judicial right you should see} in a place, you should not wonder over the thing; for a high one {above a high one shall guard}, and high ones over them. 

#### Ecclesiastes 5:9 And the abundance of the earth {for all is}; even a king needs the {of a field working}. 

#### Ecclesiastes 5:10 The one loving silver shall not be filled of silver; nor one who loved {in their abundance the offspring}. And indeed this is folly. 

#### Ecclesiastes 5:11 In a multitude of goodness {are multiplied the ones eating of it}; and what courageous thing is it to the one having it, but the sum of the seeing it with his eyes? 

#### Ecclesiastes 5:12 {is sweet Sleep} for the servant, if {little or if much he shall eat}. And to the one being filled to be rich there is none allowing him to sleep. 

#### Ecclesiastes 5:13 There is a sickness which I beheld under the sun -- riches being kept by him, for his hurt. 

#### Ecclesiastes 5:14 And {shall be destroyed those riches} in {distraction an evil}; and he engenders a son, and is there not {in his hand anything}. 

#### Ecclesiastes 5:15 As he came forth from the womb of his mother naked, he shall return to go as he comes, and nothing shall he take in his effort, that it should go with him in his hand. 

#### Ecclesiastes 5:16 And indeed this is an evil sickness; for as he came, so also he shall go forth. And what is his advantage in which he makes an effort into the wind? 

#### Ecclesiastes 5:17 And indeed all his days are in darkness, and in mourning, and {rage much}, and sickness, and bitter anger. 

#### Ecclesiastes 5:18 Behold, I saw good, which is good to eat and to drink; and to see goodness in all his effort in what ever he should make an effort in under the sun, in the number of days of his life which {gave to him God}. For it is his portion. 

#### Ecclesiastes 5:19 And indeed, every man to whom {gave to him God} riches and possessions, and gave to him authority to eat from it, and to take his portion, and to be glad in his effort; this {a gift of God is}. 

#### Ecclesiastes 5:20 For he will not much remember the days of his life, for God distracts him in the gladness of his heart. 

#### Ecclesiastes 6:1 There is a wickedness which I beheld under the sun, and it is abundant with men. 

#### Ecclesiastes 6:2 A man to whom {shall give to him God} wealth, and possessions, and glory, and there is nothing lacking to his soul from all things which he shall desire; yet {shall not give authority to him God} to eat from it; for a man, a stranger, shall eat it. And this {folly and sickness an evil is}. 

#### Ecclesiastes 6:3 If {should engender a man} a hundred, and {years many shall live}, and {abundant however} will be the days of his years, that his soul shall not be filled up from goodness, and indeed {no burial there be} for him. I said, Better for him the miscarriage. 

#### Ecclesiastes 6:4 For in folly he came, and in darkness he goes, and in darkness his name shall be covered. 

#### Ecclesiastes 6:5 And indeed {the sun he knew not}, and {knows not rest this one} over this other one. 

#### Ecclesiastes 6:6 And if he lived a thousand years of returns, and {goodness he knows not}, is it not unto {place one} all shall go? 

#### Ecclesiastes 6:7 Every effort of man is for his mouth, and indeed the soul shall not be filled. 

#### Ecclesiastes 6:8 For what advantage to the wise over the fool, for the needy knows to go in front of life? 

#### Ecclesiastes 6:9 Better vision of eyes, than going in life; for indeed this is folly and resolve of spirit. 

#### Ecclesiastes 6:10 If anything became, already {has been called its name}; and it is known what man is, and he is not able to judge against the one stronger than he. 

#### Ecclesiastes 6:11 For there are {matters many} multiplying folly. 

#### Ecclesiastes 6:12 What extra is to man? For who knows what is good to man in life, during the number of the life of the days of his folly? And he spent them as a shadow; for who shall report to man what will be after him under the sun? 

#### Ecclesiastes 7:1 A good name is above {oil good}, and the day of death above the day of birth. 

#### Ecclesiastes 7:2 It is good to go into a house of mourning, than than to go into a house of a banquet; in so far as this is the end of every man; and the living man will give good to his heart. 

#### Ecclesiastes 7:3 Better is rage than laughter, for by hurt of countenance {will be made better the heart}. 

#### Ecclesiastes 7:4 The heart of the wise is in the house of mourning; and the heart of fools is in the house of gladness. 

#### Ecclesiastes 7:5 It is good to hear the reproach of the wise, than for a man to hear songs of fools. 

#### Ecclesiastes 7:6 As the sound of the thorn-bushes burning under the kettle, so the laughter, the one of the fools; and indeed this is folly. 

#### Ecclesiastes 7:7 For extortion drives {mad the wise man}, and destroys the {heart magnanimity of his}. 

#### Ecclesiastes 7:8 Better the last of matters than its beginning; better the lenient than high spirit. 

#### Ecclesiastes 7:9 You should not hasten in your spirit to be enraged, for rage {in the bosom of fools shall rest}. 

#### Ecclesiastes 7:10 You should not say, What happened that the {days former} were good over these? for {not in wisdom you asked} concerning this. 

#### Ecclesiastes 7:11 {is good Wisdom} with an allotment and abundance to the ones viewing the sun. 

#### Ecclesiastes 7:12 For {in its shadow wisdom} is as the shadow of silver; and the advantage of the knowledge of wisdom will restore to life the one having it. 

#### Ecclesiastes 7:13 Behold the actions of God! For who shall be able to adorn what ever God should turn from him? 

#### Ecclesiastes 7:14 In the day of goodness live in good! and look out in the day of evil! Behold! and indeed with one {harmony with these caused God} concerning speech, that {should not find man after him anything}. 

#### Ecclesiastes 7:15 All things I beheld in days of my folly. There is a just man being destroyed in his justice, and there is an impious man abiding in his evil. 

#### Ecclesiastes 7:16 Do not become {righteous super}, nor discern extra, lest at any time you should be overwhelmed! 

#### Ecclesiastes 7:17 You should not be {impious super}, and do not become hard, that you should not die in your time! 

#### Ecclesiastes 7:18 It is good for you to hold fast by this; and indeed of this you should not defile your hand. For to the ones fearing God all things shall go forth. 

#### Ecclesiastes 7:19 Wisdom will give help to the wise one over ten exercising authority, of the ones being in the city. 

#### Ecclesiastes 7:20 For {man there is no just} on the earth who shall do good and shall not sin. 

#### Ecclesiastes 7:21 And indeed unto all the words which they shall speak, you should not put them to your heart, so that you should not hear your servant cursing you. 

#### Ecclesiastes 7:22 For very often he will act wickedly against you, and returning many times he shall inflict your heart; that as also indeed you cursed others. 

#### Ecclesiastes 7:23 All these things I tested in wisdom. I said, I shall be discerning, but it was far from me. 

#### Ecclesiastes 7:24 Far above what was, and a deep depth -- who shall find it? 

#### Ecclesiastes 7:25 {circled about I and my heart} to know, and to survey, and to seek wisdom, and the reckoning of things, and to know the impious man's foolishness, and rioting, and deviation. 

#### Ecclesiastes 7:26 And I find her more bitter than death -- with the woman in which {is snares and dragnets her heart}, and a bond in her hands. He that is good before the face of God shall be delivered from her; and the one sinning will be seized with her. 

#### Ecclesiastes 7:27 Behold! this I found, said the ecclesiastic, counting one by one, to find a device, 

#### Ecclesiastes 7:28 which {anxiously sought my soul}, and I did not find. Even {man one} from out of a thousand did I find. And a woman among all these I did not find. 

#### Ecclesiastes 7:29 Except behold! this I found, that God dealt with the {man upright}. And they sought {devices many}. Who knows the wise? And who knows the loosening of a saying? 

#### Ecclesiastes 8:1 {wisdom A man's} will lighten his countenance; and an impudent man's countenance will be detested. 

#### Ecclesiastes 8:2 {the mouth of a king Watch}! even because of the word of the oath of God. 

#### Ecclesiastes 8:3 {not hurriedly from his face You should go}. You should not stand in {matter an evil}, for what ever he wants, he does. 

#### Ecclesiastes 8:4 As a king exercising authority, and who shall say to him, What do you do? 

#### Ecclesiastes 8:5 The one keeping the commandment shall not know {matter an evil}. And {the time of judgment knows the heart of the wise}. 

#### Ecclesiastes 8:6 For every thing there is a season and judgment; for knowledge of man is vast unto him. 

#### Ecclesiastes 8:7 For there is not one knowing what shall be being; for as it will be, who shall announce to him? 

#### Ecclesiastes 8:8 There is no man exercising authority over spirit to restrain with the spirit; and there is no exercising authority in the day of death; and there is no discharge in the day of battle; and {shall not preserve impiety} the thing for her. 

#### Ecclesiastes 8:9 And all this I beheld; and I gave my heart to every action which I had done under the sun; the things, as much as {exercises authority a man} to a man to inflict evil on him. 

#### Ecclesiastes 8:10 And then I beheld the impious {into the tombs being brought}, and from out of the holy place; and they went and were praised in the city, because they did thus. And indeed this is folly. 

#### Ecclesiastes 8:11 Because there is no existing objection for the ones doing evil quickly, therefore by this {have full assurance the heart of the sons of man} in themselves to do evil. 

#### Ecclesiastes 8:12 The one who sinned did evil from then, and of their duration. For also even I know that there is good to the ones fearing God, so that they should fear from in front of him. 

#### Ecclesiastes 8:13 But {good it will not be} to the impious, and he shall not prolong his days which are as a shadow; for he is not fearing from before God. 

#### Ecclesiastes 8:14 There is a folly which is done upon the earth; that there are just ones that attain unto them, as the action of the impious; and there are impious that attain to them, as the action of the just. I said that, Indeed also this is folly. 

#### Ecclesiastes 8:15 And I praised with the gladness, because there is no good thing to man under the sun, were it not to eat, and to drink, and to be glad. And it will adhere to him in his effort all the days of his life, as {gave to him God} under the sun. 

#### Ecclesiastes 8:16 Whereupon I gave my heart to know wisdom, and to behold the distraction being done upon the earth. For also at day and at night {sleep with his eyes a person is not seeing}. 

#### Ecclesiastes 8:17 And I beheld all the actions of God, that {shall not be able man} to find out the action being done under the sun. As long as {should make an effort man} to seek, even he shall not find it. And indeed, as long as {should speak the wise} to know it, he shall not be able to find it. For all this I gave to my heart, and my heart {all beheld} this. 

#### Ecclesiastes 9:1 As the just, and the wise, even their works are in the hand of God. Indeed even love, indeed even hatred, there is no {knowing man} all the things before them. 

#### Ecclesiastes 9:2 Folly is in all things; {event there is one} to the just, and one to the impious; to the good and to the bad; and to the clean and to the unclean; and to the one sacrificing and to the one not sacrificing; as is the good, as is the one sinning; as the one swearing by an oath, as is the one {the oath fearing}. 

#### Ecclesiastes 9:3 This evil is in all being done under the sun, for there is {event one} to all. And indeed the heart of the sons of man are filled with evil; and madness in their heart during their life, and after them they go to the dead. 

#### Ecclesiastes 9:4 For someone who participates with all the living there is hope; for the {dog living} himself is good over the {lion dead}. 

#### Ecclesiastes 9:5 For the living shall know that they shall die; but the dead are not knowing anything; and there is not {to them any longer a wage}, for {was forgotten their remembrance}. 

#### Ecclesiastes 9:6 And indeed their love, and indeed their hatred, and indeed their zeal already perished; and {portion there is no} to them any longer into the eon, in all things being done under the sun. 

#### Ecclesiastes 9:7 Come, eat with gladness of your bread, and drink {with heart a good your wine}! for already God thought well of your actions 

#### Ecclesiastes 9:8 In every time let {be your garments} white, and {oil upon your head let not be lacking}! 

#### Ecclesiastes 9:9 And behold life with the wife which you loved all the days of the life of your folly! the ones being given to you under the sun, all the days of the life of your folly. For it is your portion in your life, and in your effort wherein you made an effort under the sun. 

#### Ecclesiastes 9:10 All as much as {should find your hand} to do, {as is power in your you do}; for there is no action, nor device, nor knowledge, nor wisdom in Hades, of where you should go there. 

#### Ecclesiastes 9:11 I turned, and I beheld under the sun, that not to the light of foot is the race; and not to the mighty ones in battle; and indeed not to the wise is the bread; and indeed not to the discerning ones is the riches; and indeed not to the ones knowing favor; for a season and a meeting shall meet with them all. 

#### Ecclesiastes 9:12 And indeed {does not know man} his season. As fishes being hunted with {casting-net a hurtful}, and as birds being hunted with a snare -- as them {shall be ensnared the sons of man} in {season an evil}, whenever it should fall upon them suddenly. 

#### Ecclesiastes 9:13 And indeed this I beheld -- wisdom under the sun, and it is great to me. 

#### Ecclesiastes 9:14 {city If there were a small}, and the men in it few; and there should come against it {king a great}, and he shall encircle it, and shall build against it {siege mounds great}; 

#### Ecclesiastes 9:15 and there should be found in it {man a needy wise}; and {shall deliver he himself} the city in his wisdom; but man remembered not with {man needy that}. 

#### Ecclesiastes 9:16 And I said, {is good Wisdom} over power. But the wisdom of the needy man is being treated with contempt, and his words are not being listened to. 

#### Ecclesiastes 9:17 Words of the wise being at rest are heard above a cry of ones being in authority in follies. 

#### Ecclesiastes 9:18 {is good Wisdom} over weapons of war; but {sinning one} shall destroy {goodness much}. 

#### Ecclesiastes 10:1 A fly put to death will rot a concoction {oil of lucious}; {is valuable A little wisdom} over {glory of folly great}. 

#### Ecclesiastes 10:2 A heart of a wise man is at his right hand; and the heart of a fool is at his left. 

#### Ecclesiastes 10:3 And indeed {in the way whenever a fool goes} of his heart, he will fail, and {which he considers all} is folly. 

#### Ecclesiastes 10:4 If spirit of the one exercising authority should ascend against you, {your place you should not leave}; for a cure will put to rest {sins great}. 

#### Ecclesiastes 10:5 There is a wickedness which I beheld under the sun, as an unintentional act came forth from the person of one exercising authority. 

#### Ecclesiastes 10:6 {was put The fool} in {heights great}, and the rich {in low shall settle}. 

#### Ecclesiastes 10:7 I beheld servants upon horses, and rulers going as servants upon the ground. 

#### Ecclesiastes 10:8 The one digging a cesspool {into it shall fall}; and the one demolishing a fence boundary, {shall bite him a serpent}. 

#### Ecclesiastes 10:9 One lifting away stones shall work hard among them; one splitting wood shall be exposed to danger in them. 

#### Ecclesiastes 10:10 If {should fall off an iron implement}, and he {in countenance is disturbed}, then {his power he shall strengthen}, and abundance is to the man of which is wisdom. 

#### Ecclesiastes 10:11 If {should bite the serpent} with no enchanter whispering, then there is no advantage to the one charming. 

#### Ecclesiastes 10:12 The words {mouth of a wise} carry favor; but the lips of a fool shall sink him; 

#### Ecclesiastes 10:13 the beginning of the words of his mouth are folly, and the end of his mouth {madness is wicked}. 

#### Ecclesiastes 10:14 And the fool multiplies words. {does not know Man} what the thing becoming is, and what the thing will be; for after him who shall announce to him? 

#### Ecclesiastes 10:15 The effort of the fools shall trouble them as one who does not know how to go into the city. 

#### Ecclesiastes 10:16 Woe to you, O city, of which your king is younger, and your rulers {in the morning eat}. 

#### Ecclesiastes 10:17 Blessed is your land of which your king is a son of free nobles, and your rulers at a proper time shall eat in force, and shall not be ashamed. 

#### Ecclesiastes 10:18 By slothful neglect {will be lowered a building}; and in idleness of hands {will drip the house}. 

#### Ecclesiastes 10:19 For laughter they make bread, and wine and olive oil {to be glad for the living}; and of the money all will heed. 

#### Ecclesiastes 10:20 And indeed in your conscience {a king you should not curse}; and in the closets of your bedrooms you should not curse a rich man. For a winged creature of heaven shall carry your voice, and the one having the wings shall report your word. 

#### Ecclesiastes 11:1 Send your bread upon the face of the water! for in a multitude of days you will find it. 

#### Ecclesiastes 11:2 Give a portion to seven, even indeed to eight! for you do not know what evil there will be upon the earth. 

#### Ecclesiastes 11:3 If {should be filled the clouds} of rain, {upon the earth they pour out}; and if {should fall a tree} towards the south, or if towards the north, in the place where {shall fall the tree} there it shall be. 

#### Ecclesiastes 11:4 Giving heed to the wind one does not sow, and one looking into the clouds will not harvest. 

#### Ecclesiastes 11:5 Among the ones in whom there is no knowing what the way of the wind is, as the bones in the womb of one being with child, so you shall not know the actions of God, as much as he shall do in all things. 

#### Ecclesiastes 11:6 At morning sow your seed, and at evening do not relieve your hand! for you do not know what will line up -- this here, this there, or if the two {together are good}. 

#### Ecclesiastes 11:7 Moreover {is sweet the light}, and it is good to the eyes to see with the sun. 

#### Ecclesiastes 11:8 For even if {years many shall live a man}, in all them he shall be glad. And {shall be remembered the days of darkness}, for they will be many. All coming is folly. 

#### Ecclesiastes 11:9 Be glad, O young man, in your youth! and let {do you good your heart} in the days of your youth! And walk in the ways of your heart unblemished, and in the vision of your eyes! And know that in all these {shall lead you God} in equity! 

#### Ecclesiastes 11:10 And leave rage from your heart, and pass off wickedness from your flesh! for youth and thoughtlessness are folly. 

#### Ecclesiastes 12:1 And remember the one creating you in the days of your youth! while {should not come the days of evil}, nor {should arrive years}, in which you shall then say, There is not in me {for them a want}. 

#### Ecclesiastes 12:2 While {are not darkened the sun and the light}, nor the moon and the stars; nor {return the clouds} after the rain; 

#### Ecclesiastes 12:3 in a day in which ever {should be shaken the keepers of the house}, and {should be turned aside men of power}, and {are idle the grinding women} because they are made few, and {shall darken the women looking out of the openings}; 

#### Ecclesiastes 12:4 and they shall lock the doors in the market in weakness of the sound of the woman grinding, and one shall rise up to the sound of the sparrow, and {shall be humbled all the daughters of song}; 

#### Ecclesiastes 12:5 and indeed from the height they shall see, even stupefactions in the way; and {shall bloom the almond}, and {shall thicken the locust}, and {shall be dispersed the caper}; because {went man} to {house his eternal}; and {circled in the market the ones beating their chests in mourning}; 

#### Ecclesiastes 12:6 until whenever should be prostrated the line of silver; and {should be broken the flower ornament of gold}, and {should be broken the water-pitcher} at the spring, and {should have rolled the wheel} unto the pit; 

#### Ecclesiastes 12:7 then {shall return the dust} upon the earth as it was; and the spirit should return to the God who gave it. 

#### Ecclesiastes 12:8 Folly of follies, said the ecclesiastic, all things are folly. 

#### Ecclesiastes 12:9 And it was extra that {became the ecclesiastic} wise, and he taught knowledge with man, and which he shall trace composed parables. 

#### Ecclesiastes 12:10 {much sought The ecclesiastic} to find {of words a wanting}, and writing of uprightness of words of truth. 

#### Ecclesiastes 12:11 The words of the wise are as the oxgoads, and as nails firmly planted; ones which by agreement were given from {shepherd one}. 

#### Ecclesiastes 12:12 And {extra by them O my son guard}! To make {scrolls many} there is no limit; and {meditation much} is weariness of flesh. 

#### Ecclesiastes 12:13 The end of the whole matter, hear! Fear God, and {his commandments keep}! for this is all man! 

#### Ecclesiastes 12:14 For every action God shall lead into judgment, with all being looked over, if good and if evil.