#### Psalms 1:1 Blessed is a man who went not in counsel of impious ones, and {in the way of sinners stood not}, and {upon a chair of mischievous ones sat not}. 

#### Psalms 1:2 But {is in the law of the LORD his will}; and in his law he shall meditate day and night. 

#### Psalms 1:3 And he will be as the tree being planted by the outlet of the waters, which {his fruit gives} in his season, and his leaf shall not drop down; and all as much as he should do will greatly prosper. 

#### Psalms 1:4 Not so the impious, not so; but is as dust which {casts forth the wind} from the face of the earth. 

#### Psalms 1:5 On account of this {shall not rise up the impious} in judgment, nor the sinners in the counsel of the just. 

#### Psalms 1:6 For the LORD knows the way of the just, but the way of impious ones shall perish. 

#### Psalms 2:1 Why did {neigh nations}, and peoples meditate upon vain things? 

#### Psalms 2:2 {stood by The kings of the earth}, and the rulers gathered together against the LORD and against his anointed one, 

#### Psalms 2:3 We should tear up their bonds, and we should throw away from us their yoke. 

#### Psalms 2:4 The one dwelling in heavens derides them, and the LORD ridicules them. 

#### Psalms 2:5 Then he shall speak to them in his anger; and in his rage he will disturb them. 

#### Psalms 2:6 But I was placed king by him over mount Zion, his holy place; 

#### Psalms 2:7 declaring the order of the LORD. The LORD said to me, {my son you are}, I today engendered you. 

#### Psalms 2:8 Ask from me! and I will give to you nations for your inheritance; and for your possession the ends of the earth. 

#### Psalms 2:9 You shall tend them with a rod of iron; as vessels of a potter you shall break them. 

#### Psalms 2:10 And now, O kings, perceive! Let {be instructed all the ones judging the earth}! 

#### Psalms 2:11 Serve to the LORD in fear, and exult to him with trembling! 

#### Psalms 2:12 Grab instruction! lest at any time you should provoke the LORD to anger, and you shall perish from {way the just}, whenever {should be kindled quickly his rage}. Blessed are all the ones yielding upon him. 

#### Psalms 3:1 O LORD, why were {multiplied the ones afflicting me}? Many rise up against me. 

#### Psalms 3:2 Many say concerning my soul, There is no deliverance to him by his God. PAUSE. 

#### Psalms 3:3 But you, O LORD, {my shielder are}, my glory, and the one raising up my head. 

#### Psalms 3:4 {my voice to the LORD I cried out}, and he heeded me from out of {mountain his holy}. 

#### Psalms 3:5 And I went to bed and slept. I woke up, for the LORD shall assist me. 

#### Psalms 3:6 I shall not fear from ten thousands of people of the ones round about joining in attacking me. 

#### Psalms 3:7 Rise up, O LORD! Deliver me, O my God! For you struck all the ones hating me for no cause; {the teeth of sinners you broke}. 

#### Psalms 3:8 {is of the LORD Deliverance}, and {is upon your people your blessing}. 

#### Psalms 4:1 In my calling, {heard me the God of my righteousness}; in affliction he widened me. Pity me, and hear my prayer! 

#### Psalms 4:2 O sons of men, until when will you ease being heavy hearted? Why do you love folly, and you seek a lie? 

#### Psalms 4:3 And know! that the LORD did a wonder for his sacred one. The LORD shall hear me in my crying out to him. 

#### Psalms 4:4 Be angry, and do not sin! What you say in your hearts, {upon your beds Let be vexed}! PAUSE. 

#### Psalms 4:5 Sacrifice a sacrifice of righteousness, and hope on the LORD! 

#### Psalms 4:6 Many say, Who shall show to us good things? {was signified to us The light of your face}, O LORD. 

#### Psalms 4:7 You put gladness into my heart. Of the fruit of the grain, wine and olive oil -- {of them they were filled}. 

#### Psalms 4:8 In peace {at the same place I will go to bed} and sleep. For you, O LORD, alone {with hope settled me}. 

#### Psalms 5:1 {my words Give ear to}, O LORD! Take notice of my cry! 

#### Psalms 5:2 Take heed to the voice of my supplication, O my king and my God! for to you I shall pray, O LORD. 

#### Psalms 5:3 In the morning you shall hear my voice. In the morning I shall stand beside you, and he shall watch me. 

#### Psalms 5:4 For {not a God wanting lawlessness you are}, nor shall {sojourn with you the one being wicked}; 

#### Psalms 5:5 nor shall {abide lawbreakers} in front of your eyes. You detested all the ones working lawlessness. 

#### Psalms 5:6 You shall destroy all the ones speaking the lie. A man of blood and deceitful the LORD abhors. 

#### Psalms 5:7 But I, in the multitude of your mercy shall enter into your house. I shall do obeisance towards {temple your holy} in the fear of you. 

#### Psalms 5:8 O LORD, guide me in your righteousness, because of my enemies! Straighten out {before you my way}! 

#### Psalms 5:9 For there is no {in their mouth truth}; their heart is vain; {is a tomb having been opened their throat}; with their tongues they used deceit. 

#### Psalms 5:10 Judge them, O God! let them fall away from their deliberations! According to the multitude of their impieties banish them! For they rebelled against you, O LORD. 

#### Psalms 5:11 And may {be glad all hoping upon you}. {into the eon They shall exult}, and you shall encamp with them; and {shall boast in you the ones loving your name}. 

#### Psalms 5:12 For you shall bless the just, O LORD. As a shield of benevolence you crowned us. 

#### Psalms 6:1 O LORD, you should not {in your rage reprove me}, nor {in your anger correct me}. 

#### Psalms 6:2 Show mercy on me, O LORD! for I am weak. Heal me, O LORD! for {are disturbed my bones}, 

#### Psalms 6:3 and my soul is disturbed exceedingly. But you, O LORD, until when? 

#### Psalms 6:4 Return, O LORD, rescue my soul! Deliver me because of your mercy! 

#### Psalms 6:5 For there is no {in death remembering you}; and in Hades, who shall make acknowledgement to you? 

#### Psalms 6:6 I tired in my moaning. I shall bathe {each night my bed}; with my tears {my strewn bed I shall rain}. 

#### Psalms 6:7 {is disturbed from rage My eye}. I grow old in all my enemies. 

#### Psalms 6:8 Remove from me all the ones working lawlessness! For the LORD heard the sound of my weeping. 

#### Psalms 6:9 The LORD listened to my supplication. The LORD {my prayer favorably received}. 

#### Psalms 6:10 May they be put to shame and may they be disturbed -- all my enemies; may they be turned back and put to shame exceedingly, even quickly. 

#### Psalms 7:1 O LORD my God, upon you I hope. Deliver me from all the ones pursuing me, and rescue me! 

#### Psalms 7:2 Lest at any time {should be snatched away as by a lion my soul}, while there is none being for ransoming nor delivering. 

#### Psalms 7:3 O LORD my God, if I did this, if there is injustice in my hands, 

#### Psalms 7:4 if I recompensed to the ones recompensing to me with bad things, may I fall away thus from my enemies empty -- 

#### Psalms 7:5 may {pursue then the enemy} my soul, and may he overtake it; and may he trample {into the ground my life}; and {my glory in the dust may be encamped}. 

#### Psalms 7:6 Rise up, O LORD, in your anger! Be raised up high in the limits of your enemies! And awaken, O LORD my God! in the order in which you gave charge. 

#### Psalms 7:7 And a gathering of peoples shall encircle you; and for this {unto the height return}! 

#### Psalms 7:8 The LORD judges peoples. Judge me, O LORD, according to my righteousness! and according to my innocence judge for me! 

#### Psalms 7:9 Finish off entirely indeed the wickedness of sinners! And you shall straighten the just, examining hearts and kidneys, O God, justly. 

#### Psalms 7:10 My help is from God, the one delivering the straight in the heart. 

#### Psalms 7:11 God {judge is a just}, and strong, and lenient, not {anger bringing on} each day. 

#### Psalms 7:12 If you should not turn, {his broadsword he will brighten}. His bow he stretched tight, and he prepared it; 

#### Psalms 7:13 And by it he prepared weapons of death; {his arrows for the ones for burning he brought to completion}. 

#### Psalms 7:14 Behold, the wicked travails with iniquity; he conceived misery, and gave birth to lawlessness. 

#### Psalms 7:15 {a pit He dug up}, even he dug it, and he shall fall into a cesspool which he worked. 

#### Psalms 7:16 {shall return His misery} unto his own head; and {upon his head his injustice shall come down}. 

#### Psalms 7:17 I shall make acknowledgment to the LORD according to his righteousness; and I shall strum to the name of the LORD the highest. 

#### Psalms 8:1 O LORD, our Lord, how wonderful is your name in all the earth. For {was lifted your majesty} up above the heavens. 

#### Psalms 8:2 From out of the mouths of infants and ones nursing you ready praise because of your enemies, to depose the enemy and the avenger. 

#### Psalms 8:3 For I shall see the heavens, the works of your fingers; the moon and stars which you founded. 

#### Psalms 8:4 What is man that you remember him? or a son of man that you visit him? 

#### Psalms 8:5 You lessened him short of any of the angels; with glory and honor you crowned him; 

#### Psalms 8:6 and you placed him over the works of your hands. All things you submitted underneath his feet -- 

#### Psalms 8:7 sheep and oxen all together, and still also the cattle of the plain, 

#### Psalms 8:8 the winged creatures of the heaven, and the fishes of the sea -- the ones traveling over the paths of the seas. 

#### Psalms 8:9 O LORD, our Lord, how wonderful is your name in all the earth. 

#### Psalms 9:1 I shall make acknowledgment to you, O LORD, with {entire heart my}. I shall describe all your wonders. 

#### Psalms 9:2 I will be glad and exult in you. I shall strum to your name, O highest one. 

#### Psalms 9:3 In the turning of my enemy unto the rear, they shall weaken and be destroyed from your face. 

#### Psalms 9:4 For you made my case and my cause. You sat upon the throne -- the one judging righteousness. 

#### Psalms 9:5 You reproached nations, and {perished the impious}. {his name You wiped away} into the eon, and into the eon of the eon. 

#### Psalms 9:6 {of the enemy failed The broadswords} unto the end; and {cities you demolished}; {was destroyed his memorial} with noise. 

#### Psalms 9:7 And the LORD {into the eon abides}. He prepared {for judgment his throne}. 

#### Psalms 9:8 And he will judge the inhabitable world in righteousness. He shall judge peoples with uprightness. 

#### Psalms 9:9 And the LORD became a refuge to the needy; a helper at an opportune time in afflictions. 

#### Psalms 9:10 And {hope upon you the ones knowing your name}, for you abandoned not the ones seeking after you, O LORD. 

#### Psalms 9:11 Strum to the LORD! to the one dwelling in Zion. Announce among the nations his practices! 

#### Psalms 9:12 For the one requiring their blood he remembered. He did not forget the cry of the needy. 

#### Psalms 9:13 Show mercy on me, O LORD! Behold my humiliation from my enemies! O one raising me from the gates of death. 

#### Psalms 9:14 so that I should publish all your praise at the gates of the daughter of Zion. We will exult over your deliverance. 

#### Psalms 9:15 {were stuck The nations} in corruption which they produced; by this snare which they hid {was seized their own foot}. 

#### Psalms 9:16 The LORD is known {judgments by executing}; {by the works of his hands is seized the sinner}. AN ODE. 

#### Psalms 9:17 Let {be turned the sinners} to Hades! even all the nations forgetting God. 

#### Psalms 9:18 For {not at the end shall be forgotten the poor}; the patience of the needy ones shall not perish to the end. 

#### Psalms 9:19 Rise up, O LORD, do not let {overpower man}! Let {be judged the nations} before you! 

#### Psalms 9:20 Place, O LORD, a lawgiver over them! Let {know the nations} that they are men! 

#### Psalms 10:1 Why, O LORD, have you abstained far off? neglected at opportune times in afflictions? 

#### Psalms 10:2 In the being prideful by the impious one, {is burnt the poor one}; they are seized by the deliberations which they argue. 

#### Psalms 10:3 For {applauds the sinner} in the desires of his soul; and the one doing wrong blesses himself. 

#### Psalms 10:4 {provoked the LORD The sinner} according to the magnitude of his anger; he shall not seek after God; {is not God} before him; 

#### Psalms 10:5 {are profane his ways} at all time; {are taken away your judgments} from in front of him; {all his enemies he shall dominate}. 

#### Psalms 10:6 For he said in his heart, In no way should I be shaken from generation to generation; I shall exist without bad happening; 

#### Psalms 10:7 whose curse his mouth is full of, and bitterness, and treachery; under his tongue is toil and misery; 

#### Psalms 10:8 he lies in wait to ambush with the rich in concealment, to kill the innocent; his eyes {against the needy look}. 

#### Psalms 10:9 He lies in wait in concealment as a lion in his lair; he lies in wait to snatch away the poor; to snatch away the poor when he draws him. In his snare he humbles him. 

#### Psalms 10:10 He shall bow and fall in his dominating the needy. 

#### Psalms 10:11 For he said in his heart, God has been forgotten, he turned his face to not see into the end. 

#### Psalms 10:12 Rise up, O LORD my God! Raise up high your hand to not forget your needy unto the end! 

#### Psalms 10:13 For what reason did {provoke to anger the impious God}? For he said in his heart, He shall not require an account. 

#### Psalms 10:14 For you see. You {misery and rage contemplate} to deliver him into your hands. {have been abandoned to you The poor}, to the orphan you were a helper. 

#### Psalms 10:15 Break the arm of the sinner and wicked one! {shall be sought for His sin}, and in no way shall he be found. 

#### Psalms 10:16 The LORD is king into the eon, and into the eon of the eon. You shall be destroyed, O nations, from out of his land. 

#### Psalms 10:17 {the desire of the needy You heard}, O LORD, {the preparation of their heart took heed to your ear}, 

#### Psalms 10:18 to judge orphans, and the humble; that {should not proceed still to brag man} upon the earth. 

#### Psalms 11:1 Upon the LORD I have yielded. How shall you say to my soul, Migrate unto the mountains as a sparrow? 

#### Psalms 11:2 For behold, the sinners stretch tight the bow; they prepare arrows for the quiver, to shoot in moonlight the straight in heart. 

#### Psalms 11:3 That which you readied, they demolished; but the just, what did they do? 

#### Psalms 11:4 The LORD is in {temple his holy}; the LORD is in heaven his throne; his eyes {unto the needy pay attention}; his eyelids inquire diligently of the sons of men. 

#### Psalms 11:5 The LORD inquires diligently to the just and the impious; but the one loving injustice detests his own soul. 

#### Psalms 11:6 He shall rain {upon sinners snares}; fire and sulphur and {wind a gale} shall be the portion of their cup. 

#### Psalms 11:7 For the LORD is just, and {righteousness he loves}; {straightness perceived his face}. 

#### Psalms 12:1 Deliver me, O LORD! for {has failed the sacred one}; for {were lessened the ones in truths} from the sons of men. 

#### Psalms 12:2 {vanity spoke Each} to his neighbor. {lips Deceitful} are in the heart, and by the heart he spoke evils. 

#### Psalms 12:3 Let the LORD utterly destroy all the {lips deceitful}, and {tongues lofty speaking}! 

#### Psalms 12:4 the ones having said, {our tongues We will magnify}; our lips {for us are}; who {our lord is}? 

#### Psalms 12:5 Because of the misery of the poor, and the moaning of the needy, now I will arise, says the LORD, I will establish by deliverance, I will speak openly by him. 

#### Psalms 12:6 The oracles of the LORD {oracles are pure}; as silver tried in fire, proved in the earth, being purified seven-fold. 

#### Psalms 12:7 You, O LORD, shall guard us, and you shall carefully keep us from this generation, and into the eon. 

#### Psalms 12:8 {round about The impious walk}. According to your stature you took great care of the sons of men. 

#### Psalms 13:1 For how long, O LORD, will you forget me -- unto the end? For how long do you turn your face from me? 

#### Psalms 13:2 Until what time shall I set plans in my soul, with griefs in my heart day and night? For how long shall {be exalted my enemy} over me? 

#### Psalms 13:3 Look upon, hear me, O LORD my God! Enlighten my eyes! lest at any time I should sleep in death; 

#### Psalms 13:4 lest at any time {might say my enemy}, I prevailed against him. The ones afflicting me shall exult if I should be shaken. 

#### Psalms 13:5 But I {upon your mercy hoped}. {shall exult My heart} over your deliverance. 

#### Psalms 13:6 I shall sing to the LORD, to the one benefiting me; and I will strum to the name of the LORD the highest. 

#### Psalms 14:1 {said The fool} in his heart, There is no God. They were corrupted and abhorrent in their practices. There is not one doing that which is good. 

#### Psalms 14:2 The LORD from out of heaven looked upon the sons of men, to see if there is one perceiving or inquiring of God. 

#### Psalms 14:3 All turned aside together; they were made useless; there is not one doing that which is good; there is not even one. 

#### Psalms 14:4 Do {not know all the ones working lawlessness}, the ones devouring my people as the food of bread? {the LORD They called not upon}. 

#### Psalms 14:5 There they were timid with fear, of which there was no fear; for God is with the generation of the just. 

#### Psalms 14:6 The counsel of the poor you disgraced, for the LORD {hope is his}. 

#### Psalms 14:7 Who will grant from Zion the deliverance of Israel? In the LORD turning the captivity of his people, Jacob shall exult, and Israel shall be glad. 

#### Psalms 15:1 O LORD, who shall sojourn in your tent, or who shall encamp in {mountain your holy}? 

#### Psalms 15:2 The one going unblemished, and working righteousness, speaking truth in his heart; 

#### Psalms 15:3 who did not speak treacherously with his tongue, and did not do {to his neighbor bad}, and {scorning did not take up} against the ones near him. 

#### Psalms 15:4 {is treated with contempt before him The one acting wickedly}; but the one fearing the LORD he glorifies, even the one swearing by an oath to his neighbor and not annulling it; 

#### Psalms 15:5 his money he did not give for interest, and bribes from the innocent he did not take. The one doing these things shall not be shaken into the eon. 

#### Psalms 16:1 Guard me, O LORD, for upon you I hoped! 

#### Psalms 16:2 I said to the LORD, {my LORD You are}, for {of my goodness no need you have}. 

#### Psalms 16:3 {the holy ones in his land wondered The LORD}, all his willing ones among them. 

#### Psalms 16:4 {were multiplied Their weaknesses} -- {after these gods they that hastened}. In no way shall I bring together the ones of their gathering for blood, nor in any way shall I mention their names through my lips. 

#### Psalms 16:5 The LORD is the portion of my inheritance and of my cup. You are the one restoring my inheritance to me. 

#### Psalms 16:6 The measuring lines fallen to me in the most excellent places. Yes, for my inheritance {most excellent is to me}. 

#### Psalms 16:7 I will bless the LORD, the one bringing understanding to me; but still also until night {corrected me my kidneys}. 

#### Psalms 16:8 I foresaw the LORD before me always; for {on my right he is} that I should not be shaken. 

#### Psalms 16:9 On account of this {was glad my heart}, and {exulted my tongue}; and still also my flesh shall encamp in hope. 

#### Psalms 16:10 For you shall not abandon my soul in Hades, nor shall you give your sacred one to see corruption. 

#### Psalms 16:11 You made known to me the ways of life. You shall fill me of gladness with your face. Delightfulness is at your right unto the end. 

#### Psalms 17:1 Hear, O LORD, my righteousness! Take heed to my supplication! Give ear to my prayer not uttered by {lips deceitful}! 

#### Psalms 17:2 {from your presence my judgment May come forth}; {my eyes let} behold uprightness! 

#### Psalms 17:3 You tried my heart; you visited at night; you set me on fire, and {was not found in me injustice}, so that {should not speak my mouth}. 

#### Psalms 17:4 Concerning the works of men, by the words of your lips I guarded {ways hard}. 

#### Psalms 17:5 Fashion my footsteps in your roads! that {should not be shaken my footsteps}. 

#### Psalms 17:6 I cried, for you heeded me, O God; lean your ear to me, and hear my words! 

#### Psalms 17:7 Show the wonder of your mercies! O one delivering the ones hoping upon you, from the ones opposing at your right. 

#### Psalms 17:8 Guard me, O LORD, as the pupil of the eye! Under the protection of your wings shelter me! 

#### Psalms 17:9 even from the face of the impious ones causing misery for me. My enemies {my soul compass}. 

#### Psalms 17:10 {in their own fat They are enclosed}; their mouth speaks pride. 

#### Psalms 17:11 They are casting me out now; they surrounded me; their eyes set to turn me to the ground. 

#### Psalms 17:12 {they undertook me As a lion prepared for a hunt}, and as a cub living in concealment. 

#### Psalms 17:13 Rise up, O LORD! Be there beforehand with them, and trip them! Rescue my soul from the impious by your broadsword! 

#### Psalms 17:14 From the enemies by your hand, O LORD; from the few of the earth; divide them in their life. And of your things being hidden {was filled their belly}; they were filled of sons, and {they leave the remnants} to their infants. 

#### Psalms 17:15 But I {in righteousness shall appear in front of you}. I shall be filled in {appearing to me your glory}. 

#### Psalms 18:1 I shall love you, O LORD, of my strength. 

#### Psalms 18:2 The LORD is my firmament, and my refuge, and my rescuer. My God is my helper, and I will hope upon him; my defender and horn of my deliverance, and my shielder. 

#### Psalms 18:3 In praising, I will call upon the LORD; and from my enemies I shall be delivered. 

#### Psalms 18:4 {compassed me Pangs of death}, and rushing streams of lawlessness disturbed me. 

#### Psalms 18:5 Pangs of Hades surrounded me; {anticipated me snares of death}. 

#### Psalms 18:6 And in my being afflicted I called upon the LORD, and to my God I cried out. He heard {from out of temple his holy my voice}, and my cry before him shall enter into his ears. 

#### Psalms 18:7 And it was shaken; and trembling took place on the earth; and the foundations of the mountains were disturbed and shaken; for {was provoked to anger by them God}. 

#### Psalms 18:8 {ascended Smoke} in his anger, and fire from in front of him. {shall be ignited Coals}; they were lit by him. 

#### Psalms 18:9 And he leaned the heavens, and came down, and dimness was under his feet. 

#### Psalms 18:10 And he mounted upon cherubim, and he spread out; he spread out upon wings of winds. 

#### Psalms 18:11 And he established darkness for his concealment. Round about him was his tent; dark water in clouds of air. 

#### Psalms 18:12 From the radiance of his presence the clouds went by; hail and coals of fire. 

#### Psalms 18:13 And {thundered from out of heaven the LORD}, and the highest uttered his voice. 

#### Psalms 18:14 And he sent out arrows, and dispersed them; and {lightnings he multiplied}, and disturbed them. 

#### Psalms 18:15 And appeared the springs of waters; and {were uncovered the foundations of the inhabitable world} from your reproach, O LORD, from the blasting breath of your anger. 

#### Psalms 18:16 He sent from the height, and he took me; he took me to himself from out of {waters many}. 

#### Psalms 18:17 He will rescue me from {enemies my mighty}, and from the ones detesting me; for they are more solidified than me. 

#### Psalms 18:18 They went before me in the day of my ill-treatment, and the LORD became my support. 

#### Psalms 18:19 And he brought me into an enlargement. He shall rescue me, for he wanted me. 

#### Psalms 18:20 And {shall recompense to me the LORD} according to my righteousness; even according to the cleanliness of my hands he will recompense to me. 

#### Psalms 18:21 For I guarded the ways of the LORD, and did not impiously depart from my God. 

#### Psalms 18:22 For all his judgments are before me; and his ordinances did not leave from me. 

#### Psalms 18:23 And I will be unblemished with him; and I shall guard myself from my lawlessness. 

#### Psalms 18:24 And {shall recompense to me the LORD} according to my righteousness, and according to the cleanliness of my hands before his eyes. 

#### Psalms 18:25 With the sacred you shall be sacred; and with {man the innocent} you shall be innocent; 

#### Psalms 18:26 and with the choice one, you will be choice; and with the crooked you shall turn aside from. 

#### Psalms 18:27 For you {people the humble will deliver}, and the eyes of the proud you will humble. 

#### Psalms 18:28 For you shall light my lamp, O LORD my God; you shall lighten my darkness. 

#### Psalms 18:29 For by you I shall be rescued from the band of marauders; and by my God I shall pass over the wall. 

#### Psalms 18:30 My God -- unblemished is his way. The oracles of the LORD are tried by fire. He is a defender of all the ones hoping upon him. 

#### Psalms 18:31 For who is God besides the LORD? Or who is God besides our God? 

#### Psalms 18:32 God is the one girding me with power, and makes {unblemished my way}; 

#### Psalms 18:33 the one readying my feet as a stag, and {upon the high places setting me}; 

#### Psalms 18:34 teaching my hands for war; and you made {as the bow of brass my arms}; 

#### Psalms 18:35 and you gave to me a shielding deliverance; and your right hand takes hold of me; and your instruction re-erects me unto the end; and your instruction itself teaches me. 

#### Psalms 18:36 You widened my footsteps underneath me, and {weakened not my soles}. 

#### Psalms 18:37 I shall pursue my enemies and overtake them; and I will not return until whenever they should cease. 

#### Psalms 18:38 I shall squeeze them, and in no way should they be able to stand; they shall fall under my feet. 

#### Psalms 18:39 And you girded me in power for war; you bound hand and foot all the ones rising up against me underneath me. 

#### Psalms 18:40 And {of my enemies you gave to me the back}; and the ones detesting me you utterly destroyed. 

#### Psalms 18:41 They cried out {and there was no one delivering to the LORD}, and he did not hear them. 

#### Psalms 18:42 And I will make them as fine as dust against the face of the wind; as mud in the squares I will grind them. 

#### Psalms 18:43 You shall rescue me from a dispute of people; you shall place me at the head of nations; a people whom I knew not shall serve to me; 

#### Psalms 18:44 in the hearing of the ear they obeyed me. {sons Alien} lied to me. 

#### Psalms 18:45 {sons Alien} grew old and became lame from their paths. 

#### Psalms 18:46 The LORD lives, and blessed is God, and {is raised up high the God of my deliverance}. 

#### Psalms 18:47 The God, the one granting acts of vengeance to me, and submitting peoples under me; 

#### Psalms 18:48 my rescuer from my enemies prone to anger. {from the ones rising up against me You raised me up high}; from {man the unjust} you shall rescue me. 

#### Psalms 18:49 On account of this I shall make acknowledgment to you among the nations, O LORD, and to your name I shall strum; 

#### Psalms 18:50 the one magnifying the deliverance of the king; and appointing mercy to his anointed one, to David and to his seed unto the eon. 

#### Psalms 19:1 The heavens describe the glory of God, {the making and of his hands announces the firmament}. 

#### Psalms 19:2 Day to day bubbles up a saying; and night unto night announces knowledge. 

#### Psalms 19:3 There are no speeches nor words which {are not heard their voices}. 

#### Psalms 19:4 Into all the earth went forth their knell; and unto the ends of the inhabitable world their words. {in the sun He put his tent}. 

#### Psalms 19:5 And he, as a groom going forth from out of his nuptial chamber, shall exult as a giant running a journey. 

#### Psalms 19:6 From one tip of heaven is his exiting, and his arrival unto the other tip of heaven; and there is not one who shall be concealed from his heat. 

#### Psalms 19:7 The law of the lord is unblemished, turning souls. The witness of the LORD is trustworthy, making wise the infants. 

#### Psalms 19:8 The ordinances of the LORD are straight, making glad the heart. The commandment of the LORD is radiant, giving light to the eyes. 

#### Psalms 19:9 The fear of the LORD is pure, abiding into the eon of the eon. The judgments of the LORD are true, doing justice to the same; 

#### Psalms 19:10 desirable above gold, and {stone precious much}, and sweeter above honey and the honeycomb. 

#### Psalms 19:11 For also your servant guards them; in the guarding of them {reward there is great}. 

#### Psalms 19:12 {his transgressions Who shall perceive}? From out of my private transgressions cleanse me! 

#### Psalms 19:13 And from the aliens spare your servant! If they should not dominate me, then I will be unblemished, and I shall be cleansed of {sin great}. 

#### Psalms 19:14 And {will be for benevolence the oracles of my mouth}, and the meditation of my heart before you always, O LORD, my helper and the one ransoming me. 

#### Psalms 20:1 Let {heed you the LORD} in the day of affliction! Let {shield you the name of the God of Jacob}. 

#### Psalms 20:2 May he send to you help from the holy place, and from Zion may he assist you. 

#### Psalms 20:3 May {be remembered every sacrifice of yours}, and {your whole burnt-offering let him fatten}! 

#### Psalms 20:4 May {give to you the LORD} according to your heart, and {all your plans fulfill}. 

#### Psalms 20:5 We will exult over your deliverance; and in the name of the LORD our God we will be magnified. May the LORD fill all your requests. 

#### Psalms 20:6 Now I knew that the LORD delivered his anointed one; he shall heed him from out of {heaven his holy}. By dominations is the deliverance of his right hand. 

#### Psalms 20:7 These in chariots, and these in horses -- but we {in the name of the LORD our God shall call}. 

#### Psalms 20:8 They are bound hand and foot, and they fall; but we rose up and were re-erected. 

#### Psalms 20:9 O LORD, preserve the king, and heed us in what ever day we should call upon you! 

#### Psalms 21:1 O LORD, {in your power shall be glad the king}; and over your deliverance he shall exult exceedingly. 

#### Psalms 21:2 The desire of his heart you gave to him; and the supplication of his lips you did not deprive him. 

#### Psalms 21:3 For you were {beforehand with him} in blessings of graciousness. You put upon his head a crown of {stone precious}. 

#### Psalms 21:4 {life He asked} of you, and you gave to him duration of days, into the eon of the eon. 

#### Psalms 21:5 {is great His glory} in your deliverance; glory and majesty you shall place upon him. 

#### Psalms 21:6 For you shall give to him a blessing into the eon of the eon; you shall gladden him with joy with your countenance. 

#### Psalms 21:7 For the king hopes upon the LORD, and in the mercy of the highest in no way shall he be shaken. 

#### Psalms 21:8 May {be found your hand} by all your enemies; {your right hand may} be found by all the ones detesting you. 

#### Psalms 21:9 For you shall put them as an oven of fire in the time of your person; the LORD in his anger disturbs them, and {shall devour them fire}. 

#### Psalms 21:10 {their fruit from the earth You shall destroy}; and their seed from the sons of men. 

#### Psalms 21:11 For they leaned {to you bad things}, they argued over plans which in no way might they be able to establish. 

#### Psalms 21:12 For you shall put of them their back among your residue; you shall prepare their front. 

#### Psalms 21:13 Be raised up high, O LORD, in your power! We shall sing and strum of your dominations. 

#### Psalms 22:1 O God, my God, take heed to me! Why did you abandon me? {are far from my deliverance The words of my transgressions}. 

#### Psalms 22:2 My God, I shall cry out by day, and you do not hear; and by night and it shall not be accounted for thoughtlessness to me. 

#### Psalms 22:3 But you {in the holy place dwell}, the high praise of Israel. 

#### Psalms 22:4 Upon you {hoped our fathers}; they hoped, and you rescued them. 

#### Psalms 22:5 To you they cried out, and they were delivered; upon you they hoped, and they were not disgraced. 

#### Psalms 22:6 But I am a worm, and not a man; the scorn of men, and a contemptible thing of people. 

#### Psalms 22:7 All the ones viewing me derided me; they speak with their lips, they shook their head, saying, 

#### Psalms 22:8 He hoped upon the LORD, let him rescue him! Let him deliver him! for he desired him. 

#### Psalms 22:9 For you are the one pulling me from the womb; my hope from the breasts of my mother. 

#### Psalms 22:10 {upon you I was cast} from the womb; from out of the belly of my mother {my God you are}. 

#### Psalms 22:11 Do not separate from me, for affliction is near, for there is no one helping me. 

#### Psalms 22:12 {surround me calves Many}; {bulls hearty} compass me. 

#### Psalms 22:13 They opened {against me their mouths}, as a lion snatching away and roaring. 

#### Psalms 22:14 As water was poured out, even {were dispersed all my bones}; {became my heart} as beeswax melting away in the midst of my belly. 

#### Psalms 22:15 {was dried as a potsherd My strength}, and my tongue cleaves to my throat. And to the dust of death you led me. 

#### Psalms 22:16 For {encircled me dogs many}; the gathering of the ones acting wicked compass me. They dug into my hands and my feet. 

#### Psalms 22:17 They counted out all my bones, and they contemplated and looked upon me. 

#### Psalms 22:18 They divided {into parts my garments} to themselves; and over my clothes they cast a lot. 

#### Psalms 22:19 But you, O LORD, {should not be far your help} from me; {to my assistance take heed}! 

#### Psalms 22:20 Rescue {from the broadsword my soul}, and {from the hand of the dog my only child}! 

#### Psalms 22:21 Deliver me from the mouth of the lion, and from the horns of the unicorns of my humiliation! 

#### Psalms 22:22 I shall describe your name to my brethren; in the midst of the assembly I will praise you. 

#### Psalms 22:23 O ones fearing the LORD -- praise him! All together, O seed of Jacob, glorify him! Fear indeed of him all together, O seed of Israel! 

#### Psalms 22:24 For he did not treat with contempt, nor loath the supplication of the poor, nor turned his face from me. And in my crying out to him, he heard me. 

#### Psalms 22:25 {is about you My high praise}. In {assembly the great} I shall confess to you. My vows I shall render in the presence of the ones fearing him. 

#### Psalms 22:26 {shall eat The needy} and shall be filled up; and {shall praise the LORD the ones seeking him}; {shall live their hearts} into the eon of the eon. 

#### Psalms 22:27 {shall remember and shall turn to the LORD All the ones at the ends of the earth}; and {shall do obeisance before him all the families of the nations}. 

#### Psalms 22:28 For of the LORD is the kingdom; and he is master of the nations. 

#### Psalms 22:29 {ate and did obeisance All the hearty of the earth}; {before him fell down all the ones going down into the earth}. And my soul lives for him. 

#### Psalms 22:30 And my seed shall serve to him. {shall be announced to the LORD The generation coming}. 

#### Psalms 22:31 And they shall announce his righteousness to a people, to the one being born, whom {made the LORD}. 

#### Psalms 23:1 The LORD tends me, and not one thing lacks for me. 

#### Psalms 23:2 In the place of tender shoots, there he encamped me. At the water of rest, he nourished me. 

#### Psalms 23:3 {my life He returned}; he guided me upon roads of righteousness because of his name. 

#### Psalms 23:4 For if even I should go in the midst of the shadow of death, I shall not be afraid of evils, for you {with me are}. Your rod and your staff, they comfort me. 

#### Psalms 23:5 You prepared before me a table, right opposite the ones afflicting me. You anointed {with oil my head}, and your cup is intoxicating me as most excellent. 

#### Psalms 23:6 And your mercy pursues me all the days of my life; and my dwelling is in the house of the LORD for duration of days. 

#### Psalms 24:1 {is of the LORD The earth}, and the fullness of it; the inhabitable world, and all the ones dwelling in it. 

#### Psalms 24:2 He {upon seas founded it}; and upon rivers he prepared it. 

#### Psalms 24:3 Who shall ascend into the mountain of the LORD, or who shall stand in {place his holy}? 

#### Psalms 24:4 Innocent hands and a pure heart, who did not take hold upon vain things for his soul, and did not swear by an oath with treachery against his neighbor. 

#### Psalms 24:5 This one shall receive a blessing by the LORD, and charity from God his deliverer. 

#### Psalms 24:6 This is the generation seeking the LORD, seeking the face of the God of Jacob. 

#### Psalms 24:7 Let {lift the gates your rulers}! and let {be lifted up gates the eternal}! and {shall enter the king of glory}. 

#### Psalms 24:8 Who is this king of glory? The LORD, fortified and mighty; the LORD mighty in battle. 

#### Psalms 24:9 Let {lift the gates your rulers}! and let {be lifted up gates the eternal}! and {shall enter the king of glory}. 

#### Psalms 24:10 Who is this king of glory? The LORD of the forces, he is the king of glory. 

#### Psalms 25:1 To you, O LORD, I lifted up my soul. 

#### Psalms 25:2 O my God, upon you I have yielded. May I not be disgraced into the eon; nor let {ridicule me my enemies}! 

#### Psalms 25:3 For all the ones remaining with you in no way shall be disgraced. Let {be ashamed the ones acting lawlessly without cause}! 

#### Psalms 25:4 Your ways, O LORD, make known to me! and {your paths teach me}! 

#### Psalms 25:5 Guide me with your truth! and teach me that you are God my deliverer! and I waited on you all the day. 

#### Psalms 25:6 Remember your compassions, O LORD, and your mercies! for {from the eon they are}. 

#### Psalms 25:7 {the sins of my youth and my ignorance Do not remember}! but according to your mercy mention me to yourself, because of your graciousness, O LORD! 

#### Psalms 25:8 Gracious and upright is the LORD; because of this he shall establish law for ones sinning in the way. 

#### Psalms 25:9 He shall guide the gentle in judgment; he shall teach the gentle his ways. 

#### Psalms 25:10 All the ways of the LORD are mercy and truth to the ones seeking his covenant and his testimonies. 

#### Psalms 25:11 Because of your name, O LORD, atone my sin! {great for it is}. 

#### Psalms 25:12 Who is the man fearing the LORD? He shall establish law to him in the way, which he took up. 

#### Psalms 25:13 His soul {in good things shall be lodged}, and his seed shall inherit the earth. 

#### Psalms 25:14 The LORD is a fortification of the ones fearing him; and his covenant he manifested to them. 

#### Psalms 25:15 My eyes are always towards the LORD, for he shall pull out {from the snare my feet}. 

#### Psalms 25:16 Look upon me and have mercy on me! for {an only child and poor am I}. 

#### Psalms 25:17 The afflictions of my heart were multiplied; {from out of my necessities lead me}! 

#### Psalms 25:18 Behold my humiliation and my toil, and forgive all my sins! 

#### Psalms 25:19 Behold my enemies! for they were multiplied, and {hatred with unjust they detested me}. 

#### Psalms 25:20 Guard my soul, and rescue me! May I not be disgraced, for I hoped upon you. 

#### Psalms 25:21 The guileless and the upright cleave to me; for I remained with you, O LORD. 

#### Psalms 25:22 Ransom, O God, Israel from all his afflictions! 

#### Psalms 26:1 Judge me, O LORD! for I {in my innocence went}, and {upon the LORD hoping}. In no way should I weaken. 

#### Psalms 26:2 Try me, O LORD, and test me! Set on fire my kidneys and my heart! 

#### Psalms 26:3 For your mercy {before my eyes is}; and I was well-pleased in your truth. 

#### Psalms 26:4 I sat not with the sanhedrin of folly; and with ones acting unlawfully in no way shall I enter. 

#### Psalms 26:5 I detested the assembly of ones doing wickedness; and with the impious in no way shall I sit. 

#### Psalms 26:6 I shall wash {in innocent things my hands}, and I shall encircle your altar, O LORD, 

#### Psalms 26:7 to hear my voice of praise of you, and to describe all your wonders. 

#### Psalms 26:8 O LORD, I loved the beauty of your house, and the place of the tent of your glory. 

#### Psalms 26:9 You should not destroy together {with the impious my soul}, nor {with the men of blood my life}, 

#### Psalms 26:10 in whose hands are lawless deeds, and their right hand was filled of bribes. 

#### Psalms 26:11 But I {in my innocence was gone}. Ransom me, and show mercy on me! 

#### Psalms 26:12 My foot stands in straightness. In the assemblies I shall bless you, O LORD. 

#### Psalms 27:1 The LORD is my illumination and my deliverer, in whom shall I fear? The LORD is the defender of my life, from whom shall I be timid? 

#### Psalms 27:2 In the approaching against me by the ones inflicting evil to devour my flesh, the ones afflicting me, and my enemies, they weakened and fell. 

#### Psalms 27:3 If {should deploy against me a camp}, {shall not fear my heart}. If {should rise up against me war}, in this I will be hopeful. 

#### Psalms 27:4 One thing I asked of the LORD, this I shall seek -- for me to dwell in the house of the LORD all the days of my life; for me to view the delightfulness of the LORD, and to visit {temple his holy}. 

#### Psalms 27:5 For he hides me in his tent; in a day of my evils he sheltered me in concealment of his tent; in a rock he raised me up high. 

#### Psalms 27:6 And now behold, he raised up high my head over my enemies. I encircled and sacrificed in his tent a sacrifice of praise and of a shout; I shall sing and strum to the LORD. 

#### Psalms 27:7 Hear, O LORD, my voice which I cried out! Show mercy on me, and hear me! 

#### Psalms 27:8 To you {said my heart}, I seek the LORD, I sought after you with my face. Your face, O LORD, I shall seek. 

#### Psalms 27:9 You should not turn your face from me, and you should not turn aside in anger from your servant. {my helper Become}! Do not curse me to be far away, and do not abandon me, and do not overlook me, O God my deliverer! 

#### Psalms 27:10 For my father and my mother abandoned me, but the LORD took me to himself. 

#### Psalms 27:11 Establish the law for me, O LORD, in your way! And guide me in {road the straight}, because of my enemies! 

#### Psalms 27:12 Do not deliver me into the souls of ones afflicting me! For {rose up against me witnesses unjust}; for {lied unjustness} to herself. 

#### Psalms 27:13 I trust to behold the good things of the LORD in the land of the living. 

#### Psalms 27:14 Wait on the LORD! Be manly and fortify your heart, and wait on the LORD! 

#### Psalms 28:1 To you, O LORD, I shall cry out. My God, do not remain silent from me! lest at any time you should remain silent, and I shall be likened to the ones going down into the pit. 

#### Psalms 28:2 Hear, O LORD, the voice of my supplication! in my beseeching to you, in my lifting my hands towards {temple your holy}. 

#### Psalms 28:3 Do not draw me together with sinners! And {with ones working injustice do not destroy me together}! of the ones speaking peace with their neighbors, but evils are in their hearts. 

#### Psalms 28:4 Give to them, O LORD, according to their works, and according to the wickedness of their practices! {according to the works of their hands Give to them}! Render their recompense unto them! 

#### Psalms 28:5 For they perceived not unto the works of the LORD, even unto the works of his hands. You shall demolish them, and in no way build them up. 

#### Psalms 28:6 Blessed be the LORD, for he heard the voice of my supplication. 

#### Psalms 28:7 The LORD is my helper and my defender; upon him {hoped my heart}, and I was helped; and {flourished again my flesh}, and by my will I will make acknowledgment to him. 

#### Psalms 28:8 The LORD is the fortification of his people, and {the defender of the deliverances of his anointed one he is}. 

#### Psalms 28:9 Deliver your people, and bless your inheritance, and tend them, and lift them up unto the eon! 

#### Psalms 29:1 Bring to the LORD, O sons of God, bring to the LORD offspring of rams! Bring to the LORD glory and honor! 

#### Psalms 29:2 Bring to the LORD the glory of his name! Do obeisance to the LORD in {courtyard his holy}! 

#### Psalms 29:3 The voice of the LORD is upon the waters. The God of glory thunders. The LORD is upon {waters many}. 

#### Psalms 29:4 The voice of the LORD is in strength. The voice of the LORD is in majesty. 

#### Psalms 29:5 The voice of the LORD breaking cedars; even the LORD breaks the cedars of Lebanon; 

#### Psalms 29:6 and he shall thin them out as the calf of Lebanon; even the one being loved as a son of unicorns. 

#### Psalms 29:7 The voice of the LORD cutting through the flame of fire. 

#### Psalms 29:8 The voice of the LORD shaking the wilderness; and the LORD shall shake the wilderness of Kadesh. 

#### Psalms 29:9 The voice of the LORD fashioning the hinds; and he shall uncover the groves; and in his temple all who say, Glory. 

#### Psalms 29:10 The LORD {the flood shall settle}; and {will sit the LORD} a king into the eon. 

#### Psalms 29:11 The LORD {strength to his people shall give}. The LORD shall bless his people with peace. 

#### Psalms 30:1 I will exalt you, O LORD, for you uplifted me, and {did not make glad my enemies} over me. 

#### Psalms 30:2 O LORD my God, I cried out to you, and I shall heal of my condition. 

#### Psalms 30:3 O LORD, you led {from out of Hades my soul}; you delivered me from the ones going down into the pit. 

#### Psalms 30:4 Let {strum to the LORD his sacred ones}, and make acknowledgment to the remembrance of his holiness! 

#### Psalms 30:5 For wrath is in his rage, but life is in his will. {the evening shall lodge Weeping}, but in the morning, exultation. 

#### Psalms 30:6 And I said in my prosperity, In no way shall I be shaken into the eon. 

#### Psalms 30:7 O LORD, in your will you furnished {to my beauty power}; but you turned your face, and I became disturbed. 

#### Psalms 30:8 To you, O LORD, I cry out. And to my God I shall beseech. 

#### Psalms 30:9 What benefit is there in my blood, in my going down into corruption? Shall {acknowledge you the dust}, or shall it announce your truth? 

#### Psalms 30:10 The LORD heard, and showed mercy on me. The LORD became my helper. 

#### Psalms 30:11 {turned The beating of my breast} into joy for me. You tore up my sackcloth, and girded me with gladness. 

#### Psalms 30:12 O how that should {strum to you my glory}, and in no way should I be vexed, O LORD my God. Into the eon I shall acknowledge you. 

#### Psalms 31:1 Upon you, O LORD, I hoped. May I not be disgraced into the eon. In your righteousness rescue me, and take me out! 

#### Psalms 31:2 Lean {to me your ear}! Hasten to take me out! Become to me as a defending God! and for a house of refuge to deliver me. 

#### Psalms 31:3 For {my fortification and my refuge you are}; and because of your name you shall guide me and nourish me. 

#### Psalms 31:4 You shall lead me out of the snare which these hid for me; for you are my defender, O LORD. 

#### Psalms 31:5 Into your hands I shall place my spirit. You ransomed me, O LORD God of truth. 

#### Psalms 31:6 You detested the ones guarding {follies ineffectual}. But I {upon the LORD hoped}. 

#### Psalms 31:7 I will exult and be glad over your mercy, for you looked upon my humiliation. You delivered {from the wants of necessities my soul}; 

#### Psalms 31:8 and you did not close me up by hands of enemies. You set {in a broad space my feet}. 

#### Psalms 31:9 Show mercy on me, O LORD! for I am afflicted. {are disturbed in rage My eye my soul and my belly}; 

#### Psalms 31:10 for {failed in grief my life}, and my years in moanings. {weakened in poorness My strength}, and my bones are disturbed. 

#### Psalms 31:11 By all my enemies I became a scorn, even to my neighbors exceedingly so, and a fear to my acquaintances. The ones viewing me outside fled from me. 

#### Psalms 31:12 I was forgotten as one dead from the heart; I am become as a vessel being destroyed. 

#### Psalms 31:13 For I heard the fault of many sojourning round about. In their gathering together against me {to take my soul they consulted}. 

#### Psalms 31:14 But I {upon you O LORD hoped}. I said, You are my God. 

#### Psalms 31:15 {are in your hands My lots}. Rescue me from the hand of my enemies, and from the ones pursuing me! 

#### Psalms 31:16 Let {appear your face} unto your servant! Deliver me in your mercy! 

#### Psalms 31:17 O LORD, may I not be disgraced, for I called upon you. May {be ashamed the impious}, and led down into Hades. 

#### Psalms 31:18 {speechless Let become the lips of the deceitful}! even the ones speaking against the just in lawlessness with pride and contempt. 

#### Psalms 31:19 How abundant is the multitude of your graciousness, O LORD, of which you hid to the ones fearing you. You brought it to completion to the ones hoping upon you, before the sons of men. 

#### Psalms 31:20 You shall hide them in the concealment of your face from the disturbance of men. You shall shelter them in a tent from the dispute of tongues. 

#### Psalms 31:21 Blessed be the LORD, for {caused wonders his mercy} in the city encompassed about. 

#### Psalms 31:22 But I said in my change of state, I am thrown away from in front of your eyes. On account of this you heard of the voice of my supplication in my crying out to you. 

#### Psalms 31:23 Let {love the LORD all his sacred ones}! For {truth requires the LORD}; and he recompenses {to the ones extremely} having pride. 

#### Psalms 31:24 Let {be manly and be fortified in your heart all the ones hoping upon the LORD}! 

#### Psalms 32:1 Blessed be whose {were forgiven lawless deeds}, and whose {were covered over sins}. 

#### Psalms 32:2 Blessed be the man to whom in no way the LORD should impute sin, nor is {in his mouth treachery}. 

#### Psalms 32:3 For I kept quiet; {were grown old my bones} from my crying out the entire day. 

#### Psalms 32:4 For day and night {presses upon me your hand}. I was turned to misery by the {sticking me thorn}. 

#### Psalms 32:5 My lawlessness I made known, and my sin I did not cover. I said, I will declare openly against myself my lawlessness to the LORD. And you forgave the impiety of my heart. PAUSE. 

#### Psalms 32:6 For this {shall pray to you every sacred one} in {time a fit}; only in a flood of waters many {to him shall not approach}. 

#### Psalms 32:7 You are my refuge from affliction encompassing me; my leap for joy to ransom me from the ones encircling me. PAUSE. 

#### Psalms 32:8 I will bring understanding to you, and I will instruct you in this way which you shall go. I will stay {upon you my eyes}. 

#### Psalms 32:9 Do not become as a horse and mule in which there is no understanding; but with muzzle and bridle {their jaws may you squeeze} of the ones not approaching to you. 

#### Psalms 32:10 Many are the whips for the sinner; {the one but hoping upon the LORD mercy shall encircle}. 

#### Psalms 32:11 Be glad upon the LORD, and exult, O just ones! and let {boast all the ones straight in the heart}! 

#### Psalms 33:1 Exult, O just ones, in the LORD! To the upright {is becoming praise}. 

#### Psalms 33:2 Make acknowledgment to the LORD with the harp! With {psaltery the ten-stringed} strum to him! 

#### Psalms 33:3 Sing to him {song a new}! {well Strum to him} with shouts! 

#### Psalms 33:4 For {is upright the word of the LORD}; and all his works in trust. 

#### Psalms 33:5 {loves charity and equity The LORD}; {of the mercy of the LORD is full the earth}. 

#### Psalms 33:6 By the word of the LORD the heavens were solidified, and by the breath of his mouth all their force; 

#### Psalms 33:7 bringing together as in a leather water bag the waters of the sea; putting in treasuries of the deeps. 

#### Psalms 33:8 Fear the LORD all the earth! {because of him and} let {be shaken all the ones dwelling in the inhabitable world}! 

#### Psalms 33:9 For he spoke, and they came to pass; he gave charge, and they were created. 

#### Psalms 33:10 The LORD effaces plans of nations, and he annuls devices of peoples, and he annuls plans of rulers. 

#### Psalms 33:11 But the counsel of the LORD {into the eon abides}; the devices of his heart from generation and generation. 

#### Psalms 33:12 Blessed is the nation of which the LORD is its God; a people whom he chose for his own inheritance. 

#### Psalms 33:13 From out of heaven {looks the LORD}; he beholds all the sons of men. 

#### Psalms 33:14 From {prepared home his} he looked upon all the ones dwelling on the earth. 

#### Psalms 33:15 He is the one shaping {alone their hearts}; the one perceiving in all their works. 

#### Psalms 33:16 {is not delivered A king} because of much force; and a giant shall not be delivered by the magnitude of his strength. 

#### Psalms 33:17 {is a false hope A horse} for deliverance, and in the magnitude of its power one shall not be delivered. 

#### Psalms 33:18 Behold, the eyes of the LORD are upon the ones fearing him; the ones hoping upon his mercy; 

#### Psalms 33:19 to rescue {from death their souls}, and to nourish them during famine. 

#### Psalms 33:20 And our soul waits on the LORD, for {helper and defender he is our}. 

#### Psalms 33:21 For in him {shall be glad our heart}; and in {name his holy} we hope. 

#### Psalms 33:22 May {come your mercy}, O LORD, upon us, just as we hoped upon you. 

#### Psalms 34:1 I will bless the LORD at all time; always his praise is in my mouth. 

#### Psalms 34:2 {in the LORD shall applaud My soul}. Let {hear the gentle} and be glad! 

#### Psalms 34:3 Magnify the LORD with me! for we should raise up high his name together. 

#### Psalms 34:4 I sought after the LORD, and he heeded me; and out of all my afflictions he rescued me. 

#### Psalms 34:5 Come forward to him, and be enlightened! and your faces in no way shall be disgraced. 

#### Psalms 34:6 This poor man cried out, and the LORD heard him; and from out of all his afflictions he delivered him. 

#### Psalms 34:7 {will encamp The angel of the LORD} round about the ones fearing him, and he will rescue them. 

#### Psalms 34:8 Taste and see that {is gracious the LORD}! Blessed is the man who hopes upon him. 

#### Psalms 34:9 Let {fear the LORD all his holy ones}! for there is no deficiency to the ones fearing him. 

#### Psalms 34:10 The rich became poor, and they hunger; but the ones seeking after the LORD shall not lack any good thing. 

#### Psalms 34:11 Come children, hear me! {a fear of the LORD I will teach you}. 

#### Psalms 34:12 Who is the man wanting life, loving {days to behold good}? 

#### Psalms 34:13 Cease your tongue from evil! and your lips, so as to not speak treachery. 

#### Psalms 34:14 Turn aside from the bad, and do good! Seek peace, and pursue it! 

#### Psalms 34:15 The eyes of the LORD are upon the just, and his ears are unto their supplication. 

#### Psalms 34:16 But the face of the LORD is against the ones committing evils, to utterly destroy {from the earth their memorial}. 

#### Psalms 34:17 {cried out The just}, and the LORD heard them; and from out of all their afflictions he rescued them. 

#### Psalms 34:18 The LORD is near to the ones being broken in heart; and the humble in spirit he shall deliver. 

#### Psalms 34:19 Many are the afflictions of the just; and from out of all of them {shall rescue them the LORD}. 

#### Psalms 34:20 The LORD guards all their bones; {one of them not} shall be broken. 

#### Psalms 34:21 The death of sinners is a sorry state; and the ones detesting the just shall offend. 

#### Psalms 34:22 The LORD shall ransom the souls of his servants; and in no way shall {offend all the ones hoping upon him}. 

#### Psalms 35:1 Adjudicate, O LORD, the ones wronging me! Wage war against the ones waging war against me! 

#### Psalms 35:2 Take hold of weapon and shield, and rise up to help me! 

#### Psalms 35:3 Discharge the broadsword, and close up right opposite the ones pursuing me! Say to my soul, {your deliverance I am}! 

#### Psalms 35:4 Let {be ashamed and feel remorse the ones seeking my soul}! Let them be turned to the rear, and let {be disgraced the ones considering evils against me}! 

#### Psalms 35:5 Let them become as dust according to the face of the wind! and an angel of the LORD squeezing them. 

#### Psalms 35:6 Let {become their way} darkness and slippery! and an angel of the LORD pursuing them. 

#### Psalms 35:7 For without cause they hid {against me of corruption their snare}; in folly they berate my soul. 

#### Psalms 35:8 Let there come to him a snare which he knows not! And the snare of the hunt which he hid, let it seize him! and in the same snare he shall fall in it. 

#### Psalms 35:9 But my soul shall exult over the LORD; it shall be made happy over his deliverance. 

#### Psalms 35:10 All my bones shall say, O LORD, O LORD, who is likened to you? rescuing the poor from the hand of the one more solid than he, and the poor and needy one from the ones tearing him in pieces. 

#### Psalms 35:11 Rising up against me {witnesses are unjust}, {of things which I did not know asking me}. 

#### Psalms 35:12 They recompensed to me evil for good, and childlessness to my soul. 

#### Psalms 35:13 But I, in their troubling me, put on sackcloth. And I humbled {in fasting my soul}; and my prayer {unto my bosom shall be returned}. 

#### Psalms 35:14 As a neighbor, as {brother to our}, so they were well-pleasing. As mourning and looking downcast so I humbled myself. 

#### Psalms 35:15 And against me they were glad and they gathered together; they gathered together {against me whips}, and I did not know; they were cut asunder and were not vexed. 

#### Psalms 35:16 They tested me; they derided me in sneering; they gnashed against me with their teeth. 

#### Psalms 35:17 O LORD, when will you scrutinize? Restore my soul from their evil actions; {from lions my only child}. 

#### Psalms 35:18 I shall make acknowledgment to you in {assembly the vast}; with {people grievous} I shall praise you. 

#### Psalms 35:19 May {not rejoice against me the ones hating me unjustly}; even the ones detesting me without a charge, and shunning their eyes. 

#### Psalms 35:20 For to me then {peaceable they spoke}, but in anger {treachery they devised}. 

#### Psalms 35:21 And they widened {against me their mouth}. They said, Well done, well done, {saw our eyes}! 

#### Psalms 35:22 You beheld, O LORD. You should not remain silent, O LORD. You should not separate from me. 

#### Psalms 35:23 Awake, O LORD, and take heed to my case, O my God, and {O my LORD to my cause}! 

#### Psalms 35:24 Judge me, O LORD, according to your righteousness, O LORD my God, and let them not rejoice against me! 

#### Psalms 35:25 May they not say in their heart, Well done, well done to our soul. Nor may they say, We swallowed him down. 

#### Psalms 35:26 May they be ashamed, and may {feel remorse together the ones rejoicing at my hurts}. Let {be clothed in shame and remorse the ones speaking great words against me}! 

#### Psalms 35:27 Exult and be glad, O ones wanting righteousness for me! And let say always, {be magnified The LORD}! by the ones wanting the peace of his servant. 

#### Psalms 35:28 And my tongue shall meditate upon your righteousness; the entire day on your high praise. 

#### Psalms 36:1 {speaks The lawbreaker so as to sin in himself}; there is no fear of God before his eyes. 

#### Psalms 36:2 For he acted treacherously before him, so as to find out his lawlessness and detest. 

#### Psalms 36:3 The sayings of his mouth are lawlessness and treachery; he wanted not to perceive how to do good. 

#### Psalms 36:4 {lawlessness He reasons} upon his bed; he renders to every way not good; and evil he did not loath. 

#### Psalms 36:5 O LORD, {is in the heaven your mercy}, and your truth unto the clouds. 

#### Psalms 36:6 Your righteousness is as the mountains of God; your judgments {abyss a vast}. {men and cattle You shall preserve}, O LORD. 

#### Psalms 36:7 How you multiplied your mercy, O God; and the sons of men {in the protection of your wings shall hope}. 

#### Psalms 36:8 They shall be intoxicated from the fatness of your house; and {of the rushing stream of your delicacy you shall water them}. 

#### Psalms 36:9 For from you is the spring of life. In your light we shall see light. 

#### Psalms 36:10 Extend your mercy to the ones knowing you, and your righteousness to the ones straight in heart! 

#### Psalms 36:11 Let not {come against me the foot of pride}! nor the hand of the sinner to shake me. 

#### Psalms 36:12 There they fell -- all the ones working lawlessness. They were pushed out, and in no way shall they be able to stand. 

#### Psalms 37:1 Be not provoked to jealousy with ones acting wickedly, nor be jealous of the ones doing lawlessness! 

#### Psalms 37:2 For {as grass quickly they shall be dried up}, and as vegetation of tender shoots they shall quickly fall away. 

#### Psalms 37:3 Hope upon the LORD, and execute graciousness! And encamp in the land! and you shall be tended by its riches. 

#### Psalms 37:4 Revel in the LORD! that he should give to you the requests of your heart. 

#### Psalms 37:5 Reveal to the LORD your way, and hope upon him! and he will act. 

#### Psalms 37:6 And he shall bring forth {as light your righteousness}, and your practice as at midday. 

#### Psalms 37:7 Submit to the LORD, and entreat him! Be not provoked to jealousy in the prospering {in his way by a man doing unlawfulness}! 

#### Psalms 37:8 Cease from anger, and abandon rage! Be not provoked to jealousy so as to do wicked! 

#### Psalms 37:9 For the ones doing wicked shall be utterly destroyed; but the ones waiting on the LORD, they shall inherit the land. 

#### Psalms 37:10 And yet in a short time, and in no way shall {exist the sinner}; and if shall you seek his place, then in no way shall you find it. 

#### Psalms 37:11 But the gentle shall inherit the earth, and they shall revel over an abundance of peace. 

#### Psalms 37:12 {shall closely watch The sinner} the just, and shall gnash {over him his teeth}. 

#### Psalms 37:13 But the LORD shall laugh out loud at him, for he foresees that {will come his day}. 

#### Psalms 37:14 {the broadsword unsheathed The sinners}; they stretched tight their bow to throw down the poor and needy, to slay the straight in heart. 

#### Psalms 37:15 {their broadsword May} enter into their own hearts; and {their bows may} be broken. 

#### Psalms 37:16 Better is a little to the just, than {riches of sinners many}. 

#### Psalms 37:17 For the arms of sinners shall be broken; {supports but the just the LORD}. 

#### Psalms 37:18 The LORD knows the ways of the unblemished; and their inheritance {into the eon shall be}. 

#### Psalms 37:19 They will not be disgraced in {time a bad}, and in the days of hunger they shall be filled. 

#### Psalms 37:20 For the sinners shall be destroyed. And the enemies of the LORD at the same time in their being glorified and exalted, {vanishing as smoke vanished}. 

#### Psalms 37:21 {borrows The sinner}, and does not pay back; but the just pities, and gives. 

#### Psalms 37:22 For the ones blessing him shall inherit land; but the ones cursing him shall be utterly destroyed. 

#### Psalms 37:23 {by the LORD The footsteps of a man are straightened out}; and {his way he shall want} exceedingly. 

#### Psalms 37:24 Whenever he shall fall he will not break, for the LORD gives support to his hand. 

#### Psalms 37:25 {younger I was once} and I grew old; and {not I beheld the just} being abandoned, nor his seed seeking bread loaves. 

#### Psalms 37:26 {the entire day shows mercy and lends The righteous}, and his seed {for a blessing will be}. 

#### Psalms 37:27 Turn aside from evil and do good, and encamp into the eon of the eon! 

#### Psalms 37:28 For the LORD loves equity, and shall not abandon his sacred ones; into the eon they shall be guarded. But lawless ones shall be driven out, and the seed of the impious shall be utterly destroyed. 

#### Psalms 37:29 But the just shall inherit the earth, and encamp into the eon of the eon upon it. 

#### Psalms 37:30 The mouth of the just shall meditate upon wisdom, and his tongue shall speak equity. 

#### Psalms 37:31 The law of his God is in his heart; and {shall not be tripped up his footsteps}. 

#### Psalms 37:32 {contemplates The sinner} the just, and seeks to kill him. 

#### Psalms 37:33 But the LORD in no way shall abandon him into his hands, nor in no way should he condemn him whenever he should judge him. 

#### Psalms 37:34 Wait on the LORD, and guard his way! and he shall exalt you to inherit the land, in the one {being utterly destroyed sinners you will see}. 

#### Psalms 37:35 I beheld the impious being greatly exalted, and being lifted up as the cedars of Lebanon. 

#### Psalms 37:36 And I went by, and behold, he was not. And I sought him, and {was not found his place}. 

#### Psalms 37:37 Guard innocence, and know straightness! for there is a leftover {man for the peaceable}. 

#### Psalms 37:38 But the lawbreakers shall be utterly destroyed together; the leftovers of the impious shall be utterly destroyed. 

#### Psalms 37:39 But deliverance of the just is by the LORD; and {defender their he is} in time of affliction. 

#### Psalms 37:40 And {shall help them the LORD}, and shall rescue them; and he shall take them away from the sinners; and he shall deliver them, for they hoped upon him. 

#### Psalms 38:1 O LORD, let not your rage reprove me, nor your anger correct me! 

#### Psalms 38:2 For your arrows were stuck in me, and {stayed upon me your hand}. 

#### Psalms 38:3 There is no healing in my flesh from the face of your anger; there is no peace in my bones from the face of my sins. 

#### Psalms 38:4 For my lawless deeds are elevated above my head; as {load a heavy} they were oppressed upon me. 

#### Psalms 38:5 {give out an odor and fester My stripes} from the face of my folly. 

#### Psalms 38:6 I was in misery and bent down until the end. All the day {looking downcast I went}. 

#### Psalms 38:7 For my flanks were filled of mockeries, and there is no healing in my flesh. 

#### Psalms 38:8 I was afflicted with evil and humbled, even unto exceedingly. I roared from the moaning of my heart. 

#### Psalms 38:9 O LORD, before you is all my desire; and my moaning from you can not be concealed. 

#### Psalms 38:10 My heart is disturbed; {abandoned me my strength}; even the light of my eyes, even it is not with me. 

#### Psalms 38:11 My friends and my neighbors right opposite me approached and stood; and the ones nearest to me {from afar off stood}. 

#### Psalms 38:12 And {expelled me the ones seeking my life}; and the ones seeking bad things for me spoke follies; and {on deceits the entire day they meditated}. 

#### Psalms 38:13 But I, as a deaf-mute, did not hear; and was as one speechless not opening his mouth. 

#### Psalms 38:14 And I became as a man not hearing, and not having {in his mouth rebukes}. 

#### Psalms 38:15 For upon you, O LORD, I hoped. You will hear, O LORD my God. 

#### Psalms 38:16 For I spoke, lest at any time {rejoice over me my enemies}, and at the shaking of my feet {against me they spoke great words}. 

#### Psalms 38:17 For I {for whips am prepared}, and my suffering {before me is always}. 

#### Psalms 38:18 For my lawlessness I will announce; and I will be anxious concerning my sin. 

#### Psalms 38:19 But my enemies live, and are fortified over me; and {multiply the ones detesting me unjustly}. 

#### Psalms 38:20 The ones recompensing to me bad for good slandered me when they pursued righteousness. 

#### Psalms 38:21 You should not abandon me, O LORD my God; you should not separate from me. 

#### Psalms 38:22 Take heed for my help, O LORD of my deliverance! 

#### Psalms 39:1 I said, I shall guard my ways {to not sin for me} with my tongue. I put {for my mouth a guard} while the {stood sinner} before me. 

#### Psalms 39:2 I was mute and humbled and quiet of good words, and my pain was renewed. 

#### Psalms 39:3 {heated My heart} within me; and in my meditation {would burn away a fire}; I spoke with my tongue. 

#### Psalms 39:4 Make known to me, O LORD, my limit! and the number of my days, what it is, that I should know what I lack. 

#### Psalms 39:5 Behold, {a palm you established} for my days; and my essence is as nothing before you. Furthermore, {all things are folly for every man living}. 

#### Psalms 39:6 However, {with an image travels a man}, except, {in folly he is disturbed}. He treasures up, but does not know why he shall gather them. 

#### Psalms 39:7 And now, what of my endurance -- is it not the LORD? Even my support {from you is}. 

#### Psalms 39:8 From all my lawless deeds rescue me! {for scorn to the fool You gave me}. 

#### Psalms 39:9 I was made mute, and I did not open my mouth, for you did it. 

#### Psalms 39:10 Abstain {from me your whips}; from the strength of your hand I failed. 

#### Psalms 39:11 With rebukes for lawlessness you corrected man; and {wastes away as a spider's his life}; besides -- {is folly every man}. PAUSE. 

#### Psalms 39:12 Hear my prayer, O LORD, and my supplication! Give ear to my tears! Be not silent! for {a sojourner I am} with you, and an immigrant, as all my fathers. 

#### Psalms 39:13 Spare me! that I shall refresh before my going forth, and should no longer in any way exist. 

#### Psalms 40:1 Enduring, I waited on the LORD, and he took heed to me, and he heard my supplication. 

#### Psalms 40:2 And he led me from out of the pit of misery, and from the mud of slime. And he stood {upon the rock my feet}, and straightened out my footsteps. 

#### Psalms 40:3 And he put into my mouth {song a new}, a hymn to our God. {shall see Many}, and shall fear, and shall hope upon the LORD. 

#### Psalms 40:4 Blessed is the man of which {is in the name of the LORD his hope}, and did not look to follies and {frenzies false}. 

#### Psalms 40:5 Many things you did yourself, O LORD my God, concerning your wonders; and concerning your devices there is not any that shall be likened to you. I reported and spoke -- they were multiplied above number. 

#### Psalms 40:6 A sacrifice and offering you wanted not, but a body you readied to me; whole burnt-offerings and a sacrifice for sin you did not seek. 

#### Psalms 40:7 Then I said, Behold, I come. In the chapter of the scroll it is written concerning me. 

#### Psalms 40:8 To do your will, O my God I wanted; and your law is in the midst of my belly. 

#### Psalms 40:9 I announced good news -- righteousness in {assembly the great}. Behold, {my lips in no way should I restrain}, O LORD, you know. 

#### Psalms 40:10 My righteousness I hid not in my heart; your truth and your deliverance I told; I hid not your mercy and your truth from the gathering of many. 

#### Psalms 40:11 But you, O LORD, {should not be far your compassions} from me. Your mercy and your truth, {always may they} take hold of me. 

#### Psalms 40:12 For {compass me bad things} which there is no number. {overtook me My lawless deeds}, and I was not able to see. They were multiplied over the hairs of my head; and my heart abandoned me. 

#### Psalms 40:13 Think well, O LORD, to rescue me! O LORD, {to help me take heed}! 

#### Psalms 40:14 May {be disgraced and feel shame together the ones seeking my life to lift it away}. May they be turned back to the rear, and may {feel shame the ones wanting bad things for me}. 

#### Psalms 40:15 Let them carry immediately their shame -- the ones saying to me, Well done. well done. 

#### Psalms 40:16 {exult and are glad over you All the ones seeking you}, O LORD. And let {say always let the LORD be magnified the ones loving your deliverance}! 

#### Psalms 40:17 But I am poor and needy; the LORD will be thoughtful of me. {my helper and my defender You are}, O my God, you should not delay. 

#### Psalms 41:1 Blessed is the one taking notice upon the poor and needy; {in day the evil shall rescue him the LORD}. 

#### Psalms 41:2 May the LORD guard him, and enliven him, and bless him in the land; and may he not deliver him into the hands of his enemies. 

#### Psalms 41:3 Let the LORD help him upon the bed of his grief! {all of his bed You turned} in his illness. 

#### Psalms 41:4 I said, O LORD, show mercy on me! Heal my soul! for I sinned against you. 

#### Psalms 41:5 My enemies said bad things against me, saying, When shall he die and {perish his name}? 

#### Psalms 41:6 And if he entered to see me, {folly spoke his heart}. He gathered lawlessness to himself; he went forth outside and spoke in the same manner. 

#### Psalms 41:7 {against me whispered All my enemies}; against me they devised bad things for me. 

#### Psalms 41:8 {matter an illegal They laid down against me}, saying, Shall the one going to bed not proceed to rise up? 

#### Psalms 41:9 For also the man of my peace upon whom I hoped, the one eating my bread loaves, magnified against me with trickery. 

#### Psalms 41:10 But you, O LORD, show mercy on me, and raise me up, and recompense to them! 

#### Psalms 41:11 By this I knew that you wanted me, that in no way should {rejoice my enemy} over me. 

#### Psalms 41:12 {my But because of} innocence you assisted and firmed me up before you into the eon. 

#### Psalms 41:13 Blessed be the LORD God of Israel, from the eon and into the eon. May it be, May it be. 

#### Psalms 42:1 In which manner {longs the stag} after the springs of the waters, so {longs my soul} after you, O God. 

#### Psalms 42:2 {thirsted My soul} for {God the mighty living}. When shall I come and appear in front of God? 

#### Psalms 42:3 {became My tears} bread for me day and night, while saying to me each day, Where is your God? 

#### Psalms 42:4 These things I remembered, and {poured out upon me my soul}, for I shall go through to the place {tent of the wonderful}, unto the house of God, with a voice of exultation, and acknowledgment of the sound of the solemnizing a holiday. 

#### Psalms 42:5 Why are you dejected, O my soul? and why do you disturb me? Hope upon God! for I shall acknowledge to him the deliverance of my person. 

#### Psalms 42:6 O my God, to myself my soul was disturbed; on account of this I will remember you from the land of Jordan, and Hermons, from {mountain the small}. 

#### Psalms 42:7 The deep {the deep calls} at the sound of your torrents; all your crests and your waves {over me went}. 

#### Psalms 42:8 By day the LORD gives charge to his mercy, and at night his ode shall be with me -- a prayer to the God of my life. 

#### Psalms 42:9 I will say to God, {shielder You are my}; why did you forget me? Why {looking downcast do I go} at the squeezing by the enemy? 

#### Psalms 42:10 In the breaking in pieces of my bones, {berated me the ones afflicting me}; while in their saying to me accordingly each day, Where is your God? 

#### Psalms 42:11 Why are you dejected, O my soul? and why do you disturb me? Hope upon God! for I shall acknowledge to him the deliverance of my person, and my God. 

#### Psalms 43:1 Judge for me, O God, and adjudicate my cause, from a nation which is not sacred! {from a man unjust and deceitful rescue me}! 

#### Psalms 43:2 For you are the God of my fortification. Why did you thrust me away? And why {looking downcast do I go} during the squeezing by the enemy? 

#### Psalms 43:3 Send out your light, and your truth! they guided me, and they led me to {mountain your holy}, and to your tents. 

#### Psalms 43:4 And I shall enter to the altar of God; to the God gladdening my youth. I will acknowledge to you with the harp, O God my God. 

#### Psalms 43:5 Why are you dejected, O my soul? and why disturb me? Hope upon God! for I shall make acknowledgment to him, the deliverance of my person, and my God. 

#### Psalms 44:1 O God, {with our ears we heard}, and our fathers announced to us the work which you worked in their days, in {days ancient}. 

#### Psalms 44:2 Your hand {nations utterly destroyed}, and planted them. You afflicted peoples and cast them out. 

#### Psalms 44:3 For not by their broadsword they inherited the land, and their arm did not deliver them; but it was your right hand, and your arm, and the illumination of your countenance, for you thought well by them. 

#### Psalms 44:4 You are he, O my king and my God, the one giving charge to the deliverances of Jacob. 

#### Psalms 44:5 In you {our enemies we will gore}, and in your name we will treat with contempt the ones rising up against us. 

#### Psalms 44:6 For not upon my bow will I hope; and my broadsword will not deliver me. 

#### Psalms 44:7 For he delivered us from the ones afflicting us; and the ones detesting us he disgraced. 

#### Psalms 44:8 In God we will be praised the entire day; and in your name we will make acknowledgment into the eon. 

#### Psalms 44:9 But now you thrusted away, and disgraced us; and you shall not go forth, O God, with our forces. 

#### Psalms 44:10 You turned us to the rear by our enemies; and the ones detesting us plundered for themselves. 

#### Psalms 44:11 You gave us as sheep for food; and among the nations you scattered us. 

#### Psalms 44:12 You rendered your people without a value; and there was no abundance by their shout. 

#### Psalms 44:13 You put us for scorn to our neighbors; for a sneering and a taunting to the ones round about us. 

#### Psalms 44:14 You put us as a parable among the nations; a shaking of the head among the peoples. 

#### Psalms 44:15 {the entire day My being made ashamed in front of me is}, and the shame of my face covered me; 

#### Psalms 44:16 even from the voice of the one berating and speaking improperly from in front of the enemy and the one banishing. 

#### Psalms 44:17 All these things came upon us, but we did not forget you; and we did not do wrong by your covenant; 

#### Psalms 44:18 and we did not leave {to the rear our heart}, nor turned aside our paths from your way. 

#### Psalms 44:19 For you humbled us in the place of affliction; and {covered over us the shadow of death}. 

#### Psalms 44:20 If we forgot the name of our God, and if we opened and spread out our hands to {god an alien}, 

#### Psalms 44:21 shall not God require these things? For he knows the secret things of the heart. 

#### Psalms 44:22 For because of you we are being put to death the entire day; we are considered as sheep for slaughter. 

#### Psalms 44:23 Awaken! Why do you sleep, O LORD? Rise up! and you should not thrust us away unto the end. 

#### Psalms 44:24 Why {your face do you turn} and forget our poorness and our affliction? 

#### Psalms 44:25 For {was humbled into the dust our soul}; {was cleaved to the earth our belly}. 

#### Psalms 44:26 Rise up, O LORD, help us and ransom us because of your name! 

#### Psalms 45:1 {discharged forth My heart word a good}. I speak of my works to the king. My tongue is a reed pen of a scribe writing fast. 

#### Psalms 45:2 More beautiful in beauty than the sons of men. {was poured out Favor} on your lips. On account of this {blessed you God} into the eon. 

#### Psalms 45:3 Gird your broadsword upon your thigh! O mighty one, in your beauty. 

#### Psalms 45:4 And in your fineness, even stretch tight your bow, and greatly prosper, and reign! Because of truth, and gentleness, and righteousness even shall {guide you wonderfully your right hand}. 

#### Psalms 45:5 Your arrows are being sharpened, O mighty one. Peoples {underneath you shall fall} in the heart of the enemies of the king. 

#### Psalms 45:6 Your throne, O God, is unto the eon of the eon. A rod of straightness is the rod of your kingdom. 

#### Psalms 45:7 You loved righteousness, and detested lawlessness; on account of this {anointed you God your God} with oil of exultation beyond your fellow partakers. 

#### Psalms 45:8 Myrrh, and balsam, and cassia of your garments from palaces of ivory, 

#### Psalms 45:9 from of which {gladdened you the daughters of kings} in your honor. {stood The queen} at your right {in clothes interwoven with gold having put around being embroidered}. 

#### Psalms 45:10 Hear, O daughter, and behold! And lean your ear, and forget your people, and the house of your father! 

#### Psalms 45:11 Even {desired the king} your beauty; for he is your lord, and you shall do obeisance to him. 

#### Psalms 45:12 And the daughter of Tyre shall come with gifts. {your face will implore The rich of the people}. 

#### Psalms 45:13 All the glory of the daughter of the king within, with bordered fringes of gold, 

#### Psalms 45:14 being put around, being embroidered. {shall be carried to the king The virgins} after her; the ones near her shall be carried to you. 

#### Psalms 45:15 They shall be carried in gladness and exultation; they shall be led into the temple of the king. 

#### Psalms 45:16 In place of your fathers, {were born your sons}. You shall place them as rulers over all the earth. 

#### Psalms 45:17 I will make {remembered your name} in every generation, and generation. On account of this peoples will make acknowledgment to you into the eon, and into the eon of the eon. 

#### Psalms 46:1 Our God is a refuge and power; a helper in afflictions, to the ones {having found us exceedingly}. 

#### Psalms 46:2 On account of this we shall not fear when the {is disturbed earth}, and {are transposed mountains} in the hearts of seas. 

#### Psalms 46:3 {sounded and were disturbed Their waters}; {were disturbed the mountains} by his force. 

#### Psalms 46:4 {of the river The rapid movements} gladdens the city of God. {sanctified his tent The highest}. 

#### Psalms 46:5 God is in the midst of her, and she shall not be shaken. {shall help her God} towards morning by morning. 

#### Psalms 46:6 {were disturbed Nations}; {leaned kingdoms}; {gave out his voice the highest}, {shook the earth}. 

#### Psalms 46:7 The LORD of the forces is with us; {is our shielder the God of Jacob}. 

#### Psalms 46:8 Come and see the works of God! what {he made miracles} upon the earth. 

#### Psalms 46:9 Taking away {in return wars} unto the ends of the earth. {the bow He shall break}, and he shall break in pieces the weapon; and the shields he shall incinerate with fire. 

#### Psalms 46:10 Relax, and know that I am God! I shall be raised up high in the nations. I shall be raised up high in the earth. 

#### Psalms 46:11 The LORD of the forces is with us; {is our shielder the God of Jacob}. 

#### Psalms 47:1 All the nations -- clap hands! Shout to God with a voice of exultation! 

#### Psalms 47:2 For the LORD the highest is dreadful; {king a great} over all the earth. 

#### Psalms 47:3 He submitted peoples to us, and nations under our feet. 

#### Psalms 47:4 He chose to us the inheritance for us, the beauty of Jacob whom he loved. 

#### Psalms 47:5 God ascended in a shout; the LORD with the sound of a trumpet. 

#### Psalms 47:6 Strum to our God! Strum! Strum to our king! Strum! 

#### Psalms 47:7 For the king of all the earth is God. Strum expertly! 

#### Psalms 47:8 God reigns over the nations. God sits upon {throne his holy}. 

#### Psalms 47:9 Rulers of peoples are brought together with the God of Abraham. For by God the strong ones of the earth {exceedingly were lifted up}. 

#### Psalms 48:1 Great is the LORD, and {praiseworthy exceedingly} in the city of our God, in {mountain his holy}. 

#### Psalms 48:2 With good root, a leap for joy of all the earth -- mount Zion on the sides of the north, the city of the {king great}. 

#### Psalms 48:3 God {in her palaces is known}, whenever he should assist her. 

#### Psalms 48:4 For behold, the kings of the earth are being brought together; they went through together. 

#### Psalms 48:5 They in seeing thus wondered; they were disturbed; they were shaken. 

#### Psalms 48:6 Trembling took hold of them there -- pangs as a woman giving birth. 

#### Psalms 48:7 By {wind a violent} you shall break the boats of Tarshish. 

#### Psalms 48:8 Just as we heard, so also we behold in the city of the LORD of the forces, in the city of our God. God founded it into the eon. 

#### Psalms 48:9 We undertook, O God, of your mercy in the midst of your people. 

#### Psalms 48:10 According to your name, O God, so also is the praise of you unto the ends of the earth. {of righteousness is full Your right hand}. 

#### Psalms 48:11 Be glad, mount Zion! and exult daughters of Judea! because of your judgments, O LORD. 

#### Psalms 48:12 Encircle Zion, and take hold of her! Describe concerning her towers! 

#### Psalms 48:13 Put your hearts for her force! and share about her palaces! so that you may describe to {generation another}. 

#### Psalms 48:14 For this is our God into the eon, and into the eon of the eon; he shall tend us into the eons. 

#### Psalms 49:1 Hear these things all nations! Give ear all the ones dwelling in the inhabitable world -- 

#### Psalms 49:2 both the earth-born, and the sons of men together, rich and needy! 

#### Psalms 49:3 My mouth speaks wisdom, and the meditation of my heart understanding. 

#### Psalms 49:4 I will lean {to a parable my ear}; I will open {with a psaltery my riddle}. 

#### Psalms 49:5 Why do I fear in {day the wicked}? The lawlessness at my heel shall encircle me -- 

#### Psalms 49:6 the ones yielding upon their power, even {upon the multitude of their riches the ones boasting}. 

#### Psalms 49:7 A brother does not ransom. Shall {ransom a man}? He shall not give to God an appeasement for himself. 

#### Psalms 49:8 (Even the value of the ransoming his soul, even if he labored into the eon.) 

#### Psalms 49:9 And he shall live till the end, for he should not see corruption. 

#### Psalms 49:10 Whenever he should behold wise men dying, {together the fool and the mindless one shall perish}; and they shall leave behind {to strangers their riches}. 

#### Psalms 49:11 And their tombs are their houses into the eon, and their tents unto generation and generation. They call {their names after lands}. 

#### Psalms 49:12 And a man {in honor being} perceived not; he resembles the {cattle unthinking}, and is like them. 

#### Psalms 49:13 This their way is an obstacle to them; yet after these things {with their mouths they take pleasure}. 

#### Psalms 49:14 {as sheep in Hades They placed them}; death tends them; and {shall dominate them the upright} in the morning; and their help shall grow old in Hades; {from their glory they were banished}. 

#### Psalms 49:15 Except God shall ransom my soul from out of the hand of Hades, whenever he should take me. 

#### Psalms 49:16 Do not fear whenever {should be enriched a man}, or whenever {should be multiplied the glory of his house}, 

#### Psalms 49:17 for {not in his dying he shall take anything}, nor will {go down with him his glory}! 

#### Psalms 49:18 For his soul {in his life shall be blessed}. He shall make acknowledgment to you whenever you should do good to him. 

#### Psalms 49:19 He shall enter unto the generation of his fathers; unto the eon he shall not see light. 

#### Psalms 49:20 And a man {in honor being} perceived not; he resembles the {cattle unthinking} and is like them. 

#### Psalms 50:1 The God of gods, the LORD spoke, and called the earth from the east sun unto its descent. 

#### Psalms 50:2 From out of Zion is the attractiveness of his beauty. 

#### Psalms 50:3 God visibly shall come, our God, and he will not remain silent. A fire before him shall burn; and round about him {gale an exceeding}. 

#### Psalms 50:4 He shall call on the heaven upward, and the earth, to separate his people. 

#### Psalms 50:5 Gathered to him are his sacred ones, the ones ordaining his covenant with sacrifices. 

#### Psalms 50:6 And {shall announce the heavens} his righteousness; for God is judge. 

#### Psalms 50:7 Hear, O my people! and I will speak to you O Israel, and I will testify to you. The God, {your God I am}. 

#### Psalms 50:8 {not over your sacrifices I will reprove you}; for your whole burnt-offerings {before me are always}. 

#### Psalms 50:9 I will not take {from your house calves}, nor {from your flocks winter yearlings}. 

#### Psalms 50:10 For {mine it is all} -- the wild beasts of the field, the cattle on the mountains, and oxen. 

#### Psalms 50:11 I know all the winged creatures of the heaven; and the beauty of the field {with me is}. 

#### Psalms 50:12 If I should hunger, in no way should I tell you, {mine for is the inhabitable world}, and the fullness of it. 

#### Psalms 50:13 Shall I eat meats of bulls or {blood of he-goats drink}? 

#### Psalms 50:14 Sacrifice to God a sacrifice of praise! and render to the highest your vows! 

#### Psalms 50:15 And call upon me in the day of affliction! and I shall rescue you, and you shall glorify me. 

#### Psalms 50:16 But to the sinner God said, Why do you describe my ordinances, and take up my covenant through your mouth? 

#### Psalms 50:17 For you detested instruction, and cast out my words to the rear. 

#### Psalms 50:18 Since you viewed a thief, you ran together with him; and {with the adulterer your portion you established}. 

#### Psalms 50:19 Your mouth abounded with evil, and your tongue twisted with deceits. 

#### Psalms 50:20 In sitting down, {against your brother you spoke ill}; even {against the son of your mother to place an obstacle}. 

#### Psalms 50:21 These things you did, and I kept quiet. You undertook lawlessness, for you thought I will be likened to you. I will reprove you, and I will stand {in front of your face your sins}. 

#### Psalms 50:22 Perceive indeed these things, O ones forgetting God! lest at any time he should snatch you away, and in no way should there be one rescuing. 

#### Psalms 50:23 A sacrifice of praise shall glorify me, and there in the way I will show to him my deliverance. 

#### Psalms 51:1 Show mercy on me, O God, according to {great mercy your}, and according to the multitude of your compassions! Wipe away my violation of the law! 

#### Psalms 51:2 Abundantly wash me from my lawlessness, and {from my sin cleanse me}! 

#### Psalms 51:3 For {my lawlessness I know}, and my sin {before me is always}. 

#### Psalms 51:4 Against you alone I sinned, and {the wicked thing before you did}; that you should be justified in your words, and should overcome in your judging. 

#### Psalms 51:5 For behold in lawless deeds I was conceived, and in sins {craved strange food for me my mother}. 

#### Psalms 51:6 For behold, {truth you loved}. {the concealed things and the private things of your wisdom You manifested to me}. 

#### Psalms 51:7 You shall sprinkle me with hyssop, and I shall be cleansed; you shall wash me and {above snow I shall be whitened}. 

#### Psalms 51:8 You shall cause me to hear exultation and gladness; {shall exult the bones being humbled}. 

#### Psalms 51:9 Turn your face from my sins, and {all my lawlessnesses wipe away}! 

#### Psalms 51:10 {heart a clean Create in me}, O God, and {spirit an upright renew} in my insides! 

#### Psalms 51:11 Do not reel {from me your face}; and {spirit the holy do not take away in return} from me! 

#### Psalms 51:12 Give back to me the exultation of your deliverance, and {spirit with your governing support me}! 

#### Psalms 51:13 I shall teach the lawless ones your ways, and the impious {to you shall turn}. 

#### Psalms 51:14 Rescue me from blood guilt, O God, the God of my deliverance! {shall exult over My tongue} your righteousness. 

#### Psalms 51:15 O LORD, {my lips you shall open}, and my mouth shall announce your praise. 

#### Psalms 51:16 For if you wanted a sacrifice, I would have given; whole burnt-offerings you do not think well of. 

#### Psalms 51:17 A sacrifice to God is a spirit being broken; {a heart being broken and humbled God will not treat with contempt}. 

#### Psalms 51:18 Do good, O LORD, by your benevolence to Zion, and let {be built the walls of Jerusalem}! 

#### Psalms 51:19 Then you will think well of a sacrifice of righteousness offering, and whole burnt-offerings; then they shall offer {upon your altar calves}. 

#### Psalms 52:1 Why do you boast in evil, O mighty man, with lawlessness the entire day? 

#### Psalms 52:2 {injustice considers Your tongue}; as {a razor sharpening} you did treachery. 

#### Psalms 52:3 You loved evil over goodness; injustice over speaking righteousness. 

#### Psalms 52:4 You loved all the {words drowning}, {tongue O deceitful}. 

#### Psalms 52:5 On account of this, God shall demolish you unto the end, to pluck you out, and to migrate you from your tent, and your root from out of the land of the living. 

#### Psalms 52:6 {shall see The just} and shall fear, and {at him shall laugh}. And they shall say, 

#### Psalms 52:7 Behold, the man who did not make God his helper, but raised hope upon the multitude of his riches, and was strengthened by his folly. 

#### Psalms 52:8 But I am as {olive tree a fruitful} in the house of God. I hoped upon the mercy of God into the eon, and into the eon of the eon. 

#### Psalms 52:9 I will make acknowledgment to you into the eon, for you acted; and I will wait on your name, for you are gracious before your sacred ones. 

#### Psalms 53:1 {said The fool} in his heart, There is no God. They were corrupt and abhorrent in lawless deeds. There is not one doing good. 

#### Psalms 53:2 God from out of the heaven looks upon the sons of men, to behold if there is one perceiving or seeking after God. 

#### Psalms 53:3 All turned aside; together they were made useless; there is not one doing good, there is not even one. 

#### Psalms 53:4 Shall {not know all the ones working lawlessness}, the ones eating up my people for solid food of bread? {the LORD They did not call upon}. 

#### Psalms 53:5 There they feared a fear, where there was no fear; for God dispersed the bones of ones trying to please men. They were disgraced, for God treated them with contempt. 

#### Psalms 53:6 Who will appoint from out of Zion deliverance for Israel? In God returning the captivity of his people, Jacob shall exult and Israel shall be glad. 

#### Psalms 54:1 O God, by your name deliver me, and by your power judge me! 

#### Psalms 54:2 O God, listen to my prayer, give ear to the words of my mouth! 

#### Psalms 54:3 For strangers rose up against me; and strong men seek my life; and they did not set God before them. 

#### Psalms 54:4 For behold God helps me; and the LORD is a shielder of my life. 

#### Psalms 54:5 He shall return the evils to my enemies. By your truth utterly destroy them! 

#### Psalms 54:6 Voluntarily I will sacrifice to you; I will make acknowledgment to your name, O LORD, for good. 

#### Psalms 54:7 For from out of all afflictions you rescued me; and among my enemies {looked upon its request my eye}. 

#### Psalms 55:1 Give ear, O God, to my prayer! for you should not overlook my supplication. 

#### Psalms 55:2 Take heed to me, and listen to me! I was fretted in my meditation and was disturbed, 

#### Psalms 55:3 from the voice of the enemy, and from the affliction of the sinner; for they turned aside against me for lawlessness, and in anger they displayed anger against me. 

#### Psalms 55:4 My heart was disturbed in me, and dread of death fell upon me. 

#### Psalms 55:5 Fear and trembling came upon me, and {covered me darkness}. 

#### Psalms 55:6 And I said, Why shall he not give to me wings as a dove, and I shall spread out and I shall rest? 

#### Psalms 55:7 Behold, I was far off being driven into exile, and was lodged in the wilderness. 

#### Psalms 55:8 I waited for the one delivering me from faint-heartedness and the gale. 

#### Psalms 55:9 Sink them, O LORD, and divide their tongues! for I saw lawlessness and dispute in the city. 

#### Psalms 55:10 Day and night he shall encircle her upon her walls; and lawlessness and misery will be in the midst of her; 

#### Psalms 55:11 and injustice, and {ceased not from out of her squares usury and treachery}. 

#### Psalms 55:12 For if an enemy berated me, I would have endured. And if the one detesting me {against me spoke great words}, I would have hidden from him. 

#### Psalms 55:13 But you, O man, are like-minded, a leader of mine, and my diviner, 

#### Psalms 55:14 who together you sweetened foods; in the house of God we went in concord. 

#### Psalms 55:15 And let {come death} upon them, and let them go down into Hades alive! For wickedness in their sojourn, is in the midst of them. 

#### Psalms 55:16 I {to God cried out}, and the LORD listened to me. 

#### Psalms 55:17 Evening and morning and at midday I describe and report; and he shall listen to my voice. 

#### Psalms 55:18 He shall ransom {in peace my soul} from the ones approaching me; for among many they were with me. 

#### Psalms 55:19 God shall listen, and {shall humble them the one existing before the eons}. PAUSE. {no For there is with them bargaining}, for they do not fear God. 

#### Psalms 55:20 He stretched out his hand in recompensing; they profaned his covenant. 

#### Psalms 55:21 He divided them into parts from the anger of his face, and {approached their hearts}. {were made tender His words} above olive oil, yet they are arrows. 

#### Psalms 55:22 Cast upon the LORD your anxiety, and he will nourish you! He will not grant {into the eon for a tossing about the just}. 

#### Psalms 55:23 But you, O God, shall lead them down into the well of corruption; men of blood and deceit in no way shall live half their days. But I, O LORD, shall hope upon you. 

#### Psalms 56:1 Show mercy on me, O God! for {trampled me man}. The entire day in waging war he afflicted me. 

#### Psalms 56:2 {trampled me My enemies} the entire day, for many are the ones waging war against me from the height. 

#### Psalms 56:3 {the day I do not fear}, and I shall hope upon you. 

#### Psalms 56:4 In God I will praise by my words. Upon God I hoped. I shall not fear what {shall do to me flesh}. 

#### Psalms 56:5 The entire day {my words they abhorred}; {are against me all their thoughts} for bad. 

#### Psalms 56:6 They will sojourn and hide; they {my heel will guard}, just as they wait for my life. 

#### Psalms 56:7 For by no means will you deliver them; {in anger peoples you will lead down}. 

#### Psalms 56:8 O God, my life I declared to you; you put my tears before you, as even according to your promise. 

#### Psalms 56:9 {shall turn My enemies} to the rear, in which ever day I should call upon you. Behold, I knew that {my God you are}. 

#### Psalms 56:10 Unto God I will praise by discourse; unto the LORD I will praise by word. 

#### Psalms 56:11 Unto God I hoped; I will not be afraid in what {shall do to me man}. 

#### Psalms 56:12 In me, O God, are the vows which I shall give of your praise. 

#### Psalms 56:13 For you rescued my soul from death, my eyes from tears, and my feet from a slip. I shall be well-pleasing before the LORD in the light of the living. 

#### Psalms 57:1 Show mercy on me, O God, show mercy on me! For {upon you yielded my soul}. And in the shadow of your wings I shall hope, until of which time {should go by lawlessness}. 

#### Psalms 57:2 I shall cry out to God the highest; the God benefiting me. 

#### Psalms 57:3 He sent out from heaven, and he delivered me. He put {unto scorn the ones trampling me}. {sent out God} his mercy and his truth; 

#### Psalms 57:4 and he rescued my soul from the midst of lion cubs. I went to bed being disturbed; the sons of men -- their teeth are weapons and arrows, and their tongue {sword a sharp}. 

#### Psalms 57:5 Be raised up high above the heavens, O God, and {above all the earth your glory}! 

#### Psalms 57:6 {a snare They prepared} for my feet, and bent down my soul. They dug {before my face a cesspool}, and they fell into it. PAUSE. 

#### Psalms 57:7 {is prepared My heart}, O God, {is prepared my heart}. I will sing and I will strum in my glory. 

#### Psalms 57:8 Awaken, my glory! Awaken, O psaltery and harp! I shall awaken at dawn. 

#### Psalms 57:9 I will make acknowledgment to you among peoples, O LORD, I will strum to you among nations. 

#### Psalms 57:10 For {was magnified unto the heavens your mercy}; and {unto the clouds your truth}. 

#### Psalms 57:11 Be raised up high above the heavens, O God, and {above all the earth your glory}! 

#### Psalms 58:1 Will truly thus {righteousness you speak} and rightly judge, O sons of men? 

#### Psalms 58:2 For even in the heart {lawlessness you work} in the earth. {in injustice Your hands closely join}. 

#### Psalms 58:3 {were separated Sinners} from the womb; they wander from the belly; they spoke lies. 

#### Psalms 58:4 Rage to them is according to the likeness of the serpent; as {asp a mute} even plugging her ears, 

#### Psalms 58:5 who does not listen to the sound {charming of the sorcerer}, and the administering of potions by a wise man. 

#### Psalms 58:6 God broke their teeth in their mouths; {the molars of the lions fractured in pieces the LORD}. 

#### Psalms 58:7 They shall be treated with contempt as water going by. He shall stretch tight his bow until of which time they shall be weakened. 

#### Psalms 58:8 As beeswax melting away, they shall be taken away in return. {fell Fire} upon them, and they did not see the sun. 

#### Psalms 58:9 Before the perceiving of your thorn-bushes -- the white-thorn shrub; as living, as in anger he shall swallow them. 

#### Psalms 58:10 {shall be glad The just one} whenever he should behold punishment. {his hands He shall wash} in the blood of the sinner. 

#### Psalms 58:11 And {shall say a man}, There is fruit to the just; there is God judging them in the earth. 

#### Psalms 59:1 Rescue me from my enemies, O God, and {from the ones rising up against me ransom me}! 

#### Psalms 59:2 Rescue me from the ones working lawlessness, and {from men of blood deliver me}! 

#### Psalms 59:3 For behold, they hunted my life; {put upon me strong ones}; nor is it because of my lawlessness nor my sin, O LORD. 

#### Psalms 59:4 Without lawlessness I ran and straightened out. Awake to meet me, and see! 

#### Psalms 59:5 And you, O LORD, the God of the forces, God of Israel, take heed to visit all the nations! You should not pity any of the ones practicing lawlessness. 

#### Psalms 59:6 They shall return at evening, and shall be famished as a dog, and shall circle the city. 

#### Psalms 59:7 Behold, they shall declare with their mouths; and the broadsword is in their lips; for they say, Who hears? 

#### Psalms 59:8 And you, O LORD, shall laugh out loud at them; you shall treat with contempt all the nations. 

#### Psalms 59:9 My might to you I will keep, for you, O God, {shielder are my}. 

#### Psalms 59:10 My God, his mercy shall go beforehand with me. My God shall show to me my desire on my enemies. 

#### Psalms 59:11 You should not kill them, lest at any time they should forget your law. Disperse them by your power, and lead them down, {my defender O LORD}! 

#### Psalms 59:12 For the sin of their mouth, and the word of their lips, even let them be seized in their pride! even for cursing and lying which they shall declare. 

#### Psalms 59:13 In consummation, by anger of consummation consume, that in no way they should exist; that they shall know that God is master of Jacob, and of the ends of the earth. PAUSE. 

#### Psalms 59:14 They shall return at evening, and be famished as a dog, and shall circle the city. 

#### Psalms 59:15 They shall be dispersed to eat, but if they should not be filled, then they shall grumble. 

#### Psalms 59:16 But I shall sing to your power, and I shall exult in the morning of your mercy; for you became my shielder and my refuge in the day of my affliction. 

#### Psalms 59:17 {my helper You are}, to you I shall strum; for you, O God, {shielder are my}, my God of my mercy. 

#### Psalms 60:1 O God, you thrusted us away, and demolished us. You were provoked to anger, yet you pitied us. 

#### Psalms 60:2 You shook the earth, and disturbed it. Heal its breaks! for it was shaken. 

#### Psalms 60:3 You showed to your people hard things; you watered us down with the wine of vexation. 

#### Psalms 60:4 You gave to the ones fearing you a signal to flee from the face of the bow. PAUSE. 

#### Psalms 60:5 So that {should be rescued your beloved}. Deliver with your hand, and heed me! 

#### Psalms 60:6 God spoke in his holy place; I will exult, and I will divide Shechem, and the valley of the tents I will measure out. 

#### Psalms 60:7 {is mine Gilead}, and {is mine Manasseh}, and Ephraim is the fortification of my head; Judah is my king; 

#### Psalms 60:8 Moab is a kettle of my hope; over Edom I will stretch out my sandal. {to me The Philistines submitted}. 

#### Psalms 60:9 Who shall take me away into the city citadel? Or who shall guide me unto Edom? 

#### Psalms 60:10 Will not you, O God, the one thrusting us away? And will you not go forth, O God, with our forces? 

#### Psalms 60:11 Give to us help from affliction! for {is vain deliverance of man}. 

#### Psalms 60:12 In God we do powerfully, and he shall treat with contempt the ones afflicting us. 

#### Psalms 61:1 Listen, O God, to my supplication! Take heed to my prayer! 

#### Psalms 61:2 From the ends of the earth {to you I cry out}. In the discouraging of my heart, {in the rock you lifted me high}; you guided me. 

#### Psalms 61:3 For you became my hope; the tower of strength from in front of an enemy. 

#### Psalms 61:4 I will sojourn in your tent into the eons; I shall be sheltered in the protection of your wings. 

#### Psalms 61:5 For you, O God, listened to my vows. You gave an inheritance to the ones fearing your name. 

#### Psalms 61:6 Days upon days of the king; you shall add of his years unto days of generations and generations. 

#### Psalms 61:7 He shall abide into the eon before God. {mercy and truth his Who will seek}? 

#### Psalms 61:8 Thus I shall strum to your name into the eons, for me to render my vows day by day. 

#### Psalms 62:1 Shall not {to God be submitted my soul}, {is by him for my deliverance}? 

#### Psalms 62:2 For even he is my God, and my deliverer, my shielder. In no way should I be shaken by many. 

#### Psalms 62:3 For how long do you put upon a man? {slaughter all You} as a wall leaning and a fence thrusting through. 

#### Psalms 62:4 But {my honor they consulted to thrust away}. I ran in thirst; with their mouth blessing, but in their heart they cursed. 

#### Psalms 62:5 But {to God be submitted}, O my soul! for {is by him my endurance}. 

#### Psalms 62:6 For he is my God, and my deliverer, my shielder; for in no way should I migrate. 

#### Psalms 62:7 By God is my deliverance, and my glory; the God of my help; and my hope is upon God. 

#### Psalms 62:8 Hope upon him, all you gathering people! pour out before him your hearts! for God is our helper. PAUSE. 

#### Psalms 62:9 But {are vain the sons of men}; {are false weights the sons of men} in the yoke balance scales to do wrong. They are of folly all together. 

#### Psalms 62:10 Hope not upon unrighteousness, and {after a thing seized long not}! If wealth should flow, set not the heart upon it! 

#### Psalms 62:11 Once God spoke, and these two things I heard; that might is of God, 

#### Psalms 62:12 and of you, O LORD, is mercy. For you recompense each according to his works. 

#### Psalms 63:1 O God, my God, to you I rise early. {thirsted for you My soul}. How often {longed for you my flesh} in {land a barren and untrodden and waterless}. 

#### Psalms 63:2 Thus in the holy place I appeared to you, to behold your power and your glory. 

#### Psalms 63:3 For {is better your mercy} than life. My lips shall praise you; 

#### Psalms 63:4 thus will I bless you in my life; {in your name I will lift my hands}. 

#### Psalms 63:5 As of fat and fatness may {be filled my soul}; and with lips of exultation {shall praise my mouth}. 

#### Psalms 63:6 Forasmuch as I remembered you upon my strewn bed; at the dawns I meditated on you. 

#### Psalms 63:7 For you are my helper, and in the protection of your wings I shall exult. 

#### Psalms 63:8 {shall cleave My soul} after you; {of me but took hold your right hand}. 

#### Psalms 63:9 But they {in folly seek my soul}; they shall enter into the lowermost part of the earth. 

#### Psalms 63:10 They shall be delivered up into the hands of the broadsword; {portions for foxes they will be}. 

#### Psalms 63:11 But the king shall be glad upon God; {shall be praised all swearing by an oath in him}, for he obstructed the mouth of the ones speaking unjustly. 

#### Psalms 64:1 Hear, O God, my voice! in my beseeching to you. {from the fear of the enemy Rescue my soul}! 

#### Psalms 64:2 Shelter me from the conspiracy of the ones acting wickedly! from the multitude of the ones working iniquity. 

#### Psalms 64:3 The ones who sharpened {as a broadsword their tongues}; they stretched tight their bow {thing for a bitter}; 

#### Psalms 64:4 to shoot in concealed places at the unblemished; suddenly they will shoot him, and they will not fear. 

#### Psalms 64:5 They determined for themselves {matter an evil}; they describe to themselves how to hide snares. They said, Who shall see them? 

#### Psalms 64:6 They searched out lawlessness; they failed while searching out in the search. {shall come forward Man} and the heart is deep, 

#### Psalms 64:7 and God shall be exalted; the arrow of infants became their calamities; 

#### Psalms 64:8 and {treated him with contempt their tongues}. {were disturbed All the ones viewing them}; 

#### Psalms 64:9 and {was fearful every man}. And they announced the works of God, and {his actions they perceived}. 

#### Psalms 64:10 {shall be glad The just} in the LORD, and shall hope upon him; and {shall be praised all the straight in heart}. 

#### Psalms 65:1 {is becoming to you A hymn}, O God, in Zion; and to you {shall be rendered the vow} in Jerusalem. 

#### Psalms 65:2 Listen to my prayer! {to you All flesh shall come}. 

#### Psalms 65:3 {words Lawless} overpowered us; but {our impieties you shall atone}. 

#### Psalms 65:4 Blessed is whom you chose, and took to yourself; he shall encamp in your courtyards. We shall be filled in the good things of your house, {holy temple your}. 

#### Psalms 65:5 Wonderful in righteousness -- heed us, O God our deliverer! He is the hope of all the ends of the earth, and of the ones in the sea afar; 

#### Psalms 65:6 preparing mountains in his strength, being girded in dominion; 

#### Psalms 65:7 the one disturbing the extent of the sea -- at the sounds of its waves who shall stand? 

#### Psalms 65:8 {shall be disturbed The nations}, and {shall fear the ones dwelling at the ends} from your signs. The exitings of the morning and evening you shall make happy. 

#### Psalms 65:9 You visited the earth, and you intoxicated it. You multiplied to enrich it. The river of God is filled with waters. You prepared their nourishment, for thus is its preparation. 

#### Psalms 65:10 {her furrows Saturate}! Multiply her produce! By her drops the produce shall be glad while rising. 

#### Psalms 65:11 You shall bless the crown of the year, because of your graciousness; and your plains shall be filled in fatness. 

#### Psalms 65:12 {shall be fattened The beautiful mountains of the wilderness}; and {in exultation the hills shall gird themselves}. 

#### Psalms 65:13 {shall put on wool The rams of the sheep}, and the valleys shall multiply grain. They shall cry out, for even they will sing praise. 

#### Psalms 66:1 Shout to the LORD all the earth! 

#### Psalms 66:2 Strum indeed to his name! Give glory of his praise! 

#### Psalms 66:3 Say to God! How fearful are your works. In the magnitude of your power {shall lie to you your enemies}. 

#### Psalms 66:4 Let all the earth do obeisance to you, and strum unto you! Let them strum to your name the highest! PAUSE. 

#### Psalms 66:5 Come and see the works of God! as fearful in counsels above the sons of men. 

#### Psalms 66:6 The one converting the sea into dry land; in the river they shall go through on foot. There we shall be glad in him -- 

#### Psalms 66:7 to the one being master in his domination of the eon. His eyes {upon the nations look}. {the ones greatly embittering him Let not} raise {up high themselves}! PAUSE. 

#### Psalms 66:8 Bless, O nations, our God! And cause {to be heard the voice of his praise}! 

#### Psalms 66:9 Even of the one who establishes my soul for life, and not granting {for tossing about my feet}. 

#### Psalms 66:10 For you tried us, O God; you set us on fire as {is set to the fire silver}. 

#### Psalms 66:11 You brought us into the snare; you put afflictions upon our back. 

#### Psalms 66:12 You set men over our heads; we went through fire and water; but you led us unto respite. 

#### Psalms 66:13 I will enter into your house with whole burnt-offerings. I will render to you my vows, 

#### Psalms 66:14 which {drew apart my lips}, and {spoke my mouth} in my affliction. 

#### Psalms 66:15 Whole burnt-offerings being filled with marrow I will offer to you, with incense and rams. I will offer to you oxen with winter yearlings. PAUSE. 

#### Psalms 66:16 Come listen! and I will describe to you (all ones fearing God) as many things as he did for my soul. 

#### Psalms 66:17 To him with my mouth I cried out, and I raised up high by my tongue. 

#### Psalms 66:18 {injustice If I had viewed} in my heart, let {not listen to me the LORD}! 

#### Psalms 66:19 On account of this {listened to me God}; he took heed to the voice of my supplication. 

#### Psalms 66:20 Blessed be the God who separated not from my prayer, nor his mercy from me. 

#### Psalms 67:1 God, may he pity us, and bless us, to shine his face upon us, and to show mercy on us; 

#### Psalms 67:2 to know in the earth your way; among all nations your deliverance. 

#### Psalms 67:3 Let {make acknowledgment to you the peoples}, O God, let {make acknowledgment to you all peoples}! 

#### Psalms 67:4 Be glad and exult, O nations! for you shall judge the peoples in straightness, and {the nations in the earth you shall guide}. PAUSE. 

#### Psalms 67:5 Let {make acknowledgment to you peoples}, O God, let {make acknowledgment to you all peoples}! 

#### Psalms 67:6 The earth gave her fruit. May {bless us God our God}. 

#### Psalms 67:7 May {bless us God}, and let {fear him all the ends of the earth}! 

#### Psalms 68:1 Let God arise, and let {be dispersed his enemies}, and let {flee from his face the ones detesting him}! 

#### Psalms 68:2 As {dissipates smoke}, let them dissipate! As {melts away beeswax} from the face of the fire, thus shall {be destroyed the sinners} from the face of God. 

#### Psalms 68:3 But {the just let} be glad! Let them exult in the presence of God! Let them be made happy with gladness! 

#### Psalms 68:4 Sing to God! Strum to his name! Open the way to the one being mounted unto the west -- the LORD is his name, and exult before him! They shall be disturbed before his face. 

#### Psalms 68:5 The father of the orphans, and judge of the widows -- God in {place his holy}. 

#### Psalms 68:6 God settles simple people in a house; leading out the prisoners being shackled in courage; in like manner the ones being greatly embittered, dwelling in tombs. 

#### Psalms 68:7 O God, in your going forth before your people in your passing over in the wilderness, 

#### Psalms 68:8 the earth was shaken. For even the heavens dripped water before the face of the God of Sinai; before the face of the God of Israel. 

#### Psalms 68:9 {rain as a voluntary act Will you separate}, O God, for your inheritance? Even it was weak, but you restored it. 

#### Psalms 68:10 Your living creatures dwell in it; you prepared in your graciousness for the poor. 

#### Psalms 68:11 The {God LORD} shall give discourse to the ones announcing good news {force for a great}. 

#### Psalms 68:12 The king of the forces of the beloved, for the beauty of the house to divide the spoils. 

#### Psalms 68:13 If you should sleep in the midst of the lots, the wings of the dove being silver plated, and her upper back in greenness of gold; 

#### Psalms 68:14 in the {drawing apart the heavenly one} kings upon it, they shall be made as snow in Salmon. 

#### Psalms 68:15 The mountain of God; the mountain being plentiful; the mountain for making cheese; the mountain being plentiful. 

#### Psalms 68:16 Why do you undertake, O mountains making cheese, the mountain which God thinks well to dwell in it? For even the LORD encamps unto the end. 

#### Psalms 68:17 The chariot of God -- ten thousand-fold; thousands of prospering ones. The LORD among them in Sinai, in the holy place. 

#### Psalms 68:18 You ascended into the height; you captured captivity; you received gifts by men; for even {the ones resisting persuasion to encamp among}. 

#### Psalms 68:19 The LORD God blessed. Blessed be the LORD day by day, for you greatly prospered us, O God of our deliverances. 

#### Psalms 68:20 Our God, the God to deliver, even the LORD delivering the ones at the outer reaches of death. 

#### Psalms 68:21 But God shall fracture in pieces the heads of his enemies; {tops of heads the hairy} traveling in their trespasses. 

#### Psalms 68:22 The LORD said from out of Bashan, I shall return. I shall return in the depths of the sea. 

#### Psalms 68:23 That {should be dipped your foot} in blood, and the tongue of your dogs be stained {enemies from his}. 

#### Psalms 68:24 {were viewed Your goings}, O God; the goings of my God, the king, in the holy place. 

#### Psalms 68:25 {went beforehand Rulers} being next to ones strumming, in the midst of young women performing on tambourines. 

#### Psalms 68:26 In assemblies bless God! the LORD from the springs of Israel. 

#### Psalms 68:27 There Benjamin the younger is in astonishment, even the rulers of Judah, and their governors, the rulers of Zebulun, the rulers of Naphtali. 

#### Psalms 68:28 Give charge, O God, to your power! Strengthen, O God! this which you worked out among us. 

#### Psalms 68:29 Because of your temple at Jerusalem {to you will bring kings gifts}. 

#### Psalms 68:30 Give reproach to the wild beasts of the reed! the gathering of the bulls among the heifers of the peoples; to lock up the ones being tried by silver. Disperse the nations! the ones {wars wanting}. 

#### Psalms 68:31 {shall come Ambassadors} from out of Egypt. Ethiopia shall go beforehand with her hand to God. 

#### Psalms 68:32 O kingdoms of the earth, sing to God! Strum to the LORD! PAUSE. 

#### Psalms 68:33 to the one mounting upon the heaven of the heaven, according to the east. Behold, he shall make his voice a sound of power. 

#### Psalms 68:34 Give glory to God! {is over Israel his majesty}, and his power is in the clouds. 

#### Psalms 68:35 God is wonderful in his holy places. The God of Israel -- he shall give power and fortification to his people. Blessed be God. 

#### Psalms 69:1 Deliver me, O God! for {entered the waters} into my soul. 

#### Psalms 69:2 I was stuck in {slime deep}, and there is no support. I came to the depths of the sea, and the gale sank me. 

#### Psalms 69:3 I tired crying out; {is sore my throat}. {failed My eyes} from my hope upon my God. 

#### Psalms 69:4 {multiplied over the hairs of my head The ones detesting me}. Freely {were strengthened my enemies}, the ones driving me out unjustly; {what I did not seize by force then I paid for}. 

#### Psalms 69:5 O God, you know my folly, and my trespasses, {from you they are not concealed}. 

#### Psalms 69:6 {not May be ashamed over me the ones waiting upon you}, O LORD, O LORD of the forces. {not May feel shame over me the ones seeking you}, O God of Israel. 

#### Psalms 69:7 For because of you I endured scorning; {covered shame} my face. 

#### Psalms 69:8 {one being separated from I was} my brethren, and a stranger to the sons of my mother. 

#### Psalms 69:9 For the zeal of your house devoured me, and the scornings of the ones berating you fell upon me. 

#### Psalms 69:10 And I covered {in fasting my soul}, and it became for scornings to me. 

#### Psalms 69:11 And I put on {for my garment sackcloth}, and I became to them as a parable. 

#### Psalms 69:12 {against me meditated The ones sitting down at the gates}; and against me they strummed, even the ones drinking wine. 

#### Psalms 69:13 But I will cry in my prayer to you, O LORD, at a time of benevolence. O God, in the multitude of your mercies heed me in the truth of your deliverance! 

#### Psalms 69:14 Deliver me from mud! that I should not be stuck. May I be rescued from the ones detesting me, and from the depths of the waters. 

#### Psalms 69:15 {not me Let sink the gale of water}, nor let {swallow me the deep}, nor let {constrain over me the well its mouth}! 

#### Psalms 69:16 Listen to me, O LORD, for {is gracious your mercy}! According to the multitude of your compassions look upon me! 

#### Psalms 69:17 You should not turn your face from your servant, for I am afflicted. Quickly heed me! 

#### Psalms 69:18 Take heed to my soul, and ransom it! {because of my enemies Rescue me}! 

#### Psalms 69:19 For you know my scorning, and my shame, and my remorse. Before you are all the ones afflicting me. 

#### Psalms 69:20 {scorning expected My soul} and misery; and I remained behind for one grieving, and he did not exist; and for ones comforting, but I did not find. 

#### Psalms 69:21 And they gave {for my food bile}; and for my thirst they gave {to drink me vinegar}. 

#### Psalms 69:22 Let {become their table before them} as a snare, and for a recompense, and for an obstacle! 

#### Psalms 69:23 Let {be darkened their eyes} to not see, and their back always bent downwards! 

#### Psalms 69:24 Pour out upon them your anger! and {the rage of your anger may} overtake them. 

#### Psalms 69:25 Let {become their property} having been made desolate! and {in their tents let there not be one dwelling}! 

#### Psalms 69:26 For whom you struck, they pursued; and {to the pain of my wounds they added}. 

#### Psalms 69:27 Add lawlessness upon their lawlessness! and let not {enter in your righteousness}! 

#### Psalms 69:28 Let them be wiped away from out of the book of the living! and {with the just let them not be written}! 

#### Psalms 69:29 {poor and aching I am}; your deliverance, O God, may it take hold of me. 

#### Psalms 69:30 I will praise the name of my God with an ode; I shall magnify him in praise, 

#### Psalms 69:31 and it shall please God above {calf a young horns bringing forth} and hoofs. 

#### Psalms 69:32 Let {see the poor} and let them be glad! Inquire of God! and {shall live your soul}. 

#### Psalms 69:33 For {listens to the needy the LORD}; and the ones of his being shackled he does not treat with contempt. 

#### Psalms 69:34 Let {praise him the heavens}, and the earth, sea, and all the things crawling in her! 

#### Psalms 69:35 For God shall deliver Zion, and {shall be built up the cities of Judea}. And they shall dwell there, and they shall inherit her. 

#### Psalms 69:36 And the seed of your servants shall hold her; and the ones loving his name shall encamp in her. 

#### Psalms 70:1 O God, for my help heed me! O LORD, {to help me hasten}! 

#### Psalms 70:2 Let {be ashamed and feel remorse the ones seeking my life}! Let {be turned to the rear and be disgraced the ones wanting bad things for me}! 

#### Psalms 70:3 Let them be turned immediately, being shamed! the ones saying to me, Well done, well done! 

#### Psalms 70:4 Let them exult and be glad over you! even all the ones seeking you, O God. And let them say always, Let {be magnified the LORD}! even the ones loving your deliverance. 

#### Psalms 70:5 But I am poor and needy, O God, help me! {my helper and my rescuer You are}, O LORD, you should not delay. 

#### Psalms 71:1 Upon you, O LORD, I hoped. May I not be disgraced into the eon. 

#### Psalms 71:2 In your righteousness rescue me, and take me! Lean {to me your ear} and deliver me! 

#### Psalms 71:3 Be to me for {God a defending}! and for {place a fortified} to deliver me. For {my confirmation and my refuge you are}. 

#### Psalms 71:4 O my God, rescue me from the hand of the sinner! from the hand of the one acting unlawfully and doing wrong. 

#### Psalms 71:5 For you are my endurance, O Lord, O LORD, the one of my hope from my youth. 

#### Psalms 71:6 {upon you I stayed From the womb}; from the belly of my mother you are my shelterer. {about you My singing praise is always}. 

#### Psalms 71:7 {as it were a miracle I was} to the many; but you are {helper my fortified}. 

#### Psalms 71:8 Let {be filled my mouth} of praise! that I may praise in song of your glory; the entire day of your majesty. 

#### Psalms 71:9 You should not throw me away in the time of old age; in the failing of my strength you should not abandon me. 

#### Psalms 71:10 For {spoke my enemies} against me; and the ones watching out for my life consulted together, 

#### Psalms 71:11 saying, God abandoned him; pursue and overtake him! for there is no one rescuing him. 

#### Psalms 71:12 O my God, you should be not far from me. O my God, {to my help take heed}! 

#### Psalms 71:13 Let {be shamed and fail the ones slandering my soul}! Let {put on shame and remorse the ones seeking bad things for me}! 

#### Psalms 71:14 But I always shall hope upon you, and I will add upon all your praise. 

#### Psalms 71:15 My mouth shall announce your righteousness the entire day; your deliverance, for I did not know writings. 

#### Psalms 71:16 I will enter in the might of the LORD. O LORD, I will mention your righteousness only. 

#### Psalms 71:17 You taught me, O God, from my youth; and until now I will report your wonders. 

#### Psalms 71:18 Even until old age, and of a senior, O my God, you should not abandon me until whenever I should report your arm to {generation every coming}; 

#### Psalms 71:19 of your might and of your righteousness, O God, unto the highests, what {you did to me magnificence}. O God, who is likened to you? 

#### Psalms 71:20 As much as you showed to me -- {afflictions many} and bad things; but turning, you restored life to me; and from out of the abysses of the earth you led me. 

#### Psalms 71:21 You abounded to me your greatness, and turning you comforted me; and from out of the abysses of the earth again you led me. 

#### Psalms 71:22 For also I will make acknowledgment to you among peoples, O LORD; with an instrument for a psalm of your truth, O God. I shall strum to you with the harp, O holy one of Israel. 

#### Psalms 71:23 {shall exult My lips} whenever I should strum to you, and my soul which you ransomed. 

#### Psalms 71:24 But still also my tongue {all the day shall meditate upon your righteousness}, whenever {should be ashamed and should feel remorse the ones seeking bad things for me}. 

#### Psalms 72:1 O God, {your judgment to the king give}, and your righteousness to the son of the king! 

#### Psalms 72:2 to judge your people in righteousness, and your poor with equity. 

#### Psalms 72:3 Let {lift up the mountains} peace to the people, and the hills righteousness! 

#### Psalms 72:4 He shall judge the poor of the people, and shall deliver the sons of the needy, and shall humble the extortioner. 

#### Psalms 72:5 And he shall continue as the sun, and before the moon for generations of generations. 

#### Psalms 72:6 He shall come down as rain upon fleece, and as drops dripping upon the earth. 

#### Psalms 72:7 {shall rise in his days Righteousness}, and a multitude of peace until of which time {should be taken away the moon}. 

#### Psalms 72:8 And he shall dominate from sea unto sea, and from rivers unto the ends of the inhabitable world. 

#### Psalms 72:9 {before him Ethiopians shall fall down}, and his enemies {dust shall lick}. 

#### Psalms 72:10 Kings of Tarshish, and the islands {gifts shall bring}. The kings of the Arabians and Sheba {with gifts will come forward}. 

#### Psalms 72:11 And {shall do obeisance to him all the kings of the earth}. All the nations shall serve to him. 

#### Psalms 72:12 For he rescued the poor from the mighty one, and the needy one in whom no {existed helper}. 

#### Psalms 72:13 He shall spare the poor and needy; and the souls of the needy he shall deliver. 

#### Psalms 72:14 From interest and from injustice he shall ransom their souls, and {valued name his} will be before them. 

#### Psalms 72:15 And he shall live, and there shall be given to him from the gold of Arabia. And they shall pray for him always; the entire day they shall bless him. 

#### Psalms 72:16 There will be a support on the earth upon the tops of the mountains. {shall be elevated above Lebanon His fruit}, and they {shall blossom of the city} as grass of the earth. 

#### Psalms 72:17 {will be His name} a blessing into the eons. {before the sun shall abide His name}, and {shall be blessed by him all the tribes of the earth}. All the nations shall declare him blessed. 

#### Psalms 72:18 Blessed be the LORD God of Israel, the one doing wonders alone. 

#### Psalms 72:19 And being blessed is the name of his glory into the eon, and into the eon of the eon. And {shall be filled of his glory all the earth}. May it be. May it be. 

#### Psalms 72:20 {are ended The hymns of David the son of Jesse}. 

#### Psalms 73:1 O how good is God to Israel, to the ones straight in the heart. 

#### Psalms 73:2 But my {were a little shaken feet}; {a little slipped my footsteps}. 

#### Psalms 73:3 For I was jealous over the lawless things, {the peace of sinners viewing}. 

#### Psalms 73:4 For there is no sign of reluctance in their death, nor confirmation in their whip. 

#### Psalms 73:5 In toils of men they are not troubled, and with other men they will not be whipped. 

#### Psalms 73:6 On account of this {held them their pride} to the end. They clothed themselves {injustice and impiety of their own}. 

#### Psalms 73:7 {comes forth as from out of fatness Their injustice}. They went by disposition of heart. 

#### Psalms 73:8 They considered and spoke in wickedness. {injustice in the haughtiness They spoke}. 

#### Psalms 73:9 They set {against heaven their mouth}, and their tongue went through upon the earth. 

#### Psalms 73:10 On account of this {shall return my people} here; and {days full} shall be found with them. 

#### Psalms 73:11 And they said, How did God know? and, Is there knowledge in the highest? 

#### Psalms 73:12 Behold, these are the sinners, and they prosper into the eon, holding wealth. 

#### Psalms 73:13 And I said, Surely in folly I justified my heart, and washed {in innocent things my hands}; 

#### Psalms 73:14 and became for whipping all the day; and my reproof is in the mornings. 

#### Psalms 73:15 If I had said, I shall describe thus; behold, in the generation of your sons, I have broken contract. 

#### Psalms 73:16 And I undertook to know this, but it is toilsome before me; 

#### Psalms 73:17 until of which time I should enter into the sanctuary of God, and should perceive to their latter end. 

#### Psalms 73:18 Besides, on account of their deceits you appointed evils unto them; you threw them down in their being lifted up. 

#### Psalms 73:19 O how they became for desolation. Suddenly they failed; they were destroyed because of their lawlessness. 

#### Psalms 73:20 As a dream of one awakening, O LORD, in your city, {their image you will treat} with contempt. 

#### Psalms 73:21 For {was kindled my heart}, and my kidneys were changed. 

#### Psalms 73:22 And I being with contempt, and not knowing, {brutish became} before you. 

#### Psalms 73:23 But I was always with you; you held {hand my right}, 

#### Psalms 73:24 and in your counsel you guided me, and with glory you received me. 

#### Psalms 73:25 For what exists to me in the heaven? And besides you, what did I want upon the earth? 

#### Psalms 73:26 {failed My heart and my flesh}. God is the strength of my heart, and {is my portion God} into the eon. 

#### Psalms 73:27 For behold, the ones being far {by their own makings from you} shall perish. You utterly destroyed every one committing harlotry from you. 

#### Psalms 73:28 But for me to cleave to God is good; to put {in the LORD my hope}; for me to declare all your praises at the gates of the daughter of Zion. 

#### Psalms 74:1 O God, why did you thrust us away unto the end? Why {provoked to anger is your rage} against the sheep of your pasture? 

#### Psalms 74:2 Remember your congregation! of which you acquired from the beginning. You ransomed the rod of your inheritance; {mount Zion this} where you encamped in it. 

#### Psalms 74:3 Lift up your hands against their pride unto completion! for as much as {did wickedly the enemy} in your holy place. 

#### Psalms 74:4 And {boasted the ones detesting you} in the midst of your holiday; they set their signs for signs. 

#### Psalms 74:5 And they knew not as in the conclusion above, as {in the forest of woods with axes they cut down}, 

#### Psalms 74:6 so {its doors together with a hewing axe and chisel they broke down}. 

#### Psalms 74:7 They set {on fire your sanctuary} to the ground. They profaned the tent of your name. 

#### Psalms 74:8 {said in their heart Their kin together}, Come and let us cause to cease all the holidays of God from the land! 

#### Psalms 74:9 {our signs We did not see}; there is not yet a prophet; and one of us does not know any longer. 

#### Psalms 74:10 For how long, O God, shall {berate the enemy}? He provokes the opposition of your name to the end. 

#### Psalms 74:11 Why did you turn away your hand, even your right hand from the midst of your bosom to the end? 

#### Psalms 74:12 But God our king is before the eon. He worked deliverance in the midst of the earth. 

#### Psalms 74:13 You held {in check by your power the sea}. You broke the heads of the dragons upon the water. 

#### Psalms 74:14 You fractured the heads of the dragon; you gave him for food {peoples to the Ethiopian}. 

#### Psalms 74:15 You tore open the springs and rushing streams. You dried the rivers of continuance. 

#### Psalms 74:16 Yours is the day, and yours is the night; you fashioned giving light and the sun. 

#### Psalms 74:17 You made all the boundaries of the earth; summer and spring, you shaped them. 

#### Psalms 74:18 Remember this! an enemy berated the LORD, and {people a foolish} provoked your name. 

#### Psalms 74:19 You should not deliver up {to the wild beasts a soul making acknowledgment to you}; of the souls of your needy you should not forget to the end. 

#### Psalms 74:20 Look unto your covenant! for {filled the ones being darkened} the earth with houses of lawless deeds. 

#### Psalms 74:21 Let not {be turned away the one being humbled} being disgraced! The poor and needy shall praise your name. 

#### Psalms 74:22 Rise up, O God, adjudicate your cause! Remember your scorning by the fool the entire day! 

#### Psalms 74:23 You should not forget the voice of your servants. The pride of the ones detesting you ascended continually. 

#### Psalms 75:1 I will make acknowledgment to you, O God; I shall make acknowledgment and shall call upon your name. I shall describe all your wonders. 

#### Psalms 75:2 Whenever I should receive the appointed time, I {in straightness shall judge}. 

#### Psalms 75:3 {is melted away The earth} and all the ones dwelling in it. PAUSE. I solidified its columns. 

#### Psalms 75:4 I said to the ones acting unlawfully, Do not act unlawfully! And to the sinners, Do not exalt the horn! 

#### Psalms 75:5 Do not lift up {unto the height your horn}, and do not speak against God in unrighteousness! 

#### Psalms 75:6 For neither from exitings, nor from descents, nor from desolate mountains, 

#### Psalms 75:7 for God is judge. This one he humbles, and this one he raises up high. 

#### Psalms 75:8 For a cup is in the hand of the LORD {wine of undiluted}, a full mixture; and he leans it this way unto this other way, but its wine with dregs was not emptied out. {shall drink All the sinners of the earth}. 

#### Psalms 75:9 But I shall exult into the eon; I shall strum to the God of Jacob. 

#### Psalms 75:10 And all the horns of the sinners I shall fracture in pieces together, and {shall be exalted the horn of the just}. 

#### Psalms 76:1 {is made known in Judea God}; in Israel {is great his name}, 

#### Psalms 76:2 and {became for peace his place}; and his home is in Zion. 

#### Psalms 76:3 There he broke the might of the bows, the shield, and the broadsword, and war. 

#### Psalms 76:4 {give light You wonderfully} from {mountains the eternal}. 

#### Psalms 76:5 {were disturbed All the senseless in the heart}. {slept their sleep and did not find anything All the men of wealth} in their hands. 

#### Psalms 76:6 Because of your reproach, O God of Jacob, {slumbered the ones mounting the horses}. 

#### Psalms 76:7 You are fearful, and who shall oppose you? For how long is your anger? 

#### Psalms 76:8 From out of the heaven you caused {to be heard judgment}. The earth feared, and was still, 

#### Psalms 76:9 in the rising up for judgment by God, to deliver all the gentle in the earth. PAUSE. 

#### Psalms 76:10 For the inner thought of man shall make acknowledgment to you; and what is left of the inner thought shall solemnize a holiday to you. 

#### Psalms 76:11 Make a vow, and render to the LORD our God! All the ones round about him shall bring gifts 

#### Psalms 76:12 to the fearful one and the one removing the spirits of rulers; fearful to the kings of the earth. 

#### Psalms 77:1 With my voice {to the LORD I cried out}; my voice to God; and he heeded me. 

#### Psalms 77:2 In the day of my affliction I inquired of God. {my hands By night} were before him, and I was not deceived. {refused to be comforted My soul}. 

#### Psalms 77:3 I remembered God and was glad. I meditated and {was faint-hearted my spirit}. PAUSE. 

#### Psalms 77:4 {first took watches My eyes}; I was disturbed and I did not speak. 

#### Psalms 77:5 I reasoned {days about ancient}; and {years everlasting I remembered}. 

#### Psalms 77:6 And I meditated; {by night with my heart I conversed}, and {tilled my spirit}. 

#### Psalms 77:7 Shall {into the eons thrust me away the LORD}? And will he proceed to not think well of me any more? 

#### Psalms 77:8 Or, {at the end his mercy will he cut off}? Did he finish entirely his discourse from generation to generations? 

#### Psalms 77:9 Shall {forget to pity God}, or hold up {in his anger his compassions}? PAUSE. 

#### Psalms 77:10 And I said, now I began. This is the change of the right hand of the highest. 

#### Psalms 77:11 I remembered the works of the LORD. For I shall remember {from the beginning your wonders}, 

#### Psalms 77:12 and I shall meditate on all your works; even in your practices I will meditate. 

#### Psalms 77:13 O God, {is in the holy place your way}. What God is great as our God? 

#### Psalms 77:14 You are God, the one doing wonders. You made known among the peoples your power. 

#### Psalms 77:15 You ransomed {by your arm your people}, the sons of Jacob and Joseph. 

#### Psalms 77:16 {beheld you The waters}, O God, {beheld you the waters} and feared; {were disturbed the abysses}. 

#### Psalms 77:17 There was a multitude of noises of waters; {a sound gave out the clouds}; for also your arrows travel abroad. 

#### Psalms 77:18 The sound of your thunder in the wheel; {appeared your lightnings} to the inhabitable world; {was shaken and trembling took place the earth}. 

#### Psalms 77:19 {are in the sea Your ways}, and your roads are in {waters many}, and your footsteps shall not be known. 

#### Psalms 77:20 You guided {as sheep your people} by the hand of Moses and Aaron. 

#### Psalms 78:1 Take heed, O my people, to my law! Lean your ear to the words of my mouth! 

#### Psalms 78:2 I will open {in parables my mouth}; I will utter riddles from the beginning; 

#### Psalms 78:3 as many as we heard and we know them, and our fathers described to us. 

#### Psalms 78:4 They were not hidden from their children for {generation another}; but are reporting the praises of the LORD, and his dominations, and his wonders which he did. 

#### Psalms 78:5 For he raised up a testimony in Jacob, and {a law he put} in Israel, which he gave charge to our fathers, to make them known to their sons; 

#### Psalms 78:6 so that {should know generation another} -- the sons being birthed. And they shall rise up and report them to their sons, 

#### Psalms 78:7 that they should put {upon God their hope}, and should not forget the works of God, but {of his commandments shall inquire}; 

#### Psalms 78:8 that they should not become as their fathers -- {generation a crooked and greatly embittered}; a generation which did not straightened out its own heart, and {was not trustworthy with God its spirit}. 

#### Psalms 78:9 The sons of Ephraim stretching tight and shooting with bows, turned back in the day of battle. 

#### Psalms 78:10 They did not guard the covenant of God, and {by his law they did not want to go}. 

#### Psalms 78:11 And they forgot his good works, and his wonders which he showed to them, 

#### Psalms 78:12 before their fathers; what {he did wonders} in the land of Egypt in the plain of Tanis. 

#### Psalms 78:13 How he tore up the sea, and led them through; and he stood the waters as a water bag. 

#### Psalms 78:14 And he guided them with a cloud by day, and the entire night with the illumination of fire. 

#### Psalms 78:15 He tore open the rock in the wilderness, and he gave them a drink as in {deep a vast}. 

#### Psalms 78:16 And he brought water from the rock, and he led it down as rivers of waters. 

#### Psalms 78:17 And they proceeded still to sin against him; they greatly embittered the highest in a waterless place. 

#### Psalms 78:18 And they put God to the test in their hearts, to ask foods for their lives. 

#### Psalms 78:19 And they spoke ill of God. And they said, Shall God be able to prepare a table in the wilderness? 

#### Psalms 78:20 For when he struck the rock, and there flowed waters, and rushing streams inundated, shall also {bread he be able to give} or prepare a table for his people? 

#### Psalms 78:21 On account of this the LORD heard, and was raised in anger. And a fire was lit in Jacob, and anger ascended upon Israel. 

#### Psalms 78:22 For they did not trust in God, nor did they hope upon his deliverance. 

#### Psalms 78:23 And he gave charge to clouds far above, and the doors of heaven were opened, 

#### Psalms 78:24 and {rained upon them manna} to eat; and {the bread of heaven he gave to them}. 

#### Psalms 78:25 {bread of angels ate Man}; {provisions he sent to them} in fullness. 

#### Psalms 78:26 He departed the south wind from heaven, and he brought on by his power the southwest wind. 

#### Psalms 78:27 And he rained {upon them as dust flesh}; even {as the sand of the seas winged creatures feathered}. 

#### Psalms 78:28 And they fell in the midst of their camp round about their tents. 

#### Psalms 78:29 And they ate, and were filled up exceedingly. And {their desire he brought} to them. 

#### Psalms 78:30 They were not deprived of their desire; but food was in their mouth, 

#### Psalms 78:31 and the anger of God ascended upon them; and he killed in their plenty; and the chosen ones of Israel he impeded. 

#### Psalms 78:32 In all these things they sinned still, and did not trust in his wonders. 

#### Psalms 78:33 And {ended in folly their days}, and their years with haste. 

#### Psalms 78:34 Whenever he killed them, then they sought him; and they turned and rose early to search for God. 

#### Psalms 78:35 And they remembered that God {their helper is}, and God the Highest {ransomer is their}. 

#### Psalms 78:36 And they loved him by their mouth, but by their tongue they lied to him. 

#### Psalms 78:37 And their heart was not straight with him, nor did they trust in his covenant. 

#### Psalms 78:38 But he is one pitying, and he shall atone their sins, and he will not utterly destroy. And he will fill the turning of his rage, and shall not kindle all his anger. 

#### Psalms 78:39 And he remembered that they are flesh; a wind going forth and not returning. 

#### Psalms 78:40 How often they greatly embittered him in the wilderness; they provoked him to anger in {land a waterless}. 

#### Psalms 78:41 And they turned and tested God; even the holy one of Israel they provoked. 

#### Psalms 78:42 They did not remember his hand the day of which he ransomed them from out of the hand of one afflicting; 

#### Psalms 78:43 or how he made {in Egypt his signs}, and his miracles in the plain of Tanis; 

#### Psalms 78:44 and he converted {into blood their rivers}, and their showers so as to not drink. 

#### Psalms 78:45 He sent to them the dog-fly, and it devoured them; and the frog, and it ruined them. 

#### Psalms 78:46 And he appointed the blight for their fruits; and {for their miseries the locust}. 

#### Psalms 78:47 He killed {by hail their grapevine}, and their sycamine trees by the frost. 

#### Psalms 78:48 And he delivered up {unto hail their cattle}, and their possessions to the fire. 

#### Psalms 78:49 He sent out to them the anger of his rage; rage and anger and affliction; a commission through {angels wicked}. 

#### Psalms 78:50 He opened the road of his anger; he did not spare {from death their souls}; and {their cattle to death he consigned}. 

#### Psalms 78:51 And he struck every first-born in the land of Egypt; first-fruit of all their toil in the tents of Ham. 

#### Psalms 78:52 And he departed {as sheep his people}; and he led them up as a flock in the wilderness. 

#### Psalms 78:53 And he guided them with hope; and they were not timid, and {their enemies covered the sea}. 

#### Psalms 78:54 And he brought them into {mountain his sanctified}; this mountain which {acquired his right hand}. 

#### Psalms 78:55 And he cast out {before their face nations}, and he allotted them by a line of inheritance. And he encamped {among their tents the tribes of Israel}. 

#### Psalms 78:56 And they tested and greatly embittered God the highest; and his testimonies they did not keep. 

#### Psalms 78:57 And they turned and annulled, as also their fathers converted into {bow a crooked}. 

#### Psalms 78:58 And they provoked him to anger in their hills; and in their carvings they provoked him to jealousy. 

#### Psalms 78:59 God heard, and he overlooked; and he treated {with contempt exceedingly Israel}. 

#### Psalms 78:60 And he thrust away the tent of Shiloh, the tent in which he encamped among men. 

#### Psalms 78:61 And he delivered up {into captivity their strength}, and their beauty into the hands of the enemies. 

#### Psalms 78:62 And he consigned {by the broadsword his people}; and his inheritance he overlooked. 

#### Psalms 78:63 Their young men were devoured by fire, and their virgins were not mourned for. 

#### Psalms 78:64 Their priests {by the broadsword fell}, and their widows shall not be wept over. 

#### Psalms 78:65 And {awakened as from sleep the LORD}; as a mighty one being dizzy from wine. 

#### Psalms 78:66 And he struck his enemies unto the rear; {scorn for eternal he appointed them}. 

#### Psalms 78:67 And he thrust away the tent of Joseph; and the tribe of Ephraim he did not choose. 

#### Psalms 78:68 He chose the tribe of Judah, mount Zion which he loved. 

#### Psalms 78:69 And he built {as the unicorn his sanctuary} in the earth; he laid its foundation into the eon. 

#### Psalms 78:70 And he chose David his servant; and he took him from out of the flocks of the sheep; 

#### Psalms 78:71 even from behind the ones giving birth he took him, to tend Jacob his servant, and Israel his inheritance. 

#### Psalms 78:72 And he tended them in the innocence of his heart; and in the skillfulness of his hands he guided them. 

#### Psalms 79:1 O God, {come nations} into your inheritance; they defiled {temple holy your}; they made Jerusalem as a storehouse of fruits. 

#### Psalms 79:2 They made the decaying flesh of your servants foods for the winged creatures of the heaven; the flesh of your sacred ones for the wild beasts of the earth. 

#### Psalms 79:3 They poured out their blood as water round about Jerusalem; and there was no one burying them. 

#### Psalms 79:4 We became scorn to our neighbors; for a sneering and taunting by the ones round about us. 

#### Psalms 79:5 For how long, O LORD? Will you be provoked to anger to the end? Will {burn as fire your zeal}? 

#### Psalms 79:6 Pour out your anger upon nations, the ones not perceiving you! and upon kingdoms in which {your name they called not upon}. 

#### Psalms 79:7 For they devoured Jacob, and {his place made} desolate. 

#### Psalms 79:8 You should not remember our lawless deeds of old. Quickly let {be first to take us your compassions}! for we are {poor exceedingly}. 

#### Psalms 79:9 Help us, O God our deliverer, because of the glory of your name! O LORD, rescue us, and atone our sins, because of your name! 

#### Psalms 79:10 Lest at any time {should say the nations}, Where is their God? then let it be known among the nations, before our eyes, the vengeance for the blood of your servants being poured out! 

#### Psalms 79:11 Let {enter before you the moaning of the ones being shackled}! According to the greatness of your arm protect the sons of the ones being put to death! 

#### Psalms 79:12 Repay to our neighbors seven-fold into their bosom! for their scorning which they berated you, O LORD. 

#### Psalms 79:13 But we are your people, and the sheep of your pasture. We shall confess to you, O God, into the eon; for generation and generation we shall declare your praise. 

#### Psalms 80:1 O one tending Israel, take heed! O one guiding {as sheep Joseph}, the one sitting down upon the cherubim -- appear! 

#### Psalms 80:2 Before Ephraim, and Benjamin, and Manasseh -- awaken your might, and come for the delivering us! 

#### Psalms 80:3 O God, turn towards us, and let {appear your face}! and we shall be delivered. 

#### Psalms 80:4 O LORD God of the forces, for how long are you provoked to anger over the prayer of your servants? 

#### Psalms 80:5 You shall feed us bread of tears, and give us to drink with tears by measure. 

#### Psalms 80:6 You made us for dispute to our neighbors; and our enemies sneer at us. 

#### Psalms 80:7 O LORD God of the forces, turn towards us, and let {appear your face}! and we shall be delivered. 

#### Psalms 80:8 {a grapevine from out of Egypt You moved}; you cast out nations, and planted her. 

#### Psalms 80:9 You opened a way before her, and you planted her roots, and {was filled the earth}. 

#### Psalms 80:10 {covered mountains Her shadow}, and her tendrils covered the cedars of God. 

#### Psalms 80:11 She stretched out her vine branches unto the sea, and {unto the rivers her shoots}. 

#### Psalms 80:12 Why did you demolish her barrier, and {gather her vintage all the ones passing by the way}? 

#### Psalms 80:13 {laid her wasted The pig from the forest}, and {boar the wild} feeds on her. 

#### Psalms 80:14 O God of the forces, turn towards us indeed! And look upon us from out of heaven, and behold and visit this grapevine! 

#### Psalms 80:15 And ready her whom {planted your right hand}! and upon the son of man whom you fortified to yourself. 

#### Psalms 80:16 She is being set on fire and being dug up. From the reproach of your face they shall be destroyed. 

#### Psalms 80:17 Let {be your hand} upon the man of your right, even upon the son of man whom you strengthened to yourself. 

#### Psalms 80:18 For in no way should we separate from you. You shall enliven us, and {your name we shall call upon}. 

#### Psalms 80:19 O LORD God of the forces, turn towards us, and let {appear your face}! and we shall be delivered. 

#### Psalms 81:1 Exult to God our helper! Shout to the God of Jacob! 

#### Psalms 81:2 Take a psalm, and utter a sound on the tambourine, {psaltery and the delightful} with the harp! 

#### Psalms 81:3 Trump during the new moon -- a trumpet in the well-marked day of your holiday! 

#### Psalms 81:4 For {an order to Israel it is}, and a judgment by the God of Jacob. 

#### Psalms 81:5 {to be a testimony among Joseph He made it}, during his coming forth from out of the land of Egypt; a tongue which knew not, he heard. 

#### Psalms 81:6 He removed {from tribute his back}; his hands {to the hamper were enslaved}. 

#### Psalms 81:7 In affliction you called upon me, and I rescued you. I heeded you in the concealed place of the gale; PAUSE. I tried you at Water of Dispute. 

#### Psalms 81:8 Hear, O my people! and I will testify to you, O Israel, if you should hear me. 

#### Psalms 81:9 There will not be in you a god newly made, nor shall you do obeisance to an alien god. 

#### Psalms 81:10 For I am the LORD your God; the one leading you from out of the land of Egypt. Widen your mouth! and I shall fill it. 

#### Psalms 81:11 But {did not hear my people} my voice; and Israel gave no heed to me. 

#### Psalms 81:12 And I sent them out according to the practices of their hearts; they shall go in their practices. 

#### Psalms 81:13 If my people heard me, {Israel by my ways if were gone}, 

#### Psalms 81:14 not the less would {their enemies I humbled}, and {upon the ones afflicting them I would have put my hand}. 

#### Psalms 81:15 The enemies of the LORD lied to him, and {will be their time} into the eon. 

#### Psalms 81:16 And he fed them of the fat of wheat; and {from out of the rock with honey he filled them}. 

#### Psalms 82:1 God stood in the congregation of gods; {in the midst and} of gods he examines. 

#### Psalms 82:2 For how long will you judge injustice, and {persons of sinners receive}? 

#### Psalms 82:3 Judge for the orphan, and the poor! {to the humble and needy Do justice}! 

#### Psalms 82:4 Deliver the needy and the poor! {from the hand of the sinner rescue him}! 

#### Psalms 82:5 They did not know, nor perceived. {in darkness They travel}. {shall be shaken All the foundations of the earth}. 

#### Psalms 82:6 I said, You are gods, and {sons of the highest all}. 

#### Psalms 82:7 But you {as men die}; and {as one of the rulers fall}. 

#### Psalms 82:8 Rise up, O God, judge the earth! for you shall inherit among all the nations. 

#### Psalms 83:1 O God, who is likened to you? You should not keep quiet, nor soothe, O God. 

#### Psalms 83:2 For behold, your enemies sounded, and the ones detesting you lift their head. 

#### Psalms 83:3 Against your people they deal treacherously in design, and consult against your holy ones. 

#### Psalms 83:4 They said, Come, for we should utterly destroy them from out of the nations; for in no way should {be remembered the name of Israel} any longer. 

#### Psalms 83:5 For they consulted in concord together; against you {a covenant they ordained}; 

#### Psalms 83:6 even the tents of the Edomites, and the Ishmaelites, Moab, and the Hagarites; 

#### Psalms 83:7 Gebal, and Ammon, and Amalek; the Philistines with the ones dwelling in Tyre. 

#### Psalms 83:8 For even also Assyria came together with them; they became an assistance to the sons of Lot. PAUSE. 

#### Psalms 83:9 Do to them as to Midian, and to Sisera; as to Jabin at the rushing stream Kishon! 

#### Psalms 83:10 They were utterly destroyed in En-dor. They became as dung for the earth. 

#### Psalms 83:11 Make their rulers as Oreb and Zeeb, and Zebah and Zalmunna -- all their rulers! 

#### Psalms 83:12 Who said, We should inherit {for ourselves the sanctuary of God}? 

#### Psalms 83:13 O my God, make them as a whirlwind; as stubble against the face of the wind! 

#### Psalms 83:14 as fire which shall burn up a forest; as a flame which incinerates mountains. 

#### Psalms 83:15 So shall you pursue them with your gale; and in your anger you shall disturb them. 

#### Psalms 83:16 Fill their faces with dishonor! and they shall seek your name, O LORD. 

#### Psalms 83:17 Let them be shamed and disturbed into the eon of the eon! And let them feel remorse and be destroyed! 

#### Psalms 83:18 And let them know that the name to you is, the LORD! You alone are highest over all the earth. 

#### Psalms 84:1 How beloved are your tents, O LORD of the forces. 

#### Psalms 84:2 {longs after and falters My soul} for the courtyards of the LORD. My heart and my flesh exulted over the living God. 

#### Psalms 84:3 For even the sparrow finds for himself a house; and the turtle-dove a nest for herself, where she puts her own nestlings, even your altars, O LORD of the forces, my king and my God. 

#### Psalms 84:4 Blessed are the ones dwelling in your house; into the eons of the eons they shall praise you. PAUSE. 

#### Psalms 84:5 Blessed is the man in whom is the assistance to him from you; {ascending in his heart he ordained}; 

#### Psalms 84:6 into the valley of the place of weeping; into the place which he put himself. For even {a blessing will give the one establishing law}. 

#### Psalms 84:7 They shall go from force to force; they shall see the God of gods in Zion. 

#### Psalms 84:8 O LORD, the God of the forces, listen to my prayer! Give ear, O God of Jacob! PAUSE. 

#### Psalms 84:9 {our defender Behold O God}, and look into the face of your anointed one. 

#### Psalms 84:10 For better is {day one} in your courtyards than thousands. I would choose to be thrown aside in the house of my God, rather than for me to live among the tents of sinners. 

#### Psalms 84:11 For {mercy and truth the LORD loves}. God {favor and glory shall give}. The LORD will not deprive good things to the ones going in innocence. 

#### Psalms 84:12 O LORD, the God of the forces, blessed is the man hoping upon you. 

#### Psalms 85:1 You thought well, O LORD, of your land. You returned the captivity of Jacob. 

#### Psalms 85:2 You forgave the lawless deeds of your people. You covered all their sins. 

#### Psalms 85:3 You rested all of your anger. You turned from the anger of your rage. 

#### Psalms 85:4 Turn us, O God of our deliverances, and turn your rage from us! 

#### Psalms 85:5 Shall you {into the eons be provoked to anger against us}? Or shall you extend your anger from generation unto generation? 

#### Psalms 85:6 O God, you, in turning towards us shall enliven us, and your people shall be glad over you. 

#### Psalms 85:7 Show to us, O LORD, your mercy! and {your deliverance may you give} to us. 

#### Psalms 85:8 I shall hear what {shall speak to me the LORD God}; for he shall speak peace unto his people, and unto his sacred ones, and unto the ones turning hearts unto him. 

#### Psalms 85:9 Moreover {is near the ones fearing him his deliverance}; so that {may encamp his glory} in our land. 

#### Psalms 85:10 Mercy and truth are met together; righteousness and peace kissed. 

#### Psalms 85:11 Truth {from out of the land arose}; and righteousness {from heaven looks through}. 

#### Psalms 85:12 For even the LORD shall give graciousness; and our land shall give its fruit. 

#### Psalms 85:13 Righteousness {before him shall go forth}, and he shall place {in the way his footsteps}. 

#### Psalms 86:1 Lean, O LORD, your ear, and heed me! for {poor and needy I am}. 

#### Psalms 86:2 Guard my soul, for I am sacred! Deliver your servant, O my God! the one hoping upon you. 

#### Psalms 86:3 Show mercy on me, O LORD! for to you I will cry out the entire day. 

#### Psalms 86:4 Gladden the soul of your servant! for to you I lifted my soul. 

#### Psalms 86:5 For you, O LORD, are gracious, and lenient, and full of mercy to all the ones calling upon you. 

#### Psalms 86:6 Give ear, O LORD, to my prayer, and take heed to the voice of my supplication! 

#### Psalms 86:7 In the day of my affliction I cried out to you, for you heeded me. 

#### Psalms 86:8 There is not one likened to you among gods, O LORD; and there is not one likened according to your works. 

#### Psalms 86:9 All the nations, as many as you made, shall come and do obeisance before you, O LORD, and they shall glorify your name. 

#### Psalms 86:10 For {great you are}, and performing wonders. You are the only God. 

#### Psalms 86:11 Guide me, O LORD, in your way! and I will go in your truth. Let {be glad my heart} to fear your name! 

#### Psalms 86:12 I shall make acknowledgment to you, O LORD my God, with {entire heart my}; and I will glorify your name into the eon. 

#### Psalms 86:13 For your mercy is great towards me; and you rescued my soul from out of {Hades lowermost}. 

#### Psalms 86:14 O God, lawbreakers rose up against me, and a gathering of strong ones sought my life; and they did not set you before them. 

#### Psalms 86:15 And you, O LORD my God, are pitying and merciful, lenient and full of mercy, and true. 

#### Psalms 86:16 Look upon me, and show mercy on me! Give your might to your child, and deliver the son of your maidservant! 

#### Psalms 86:17 Establish with me a sign for good, and let {see the ones detesting me}, and be ashamed! For you, O LORD, helped me, and comforted me. 

#### Psalms 87:1 His foundations are in the {mountains holy}. 

#### Psalms 87:2 The LORD loves the gates of Zion above all the tents of Jacob. 

#### Psalms 87:3 Things being glorified was spoken concerning you, O city of God. 

#### Psalms 87:4 I shall make mention of Rahab and Babylon to the ones knowing me; and behold, the Philistines and Tyre, and the people of the Ethiopians; these were there. 

#### Psalms 87:5 Mother of Zion, {shall say a man}, and the man born in her; and {himself founded her the highest}. 

#### Psalms 87:6 The LORD shall describe in the writing of peoples, and of these rulers being born in her. PAUSE. 

#### Psalms 87:7 As ones being glad are all dwelling in you. 

#### Psalms 88:1 O LORD, the God of my deliverance; {day I cried out and at night before you}. 

#### Psalms 88:2 Let {enter before you my prayer}! Lean your ear to my supplication! 

#### Psalms 88:3 For {is filled of bad things my soul}, and my life {Hades approached}. 

#### Psalms 88:4 I was counted with the ones going down into the pit. I became as {man an incurable}; 

#### Psalms 88:5 {among the dead free}, as ones slain sleeping in the tomb, whom you do not remember any longer; and they {from out of your hand were thrusted away}. 

#### Psalms 88:6 They put me in {pit the lowermost}, in dark places, and in the shadow of death. 

#### Psalms 88:7 Upon me {stayed your rage}, and {all your crests you brought upon me}. PAUSE. 

#### Psalms 88:8 You distanced {the ones knowing me from me}. You made me an abomination to them. I have been delivered up, and have not gone forth. 

#### Psalms 88:9 My eyes are weakened from poorness. I cried out to you, O LORD, the entire day. I opened and spread out to you my hands. 

#### Psalms 88:10 Shall {for the dead you do wonders}? or shall physicians rise up and make acknowledgment to you? 

#### Psalms 88:11 Shall {describe any one in the tomb} your mercy and your truth in the destruction? 

#### Psalms 88:12 Shall {be made known in the darkness your wonders}? and your righteousness in a land being forgotten? 

#### Psalms 88:13 But I {to you O LORD cried out}; and in the morning my prayer shall be with you beforehand. 

#### Psalms 88:14 Why, O LORD, do you thrust away my soul, and turn your face from me? 

#### Psalms 88:15 {poor I am} and in troubles from my youth. But being raised up high I was humbled and left destitute. 

#### Psalms 88:16 Upon me {went your angers}; your frightful things disturbed me. 

#### Psalms 88:17 They encircle me as water; the entire day they compassed me together. 

#### Psalms 88:18 You put far from me friend and near one, and the ones knowing me, because of misery. 

#### Psalms 89:1 {of your mercies O LORD into the eon I shall sing}. Unto generation and generation I shall report your truth with my mouth. 

#### Psalms 89:2 For you said, Into the eon mercy shall be built up. {in the heavens shall be prepared Your truth}. 

#### Psalms 89:3 I ordained a covenant with my chosen ones; I swore by an oath to David my servant. 

#### Psalms 89:4 Unto the eon I shall prepare your seed, and I will build {unto generation and generation your throne}. 

#### Psalms 89:5 {shall acknowledge The heavens} your wonders, O LORD, and your truth in the assembly of the holy ones. 

#### Psalms 89:6 For who in the clouds shall be equal to the LORD; likened to the LORD among the sons of God? 

#### Psalms 89:7 God is being glorified in the counsel of holy ones; {great and fearful he is} over all the ones surrounding him. 

#### Psalms 89:8 O LORD, the God of the forces, who is likened to you? You are mighty, O LORD, and your truth is round about you. 

#### Psalms 89:9 You are master of the might of the sea; and the tossing about of its waves you soothe. 

#### Psalms 89:10 You humbled {as slain the proud}; with the arm of your might you dispersed your enemies. 

#### Psalms 89:11 {are yours The heavens}, and {is yours the earth}. The inhabitable world and its fullness you founded. 

#### Psalms 89:12 The north and the west you created. Tabor and Hermon {in your name shall exult}. 

#### Psalms 89:13 Your arm is with dominations. Let {be fortified your hand}! Let {be raised up high your right hand}! 

#### Psalms 89:14 Righteousness and equity are the preparation of your throne; mercy and truth shall go forth before your face. 

#### Psalms 89:15 Blessed are the people knowing the shout of joy. O LORD, {in the light of your face they shall go}. 

#### Psalms 89:16 And in your name they shall exult the entire day. And in your righteousness they shall be raised up high. 

#### Psalms 89:17 For {the boast of their power you are}; and by your benevolence {shall be raised up high our horn}. 

#### Psalms 89:18 For {is of the LORD assistance}, and of the holy one of Israel, our king. 

#### Psalms 89:19 Then you spoke in a vision to your sons, and said, I put help upon a mighty one; raising up high a chosen one from out of my people. 

#### Psalms 89:20 I found David my servant. {with oil my holy I anointed him}. 

#### Psalms 89:21 For my hand shall be an aid to him; and my arm shall strengthen him. 

#### Psalms 89:22 {shall not derive benefit The enemy} by him; and the son of lawlessness shall not proceed to inflict evil on him. 

#### Psalms 89:23 And I will cut down {from in front of him his enemies}; and the ones detesting him shall be put to flight. 

#### Psalms 89:24 And my truth and my mercy are with him; and in my name {shall be raised up high his horn}. 

#### Psalms 89:25 And I will set {in the sea his hand}, and {in rivers his right hand}. 

#### Psalms 89:26 He shall call upon me, saying, {my father You are}, my God, and the shielder of my deliverance. 

#### Psalms 89:27 And I {first-born will make him}, high above the kings of the earth. 

#### Psalms 89:28 Into the eon I shall guard to him my mercy; and my covenant is trustworthy to him. 

#### Psalms 89:29 And I shall establish {into the eon of the eon his seed}, and his throne as the days of heaven. 

#### Psalms 89:30 If {should abandon his sons} my law, and {by my judgments should not go}; 

#### Psalms 89:31 if {my ordinances they should profane}, and {my commandments should not keep}; 

#### Psalms 89:32 then I will visit {with a rod their lawlessnesses}; and {with whips their iniquities}. 

#### Psalms 89:33 But my mercy in no way should I efface from them, nor in any way should I wrong in my truth; 

#### Psalms 89:34 nor in any way should I profane my covenant; and the things going forth through my lips in no way should I annul. 

#### Psalms 89:35 Once I swore by an oath by my holiness; shall I lie to David, no. 

#### Psalms 89:36 His seed {into the eon shall abide}, and his throne as the sun before me; 

#### Psalms 89:37 and as the moon being readied into the eon, and the {witness in heaven trustworthy}. PAUSE. 

#### Psalms 89:38 But you thrusted away and treated with contempt. You raised your anointed one. 

#### Psalms 89:39 You eradicated the covenant of your servant. You profaned in the land of his sanctuary. 

#### Psalms 89:40 You demolished all his barriers. You made his fortresses dreaded. 

#### Psalms 89:41 {plundered him All the ones traveling through the way}. He became scorn to his neighbors. 

#### Psalms 89:42 You raised up high the right hand of the ones afflicting him; you made glad all his enemies. 

#### Psalms 89:43 You turned back the help of his broadsword, and did not assist him in battle. 

#### Psalms 89:44 You rested from cleansing him. {his throne unto the ground You broke down}. 

#### Psalms 89:45 You diminished the days of his throne. You poured upon him shame. 

#### Psalms 89:46 For how long, O LORD, will you turn away -- to the end? Will {burn as fire your anger}? 

#### Psalms 89:47 Remember what my reality is; for acting in folly, did you creat all the sons of men? 

#### Psalms 89:48 Who is the man who shall live and not see death? Shall he rescue his own soul from out of the hand of Hades? PAUSE. 

#### Psalms 89:49 Where are {mercies your ancient}, O LORD, which you swore by an oath to David in your truth? 

#### Psalms 89:50 Remember, O LORD, the scorning of your servants! which I underwent in my bosom, of many nations; 

#### Psalms 89:51 where {berated your enemies}, O LORD, where they berated the equivalent of your anointed one. 

#### Psalms 89:52 Blessed be the LORD into the eon. May it be. May it be. 

#### Psalms 90:1 O LORD, {a refuge you became} for us unto generation and generation. 

#### Psalms 90:2 Before the mountains existed, and {took shape the earth and inhabitable world}; even from eon and until the eon you are. 

#### Psalms 90:3 You should not return man unto humiliation, whereas you said, Return, O sons of men! 

#### Psalms 90:4 For a thousand years in your eyes, O LORD, are as day -- yesterday which went, and is as a watch in the night. 

#### Psalms 90:5 {their contempt Years shall be}; {the morning as tender shoots may it go by}; 

#### Psalms 90:6 {in the morning blooming}, and may it go by; in the evening it shall fall away, may it be hardened and dried up. 

#### Psalms 90:7 For we faltered in your anger, and in your rage we were disturbed. 

#### Psalms 90:8 You put our lawlessness before you; our eon in the illumination of your face. 

#### Psalms 90:9 For all our days failed; even in your anger we failed. Our years are as of a spider meditating. 

#### Psalms 90:10 The days of our years among them are seventy years; but if by commands -- eighty years, but much of them toil and misery; for {comes mellowing} upon us, and we shall be corrected. 

#### Psalms 90:11 Who knows the power of your anger? and {because of the fear of your rage how to count out his days}? 

#### Psalms 90:12 {your right hand So make known to me}! and the ones being corrected in the heart by wisdom. 

#### Psalms 90:13 Return, O LORD! For how long? and give comfort unto your servants! 

#### Psalms 90:14 We were filled up in the morning with your mercy, O LORD, and we exulted and were glad in all our days. 

#### Psalms 90:15 We were gladdened because of the days you humbled us; years which we beheld bad things. 

#### Psalms 90:16 And look upon your servants, and upon your works, and guide their sons! 

#### Psalms 90:17 And let {be the brightness of the LORD our God} upon us! And {the works of our hands prosper for us} -- yes, {the work of our hands prosper}! 

#### Psalms 91:1 The one dwelling in the help of the highest, {in the protection of the God of the of heaven shall lodge}. 

#### Psalms 91:2 He shall say to the LORD, {shielder You are my}, and my refuge; my God, and I will hope upon him. 

#### Psalms 91:3 For he shall rescue you from out of the snare of hunters, from {matter a disturbing}. 

#### Psalms 91:4 With his upper back he shall overshadow you, and under his wings you shall hope. {with the shield He shall encircle you} of his truth. 

#### Psalms 91:5 You shall not be afraid from fear by night, nor from an arrow flying by day, 

#### Psalms 91:6 nor from a thing {in darkness going}, nor from an adverse incident, and the demon at midday. 

#### Psalms 91:7 {shall fall at your side A thousand}, and myriads at your right hand; {unto you but it shall not approach}. 

#### Psalms 91:8 Only with your eyes you shall contemplate; and {the recompense of sinners you shall see}. 

#### Psalms 91:9 For you, O LORD, the one of my hope; {the highest you made} your refuge. 

#### Psalms 91:10 There shall not come near to you bad things; and the whip shall not approach in your tent. 

#### Psalms 91:11 For to his angels he gives charge concerning you, to guard you in all your ways. 

#### Psalms 91:12 By hands they will lift you, lest at any time you should stumble {against a stone your foot}. 

#### Psalms 91:13 {upon the asp and cobra You shall set foot}; and you shall trample on the lion and dragon. 

#### Psalms 91:14 For {upon me he hoped}, and I shall rescue him. I will shelter him, for he knew my name. 

#### Psalms 91:15 He shall cry out to me, and I shall heed him. {with him I am} in affliction. I will rescue him and glorify him. 

#### Psalms 91:16 {with duration of days I will fill him}, and I will show to him my deliverance. 

#### Psalms 92:1 It is good to make acknowledgment to the LORD, and to strum to your name, O Highest One. 

#### Psalms 92:2 To announce in the morning of your mercy, and of your truth at night, 

#### Psalms 92:3 on the ten-stringed psaltery, with an ode on the harp. 

#### Psalms 92:4 For you gladdened me, O LORD, by your action; and in the works of your hands I shall exult. 

#### Psalms 92:5 O how {were magnified your works}, O LORD; {exceedingly deepen your thoughts}. 

#### Psalms 92:6 {man A foolish} will not know, and the senseless shall not perceive these things. 

#### Psalms 92:7 In the rising up of the sinners as grass, and {look on all the ones working lawlessness}, that thus they shall be utterly destroyed into the eon of the eon. 

#### Psalms 92:8 But you are the highest into the eon, O LORD. 

#### Psalms 92:9 For behold, your enemies, O LORD, for behold, your enemies shall perish, and {shall be dispersed all the ones working lawlessness}. 

#### Psalms 92:10 And {shall be raised up high as a unicorn my horn}; and my old age with {oil plentiful}. 

#### Psalms 92:11 And {looked my eye} on my enemies, and {among the ones rising up against me the ones acting wickedly shall hear my ear}. 

#### Psalms 92:12 The just one {as a palm tree shall bloom}; as a cedar in Lebanon he shall be multiplied. 

#### Psalms 92:13 The ones being planted in the house of the LORD, in the courtyards of our God, shall blossom. 

#### Psalms 92:14 Still they shall be multiplied in {old age plentiful}; and {enjoying pleasure they will be}; to announce 

#### Psalms 92:15 that {is upright the LORD our God}, and there is no injustice in him. 

#### Psalms 93:1 The LORD reigned; {beauty he put on}; the LORD put on power and girded himself. For he solidified the inhabitable world, which shall not be shaken. 

#### Psalms 93:2 {was prepared Your throne} from then; from the eon you are. 

#### Psalms 93:3 {lifted up The rivers}, O LORD, {lifted up the rivers} their voices. 

#### Psalms 93:4 {shall take away The rivers}; you shall wear them away by sounds {waters of many}. {are wonderful the crests of the sea}; {is wonderful in high places the LORD}. 

#### Psalms 93:5 Your testimonies are trustworthy -- exceedingly. {to your house is becoming Sanctification}, O LORD, for the duration of days. 

#### Psalms 94:1 The God of acts of vengeance. The LORD God of acts of vengeance spoke openly. 

#### Psalms 94:2 Rise up high, O one judging the earth! Render recompense to the proud! 

#### Psalms 94:3 For how long sinners, O LORD, how long shall sinners boast? 

#### Psalms 94:4 They will utter and speak injustice; {shall speak all the ones practicing iniquity}. 

#### Psalms 94:5 Your people, O LORD, they humbled; and {your inheritance they inflicted evil on}. 

#### Psalms 94:6 The widow and orphan they killed; and the foreigner they murdered. 

#### Psalms 94:7 And they said, {shall not see the LORD}, nor shall {perceive the God of Jacob}. 

#### Psalms 94:8 Perceive indeed foolish among the people! and O moron, {at some time or other think}! 

#### Psalms 94:9 The one planting the ear, does he not hear? or the one shaping the eye, does he not contemplate? 

#### Psalms 94:10 The one correcting nations, shall he not reprove? The one teaching man knowledge; 

#### Psalms 94:11 the LORD, he knows the thoughts of men, for they are vain. 

#### Psalms 94:12 Blessed is a man whom ever you should correct, O LORD, and from out of your law you should teach him; 

#### Psalms 94:13 to calm him from {days evil}, until of which time he should have dug {for the sinner the pit}. 

#### Psalms 94:14 For {shall not thrust away the LORD} his people, and {his inheritance he shall not abandon}; 

#### Psalms 94:15 until of which time righteousness returns for judgment, and having it are all the straight in heart. PAUSE. 

#### Psalms 94:16 Who shall rise up to me against the ones acting wickedly? or who shall stand up with me against the ones working lawlessness? 

#### Psalms 94:17 Unless that the LORD helped me, {would shortly have sojourned in Hades my soul}. 

#### Psalms 94:18 If I said, {shakes My foot}; your mercy, O LORD, helps me. 

#### Psalms 94:19 According to the multitude of my griefs in my heart, so your comforts made glad my soul. 

#### Psalms 94:20 Shall {adhere with you the throne of lawlessness}, the one shaping trouble out of order? 

#### Psalms 94:21 They shall hunt for {soul a just}, and {blood innocent condemn}. 

#### Psalms 94:22 But {became to me the LORD} for a refuge; and my God for a helper of my hope. 

#### Psalms 94:23 And he shall recompense to them their lawlessness; and according to their wickedness {shall remove them from view The LORD God}. 

#### Psalms 95:1 Come, we should make exultation to the LORD; we should shout to God our deliverer. 

#### Psalms 95:2 We should go before his presence with acknowledgment; and by psalms we should sound aloud to him. 

#### Psalms 95:3 For {God is a great the LORD}, and {king a great} above all the earth. 

#### Psalms 95:4 For in his hand are the ends of the earth; and the heights of the mountains are his. 

#### Psalms 95:5 For his is the sea, and he himself made it; and {the dry land his hands shaped}. 

#### Psalms 95:6 Come, we should do obeisance and fall before him; and weep before the LORD, the one making us. 

#### Psalms 95:7 For he is our God, and we are the people of his pasture, and the sheep of his hand. Today, if {his voice you should hear}, 

#### Psalms 95:8 you should not harden your hearts as in the embittering, according to the day of the test in the wilderness, 

#### Psalms 95:9 of which {tested me your fathers}; they tried me, and they beheld my works. 

#### Psalms 95:10 Forty years I loathed that generation, and said, They continually wander in the heart, and they do not know my ways. 

#### Psalms 95:11 So I swore by an oath in my anger, Shall they enter into my rest, no. 

#### Psalms 96:1 Sing to the LORD {song a new}! Sing to the LORD all the earth! 

#### Psalms 96:2 Sing to the LORD! Bless his name! Announce good news day by day of his deliverance! 

#### Psalms 96:3 Announce among the nations of his glory, and among all the peoples of his wonders! 

#### Psalms 96:4 For great is the LORD, and praiseworthy -- exceedingly. He is fearful above all the gods. 

#### Psalms 96:5 For all the gods of the nations are demons; but the LORD {the heavens made}. 

#### Psalms 96:6 Acknowledgment and beauty are before him; holiness and majesty are in his sanctuary. 

#### Psalms 96:7 Bring to the LORD, O families of the nations! Bring to the LORD glory and honor! 

#### Psalms 96:8 Bring to the LORD glory for his name! Carry sacrifices, and enter into his courtyards! 

#### Psalms 96:9 Do obeisance to the LORD in {courtyard his holy}! Let {shake before his face all the earth}! 

#### Psalms 96:10 Say among the nations that, The LORD reigns! For even he set up the inhabitable world which will not be shaken. He shall judge peoples in straightness. 

#### Psalms 96:11 Let {be glad the heavens}, and let {exult the earth}! Let {be shaken the sea}, and the fullness of it! 

#### Psalms 96:12 {shall rejoice The plains}, and all the things in them. Then {shall exult all the trees of the forest} 

#### Psalms 96:13 from the face of the LORD, for he comes; for he comes to judge the earth. He shall judge the inhabitable world in righteousness, and peoples in his truth. 

#### Psalms 97:1 The LORD reigned. Exult, O earth! Let {be glad islands many}! 

#### Psalms 97:2 There is a cloud and dimness round about him; righteousness and judgment are the success of his throne. 

#### Psalms 97:3 Fire {before him shall go forth}, and it shall blaze round about his enemies. 

#### Psalms 97:4 {appeared His lightnings} to the inhabitable world; {beheld and shook the earth}. 

#### Psalms 97:5 The mountains {as beeswax melted away} from the face of the LORD; from the face of the LORD of all the earth. 

#### Psalms 97:6 {announced The heavens} his righteousness; and {beheld all the peoples} his glory. 

#### Psalms 97:7 {were shamed All the ones doing obeisance to the carvings}; the ones boasting in their idols. Let {do obeisance to him all his angels}! 

#### Psalms 97:8 {heard and was glad Zion}; and {exulted the daughters of Judea} because of your judgments, O LORD. 

#### Psalms 97:9 For you the LORD are highest over all the earth -- exceedingly. You were greatly exalted above all the gods. 

#### Psalms 97:10 The ones loving the LORD detest evil. The LORD guards the souls of his sacred ones. From out of the hand of the sinner he shall rescue them. 

#### Psalms 97:11 Light arose to the just, and {to the straight in heart gladness}. 

#### Psalms 97:12 {should be glad The just} in the LORD, and make acknowledgment to the remembrance of his holiness. 

#### Psalms 98:1 Sing to the LORD {song a new}! for {wonderful things did the LORD}. He delivered him by his right hand and {arm his holy}. 

#### Psalms 98:2 The LORD made known his deliverance; before the nations he revealed his righteousness. 

#### Psalms 98:3 He remembered his mercy to Jacob, and his truth to the house of Israel. {beheld All the ends of the earth} the deliverance of our God. 

#### Psalms 98:4 Shout to God all the earth! Sing and exult and strum! 

#### Psalms 98:5 Strum to the LORD with a harp; with a harp and voice of a psalm! 

#### Psalms 98:6 With {trumpets hammered metal}, and the sound of the trumpet of the horn shout before the king of the LORD! 

#### Psalms 98:7 Let {shake the sea}, and the fullness of it! the inhabitable world and all the ones dwelling in it. 

#### Psalms 98:8 Rivers shall clap hand together. The mountains shall exult from the face of the LORD, for he comes. 

#### Psalms 98:9 For he comes to judge the earth; he shall judge the inhabitable world in righteousness, and peoples in straightness. 

#### Psalms 99:1 The LORD reigned. Let {be angry peoples}! He is the one sitting upon the cherubim. Let {be shaken the earth}! 

#### Psalms 99:2 The LORD {in Zion is great}, and is high above all the peoples. 

#### Psalms 99:3 Let them acknowledge {name your great}! for {fearful and holy he is}. 

#### Psalms 99:4 And the honor of the king {equity loves}. You prepared straight judgment; and {righteousness in Jacob you established}. 

#### Psalms 99:5 Raise up high the LORD our God, and do obeisance at the footstool of his feet! for he is holy. 

#### Psalms 99:6 Moses and Aaron are among his priests, and Samuel is among the ones calling upon his name. They called upon the LORD, and he listened to them. 

#### Psalms 99:7 In a column of cloud he spoke to them; for they guarded his testimony, and his orders which he gave to them. 

#### Psalms 99:8 O LORD our God, you heeded them. O God, you {propitious became} to them, yet punishing over all their practices. 

#### Psalms 99:9 Raise up high the LORD our God, and do obeisance at {mountain his holy}! for {is holy the LORD our God}. 

#### Psalms 100:1 Shout to God all the earth! 

#### Psalms 100:2 Give service to the LORD with gladness! Enter his presence with exultation! 

#### Psalms 100:3 Know that the LORD, he is our God! He made us, and not we. But we are his people, and the sheep of his pasture. 

#### Psalms 100:4 Enter into his gates with acknowledgment, into his courtyards with hymns! Make acknowledgment to him! Praise his name! 

#### Psalms 100:5 For {is gracious the LORD}; {is into the eon his mercy}, and {unto generation and generation his truth}. 

#### Psalms 101:1 About mercy and judgment I shall sing to you, O LORD. 

#### Psalms 101:2 I shall strum, and I shall perceive in {way an unblemished}. When shall you come to me? I traveled in the innocence of my heart; in the midst of my house. 

#### Psalms 101:3 I did not set before my eyes {thing an illegal}; {ones committing violations I detested}. 

#### Psalms 101:4 {cleaved not to me heart A crooked}, turning aside from me, the wicked man I knew not. 

#### Psalms 101:5 The one speaking ill in private of the ones near him -- this one I drove out. Proud eye and insatiable heart -- with this one I ate not. 

#### Psalms 101:6 My eyes are upon the trustworthy of the land, for them to sit together with me, going in {way an unblemished}. This one officiated to me. 

#### Psalms 101:7 {dwelt not in the midst of my house one having pride}. One speaking unjust did not conduct anything before my eyes. 

#### Psalms 101:8 Into the morning I killed all the sinners of the land; to utterly destroy from out of the city of the LORD all the ones practicing lawlessness. 

#### Psalms 102:1 O LORD, listen to my prayer, and {my cry unto you let come}! 

#### Psalms 102:2 You should not turn your face from me in which ever day I should be afflicted. Lean to me your ear! in which ever day I should call upon you. Quickly heed me! 

#### Psalms 102:3 For {dissipated as smoke my days}, and my bones {as dried sticks are parched}. 

#### Psalms 102:4 {is struck down as grass and is dried up My heart}, so that I forgot to eat my bread. 

#### Psalms 102:5 From the sound of my moaning {cleaves my bone} to my flesh. 

#### Psalms 102:6 I became like {pelican a solitary}; I became as the long-eared owl in its area. 

#### Psalms 102:7 I was sleepless and I became as a sparrow living alone upon a roof. 

#### Psalms 102:8 All the day {berated me my enemies}, and the ones praising me {against me swore an oath}. 

#### Psalms 102:9 For {ashes as bread I ate}, and my drink {with weeping is being diluted}; 

#### Psalms 102:10 because of the face of your anger, and your rage; for having lifted me up you broke me down. 

#### Psalms 102:11 My days {as a shadow declined}, and I as grass am dried up. 

#### Psalms 102:12 But you, O LORD, {into the eon abide}, and your memorial unto generation and generation. 

#### Psalms 102:13 In your rising up you shall pity Zion, for it is time to pity it, for {comes the time}. 

#### Psalms 102:14 For {thought well of your servants} her stones, and {her dust shall pity}. 

#### Psalms 102:15 And {shall fear the nations} the name of the LORD, and all the kings of the earth your glory. 

#### Psalms 102:16 For the LORD shall build up Zion, and he shall appear in his glory. 

#### Psalms 102:17 He looked upon the prayer of the humble, and did not treat {with contempt their supplication}. 

#### Psalms 102:18 Let this be written for {generation another}! and the people being created shall praise the LORD. 

#### Psalms 102:19 For he looked out from the height of his holy place. The LORD {from heaven upon the earth looked}, 

#### Psalms 102:20 to hear the moaning of the ones being shackled, to untie the sons of the ones being killed, 

#### Psalms 102:21 to announce in Zion the name of the LORD, and his praise in Jerusalem, 

#### Psalms 102:22 in the assembling of peoples together, and kings to serve to the LORD. 

#### Psalms 102:23 It shall be answered by him in the way of his strength; {the fewness of my days he announced to me}. 

#### Psalms 102:24 You should not lead me away in half of my days; {are in generation of generations your years}. 

#### Psalms 102:25 At the beginning, you, O LORD, {for the earth laid a foundation}; and the works of your hands are the heavens. 

#### Psalms 102:26 They shall perish, but you shall abide. And all as a garment shall become old; and as a wrap-around garment you shall coil them, and they shall be changed. 

#### Psalms 102:27 But you {the same are}, and your years shall not cease. 

#### Psalms 102:28 The sons of your servants shall encamp, and their seed {into the eon shall conduct matters}. 

#### Psalms 103:1 Bless {O my soul the LORD}, and all the things within me, bless {name his holy}! 

#### Psalms 103:2 Bless {O my soul the LORD}, and forget not all his recompenses! 

#### Psalms 103:3 the one propitiating all your lawlessnesses; the one healing all your diseases; 

#### Psalms 103:4 the one ransoming {from out of corruption your life}; the one crowning you with mercy and compassions; 

#### Psalms 103:5 the one filling {with good things your desire}. {shall be renewed as an eagle Your youth}. 

#### Psalms 103:6 The one doing charity is the LORD, and judgment to all the ones having been wronged. 

#### Psalms 103:7 He made known his ways to Moses; to the sons of Israel his wants. 

#### Psalms 103:8 Pitying and merciful is the LORD; lenient and full of mercy. 

#### Psalms 103:9 Not unto the end shall he be provoked to anger, nor into the eon will he cherish wrath. 

#### Psalms 103:10 Not according to our lawless deeds did he deal with us; nor according to our sins did he recompense to us. 

#### Psalms 103:11 For as the height of the heaven from the earth, so the LORD fortified his mercy upon the ones fearing him. 

#### Psalms 103:12 According to as much as the distance eastwards from westwards, he set afar from us our lawlessnesses. 

#### Psalms 103:13 As {pities a father} his sons, so the LORD pities the ones fearing him. 

#### Psalms 103:14 For he knew our shape, he remembered that we are dust. 

#### Psalms 103:15 Man, as grass, so are his days; as a flower of the field, so he shall blossom. 

#### Psalms 103:16 For as wind goes by him, and it no longer exists, so also he shall not recognize {any longer his place}. 

#### Psalms 103:17 But the mercy of the LORD from the eon, and unto the eon, is upon the ones fearing him. And his righteousness is upon the sons of the sons; 

#### Psalms 103:18 to the ones guarding his covenant, and to the ones remembering his commandments to observe them. 

#### Psalms 103:19 The LORD {in the heaven prepared his throne}, and {his kingdom he is master of all}. 

#### Psalms 103:20 Bless the LORD all you his angels, mighty in strength, executing his word, to hearken to the sound of his words! 

#### Psalms 103:21 Bless the LORD, all you his forces! his ministers performing his will. 

#### Psalms 103:22 Bless the LORD, all you his works, in every place of his dominion! Bless {O my soul the LORD}! 

#### Psalms 104:1 Bless {O my soul the LORD}! O LORD my God, you are magnified exceedingly. {acknowledgment and majesty You clothed yourself with}; 

#### Psalms 104:2 cloaking on light as a garment; stretching out the heaven as a hide covering; 

#### Psalms 104:3 roofing {with waters his upper rooms}; placing clouds for his step; the one walking upon the wings of the winds; 

#### Psalms 104:4 the one making his angels winds, and his ministers {of fire a flame}; 

#### Psalms 104:5 the one laying the foundation for the earth in its stability (it shall not lean into the eon of the eon); 

#### Psalms 104:6 the deep as a garment of his wrap. Upon the mountains {shall stand waters}; 

#### Psalms 104:7 from your reproach they shall flee; from the sound of your thunder they shall show timidity. 

#### Psalms 104:8 They ascend the mountains, and go down to the plains, to a place where you laid a foundation for them. 

#### Psalms 104:9 {a limit You placed} which they shall not pass, nor shall they return to cover the earth. 

#### Psalms 104:10 The one sending out springs in ravines; {in the midst of the mountains shall go through waters}; 

#### Psalms 104:11 they shall water all the wild beasts of the field; {shall receive it wild donkeys} for their thirst; 

#### Psalms 104:12 by them the winged creatures of the heaven shall encamp; from between the rocks they shall give out a sound; 

#### Psalms 104:13 watering mountains from out of his upper rooms. By the fruit of your works {shall be filled the earth}. 

#### Psalms 104:14 The one causing {to rise up grass} to the cattle, and tender shoots to the service of the men, to bring bread from the earth; 

#### Psalms 104:15 and wine makes glad the heart of man; to make {happy his face} with olive oil; and bread {the heart of man supports}. 

#### Psalms 104:16 {shall be filled The woods of the plain} with the cedars of Lebanon which you planted. 

#### Psalms 104:17 There the sparrows will nest; {of the heron the dwelling} takes lead over them; 

#### Psalms 104:18 {mountains the high} for the stags; a rock of refuge for the hyrax. 

#### Psalms 104:19 He made the moon for seasons; the sun knows his setting. 

#### Psalms 104:20 You made darkness, and {happened night}; {in it go all the wild beasts of the forest}. 

#### Psalms 104:21 Lion cubs roaring to seize by force; and seeking from God food for themselves. 

#### Psalms 104:22 {arose The sun}, and they were brought together, and in their lairs they shall lay down. 

#### Psalms 104:23 {shall go forth Man} unto his work, even unto his work until evening. 

#### Psalms 104:24 How {were magnified your works}, O LORD; {all in wisdom you made}; {was filled the earth} of your creation; 

#### Psalms 104:25 this the {sea great} and broad space; located there are reptiles which there is no count; living creatures -- small with the great; 

#### Psalms 104:26 there boats travel over; this dragon whom you shaped to sport in it. 

#### Psalms 104:27 All {from you expect} to give them nourishment in an opportune time. 

#### Psalms 104:28 At your giving to them, they shall collect; opening your hand, all things shall be filled by that which is good. 

#### Psalms 104:29 But at the turning of your face they shall be disturbed; you shall take away in return their spirit, and they shall fail, and unto their dust they shall return. 

#### Psalms 104:30 You shall send out your spirit, and they shall be created; and you shall renew the face of the earth. 

#### Psalms 104:31 Let {be the glory of the LORD} into the eons! The LORD shall be glad over his works; 

#### Psalms 104:32 the one looking upon the earth, and making it to tremble; the one touching the mountains and they smoke. 

#### Psalms 104:33 I shall sing to the LORD in my life. I shall strum to my God while I exist. 

#### Psalms 104:34 Let {be delicious to him my versification}, and I shall be glad in the LORD. 

#### Psalms 104:35 {failed Sinners} from the earth, and lawless ones so as for {to not exist them}. Bless {O my soul the LORD}! 

#### Psalms 105:1 Make acknowledgment to the LORD, and call upon his name! Report among the nations of his works! 

#### Psalms 105:2 Sing to him, and strum to him! Describe all his wonders! 

#### Psalms 105:3 Applaud in {name his holy}! Let {be glad the heart seeking the LORD}! 

#### Psalms 105:4 Seek the LORD, and be fortified! Seek his face always! 

#### Psalms 105:5 You should remember his wonders of which he did; his miracles, and the judgments of his mouth; 

#### Psalms 105:6 seed of Abraham his servants; sons of Jacob his chosen. 

#### Psalms 105:7 He is the LORD our God; {are in all the earth his judgments}. 

#### Psalms 105:8 He remembered {into the eon his covenant}; the word which he gave charge for a thousand of generations; 

#### Psalms 105:9 which he ordained with Abraham, and his oath to Isaac. 

#### Psalms 105:10 And he established it to Jacob for an order, and to Israel for {covenant an eternal}, 

#### Psalms 105:11 saying, To you I give the land of Canaan, a piece of measured out land for your inheritance. 

#### Psalms 105:12 In their being {in number few}, very few, and sojourners in it; 

#### Psalms 105:13 that they went from nation to nation, and from a kingdom to {people another}. 

#### Psalms 105:14 He did not let a man wrong them; and he reproved {for them kings}, saying, 

#### Psalms 105:15 Do not touch my anointed ones! and among my prophets do not do wickedly! 

#### Psalms 105:16 And he called famine upon the land; {all reliance on bread he broke}. 

#### Psalms 105:17 He sent in front of them a man; {for a servant was sold Joseph}. 

#### Psalms 105:18 They humbled {with shackles his feet}; {iron went through his soul}; 

#### Psalms 105:19 until {came his word}; the oracle of the LORD purified him. 

#### Psalms 105:20 {sent The king} and untied him, even a ruler of the people, and let him go. 

#### Psalms 105:21 He placed him as master of his house, and ruler of all his possessions; 

#### Psalms 105:22 to instruct his rulers as he himself, and {his elders to make} wise. 

#### Psalms 105:23 And Israel entered into Egypt, and Jacob sojourned in the land of Ham. 

#### Psalms 105:24 And {grew his people} exceedingly; and he fortified it above his enemies. 

#### Psalms 105:25 He converted his heart to detest his people; to use deceit with his servants. 

#### Psalms 105:26 He sent out Moses his servant; Aaron whom he chose for himself. 

#### Psalms 105:27 He put among them the matters of his signs, and of his miracles in the land of Ham. 

#### Psalms 105:28 He sent out darkness, and it darkened; and they rebelled against his words. 

#### Psalms 105:29 He converted their waters into blood, and killed their fishes. 

#### Psalms 105:30 {crept forth in their land Frogs}; in the closets of their kings. 

#### Psalms 105:31 He spoke, and there came the dog-fly and midges in all their borders. 

#### Psalms 105:32 He made their rains into hail, and fire burning up in their land. 

#### Psalms 105:33 And he struck their grapevines, and their fig-trees; and he broke every tree of their border. 

#### Psalms 105:34 He spoke, and there came forth the locust and grasshopper, of which there was no number. 

#### Psalms 105:35 And they devoured all the grass in their land, and devoured the fruit of their land. 

#### Psalms 105:36 And he struck every first-born in their land, first-fruit of all their toil. 

#### Psalms 105:37 And he led them out with silver and gold; and there was not one among their tribes being weak. 

#### Psalms 105:38 Egypt was glad in their exodus; for {fell the fear of them} upon them. 

#### Psalms 105:39 He opened and spread out a cloud for their protection, and fire to give light to them at night. 

#### Psalms 105:40 They asked for, and {came the mother-quail}, and the bread of heaven filled them. 

#### Psalms 105:41 He tore open the rock, and {flowed the waters}; {went to waterless places rivers}. 

#### Psalms 105:42 For he remembered {word his holy} spoken to Abraham his servant. 

#### Psalms 105:43 And he led out his people in exultation, and his chosen ones in gladness. 

#### Psalms 105:44 And he gave to them the places of nations, and produce of the toils of the peoples that they inherited; 

#### Psalms 105:45 so that they should guard his ordinances, and {his law seek after}. 

#### Psalms 106:1 Make acknowledgment to the LORD, for he is gracious; for into the eon is his mercy. 

#### Psalms 106:2 Who shall speak the mighty deeds of the LORD? Audibly, who shall offer all his praises? 

#### Psalms 106:3 Blessed are the ones keeping equity, and doing righteousness in every season. 

#### Psalms 106:4 Remember us, O LORD, with the benevolence of your people! Visit us with your deliverance! 

#### Psalms 106:5 To behold in the thing gracious of your chosen ones; to be glad in the gladness of your nation; to applaud with your inheritance. 

#### Psalms 106:6 We sinned with our fathers; we acted lawlessly; we did wrong. 

#### Psalms 106:7 Our fathers in Egypt did not perceive your wonders, they remembered not the magnitude of your mercy; and they rebelled while ascending unto the red sea. 

#### Psalms 106:8 And he delivered them because of his name, to make known his might. 

#### Psalms 106:9 And he reproached the red sea, and it was dried up. And he guided them in the deep as in the wilderness. 

#### Psalms 106:10 And he delivered them out of the hand of the one detesting; and he ransomed them out of the hand of enemies. 

#### Psalms 106:11 {covered Water} the ones afflicting them; {one of them not} was left behind. 

#### Psalms 106:12 And they trusted in his word; and they were his praise. 

#### Psalms 106:13 They hastened; they forgot his works; they did not wait for his counsel. 

#### Psalms 106:14 And they desired with desire in the wilderness; and they tested God in a waterless place. 

#### Psalms 106:15 And he gave them their request; he sent fullness unto their souls. 

#### Psalms 106:16 And they provoked Moses to anger in the camp, and Aaron the holy one of the LORD. 

#### Psalms 106:17 {opened The earth} and swallowed down Dathan, and covered over upon the congregation of Abiram. 

#### Psalms 106:18 And {was kindled fire} in their congregation; a flame burnt up the sinners. 

#### Psalms 106:19 And they made a calf in Horeb, and they did obeisance to the carving. 

#### Psalms 106:20 And they changed their glory into a representation of a calf eating grass. 

#### Psalms 106:21 And they forgot the God, the one delivering them, the one doing great things in Egypt; 

#### Psalms 106:22 wonders in the land of Ham; fearful things at {sea the red}. 

#### Psalms 106:23 And he spoke to utterly destroy them, unless Moses his chosen one stood among the devastation before him, to turn his rage to not utterly destroy them. 

#### Psalms 106:24 And they treated {with contempt land the desirable}; they did not trust in his word. 

#### Psalms 106:25 And they grumbled in their tents; they did not listen to the voice of the LORD. 

#### Psalms 106:26 And he lifted up his hand against them, to throw them down into the wilderness; 

#### Psalms 106:27 and to throw down their seed into the nations, and to disperse them in the places. 

#### Psalms 106:28 And they were initiated to Baal-peor, and they ate a sacrifice of the dead. 

#### Psalms 106:29 And they provoked him in their practices; and {was multiplied among them the blow}. 

#### Psalms 106:30 And Phinehas stood and made atonement, and {was abated the devastation}. 

#### Psalms 106:31 And it was imputed to him for righteousness, for generation and generation, unto the eon. 

#### Psalms 106:32 And they provoked him to anger at Water of Dispute; and evil was inflicted upon Moses because of them; 

#### Psalms 106:33 for they greatly embittered his spirit, and he drew apart with his lips. 

#### Psalms 106:34 They did not utterly destroy the nations which the LORD told to them. 

#### Psalms 106:35 And they mixed among the nations, and learned their works. 

#### Psalms 106:36 And they served their carvings, and it became to them for a cause of offence. 

#### Psalms 106:37 And they sacrificed their sons and their daughters to the demons; 

#### Psalms 106:38 and they poured out {blood innocent} -- the blood of their sons and daughters whom they sacrificed to the carvings of Canaan. And {was polluted with murder the land} by their blood, 

#### Psalms 106:39 and it was defiled by their works. And they committed harlotry by their practices. 

#### Psalms 106:40 And {was provoked to anger in rage the LORD} against his people; and he abhorred his inheritance. 

#### Psalms 106:41 And he delivered them into the hands of enemies, and {dominated them the ones detesting them}. 

#### Psalms 106:42 And {afflicted them their enemies}, and they were humbled under their hands. 

#### Psalms 106:43 Many times he rescued them, but they greatly embittered him by their counsel, and they were humbled in their lawless deeds. 

#### Psalms 106:44 And the LORD beheld in their being afflicted while at the same time listening to their supplication. 

#### Psalms 106:45 And he remembered his covenant, and repented according to the magnitude of his mercy. 

#### Psalms 106:46 And he gave them over for compassions before all the ones having captured them. 

#### Psalms 106:47 Deliver us, O LORD our God, and assemble us from out of the nations! to acknowledge {name your holy}; to boast in your praise. 

#### Psalms 106:48 Blessed be the LORD God of Israel, from the eon and unto the eon. And {shall say all the people}, May it be. May it be. 

#### Psalms 107:1 Make acknowledgment to the LORD for he is gracious, for {is into the eon his mercy}! 

#### Psalms 107:2 Let {speak the ones having been ransomed by the LORD}! whom he ransomed from out of the hand of the enemy. 

#### Psalms 107:3 And from out of the places he gathered them; from the east, and west, and north, and the sea. 

#### Psalms 107:4 They wandered in the wilderness in a waterless way; {a city for a home they did not find}. 

#### Psalms 107:5 Hungering and thirsting, their soul {in them failed}. 

#### Psalms 107:6 And they cried out to the LORD in their being afflicted, and from their distresses he rescued them. 

#### Psalms 107:7 And he guided them in {way the straight}, to go into a city of habitation. 

#### Psalms 107:8 Let them make acknowledgment to the LORD of his mercies, and of his wonders to the sons of men! 

#### Psalms 107:9 For he fills {soul the empty}; and the soul hungering he filled up with good things; 

#### Psalms 107:10 even the ones sitting down in darkness and the shadow of death, being shackled in poorness and in iron; 

#### Psalms 107:11 for they rebelled against the oracles of God; and the counsel of the highest they provoked. 

#### Psalms 107:12 And {was humbled with troubles their heart}; they weakened and there was no one helping. 

#### Psalms 107:13 And they cried out to the LORD in their being afflicted; and from out of their distresses he delivered them. 

#### Psalms 107:14 And he led them from out of darkness and the shadow of death; and {their bonds he tore up}. 

#### Psalms 107:15 Let them make acknowledgment to the LORD of his mercies, and his wonders to the sons of men! 

#### Psalms 107:16 For he broke the gates of brass; and the bars of iron he fractured in pieces. 

#### Psalms 107:17 He took hold of them from out of the way of their lawlessnesses; for on account of their lawlessnesses they were humbled. 

#### Psalms 107:18 {every food abhorred Their soul}, and they approached unto the gates of death. 

#### Psalms 107:19 And they cried out to the LORD in their being afflicted; and {from out of their distresses he delivered them}. 

#### Psalms 107:20 He sent his word and healed them; and he rescued them from out of their corruptions. 

#### Psalms 107:21 Let them make acknowledgment to the LORD of his mercies, and his wonders to the sons of men! 

#### Psalms 107:22 And let them sacrifice to him a sacrifice of praise! And let them declare his works in exultation! 

#### Psalms 107:23 The men going down into the sea in boats, doing work in {waters many}; 

#### Psalms 107:24 these men beheld the works of the LORD, and his wonders in the deep. 

#### Psalms 107:25 He spoke, and {is established wind the gale}, and {are raised up high its waves}. 

#### Psalms 107:26 They ascend unto the heavens, and they go down unto the abysses; their soul {in evils melts away}. 

#### Psalms 107:27 They were disturbed; they were shaken as the one being intoxicated, and all their wisdom was swallowed down. 

#### Psalms 107:28 And they cry out to the LORD in their being afflicted; and {from out of their distresses he leads them}. 

#### Psalms 107:29 And he gave orders to the gale, and it stood as a breeze, and {were quiet its waves}. 

#### Psalms 107:30 And they were glad for they were stilled; and he guided them unto the harbor of their want. 

#### Psalms 107:31 Let them make acknowledgment to the LORD of his mercies, and his wonders to the sons of men! 

#### Psalms 107:32 Let them exalt him in the assembly of people, and {in the chair of the elders let them praise him}! 

#### Psalms 107:33 He put rivers into a wilderness, and outlets of waters into a thirsty ground; 

#### Psalms 107:34 a ground bearing fruit into brine, from the evils of the ones dwelling in it. 

#### Psalms 107:35 He made a wilderness into lakes of waters; and {ground a waterless} into outlets of waters. 

#### Psalms 107:36 And he settled there ones hungering, and they stood together cities of habitation. 

#### Psalms 107:37 And they sow fields, and plant vineyards, and they make fruit of produce. 

#### Psalms 107:38 And he blessed them, and they were multiplied exceedingly, and {their cattle he does not diminish}. 

#### Psalms 107:39 And they were made few and were maltreated by the affliction of evils and grief. 

#### Psalms 107:40 {was poured out Contempt} upon their rulers, and he wandered them in an untrodden place and no street. 

#### Psalms 107:41 But he helps the needy from out of poorness; and he made {as flocks families}. 

#### Psalms 107:42 {shall see The upright} and be glad; and all lawlessness shall obstruct its mouth. 

#### Psalms 107:43 Who is wise and will guard these things, and perceive the mercies of the LORD? 

#### Psalms 108:1 {is prepared My heart}, O God, {is prepared my heart}. I shall sing and strum in my glory. 

#### Psalms 108:2 Awake, O my glory! Awake, psaltery and harp! I will be awakened at dawn. 

#### Psalms 108:3 I will make acknowledgment to you among peoples, O LORD; I shall strum to you among nations. 

#### Psalms 108:4 For great above the heavens is your mercy; and unto the clouds is your truth. 

#### Psalms 108:5 Be raised up high above the heavens, O God, and above all the earth with your glory! 

#### Psalms 108:6 so that {should be rescued your beloved}. Deliver with your right hand, and heed me! 

#### Psalms 108:7 God spoke in his holy place. I shall be raised up high, and I shall divide Shechem into parts; and the valley of the tents I will measure out. 

#### Psalms 108:8 Mine is Gilead; and mine is Manasseh; and Ephraim is the assistance of my head; 

#### Psalms 108:9 Judah is my king; Moab the kettle of my hope; upon Edom I will put my sandal; {to me the Philistines are submitted}. 

#### Psalms 108:10 Who shall take me away into a city of a citadel? or who shall guide me to Edom? 

#### Psalms 108:11 Is it not you, O God, the one thrusting us away? And will you not go forth, O God, with our forces? 

#### Psalms 108:12 Give to us help from out of affliction, for {is vain deliverance of man}! 

#### Psalms 108:13 In God we shall execute power, and he shall treat {with contempt our enemies}. 

#### Psalms 109:1 O God of my praise, you should not remain silent; 

#### Psalms 109:2 for the mouth of the sinner, and the mouth of the deceitful one {against me opened}; they spoke against me {tongue with a deceitful}; 

#### Psalms 109:3 and with words of hatred they encircled me; and they waged war against me without charge. 

#### Psalms 109:4 Instead of the loving me, they slandered me; but I prayed. 

#### Psalms 109:5 And they placed against me bad things for good things; and hatred for my affection. 

#### Psalms 109:6 Place {against him the sinner}, and let the devil stand at his right hand! 

#### Psalms 109:7 In his being judged, may he go forth having been condemned; and {his prayer let} become as sin! 

#### Psalms 109:8 Let {become his days} few, and {his overseeing may take another}! 

#### Psalms 109:9 Let {become his sons} orphans, and his wife a widow! 

#### Psalms 109:10 In being shaken up, let {change residence his sons}, and let them beg! Let them be cast out from their areas! 

#### Psalms 109:11 Let {search out the money-lender} all as much as exists to him, and let {plunder strangers} his toils! 

#### Psalms 109:12 Let there not exist to him a shielder, nor let there be one pitying his orphans! 

#### Psalms 109:13 Let {be his children} given for devastation! In {generation one} let {be wiped away his name}! 

#### Psalms 109:14 May {be called to mind the lawlessness of his fathers} before the LORD; and {the sin of his mother not may} be wiped away. 

#### Psalms 109:15 Let them be before the LORD always! and may {be utterly destroyed from the land their memorial}. 

#### Psalms 109:16 Because he did not remember to perform mercy, but pursued {man a needy and poor}, and vexing the heart to kill him. 

#### Psalms 109:17 And he loved a curse, and it shall come to him; and he did not want a blessing, and it shall be far from him. 

#### Psalms 109:18 And he put on the curse as a cloak, and it entered as water into his insides, and as oil in his bones. 

#### Psalms 109:19 Let it be to him as a cloak which he puts around, and as a belt which he always girds himself! 

#### Psalms 109:20 This is the work of the ones slandering me by the LORD, and the ones speaking evil against my soul. 

#### Psalms 109:21 And you, O LORD, O Lord, deal with me because of your name, for {is gracious your mercy}! 

#### Psalms 109:22 Rescue me, for {poor and needy I am}! and my heart is disturbed within me. 

#### Psalms 109:23 As shade in its turning aside, I was taken away in return; I was shaken away as locusts. 

#### Psalms 109:24 My knees weakened from fasting, and my flesh was changed through want of oil. 

#### Psalms 109:25 And I became scorn to them; they beheld me; they shook their heads. 

#### Psalms 109:26 Help me, O LORD my God, and deliver me according to your mercy! 

#### Psalms 109:27 And let them know that {your hand this is}! and you, O LORD, did it. 

#### Psalms 109:28 They shall curse themselves, but you shall bless. The ones rising up against me, let them be ashamed! but your servant shall be glad. 

#### Psalms 109:29 Let {put on the ones slandering me} shame, and let them put {around as a garment their shame}! 

#### Psalms 109:30 I will make acknowledgment to the LORD -- exceedingly. With my mouth and in the midst of many I will praise him. 

#### Psalms 109:31 For he stands at the right hand of the needy, to deliver from the ones pursuing my soul. 

#### Psalms 110:1 {said The LORD} to my Lord, Sit down at my right hand until whenever I should make your enemies a footstool for your feet. 

#### Psalms 110:2 {a rod of power shall send out to you The LORD} from out of Zion; and you dominate in the midst of your enemies! 

#### Psalms 110:3 With you is the sovereignty in the day of your power, with the brightness of your holy ones. From out of the womb before the morning star I engendered you. 

#### Psalms 110:4 The LORD swore by an oath, and shall not repent, saying, You are a priest unto the eon according to the order of Melchisedek. 

#### Psalms 110:5 The LORD at your right hand fractured {in pieces in the day of his anger kings}. 

#### Psalms 110:6 He shall judge among the nations; he shall fill up with corpses; he shall fracture in pieces heads upon the earth -- many. 

#### Psalms 110:7 {from out of the rushing stream in the way He shall drink}; on account of this he shall raise up high a head. 

#### Psalms 111:1 I shall make acknowledgment to you, O LORD, with {entire heart my}, in the counsel of the upright, and in the congregation. 

#### Psalms 111:2 Great are the works of the LORD, being inquired for all his wants. 

#### Psalms 111:3 {is acknowledgeable and with majesty His work}; and his righteousness abides into the eon of the eon. 

#### Psalms 111:4 {a memorial He made} for his wonders; merciful and pitying is the LORD. 

#### Psalms 111:5 A nourishment he gave to the ones fearing him; {shall be remembered into the eon his covenant}. 

#### Psalms 111:6 The strength of his works he announced to his people; to give to them the inheritance of nations. 

#### Psalms 111:7 The works of his hands are truth and equity; trustworthy are all his commandments; 

#### Psalms 111:8 fixed into the eon of the eon; done in truth and uprightness. 

#### Psalms 111:9 {a ransoming He sent} to his people; he gave charge into the eon concerning his covenant; holy and fearful is his name. 

#### Psalms 111:10 The beginning of wisdom is fear of the LORD; {understanding and good} to all the ones observing it. The praise of him abides into the eon of the eon. 

#### Psalms 112:1 Happy the man fearing the LORD; in his commandments he will want exceedingly. 

#### Psalms 112:2 {mighty in the earth will be His seed}; a generation of the upright shall be blessed. 

#### Psalms 112:3 Glory and riches in his house; and his righteousness abides into the eon of the eon. 

#### Psalms 112:4 He caused to rise up in darkness a light to the upright; he is merciful and pitying and just. 

#### Psalms 112:5 A gracious man is the one pitying and lending; he shall manage his matters in equity. 

#### Psalms 112:6 For into the eon he shall not be shaken; {for memorial an eternal will be the just}. 

#### Psalms 112:7 From hearing a wicked report he shall not be afraid; {is prepared his heart} to hope upon the LORD. 

#### Psalms 112:8 {is fixed firmly His heart}; in no way should he be fearful, until of which time he should see his desires upon his enemies. 

#### Psalms 112:9 He dispersed; he gave to the needy; his righteousness abides into the eon of the eon; his horn shall be raised up high in glory. 

#### Psalms 112:10 A sinner shall see and shall be provoked to anger; {his teeth he shall gnash} and melt away; the desire of the sinner shall perish. 

#### Psalms 113:1 Praise, O servants, the LORD! Praise the name of the LORD! 

#### Psalms 113:2 May {be the name of the LORD} for blessing from the present and unto the eon. 

#### Psalms 113:3 From the dawn of the sun until the descent -- praiseworthy is the name of the LORD. 

#### Psalms 113:4 High above all the nations is the LORD; upon the heavens is his glory. 

#### Psalms 113:5 Who is as the LORD our God? the one {in high places dwelling}, 

#### Psalms 113:6 and {the humble inspecting} in the heaven, and in the earth. 

#### Psalms 113:7 The one raising {from the earth the poor}, and {from the dung elevating the needy}; 

#### Psalms 113:8 to set him with rulers, with rulers of his people. 

#### Psalms 113:9 The one who settles the sterile woman in a house as a mother {with children being glad}. 

#### Psalms 114:1 In the exodus of Israel from Egypt, of the house of Jacob, from {people a barbaric}, 

#### Psalms 114:2 Judea became his sanctuary, and Israel his authority. 

#### Psalms 114:3 The sea beheld and fled; the Jordan turned to the rear; 

#### Psalms 114:4 the mountains leaped as rams, and the hills as little lambs of sheep. 

#### Psalms 114:5 What is it with you, O sea, that you fled? and you, O Jordan, that you turned to the rear? 

#### Psalms 114:6 {the mountains for} leaped as rams, and the hills as little lambs of sheep. 

#### Psalms 114:7 From the presence of the LORD {was shaken the earth}; from the presence of the God of Jacob; 

#### Psalms 114:8 of the one turning the rock into lakes of waters, and the chiseled stone into springs of waters. 

#### Psalms 115:1 Not to us, O LORD, not to us, but only to your name give glory, because of your mercy and your truth! 

#### Psalms 115:2 lest at any time {should say the nations}, Where is their God? 

#### Psalms 115:3 But our God in the heaven and in the earth {all as much as he wants does}. 

#### Psalms 115:4 The idols of the nations are silver and gold -- works of the hands of men. 

#### Psalms 115:5 {a mouth They have}, but they shall not speak; {eyes they have}, but they shall not see; 

#### Psalms 115:6 {ears they have}, but they shall not hear; {noses they have}, but they shall not smell; 

#### Psalms 115:7 {hands they have}, but they shall not handle; {feet they have}, but they shall not walk; they shall not speak out loud through their throat. 

#### Psalms 115:8 {likened to them Let become the ones making them}! and all the ones yielding upon them. 

#### Psalms 115:9 The house of Israel hopes upon the LORD; {helper and defender he is their}. 

#### Psalms 115:10 The house of Aaron hopes upon the LORD; {helper and defender he is their}. 

#### Psalms 115:11 The ones fearing the LORD hoped upon the LORD; {helper and defender he is their}. 

#### Psalms 115:12 The LORD was remembering us; he blessed us; he blessed the house of Israel; he blessed the house of Aaron; 

#### Psalms 115:13 he blessed the ones fearing the LORD, the small with the great. 

#### Psalms 115:14 May the LORD add unto you; unto you and unto your sons. 

#### Psalms 115:15 You are being blessed by the LORD, the one making the heaven and the earth. 

#### Psalms 115:16 The heaven of the heaven belongs to the LORD; but the earth he gave to the sons of men. 

#### Psalms 115:17 {not The dead shall} praise you, O LORD, nor all the ones going down into Hades. 

#### Psalms 115:18 But we the living, we shall bless the LORD from the present and unto the eon. 

#### Psalms 116:1 I loved that {shall listen to the LORD} the voice of my supplication. 

#### Psalms 116:2 For he leaned his ear to me; and during my days I shall call upon him. 

#### Psalms 116:3 {compassed me The pangs of death}; the dangers of Hades found me; {affliction and grief I found}. 

#### Psalms 116:4 And the name of the LORD I called upon. O LORD rescue my soul! 

#### Psalms 116:5 {is merciful The LORD} and just; and our God shows mercy. 

#### Psalms 116:6 {is the one guarding the infants The LORD}. I was humbled, and he delivered me. 

#### Psalms 116:7 Return, O my soul, to your rest! for the LORD benefited you. 

#### Psalms 116:8 For he rescued my soul from out of death; my eyes from tears, and my feet from a slip. 

#### Psalms 116:9 I should be well-pleasing before the LORD in the place of the living. 

#### Psalms 116:10 I trusted, therefore I spoke; but I was humbled exceedingly. 

#### Psalms 116:11 And I said in my change of state, Every man is a liar. 

#### Psalms 116:12 What shall I recompense to the LORD for all which he recompensed to me? 

#### Psalms 116:13 The cup of deliverance I shall take; and the name of the LORD I shall call upon. 

#### Psalms 116:14 My vows to the LORD I will render before all his people. 

#### Psalms 116:15 Esteemed before the LORD is the death of his sacred ones. 

#### Psalms 116:16 O LORD I am {servant your}; I am {servant your}, and a son of your maidservant. You tore up my bonds. 

#### Psalms 116:17 To you I shall sacrifice a sacrifice of praise, and {in the name of the LORD I will call}. 

#### Psalms 116:18 {my vows to the LORD I will render} before all his people, 

#### Psalms 116:19 in the courtyards of the house of the LORD, in the midst of you, Jerusalem. 

#### Psalms 117:1 Praise the LORD all nations! Applaud him all peoples! 

#### Psalms 117:2 For {is strengthened his mercy} upon us, and the truth of the LORD abides into the eon. 

#### Psalms 118:1 Make acknowledgment to the LORD, for he is good, for into the eon is his mercy! 

#### Psalms 118:2 Say indeed, O house of Israel, that he is good, for into the eon is his mercy! 

#### Psalms 118:3 Say indeed, O house of Aaron, that he is good, for into the eon is his mercy! 

#### Psalms 118:4 Say indeed, all the ones fearing the LORD, that he is good, for into the eon is his mercy! 

#### Psalms 118:5 From out of affliction I called upon the LORD, and he heeded me in an enlargement. 

#### Psalms 118:6 The LORD to me is a helper; and I shall not fear what {shall do to me man}. 

#### Psalms 118:7 The LORD to me is a helper, and I will scrutinize my enemies. 

#### Psalms 118:8 It is good to yield unto the LORD, than to yield unto man. 

#### Psalms 118:9 It is good to hope upon the LORD, than to hope upon rulers. 

#### Psalms 118:10 All the nations encircled me, and in the name of the LORD I repulsed them. 

#### Psalms 118:11 In encircling, they encircled me; and in the name of the LORD I repulsed them. 

#### Psalms 118:12 They encircled me as bees at a honeycomb; and they burned away as fire among thorn-bushes; and in the name of the LORD I repulsed them. 

#### Psalms 118:13 Being thrust through, I was prostrated to fall, and the LORD took hold of me. 

#### Psalms 118:14 {is my strength and my singing of praise The LORD}; and he became to me for deliverance; 

#### Psalms 118:15 a voice of exultation and deliverance in the tents of the just. The right hand of the LORD acted in power. 

#### Psalms 118:16 The right hand of the LORD exalted me. The right hand of the LORD acted in power. 

#### Psalms 118:17 I shall not die, but I shall live; and I shall describe the works of the LORD. 

#### Psalms 118:18 In correcting, {corrected me the LORD}; and {to death he shall not deliver me}. 

#### Psalms 118:19 Open to me the gates of righteousness, and entering in them I shall confess to the LORD. 

#### Psalms 118:20 This is the gate of the LORD; the just shall enter in it. 

#### Psalms 118:21 I shall confess to you, for you took heed of me, and you became for me as deliverance. 

#### Psalms 118:22 The stone which {rejected the builders}, this one became for the head of the corner. 

#### Psalms 118:23 {by the LORD This happened}, and it is wonderful in our eyes. 

#### Psalms 118:24 This is the day which {made the LORD}, we shall exult and be glad in it. 

#### Psalms 118:25 O LORD, deliver indeed! O LORD, prosper the way indeed! 

#### Psalms 118:26 Being blessed is the one coming in the name of the LORD. We blessed you from out of the house of the LORD. 

#### Psalms 118:27 God is the LORD, and he shined upon us. Stand together for a holiday with the ones making dense the victims unto the horns of the altar. 

#### Psalms 118:28 {my God You are}, and I shall confess to you. {my God You are}, and I will exalt you. I will confess to you, for you took heed of me; and you became to me for deliverance. 

#### Psalms 118:29 I will confess to the LORD, for he is good, for into the eon is his mercy. 

#### Psalms 119:1 Blessed are the unblemished in the way; the ones going by the law of the LORD. 

#### Psalms 119:2 Blessed are the ones searching out his testimonies; with the entire heart they shall seek after him. 

#### Psalms 119:3 {not For the ones practicing lawlessness in his ways were gone}. 

#### Psalms 119:4 You gave charge {your commandments to keep} exceedingly. 

#### Psalms 119:5 Ought that {be straightened out my ways} to keep your ordinances; 

#### Psalms 119:6 then in no way should I be ashamed in my paying attention concerning all of your commandments. 

#### Psalms 119:7 I shall confess to you in uprightness of heart in my learning the judgments of your righteousness. 

#### Psalms 119:8 Your ordinances I will keep. You should not abandon me unto an exceeding amount. 

#### Psalms 119:9 How shall {keep straight a younger man} his way? by the keeping of your words. 

#### Psalms 119:10 With {whole heart my} I inquired of you; you should not thrust me from your commandments. 

#### Psalms 119:11 In my heart I hid your oracles, so that I should not sin against you. 

#### Psalms 119:12 Blessed are you, O LORD. Teach me your ordinances! 

#### Psalms 119:13 With my lips I will declare all the judgments of your mouth. 

#### Psalms 119:14 {in the way of your testimonies I delighted} as above all riches. 

#### Psalms 119:15 In your commandments I shall meditate; and I shall contemplate your ways. 

#### Psalms 119:16 {in your ordinances I shall meditate}; I shall not forget your words. 

#### Psalms 119:17 Recompense to your servant! Enliven me! and I will keep your words 

#### Psalms 119:18 Uncover my eyes! and I shall contemplate the wonders of your law. 

#### Psalms 119:19 {a sojourner I am} in the earth; you should not conceal from me your commandments. 

#### Psalms 119:20 {longed My soul} to desire your judgments at every occasion. 

#### Psalms 119:21 You reproached the proud; accursed are the ones turning aside from your commandments. 

#### Psalms 119:22 Remove from me scorn and contempt! for {of your testimonies I inquired}. 

#### Psalms 119:23 For even {sat rulers} and {against me spoke ill}; but your servant meditated in your ordinances. 

#### Psalms 119:24 For even your testimonies {my meditation are}; and {are my advice your ordinances}. 

#### Psalms 119:25 {cleaved to the floor My soul}; let me live according to your word! 

#### Psalms 119:26 My ways I declared, and you heeded me. Teach me your ordinances! 

#### Psalms 119:27 {in the way of your ordinances Bring understanding to me}! and I will meditate in your wonders. 

#### Psalms 119:28 {slumbered My soul} from indifference. Firm me in your words! 

#### Psalms 119:29 {the way of injustice Remove} from me, and {by your law show mercy to me}! 

#### Psalms 119:30 The way of truth I took up, and your judgments I did not forget. 

#### Psalms 119:31 I cleaved to your testimonies, O LORD; you should not put me to shame. 

#### Psalms 119:32 {the way of your commandments I ran}, whenever you widened my heart. 

#### Psalms 119:33 Establish for me, O LORD, the way of your ordinances! and I will seek after them always. 

#### Psalms 119:34 Bring understanding to me! and I will search out your law, and I will guard it with {whole heart my}. 

#### Psalms 119:35 Guide me in the road of your commandments! for I wanted it. 

#### Psalms 119:36 Lean my heart unto your testimonies, and not unto the desire for wealth! 

#### Psalms 119:37 Turn my eyes to not behold folly! {in your way Enliven me}! 

#### Psalms 119:38 Establish to your servant your oracle, so as to fear you! 

#### Psalms 119:39 Remove my scorn! which I dreaded, for your judgments are gracious. 

#### Psalms 119:40 Behold, I desired your commandments; {in your righteousness enliven me}! 

#### Psalms 119:41 And may {come upon me your mercy}, O LORD; even your deliverance according to your word. 

#### Psalms 119:42 Then I shall answer to the ones berating against me in a matter, for I hoped upon your words. 

#### Psalms 119:43 For you should not remove from out of my mouth the word of truth unto an exceeding amount; for upon your judgments I raised hope. 

#### Psalms 119:44 And I shall guard your law always, into the eon, and into the eon of the eon. 

#### Psalms 119:45 For I went into an enlargement; for {your commandments I sought after}. 

#### Psalms 119:46 And I spoke by your testimonies before kings, and I was not ashamed. 

#### Psalms 119:47 And I meditated in your commandments which I loved very much. 

#### Psalms 119:48 And I lifted my hands to your commandments which I loved; and I meditated in your ordinances. 

#### Psalms 119:49 Remember your words to your servant! which you raised my hope. 

#### Psalms 119:50 This comforted me in my humiliation; for your oracle enlivened me. 

#### Psalms 119:51 The proud acted unlawfully unto exceedingly; but from your law I did not turn aside. 

#### Psalms 119:52 I remembered your judgments of the eon, O LORD, and I was comforted. 

#### Psalms 119:53 Depression held me down because of the sinners -- the ones abandoning your law. 

#### Psalms 119:54 {as strummed chords of music were to me Your ordinances} in the place of my sojourn. 

#### Psalms 119:55 I remembered {in the night your name}, O LORD, and I kept your law. 

#### Psalms 119:56 This happened to me, for {your ordinances I sought after}. 

#### Psalms 119:57 {my portion You are}, O LORD. I spoke concerning guarding your law. 

#### Psalms 119:58 I beseeched your face with {entire heart my}. Show mercy on me according to your oracle! 

#### Psalms 119:59 I argued your ways, and I turned my feet to your testimonies. 

#### Psalms 119:60 I prepared myself, and was not disturbed to keep your commandments. 

#### Psalms 119:61 The rough cords of sinners twist me, but your law I did not forget. 

#### Psalms 119:62 At midnight I awoke to confess to you over the judgments of your righteousness. 

#### Psalms 119:63 {a partner I am} of all of the ones fearing you, and of the ones keeping your commandments. 

#### Psalms 119:64 Of your mercy, O LORD, {is full the earth}; {your ordinances teach me}! 

#### Psalms 119:65 That which is good you did with your servant, O LORD, according to your word. 

#### Psalms 119:66 That which is good, and instruction, and knowledge, teach me! for {your commandments I trusted}! 

#### Psalms 119:67 Before my being humbled, I committed trespasses; on account of this {your oracle I guarded}. 

#### Psalms 119:68 {gracious You are}, O LORD; and in your graciousness teach me your ordinances! 

#### Psalms 119:69 {was multiplied against me The injustice of the proud}; but I {with whole heart my shall search out your commandments}. 

#### Psalms 119:70 {was curdled as milk Their heart}; but I {your law meditated upon}. 

#### Psalms 119:71 It is good for me that you humbled me, so that I should learn your ordinances. 

#### Psalms 119:72 {is good to me The law of your mouth}, above a thousand pieces of gold and silver. 

#### Psalms 119:73 Your hands made me, and shaped me. Bring understanding to me! and I shall learn your commandments. 

#### Psalms 119:74 The ones fearing you shall see me and shall be glad; for in your words I raised hope. 

#### Psalms 119:75 I knew, O LORD, that {are righteousness your judgments}, and in truth you humbled me. 

#### Psalms 119:76 Let {be indeed your mercy} to comfort me according to your oracle to your servant! 

#### Psalms 119:77 Let {come to me your compassions}! and I shall live; for your law {meditation is my}. 

#### Psalms 119:78 Let {be shamed the proud}! for unjustly they acted lawlessly against me. But I shall meditate in your commandments. 

#### Psalms 119:79 Turn towards me the ones fearing you, and the ones knowing your testimonies! 

#### Psalms 119:80 Let {become my heart} unblemished in your ordinances! so that I should not be shamed. 

#### Psalms 119:81 {is wanting for your deliverance My soul}. In your words I raised hope. 

#### Psalms 119:82 {failed My eyes} for your oracle, saying, When will you comfort me? 

#### Psalms 119:83 For I became as a leather bag in frost; your ordinances I forgot not. 

#### Psalms 119:84 How many are the days of your servant? When will you execute for me {against the ones pursuing me a judgment}? 

#### Psalms 119:85 {described against me Lawbreakers a meditation}, but not according to your law, O LORD. 

#### Psalms 119:86 All your commandments are truth. {unjustly They pursued me}; help me! 

#### Psalms 119:87 In a short time they would have finished me off entirely in the earth, but I did not abandon your commandments. 

#### Psalms 119:88 According to your mercy enliven me! and I shall guard the testimonies of your mouth. 

#### Psalms 119:89 Into the eon, O LORD, your word abides in the heaven. 

#### Psalms 119:90 Unto generation and generation is your truth. You laid {foundation the earth's}, and it abides. 

#### Psalms 119:91 {by your disposition abides The day}; for all things {subservient are your}. 

#### Psalms 119:92 Were it not that your law {my meditation is}, then would I have been destroyed in my humiliation. 

#### Psalms 119:93 {into the eon In no way should I forget your ordinances}; for by them you enlivened me. 

#### Psalms 119:94 {yours I am}, deliver me! for {your ordinances I sought after}. 

#### Psalms 119:95 {for me remained behind Sinners}, to destroy me; {your testimonies I perceived}. 

#### Psalms 119:96 {of every completion I beheld the end}; {spacious your commandment is exceedingly}. 

#### Psalms 119:97 How I loved your law, O LORD; the entire day {meditation it is my}. 

#### Psalms 119:98 Above my enemies you made me wiser by your commandment; for into the eon it is to me. 

#### Psalms 119:99 Above all the ones teaching me I perceived; for your testimonies {my meditation are}. 

#### Psalms 119:100 Above the elders I perceived; for {your commandments I sought after}. 

#### Psalms 119:101 From out of every {way evil} I restrained my feet, so that I shall guard your words. 

#### Psalms 119:102 From your judgments I did not turn aside; for you established law for me. 

#### Psalms 119:103 How sweet to my throat are your oracles; more than honey in my mouth. 

#### Psalms 119:104 By your commandments I perceived; on account of this I detested every way of injustice. 

#### Psalms 119:105 {is a lamp unto my feet Your law} and a light to my paths. 

#### Psalms 119:106 I swore by an oath, and stood to guard the judgments of your righteousness. 

#### Psalms 119:107 I was humbled unto exceedingly, O LORD; enliven me according to your word! 

#### Psalms 119:108 {the voluntary offerings of my mouth Take pleasure indeed in}, O LORD, and {your judgments teach me}! 

#### Psalms 119:109 My soul is in your hands always; and your law I forgot not. 

#### Psalms 119:110 {put Sinners} a snare for me; but from your commandments I wandered not. 

#### Psalms 119:111 I inherited your testimonies into the eon; for {a leap for joy to my heart they are}. 

#### Psalms 119:112 I leaned my heart to observe your ordinances into the eon in remuneration. 

#### Psalms 119:113 Lawbreakers I detested, but your law I loved. 

#### Psalms 119:114 {my helper and my shielder You are}; by your words I raised hope. 

#### Psalms 119:115 Turn aside from me O ones acting wicked! for I shall search out the commandments of my God. 

#### Psalms 119:116 Take hold of me according to your oracle; and enliven me! for you should not put me to shame of my expectation. 

#### Psalms 119:117 Help me, and I shall be delivered! and I will meditate in your ordinances always. 

#### Psalms 119:118 {treated me with contempt All the ones defecting from your ordinances}; for {is unjust their thought}. 

#### Psalms 119:119 {as ones violating the law I considered All the sinners of the earth}; on account of this I loved your testimonies. 

#### Psalms 119:120 Nail up {because of the fear of you my flesh}! for because of your judgments I feared. 

#### Psalms 119:121 I executed judgment and righteousness; you should not deliver me to the ones wronging me. 

#### Psalms 119:122 Look out for your servant for good; let not {extort me the proud}! 

#### Psalms 119:123 My eyes are wanting for your deliverance, and for the oracle of your righteousness. 

#### Psalms 119:124 Do with your servant according to your mercy, and {your ordinances teach me}! 

#### Psalms 119:125 {your servant I am}; bring understanding to me! and I will make known your testimonies. 

#### Psalms 119:126 It is time {to act for the LORD}; they effaced your law. 

#### Psalms 119:127 On account of this I loved your commandments above gold and topaz. 

#### Psalms 119:128 On account of this {to all of your commandments I kept straight}; every way of the unjust I detested. 

#### Psalms 119:129 {are wonderful Your testimonies}; on account of this {searches them out my soul}. 

#### Psalms 119:130 The manifestation of your words shall give light, and bring understanding to simple ones. 

#### Psalms 119:131 {my mouth I opened} and drew breath; for your commandments I longed after. 

#### Psalms 119:132 Look upon me, and show mercy on me! according to the practice of the ones loving your name. 

#### Psalms 119:133 {my footsteps Straighten out} according to your oracle! and let there not dominate me any lawlessness! 

#### Psalms 119:134 Ransom me from the extortion of men! and I will keep your commandments. 

#### Psalms 119:135 {your face Let} appear unto your servant, and teach me your ordinances! 

#### Psalms 119:136 Streams of waters flowed down my eyes when I kept not your law. 

#### Psalms 119:137 You are just, O LORD, and {are straight your judgments}. 

#### Psalms 119:138 You gave charge for righteousness of your testimonies and truth -- exceedingly. 

#### Psalms 119:139 {wasted me away The zeal of you}, for {forgot your words my enemies}. 

#### Psalms 119:140 {setting on fire Your oracle is an exceeding}; and your servant loves it. 

#### Psalms 119:141 {younger I am}, and being treated with contempt; {your ordinances I did not forget}. 

#### Psalms 119:142 Your righteousness is righteousness into the eon, and your law is truth. 

#### Psalms 119:143 Afflictions and distresses found me; your commandments are my meditation. 

#### Psalms 119:144 {are righteousness Your testimonies} into the eon. Bring understanding to me! and I shall live. 

#### Psalms 119:145 I cried out with {whole heart my}. Heed me, O LORD! {your ordinances I will seek after}. 

#### Psalms 119:146 I cried out to you; deliver me! and I will keep your testimonies. 

#### Psalms 119:147 I anticipated at midnight, and I cried out; in your words I raised hope. 

#### Psalms 119:148 {anticipated My eyes} before dawn to meditate upon your oracles. 

#### Psalms 119:149 {voice Hear my}, O LORD, according to your mercy! {according to your judgment Enliven me}! 

#### Psalms 119:150 {draw near The ones pursuing me lawlessly}, {from and your law they are far}. 

#### Psalms 119:151 You are near, O LORD, and all your ways are truth. 

#### Psalms 119:152 From ancient times I knew of your testimonies, that into the eon you founded them. 

#### Psalms 119:153 Behold my humiliation, and rescue me! for {your law I did not forget}. 

#### Psalms 119:154 Judge my case, and ransom me! On account of your word enliven me! 

#### Psalms 119:155 {is far from sinners Deliverance}, for {your ordinances they did not seek after}. 

#### Psalms 119:156 Your compassions are many, O LORD; according to your judgment enliven me! 

#### Psalms 119:157 Many are the ones driving me out and afflicting me; from your testimonies I did not turn aside. 

#### Psalms 119:158 I beheld ones lacking sense and wasting away, for {your oracles they kept not}. 

#### Psalms 119:159 Behold! for {your commandments I loved}, O LORD; in your mercy enliven me! 

#### Psalms 119:160 The beginning of your words is truth; and into the eon are all the judgments of your righteousness. 

#### Psalms 119:161 Rulers pursued me without charge; and from your words {was timid my heart}. 

#### Psalms 119:162 I shall exult over your oracles, as one finding {spoils many}. 

#### Psalms 119:163 Injustice I detested and abhorred; but your law I loved. 

#### Psalms 119:164 Seven times a day I praised you over the judgments of your righteousness. 

#### Psalms 119:165 {peace Great} is to the ones loving your law, and there is no obstacle to them. 

#### Psalms 119:166 I expected your deliverance, O LORD, and {your commandments loved}. 

#### Psalms 119:167 {guarded My soul} your testimonies, and it loved them very much. 

#### Psalms 119:168 I kept your commandments and your testimonies, for all my ways are before you, O LORD. 

#### Psalms 119:169 Let {approach my supplication} before you, O LORD! according to your oracle bring understanding to me! 

#### Psalms 119:170 May {enter that which is fit of me} before you, O LORD; according to your oracle rescue me! 

#### Psalms 119:171 {discharged forth My lips} a hymn, whenever you should teach me your ordinances. 

#### Psalms 119:172 May {utter the sound my tongue} of your oracles, for all your commandments are righteousness. 

#### Psalms 119:173 Let {be your hand} to deliver me! for {your commandments I took up}. 

#### Psalms 119:174 I longed after your deliverance, O LORD, and your law {my meditation is}. 

#### Psalms 119:175 {shall live My soul}, and it shall praise you; and your judgments shall help me. 

#### Psalms 119:176 I wandered as a sheep perishing. Seek your servant! for your commandments I did not forget. 

#### Psalms 120:1 {to the LORD in my being afflicted I cried out}, and he listened to me. 

#### Psalms 120:2 O LORD, rescue my soul from {lips unjust}, and from {tongue a deceitful}! 

#### Psalms 120:3 What may be given to you, and what added to you, to {tongue the deceitful}? 

#### Psalms 120:4 The arrows of the mighty are being sharpened with the {coals solitary}. 

#### Psalms 120:5 Alas, for my sojourn was far; I encamped with the tents of Kedar. 

#### Psalms 120:6 {much sojourned My soul} with the ones detesting peace. 

#### Psalms 120:7 I was peaceable whenever I was speaking to them; they waged war against me without charge. 

#### Psalms 121:1 I lifted my eyes unto the mountains, from where {shall come my help}. 

#### Psalms 121:2 My help is from the LORD; of the one making the heaven and the earth. 

#### Psalms 121:3 May he not give {to tossing about your foot}, nor should {slumber the one guarding you}. 

#### Psalms 121:4 Behold, {shall not slumber nor sleep the one guarding Israel}. 

#### Psalms 121:5 The LORD shall guard you. The LORD is protection to you at {hand your right}. 

#### Psalms 121:6 By day the sun shall not burn you, nor the moon by night. 

#### Psalms 121:7 The LORD shall guard you from all evil; {shall guard your soul the LORD}. 

#### Psalms 121:8 The LORD shall guard your entrance and your exit, from the present and unto the eon. 

#### Psalms 122:1 I shall be glad over the ones saying to me, {into the house of the LORD We shall go}. 

#### Psalms 122:2 {were standing Our feet} in your courtyards, O Jerusalem. 

#### Psalms 122:3 Jerusalem being built as a city of which the sharing of it is together. 

#### Psalms 122:4 For there {ascend the tribes}, tribes of the LORD, for a testimony of Israel, to confess to the name of the LORD. 

#### Psalms 122:5 For there {sit thrones} in judgment; thrones for the house of David. 

#### Psalms 122:6 Ask indeed the things for peace to Jerusalem, and prosperity to the ones loving you! 

#### Psalms 122:7 Let there be peace with your force, and prosperity in your towered fortifications! 

#### Psalms 122:8 Because of my brethren and my neighbors I spoke indeed peace concerning you. 

#### Psalms 122:9 Because of the house of the LORD our God, I sought good for you. 

#### Psalms 123:1 To you I lifted my eyes, O one dwelling in the heaven. 

#### Psalms 123:2 Behold, as eyes of servants are to the hands of their masters; as the eyes of the maidservant to the hands of her lady; so our eyes are to the LORD our God, until of which time he should pity us. 

#### Psalms 123:3 Show mercy on us, O LORD, show mercy on us! for unto greatly we filled of contempt. 

#### Psalms 123:4 {more greatly was filled Our soul}; let scorn be against they that prosper; and contempt against the proud. 

#### Psalms 124:1 Unless it be that the LORD was with us -- let {say now Israel}! 

#### Psalms 124:2 Unless it was that the LORD was with us in the rising up of men against us, 

#### Psalms 124:3 then would the ones living have swallowed us in the provoking to anger of his rage against us. 

#### Psalms 124:4 Then would the water have sunk us; {the rushing stream going through our soul}. 

#### Psalms 124:5 Surely {went through our soul} the {water unsubdued}. 

#### Psalms 124:6 Blessed be the LORD, who did not give us as game for their teeth. 

#### Psalms 124:7 Our soul as a sparrow was rescued from out of the snare of the ones hunting. The snare was broken, and we were rescued. 

#### Psalms 124:8 Our help is in the name of the LORD; the one making the heaven and the earth. 

#### Psalms 125:1 The ones yielding upon the LORD are as mount Zion; {shall not be shaken into the eon the one dwelling in Jerusalem}. 

#### Psalms 125:2 The mountains are round about her, and the LORD is round about his people, from the present and unto the eon. 

#### Psalms 125:3 For {will not allow the LORD} the rod of the sinners upon the lot of the just; so that {might not stretch out the just} in lawless deeds with their hands. 

#### Psalms 125:4 Do good, O LORD, to the good, and to the straight in heart! 

#### Psalms 125:5 But the ones turning aside unto perverseness, the LORD shall take away with the ones working lawlessness. Peace unto Israel. 

#### Psalms 126:1 In the {returning LORD} the captivity of Zion, we became as ones comforted. 

#### Psalms 126:2 Then {was filled with joy our mouth}, and our tongue with exultation. Then shall they say among the nations, the LORD magnified himself in dealing with them. 

#### Psalms 126:3 The LORD magnified himself in dealing with us; we became ones being glad. 

#### Psalms 126:4 Return, O LORD, our captivity as the rushing streams in the south! 

#### Psalms 126:5 The ones sowing in tears, {in exultation shall harvest}. 

#### Psalms 126:6 The ones going went and wept throwing their seed; but the ones coming shall come in exultation, lifting their sheaves. 

#### Psalms 127:1 Unless the LORD built the house, {in vain tired the builders}. Unless the LORD guarded the city, {in vain stayed awake the one guarding}. 

#### Psalms 127:2 For {vain for you it is} to rise up early; you arise after sitting down, O ones eating the bread of grief, whenever he should give {to his beloved ones sleep}. 

#### Psalms 127:3 Behold, the inheritance of the LORD, O sons, the wage of the fruit of the womb. 

#### Psalms 127:4 As arrows in the hand of the mighty, so are the sons of the ones being shaken off. 

#### Psalms 127:5 Blessed is the one who shall fill his desire with them; they shall not be disgraced whenever they should speak to his enemies at the gates. 

#### Psalms 128:1 Blessed are all the ones fearing the LORD; the ones going in his ways. 

#### Psalms 128:2 The toils of your wrist you shall eat; blessed are you, and well it will be to you. 

#### Psalms 128:3 Your wife is as a grapevine prospering on the sides of your house; your sons as newly planted olive plants round about your table. 

#### Psalms 128:4 Behold, thus shall be blessed the man fearing the LORD. 

#### Psalms 128:5 May {bless you the LORD} from out of Zion; and may you behold the good things of Jerusalem all the days of your life. 

#### Psalms 128:6 And may you behold the sons of your sons. Peace be upon Israel. 

#### Psalms 129:1 Many times they waged war against me from my youth -- Let {say indeed Israel}! 

#### Psalms 129:2 Many times they waged war against me from my youth; and yet they were not able to prevail against me. 

#### Psalms 129:3 {upon my back contrived The sinners}; they prolonged their lawlessness. 

#### Psalms 129:4 The LORD is just; he cut down the necks of sinners. 

#### Psalms 129:5 Let them be shamed, and be turned to the rear! all the ones detesting Zion. 

#### Psalms 129:6 Let them become as grass on roofs! which before being pulled out were dried; 

#### Psalms 129:7 of which {did not fill his hand the one harvesting}, nor the one {unto his bosom the sheaves collecting together}, 

#### Psalms 129:8 and {said not the ones passing by}, The blessing of the LORD be upon you; we bless you in the name of the LORD. 

#### Psalms 130:1 From out of the depths I cried out to you, O LORD. 

#### Psalms 130:2 O LORD, listen to my voice! Let {be your ears} attentive to the voice of my supplication! 

#### Psalms 130:3 If {lawless deeds you should closely watch}, O Lord, O LORD, who shall stand? 

#### Psalms 130:4 For {by you atonement is}. Because of your name I waited for you, O LORD. 

#### Psalms 130:5 {waited My soul} for your word. 

#### Psalms 130:6 {hoped My soul} upon the LORD from {watch the morning} till night. 

#### Psalms 130:7 Let Israel hope upon the LORD! for with the LORD is mercy, and an abundant {by him ransoming}. 

#### Psalms 130:8 And he shall ransom Israel from all his lawlessnesses. 

#### Psalms 131:1 O LORD, {was not exalted my heart}, nor were {raised up high my eyes}, nor was I gone among the great ones, nor in wonders above me. 

#### Psalms 131:2 Unless I was humble-minded, but I exalted my soul. As the one being weaned upon his mother, so will you recompense unto my soul. 

#### Psalms 131:3 Let {hope Israel} upon the LORD, from the present and unto the eon! 

#### Psalms 132:1 Remember, O LORD, David and all his gentleness! 

#### Psalms 132:2 As he swore by an oath to the LORD; he made a vow to the God of Jacob, saying, 

#### Psalms 132:3 Shall I enter into the tent of my house, no. Shall I ascend unto the bier of my stewn bed, no. 

#### Psalms 132:4 Shall I give sleep to my eyes, and {to my eyelids slumber}, and rest to my temples, no; 

#### Psalms 132:5 not until of which time I shall find a place for the LORD, a tent for the God of Jacob? 

#### Psalms 132:6 Behold, we heard her in Ephratah; we found her in the plains of the groves. 

#### Psalms 132:7 We shall enter into his tents; we shall do obeisance in the place of which {stood his feet}. 

#### Psalms 132:8 Rise up, O LORD, unto your rest, you and the ark of your sanctuary! 

#### Psalms 132:9 Your priests shall put on righteousness, and your sacred ones shall exult. 

#### Psalms 132:10 Because of David your servant you should not turn away the face of your anointed one. 

#### Psalms 132:11 The LORD swore by an oath to David in truth, and in no way shall he annul it, saying, {from the fruit of your belly I will establish upon your throne}. 

#### Psalms 132:12 If {shall guard sons your} my covenant, and {my testimonies these} which I shall teach them, then their sons {unto the eon shall sit upon your throne}. 

#### Psalms 132:13 For the LORD chose Zion; he took it for a dwelling to himself, saying, 

#### Psalms 132:14 This is my rest into the eon of the eon; here I shall dwell, for I took her. 

#### Psalms 132:15 Her game being a blessing, I shall bless; her poor I will fill with bread loaves; 

#### Psalms 132:16 Her priests I will clothe with deliverance; and her sacred ones {in exultation shall exult}. 

#### Psalms 132:17 There I will cause {to rise up the horn} to David; I prepared a lamp for my anointed one. 

#### Psalms 132:18 His enemies I will clothe with shame; but upon him {shall blossom my sanctification}. 

#### Psalms 133:1 Behold, indeed what is good or what is delightful, none other than the dwelling of the brethren together. 

#### Psalms 133:2 As perfumed liquid upon the head going down upon the beard -- the beard of Aaron; the going down upon the edge of his garment; 

#### Psalms 133:3 as dew of Hermon going down upon the mountains of Zion; for there the LORD gave charge to the blessing -- life unto the eon. 

#### Psalms 134:1 Behold indeed, bless the LORD all you servants of the LORD, the ones standing in the house of the LORD, in the courtyards of the house of our God in the night! 

#### Psalms 134:2 Lift up your hands in the holy place, and bless the LORD! 

#### Psalms 134:3 May {bless you the LORD} from out of Zion, the one making the heaven and the earth. 

#### Psalms 135:1 Praise the name of the LORD! Praise, O servants, the LORD, 

#### Psalms 135:2 O ones standing in the house of the LORD, in the courtyards of the house of our God! 

#### Psalms 135:3 Praise the LORD, for the LORD is good! Strum to his name, for it is good! 

#### Psalms 135:4 For {chose Jacob for himself the LORD}; Israel for a prized possession to himself. 

#### Psalms 135:5 For I know that {is great the LORD}, and our LORD is above all the gods. 

#### Psalms 135:6 All as much as {wanted the LORD} he did in the heaven, and on the earth, in the seas, and in all the deeps. 

#### Psalms 135:7 Leading clouds from the end of the earth, {lightnings in rain he made}. The one leading winds from his treasuries. 

#### Psalms 135:8 The one who struck the first-born of Egypt, from man unto beast. 

#### Psalms 135:9 He sent out signs and miracles in the midst of you, O Egypt, on Pharaoh, and among all his servants. 

#### Psalms 135:10 The one who struck {nations many}, and killed {kings strong}; 

#### Psalms 135:11 Sihon king of the Amorites, and Og king of Bashan, and all the kingdoms of Canaan. 

#### Psalms 135:12 And he gave their land for an inheritance; an inheritance to Israel his people. 

#### Psalms 135:13 O LORD, your name is into the eon, and your memorial unto generation and generation. 

#### Psalms 135:14 For the LORD shall judge his people, and concerning his servants he shall be comforted. 

#### Psalms 135:15 The idols of the nations are silver and gold, the works of the hands of men. 

#### Psalms 135:16 {a mouth They have}, and they shall not speak; {eyes they have} and they shall not see; 

#### Psalms 135:17 {ears they have} and they shall not give ear; and neither is a breath in their mouth. 

#### Psalms 135:18 {likened to them May become the ones making them}, and all the ones yielding upon them. 

#### Psalms 135:19 O house of Israel, bless the LORD! O house of Aaron, bless the LORD! 

#### Psalms 135:20 O house of Levi, bless the LORD! O ones fearing the LORD, bless the LORD! 

#### Psalms 135:21 Blessed be the LORD in Zion, the one dwelling in Jerusalem. 

#### Psalms 136:1 Let us confess to the LORD, for he is good, for into the eon is his mercy! 

#### Psalms 136:2 Let us confess to the God of gods, for into the eon is his mercy! 

#### Psalms 136:3 Let us confess to the LORD of lords, for into the eon is his mercy! 

#### Psalms 136:4 To the one doing {wonders great} alone, for into the eon is his mercy. 

#### Psalms 136:5 To the one making the heavens in skilfulness, for into the eon is his mercy. 

#### Psalms 136:6 To the one solidifying the earth upon the waters, for into the eon is his mercy. 

#### Psalms 136:7 To the one making {lights the great} alone, for into the eon is his mercy. 

#### Psalms 136:8 The sun for authority at day, for into the eon is his mercy. 

#### Psalms 136:9 The moon and the stars for authority of the night, for into the eon is his mercy. 

#### Psalms 136:10 To the one striking Egypt with their first-born, for into the eon is his mercy. 

#### Psalms 136:11 And leading Israel from their midst, for into the eon is his mercy. 

#### Psalms 136:12 With {hand a strong} and {arm high}, for into the eon is his mercy. 

#### Psalms 136:13 To the one dividing the red sea into divisions, for into the eon is his mercy. 

#### Psalms 136:14 And leading Israel through the middle of it, for into the eon is his mercy. 

#### Psalms 136:15 And the one shaking off Pharaoh and his force into {sea the red}, for into the eon is his mercy. 

#### Psalms 136:16 To the one leading his people in the wilderness, for into the eon is his mercy. 

#### Psalms 136:17 To the one striking {kings great}, for into the eon is his mercy. 

#### Psalms 136:18 And killing {kings strong}, for into the eon is his mercy. 

#### Psalms 136:19 Sihon king of the Amorites, for into the eon is his mercy. 

#### Psalms 136:20 And Og king of Bashan, for into the eon is his mercy. 

#### Psalms 136:21 And giving their land for an inheritance, for into the eon is his mercy. 

#### Psalms 136:22 An inheritance to Israel his servant, for into the eon is his mercy. 

#### Psalms 136:23 For in our humiliation {remembered us the LORD}, for into the eon is his mercy. 

#### Psalms 136:24 And he ransomed us from our enemies, for into the eon is his mercy. 

#### Psalms 136:25 The one giving nourishment to all flesh, for into the eon is his mercy. 

#### Psalms 136:26 Confess to God, O heaven, for into the eon is his mercy! 

#### Psalms 137:1 At the rivers of Babylon, there we sat; and we wept in our remembering Zion. 

#### Psalms 137:2 At the willows in the midst of it we hung our instruments. 

#### Psalms 137:3 For there {asked us the ones capturing us} of words of odes; and the ones having taken us away asked for a hymn -- Sing to us from the odes of Zion! 

#### Psalms 137:4 How should we sing the ode of the LORD upon {land an alien}? 

#### Psalms 137:5 If I should forget you, O Jerusalem, may {be forgotten my right hand}. 

#### Psalms 137:6 May {cleave my tongue} to my throat if I do not remember you; if I do not prefer Jerusalem as in the beginning of my gladness. 

#### Psalms 137:7 Remember, O LORD, the sons of Edom in the day of Jerusalem! The ones saying, Empty it out, empty it out unto its foundations! 

#### Psalms 137:8 The daughter of Babylon, the miserable; blessed is the one who shall recompense you with your recompense, which he was recompensing against us. 

#### Psalms 137:9 Blessed is the one who shall hold and dash your infants against the rock. 

#### Psalms 138:1 I will confess to you, O LORD, with {whole heart my}; and before angels I will strum to you, for you heard all the sayings of my mouth. 

#### Psalms 138:2 I shall do obeisance towards {temple your holy}, and I shall make acknowledgment to your name concerning your mercy and your truth; for you magnified {above all name your holy}. 

#### Psalms 138:3 In what ever day I should call upon you, quickly heed me! You shall take great care of me in my soul by your power. 

#### Psalms 138:4 Let them make acknowledgment to you, O LORD, even all the kings of the earth! for they heard all the sayings of your mouth. 

#### Psalms 138:5 And let them sing in the ways of the LORD, for great is the glory of the LORD! 

#### Psalms 138:6 For high is the LORD, and {the humble he watches over}, and the high things {from afar off he knows}. 

#### Psalms 138:7 If I should go in the midst of affliction, he shall enliven me. {against the anger of my enemies You stretched out your hands}, and {delivered me your right hand}. 

#### Psalms 138:8 The LORD shall recompense for me. O LORD, your mercy is into the eon. The works of your hands you should not ignore. 

#### Psalms 139:1 O LORD, you tried me, and knew me. 

#### Psalms 139:2 You knew my sitting down and my rising up; you perceived my thoughts from far off. 

#### Psalms 139:3 My path and my bent rush grass you traced; and all my ways you looked out ahead. 

#### Psalms 139:4 For there is no deceit in my tongue. Behold, O LORD, you knew all things; 

#### Psalms 139:5 the last and the former. You shaped me and put {upon me your hand}. 

#### Psalms 139:6 {causes wonder The knowledge of you} in me; it was strengthened; in no way should I be able to attain it. 

#### Psalms 139:7 Where should I go from your spirit? And from your presence where should I flee? 

#### Psalms 139:8 If I should ascend into the heaven, you are there; if I should go down into Hades, you are at hand. 

#### Psalms 139:9 If I may take up my wings at dawn, and I should encamp unto the ends of the sea, 

#### Psalms 139:10 even there your hand shall guide me, and {shall hold me your right hand}. 

#### Psalms 139:11 And I said, Surely darkness shall trample me; even the night was illumination for my luxury; 

#### Psalms 139:12 for darkness will not be made darkness with you; and night as day shall be given light; as its darkness, so also its light. 

#### Psalms 139:13 For you acquired of my kidneys; you took hold of me from out of the womb of my mother. 

#### Psalms 139:14 I will make acknowledgment to you, for fearfully you caused wonder; the wonders of your works; and my soul knows exceedingly. 

#### Psalms 139:15 {were not hidden My bones} from you, which you made in secret; and my essence in the lowermost parts of the earth. 

#### Psalms 139:16 {my unfinished state saw Your eyes}; and on your scroll all men shall be written. Days were shaped, and no one among them. 

#### Psalms 139:17 {by me But exceedingly were esteemed your friends}, O God, {exceedingly were strengthened their beginnings}. 

#### Psalms 139:18 I shall count them out, and above the sand they shall be multiplied; I awake, and still I am with you. 

#### Psalms 139:19 O that you should kill sinners, O God. O men of blood, turn aside from me! 

#### Psalms 139:20 For you will say concerning their thoughts, that they shall take {in folly your cities}. 

#### Psalms 139:21 Is it not the ones detesting you, O LORD, that I detested? and against your enemies I wasted? 

#### Psalms 139:22 In perfect hatred I detested them; {as enemies they became} to me. 

#### Psalms 139:23 Try me, O God, and know my heart! Examine me, and know my paths! 

#### Psalms 139:24 and see if the way of lawlessness is in me, and guide me in {way the eternal}! 

#### Psalms 140:1 Take me, O LORD, from {man the wicked}! {from man the unjust Rescue me}! 

#### Psalms 140:2 The ones who considered iniquity in their heart; the entire day they deployed for wars. 

#### Psalms 140:3 They sharpened their tongue as a serpent; the poison of asps is under their lips. PAUSE. 

#### Psalms 140:4 Guard me, O LORD, from the hand of the sinner! {from men unjust Take me away} who reasoned to trip up my footsteps! 

#### Psalms 140:5 {hid The proud} a snare for me; and {lines they extended} for a snare for my foot; next to a road {an obstacle they placed} for me. PAUSE. 

#### Psalms 140:6 I said to the LORD, {my God You are}. Give ear, O LORD, to the voice of my supplication! 

#### Psalms 140:7 O LORD, O Lord, the power of my deliverance. You shadowed over my head in the day of battle. 

#### Psalms 140:8 You should not deliver me, O LORD, from my desire unto the sinner. They argue against me. You should not abandon me, lest at any time they should be raised up high. PAUSE. 

#### Psalms 140:9 As for the head of them encircling me, the trouble of their lips shall cover them. 

#### Psalms 140:10 {shall fall upon them Coals with fire}; you shall throw them down in miseries, and in no way should they stand. 

#### Psalms 140:11 {man A talkative} shall not prosper upon the earth. {man an unjust Evils shall hunt} unto corruption. 

#### Psalms 140:12 I know that the LORD shall deal with the case of the poor, and the cause of the needy. 

#### Psalms 140:13 Besides, the just shall make acknowledgment to your name, and {shall dwell the upright} with your presence. 

#### Psalms 141:1 O LORD, I cried out to you. Listen to me! Take heed to the voice of my supplication in my crying to you! 

#### Psalms 141:2 May {be straightened my prayer} as incense before you; the raising of my hands as a sacrifice at evening. 

#### Psalms 141:3 Set, O LORD, a watch for my mouth, and {door a citadel} for my lips! 

#### Psalms 141:4 You should not turn aside my heart to words of wickedness, to make excuses for sins with men working lawlessness; and in no way shall I associate myself with their choice ones. 

#### Psalms 141:5 {shall correct me The just} with mercy, and reprove me; but the oil of the sinner, let it not anoint my head! For still yet shall my prayer be against their good-pleasures. 

#### Psalms 141:6 {were swallowed down next to the rock Their judges}. They shall hear my sayings, for they are a delight. 

#### Psalms 141:7 As thick ground was broken asunder upon the earth, {were dispersed his bones} by Hades. 

#### Psalms 141:8 For unto you, O LORD, O Lord, are my eyes. Upon you I hoped; you should not take away {in return my soul}. 

#### Psalms 141:9 Keep me from a snare which they concocted against me! and from obstacles of the ones working lawlessness. 

#### Psalms 141:10 {shall fall in their own casting-net Sinners}. {alone I am} until whenever I should pass away. 

#### Psalms 142:1 {with my voice to the LORD I cried out}; {with my voice to the LORD I beseeched}. 

#### Psalms 142:2 I shall pour out {before him my supplication}; {my affliction before him I shall report}. 

#### Psalms 142:3 In {failing from me my spirit}, then you knew my paths; in this very way that I went, they hid a snare for me. 

#### Psalms 142:4 I contemplated to the right, and I looked; for there was not one recognizing me. {perished Flight} from me, and there is not one inquiring after my soul. 

#### Psalms 142:5 I cried out to you, O LORD. I said, You are my hope, {my portion you are} in the land of the living. 

#### Psalms 142:6 Take heed to my supplication! for I was humbled exceedingly. Rescue me from the ones pursuing me! for they were strengthened above me. 

#### Psalms 142:7 Lead {out of prison my soul}! to make acknowledgment to your name. {shall wait for me The just}, until of which time you should recompense me. 

#### Psalms 143:1 O LORD, listen to my prayer! Give ear to my supplication in your truth! Hearken to me in your righteousness! 

#### Psalms 143:2 And you should not enter into judgment with your servant, for {not shall do justice before you all the living}. 

#### Psalms 143:3 For {pursued the enemy} my soul; he humbled {unto the ground my life}; he seated me in dark places as the dead of the eon. 

#### Psalms 143:4 And {was discouraged within me my spirit}; {within me was disturbed my heart}. 

#### Psalms 143:5 I remembered days of old. I meditated on all your works. {on the actions of your hands I meditated}. 

#### Psalms 143:6 I opened and spread out to you my hands. My soul is as {land a waterless} to you. 

#### Psalms 143:7 Quickly listen to me! O LORD, {fails my spirit}. You should not turn your face from me, so that I shall be like the ones going down into the pit. 

#### Psalms 143:8 {to be audible Cause to me in the morning your mercy}! for upon you I hoped. Make known to me, O LORD, the way in which I shall go! for to you I lifted my soul. 

#### Psalms 143:9 Rescue me from my enemies, O LORD! to you I take refuge. 

#### Psalms 143:10 Teach me to do your will! for you are my God. {spirit Your good} shall guide me in {land an upright}. 

#### Psalms 143:11 Because of your name, O LORD, you shall enliven me. In your righteousness you shall lead {from out of affliction my soul}. 

#### Psalms 143:12 And in your mercy you shall utterly destroy my enemies; and you shall destroy all the ones afflicting my soul; for {your servant I am}. 

#### Psalms 144:1 Blessed be the LORD my God; the one teaching my hands for battle array, and my fingers for war; 

#### Psalms 144:2 my mercy and my refuge; my shielder and my rescuer; my defender, and upon him I hoped; the one subjecting my people under me. 

#### Psalms 144:3 O LORD, what is man that you were known to him? or the son of man that you should consider him? 

#### Psalms 144:4 Man {folly is like}; his days as a shadow pass by. 

#### Psalms 144:5 O LORD, lean your heavens, and come down! Touch the mountains! and they shall smoke. 

#### Psalms 144:6 Flash lightning! and you shall disperse them. Send out your arrows! and you shall disturb them. 

#### Psalms 144:7 Send out your hand from the height! Take me, and rescue me from {waters many}, from out of the hand of the sons of strangers! 

#### Psalms 144:8 whose mouth spoke folly, and their right hand is a right hand of iniquity. 

#### Psalms 144:9 O God, {ode a new I will sing} to you; with {psaltery a ten-stringed} I will strum to you, 

#### Psalms 144:10 to the one giving deliverance to the kings, to the one ransoming David his servant from {broadsword the ferocious}. 

#### Psalms 144:11 Rescue me, and deliver me from the hand of the sons of strangers! whose mouth spoke folly, and their right hand is a right hand of iniquity; 

#### Psalms 144:12 whom their sons are as newly planted, secure in their youth; their daughters being bedecked, being adorned sumptuously as the likeness of a temple; 

#### Psalms 144:13 their storerooms are full, discharging forth from out of this one to that one; their sheep are prolific, multiplying in their streets; 

#### Psalms 144:14 their oxen are thick; there is no ruined fence, nor stream, nor a cry in their broad spaces; 

#### Psalms 144:15 {declare them happy the people} to which these things are. Blessed be the people of which the LORD is his God. 

#### Psalms 145:1 I will exalt you, O my God, my king; and I will bless your name into the eon, and into the eon of the eon. 

#### Psalms 145:2 According to each day I will bless you; and I will praise your name into the eon, and into the eon of the eon. 

#### Psalms 145:3 Great is the LORD, and praiseworthy exceedingly, and of his greatness there is no end. 

#### Psalms 145:4 Generation and generation shall praise your works, and {of your power they will report}. 

#### Psalms 145:5 The majesty of the glory of your holiness they shall speak, and your wonders they will describe. 

#### Psalms 145:6 And the power of your fearful acts they shall speak, and {your greatness they will describe}. 

#### Psalms 145:7 The remembrance of the multitude of your graciousness they shall discharge forth, and {your righteousness they will exult}. 

#### Psalms 145:8 Pitying and merciful is the LORD; lenient and full of mercy. 

#### Psalms 145:9 Gracious is the LORD in all things, and his compassions are upon all his works. 

#### Psalms 145:10 Let {make acknowledgment to you O LORD all of your works}, and {your sacred ones let} bless you! 

#### Psalms 145:11 The glory of your kingdom they shall speak, and {of your dominion they shall tell}; 

#### Psalms 145:12 to make known to the sons of men of your dominion, and the glory of the majesty of your kingdom. 

#### Psalms 145:13 Your kingdom is a kingdom of all the eons; and your mastery is in every generation and generation. Trustworthy is the LORD in all his words, and sacred in all his works. 

#### Psalms 145:14 The LORD supports all the ones falling down, and he re-erects all the ones being broken down. 

#### Psalms 145:15 The eyes of all {in you hope}; and you give them nourishment at an opportune time. 

#### Psalms 145:16 You opened your hand, and filled up every living creature of benevolence. 

#### Psalms 145:17 The LORD is just in all his ways, and sacred in all his works. 

#### Psalms 145:18 The LORD is near to all the ones calling upon him; all the ones calling upon him in truth. 

#### Psalms 145:19 {the will of the ones fearing him He will do}; and their supplication he shall listen to, and he shall deliver them. 

#### Psalms 145:20 The LORD guards all the ones loving him, and all the sinners he shall utterly destroy. 

#### Psalms 145:21 {to praise the LORD shall speak My mouth}. And let {bless all flesh} {name his holy} into the eon, and into the eon of the eon! 

#### Psalms 146:1 Praise {O my soul the LORD}! 

#### Psalms 146:2 I will praise the LORD in my life. I shall strum to my God as long as I exist. 

#### Psalms 146:3 Do not have reliance upon rulers; upon the sons of men in whom there is no deliverance. 

#### Psalms 146:4 {shall go forth His breath}, and shall return unto his earth. In that day {shall perish all his devices}. 

#### Psalms 146:5 Blessed is of whom the God of Jacob is his helper; his hope is upon the LORD his God; 

#### Psalms 146:6 the one making the heaven and the earth, the sea, and all the things in them; the one guarding truth into the eon; 

#### Psalms 146:7 the one executing judgment to the ones being wronged; giving nourishment to the ones hungering. The LORD unties ones being shackled. 

#### Psalms 146:8 The LORD gives wisdom to the blind. The LORD re-erects ones being broken down. The LORD loves the just. 

#### Psalms 146:9 The LORD guards the foreigners; orphan and widow he takes up; and the way of sinners he obliterates. 

#### Psalms 146:10 The LORD shall reign into the eon; your God, O Zion, unto generation and generation. 

#### Psalms 147:1 Praise the LORD, for {is good a psalm}! {to our God may be delicious praise}. 

#### Psalms 147:2 {is building Jerusalem The LORD}; the dispersions of Israel he shall assemble; 

#### Psalms 147:3 the one healing the ones broken in heart; and the one binding their ones being broken; 

#### Psalms 147:4 the one counting the multitude of stars; and {to all them by names calling}. 

#### Psalms 147:5 Great is our Lord, and great is his strength; and {of his understanding there is no number}. 

#### Psalms 147:6 The one taking up the gentle ones is the LORD; but humbling sinners onto the ground. 

#### Psalms 147:7 Take the lead to the LORD in acknowledgment! Strum to our God with a harp! 

#### Psalms 147:8 to the one covering the heaven with clouds; to the one preparing {for the earth rain}; to the one causing {to rise up on mountains grass}, and tender shoots for the service of men; 

#### Psalms 147:9 giving to the cattle their nourishment, and to the young of the crows -- to the ones calling upon him. 

#### Psalms 147:10 Not by the might of the horse does he want; nor by the lower legs of a man does he think well of. 

#### Psalms 147:11 The LORD thinks well in the ones fearing him, and in the ones hoping upon his mercy. 

#### Psalms 147:12 Applaud, O Jerusalem, the LORD! Praise your God, O Zion! 

#### Psalms 147:13 For he strengthened the bars of your gates; he blessed your sons by you. 

#### Psalms 147:14 The one putting your borders at peace; and with fatness of wheat filling you up. 

#### Psalms 147:15 The one sending his oracle to the earth; quickly {shall run his word}; 

#### Psalms 147:16 yielding up his snow as wool; {fog as ashes strewing}; 

#### Psalms 147:17 throwing his ice as morsels. Before the presence of his chilliness who shall stand? 

#### Psalms 147:18 He shall send out his word, and melt them. He shall breathe his breath and {shall flow waters}. 

#### Psalms 147:19 The one reporting his oracle to Jacob; {ordinances and judgments his} to Israel. 

#### Psalms 147:20 He did not do thus to every nation, and his judgments he manifested not to them. 

#### Psalms 148:1 Praise the LORD from out of the heavens! Praise him in the highest! 

#### Psalms 148:2 Praise him all you his angels! Praise him all his forces! 

#### Psalms 148:3 Praise him O sun and moon! Praise him all the stars, and the light! 

#### Psalms 148:4 Praise him O heavens of the heavens, and the water up above the heavens! 

#### Psalms 148:5 Praise the name of the LORD! For he spoke, and they existed. He gave charge, and they were created. 

#### Psalms 148:6 He established them into the eon, and into the eon of the eon. {an order He made}, and it shall not pass away. 

#### Psalms 148:7 Praise the LORD from the earth, O dragons and all abysses! 

#### Psalms 148:8 fire, hail, snow, ice, wind, blast -- the things executing his word; 

#### Psalms 148:9 the mountains and all the hills; the trees bearing fruit, and all the cedars; 

#### Psalms 148:10 the wild beasts and all the cattle; the reptiles, and {winged creatures feathered}; 

#### Psalms 148:11 kings of the earth, and all peoples; rulers and all judges of the earth; 

#### Psalms 148:12 young men and virgins; elders with younger; 

#### Psalms 148:13 let them praise the name of the LORD! For {is exalted his name alone}. The acknowledgment of him is above the earth and heaven. 

#### Psalms 148:14 And he shall exalt the horn of his people. A hymn to all his sacred ones; to the sons of Israel; to a people approaching to him. 

#### Psalms 149:1 Sing to the LORD {song a new}, of his praise in the assembly of the sacred ones! 

#### Psalms 149:2 Let Israel be glad upon the one making him! and the sons of Zion, let them exult over their king! 

#### Psalms 149:3 Let them praise his name among the company of dancers! with tambourine and psaltery let them strum to him! 

#### Psalms 149:4 For the LORD takes pleasure in his people, and he shall exalt the gentle with deliverance. 

#### Psalms 149:5 {shall boast sacred ones} in glory, and shall exult upon their beds. 

#### Psalms 149:6 The act of exaltation of God is in their throat, and {broadswords double-edged} are in their hands; 

#### Psalms 149:7 to execute punishment among the nations, and rebukes among the peoples; 

#### Psalms 149:8 to tie their kings in shackles, and their nobles in manacles of iron; 

#### Psalms 149:9 to execute among them {judgment written}. This glory is to all his sacred ones. 

#### Psalms 150:1 Praise God in his holy places! Praise him in the firmament of his power! 

#### Psalms 150:2 Praise him according to his dominations! Praise him according to the magnitude of his greatness! 

#### Psalms 150:3 Praise him with a sound of a trumpet! Praise him with a psaltery and harp! 

#### Psalms 150:4 Praise him with a tambourine and company of dancers! Praise him with strings of a lyre and musical instrument! 

#### Psalms 150:5 Praise him with {cymbals distinct}! Praise him with {of cymbals a shout}! 

#### Psalms 150:6 All with breath praise the LORD!