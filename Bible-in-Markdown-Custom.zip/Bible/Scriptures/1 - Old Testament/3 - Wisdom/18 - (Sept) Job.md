#### Job 1:1 {a certain man There was} in the land of Uz, Job was the name to him. And {was that man} true, unblemished, {man a sincere}, and upright, and fearing God, at a distance from every wicked thing. 

#### Job 1:2 And there were to him {sons seven} and {daughters three}. 

#### Job 1:3 And {were his animals} -- {sheep seven thousand}, {camels three thousand}, {teams of oxen five hundred}, and {donkeys female grazing five hundred}, and for service {many exceedingly}, and {works great there were} of his upon the land. And {was that man} great of the ones from {sun the east}. 

#### Job 1:4 {going And his sons} to one another prepared a banquet, each of his own day, taking along together also {three sisters their} to eat and to drink with them. 

#### Job 1:5 And whenever they completed the days of the banquet, Job sent and purified them, rising up in the morning, and offering for them a sacrifice according to their number. {said For Job}, Lest at any time {sinned and raved against God with their heart my sons}. Thus then Job did all the days. 

#### Job 1:6 And it came to pass this day, and behold, {came the sons of God} to stand before the LORD, and the devil came in the midst of them. 

#### Job 1:7 And {said the LORD} to the devil, From what place have you come? And {answered the devil} to the LORD, and said, Going around the earth, and walking about the {under heaven place at hand}. 

#### Job 1:8 And {said to him the LORD}, Have you been attentive then in your consideration to my attendant Job, that there is none likened to him of the ones upon the earth, {man a blameless}, a man sincere and upright and fearing God, at a distance from every wicked thing? 

#### Job 1:9 {answered And the devil}, and said, Before the LORD, does Job freely fear God? 

#### Job 1:10 Have you not enclosed him, and the things inside his household, and the things outside? And all of the things being to him round about -- the works of his hands you blessed, and {his cattle many you made} upon the earth. 

#### Job 1:11 But send your hand, and touch all which he has, and assuredly {in your face he will rave} against you. 

#### Job 1:12 Then {said the LORD} to the devil, Behold, all as much as is his I put into your hand; but he himself you shall not touch. And {went forth the devil} from the LORD. 

#### Job 1:13 And it was on this day the sons of Job and his daughters were drinking wine in the house {brother of their elder}. 

#### Job 1:14 And behold, a messenger came to Job, and said to him, The teams of oxen were plowing, and the female donkeys were grazing next to them. 

#### Job 1:15 And Sabeans fell upon and captured them, and the servants they killed by swords. {escaped And I alone}, and I came to report to you. 

#### Job 1:16 Yet speaking this, there came another, and said to Job, Fire from God fell from out of the heaven, and it incinerated the sheep; and the shepherds were devoured up in like manner; and having escaped, I alone came to report to you. 

#### Job 1:17 While speaking this, there came another messenger, and said to Job, The Chaldeans put three companies, and encircled the camels, and captured them; and the servants they killed by swords, {escaped and I alone}, and I came to report to you. 

#### Job 1:18 While this one was speaking, another messenger came, saying to Job, Your sons and your daughters were eating and drinking with {brother their elder}. 

#### Job 1:19 Suddenly {wind a great} came upon them from out of the wilderness, and it touched the four corners of their house, and {fell the house} upon your children, and they came to an end; {escaped and I alone}, and I came to report to you. 

#### Job 1:20 Thus rising up, Job tore up his garments, and sheared the hair of his head, and falling to the ground he did obeisance. 

#### Job 1:21 And said, I myself {naked came forth} from out of {belly my mother's}, and naked I shall go forth there. The LORD gave, the LORD removed, as to the LORD it seemed good, so also it came to pass. May {be the name of the LORD} blessed. 

#### Job 1:22 In all these things coming to pass against him, in nothing Job sinned before the LORD, and he imputed not folly to God. 

#### Job 2:1 And it came to pass as this day occurred, and {came the sons of God} to stand before the LORD. And the devil came in the midst of them to stand before the LORD. 

#### Job 2:2 And {said the LORD} to the devil, From what place come you? Then {said the devil} before the LORD, Traveling over the place under heaven, and walking about the whole the place at hand. 

#### Job 2:3 {said And the LORD} to the devil, Have you taken heed then to my attendant Job, that there is not according to him of the ones upon the earth, a man not wicked, true, blameless, godly, and at a distance from all evil? But still he has innocence, but you spoke {his substance without cause to destroy}. 

#### Job 2:4 {undertaking But the devil}, said to the LORD, Skin for skin, and all as much as exists to a man {for his life he will give}. 

#### Job 2:5 But in fact, but you send your hand to touch his bones and his flesh, assuredly {in your face he will rave}. 

#### Job 2:6 {said And the LORD} to the devil, Behold, I deliver him to you, only {his life you guard}! 

#### Job 2:7 And {went forth the devil} from the LORD, and smote Job {sore with a severe} from feet unto head. 

#### Job 2:8 And he took to himself a potsherd so as {the pus to scrape}; and he sat down within the ashes. 

#### Job 2:9 And {said to him his wife}, Until how long will you persevere? But speak any word to God, and come to an end! 

#### Job 2:10 And he, looking to her said, Why as one of the foolish women did you speak? If {the good things we looked for} from the hand of the LORD, {the bad shall we not endure}? In all these things, the ones coming to pass to him, not one thing Job sinned with his lips before the LORD. 

#### Job 2:11 {hearing And three friends his the bad things all} coming upon him, came each from their own place to him. Eliphaz the Temanite -- a king, Baldad the Shuhite -- a sovereign, Zophar the Minaean -- a king. And they came to him with one accord to comfort and visit him. 

#### Job 2:12 And seeing him at a distance, they did not recognize him. And they yelled {voice with a great}, and wept, {tearing each} his own apparel, and strewing earth. 

#### Job 2:13 And they sat beside him seven days and seven nights, and not one of them spoke to him a word; for they saw the {calamity awful} being, and {great it was exceedingly}. 

#### Job 3:1 And after this Job opened his mouth and cursed his day, 

#### Job 3:2 saying, 

#### Job 3:3 May {be destroyed the day in which I was born}, and the night in which they said, Behold, a male. 

#### Job 3:4 {that night May be} darkness, and {not may search out it the LORD} from above, nor may {come into it brightness}. 

#### Job 3:5 {may take But it darkness and the shadow of death}. May {come upon it dimness}. And may {be disturbed day that}, 

#### Job 3:6 and that night. May {have carried away it darkness}. May it not be for the days of the year, nor may it be counted for the days of the months. 

#### Job 3:7 But {that night may} be grief, and may {not come upon it gladness}, nor a cause for joy. 

#### Job 3:8 But may {curse it the one cursing day that}, the ones being about to awaken Leviathan. 

#### Job 3:9 May {be enveloped in darkness the stars of that night}, and not remain, and {for illumination not come}. And may {not be seen morning star the arising}. 

#### Job 3:10 For it did not close up the gates {womb of my mother's}, {dismissed for it would have} misery from my eyes. 

#### Job 3:11 For why in the belly did I not come to an end? {from the womb But instead I came forth}, and was not straightway destroyed? 

#### Job 3:12 And why did {meet me the knees}? And why did {on the breasts I nurse}. 

#### Job 3:13 Now going to bed I should be stilled; and having slept rested; 

#### Job 3:14 with the kings, the counselors of the earth, who prance with swords; 

#### Job 3:15 or with rulers, whose {was abundant gold}, who filled their houses with silver. 

#### Job 3:16 Or as if a miscarriage going forth from out of {womb a mother's}, or as infants who beheld not light. 

#### Job 3:17 There the impious ceased the rage of anger; there {are rested the exhausted in body}. 

#### Job 3:18 But with one accord the ones being bound do not hear the voice of the tribute-gatherer. 

#### Job 3:19 Small and great are there, even the attendant being in awe of his master. 

#### Job 3:20 For why has {been given to the ones in bitterness light}, and life to the {in griefs souls}? 

#### Job 3:21 the ones who long for death, and do not attain; rooting it up as if for treasures; 

#### Job 3:22 {overjoyed and they become} if they should attain it. Death to a man is rest. 

#### Job 3:23 {not The way was} concealed, {hemmed in for God} against him. 

#### Job 3:24 {before For my grain moaning comes to me}, and shall be poured as waters roaring. 

#### Job 3:25 For the fear which I thought about, came to me; and which I had in awe, met with me. 

#### Job 3:26 Neither was I at peace, nor still, nor I rested; {came but to me wrath}. 

#### Job 4:1 And undertaking, Eliphaz the Temanite says, 

#### Job 4:2 If we take to speak to you, will you tire? But the strength of your words, who shall endure? 

#### Job 4:3 For since you admonished many, and {the hands of the weak comforted}, 

#### Job 4:4 {the ones being weak and also raised up} with words, {in knees and to the ones powerless courage you invested}, 

#### Job 4:5 but now {comes upon you misery}, and touched you; and now you are hurried. 

#### Job 4:6 Is it not that your fear is in folly, and your hope, and the evil of your way? 

#### Job 4:7 Do you remember then who being pure was destroyed? or when the true ones {entirely from the root were destroyed}? 

#### Job 4:8 As in which manner I beheld the ones plowing the unnatural places, then the ones sowing them {griefs shall harvest} for themselves. 

#### Job 4:9 By the order of the LORD they shall perish, and by the breath of his anger they shall be obliterated. 

#### Job 4:10 The strength of the lion, and the voice of the lioness, and the prancing of dragons shall be extinguished. 

#### Job 4:11 The small lion is destroyed by not having game; and the cubs of lions forsook one another. 

#### Job 4:12 {to me And} it was spoken clandestinely in stealth; shall not {receive my ear} extraordinary things by him, 

#### Job 4:13 in amazement from {vision my nightly} falling fear upon men? 

#### Job 4:14 But a shuddering awe met with me, and trembling, and {greatly my bones quaked}. 

#### Job 4:15 And a spirit {upon my face came}, {shuddered and my hair and flesh}. 

#### Job 4:16 I rose up, and knew not; I saw and {no was there} appearance before my eyes, but only a breeze; and {a voice I heard}, saying, 

#### Job 4:17 For what, Shall {pure be a mortal} before the LORD? or {from his works be blameless shall a man}? 

#### Job 4:18 If {even his servants he does not trust}, and even considers his angels as crooked in what he thinks about, 

#### Job 4:19 then the ones dwelling in houses of clay, of whom also we {from out of the same mortar are} -- he smites them {of a moth in the manner}. 

#### Job 4:20 And from morning until evening {no longer they are}; by their not being able {themselves to help themselves they} perish. 

#### Job 4:21 You raised up together their vestige in them; they perished by {not having their} wisdom. 

#### Job 5:1 But call, if any one will hearken to you; or if {any angels holy you shall see}. 

#### Job 5:2 For even {a fool does away with anger}, {one having wandered and puts to death zeal}. 

#### Job 5:3 And I have seen fools {root laying}; and I cursed their attractiveness immediately. 

#### Job 5:4 {at a distance May be their sons} from safety, and they shall be crushed at the doors of lesser men, and there shall not be one rescuing. 

#### Job 5:5 {which For those things} they harvested, one hungering shall eat; but they {to ones armed shall be carried}; may {be siphoned off their strength}. 

#### Job 5:6 {not For can come forth out of the earth toil}, nor {from the mountains sprout up shall misery}. 

#### Job 5:7 But a man is born to toil, and the young eagles {the high places to fly}; 

#### Job 5:8 {nevertheless but} I shall beseech of the LORD, {the LORD and the master of all I shall call upon}, 

#### Job 5:9 the one doing great things, and untraceable, honorable things also, and extraordinary, which there is no number; 

#### Job 5:10 the one giving rain upon the earth, sending water upon the places under heaven; 

#### Job 5:11 the one appointing the humble unto the height, and {the ones perishing raising up}, 

#### Job 5:12 effacing counsels of clever ones, that in no way should {perform their hands} true; 

#### Job 5:13 the one overtaking the wise with the intellect; and the counsel of the crafty ones he amazes. 

#### Job 5:14 By day {shall meet them darkness}, and at midday may they grope equally as at night. 

#### Job 5:15 And may they perish in war; and may the powerless come forth from out of the hand of the mighty one. 

#### Job 5:16 And may there be {to the poor hope}; {of the unjust but the mouth may} be obstructed. 

#### Job 5:17 And blessed is the man whom {reproved the LORD}, {the admonition and of the almighty does not refuse}. 

#### Job 5:18 For he {one to ache causes}, and again he restores; he smites, and his hands heal. 

#### Job 5:19 Six times {from out of your distresses he rescues you}, and in the seventh time in no way will he touch you for bad. 

#### Job 5:20 In famine, he will rescue you from death, {in war and from out of the hand of iron he will untie you}. 

#### Job 5:21 {from the whip of the tongue He shall hide you}, and in no way shall you be fearful from {evils the coming}. 

#### Job 5:22 The unjust and lawless you shall ridicule, and from {beasts wild} in no way shall you be fearful; 

#### Job 5:23 for the beasts of the wild shall make peace with you. 

#### Job 5:24 Then you shall know that {shall be at peace your house}; and he shall visit your beauty, and in no way should it have sinned. 

#### Job 5:25 And you shall know that {shall be many your seed}, and your progeny will be as the abundant herbage of the field. 

#### Job 5:26 And you shall come unto the grave as grain in season, according to the time of harvesting; or as a heap of the threshing-floor according to the hour of its being collected. 

#### Job 5:27 Behold, these things thus we tracked out, these things are what we have heard; but you, know in yourself if you acted in anything! 

#### Job 6:1 And undertaking, Job says, 

#### Job 6:2 For if anyone stationing weight would set my wrath, and {griefs my lift} onto a yoke balance scale, they would be in one accord. 

#### Job 6:3 For indeed of the sand of the coast it will be heavier; upon this my sayings were trampled. 

#### Job 6:4 For arrows of the worthy one {in my body are}, which their rage drinks up my blood. Whenever I begin to speak, they sting me. 

#### Job 6:5 For what -- will {ineffectually cry out donkey the wild} if he is not {grain seeking}, no. And shall then {tear loose the voice of the ox} at the stable while having foods, no. 

#### Job 6:6 Shall {be eaten bread} without salt, no. and is there taste in {words empty}, no. 

#### Job 6:7 {is not able For my to cease soul}; for groaning I see my grain as the scent of a lion. 

#### Job 6:8 For if only he might give and {might come my requests}, and that {my hope might grant the LORD}. 

#### Job 6:9 Beginning, {the LORD let} pierce; {unto the end but me not let be done away with}! 

#### Job 6:10 {may be But my city the grave}, upon {of which upon the walls I leaped}; upon it I shall not spare; {not for I lied} about {sayings the holy} of my God. 

#### Job 6:11 For what is my strength, that I remain? or what is my time, that {endures my soul}? 

#### Job 6:12 Is {the strength of stones my strength}? or {my flesh members are} of brass? 

#### Job 6:13 Or not upon him to yield? but help {from me was departed}; 

#### Job 6:14 {is forbidden me mercy}; and the visit of the LORD overlooked me. 

#### Job 6:15 {looked not at me My brothers}; {as if a rushing stream dissipating or as if a wave they went by me}. 

#### Job 6:16 The ones who revered me, now fall upon me as if snow or ice banked up, 

#### Job 6:17 and as the melting away {of heat by the coming}, it was not recognized of where it was. 

#### Job 6:18 So I also was left by all; and I am destroyed, and {homeless I became}. 

#### Job 6:19 Behold the ways of the Temanites, {the short cuts of the Sabaeans O ones seeing clearly}. 

#### Job 6:20 And for shame they shall owe -- the ones in cities and the things relied upon there. 

#### Job 6:21 But nevertheless, even you mounted against me mercilessly; so that beholding my wound you are fearful. 

#### Job 6:22 For what -- {anything of you did I ask}, or {from you strength do I want}, 

#### Job 6:23 so as to deliver me from enemies, or {from out of the hand of mighty ones to rescue me}? 

#### Job 6:24 Teach me, and I will be silent! If in anything I have wandered, expound to me! 

#### Job 6:25 But as it seems, {are vile of a true man the words}; {not for from you strength I do ask}. 

#### Job 6:26 Nor will your reproof {my words cause me to cease}; for neither your utterance of a word will I endure. 

#### Job 6:27 Besides that, {upon an orphan you fall}, and you assail against your friend. 

#### Job 6:28 But now, having looked into your faces, I will not lie. 

#### Job 6:29 Sit indeed, and may there not be anything unjust, and again {with the just come together}! 

#### Job 6:30 {no For there is on my tongue unjust thing}; or, does not my throat meditate on understanding? 

#### Job 7:1 In either way {not a trial is the existence of man upon the earth}, and {as hireling the daily his life}, 

#### Job 7:2 or as an attendant in awe of his master, and attaining for shade; or as if a hireling awaiting his wage? 

#### Job 7:3 So I also waited months in vain; and nights of griefs {given to me are}. 

#### Job 7:4 When I should go to bed, I say, When will it be the day? and whenever I rise up, again I say, When will it be evening? {full And I am} of griefs, from evening unto morning. 

#### Job 7:5 {is befouled And my body} in rottenness of worms, and I melt away with clods of earth {of pus scraping}. 

#### Job 7:6 And my existence is lighter than speech, and has perished in vain hope. 

#### Job 7:7 Remember then that my breath is life; and no longer shall {return back my eye} to behold good. 

#### Job 7:8 {shall not look round about The eye of the one seeing me}; your eyes are on me, and I am not. 

#### Job 7:9 I am as a cloud being cleared away from the heaven; for if a man should go down into Hades, no longer in any way should he ascend; 

#### Job 7:10 and neither in any way shall he return unto his own house, nor {in any way shall recognize him any more his place}. 

#### Job 7:11 Nevertheless then, nor will I spare my mouth; I will speak {in distress being} of my spirit; I will open the bitterness of my soul being held in. 

#### Job 7:12 Is it that I am a sea or a dragon, that you delegated {over me a guard}? 

#### Job 7:13 I said that {shall comfort me my bed}, and I shall offer to myself my own word in my bed. 

#### Job 7:14 You frighten me with dreams, and with visions you strike terror in me. 

#### Job 7:15 You will dismiss {from my spirit my soul}, {from and death my bones}. 

#### Job 7:16 {not For into the eon I shall live}, that I should patiently wait. Depart from me, {is empty for my livelihood}! 

#### Job 7:17 For what is man that you magnified him? or that you heed the mind in him? 

#### Job 7:18 Or {him a visit will you make} until the morning; and {for rest shall you judge him}? 

#### Job 7:19 For how long do you not allow me, nor let me go, until whenever I should swallow down my spittle in grief? 

#### Job 7:20 If I sinned, how am I able {against you to act out}, O one having knowledge of the mind of men? Why did you establish me as your accuser, and I am {unto you a load}? 

#### Job 7:21 And why did you not appoint of my lawlessness to forgetfulness, and for a cleansing of my sin? But now into the earth I shall go forth, {for rising early and no longer I am}. 

#### Job 8:1 And undertaking, Baldad the Shuhite, says, 

#### Job 8:2 Till when shall you speak these things {spirit by a talkative} of your mouth? 

#### Job 8:3 Will the LORD transgress judging? or the one making all things disturb the just? 

#### Job 8:4 If your sons sin before him, he sent them away in hand because of their lawlessness. 

#### Job 8:5 But you, rise early to the LORD almighty beseeching him! 

#### Job 8:6 If you are pure and true, {supplication he will heed your}, and he will restore to you the habitation of righteousness. 

#### Job 8:7 It will be then that as your first shall be little, yet your last will be an untold amount. 

#### Job 8:8 For ask {generation the first}, and trace according to the race of the fathers! 

#### Job 8:9 {of yesterday For we are}, and have not known; {a shadow for our is existence upon the earth}; 

#### Job 8:10 shall these not teach you, and announce to you, and from out of the heart lead forth sayings? 

#### Job 8:11 Does {flourish papyrus} without water? or shall {rise up high the flowering rush} without drinking? 

#### Job 8:12 Yet being upon the root, and in no way harvested, {before the drinking of all pasturage shall it not be dried}? 

#### Job 8:13 So therefore will it be for the last of all the ones forgetting the LORD; for the hope of the impious shall perish. 

#### Job 8:14 {uninhabited For his will be house}, {as for a spider and his will turn out to be tent}. 

#### Job 8:15 If one should overlook his house, in no way shall it stand; and grasping it, in no way shall it remain. 

#### Job 8:16 {wet For it is} under the sun, and {out of his rottenness his tender branch shall come forth}. 

#### Job 8:17 Upon a gathering of stones he goes to bed, and in the midst of gravel he shall live. 

#### Job 8:18 And if {should swallow him the place}, it shall lie to him, saying, Have you not seen such a thing? 

#### Job 8:19 For the undoing of the impious is such, and from out of the earth another shall sprout up. 

#### Job 8:20 For the LORD in no way will undo the guileless, and every gift of the impious he will not receive. 

#### Job 8:21 {of the true ones But the mouth} he will fill with laughter, and their lips with acknowledgment. 

#### Job 8:22 But their enemies shall put on shame; and the habitation of the impious will not be. 

#### Job 9:1 And undertaking, Job says, 

#### Job 9:2 In truth I know that it is so; for how shall there be a just mortal before the LORD? 

#### Job 9:3 For if he should want to enter into judgment with him, in no way shall God obey him, so that he shall not contradict with one word of his from out of a thousand. 

#### Job 9:4 {wise For he is} in thought, fortified also, and great. Who {hard being} before him even made peace? 

#### Job 9:5 The {of old mountains} even do not know the one eradicating them in anger. 

#### Job 9:6 The one shaking the thing under heaven from its foundations, and the columns of it shake. 

#### Job 9:7 The one speaking to the sun, and it does not rise; and accordingly {the stars he seals up}. 

#### Job 9:8 The one stretching the heaven alone, and walking {as upon a floor upon the sea}. 

#### Job 9:9 The one making Pleiades and Hesperus and Arcturus, and the chambers of the south. 

#### Job 9:10 The one doing great and untraceable things; honorable also, and extraordinary things which there is no number. 

#### Job 9:11 If he should pass over me, in no way shall I behold it; and if he should go by me, neither thus I knew it. 

#### Job 9:12 If he dismisses, who returns? or who shall say to him, What did you do? 

#### Job 9:13 God will not turn away the anger, {under him but were bent the whales under heaven}. 

#### Job 9:14 But then should he obey me, or shall he litigate my things? 

#### Job 9:15 {even if For just I should be} shall he listen not to me? his equity I will beseech. 

#### Job 9:16 And if I should call and he should hearken, I do not trust that he has listened to my voice. 

#### Job 9:17 {not by dimness He should obliterate me}; but many of my bruises he has made without cause. 

#### Job 9:18 {not he allows For me} to breathe, and he filled me with bitterness. 

#### Job 9:19 For indeed by strength he prevails; who then {his judgment shall oppose}? 

#### Job 9:20 For if I might be just, my mouth will be impious; and though I might be blameless, {perverse I shall turn out}. 

#### Job 9:21 For whether I was impious, I do not know in soul; besides, {is removed from me life}. 

#### Job 9:22 Therefore I said, {the great and mighty one he destroys} in wrath. 

#### Job 9:23 For the vile {in death are extraordinary}, but the just are ridiculed. 

#### Job 9:24 For they are delivered into the hands of the impious; {the faces of her judges he covers up}; but if not he, who is it? 

#### Job 9:25 But my existence is lighter than a runner; my days ran away, and they knew it not. 

#### Job 9:26 Or also is there {of ships a trace} in the way? or a trace of an eagle flying seeking prey? 

#### Job 9:27 For if also I said, I shall forget about speaking, I will stoop down my countenance and I will moan. 

#### Job 9:28 I shake in all my limbs, for I know that {not me be innocent you will let}. 

#### Job 9:29 But since I am impious, for why is this {in vain I labor}? 

#### Job 9:30 For if I should wash myself off with snow, and should clear away my hands clean, 

#### Job 9:31 fittingly in my filth you dipped me; {abhorred and me my apparel}. 

#### Job 9:32 {not For you are} a man like me, with whom I can judge by comparison, that we should come with one accord for judgment. 

#### Job 9:33 If indeed {was present our mediator}, and the one reproving, and the one hearing between both, 

#### Job 9:34 let him dismiss {from me the rod}, {the and fear of him let not} whirl about, 

#### Job 9:35 and in no way shall I fear, but I will speak, for I am not thus conscious of guilt. 

#### Job 10:1 Being weary in my soul, in moaning I will let loose upon myself my sayings; I will speak in the bitterness of my soul, being constrained. 

#### Job 10:2 And I will say to the LORD, {not me to be impious Teach}! and why {me have you so judged}? 

#### Job 10:3 Or is it good to you that I should transgress? that I should forbid the works of your hands? {the counsel and of the impious did you heed}? 

#### Job 10:4 Or as a mortal sees -- do you look? or as {sees a man} -- shall you see? 

#### Job 10:5 Or your existence -- is it mankind? or your years -- a man's? 

#### Job 10:6 For you searched out my lawlessnesses, and {my sins you traced}. 

#### Job 10:7 For you know that I did not act impious; but who is the one {from out of your hands rescuing}? 

#### Job 10:8 Your hands shaped me and made me; after these things in turning you smote me. 

#### Job 10:9 Remember that {of clay you shaped me}, and unto the earth {me again you return}. 

#### Job 10:10 Or {not as milk me did you extract}, and curdled me equal to cheese? 

#### Job 10:11 But skin and meat you put on me, and with bones and nerves you entwined me. 

#### Job 10:12 And life and mercy you put upon me, and by your overseeing you guarded my spirit. 

#### Job 10:13 Having these things in yourself, I know that {all things you are able to do}; {is impossible and with you not one thing}. 

#### Job 10:14 For if I should sin, you guard me; but from lawlessness {not innocent me you have appointed}. 

#### Job 10:15 For if I should be impious, alas; but if I might be just, I am not able to lift up the head, {full for of dishonor I am}. 

#### Job 10:16 For I am caught as a lion for slaughter; and again in turning {awfully me you destroy}; 

#### Job 10:17 renewing upon me my chastisement; {anger and in great you dealt with me}, and you brought {against me trials}. 

#### Job 10:18 Why then in the belly did you lead me out, and I did not die, that an eye {me did not see}, 

#### Job 10:19 and that {as if one not being I became}? For why {from the womb unto the tomb was I not dismissed}? 

#### Job 10:20 Or {not little is the time of my existence}? Allow me to rest a little! 

#### Job 10:21 before my going from where I shall not return, unto a land dark and dim; 

#### Job 10:22 unto a land {darkness of eternal}, where there is no brightness, nor seeing the life of mortals. 

#### Job 11:1 And undertaking, Sophar the Minean says, 

#### Job 11:2 The one {many things saying} also shall listen in turn; or does the well-spoken imagine himself to be just? Blessed be the one born of woman short-lived. 

#### Job 11:3 {not many in words Become}; {no one for there is} judging you by comparison. 

#### Job 11:4 For do not say that, I am pure in works, and blameless before him. 

#### Job 11:5 But how ever is the LORD to speak to you, and open his lips with you; 

#### Job 11:6 then he shall announce to you the power of wisdom, that it will be double to the things of yours? And then you shall know that what is worthy to you resulted from the LORD whom you have sinned. 

#### Job 11:7 Or {the trace of the LORD will you find}? or {unto the latter end did you arrive} which {prepared the almighty}? 

#### Job 11:8 {is high Heaven}, and what will you do? And there are deeper things than in Hades, what do you know? 

#### Job 11:9 or longer than the measure of the earth, or the breadth of the sea. 

#### Job 11:10 And if he shall eradicate all things, who will say to him, What did you do? 

#### Job 11:11 For he knows the works of the lawless; and beholding {the things out of place he shall not overlook}. 

#### Job 11:12 But man otherwise shall be over-confident with words; but a mortal born of a woman is equal {donkey to a recluse}. 

#### Job 11:13 For if you {clean established your heart}, and turned up and opened your hands to him; 

#### Job 11:14 if {lawless thing any there is} in your hands, {to be at a distance cause it}! {injustice and in your habitation let not lodge}! 

#### Job 11:15 For thus {shall illuminate your face} as if {water pure}; and you shall strip off filth, and in no way shall you be fearful. 

#### Job 11:16 And {trouble you shall forget} as a wave going by; and you shall not be terrified. 

#### Job 11:17 And your vow will be as the morning star; and from midday {shall arise to you life}. 

#### Job 11:18 {complying And you shall be}, for it is hope to you; and from anxiety and bewilderment {shall appear to you peace}. 

#### Job 11:19 For you shall be tranquil, and there will not be one waging war against you; and turning, many will beseech you. 

#### Job 11:20 But deliverance shall leave them, for their hope is destruction; and the eyes of the impious shall melt away. 

#### Job 12:1 And undertaking, Job says, 

#### Job 12:2 So then you are men, then {with you comes to an end wisdom}? 

#### Job 12:3 {also to me indeed a heart like yours There is}. 

#### Job 12:4 For a just man, and blameless, was born for an object for taunts. 

#### Job 12:5 {at time For an appointed} man had been prepared to fall under others; {house also for his} to be pillaged by lawless ones. But let not however any one {rely on wicked being} he shall be considered innocent; 

#### Job 12:6 as many as provoke {to anger the LORD}, as if {not also their chastisement there will be}. 

#### Job 12:7 But indeed ask the four-footed beasts! if they should speak to you, or birds of the heaven, if they were able to report to you. 

#### Job 12:8 {let tell in detail And the earth}! if it should expound to you; and {shall describe to you the fishes of the sea}. 

#### Job 12:9 Who knew not among all these, that the hand of the LORD made these? 

#### Job 12:10 Except in his hand is the life of all the living, and the breath of every man. 

#### Job 12:11 {the ear indeed For words scrutinizes}, and the throat {grains tastes}. 

#### Job 12:12 In a long time is wisdom; and in a long existence is higher knowledge. 

#### Job 12:13 By him is wisdom and power; with him counsel and understanding. 

#### Job 12:14 If he should throw down, who shall build up? If he locks against man, who opens? 

#### Job 12:15 If he should restrain the water, he shall dry the earth; and if he should let it loose, he destroys it by eradication. 

#### Job 12:16 By him is might and strength; in him is higher knowledge and understanding, 

#### Job 12:17 leading counselors as captives; and judges of the earth he amazes; 

#### Job 12:18 sitting kings upon thrones, and ties a belt on their loins; 

#### Job 12:19 sending priests as captives; and the mighty ones of the earth he eradicates; 

#### Job 12:20 reconciling the lips of the trustworthy; {the understanding and} of the elders he knew; 

#### Job 12:21 pouring out dishonor upon rulers, but the humble he healed; 

#### Job 12:22 uncovering the deeps from out of darkness, and he leads {into light the shadow of death}; 

#### Job 12:23 wandering nations, and destroying them; prostrating nations, and directing them; 

#### Job 12:24 reconciling the hearts of the rulers of the earth, but wandering them in the way which they do not know. 

#### Job 12:25 May they handle darkness, and not light; may they be wandering as if one being intoxicated. 

#### Job 13:1 Behold, {these things has seen my eye}, and {has heard my ear}. 

#### Job 13:2 And I know as much as even you know; and {not more senseless I am} than you. 

#### Job 13:3 But nevertheless, I {to the LORD will speak}; and I will reprove before him, if he should be willing. 

#### Job 13:4 But you are {physicians unjust}, and {healers bad are all}. 

#### Job 13:5 But it may be good for you to be silent, and it shall turn out to you for wisdom. 

#### Job 13:6 Hear the reproof of my mouth; {the judgment and of my lips heed}! 

#### Job 13:7 Is it not against the LORD you speak, and before him you utter a sound of deceit? 

#### Job 13:8 Or will you keep back? But you yourselves {judges become}! 

#### Job 13:9 Is it good if he should track you; for as if {all things the ones doing} shall you be added to him; 

#### Job 13:10 in not one thing less shall he reprove you; but if also {secretly at persons you shall wonder}. 

#### Job 13:11 Is it not in his awfulness that he shall whirl you, and fear of him shall fall upon you? 

#### Job 13:12 {shall turn out But your prancing} equal to ashes, and the body to clay. 

#### Job 13:13 Be silent, that I shall speak, and rest my rage! 

#### Job 13:14 Taking my flesh in my teeth, {life even my I shall put} in my hand. 

#### Job 13:15 Though {me should lay hands against the mighty one}, since even he begins, in fact I shall speak and reprove before him. 

#### Job 13:16 And this {to me shall result in deliverance}; {not for before him treachery shall enter}. 

#### Job 13:17 Hear, hear my words! for I will announce in your hearing. 

#### Job 13:18 Behold, I am near my judgment; I know that {just I shall appear}. 

#### Job 13:19 For who is the one passing judgment to me, that now I shall be silent and shall cease? 

#### Job 13:20 But two things you shall furnish to me, then from your presence I will not hide. 

#### Job 13:21 Let your hand {from me be at a distance}! and {in the fear of you let me not be struck with terror}! 

#### Job 13:22 Then you shall call, and I will hearken to you; or you shall speak, and I will give you an answer. 

#### Job 13:23 How many are my sins, and my lawless deeds? Teach me what they are! 

#### Job 13:24 Why {from me do you hide}; and esteem me contrary to you? 

#### Job 13:25 Or as a leaf moving by the wind, will you be cautious of me? or as grass borne by the wind, will you be adverse to me? 

#### Job 13:26 For you wrote down against me bad things, and you invested to me youthful sin. 

#### Job 13:27 And you put my foot under restraint; and you watched all my works; and into the roots of my feet you attained. 

#### Job 13:28 I am the one turning old equal to a leather bag, or as {garment a moth-eaten}. 

#### Job 14:1 For a mortal born of a woman is short-lived and full of wrath. 

#### Job 14:2 Or as the flower blooming he falls off; and he runs away as a shadow, and in no way stands. 

#### Job 14:3 Have you not also {an account of this one made}, and made this one to enter before you in judgment? 

#### Job 14:4 For who will be clean from filth? but no one; 

#### Job 14:5 if even {be one day his existence} upon the earth, {are counted and his months} by you. {for a time You appointed him}, and in no way shall he pass beyond. 

#### Job 14:6 Separate from him! that he should be still, and he shall think well of the existence as the hireling. 

#### Job 14:7 For there is {for a tree hope}; for if it should be cut down, still it will bloom again, and its tender branch in no way shall fail; 

#### Job 14:8 for if {should grow old in the earth its root}, {in and the rock should come to an end its trunk}; 

#### Job 14:9 from the scent of water it shall bloom, and shall produce a harvest as if newly planted. 

#### Job 14:10 But a man coming to an end is undone; {falling and a mortal} is no longer. 

#### Job 14:11 For in time {is depleted a sea}, and a river being made desolate is dried up. 

#### Job 14:12 But man going to sleep shall certainly not rise up, until whenever the heaven in no way shall be sewn together, and they shall not wake up from their sleep. 

#### Job 14:13 For ought in Hades you guarded me, and hid me until whenever {should cease your anger}; and should have ordered for me a time in which {mention of me you shall make}. 

#### Job 14:14 For if {should die a man}, shall he live again having completed the days of his existence? I shall wait until {again I should exist}. 

#### Job 14:15 Then you shall call, and I will hearken to you; but the works of your hands do not undo. 

#### Job 14:16 But you counted my practices, and in no way shall there go by you even one of my sins. 

#### Job 14:17 And you set a seal upon my lawless deeds in a bag, and marked if in anything {unwillingly I violated}. 

#### Job 14:18 And moreover a mountain falling shall fall into ruin, and a rock shall be worn old from out of its place. 

#### Job 14:19 {stones smooth ground Waters}, and {flooded waters} the steeps of the embankment of the earth; and {the endurance of man you destroyed}. 

#### Job 14:20 You thrust him through unto the end, and he is undone; you set {against him your face}, and send him out. 

#### Job 14:21 And though there are many {being born of his sons}, he knows it not; if also {few they become}, he knows not. 

#### Job 14:22 But his flesh aches, and his soul mourns. 

#### Job 15:1 And undertaking, Eliphaz the Temanite says, 

#### Job 15:2 Is it that a wise man {an answer will give} of an understanding spirit, and filled up the misery of the womb, 

#### Job 15:3 reproving in sayings {in which must not be spoken with words}, in which no one benefits? 

#### Job 15:4 And did you not undo fear, and complete {sayings such} before the LORD? 

#### Job 15:5 You are liable by the sayings of your mouth, of which you litigated sayings of mighty ones. 

#### Job 15:6 May {reprove you your mouth}, and not I. And your lips, may they bear witness against you. 

#### Job 15:7 For what, are you the first man born? or {before the hills were you banked up}? 

#### Job 15:8 {the arranged order of the LORD have you heard}? and unto you {arrived wisdom}? 

#### Job 15:9 For what do you know, which we do not know? or what do you perceive, which {do not also we}? 

#### Job 15:10 And indeed an elder, and indeed an old one is among us, more weighty than your father, in days. 

#### Job 15:11 {but little for your sins You have been whipped}, but greatly above measure have you spoken. 

#### Job 15:12 What did {dare your heart}? or what have {added to see your eyes}, 

#### Job 15:13 that your rage tore before the LORD, and {led forth from out of your mouth sayings such}? 

#### Job 15:14 For who, being a mortal, still will be blameless? or {as being just who is born of a woman}? 

#### Job 15:15 forasmuch as {the holy ones he trusts not}, and the heaven is not pure before him. 

#### Job 15:16 Alas then, {is abhorrent and unclean man}, drinking iniquity equal to a beverage. 

#### Job 15:17 But I will report to you, hear me! What indeed I have seen, I will report to you -- 

#### Job 15:18 what the wise men shall say, and what was not hidden from their fathers. 

#### Job 15:19 To them alone {was given the earth}, and no {came foreigner} upon them. 

#### Job 15:20 All the existence of the impious is spent in bewilderment; and the years {are counted being given to the mighty one}, 

#### Job 15:21 and his fear is in his ears. Whenever the impious should seem already at peace, {shall come his undoing}. 

#### Job 15:22 Let him not trust to return from darkness, for he has been given charge already unto the hands of iron. 

#### Job 15:23 And he has been delegated for the grain of vultures, and he knows in himself that he waits for being a corpse; {day and a dark} shall whirl him away. 

#### Job 15:24 And distress and affliction shall hold him down. {is as a commandant of the front rank His falling down}. 

#### Job 15:25 For he has lifted hands against the LORD, and before the almighty he stiffened his neck. 

#### Job 15:26 And he ran against his insolence with the thickness of the back of his shield. 

#### Job 15:27 For he covered his face with his fat, and made a cleft upon the thighs. 

#### Job 15:28 And may he be lodged {cities in desolate}, and enter {houses uninhabited}; and what these prepared, others shall carry away. 

#### Job 15:29 Nor shall he be enriched, nor shall {remain his possessions}; in no way shall he cast {upon the earth a shadow}. 

#### Job 15:30 Neither shall he flee from the darkness; {his bud may wither wind}, {may fall off and his flower}. 

#### Job 15:31 Let him not trust that he will remain behind, for emptiness shall result to him. 

#### Job 15:32 His pruning {before its season shall be corrupted}, and his tender branch in no way shall become dense. 

#### Job 15:33 And may he be gathered as an unripe grape before its season; and may he fall off as the flower of the olive. 

#### Job 15:34 {is the testimony For of an impious man death}, and fire shall burn the houses of the ones taking bribes. 

#### Job 15:35 {in the womb And he shall conceive griefs}, and there shall result unto him emptiness, and his belly shall endure deceit. 

#### Job 16:1 And undertaking, Job says, 

#### Job 16:2 I have heard {such things many}. {comforters bad You are all}. 

#### Job 16:3 For what, {order is there} in words of wind? or what shall it trouble you that you answer? 

#### Job 16:4 I also {as you could speak} if {laid indeed your life} instead of my life. So then I shall assail against you with words, and I will shake {as you my head}. 

#### Job 16:5 And may that there be strength in my mouth, {the movement then of my lips I would not spare}. 

#### Job 16:6 For if I shall speak {shall not ache my wound}; and if also I keep silent, how less will I be pierced? 

#### Job 16:7 But now, {me exhausted he has made}, {moron a festering}, and it took hold of me. 

#### Job 16:8 For {a testimony I became}, and {rose up in me my lie}; according to my face it was answered. 

#### Job 16:9 In anger the one dealing with me cast me down; he gnashed against me with his teeth; the arrows of his marauders {upon me have fallen}; 

#### Job 16:10 {points of his eyes he assailed me with the sharp}; he smote me onto my knees; and with one accord they ran upon me. 

#### Job 16:11 {delivered For me the LORD} into the hands of the unjust, and unto the impious he tossed me. 

#### Job 16:12 Making peace he effaced me; taking me by the hair of the head he plucked it out; he placed me as if an exemplar. 

#### Job 16:13 They encircled me with lances, casting into my kidney, not sparing; they poured out {onto the earth my bile}. 

#### Job 16:14 They threw me down, downfall upon downfall; they ran against me prevailing; 

#### Job 16:15 {sackcloth they sewed} upon my hide; and my strength {in the ground was extinguished}. 

#### Job 16:16 My belly burns from weeping, and upon my eyelids a shadow of death. 

#### Job 16:17 {unjust thing And not one there was} in my hands, {vow and my} is pure. 

#### Job 16:18 O earth, you should not cover over the blood of my flesh, nor may there be a place for my cry. 

#### Job 16:19 And now behold, {is in the heavens my witness}, and my joint witness is in the highest. 

#### Job 16:20 May {arrive my supplication} unto the LORD, and before him may {drip tears my eye}. 

#### Job 16:21 And may it be reproof to man before the LORD, and to a son of man to his neighbor. 

#### Job 16:22 {years But counted} have come; and in the way in which I shall not be returned -- I shall go. 

#### Job 17:1 I am destroyed, {by a wind being borne}; and I beseech a burial, and attain it not. 

#### Job 17:2 {I implore In wearying}, for what shall I do? {stole and my possessions strangers}. 

#### Job 17:3 Who is this to my hand tied together? 

#### Job 17:4 For {their heart you hid} from intellect; on account of this, in no way shall you exalt them. 

#### Job 17:5 {in portion He shall announce evils}; and eyes upon sons were melted away. 

#### Job 17:6 But you appointed me for a common topic among the nations, {as laughter and for them I resulted}. 

#### Job 17:7 {are calloused For from wrath my eyes}; I have been assaulted greatly by all. 

#### Job 17:8 Wonder held true men over these things; {the just and against the lawbreaker may rise up}. 

#### Job 17:9 {may hold But the trustworthy} his own way; {the clean and hands may} take courage. 

#### Job 17:10 But however, let all be established and come indeed! {not for I do find} among you a true one. 

#### Job 17:11 My days go by in groaning, {were torn and the articulations of my heart}. 

#### Job 17:12 {night for day I put}; the light is near from the face of darkness. 

#### Job 17:13 For if I remain, Hades is my house; and in dimness I will make my strewn bed. 

#### Job 17:14 {death I called upon father to be my}; {mother and my to be and sister rottenness}. 

#### Job 17:15 Where then is my hope? or {my good shall I see}? 

#### Job 17:16 or {with me into Hades will they go down}? or with one accord {unto the embankment shall we go down}? 

#### Job 18:1 And undertaking, Baldad the Shuhite says, 

#### Job 18:2 Until when will you cease? Wait! that also {to these things we should speak}. 

#### Job 18:3 Why as if four-footed beasts do we keep silent before you? 

#### Job 18:4 {has dealt with you Anger}. For what if you should die, will it be uninhabited under heaven? or shall {be eradicated mountains} from their foundations? 

#### Job 18:5 But the light of the impious shall be extinguished, and {shall not turn out to be their flame}; 

#### Job 18:6 his light will be darkness in his habitation, and the lamp over him shall be extinguished. 

#### Job 18:7 May {hunt the least of men} his possessions; {may trip him and his counsel}. 

#### Job 18:8 {may be put And his foot} in a snare; {in a net may he be coiled}; 

#### Job 18:9 and may there come upon him snares; {shall grow strong against him ones thirsting}. 

#### Job 18:10 {is hidden in the earth His line}, and the thing seizing him is upon the roads. 

#### Job 18:11 {round about May destroy him griefs}, {many things and around his foot may come}. 

#### Job 18:12 {in hunger severe downfall But for him is prepared an extraordinary}. 

#### Job 18:13 And may {be devoured the soles of his feet}, {shall devour and his beautiful things death}. 

#### Job 18:14 {may be torn And from his habitation healing}; and may he have himself distress by reason of a royal decree. 

#### Job 18:15 It shall encamp in his tent in his night; {shall be scattered his beautiful things} with sulphur. 

#### Job 18:16 {from beneath His roots shall be dried}, and on top {shall fall his harvest}. 

#### Job 18:17 {his memorial May} be destroyed from the earth, and what exists to his name upon the face outer. 

#### Job 18:18 May one thrust him from light unto darkness; and from the inhabitable world they displaced him. 

#### Job 18:19 He will not be well known among his people, nor {be preserved in the place under heaven will his house}. 

#### Job 18:20 But in his house {shall live others}; {for him moaned the last}, and the first had wonder. 

#### Job 18:21 These are the houses of the unjust, and this is the place of the ones not knowing the LORD. 

#### Job 19:1 And undertaking, Job says, 

#### Job 19:2 For how long {weary will you make my soul}, and demolish me with words? Know only! that the LORD did thus with me. 

#### Job 19:3 You speak ill of me; not being ashamed by me, you press upon me. 

#### Job 19:4 Yes indeed, in truth I was misled, {in me and lodges delusion}, to speak a word which must not be said; but my words mislead, and are not in time. 

#### Job 19:5 But alas, for {against me you magnify yourselves}, and you assail me in scorn. 

#### Job 19:6 Know then! that the LORD is the one disturbing; {fortress and his against me he raised up high}. 

#### Job 19:7 Behold, I laugh at scorn, and I shall not speak; I shall have cried out, and not at all is there judgment. 

#### Job 19:8 {round about I have been enclosed}, and in no way shall I pass over; {upon my face darkness he put}. 

#### Job 19:9 And the glory of mine {from me he took off}, and removed the crown from my head. 

#### Job 19:10 He pulled me apart round about, and I am set out; and he cut down {as if a tree my hope}. 

#### Job 19:11 {awfully And me in anger he treated}, and he led me as if an enemy. 

#### Job 19:12 And with one accord {came his marauders} against me; in my ways {encircled me ones lying in wait}. 

#### Job 19:13 {me brothers My left}; they know strangers rather than me; {friends and my unmerciful have become}. 

#### Job 19:14 {not to know pretend me The ones near me}, and the ones knowing my name forgot me. 

#### Job 19:15 As for the neighbors of the house, {female attendants and also my}, I was foreign before them. 

#### Job 19:16 {attendant I called my}, and he obeyed not; {mouth and my} beseeched him. 

#### Job 19:17 And I entreated my wife; and I called -- flattering the sons of my concubines. 

#### Job 19:18 But they {into the eon undid me}; whenever I rise up, {against me they speak}. 

#### Job 19:19 {abhorred me The ones knowing me}; whom indeed I had loved, rose up against me. 

#### Job 19:20 {in my skin festers My flesh}; and the things of my bones {in teeth are held}. 

#### Job 19:21 Show mercy on me, show mercy on me, O friends! {the hand for of the LORD touching me it is}. 

#### Job 19:22 And why do you pursue me as also the LORD, {with and my flesh you are not filled up}? 

#### Job 19:23 For what that {might be given to be written my words}, and to put them in a scroll for the eon; 

#### Job 19:24 written with a stylus of iron and on lead, or {on a rock being engraved}. 

#### Job 19:25 For I know that {everlasting is the one to enfeeble me being about} upon the earth, 

#### Job 19:26 to raise up my skin being fatigued by these things. For by the LORD these things was exhausted on me, 

#### Job 19:27 which I myself am conscious of, which my eye has seen, and not another; but all {on me has been exhausted} in my bosom. 

#### Job 19:28 But if even you shall say, What shall we say before him, and {the root of the matter so find} in him? 

#### Job 19:29 Venerate even to yourselves from a covering! For rage {upon the lawless ones shall come}, and then they shall know where {is their material}. 

#### Job 20:1 And undertaking, Sophar the Minean says, 

#### Job 20:2 Not so far have I undertook to contradict you in these things, and neither do you perceive more than I. 

#### Job 20:3 {instruction for making me ashamed I will hearken to}; and the spirit of understanding answers me. 

#### Job 20:4 Have {these things you known} from the yet of which time {was put man} upon the earth? 

#### Job 20:5 For the gladness of the impious {downfall is an extraordinary}; and a cause for joy of the lawbreakers is destruction. 

#### Job 20:6 If {should ascend into heaven his gifts}, and his sacrifice {the clouds should touch}; 

#### Job 20:7 for whenever he should seem already firmly fixed, then {unto the end he shall perish}; and the ones knowing him shall say, Where is he? 

#### Job 20:8 As if a dream spreading forth, in no way shall he be found; so he flys as if {manifestation a nightly}. 

#### Job 20:9 The eye overlooked, and does not proceed, and {no longer pays attention to him his place}. 

#### Job 20:10 {his sons May destroy his inferiors}, and may his hands light the fire of griefs. 

#### Job 20:11 His bones were filled with the vigor of his youth, and {with him upon the embankment it shall go to bed}. 

#### Job 20:12 Though {should be sweet in his mouth evil}, he shall hide it under his tongue, 

#### Job 20:13 and he shall not spare it, and will not abandon it, but brings it in the midst of his throat. 

#### Job 20:14 Yet in no way shall he be able to help himself; the bile of an asp is in his belly. 

#### Job 20:15 His riches unjustly brought together shall be vomited forth. From out of his house {shall drag him away an angel}. 

#### Job 20:16 {the rage And of dragons may he nurse}; {may do away with and him the tongue of a serpent}. 

#### Job 20:17 May he not behold the milking of grazing animals, nor the pastures of honey and butter. 

#### Job 20:18 For {in emptiness and vanity he tired for riches}, of which he shall not taste; it is as if tough, unchewable, and impotable. 

#### Job 20:19 {of many For of the disabled the houses he crushed}; and a habitation he seized by force, and he established it not. 

#### Job 20:20 {is not His safety} in the possessions; by his desire he will not escape. 

#### Job 20:21 There is no leftover of his foods; on account of this {shall not bloom his good things}. 

#### Job 20:22 And whenever it should seem urgent to accomplish something, he shall be afflicted; and all distress {upon him shall come}. 

#### Job 20:23 If by any means he might fill his belly, let God send as a successor upon him the rage of anger; may {wash over him griefs}. 

#### Job 20:24 And in no way shall he be delivered from the hand of iron; may {pierce him the bow of brass}; 

#### Job 20:25 {may go completely and through his body the arrow}; {the stars and on his habitation may walk}; {upon him may fears be}. 

#### Job 20:26 {all And darkness for him may wait}; {shall devour him fire inextinguishable}; {may inflict evil on and his a stranger} house. 

#### Job 20:27 {may uncover And his the heaven} lawless deeds; and the earth rise up against him. 

#### Job 20:28 May {draw his house destruction} unto the end; {the day of anger may} come upon him. 

#### Job 20:29 This is the portion {man of an impious} from the LORD, and the possession of his substance given to him by the overseer. 

#### Job 21:1 And undertaking, Job says, 

#### Job 21:2 Hear, hear my words! that there should be to me {from you this comfort}. 

#### Job 21:3 Lift me! and I will speak, then you shall not ridicule me. 

#### Job 21:4 For what, is {from man my rebuke}? or why shall I not be enraged? 

#### Job 21:5 O ones looking at me, wonder {your hand while putting} upon your jaw. 

#### Job 21:6 For even if I should remember, I hurry, {hold and the things of my flesh griefs}. 

#### Job 21:7 Why do the impious live, and they grow old, and in riches? 

#### Job 21:8 Their sowing is according to their soul's desire; and their children in eyes. 

#### Job 21:9 Their houses prosper, and fear is not to them at all; and the whip of the LORD is not upon them. 

#### Job 21:10 Their ox does not bring forth prematurely, {are preserved and their ones pregnant} to have, and not to trip. 

#### Job 21:11 And they remain as {sheep everlasting}, and their children play before them, 

#### Job 21:12 taking up the psaltery and harp, and they are gladdened at the sound of a psalm. 

#### Job 21:13 And they complete {with good things their existence}, and in the rest of Hades they go to sleep. 

#### Job 21:14 And he says to the LORD, Separate from me! {your ways to know I do not want}. 

#### Job 21:15 What is fit that we shall serve him? and what benefit, that we shall meet with him? 

#### Job 21:16 {in hands For were not to him the good things}; but works of the impious he does not inspect. 

#### Job 21:17 But in fact, even {of the impious the lamp} shall be extinguished, and there shall come upon them the final event, and pangs from them they shall have from anger. 

#### Job 21:18 And they will be as straw before the wind, or as a cloud of dust which {took up the tempest}. 

#### Job 21:19 May {fail his sons his possessions}; and God shall recompense to him, and he shall know it. 

#### Job 21:20 May {behold his eyes} his own slaughter; and by the LORD may he not be delivered. 

#### Job 21:21 For his will is in his house with him, and the numbers of his months were divided. 

#### Job 21:22 Is it not the LORD who is the one teaching understanding and higher knowledge? And is it not he who {the wise litigates}. 

#### Job 21:23 This one shall die in the might of his singleness of purpose, but entirely enjoying pleasure and prospering; 

#### Job 21:24 and his insides are full of fat, {marrow and his} is diffused in him. 

#### Job 21:25 And another one comes to an end in bitterness of soul, not eating anything good. 

#### Job 21:26 But in one accord upon the earth they sleep, and rottenness covers them. 

#### Job 21:27 So as I know you, that you daringly press upon me; 

#### Job 21:28 that you shall say, Where is the house of the ruler? and where is the protection of the tents of the impious? 

#### Job 21:29 Ask the ones passing by the way, and {their signs you shall not separate from}. 

#### Job 21:30 For unto the day of destruction {lightens the wicked one}; for the day of his anger he shall be taken away. 

#### Job 21:31 Who will report unto his face his way? And what he did, who shall recompense to him? 

#### Job 21:32 And he {unto the tombs was carried away}; and {upon the heaps stayed awake}. 

#### Job 21:33 {was sweet to him The gravel of the rushing stream}, and after him every man shall go forth, and in front of him there are innumerable ones. 

#### Job 21:34 And how do you comfort me in vain? but for me to rest from you is nothing. 

#### Job 22:1 And undertaking, Eliphaz the Temanite says, 

#### Job 22:2 Is it not the LORD that is the one teaching understanding and higher knowledge? 

#### Job 22:3 For what does it concern the LORD if you were {in works blameless}, or what benefit that you simplify your way? 

#### Job 22:4 or {your word making} will he reprove you? and will he enter together with you for judgment? 

#### Job 22:5 Is it not that your evil is much, {innumerable and your are sins}? 

#### Job 22:6 And you took security of your brethren without cause, {clothing and of the naked you removed}. 

#### Job 22:7 Nor {water for the thirsting did you give to drink}, and {of ones hungering you deprived a morsel}. 

#### Job 22:8 And you admired the faces of some; you resettled the poor upon the earth; 

#### Job 22:9 {widows and you sent out} empty, {on orphans and you inflicted evil}. 

#### Job 22:10 Accordingly {encircled you snares}, and {hurried you war an extraordinary}. 

#### Job 22:11 The light {for you darkness resulted in}; and in going to sleep water covered you. 

#### Job 22:12 Is it not that the one {the high places inhabiting} inspects? {the ones and insolence bearing he humbled}? 

#### Job 22:13 And you said, What does {know the mighty one}? or {in the dark does he judge}? 

#### Job 22:14 A cloud is his concealment, and he shall not be seen; and the curve of heaven he travels over. 

#### Job 22:15 {not road the eternal Will you guard} which {trod men unjust}? 

#### Job 22:16 The ones who were seized untimely are as a river overflowing their foundations. 

#### Job 22:17 The ones saying, The LORD, what will he do to us? or what will {bring upon us the almighty}? 

#### Job 22:18 And he is the one who filled up their houses with good things; but the counsel of the impious is at a distance from him. 

#### Job 22:19 In beholding, the just laugh; and the blameless one sneers at them. 

#### Job 22:20 Except {vanished their support}, and {their vestige shall devour fire}. 

#### Job 22:21 Become firm indeed! if you should remain, so that your fruit will be for good things. 

#### Job 22:22 And take {from out of his mouth an utterance}! and take up his sayings in your heart! 

#### Job 22:23 And if you should turn and humble yourself before the LORD, {to be a distance then you made from your habitation wrongdoing}. 

#### Job 22:24 You shall put upon an embankment in rock, even as a rock of a rushing stream of Ophir. 

#### Job 22:25 {will be Then your the almighty} helper from the enemies, {clean and he will render you} as {silver purified}. 

#### Job 22:26 So then, you shall speak openly before the LORD, looking up into the heaven happily. 

#### Job 22:27 {vowing And of your} to him, he will listen to you; and he will give to you power to render the vows. 

#### Job 22:28 And he will restore to you a habitation of righteousness, and upon your ways will be brightness. 

#### Job 22:29 For one humbled himself; and you shall say, He is prideful, but the one having downcast eyes, he shall deliver. 

#### Job 22:30 He shall rescue the innocent; but be delivered in {cleanness of hands your}! 

#### Job 23:1 And undertaking Job says, 

#### Job 23:2 For indeed I know that {out of my hand my rebuke is}; and his hand {heavy has become} over my moaning. 

#### Job 23:3 But who is it that may know that I might find him, and that I might come to the end of the matter? 

#### Job 23:4 And I might speak {for myself judgment}, and with my mouth I shall fill up reproofs. 

#### Job 23:5 And then I may know the cure which he shall speak to me, and then I may perceive what he shall report to me. 

#### Job 23:6 And if in much strength he shall come upon me, so then {with intimidation me he shall not treat}. 

#### Job 23:7 For truth and reproof are from him; and may he bring {unto my end equity}. 

#### Job 23:8 For at first I shall go, and no longer am I; and the things of the latter end, what do I know? 

#### Job 23:9 {with the left hand In his acting}, I cannot hold back; he covers the right hand, and I shall not see it. 

#### Job 23:10 For he knows {already my way}; he examined me as the gold. 

#### Job 23:11 And I shall go forth in his precepts, {ways for his} I kept; and in no way shall I turn aside from his precepts; 

#### Job 23:12 and in no way shall I pass by them; and in my bosom I hid his sayings. 

#### Job 23:13 But if even he judged thus, who is the one contradicting him; for he wanted and did. 

#### Job 23:14 On account of this, {unto him I have hastened}; and being admonished, I thought of him. 

#### Job 23:15 Over this {his face I should take} seriously; I shall contemplate and shall be terrified of him. 

#### Job 23:16 But the LORD softened my heart, and the almighty hastened me. 

#### Job 23:17 {not For I knew} that {shall come upon me darkness}; {before face and my covered dimness}. 

#### Job 24:1 And why did {by the LORD not escape notice the seasons}? 

#### Job 24:2 And the impious {the border passed over}, {a flock with shepherd seizing}. 

#### Job 24:3 {a beast of burden And} of orphans they took away, and oxen of widows for security. 

#### Job 24:4 They turned aside the disabled from {way the just}; with one accord {was hidden the gentle of the earth}. 

#### Job 24:5 And they resulted as if donkeys in the field {for me going forth} on their own action; {is delicious their bread for the young}. 

#### Job 24:6 {a field before its season not being their own They harvested}; and the disabled {the vineyards of the impious without pay and without eating worked}. 

#### Job 24:7 {naked many They rested} without clothes; {clothing and necessary for their life they removed}. 

#### Job 24:8 From the mists of the mountains they are wetted; from {not holding to them protection} {with rock they covered themselves}. 

#### Job 24:9 They seized the orphan from the breast, {the one falling off and they humbled}. 

#### Job 24:10 And of naked ones they rested wrongfully, and of ones hungering {the morsel they removed}. 

#### Job 24:11 In narrows they wrongly lie in wait; and the way of the just they knew not. 

#### Job 24:12 The ones from the city and {houses the ones of their own} they cast out; and the soul of the infants moaned greatly. 

#### Job 24:13 {did he But why these in overseeing} not act {upon the earth in their being}? and they did not recognize, and the way of righteousness they knew not, nor {by their short-cuts were gone}. 

#### Job 24:14 But knowing their works he delivered them unto darkness; and night will be as a thief. 

#### Job 24:15 And the eye of the adulterer watched for the darkness, saying, {will not think of me beforehand The eye}; and {a concealment for his face he put}. 

#### Job 24:16 {he dug through In darkness} houses; by day they seal up themselves. they do not know the light. 

#### Job 24:17 For with one accord to them in the morning is the shadow of death; for each shall realize the disturbances of the shadow of death. 

#### Job 24:18 He is light upon the face of the water; may {be cursed their portion} upon the earth; {may appear and their plants 

#### Job 24:19 upon the earth dry}; for armfuls of orphans they seized by force. 

#### Job 24:20 So then {is called to mind his sin}, and as fog of dew {vanishes he}; and may it be recompensed to him what he acted; {may be destroyed and every unjust one} equally {wood as incurable rotten}. 

#### Job 24:21 For the sterile woman {not well he did do}, and on the helpless woman he did not show mercy. 

#### Job 24:22 And in rage he overturned the disabled; {in rising up accordingly}, in no way shall he trust in his own life. 

#### Job 24:23 In being infirm, let him not hope to be healed! but he shall fall in disease. 

#### Job 24:24 {many For afflicted his arrogance}; but he withered as a mallow plant in sweltering heat, and as an ear of corn {from the stubble by itself falling off}. 

#### Job 24:25 But if not, who is the one saying {falsely for me to speak}, and he renders {as nothing my words}? 

#### Job 25:1 And undertaking, Baldad the Shuhite says, 

#### Job 25:2 For what retort or fear is his -- the one making all things in the highest? 

#### Job 25:3 For let not any undertake the thought that there is deferment for marauders. {upon whom And} will there not come an ambush from him? 

#### Job 25:4 For how shall {be just a mortal} before the LORD? or who may cleanse himself born of a woman? 

#### Job 25:5 If {the moon he should order}, then it does not shine; and the stars are not pure before him. 

#### Job 25:6 But alas, man is rottenness, and the son of man a worm. 

#### Job 26:1 And undertaking, Job says, 

#### Job 26:2 To whom do you lie near to, or to whom are you about to help? Is it not the one who has much strength, and whose arm is fortified? 

#### Job 26:3 By whom have you been advised, is it not to the one who has all wisdom? or to whom will you follow after, is it not the one who has greatest power? 

#### Job 26:4 To whom did you announce words? {breath and whose} is it that comes forth from you? 

#### Job 26:5 Shall giants act as midwife from beneath the water, and for his neighbors? 

#### Job 26:6 {is naked Hades} before him, and there is no wrap-around garment for destruction. 

#### Job 26:7 He stretches out the north wind upon nothing, and hangs the earth upon nothing; 

#### Job 26:8 binding water in his clouds, and {is not torn the cloud} underneath it; 

#### Job 26:9 holding back the front of his throne, spreading {over it his cloud}. 

#### Job 26:10 By order he made the curvature upon the face of the water till the completion of light with darkness. 

#### Job 26:11 The columns of heaven are spread out, and are startled at his reproach. 

#### Job 26:12 By strength he rested the sea, and by higher knowledge he spread forth for the whale. 

#### Job 26:13 And the bolts of heaven are in awe of him; {order and by his} he put to death the dragon defector. 

#### Job 26:14 Behold, these are the parts of his way; and at the exhalation of his word we hearken to him; {the strength and of his thunder who knows when he will execute}? 

#### Job 27:1 And still Job proceeded and said in the retort. 

#### Job 27:2 {lives God} who thus has judged me, even the almighty, the one embittering my soul; 

#### Job 27:3 is it not yet of my breath to be in me, {breath and the divine} remains to me in my nostrils? 

#### Job 27:4 {shall not speak My lips} lawless things, nor {my soul shall} meditate upon wrongdoing. 

#### Job 27:5 May it not be to me {as just ones you to sentence}. Until whenever I die {not for I will} dismiss from me my innocence, 

#### Job 27:6 {to my righteousness and taking heed} in no way will I let it go; {not for I am fully conscious myself} {out of place of acting}. 

#### Job 27:7 No rather, but may {be my enemies} as the undoing of the impious, and the ones {against me rising up} as the destruction of the lawbreakers. 

#### Job 27:8 For what is the hope of the impious that he waits for? {in yielding upon the LORD Is it} that he shall be delivered? 

#### Job 27:9 or {his supplication will listen to God}? or when {comes upon him necessity}, 

#### Job 27:10 shall he hold any confidence before him? or as one calling upon him, shall he listen to him? 

#### Job 27:11 But indeed, I will announce to you what is in the hand of the LORD; the things which are by the almighty I shall not lie about. 

#### Job 27:12 Behold, you all know that {vanity upon vanity you put}. 

#### Job 27:13 This is the portion {man of an impious} from the LORD, and the possession of mighty ones shall come from the almighty upon them. 

#### Job 27:14 And if {many become his sons}, {for slaughter they will be}; and if even they should arrive at manhood they shall beg. 

#### Job 27:15 And the ones remaining of his {in plague shall come to an end}; {widows and on their no one shall show mercy}. 

#### Job 27:16 If he should have gathered together {as earth silver}, and equally {as mortar shall prepare gold}, 

#### Job 27:17 all these things the just shall procure, and of his things the true ones will control. 

#### Job 27:18 {turned out to be And his house} as if for a moth, and as if for a spider. 

#### Job 27:19 The rich man shall sleep, and shall not proceed; his eyes are opened wide, and he is no longer. 

#### Job 27:20 {meet up with him as if water Griefs}; and by night {takes him the dark}. 

#### Job 27:21 {takes him A burning wind}, and he shall go forth; and it shall winnow him from out of his place. 

#### Job 27:22 And he shall cast upon him, and shall not spare; {from out of his hand exile he shall flee into}. 

#### Job 27:23 He shall cause man to clap {against him his hands}, and he shall whistle at him from out of his place. 

#### Job 28:1 For there is {for silver a place} from where it exists, and a place for gold from where it is refined. 

#### Job 28:2 {iron For from out of the earth comes}, and brass equally {like stone is quarried}. 

#### Job 28:3 {an order He established} for darkness, and every limit he determines exactly; {is as a stone darkness and the shadow of death}. 

#### Job 28:4 There is a breach of the rushing stream from powder; and the ones forgetting {way the just} are weakened; of mortals -- they are shaken. 

#### Job 28:5 As for the earth, out of it shall come forth bread; underneath it, it was turned as fire. 

#### Job 28:6 {are the place of the sapphire Her stones}; and {an embankment her gold}. 

#### Job 28:7 There is a road {not knows it the bird}; and {looked not over it the eye of the vulture}, 

#### Job 28:8 {not trod it the sons of ostentatious ones}; {not went upon it a lion}. 

#### Job 28:9 {in a chiseled place He stretched forth his hand}, and overturned {by the roots mountains}; 

#### Job 28:10 and the hill of rivers he tore up; {every and valuable thing beheld my eye}. 

#### Job 28:11 And the depths of the rivers he uncovered, and he shows his power in light. 

#### Job 28:12 But {is wisdom from what place} found? and of what place is higher knowledge? 

#### Job 28:13 {knows not A mortal} her way, in no way is she found among men. 

#### Job 28:14 The abyss said, She is not in me; and the sea said, She is not with me. 

#### Job 28:15 One shall not give an investment for her, and shall not set silver as a bargain for her. 

#### Job 28:16 And she shall not be compared with the gold of Ophir, with {onyx valuable} and sapphire. 

#### Job 28:17 {shall not be equal to her Gold and glass}, nor {as barter for her items of gold}. 

#### Job 28:18 Meteorites and crystal shall not be mentioned; but draw on wisdom above the innermost things. 

#### Job 28:19 {shall not be equal to her The topaz of Ethiopia}; {gold pure she shall not be compared with}. 

#### Job 28:20 But concerning wisdom, from what place shall she be found? and of what kind of place is understanding? 

#### Job 28:21 She has escaped notice of every man; and from the birds of the heaven she was hid. 

#### Job 28:22 Destruction and death said, We have heard of her fame. 

#### Job 28:23 God {well commended her way}; and he knows her place. 

#### Job 28:24 For he {under heaven inspects all things}, knowing the things in the earth; 

#### Job 28:25 all which he made, {of the winds even the weight}, {of water and the measures}. 

#### Job 28:26 When he made them, thus seeing he counted them, and made a way for the vibration of sound. 

#### Job 28:27 Then he beheld it, he described it; preparing he tracked it out. 

#### Job 28:28 And he said to man, Behold, godliness is wisdom; and being at a distance from evils is higher knowledge. 

#### Job 29:1 But still Job proceeding spoke the retort. 

#### Job 29:2 O that he might have put me according to the month before the days of which {me God guarded}; 

#### Job 29:3 as when {shone his lamp} over my head; when {by his light I went through darkness}; 

#### Job 29:4 when I was in the days of my youth; when God overseeing dealt with my house; 

#### Job 29:5 when I was {flush exceedingly}, and round about me were my children; 

#### Job 29:6 when {poured forth my ways} butter, and my mountains poured forth milk; 

#### Job 29:7 when I went forth at daybreak into the city, {in and the squares they placed my chair}. 

#### Job 29:8 In beholding me, the young men hid, {the old men and all} stood. 

#### Job 29:9 And the stout men ceased speaking, {their finger placing} to their mouth. 

#### Job 29:10 And the ones hearing declared me blessed; and their tongue {to their throat cleaved}. 

#### Job 29:11 For the ear heard, and blessed me; and the eye beholding me, turned aside. 

#### Job 29:12 For I delivered the poor from out of the hand of the mighty one; and the orphan in whom there was no helper, I helped. 

#### Job 29:13 {the blessing of the one perishing upon me May come}; for the mouth of the widow blessed me. 

#### Job 29:14 And righteousness I had put on, and I clothed on judgment equal to a double garment. 

#### Job 29:15 I was the eye of the blind, and the foot for the lame. 

#### Job 29:16 I was the father of the disabled; {the cause and which I knew not I tracked out}. 

#### Job 29:17 And I broke the molars of unjust ones; and from out of the midst of their teeth {the prey I pulled out}. 

#### Job 29:18 And I said, My stature shall grow old as the trunk of a palm; {with much time I shall spend life}. 

#### Job 29:19 The root was widened upon the water, and the dew lodged among my harvest. 

#### Job 29:20 My glory was new with me, and my bow {in his hand went forth}. 

#### Job 29:21 Men hearing of me took heed, and kept silent over my counsel. 

#### Job 29:22 At my word they proceeded not; {overjoyed but they became} when I spoke to them. 

#### Job 29:23 As the earth thirsting, favorably receiving the rain, so were these at my speech. 

#### Job 29:24 If I should have laughed on them, in no way should they have trusted the thing; and the light of my face was not fallen away. 

#### Job 29:25 I chose their way, and I sat as ruler; and I encamped as king among armed ones, in which manner {mourners comforting}. 

#### Job 30:1 And now {ridicule me the least of them}; now they admonish me in turn -- whom I treated {with contempt their fathers}, whom I did not esteem to be worthy of dogs of my grazing flocks. 

#### Job 30:2 And indeed, {is the strength of their hands what profit} to me? {of them It was destroyed} to completion. 

#### Job 30:3 In lack and hunger one is barren, as the ones fleeing waterless yesterday in conflict and misery. 

#### Job 30:4 The ones breaking off the marine plant upon the sounding shore, whose marine plants were for their grain; and were without honor, and being treated as worthless, lacking of every good thing; and the roots of trees gnawed because of {hunger great}. 

#### Job 30:5 {rose up against me Thieves}, 

#### Job 30:6 whom their houses were burrows of rocks. 

#### Job 30:7 {in the midst of distinct places shall yell the ones who under stick dwellings wild pass life}. 

#### Job 30:8 {of fools They are sons} and {without honor have a name}, and fame extinguished from the earth. 

#### Job 30:9 And now {harp I am their}, and {me for a common topic they have}. 

#### Job 30:10 And they abhorred me, separating far from me; and from my face they spared not spittle. 

#### Job 30:11 For having opened his quiver he afflicted me; and {the bridle of my presence sent away}. 

#### Job 30:12 {on the right hand of their offspring They rose up against me}. {his feet He stretched out} and opened against me; with paths of their destruction 

#### Job 30:13 they obliterated my paths; for he took off my apparel; with his spear he ran me through; 

#### Job 30:14 and he has judged me as he wills; in griefs I am befouled. 

#### Job 30:15 {return My griefs}; {was set out my hope} as if the wind, and {as if a cloud deliverance my}. 

#### Job 30:16 And now {upon me shall be poured out my soul}; {suffice and me days of griefs}. 

#### Job 30:17 And at night my bones burn, and my nerves are parted. 

#### Job 30:18 With great strength it took hold of my robe; as the cleft of my garment it compassed me. 

#### Job 30:19 And you have esteemed me equal to clay; in earth and ashes is my portion. 

#### Job 30:20 And I have cried out to you, and {not you hear me}; they stood and contemplated me. 

#### Job 30:21 And you mounted against me mercilessly; {hand with a strong you whipped me}. 

#### Job 30:22 And you arranged against me with griefs; and you threw me away from deliverance. 

#### Job 30:23 For I know that death will obliterate me; for the house of every mortal is ground. 

#### Job 30:24 For ought that I should be able {myself to lay hands upon}, or indeed beseech another and he should do this to me. 

#### Job 30:25 And I {over every disabled man wept}; and I moaned beholding man in necessities. 

#### Job 30:26 I waited for good things, and behold {met with me instead days bad}. 

#### Job 30:27 My belly erupted, and would not keep silent; {anticipated me days of poorness}. 

#### Job 30:28 {moaning I went} without a rein; and I have stood in the assembly crying out. 

#### Job 30:29 {a brother I have become} of sirens, and companion of ostriches. 

#### Job 30:30 My skin is darkened greatly, and my bones from sweltering heat. 

#### Job 30:31 {turned And into mourning my harp}, and my psalm into weeping for me. 

#### Job 31:1 {a covenant I made} with my eyes, and I will not take notice upon a virgin. 

#### Job 31:2 And what portion is from God above, and {inheritance what fit} is from the highest? 

#### Job 31:3 Woe, destruction to the unjust, and alienation to the one committing lawlessness. 

#### Job 31:4 Will he not see my way, and {all my footsteps count out}? 

#### Job 31:5 But if I was going with jokesters, or even hurrying my foot for treachery; 

#### Job 31:6 (for I stand in {yoke balance scale a just}, {knew and the LORD} my innocence); 

#### Job 31:7 if {turned aside my foot} from out of the way, or if even {my eye follows after my heart}, and if even my hands touched bribes; 

#### Job 31:8 {may I sow then}, and others eat; {rootless and may I become} upon the earth. 

#### Job 31:9 If {followed after my heart} the wife {man of another}, and if {laid in wait I had} at her doors; 

#### Job 31:10 {may please then even my wife} another; and {my infants may be humbled}. 

#### Job 31:11 For the rage of anger is unrestrained in the defiling of a man's wife. 

#### Job 31:12 {a fire For it is} burning upon all the parts; and whomever it may come upon {from the roots it destroyed}. 

#### Job 31:13 And if even I treated as worthless the equity due my male attendant or female attendant, in their pleading with me, 

#### Job 31:14 what then shall I do if {chastisement for me shall appoint the LORD}? and if also he should visit, what answer shall I make? 

#### Job 31:15 Were they not even as I, born in a womb? and these were born, and we were born in the same belly. 

#### Job 31:16 But the disabled {whatever need at some time or other they had missed not}; {of the widow and the eye I wasted not}. 

#### Job 31:17 And even if {my morsel I ate} alone, and {not with an orphan I shared of it}, 

#### Job 31:18 (for from my youth I nourished them as a father, and from the womb of my mother I guided); 

#### Job 31:19 and even if I overlooked the naked perishing, and clothed him not; 

#### Job 31:20 and the disabled, unless they blessed me, and of the shearing wool of my lambs {were not heated their shoulders}; 

#### Job 31:21 and if I lifted up {against an orphan a hand}, (relying that much {to me help remained}); 

#### Job 31:22 {may separate then my shoulder} from the collar-bone, and {my arm from the elbow may be broken}. 

#### Job 31:23 For the fear of the LORD constrained me; from his concern I shall not endure. 

#### Job 31:24 If I ordered up gold for my strength; and if even {stone very costly I relied upon}; 

#### Job 31:25 and even if {gladness great} in riches was coming to me; and if also {upon innumerable things I put my hand}; 

#### Job 31:26 (or do we not see {sun the shining} subsiding, and the moon waning? {no power For to them there is}). 

#### Job 31:27 And if {was deceived in private my heart}; and if {hand placing my upon my mouth I was fond of}; 

#### Job 31:28 then let this be {so to me lawlessness as the greatest imputed}; for I lied before the LORD of the highest. 

#### Job 31:29 And even if {gratified I became} at the calamitous downfall of my enemies; and said in my heart, Well done! 

#### Job 31:30 Let {hear then my ear} my curse, and may I then be a common topic by my people for my inflicting evil. 

#### Job 31:31 And if even often {said my female attendants}, Who ever might give to us his flesh to satisfy? exceedingly of my being gracious. 

#### Job 31:32 {outside for lodged not the stranger}, and my door {to all that came was open}. 

#### Job 31:33 And if even of sins, unintentionally I hid my sin, 

#### Job 31:34 (for I was not diverted {multitude by a great} to not openly declare before them); and if even I allowed a disabled man to go forth from my door {bosom with an empty}, 

#### Job 31:35 (oh that there might be given one to hear me), {of the hand but of the LORD unless I was in awe}; and as to a writ which I had against anyone, 

#### Job 31:36 {upon even my shoulders putting it on a crown} I read it. 

#### Job 31:37 And unless tearing it I gave it back {nothing having received} from a debtor. 

#### Job 31:38 If {against me perhaps the earth moaned}, and even if her furrows wept with one accord; 

#### Job 31:39 and even if of its strength I ate alone without value; and if even {of the life of the master of the land in taking anything} I fretted him; 

#### Job 31:40 instead of wheat then may there come forth to me nettles; and instead of barley a bush. And Job ceased words. 

#### Job 32:1 And they were quiet, and {three friends his} no longer contradicted Job, {was for Job} righteous before them. 

#### Job 32:2 {was provoked to anger And Elihu}, the son of Barachel, the Buzite, of the kin of Ram, of the place of Ausis; and he was provoked to anger against Job exceedingly, because he sentenced himself as righteous before the LORD. 

#### Job 32:3 {even against the three But} friends he was provoked to anger exceedingly, for they were not able to answer contrary to Job; and they established him to be an impious man. 

#### Job 32:4 And Elihu waited to give an answer to Job, for {older than he they were} in days. 

#### Job 32:5 And Elihu saw that there is no answer in the mouths of the three men, and {was enraged his anger}. 

#### Job 32:6 And undertaking, Elihu the son of Barachel the Buzite, said, {younger Forasmuch as I am} in time, and you are older; therefore I was still, fearing to announce to you the {of myself higher knowledge}. 

#### Job 32:7 And I said, {not time It is} for speaking; {in many but} years men have not known wisdom. 

#### Job 32:8 But there is a spirit in mortals, and the breath of the almighty is the one teaching. 

#### Job 32:9 {not The long-lived are} wise as such; and neither do the aged know equity. 

#### Job 32:10 Therefore I said, Hear me! and I will announce to you what I know. 

#### Job 32:11 Give ear to my sayings! for I will speak in your hearing, as far as of which time you should examine the words; 

#### Job 32:12 and until you shall perceive; and behold, there was no one reproving Job, in answering his words from you, 

#### Job 32:13 that you should not say, We found wisdom being added by the LORD. 

#### Job 32:14 {man And you commissioned} to speak such words. 

#### Job 32:15 And they were terrified. They answered not any longer; {were old coming from them words}. 

#### Job 32:16 I waited, for I did not speak, for they stood, they answered not. 

#### Job 32:17 And undertaking, Elihu says, Again I shall speak, 

#### Job 32:18 {full for I am} of words, {destroys for me the wind of the belly}; 

#### Job 32:19 and my belly is as if a leather bag of sweet new wine bubbling, being tied up; and as if the bellows of a brazier tearing forth. 

#### Job 32:20 I will speak that I shall rest myself in opening my lips. 

#### Job 32:21 {by man For in no way shall I be shamed}, and in fact, nor {from a mortal shall I in any way feel shame}. 

#### Job 32:22 {not For I know} to admire a person; but if not, even {me moths shall devour}. 

#### Job 33:1 But in fact, hear, O Job, my words, and {speech give ear to my}! 

#### Job 33:2 For behold, I opened my mouth, and {spoke my tongue}. 

#### Job 33:3 {is pure My heart} in words, and the understanding of my lips {pure shall purpose}. 

#### Job 33:4 {spirit divine The} made me, and the breath of the almighty is what is teaching me. 

#### Job 33:5 If you should be able, give to me an answer for these things! Wait, stand against me, and I against you! 

#### Job 33:6 From out of clay you were molded as also I; {from out of the same clay we were molded}. 

#### Job 33:7 {not in the fear of me You shall whirl about}, nor {my hand heavy shall be} upon you. 

#### Job 33:8 Except you said in my ears, {the voice of your words I have heard}, for you say, 

#### Job 33:9 I am pure, not having sinned; {blameless for I am}, for I did not act lawlessly. 

#### Job 33:10 {a complaint But against me he found}, and he has esteemed me as if an opponent. 

#### Job 33:11 And he put {in stocks of wood my foot}, and guarded all my ways. 

#### Job 33:12 For how say you, I am righteous, and he has not heeded me? {eternal For is the one above mortals}. 

#### Job 33:13 But you say, Why of my righteousness has he not heeded every word? 

#### Job 33:14 For when {once speaks the LORD}, or a second time, 

#### Job 33:15 sending a dream or in {meditation a nightly}, or as whenever {falls an awful fear} upon men, in slumberings upon a bed; 

#### Job 33:16 then he uncovers the mind of men in sights of fear; with such he frightens them, 

#### Job 33:17 to turn a man from iniquity, and {his body from a calamitous downfall he rescues}. 

#### Job 33:18 And he spares his soul from death, and spares {so as to not fall him} in war. 

#### Job 33:19 And again he reproves him by infirmity upon his bed, and {a multitude of his bones he paralyzed}. 

#### Job 33:20 {any And eatable grain in no way shall he be able to favorably receive}, even though his soul {food desires}; 

#### Job 33:21 until whenever {should fester his flesh}, and {should be exposed his bones} bare; 

#### Job 33:22 {approached and unto death his soul}, and his life unto Hades. 

#### Job 33:23 If there might be a thousand messengers causing death, one of them in no way shall pierce him, if he should purpose in his heart to turn towards the LORD, and announce to man his own complaint, and {his lawlessness should show}; 

#### Job 33:24 he shall hold him to not fall into death; and he shall renew his body as new plaster upon a wall; and {his bones he will fill up} with marrow. 

#### Job 33:25 He will make tender his flesh as an infant, and he shall restore him to manhood among men. 

#### Job 33:26 And one vowing to the LORD, and {accepted for him it will be}; and he shall enter {face with a clean}, with an utterance of praise; and he will recompense {to men righteousness}. 

#### Job 33:27 Even then shall {blame a man} himself, saying, What things have I completed? and {not worth he chastised me} what I sinned. 

#### Job 33:28 Deliver my soul! to not come unto corruption, that my life {light shall see}. 

#### Job 33:29 Behold, all these things {works the strong one ways three} with a man. 

#### Job 33:30 And he rescued my soul from death, that my life in light should praise him. 

#### Job 33:31 Give ear, O Job, and hear me! Be silent! for I myself shall speak. 

#### Job 33:32 If there are words in you, answer me! Speak! for I want justice to be done for you. 

#### Job 33:33 If not, you hear me! Be silent! and I will teach you wisdom! 

#### Job 34:1 And undertaking, Elihu says, 

#### Job 34:2 Hear me! O wise men. O ones having knowledge, give ear to the good! 

#### Job 34:3 For the ear {words tries}, and the throat tastes food. 

#### Job 34:4 Judgment we should take up for ourselves; we should know between ourselves what is good. 

#### Job 34:5 For Job has said, I am righteous; the LORD has dismissed my judgment. 

#### Job 34:6 And he lied in my judgment; {is violent my spear} without injustice. 

#### Job 34:7 What man is as Job, drinking sneering as if water? 

#### Job 34:8 Not sinning, nor being impious, nor wholly participating with ones committing lawless deeds, to go with the impious. 

#### Job 34:9 {not For you should} say that there will not be an overseeing of a man -- and there is an overseeing of him by the LORD. 

#### Job 34:10 Therefore, O discerning of heart, hear me! {not to me May it be} before the LORD to be impious, and before the almighty to disturb justice. 

#### Job 34:11 But he gives back to man as {does each of them}, and by a path man will find him. 

#### Job 34:12 And do you imagine the LORD {something out of place doing}, or that the almighty will disturb a judgment -- the one who made the earth? 

#### Job 34:13 And who is the one acting under heaven, and {the things being in it all}? 

#### Job 34:14 For if he might want to constrain, and {the spirit by himself to hold down}, 

#### Job 34:15 {would come to an end all flesh} with one accord. Every mortal {into the earth shall go forth} from where even he was shaped. 

#### Job 34:16 But if he should not admonish, then hear these things! Give ear to the sound of words! 

#### Job 34:17 Behold then the one detesting lawless deeds, and the one destroying the wicked, being eternally righteous. 

#### Job 34:18 Impious is the one saying to a king, You act unlawfully, and saying, O impious one, to the rulers, 

#### Job 34:19 who was not feeling of respect for the person of honor, nor knows {honor to appoint} to the stout men, to admire their persons. 

#### Job 34:20 {in vanity But to them it shall result}, to cry out and to beseech a man; for they dealt unlawfully, turning aside the disabled. 

#### Job 34:21 For he is an observer of the works of men, {has escaped and him nothing of how they act}; 

#### Job 34:22 nor is there a place to hide for the ones doing lawless deeds. 

#### Job 34:23 For {not upon a man he will put} any longer. 

#### Job 34:24 For the LORD inspects all; He is the one perceiving untraceable things, honorable things also, and extraordinary things which there is no number; 

#### Job 34:25 the one knowing their works, and he shall turn night upon them, and they shall be humbled. 

#### Job 34:26 And he extinguishes the impious, for they are visible before him. 

#### Job 34:27 For they turned aside from the law of God; {ordinances his they did not recognize}, 

#### Job 34:28 so as to bring unto him the cry of the needy; for {the cry of the poor he will listen to}; 

#### Job 34:29 and he {rest will furnish}, and who will condemn? and he will hide his face, and who shall see him? even against a nation and against a man together; 

#### Job 34:30 giving reign to a man who is a hypocrite, because of the discontent of people, 

#### Job 34:31 that to the mighty one saying, I have received blessings; I will not take anything for security. 

#### Job 34:32 {apart from myself I will see}; you show to me, if {iniquity I practiced}! then in no way shall I proceed. 

#### Job 34:33 Will {on you he pay it}, in that you should have thrust it away; for you shall choose, and not I, and what you know -- speak! 

#### Job 34:34 Therefore the discerning in heart shall say these things, {man and a wise} hears my word. 

#### Job 34:35 But Job {not with understanding spoke}; and his words are not with higher knowledge. 

#### Job 34:36 But in fact, learn Job! No {give longer} an answer as the fools, 

#### Job 34:37 that we should not add upon our sins; for lawlessness {against us may be imputed many in speaking} words before the LORD. 

#### Job 35:1 And undertaking, Elihu says, 

#### Job 35:2 What is this you esteem in equity? You, who are you, that you said, I am righteous before the LORD? 

#### Job 35:3 For you shall say, How should I have committed sinning? 

#### Job 35:4 I shall give to you an answer, and to {three friends your}. 

#### Job 35:5 Look up into the heaven, and behold! Study the clouds, how high they are from you! 

#### Job 35:6 If you sinned, what will you do? And even if in many things you acted lawlessly, what are you able to do? 

#### Job 35:7 Since then you are righteous, what shall you give to him, or what {from out of your hand shall he take}? 

#### Job 35:8 To a man likened to you -- of your impiety; and to a son of man -- of your righteousness. 

#### Job 35:9 {by a multitude The ones being extorted} shall cry out; they shall yell because of the arm of many. 

#### Job 35:10 And one said not, Where is the God who made me, the one delegating {watches the nightly}; 

#### Job 35:11 the one separating me from the four-footed beasts of the earth, and from the birds of heaven. 

#### Job 35:12 There they shall cry out, and in no way shall one listen, even because of the insolence of wicked men. 

#### Job 35:13 For things out of place {does not want to behold the LORD}, for he is the almighty. 

#### Job 35:14 He is an observer of the ones completing lawless deeds, and he will deliver me; and you plead before him! if you are able to praise him, as he is. 

#### Job 35:15 And now that he is not numbering his anger, and he knows not {transgressions exceeding}, 

#### Job 35:16 even Job acting in folly opens his mouth; in ignorance {words he weighs down}. 

#### Job 36:1 And proceeding still, Elihu says, 

#### Job 36:2 Wait for me a little more! that I shall teach you. {still For in me there is speech}. 

#### Job 36:3 Having taken up my higher knowledge from afar, and to works of mine, 

#### Job 36:4 {righteous things I will speak} in truth, and {not unjust words unjustly you shall perceive}. 

#### Job 36:5 But know! that the LORD in no way shall undo the guileless man; the mighty in strength of heart. 

#### Job 36:6 The impious in no way will he restore to life; and {equity for the poor he shall impute}. 

#### Job 36:7 He will not remove {from the righteous his eyes}, and they shall be with kings on a throne; he shall seat them into victory, and they shall be exalted. 

#### Job 36:8 And the ones being shackled in manacles shall be held together by rough cords of poverty. 

#### Job 36:9 And he shall announce to them their works, and their transgressions, for they are prevalent. 

#### Job 36:10 But {the righteous he will listen to}; and he spoke that they shall turn from unrighteousness. 

#### Job 36:11 If they shall hear and serve, they shall complete their days among good things, and their years among beautiful things. 

#### Job 36:12 But the impious are not preserved -- by {not willing their} to behold the LORD, and because being admonished they were unhearing. 

#### Job 36:13 And hypocrites in heart shall order rage; they shall not yell, for he bound them. 

#### Job 36:14 {may die Therefore in youth their soul}, and their life being pierced by messengers, 

#### Job 36:15 because they afflicted the weak and disabled; {judgment and for the gentle he will expound}. 

#### Job 36:16 And from when he beguiled from out of the mouth of the enemy, an abyss for throwing down underneath it, that {went down your table} full of fatness. 

#### Job 36:17 {shall not fail but from the righteous judgment}; 

#### Job 36:18 and rage {upon the impious will be}, because of the impiety of bribes which they received for iniquities. 

#### Job 36:19 {not you Let turn aside willingly the mind} of the supplication {in necessity of the ones being disabled}! And all the ones fortifying strength. 

#### Job 36:20 You shall not drag away by night, {should ascend so that others} instead of them. 

#### Job 36:21 But guard lest you act out of place! {of these things for} you took up because of poorness. 

#### Job 36:22 Behold, the strong one shall conquer by his strength, for who is as he -- the mighty one. 

#### Job 36:23 And who is the one examining his works? or who is the one having said, He acted unjustly. 

#### Job 36:24 Remember that {great works his are}, which {command men}! 

#### Job 36:25 Every man beholds in himself how many {being pierced are mortals}. 

#### Job 36:26 Behold, the strong one is great, and we shall not know him; {the number of his years and} are unlimited. 

#### Job 36:27 {shall be counted And by him the drops of rain}, and shall they be poured for rain in the cloud. 

#### Job 36:28 {shall flow Things grown old}, {shadow and clouds} over untold mortals. 

#### Job 36:29 And should one have perceived the spreading out of the clouds, as equal of his tent? 

#### Job 36:30 Behold, he stretches out {upon it light}, and {the root of the sea he covers}. 

#### Job 36:31 For in them he shall judge peoples; he shall give nourishment to the one being strong. 

#### Job 36:32 With the hands he covers light, and he gave charge concerning it with the encountering clouds. 

#### Job 36:33 He will announce {concerning him his friend} -- for possession and for injustice. 

#### Job 37:1 And from this {is disturbed my heart}, and was dropped down from out of its place. 

#### Job 37:2 Hear a report in anger of rage of the LORD! And a meditation from out of his mouth shall come forth. 

#### Job 37:3 Underneath all the heaven is his sovereignty, and his light is upon the wings of the earth. 

#### Job 37:4 After him {shall yell out a voice}; he shall thunder with the sound of his insult; and he shall not bargain them, that one shall hear his voice. 

#### Job 37:5 {will thunder The strong one with his voice wonders}. {a season He established} for animals, and they know {of the fold the order}. Upon all these things {is not receded your thought}, nor is {reconciled your heart} with your body. For he did great things which we knew not; 

#### Job 37:6 ordering the snow, saying, Be upon the earth; and the winter rain of his command. 

#### Job 37:7 In the hand of every man he seals up, that {should know every man} his own weakness. 

#### Job 37:8 {entered And the wild beasts} under the protection, and are tranquil in their lair. 

#### Job 37:9 From out of inner chambers come griefs, and from extremities chilliness. 

#### Job 37:10 And from the breath of the strong one he appoints ice; and he steers the water where ever he wants. 

#### Job 37:11 And if a chosen {plasters over cloud}, {disperses the cloud then his light}, 

#### Job 37:12 and he {the swirls shall turn aside} by his rule for performing their works -- all as much as he should give charge to them. 

#### Job 37:13 These things were ordered by him upon the earth. Whether for instruction, whether for his land, whether for an object of his mercy, he shall find it. 

#### Job 37:14 Give ear to these things, O Job! Stand admonished by the power of the LORD! 

#### Job 37:15 We know that God established his works, {light making} out of darkness. 

#### Job 37:16 And he knows the distinction of clouds, and the extraordinary calamitous downfalls of the wicked. 

#### Job 37:17 And your apparel is hot, but there is tranquility upon the earth from the south. 

#### Job 37:18 Will you solidify with him for things grown old; things which are strong as the vision of a vessel? 

#### Job 37:19 Why teach me, what shall we say to him? then let us cease {much from saying}. 

#### Job 37:20 Is there a book or scribe standing beside me, that {a man standing I should quell}? 

#### Job 37:21 {to all But is not visible the light}; it is radiant among the things grown old, as if from him upon the clouds. 

#### Job 37:22 From the north are clouds shining like gold; in these {is great the glory and honor from the almighty}; 

#### Job 37:23 and we do not find another likened to his strength. The one {justly judging}, do you not imagine that he listens? 

#### Job 37:24 Therefore {shall fear him men}; {shall fear and him even the wise in heart}. 

#### Job 38:1 And after the ceasing {of Elihu of the speech}, {said the LORD} to Job through a tempest and cloud, saying, 

#### Job 38:2 Who is this hiding counsel, and constraining matters in heart, {from me and imagines to hide}? 

#### Job 38:3 Tie up {as a man your loin}! And I will ask you, and you answer me! 

#### Job 38:4 Where were you in my laying the foundation for the earth? And report to me! if you should have knowledge of understanding. 

#### Job 38:5 Who established the measures of it, if you know? Or who is the one bringing a measuring cord upon it? 

#### Job 38:6 Upon what are its hooks pitched on? And who is the one laying {foundation stone an angular} upon it? 

#### Job 38:7 When {came to pass the stars}, {praised me a great voice with all my angels}. 

#### Job 38:8 And I shut up the sea with gates, when it was led irresistibly {out of belly its mother's going forth}. 

#### Job 38:9 And I established the cloud for its clothing, and fog for its being swaddled. 

#### Job 38:10 And I established limits for it, I put in place bolts and gates. 

#### Job 38:11 And I said to it, Unto this far you shall come, and shall not pass over; and within yourself {shall break your waves}. 

#### Job 38:12 Or by you have I ordered {brightness the early morning}? And did the morning star behold his own order; 

#### Job 38:13 to take hold of the wings of the earth, to shake off the impious from it. 

#### Job 38:14 Or did you, having taken earth's clay, shape a living creature, and {the power of speech to it establish} upon the earth? 

#### Job 38:15 And have you removed {from the impious the light}, {the arm and of the proud broke}? 

#### Job 38:16 Did you come unto the spring of the sea, {in and the tracks of the deep walk}? 

#### Job 38:17 {open And to you in fear do the gates of death}; and did gatekeepers of Hades, in beholding you, become alarmed? 

#### Job 38:18 And have you been admonished about the breadth under heaven? Announce it indeed to me! how great it is. 

#### Job 38:19 And of what kind of land lodges the light? And darkness, what kind of place? 

#### Job 38:20 If you could lead me into their limits, and even if you know their paths. 

#### Job 38:21 Have you known that it is so then because you were born, and the number of your years great? 

#### Job 38:22 But did you come unto the treasuries of snow? {the treasuries and of hail have you seen}? 

#### Job 38:23 And is it reserved to you for the hour of the enemies, for the day of war and battle? 

#### Job 38:24 And from what place goes forth the frost, or {is dispersed the south wind} into the place under heaven? 

#### Job 38:25 And who prepared {rain of the fierce the flow}, and a way in uproar; 

#### Job 38:26 to rain upon the land of which there is no man, the wilderness of which there is no {existing man} in it; 

#### Job 38:27 so as to fill the untrodden and uninhabited land, and the causing to sprout forth the issue of tender shoots? 

#### Job 38:28 Who is the rain's father, and who is the one giving birth to droplets of dew? 

#### Job 38:29 {from out of womb And whose} comes forth the ice; {the frost and in the heaven who gave birth to}, 

#### Job 38:30 which comes down as if water flowing? {the face And of the abyss who alarmed}? 

#### Job 38:31 And do you perceive the bond of Pleiades; and {the barrier of Orion did you open}? 

#### Job 38:32 Or will you open Mazuroth in its time? And Hesperus with its tail -- will you lead it? 

#### Job 38:33 And do you know the circuits of heaven, or the things {under heaven with one accord taking place}? 

#### Job 38:34 And will you call a cloud by voice, and in trembling {water of rain the fierce will} obey you? 

#### Job 38:35 And will you send thunderbolts? and will they go forth? and shall they say to you, What is it? 

#### Job 38:36 And who gave women {for a woven work wisdom}, or {for embroidery skill}? 

#### Job 38:37 And who is the one counting clouds in wisdom, {the heaven and unto the earth leaned}, 

#### Job 38:38 and it is poured as earth's powder, and I have cleaved it as a stone cube? 

#### Job 38:39 And will you hunt {for the lions a prey}? {the souls and of dragons fill up}? 

#### Job 38:40 for they are in awe in their lairs, and they sit in the woods lying in wait. 

#### Job 38:41 And who prepared {for the crow carrion}? {young for its to the LORD cry out in wandering grain seeking}. 

#### Job 39:1 Do you know the time of the birthing of the antelopes of the rock? And did you watch the birth pangs of hinds? 

#### Job 39:2 And did you count {months their full} of birthing? {birth pangs and their did you untie}? 

#### Job 39:3 And did you nourish their offspring outside of fear? {birth pangs and their will you send away}? 

#### Job 39:4 {shall rip forth Their young}; they shall be multiplied in offspring; their young will go forth and in no way shall return to them. 

#### Job 39:5 And who is the one letting {donkey the wild} free? {bonds and his who untied}? 

#### Job 39:6 For I established for his habitation a wilderness, and {for his tents the salt-flats}. 

#### Job 39:7 He ridicules the great multitude of the city, {the complaint and of the tribute-gatherer hears not}. 

#### Job 39:8 He shall survey the mountains as his pasture, and {after every green thing he seeks}. 

#### Job 39:9 {shall be willing And to you the unicorn to serve}, or to sleep at your stable? 

#### Job 39:10 And will you tie {with straps his yoke}, or will he draw furrows in the plain? 

#### Job 39:11 And do you rely upon him, because {is great his strength}? and will you slacken {for him your works}? 

#### Job 39:12 And do you trust that he will give back to you the seed, and carry it into your threshing-floor? 

#### Job 39:13 The wing delighting ostriches; but should {conceive the stork and feathers}? 

#### Job 39:14 for she shall let {go unto the earth her eggs}, and {upon the dust she shall incubate}; 

#### Job 39:15 and she forgot that the foot will disperse them, and the wild beasts of the field will trample them. 

#### Job 39:16 She hardened against her offspring, so as to not bereave herself; in vain she tired without fear. 

#### Job 39:17 For {quelled her God} wisdom, and portioned not to her with understanding. 

#### Job 39:18 In time {in height she will raise up high}; she will ridicule the horse and his rider. 

#### Job 39:19 Or did you invest the horse with power, or clothe his neck in fear? 

#### Job 39:20 And did you invest in him full armor, and the glory of his breast in daring? 

#### Job 39:21 {rooting up in the plain He prances}, and he goes forth into the plain in strength. 

#### Job 39:22 {meeting up with spears He ridicules}, and in no way turns from an iron weapon. 

#### Job 39:23 Against him prance the bow and sword; 

#### Job 39:24 and in anger he shall obliterate the ground. In no way shall he trust until whenever {signifies the trumpet}; 

#### Job 39:25 and with the trumpet signifying, he says, Well done! And at a distance he smells war with leaping and crying out. 

#### Job 39:26 And from your higher knowledge {set does the hawk} having the look of effrontery with wings fixed looking down towards the south? 

#### Job 39:27 And at your order {rise up high does the eagle}, and does the vulture {upon its nest sit lodged}, 

#### Job 39:28 upon the prominence of the rock and is concealed? 

#### Job 39:29 Being at that place he seeks grain; {at a distance his eyes watch}, 

#### Job 39:30 {young and his} befoul themselves in blood; and where ever ones dying might be, immediately they are found. 

#### Job 40:1 And {responded the LORD God} to Job, and said, 

#### Job 40:2 Shall {a judgment with the fit one you judge}? One reproving God -- shall he answer to him? 

#### Job 40:3 And undertaking, Job says to the LORD, 

#### Job 40:4 Why still do I plead, being admonished and reproved by the LORD? Hearing such things, and being nothing; and I, what answer shall I give to these things? {a hand I shall put} upon my mouth. 

#### Job 40:5 Once I have spoken, but for a second time I will not proceed. 

#### Job 40:6 And again undertaking, the LORD spoke to Job from out of the cloud, saying, 

#### Job 40:7 But no, tie up {as a man your loin}! and I will ask you, then you answer me! 

#### Job 40:8 Or should you undo my judgment? And do you imagine me otherwise executing things with you? or that you should appear just? 

#### Job 40:9 or {your arm is} as the arm of the LORD? or {with a voice as his do you thunder}? 

#### Job 40:10 Then lift yourself up in stature and power, {with glory and and honor clothe yourself}! 

#### Job 40:11 And send angels in anger, {all and the arrogant humble}! 

#### Job 40:12 {the proud man And extinguish}! {cause to rot and the impious} immediately! 

#### Job 40:13 And hide them in the earth with one accord! and the things of their faces {with dishonor fill}! 

#### Job 40:14 And indeed, I shall acknowledge surely that {is able your right hand} to deliver. 

#### Job 40:15 But indeed, behold, the wild beast by you; {grass equal to oxen it eats}. 

#### Job 40:16 Behold indeed, his strength is in his loin, and his power is in the navel of his belly. 

#### Job 40:17 He sets his tail as a cypress; and his nerves are closely joined. 

#### Job 40:18 His sides are sides of brass; and his spine {iron is as cast}. 

#### Job 40:19 This is the beginning of the thing shaped by the LORD; being made to be mocked by his angels. 

#### Job 40:20 And coming upon {mountain a chiseled}, he produces a cause for joy to the four-footed in the infernal region. 

#### Job 40:21 Under all kinds of trees he sleeps; by the papyrus, and reed and flowering rush. 

#### Job 40:22 {shadow And in him trees} with scions and branches of the chaste tree. 

#### Job 40:23 If there becomes an inundation, in no way shall it be perceived; he relies that {will rush up the Jordan} into his mouth. 

#### Job 40:24 In his eye will one take him? Being caught in a snare will you drill his nose? 

#### Job 41:1 And shall you lead the dragon by a hook, and put a halter around his nose? 

#### Job 41:2 Or will you tie a hook in his nose, {for a clasp and will you make a hole in his lip}? 

#### Job 41:3 And will he speak to you {supplications earnest} softly? 

#### Job 41:4 {will he establish And with you a covenant}? And will you take him {servant for an everlasting}? 

#### Job 41:5 And will you play with him as a bird? Or will you bind him as a sparrow for a child? 

#### Job 41:6 {feed And do in him nations}? {partition And do him of the Phoenicians the nations}? 

#### Job 41:7 And everything afloat coming together in no way shall bear the hide {one tail of his}; nor in the boats of fishermen shall they bear his head. 

#### Job 41:8 But shall you place a hand on him, remembering the war taking place in his body, and let it no longer take place? 

#### Job 41:9 Have you not seen him, nor {over the ones speaking wondered}? 

#### Job 41:10 Are you not in awe that it has been prepared by me? For who is the one opposing me? 

#### Job 41:11 Or who shall oppose me and remain, since all under heaven is mine? 

#### Job 41:12 I will not keep silent because of him; and the word of power shall show mercy equal to him. 

#### Job 41:13 Who will uncover the front of his clothing? and into the fold of his chest plate who can enter? 

#### Job 41:14 {the gates of his face Who will open}? Round about his teeth is fear; 

#### Job 41:15 His insides are as shields of brass, {sinews and his} are as emery stone. 

#### Job 41:16 One of one cleaves together, and wind in no way goes through it; 

#### Job 41:17 as a man to his brother they shall be cleaved; they are held together, and in no way draw apart. 

#### Job 41:18 In his sneezing {shines forth brightness}, and his eyes are as the appearance of the morning star. 

#### Job 41:19 From out of his mouth {shall go forth lamps burning}, and scattered grates of fire. 

#### Job 41:20 From out of his nostrils comes forth smoke of a furnace burning {of fire with coals}. 

#### Job 41:21 His soul is as live coals; and a flame {from out of his mouth goes forth}. 

#### Job 41:22 And in his neck lodges power. {before him runs Destruction}. 

#### Job 41:23 And the flesh of his body cleaves tightly. If one pours down upon him, he will not be shaken. 

#### Job 41:24 His heart is fixed as stone, and he stands as an anvil, not malleable. 

#### Job 41:25 {turning And his} gives fear {wild beasts to the four-footed upon the earth leaping}. 

#### Job 41:26 If {should meet up with him lances}, nothing in any way shall terrify by spear and chest plate. 

#### Job 41:27 For he esteems iron as straw, and brass as {wood rotten}. 

#### Job 41:28 In no way shall {pierce him the bow of brass}. He esteems a slinger indeed as grass; 

#### Job 41:29 {as stubble are considered hammers}; and he ridicules the quaking of a fire-bearer. 

#### Job 41:30 His strewn bed {points is of sharp}; and all the gold of the sea under him is as {mud untold}. 

#### Job 41:31 {breaks out The abyss} as a brazen cauldron; and he esteems the sea as an ointment jar. 

#### Job 41:32 And the infernal region of the abyss is as if a captive; he considers the abyss for a promenade. 

#### Job 41:33 There is not anything upon the earth likened to him, being made, to be mocked at by my angels. 

#### Job 41:34 Every lofty thing he sees; and he is king of all the things in the waters. 

#### Job 42:1 And undertaking, Job {to the LORD says}, 

#### Job 42:2 I know that in all things you are able, {is powerless and to you nothing}. 

#### Job 42:3 For who is the one hiding you counsel, and sparing words, and {you imagines to hide}? And who announces to me things which I knew not, great and wonderful, things which I had no knowledge? 

#### Job 42:4 But hear me, O LORD! for I also shall speak. And I will ask you, and you teach me! 

#### Job 42:5 Hearing indeed in my ear, I heard of you formerly; but now my eye sees you. 

#### Job 42:6 Therefore I treated {as worthless myself}, and I was melted away; and I esteem myself earth and ashes. 

#### Job 42:7 And it came to pass after the {speaking LORD} all these words to Job, {said the LORD} to Eliphaz the Temanite, You sinned and {two friends your}, {not for you spoke before me true anything}, as my attendant Job. 

#### Job 42:8 And now, take seven calves, and seven rams, and go to my attendant Job! and he shall offer a yield offering for you, for in no way {of his face shall I receive}, for but on account of him I would have destroyed you. {not For you did} speak true concerning my attendant Job. 

#### Job 42:9 And they went -- Eliphaz the Temanite, and Baldad the Shuhite, and Sophar the Minean. And they went as {ordered them the LORD}, and he dismissed their sin because of Job. 

#### Job 42:10 And the LORD increased Job. {making a vow And of his} and because of being his friends he forgave to them the sin. {gave And the LORD} double, as much as was Job's before, by doubling. 

#### Job 42:11 {heard And all his brothers and his sisters} all the things coming to pass to him. And came to him even all as many as knew him at first. And eating and drinking with him, they comforted him. And they wondered upon all which {brought upon him the LORD}. {they gave And to him each ewe-lamb one}, and a four-drachma {gold piece of unmarked}. 

#### Job 42:12 And the LORD blessed the latter end of Job than the former. {was And cattle his} -- {sheep ten thousand four thousand}, {camels six thousand}, {teams of oxen a thousand}, {donkeys female grazing a thousand}. 

#### Job 42:13 And there were born to him {sons seven} and {daughters three}. 

#### Job 42:14 And he called the first, Day, and the second, Keziah, and the third, Amalthaia's Horn. 

#### Job 42:15 And there were not found according to the daughters of Job better than they among the places under heaven. {gave And to them their father} an inheritance among the brethren. 

#### Job 42:16 {lived And Job} after the calamity {years a hundred forty}. And Job saw his sons, and the sons of his sons, to the fourth generation. 

#### Job 42:17 And Job came to an end an old man and full of days.