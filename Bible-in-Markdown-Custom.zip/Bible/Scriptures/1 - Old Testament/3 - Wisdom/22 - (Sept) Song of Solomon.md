#### Song of Solomon 1:1 A song of songs which is to Solomon. 

#### Song of Solomon 1:2 Let him kiss me by kisses of his mouth! for {are good your breasts} over wine. 

#### Song of Solomon 1:3 And the scent of your perfumes -- {is over all the aromatics of perfume being emptied out your name}; on account of this the young women loved you. 

#### Song of Solomon 1:4 They drew me; {after you for the scent of your perfumes we will run}. {carried me The king} into his inner chamber. We should exult and be glad in you. We shall love your breasts over wine. Uprightness loved you. 

#### Song of Solomon 1:5 {black I am} and fair, O daughters of Jerusalem, as the tents of Kedar, as the hide coverings of Solomon. 

#### Song of Solomon 1:6 You should not look, for I am being blackened, for {looked over me the sun}. Sons of my mother quarreled with me. They made me keeper in the vineyards. {vineyard my own I kept not}. 

#### Song of Solomon 1:7 Report to me! you whom {loved my soul}, where you tend, where you bed at midday; lest at any time I should become as one being covered by a veil by the herds of your companions! 

#### Song of Solomon 1:8 If you should not know yourself, O fair one among women, come forth at the heels of the flocks, and tend your kids by the tents of the shepherds! 

#### Song of Solomon 1:9 To my horse among the chariots of Pharaoh, I likened you, my dear one. 

#### Song of Solomon 1:10 How {are beautiful your cheeks} as a turtle-dove; your neck as pendants. 

#### Song of Solomon 1:11 Representations of gold we will make for you with marks of silver. 

#### Song of Solomon 1:12 Until of which time the king was at his laying down, my spikenard gave its scent. 

#### Song of Solomon 1:13 {is a bundle of balsam My beloved man} to me; {between my breasts he shall be lodged}. 

#### Song of Solomon 1:14 A cluster of camphor is my beloved man to me in vineyards of En-gedi. 

#### Song of Solomon 1:15 Behold, you are fair my dear one; behold, you are fair; your eyes are as the doves. 

#### Song of Solomon 1:16 Behold, you are fair, my beloved man; and indeed beautiful to {bed our shady}. 

#### Song of Solomon 1:17 Beams of our houses are cedars; our fretworks cypresses. 

#### Song of Solomon 2:1 I am a flower of the plain; a lily of the valleys. 

#### Song of Solomon 2:2 As a lily in the midst of thorn-bushes, thus is my dear one in the midst of the daughters. 

#### Song of Solomon 2:3 As an apple among the trees of the groves, so is my beloved man in the midst of the sons. To be in his shadow I desired, and I sat down, and his fruit was sweet in my throat. 

#### Song of Solomon 2:4 Bring me into the house of wine! Order for me love! 

#### Song of Solomon 2:5 Support me with perfumes! Pile me with apples, for {being pierced of love I am}. 

#### Song of Solomon 2:6 His left hand is under my head, and his right hand will embrace me. 

#### Song of Solomon 2:7 I bound you by an oath, O daughters of Jerusalem, by the powers and by the strengths of the field, if you should arise and awaken love until of which time it should want. 

#### Song of Solomon 2:8 The voice of my beloved man. Behold, thus he comes springing up over the mountains, leaping over the hills. 

#### Song of Solomon 2:9 {is likened My beloved man} to the doe or a fawn of the hinds. Behold, he stands behind our wall, leaning over through the windows, looking out through the lattice. 

#### Song of Solomon 2:10 {responds My beloved man}, and he says to me, Rise up, come my dear one, my fair one, my dove! 

#### Song of Solomon 2:11 For behold, the winter went by, the rain went forth; it went to itself. 

#### Song of Solomon 2:12 The flowers appeared in the land; the time of pruning arrived; the voice of the turtle-dove was heard in our land; 

#### Song of Solomon 2:13 the fig-tree brought forth its immature figs; the grapevines blossom, they gave a scent. Rise up, come my dear one, my fair one, my dove, yes come! 

#### Song of Solomon 2:14 You are my dove in the protection of the rock, being next to the area around the wall. Show to me your appearance, and cause me to hear your voice! for your voice is agreeable, and your appearance is beautiful. 

#### Song of Solomon 2:15 Lay hold for us {foxes the small}, that are obliterating the vineyards; for our grapevines blossom. 

#### Song of Solomon 2:16 My beloved man is to me, and I to him. He is the one tending among the lilies, 

#### Song of Solomon 2:17 until of which time {should refresh the day}, and {should move the shadows} -- return! You be like, O my beloved man, to the buck or fawn of the hinds {upon the mountains encircling}! 

#### Song of Solomon 3:1 Upon my bed in the nights I sought whom {loved my soul}. I sought him, and I did not find him. I called unto him, and he did not hearken to me. 

#### Song of Solomon 3:2 I shall rise up indeed, and I shall encircle in the city, in the markets, and in the squares, and I will seek whom {loved my soul}. I sought him, and I did not find him. 

#### Song of Solomon 3:3 They found me, the ones keeping guard, the ones encircling in the city. {not whom loved my soul Saw they}? 

#### Song of Solomon 3:4 It was a little time when I passed by them, until of which time I found whom {loved my soul}. I held him, and did not let go of him, until of which time I brought him into the house of my mother, and into the inner chamber of the one conceiving me. 

#### Song of Solomon 3:5 I bound you by an oath, O daughters of Jerusalem, by the powers and by the strengths of the field, if you should arise and awaken love until whenever it should want. 

#### Song of Solomon 3:6 Who is she ascending from the wilderness as sticks of smoke, being of burning incense of myrrh and frankincense, from all the powders of the perfumer? 

#### Song of Solomon 3:7 Behold, the bed of Solomon, sixty mighty men round about it, from among the mighty ones of Israel. 

#### Song of Solomon 3:8 All holding a broadsword, being taught war; every man with his broadsword upon his thigh, because of consternation in the nights. 

#### Song of Solomon 3:9 {a carriage made for himself King Solomon} from woods of Lebanon. 

#### Song of Solomon 3:10 His columns he made of silver, and his couch of gold, his step purple; within it {stone pavement a love} from the daughters of Jerusalem. 

#### Song of Solomon 3:11 Come forth and behold, daughters of Zion! unto king Solomon, unto the crown which {crowned him his mother} in the day of his betrothing, and in the day of the gladness of his heart. 

#### Song of Solomon 4:1 Behold, you are fair my dear one; behold, you are fair. Your eyes -- doves outside your veil. Your head of hair is as herds of goats, the ones who were revealed from Gilead. 

#### Song of Solomon 4:2 Your teeth are as herds of the ones being sheared, the ones which ascended from the bath, all bearing twins, and {a childless one there is not} among them. 

#### Song of Solomon 4:3 {are as string a scarlet Your lips}, and your speech beautiful. {are as a rind of the pomegranate your cheeks}, outside your veil. 

#### Song of Solomon 4:4 {is as the tower of David Your neck}, the tower having been built for the armory; a thousand shields hang upon it, all the arrows of the mighty. 

#### Song of Solomon 4:5 {two breasts Your} are as two {fawns twin} of the doe, the ones feeding among the lilies. 

#### Song of Solomon 4:6 Until of which time {should refresh the day}, and {move away the shadows}, I will go myself to the mountain of myrrh, and to the hill of frankincense. 

#### Song of Solomon 4:7 Entirely fare is my dear one, and {blemish there is no} in you. 

#### Song of Solomon 4:8 Come from Lebanon, O bride, come from Lebanon. You shall come and go through from the top of Trust, from the head of Shenir and Hermon, from the lairs of lions, from the mountains of leopards. 

#### Song of Solomon 4:9 You took my heart, my sister, O bride; you took my heart with one of your eyes, with one garland of your neck. 

#### Song of Solomon 4:10 How {were beautified your breasts} my sister, O bride. How {were beautified your breasts} above wine, and the scent of your garments above all aromatics. 

#### Song of Solomon 4:11 {honeycomb drop Your lips}, O bride. Honey and milk are under your tongue; and the scent of your garments is as the scent of frankincense. 

#### Song of Solomon 4:12 {is as a garden being locked My sister}, O bride; a spring having a seal upon it. 

#### Song of Solomon 4:13 Your dowries are a garden of pomegranates, with the fruit of fruit trees; camphor with spikenards. 

#### Song of Solomon 4:14 Spikenard and saffron, calamus and cinnamon, with all the woods of Lebanon; myrrh, aloes, with all of the foremost perfumes. 

#### Song of Solomon 4:15 A spring of gardens; a well of water living, and gurgling from Lebanon. 

#### Song of Solomon 4:16 Awake, O north wind! And come, O south! and refresh my garden, and let flow my aromatics! 

#### Song of Solomon 5:1 Let {go down my beloved man} into his garden, and let him eat the fruit of his fruit trees! I entered into my garden, my sister, O bride. I gathered the vintage of my myrrh with my aromatics; I ate my bread with my honey; I drank wine with my milk. Eat, O dear men, and drink! and be intoxicated beloved men! 

#### Song of Solomon 5:2 I sleep, but my heart is sleepless. The voice of my beloved man knocks upon the door, saying, Open to me my sister, my dear one, my dove, my perfect one! for my head is filled of dew, and my curls of the mist of the night. 

#### Song of Solomon 5:3 I took off my inner garment; how shall I put it on again? I washed my feet; how shall I taint them? 

#### Song of Solomon 5:4 My beloved man sent his hand through the opening, and my belly was alarmed over him. 

#### Song of Solomon 5:5 I rose up to open to my beloved man; my hands dripped myrrh, my fingers {of myrrh with full bodied} upon the handles of the bolt. 

#### Song of Solomon 5:6 I opened to my beloved man; my beloved man was gone. My soul came forth for his word. I sought him, and I did not find him; I called him, and he did not hearken to me. 

#### Song of Solomon 5:7 They found me, the guards, the ones encircling in the city. They struck me, they wounded me, {took my lightweight covering from me the keepers of the walls}. 

#### Song of Solomon 5:8 I bind you by an oath, O daughters of Jerusalem, by the powers and by the strengths of the field, if you should find my beloved man, what should you report to him, for {being pierced of love I am}. 

#### Song of Solomon 5:9 What is your beloved man from a beloved man, O fair one among women? What is your beloved man from a beloved man, that thus you bound us by an oath? 

#### Song of Solomon 5:10 My beloved man is white and ruddy, being selected from myriads. 

#### Song of Solomon 5:11 His head is as gold of Kefaz; his curls flowing fir trees, black as a crow. 

#### Song of Solomon 5:12 His eyes are as doves by the fullnesses of waters, being bathed in milk, sitting down upon the fullnesses of waters. 

#### Song of Solomon 5:13 His jaws are as bowls of the aromatic, germinating scents. His lips are as lilies dripping {myrrh full- bodied}. 

#### Song of Solomon 5:14 His hands are as turned gold, being filled with Tharsis stone. His belly is as a writing-tablet of ivory upon a stone of sapphire. 

#### Song of Solomon 5:15 His legs are as columns of marble, founded upon bases of gold. His appearance as Lebanon, choice as cedars. 

#### Song of Solomon 5:16 His throat is sweetness, and he is entirely desirable. This is my beloved man, and this is my dear one, O daughters of Jerusalem. 

#### Song of Solomon 6:1 Where did {go forth your beloved man}, O fair one among women? Where did {look away your beloved man}? for we will seek him with you. 

#### Song of Solomon 6:2 My beloved man went down to his garden, to bowls of the aromatics, to tend in gardens, and to collect lilies. 

#### Song of Solomon 6:3 I am to my beloved man, and my beloved man to me -- the one tending among the lilies. 

#### Song of Solomon 6:4 You are fair, O dear one, as good-pleasure; beautiful as Jerusalem; a consternation as ones arranged for battle. 

#### Song of Solomon 6:5 Turn away your eyes from before me! for they incited me. The hair of your head is as the herds of the goats which ascended from Gilead. 

#### Song of Solomon 6:6 Your teeth as herds of the ones being sheared, the ones which ascend from the bath, all bearing twins, and {one being childless there is not} among them. {are as string a scarlet Your lips}, and your speech is beautiful. 

#### Song of Solomon 6:7 {are as the rind of the pomegranate Your cheeks} being seen outside your veil. 

#### Song of Solomon 6:8 {sixty There are} queens, and eighty concubines, and young women which there is no number. 

#### Song of Solomon 6:9 {is one My dove}, my perfect one. She is the only one to her mother; the choice one is to the one giving birth to her. {beheld her The daughters}, and {will declare her blessed queens}, and indeed the concubines also shall praise her. 

#### Song of Solomon 6:10 Who is she, the one looking out as the dawn, fair as the moon, choice as the sun, the consternation as troops being set in order. 

#### Song of Solomon 6:11 Into the garden of walnuts I went down to behold among the produce of the valley of the rushing stream; to see if {bloomed the grapevine}, {blossomed or if the pomegranates}. 

#### Song of Solomon 6:12 {did not know My soul}, it made me as the chariots of Aminadab. 

#### Song of Solomon 6:13 Return! return! O Shulamite. Return! return! and we will look to you. 

#### Song of Solomon 7:1 What shall you see in the Shulamite? She comes as a company of the camps. How you do beautify your footsteps in sandals, O daughter of Nabad. The proportions of your thighs are likened to pendants -- works of the hands of a craftsman. 

#### Song of Solomon 7:2 Your navel is as {basin a turned}, not lacking mixed wine. Your belly is as a heap of grain shut up in lilies. 

#### Song of Solomon 7:3 {two breasts Your} are as two fawns, twins of the doe. 

#### Song of Solomon 7:4 Your neck is as a tower of ivory; your eyes are as lakes in Heshbon, by the gates of the daughter of many. Your nose is as the tower of Lebanon, watching in front of Damascus. 

#### Song of Solomon 7:5 Your head upon you is as Carmel, and the braid of your head is as purple, with the king being bound by its passing by. 

#### Song of Solomon 7:6 How beautiful and how delicious, O love, in your luxuries. 

#### Song of Solomon 7:7 This your greatness is likened to the palm, and your breasts to the clusters of grapes. 

#### Song of Solomon 7:8 I said, I will ascend unto the palm, I will seize its heights; and {shall indeed be your breasts} as clusters of grapes of the grapevine, and the scent of your nose as apples. 

#### Song of Solomon 7:9 And your throat is as {wine good}, going to my beloved man in straightness, suiting in my lips and teeth. 

#### Song of Solomon 7:10 I turn to my beloved man, and {is towards me his turning}. 

#### Song of Solomon 7:11 Come, O my beloved man! we should go forth into the field; we should lodge in towns. 

#### Song of Solomon 7:12 We should rise early to the vineyards; we should see if {bloomed the grapevine}; if {bloomed the blossoms}; if {bloomed the pomegranates}. There I will give my breasts to you. 

#### Song of Solomon 7:13 The mandrakes gave a scent, and at our doors are all the fruit trees -- new to old. O my beloved man, I kept them for you. 

#### Song of Solomon 8:1 Who should grant you, O my beloved man, nursing the breasts of my mother; finding you outside I should kiss you, and indeed, they will not treat me with contempt. 

#### Song of Solomon 8:2 I shall take you; I shall bring you into the house of my mother, and into the inner chamber of the one conceiving me. I will give you to drink from {wine scented} of the juice of my pomegranates. 

#### Song of Solomon 8:3 His left hand is under my head, and his right hand shall embrace me. 

#### Song of Solomon 8:4 I bound you by an oath, O daughters of Jerusalem, by the powers, by the strengths of the field, why should you arise and why should you awaken love until whenever it should want? 

#### Song of Solomon 8:5 Who is this ascending from the wilderness, staying upon her beloved man? Under the apple tree I awakened you. There {travailed with you your mother}. There she travailed with you, giving birth to you. 

#### Song of Solomon 8:6 Set me as a seal upon your heart, as a seal upon your arm! For {is strong as death the love}; hard as Hades is jealousy; her sparks are sparks of the fire of her flames. 

#### Song of Solomon 8:7 {water Much} will not be able to extinguish love, and rivers shall not engulf it. If {should give a man} all his livelihood for love, with contempt men will treat it contemptuously. 

#### Song of Solomon 8:8 Our sister is small and {breasts no has}; what shall we do for our sister in the day in which ever she should be spoken for in it? 

#### Song of Solomon 8:9 If she is a wall, we should build upon her parapets of silver. And if she is a door, we will circumscribe for her {plank cedar}. 

#### Song of Solomon 8:10 I am a wall, and my breasts are as towers. I was in their eyes as one finding peace. 

#### Song of Solomon 8:11 A Vineyard existed to Solomon in Baal-hamon. He gave over his vineyard to the ones keeping it. Every man shall bring for its fruit a thousand pieces of silver. 

#### Song of Solomon 8:12 My vineyard, mine, is before me. The thousands to Solomon, and two hundred to the ones keeping its fruit. 

#### Song of Solomon 8:13 O one sitting down in the gardens, the companions are taking heed to your voice. You caused me to hear! 

#### Song of Solomon 8:14 Flee, O my beloved man, and be like the doe or the fawn of the hinds upon mountains of aromatics!