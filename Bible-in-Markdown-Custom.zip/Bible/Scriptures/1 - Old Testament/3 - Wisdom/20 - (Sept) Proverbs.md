#### Proverbs 1:1 The proverbs of Solomon son of David who reigned in Israel, 

#### Proverbs 1:2 to know wisdom and instruction; to comprehend also words of intelligence; 

#### Proverbs 1:3 to receive also the shifting and turning of words, and loosening enigmas; to comprehend also {righteousness true} and {judgment to straighten out}, 

#### Proverbs 1:4 that he should give to the guileless astuteness, {child but to the young} perception, and also reflection. 

#### Proverbs 1:5 But of the ones for hearing, the wise will be wiser, and the intelligent {guidance shall acquire}. 

#### Proverbs 1:6 He shall comprehend also a parable and a dark matter; sayings also of the wise, and enigmas. 

#### Proverbs 1:7 The beginning of wisdom is fear of the LORD, {understanding and good} to all the ones observing it. And piety to God is the beginning of perception. But wisdom and instruction the impious shall treat with contempt. 

#### Proverbs 1:8 Hear, O son, the laws of your father! and you should not thrust away the rules of your mother; 

#### Proverbs 1:9 {a crown for of favors you shall receive} for your head, and a collar of gold around your neck. 

#### Proverbs 1:10 O son, you should not have caused {to wander you men impious}, nor should you consent. 

#### Proverbs 1:11 If they should comfort you, saying, Come with us, partake in blood! for we should hide {in the ground man the just unjustly}, 

#### Proverbs 1:12 and we should swallow him as Hades, while living, and lift his remembrance from the earth, 

#### Proverbs 1:13 the {property of his very costly} we should overtake, and we should fill {houses our} of spoils. 

#### Proverbs 1:14 and {your lot throw} in with us, and {money bag one let there become} for us. 

#### Proverbs 1:15 You should not go in the ways with them. Turn aside your foot from their paths! 

#### Proverbs 1:16 For their feet {to evil run}, and are quick to pour out blood. 

#### Proverbs 1:17 {are not For wrongfully stretched out nets} for feathered birds. 

#### Proverbs 1:18 For they, the ones {in murder partaking}, treasure up for themselves evils. 

#### Proverbs 1:19 These {the ways are} of all the ones completing the lawless things. For by impiety {their own life they remove}. 

#### Proverbs 1:20 Wisdom {in the streets sings praise}; and in the squares in open places she celebrates. 

#### Proverbs 1:21 {upon the tops And of the walls she proclaims}; and at the gates of the city courageously says, 

#### Proverbs 1:22 As much time as the guileless have of the righteousness, they shall not be ashamed; but the fools {insolence being ones who crave}, {impious having become}, detest good sense, 

#### Proverbs 1:23 and {accountable become} for reproofs. Behold, I will let go to you my breath's saying, and I will teach you by my word. 

#### Proverbs 1:24 Since I called, and you did not obey; and I stretched out words, and you did not take heed; 

#### Proverbs 1:25 but {void you made my counsels}, and {to my reproofs you did not give heed}; 

#### Proverbs 1:26 accordingly I also {your destruction laugh at}; and I will rejoice when ever {comes to you ruin}. 

#### Proverbs 1:27 And when ever {should arrive unto you suddenly a tumult}, and the undoing of yourself like a blast is at hand; or whenever {should come upon you affliction and assault}; 

#### Proverbs 1:28 that it will be whenever you should call upon me, even I shall not listen to you. {shall seek me Evil men}, and will not find me; 

#### Proverbs 1:29 for they detested wisdom, and the fear of the LORD they did not prefer; 

#### Proverbs 1:30 nor wanted {to my to take heed} counsels; but they sneered at my reproofs. 

#### Proverbs 1:31 Accordingly they shall eat {of their own way the fruits}, and {with their own impiety shall be filled}. 

#### Proverbs 1:32 For because they wronged the simple ones, they shall be slaughtered, and an inquisition {the impious shall destroy}. 

#### Proverbs 1:33 But the one hearing me shall encamp with hope, and shall be tranquil without fear from all evil. 

#### Proverbs 2:1 O son, if receiving the saying of my commandment, you shall hide it unto yourself; 

#### Proverbs 2:2 {shall obey wisdom your ear}, and you shall set aside your heart unto understanding; and you shall set it for admonition to your son. 

#### Proverbs 2:3 For if {wisdom you should call upon}, and {for understanding should give your voice}; 

#### Proverbs 2:4 and {perception you should seek great} with your voice; and if you should seek her as silver, and {as for treasures should search her out}; 

#### Proverbs 2:5 then you shall perceive the fear of the LORD, and {full knowledge of God you will find}. 

#### Proverbs 2:6 For the LORD gives wisdom; and from his presence knowledge and understanding. 

#### Proverbs 2:7 And he treasures up {to the ones keeping straight deliverance}; and he will shield their goings; 

#### Proverbs 2:8 to guard the way of right actions; and the way of the ones venerating him he will protect. 

#### Proverbs 2:9 Then you shall perceive righteousness and judgment, and you shall set up all courses of action for good things. 

#### Proverbs 2:10 For if {shall come wisdom} into your consideration, and perception {for your soul good to be shall seem}; 

#### Proverbs 2:11 {counsel good} shall guard you, {reflection and sacred} will keep you, 

#### Proverbs 2:12 that it should rescue you from {way the evil}, and from the man speaking nothing trustworthy. 

#### Proverbs 2:13 O the ones abandoning {ways the straight} to go in the ways of darkness. 

#### Proverbs 2:14 O the ones being glad over evils, and rejoicing over {perverseness evil}; 

#### Proverbs 2:15 which paths are crooked, and {curved tracks their}; 

#### Proverbs 2:16 {to be far you to cause} from {way the straight}, and alien of a righteous design. O son, you should not let {overtake you bad counsel}, 

#### Proverbs 2:17 which left the instruction of youth, and {covenant the divine forgot}. 

#### Proverbs 2:18 For she put {near death her house}, and {lead by Hades with the earthborn her courses of action}. 

#### Proverbs 2:19 All the ones coming near with her shall not return; nor shall they overtake {paths straight}; for they are not overtaken by years of life. 

#### Proverbs 2:20 For if they went by {paths good}, they would have found even the paths of righteousness smooth. {will be gracious The inhabitants of the earth}, and the guileless will be left behind in her. 

#### Proverbs 2:21 For the upright shall encamp in the land, and the sacred ones will be left behind in it. 

#### Proverbs 2:22 And the ways of the impious {from the earth shall be destroyed}, and the lawbreakers shall be banished from it. 

#### Proverbs 3:1 O son, {my laws forget not}, and {my sayings give heed to} in your heart! 

#### Proverbs 3:2 For the length of existence, and years of life and peace shall be added to you. 

#### Proverbs 3:3 Charity and trust -- do not let them fail to you! but affix them upon your neck! write them upon the tablet of your heart! 

#### Proverbs 3:4 and you shall find favor. And think beforehand on the good things before the LORD and men! 

#### Proverbs 3:5 Be yielding with your whole heart upon God, and upon your own wisdom be not encouraged! 

#### Proverbs 3:6 In all your ways make her known! that she should cut straight your ways. 

#### Proverbs 3:7 Be not skilled of yourself, but fear God, and turn aside from all evil! 

#### Proverbs 3:8 Then shall there be healing to your body, and care to your bones. 

#### Proverbs 3:9 Esteem the LORD by your just toils, and dedicate to him from your fruits of righteousness! 

#### Proverbs 3:10 that {should be filled your storerooms} with fullness of grain, and wine {of your wine vats should gush out}. 

#### Proverbs 3:11 O son, do not have little regard for the instruction of the LORD, nor loosen up under his reproving! 

#### Proverbs 3:12 For whom the LORD loves he corrects; and he whips every son whom he welcomes. 

#### Proverbs 3:13 Blessed is the man who found wisdom, and the mortal who beholds intelligence. 

#### Proverbs 3:14 For it is better to trade for her, than for gold and silver treasures. 

#### Proverbs 3:15 {more valuable than And she is stones very costly}; and every valuable thing {not equal worth her is}. 

#### Proverbs 3:16 For length of existence and years of life are in her right hand; and in her left riches and glory. Out of her mouth goes forth in righteousness; and law and mercy {upon her tongue she wears}. 

#### Proverbs 3:17 Her ways {ways are good}, and all her paths are in peace. 

#### Proverbs 3:18 {a tree of life She is} to all the ones holding her; and to the ones leaning upon her {as upon the LORD are safe}. 

#### Proverbs 3:19 God in wisdom founded the earth; and he prepared the heavens in intelligence. 

#### Proverbs 3:20 In his perception abysses were torn, and clouds flowed dew. 

#### Proverbs 3:21 O son, you should not let it flow by; but heed my counsel and insight! 

#### Proverbs 3:22 that {should live your soul}, and favor should be around your neck; and it will be healing to your flesh, and care to your bones; 

#### Proverbs 3:23 that you should go yielded in peace in all your ways, and the foot of yours in no way should stumble. 

#### Proverbs 3:24 For if you should sit down, you will be without fear; and if you should repose, {with pleasure you shall sleep}. 

#### Proverbs 3:25 And you shall not be afraid of terror coming upon, nor the thrusting of the impious coming upon. 

#### Proverbs 3:26 For the LORD will be over all your ways, and he shall establish your foot that you should not be shaken. 

#### Proverbs 3:27 You should not be at a distance {good to do} to the one lacking, when you should have your hand to help. 

#### Proverbs 3:28 You should not say, Returning back, come back again! and tomorrow I will give; {able is with you while being good to do}; for you shall not see what shall give birth against you. 

#### Proverbs 3:29 You should not contrive {against your friend bad things}, the one sojourning and relying upon you. 

#### Proverbs 3:30 You should not be fond of quarreling against a man in vain, so that {not against you he should work evil}. 

#### Proverbs 3:31 You should not acquire evils of men's scorn, nor should you be jealous of their ways. 

#### Proverbs 3:32 {is unclean For before the LORD every lawbreaker}, {with and the righteous they do not sit together}. 

#### Proverbs 3:33 The curse of the LORD is in the houses of the impious, but the properties of the just are blessed. 

#### Proverbs 3:34 The LORD {the proud resists}, {to the humble but gives favor}. 

#### Proverbs 3:35 {glory The wise shall inherit}; but the impious exalted dishonor. 

#### Proverbs 4:1 Hear, O children, the instruction of a father, and take heed to know insight! 

#### Proverbs 4:2 {gift For a good I present to you}; {my word you should not abandon}. 

#### Proverbs 4:3 {a son For I was also to a father subject}, and being loved in the presence of a mother; 

#### Proverbs 4:4 the ones who spoke and taught me, saying, Establish our word in your heart! Keep the commandments! Do not forget! 

#### Proverbs 4:5 Acquire wisdom! Acquire understanding! You should not forget, nor should you ignore the saying of my mouth; nor should you turn aside from the words of my mouth. 

#### Proverbs 4:6 You should not abandon it, for it shall hold to you. Love it passionately! and it will keep you. 

#### Proverbs 4:7 {is the beginning Wisdom}, acquire wisdom! And in all of your possessing acquire understanding! 

#### Proverbs 4:8 Surround her with a rampart! and she shall exalt you. Esteem her! that she should keep you; 

#### Proverbs 4:9 that she should give {to your head a crown of favors}, {with a crown and of luxury should shield you}. 

#### Proverbs 4:10 Hear, O son, and receive my words! and {will be multiplied to you years of your life}, that to you there should be many ways of life. 

#### Proverbs 4:11 For the ways of wisdom I teach you; {I put on board and you tracks straight}. 

#### Proverbs 4:12 For when you should go {will not be hemmed in your footsteps}; and when you should run, you shall not tire. 

#### Proverbs 4:13 Take hold of my instruction! you should not let go; but keep it to yourself, for your life! 

#### Proverbs 4:14 {ways by impious You should not come}, nor be jealous of the ways of lawbreakers. 

#### Proverbs 4:15 In what ever place they should encamp, you should not come there. Turn aside from them and alter course! 

#### Proverbs 4:16 {not For they shall} sleep, unless they should have done evil. {is removed Sleep} from them, and they do not go to bed. 

#### Proverbs 4:17 For thus they feed well on grain of impiety; and by wine of a lawbreaker they are intoxicated. 

#### Proverbs 4:18 But the ways of the just are likened to light -- they radiate. They go before and give light until whenever {should set up the day}. 

#### Proverbs 4:19 But the ways of the impious are dark; they do not know how they stumble. 

#### Proverbs 4:20 O son, {to my saying take heed}, and to my words set aside your ear! 

#### Proverbs 4:21 so that {should not fail you your springs}. Keep them in your heart! 

#### Proverbs 4:22 {life for they are} to all the ones finding them, and {to all flesh healing}. 

#### Proverbs 4:23 With all guard, give heed to your heart! for from out of these things are the issues of life. 

#### Proverbs 4:24 Remove yourself from a crooked mouth, and {unjust lips far from you thrust away}! 

#### Proverbs 4:25 {your eyes straight Let see}, and your eyelids nod assent to the just! 

#### Proverbs 4:26 {straight tracks Make} for your feet, and {your ways straighten out}! 

#### Proverbs 4:27 You should not turn aside unto the right nor unto the left; but turn your foot from {way an evil}! For the ways, the ones of the right, {knows God}; but the ones perverting are of the left; but he {straight makes your tracks}, and {your goings in peace he shall lead before}. 

#### Proverbs 5:1 O son, {to my wisdom take heed}, {to my and words set aside your ear}! 

#### Proverbs 5:2 that you should guard {insight good}. And perception of my lips I give charge to you. Give no heed to a vile woman! 

#### Proverbs 5:3 For honey drops from the lips {woman of a harlot}, which for a time fattens your throat. 

#### Proverbs 5:4 Afterwards however {more bitter than bile you shall find it}, and being more sharpened rather than {sword a double-edged}. 

#### Proverbs 5:5 For {of folly the feet} lead {down the ones dealing with her with death unto Hades}; and her tracks are not established; 

#### Proverbs 5:6 {the ways for of life she does not come by}; {are slippery but her tracks}, and not well-known. 

#### Proverbs 5:7 Now then, O son, hear me! and you should not {void works do} of my words. 

#### Proverbs 5:8 {far Make from her your way}! You should not approach to doors of her houses; 

#### Proverbs 5:9 that you should not let {go to others your means of life}, and your livelihood to the unmerciful; 

#### Proverbs 5:10 that {should not be filled with strangers} your strength, and your toils {into houses of strangers should enter}; 

#### Proverbs 5:11 and you shall be repenting at last when ever {wears away the flesh} from your body. 

#### Proverbs 5:12 And you shall say, O how I detested instruction, and {reproofs turned aside my heart}! 

#### Proverbs 5:13 I did not hear the voice of one correcting me and teaching me; nor did I set aside my ear. 

#### Proverbs 5:14 By little I came unto every evil in the midst of the assembly and congregation. 

#### Proverbs 5:15 O son, drink waters from your own receptacles, and {from your own wells the flow}! 

#### Proverbs 5:16 Let {overflow to you the waters} from out of your own spring; and into your own squares let {go along your waters}! 

#### Proverbs 5:17 Let it be {to you alone existing}, and let not a stranger partake with you! 

#### Proverbs 5:18 The spring of your water -- let it be to you in particular! and be glad with the wife of your youth! 

#### Proverbs 5:19 Let your hind of friendship, and {filly your} of favors, consort with you! and in particular let her be esteemed by you, and be with you at all time! For in this friendship {accommodated a great deal you will be}. 

#### Proverbs 5:20 {not much Be} with the strange woman, nor hold {in embraces the one not your own}! 

#### Proverbs 5:21 {before For are the of God eyes the ways of a man}, {unto and all his tracks he watches}. 

#### Proverbs 5:22 Unlawful deeds {a man ensnare}; {chains and of ones own sins each is grasped by}. 

#### Proverbs 5:23 This man comes to an end with the uninstructed; and from the abundance of his own sustenance was cast forth, and perished through folly. 

#### Proverbs 6:1 O son, if you should guarantee a loan for your friend, you shall deliver up your hand to the enemy. 

#### Proverbs 6:2 {snare For are a strong a man's own lips}, and he is captured by the words of his own mouth. 

#### Proverbs 6:3 Do, O son, what I give charge to you, and preserve yourself! {you come For into the hands of evils on account of your friend}. Be not enfeebled! but you provoke even your friend whom you guaranteed a loan. 

#### Proverbs 6:4 You should not give sleep to your eyes nor slumber to your eyelids, 

#### Proverbs 6:5 so that you should escape as a doe from nooses, and as a fowl from out of a snare. 

#### Proverbs 6:6 Be as the ant, O lazy one, and be jealous beholding his ways; and become as that one -- wiser! 

#### Proverbs 6:7 For to that one there is no farm possession, nor {one compelling him is he having}, nor {under a master is he being}. 

#### Proverbs 6:8 He prepares {of summer the nourishment}, {much and also in the harvest he prepares} for the fete. 

#### Proverbs 6:9 For how long, O lazy one, do you recline? And when {from out of sleep will you arise}? 

#### Proverbs 6:10 A little then to sleep, and a little you sit down, and a little you slumber, and a little you fold your arms with hands to the breasts. 

#### Proverbs 6:11 So then {comes upon you as an evil traveler poverty}; and lack as a good runner. 

#### Proverbs 6:12 A man, a fool and a lawbreaker, shall go by ways not good. 

#### Proverbs 6:13 And the same beckons with the eyes, and makes signs with the foot, and teaches with the beckoning of his fingers. 

#### Proverbs 6:14 {being perverted And a heart} contrives evils; at all time such a one {disturbances concocts} to a city. 

#### Proverbs 6:15 On account of this {suddenly comes his destruction}; severance and {destruction irretrievable}. 

#### Proverbs 6:16 For he rejoices in all things which {detests the LORD}; and he is destroyed because of uncleanness of soul -- 

#### Proverbs 6:17 {eye an insulting}, {tongue an unjust}, hands pouring out {blood righteous}, 

#### Proverbs 6:18 and a heart contriving {devices evil}, and feet hurrying to do evil. 

#### Proverbs 6:19 {kindles lying witness An unjust}, and brings in addition judicial cases between brethren. 

#### Proverbs 6:20 O son, guard the laws of your father! and you should not thrust away the rules of your mother. 

#### Proverbs 6:21 But affix them upon your soul always, and bind them with a cord around your neck! 

#### Proverbs 6:22 When ever you should walk, bring it, and {with you let it be}! And when ever you should sleep, let it guard you! that in arising it should converse together with you. 

#### Proverbs 6:23 For {is a lamp the commandment of the law}, and a light, and a way of life, and reproof, and instruction; 

#### Proverbs 6:24 to guard you from {woman a married}, and from the distraction {tongue of a strange}. 

#### Proverbs 6:25 O son, let not {overcome you of beauty the desire}, nor {be caught your eyes} nor seized by her eyelids. 

#### Proverbs 6:26 For the value of a harlot is as much as even one bread loaf; and a woman {of men the precious souls ensnares}. 

#### Proverbs 6:27 Shall anyone tie up fire in his bosom, and his garments not incinerate? 

#### Proverbs 6:28 Or shall anyone walk upon coals of fire, and his feet shall not incinerate. 

#### Proverbs 6:29 So the one entering to {woman a married}; he shall not be acquitted, nor any one touching her. 

#### Proverbs 6:30 It is not a wonder if any be captured stealing; for he steals that he should fill up his soul when hungering; 

#### Proverbs 6:31 but if he should be captured he shall pay seven-fold, and {all his possessions by giving shall rescue himself}. 

#### Proverbs 6:32 But the adulterer, through lack of sense, {destruction for his soul procures}. 

#### Proverbs 6:33 Both griefs and dishonor he suffers, and his scorn shall not be wiped away into the eon. 

#### Proverbs 6:34 {is full For of zeal the rage of her husband}; he will not spare in the day of judgment. 

#### Proverbs 6:35 He will not bargain for any ransom of his hatred, nor part by many gifts. 

#### Proverbs 7:1 O son, keep my words, and my commandments hide for yourself! 

#### Proverbs 7:2 O son, esteem the LORD! and you shall strengthen; and besides him, do not fear another! Keep my commandments! and you shall spend life; and my words as if the pupil of your eyes. 

#### Proverbs 7:3 Put them on your fingers, and inscribe them upon the width of your heart! 

#### Proverbs 7:4 Speak wisdom {your sister to be}; and {intelligence as an acquaintance procure to yourself}! 

#### Proverbs 7:5 that she should keep you from {woman the strange and wicked}, if {words for you for favor she should put}. 

#### Proverbs 7:6 For from the window of her house {into the squares she leans} 

#### Proverbs 7:7 at whom ever she should behold of the foolish offspring -- a young man lacking of sense, 

#### Proverbs 7:8 passing by the corner in the corridors of her houses, speaking 

#### Proverbs 7:9 in darkness during the evening, when ever all is at rest nightly, or also at dimness. 

#### Proverbs 7:10 And the woman meets with him {the appearance having} of a harlot, which makes {of young men to flutter the heart}. 

#### Proverbs 7:11 {inciting And she is} and carnal, {in her house and do not stay still her feet}. 

#### Proverbs 7:12 {time For at certain outside she strays}, and another time {in the squares by every corner she lies in wait}. 

#### Proverbs 7:13 Then, taking hold, she fondles him; and with impudent face she says to him, 

#### Proverbs 7:14 {sacrifice a peace with me There is}, today I render my vows. 

#### Proverbs 7:15 Because of this I come forth for meeting you; feeling the absence of your face I have found you. 

#### Proverbs 7:16 In trimming, I have stretched my bed. {spreads I spread} from Egypt. 

#### Proverbs 7:17 I have sprinkled my bed with saffron, and my house with cinnamon. 

#### Proverbs 7:18 Come! for we should enjoy friendship until dawn. Come, for we should wrap up in passion. 

#### Proverbs 7:19 {is not For at hand my husband} in the house; he has gone {way a long}, 

#### Proverbs 7:20 {a bundle of silver taking} in his hands; for only after {days many} will he come back again to his house. 

#### Proverbs 7:21 {she led astray And him} with much companionship, {with nooses and also}. By the things from her lips she led him aground. 

#### Proverbs 7:22 And he followed after her, being easily led on, and as an ox {unto slaughter is led}, and as a dog to bonds, and as a stag shot with a bow, 

#### Proverbs 7:23 striking into the liver; and he hastens as a fowl into a snare, not seeing that {for his life he runs}. 

#### Proverbs 7:24 Now then, O son, hear me, and take heed to the sayings of my mouth! 

#### Proverbs 7:25 Do not turn aside to her ways with your heart! and you should not be misled by her short-cuts. 

#### Proverbs 7:26 {many For in piercing she has thrown down}, and innumerable are whom she has murdered. 

#### Proverbs 7:27 {is the ways of Hades Her house}; they lead down into the storerooms of death. 

#### Proverbs 8:1 You {wisdom shall proclaim}, that intellect should obey you. 

#### Proverbs 8:2 {upon For the high extremities she is}, {in the midst and of the paths she stands}. 

#### Proverbs 8:3 For by the gates of mighty ones she is occupied; and in the entrances sings, saying, 

#### Proverbs 8:4 You, O men, I comfort; and I let go with my voice to the sons of men. 

#### Proverbs 8:5 Comprehend, O guileless ones, astuteness! and O uninstructed, insert it in heart! 

#### Proverbs 8:6 Listen to me! {serious things for I shall speak}, and I will offer {from my lips straight things}! 

#### Proverbs 8:7 For {truth shall meditate my throat}; {are abhorrent and before me lips lying}. 

#### Proverbs 8:8 {are with righteousness All the sayings of my mouth}; nothing in them is crooked nor insidious. 

#### Proverbs 8:9 All is face to face to the ones perceiving; and straight to the ones finding knowledge. 

#### Proverbs 8:10 Receive instruction, and not silver! and knowledge above {gold tried}. 

#### Proverbs 8:11 {is better For wisdom stones than very costly}; and every esteemed thing {not worth her is}. 

#### Proverbs 8:12 I wisdom encamped with counsel and knowledge; and {reflection I called upon}. 

#### Proverbs 8:13 The fear of the LORD detests injustice; insolence also, and pride, and the ways of evil ones; {have detested and I} the perverting ways of evil men. 

#### Proverbs 8:14 {are mine Counsel and safety}; {is mine intelligence}, {is mine and strength}. 

#### Proverbs 8:15 By me kings reign, and the mighty ones write righteousness. 

#### Proverbs 8:16 Through me great men become magnified, and sovereigns through me take hold of the earth. 

#### Proverbs 8:17 I {the ones me being fond of love}; and the ones seeking me shall find favor. 

#### Proverbs 8:18 Wealth and glory exist by me, and {property much} and righteousness. 

#### Proverbs 8:19 Best to gather my fruit than gold and {stone precious}; and my produce is better than {silver choice}. 

#### Proverbs 8:20 {in the ways of righteousness I walk}, and {in the midst of paths of reason I return}; 

#### Proverbs 8:21 that I shall portion {to the ones loving me substance}; and their treasuries I shall fill up of good things. If I should announce to you the things {each day happening}, I will remember also {the things of the eon to count}. 

#### Proverbs 8:22 The LORD created me the head of his ways for his works. 

#### Proverbs 8:23 Before the eon he founded me in the beginning, before the {the earth making}; 

#### Proverbs 8:24 and before the {the abysses making}; before the coming forth of the springs of waters; 

#### Proverbs 8:25 before {of the mountains the seating}; and before all the hills he engenders me. 

#### Proverbs 8:26 The LORD made regions, and uninhabited places, and uttermost parts of the inhabitable world under the heavens. 

#### Proverbs 8:27 When he prepared the heaven, I was present with him, and when he separated his throne upon the winds; 

#### Proverbs 8:28 when {strong he made the upward clouds}; and as {safe he made the springs under heaven}; 

#### Proverbs 8:29 in the putting {to the sea of his restriction}; and the waters shall not go by his mouth; and as {strong he made the foundations of the earth}, 

#### Proverbs 8:30 I was by him. {being in accord I was}, in which he rejoiced with. {each day And} I was glad in front of him at all time, 

#### Proverbs 8:31 even when he was pleased with the {the inhabitable world completing}, and was pleased among the sons of men. 

#### Proverbs 8:32 Now then, O son, hear me! and blessed are the ones {my ways guarding}. 

#### Proverbs 8:33 Hear wisdom! and you should be wise, and you should not seal it up. Blessed is the man who shall listen to me, and the man who {my ways shall guard}; 

#### Proverbs 8:34 being awake at my doors each day, giving heed at the doorposts of my entrances. 

#### Proverbs 8:35 For my issues are the issues of life, and in them {is prepared volition} from the LORD. 

#### Proverbs 8:36 But the ones sinning against me are impious unto their own souls; and the ones detesting me love death. 

#### Proverbs 9:1 Wisdom built to herself a house, and she propped up {columns seven}. 

#### Proverbs 9:2 She slew the things for herself which are offered in sacrifices; she mixed into a basin wine for herself, and she prepared a table for herself. 

#### Proverbs 9:3 She sent her own servants, calling together with high proclamation, upon a basin, saying, 

#### Proverbs 9:4 Whosoever is a fool, turn aside to me! And to the ones lacking of sense, she said, 

#### Proverbs 9:5 Come eat of my bread loaves, and drink wine which I mixed for you! 

#### Proverbs 9:6 Cease folly! and you shall live. And seek intelligence! that you should spend life. And keep straight {by knowledge understanding}! 

#### Proverbs 9:7 The one correcting evil men shall take on himself dishonor; and in reproving, the impious scoffs at himself. 

#### Proverbs 9:8 Do not reprove evil men! so that they should not detest you. Reprove a wise man! and he shall love you. 

#### Proverbs 9:9 Give to a wise man opportunity! and he will be wiser; make things known to a just man! and he shall proceed to receive more. 

#### Proverbs 9:10 The beginning of wisdom is fear of the LORD; and the counsel of holy ones is understanding. For to know the law {consideration is of good}. 

#### Proverbs 9:11 For in this manner {a long you shall live} time, and {shall be added to you years of life}. 

#### Proverbs 9:12 O son, if {wise you be}, {to yourself wise you shall be}; and if {evil you should turn out to be}, {alone then you shall draw evils}. 

#### Proverbs 9:13 {woman A foolish and bold lacking of a morsel becomes who does not have knowledge of shame}. 

#### Proverbs 9:14 She sits at the doors of her own house upon a chair, visibly in the squares, 

#### Proverbs 9:15 calling the ones passing by the way, and the ones going straight on their ways, saying, 

#### Proverbs 9:16 Whoever is most foolish of you, turn aside to me! And to the ones lacking intelligence I rouse, saying, 

#### Proverbs 9:17 Bread loaves of secrets {with pleasure you touch}, and water of fraud {sweet you drink}! 

#### Proverbs 9:18 But he does not know that earth-born men {by her are destroyed}, and {upon the perch of Hades he meets}. 

#### Proverbs 10:1 {son A wise} gladdens a father, {son but a foolish} is distress to a mother. 

#### Proverbs 10:2 {shall not benefit Treasures} the lawless; but righteousness shall rescue from out of death. 

#### Proverbs 10:3 {will not famish The LORD soul a just}; but the life of the impious he will prostrate. 

#### Proverbs 10:4 Poverty {a man humbles}; but the hands of the vigorous enrich. A son being corrected will be wise; but the foolish {for a servant he will treat}. 

#### Proverbs 10:5 {is preserved from sweltering heat son An intelligent}; but destruction by the wind comes at the harvest to a son who is a lawbreaker. 

#### Proverbs 10:6 A blessing of the LORD is upon the head of the just; but the mouth of the impious he covers {mourning with untimely}. 

#### Proverbs 10:7 Remembrance of the just is with commendation; but the name of the impious is extinguished. 

#### Proverbs 10:8 A wise heart shall receive commandments; but the open-mouthed {lips by crooked shall be tripped up}. 

#### Proverbs 10:9 The one who goes simply, goes complying; but the one perverting his ways shall be known. 

#### Proverbs 10:10 The beckoning eye with treachery gathers {for men distresses}; but the one reproving with an open manner makes peace. 

#### Proverbs 10:11 The spring of life is in the hand of the just; {the mouth but of the impious shall cover destruction}. 

#### Proverbs 10:12 Hatred raises up altercation; {all but the ones not fond of altercations shall cover friendship}. 

#### Proverbs 10:13 The one who {from his lips brings forth wisdom}, {with a rod beats man the heartless}. 

#### Proverbs 10:14 The wise shall hide perception; but the mouth of the precipitous approaches destruction. 

#### Proverbs 10:15 The property of rich men {city is a fortified}; but destruction of impious ones is poverty. 

#### Proverbs 10:16 The works of the just {life produce}; but the fruit of the impious produces sins. 

#### Proverbs 10:17 {the ways of life keeps Instruction}, but instruction unascertained wanders. 

#### Proverbs 10:18 {cover hatred lips Just}; but the ones bringing forth reviling are most foolish. 

#### Proverbs 10:19 By many words you shall not flee from sin; but in the sparing of your lips you will be intelligent. 

#### Proverbs 10:20 {is silver being purified The tongue of the just}; but the heart of the impious shall fail. 

#### Proverbs 10:21 The lips of just ones have knowledge of high things; but the fools {with lack come to an end}. 

#### Proverbs 10:22 The blessing of the LORD upon the head of the just -- this enriches, and in no way shall {be added to it distress in heart}. 

#### Proverbs 10:23 With laughter a fool commits evils; but wisdom {to a man births intelligence}. 

#### Proverbs 10:24 By destruction an impious man is carried round about; but the desire of the just is accepted. 

#### Proverbs 10:25 In the coming of the blast {are obliterated the impious}; but the just in turning aside escapes into the eon. 

#### Proverbs 10:26 As an unripe grape to the teeth is hurtful, and smoke to the eyes; thus unlawfulness to the ones dealing with it. 

#### Proverbs 10:27 The fear of the LORD adds days; but the years of the impious shall be lessened. 

#### Proverbs 10:28 {lingers with the just Gladness}; but the hope of the impious shall be destroyed. 

#### Proverbs 10:29 {is the fortress of the sacred The fear of the LORD}; but destruction to the ones working evils. 

#### Proverbs 10:30 The just {into the eon shall not give way}; but the impious shall not live on the earth. 

#### Proverbs 10:31 The mouth of the just drops wisdom; but the tongue of the unjust shall be totally ruined. 

#### Proverbs 10:32 The lips {men of just} drop favors; but the mouth of the impious is perverted. 

#### Proverbs 11:1 {yoke balance scales Deceitful} are an abomination before the LORD; {weight but a just} is acceptable to him. 

#### Proverbs 11:2 Where ever {should enter insult}, {there is also dishonor}; but the mouth of the humble meditates upon wisdom. 

#### Proverbs 11:3 {in dying The just forsakes regret}; but beforehand {takes place and incurs ridicule of the impious the destruction}. 

#### Proverbs 11:4 The soundness of the upright will guide them; and a fall {the ones disregarding will plunder} them. {will not benefit Possessions} in the day of rage; and righteousness shall rescue from death. 

#### Proverbs 11:5 Righteousness unblemished cuts straight ways; but impiety falls among injustice. 

#### Proverbs 11:6 Righteousness {men of upright} shall rescue them; but by thoughtlessness {are captured lawbreakers}. 

#### Proverbs 11:7 Of the coming to an end {man of a just} {is not destroyed hope}; but the boasting of the impious is destroyed. 

#### Proverbs 11:8 The just {from out of a trap are taken}; {instead of him and is delivered up the impious one}. 

#### Proverbs 11:9 In the mouth of impious men is a snare to fellow-countrymen; but the perception of just men is prosperous. 

#### Proverbs 11:10 By the good things of just men {is set up a city}; and in the destruction of the impious there is a leap for joy. 

#### Proverbs 11:11 By the blessing of the upright {shall be exalted a city}; but by the mouths of impious men it shall be razed. 

#### Proverbs 11:12 {sneers at fellow-countrymen A man lacking of sense}; {man but an intelligent restfully leads}. 

#### Proverbs 11:13 A man being double-tongued uncovers plans in the sanhedrin; but the trustworthy man in breath {hidden keeps matters}. 

#### Proverbs 11:14 The ones who do not exist with guidance fall as leaves; but deliverance exists in much counsel. 

#### Proverbs 11:15 The wicked man does evil whenever he mixes with a just man; and he detests the sound of safety. 

#### Proverbs 11:16 {wife A gracious} raises {to her husband glory}; but a throne of dishonor is a wife detesting righteous things. {of riches The lazy lacking become}; but the vigorous establish riches. 

#### Proverbs 11:17 {to his soul good does man A merciful}; {totally ruins but his body the unmerciful}. 

#### Proverbs 11:18 The impious do {works unjust}; but the seed of the just is a wage of truth. 

#### Proverbs 11:19 {son A just} engenders unto life; but the persecution of the impious is unto death. 

#### Proverbs 11:20 {are an abomination to the LORD Perverting ways}; {are acceptable but to him all unblemished ones in the way}. 

#### Proverbs 11:21 {against a hand hands The one putting unjustly not unpunished will be} of evils; but the one sowing righteousness shall receive {wage a trustworthy}. 

#### Proverbs 11:22 As a ring of gold in a nose of a pig; so {woman to an evil-minded beauty}. 

#### Proverbs 11:23 {the desire of the just All} is good; but the hope of the impious shall perish. 

#### Proverbs 11:24 There are the ones {their own seed sowing more making}; and there are also the ones gathering having less. 

#### Proverbs 11:25 {soul is being blessed Every sincere}; but a man inclined to rage is not decent. 

#### Proverbs 11:26 {the one hoarding grain May} leave it to the nations; but a blessing be on the head of the one sharing. 

#### Proverbs 11:27 The one contriving good things seeks {favor good}; but the one seeking evil things, evil shall overtake him. 

#### Proverbs 11:28 The one yielding upon his own riches, this one shall fall; but the one assisting just men shall rise. 

#### Proverbs 11:29 The one not being accommodating to his own house shall inherit the wind; {will be a slave and the fool} to the intelligent. 

#### Proverbs 11:30 From out of the fruit of righteousness germinates a tree of life; {are removed but at unseasonable times the lives of lawbreakers}. 

#### Proverbs 11:31 If then the just are hardly delivered, the impious one and the sinner, where shall he appear? 

#### Proverbs 12:1 The one loving instruction loves perception; but the one detesting reproofs is a fool. 

#### Proverbs 12:2 Better the one finding favor from the LORD; but a man who is a lawbreaker shall be silenced. 

#### Proverbs 12:3 {will not keep straight A man} by a lawless deed; but the roots of the just shall not be lifted away. 

#### Proverbs 12:4 {wife A courageous} is a crown to her husband; but as {in wood the worm}, so {her husband destroys wife an evil doing}. 

#### Proverbs 12:5 The devices of the just are true judgments; {devise but the impious} treachery. 

#### Proverbs 12:6 The words of the impious are deceitful for blood; but the mouth of the upright shall rescue them. 

#### Proverbs 12:7 Of which ever time {should be over turned the impious} he vanishes; but the houses of the just remain. 

#### Proverbs 12:8 The mouth of the discerning is lauded by a man; but the dull of heart is sneered at. 

#### Proverbs 12:9 Better a man with dishonor serving himself, than {value on himself one putting}, and feeling want of bread. 

#### Proverbs 12:10 A just one pities the lives of his cattle; but the feelings of compassion of the impious are unmerciful. 

#### Proverbs 12:11 The one working his own ground shall be filled up with bread loaves; but the ones pursuing vain things are lacking of sense. The one who is pleasure-bent in wine drinking pastimes, {in his own fortresses shall leave behind dishonor}. 

#### Proverbs 12:12 The desires of the impious are evil things; but the roots of the pious are in fortresses. 

#### Proverbs 12:13 Through the sin of the lips {falls into snares a sinner}; {flees but from them the just}. 

#### Proverbs 12:14 From fruits of the mouth a soul of a man shall be filled of good things; and a recompense of his lips shall be rendered to him. 

#### Proverbs 12:15 The ways of fools are straight before them; {listens to but advice the wise}. 

#### Proverbs 12:16 A fool daily publishes his anger; {hides but his own dishonor one astute}. 

#### Proverbs 12:17 {by displaying trust reports The just man}; but the witness of the unjust is deceitful. 

#### Proverbs 12:18 There are the ones speaking -- they pierce as a sword; but the tongues of the wise heal. 

#### Proverbs 12:19 {lips True} straighten testimony; {witness but a quick tongue has an unjust}. 

#### Proverbs 12:20 Treachery is in the heart of the one contriving evils; but the ones wanting peace shall be glad. 

#### Proverbs 12:21 {shall not please the just Anything unjust}; but the impious shall be filled with bad things. 

#### Proverbs 12:22 {are an abomination to the LORD lips Lying}; but the one dealing in trust is accepted by him. 

#### Proverbs 12:23 {man A discerning} is a throne of perception; but the heart of fools shall meet with curses. 

#### Proverbs 12:24 The hand of chosen men shall prevail easily; but the deceitful will be for plunder. 

#### Proverbs 12:25 A fearful word {the heart disturbs} of a man; {message but a good} gladdens him. 

#### Proverbs 12:26 {arbitrator a just of himself A friend will be}; but the ones sinning pursue evil things, and the way of the impious misleads them. 

#### Proverbs 12:27 {shall not succeed in A deceitful man} hunting; {possession but is an esteemed man a pure}. 

#### Proverbs 12:28 In the ways of righteousness is life; but the ways of the resentful are unto death. 

#### Proverbs 13:1 {son An astute} is subject to his father; {son but an unhearing} goes unto destruction. 

#### Proverbs 13:2 From fruits of righteousness {shall eat the good}; but the lives of lawbreakers will be destroyed unseasonably. 

#### Proverbs 13:3 The one who guards his own mouth gives heed to his own soul; but the one with precipitous lips shall terrify himself. 

#### Proverbs 13:4 {with desire is Every idle man}; but the hands of the vigorous are caring. 

#### Proverbs 13:5 {word an unjust detest The just}; but the impious man is ashamed, and shall not have an open manner. 

#### Proverbs 13:6 Righteousness guards the guileless in the way; but the {impious ones vile} produce sin. 

#### Proverbs 13:7 There are the ones enriching themselves, {nothing having}; and there are the ones abasing themselves with many riches. 

#### Proverbs 13:8 {is the ransom A man's of his life own riches}; but the poor does not stand at intimidation. 

#### Proverbs 13:9 Light to the just is always; light for the impious is extinguished. 

#### Proverbs 13:10 An evil man {with insult practices evil}; but the {themselves are arbitrating wise}. 

#### Proverbs 13:11 Substance being hastily obtained with lawlessness {less becomes}; but the one gathering for himself with piety shall be multiplied. The just pities and lends. 

#### Proverbs 13:12 Better is the one commencing help in heart, than the one promising, and {to hope leads another}; {is a tree for of life desire a good}. 

#### Proverbs 13:13 The one who disdains a matter, shall be disdained by it; but the one fearing a commandment, this one is in health. {son To a deceitful} nothing will be good; {servant but a wise prosperous will be} in actions, and {shall prosper his way}. 

#### Proverbs 13:14 The law for the wise is a spring of life; but the mindless man {by a snare shall die}. 

#### Proverbs 13:15 {understanding Good} gives favor; but to know the law {consideration is of good}; but the ways of the disdaining end in destruction. 

#### Proverbs 13:16 Every astute man acts with knowledge; but the fool spreads forth {for himself evil}. 

#### Proverbs 13:17 {king A rash} falls into evils; {messenger but a wise} shall rescue him. 

#### Proverbs 13:18 Poverty and dishonor are removed by instruction; and the one guarding reproofs shall be extolled. 

#### Proverbs 13:19 The desires of the impious delight the soul; but the works of the impious are far from knowledge. 

#### Proverbs 13:20 The one going with wise men, will be wise; but the one going with fools shall be known. 

#### Proverbs 13:21 {ones sinning shall pursue Evils}; but {the just shall overtake good things}. 

#### Proverbs 13:22 A good man shall inherit sons of sons; {are treasured up and for the just the riches of the impious}. 

#### Proverbs 13:23 The just shall spend {in wealth years many}; but the unjust shall perish suddenly. 

#### Proverbs 13:24 The one who spares the staff detests his son; but the one loving carefully corrects. 

#### Proverbs 13:25 The just in eating fills up his soul; but souls of the impious go lacking. 

#### Proverbs 14:1 Wise women build houses; but the foolish razes her house by her hands. 

#### Proverbs 14:2 The one going rightly fears the LORD; but the crooked one {in his ways shall be dishonored}. 

#### Proverbs 14:3 From out of the mouth of fools is a staff of insult; but the lips of the wise keep them. 

#### Proverbs 14:4 Where there are no oxen, the stables are clean; and where there is much produce, {is apparent of the ox the strength}. 

#### Proverbs 14:5 {witness A trustworthy} does not lie; {kindles but a lying witness} unjust acts. 

#### Proverbs 14:6 You shall seek wisdom with bad men, and you shall not find it; but good sense from the intelligent is easily managed. 

#### Proverbs 14:7 All things are adverse {man to a foolish}; {are shields but for good sense lips wise}. 

#### Proverbs 14:8 The wisdom of the astute will realize their ways; but the thoughtlessness of fools leads unto delusion. 

#### Proverbs 14:9 The houses of lawbreakers shall owe cleansing; but the houses of the just are acceptable. 

#### Proverbs 14:10 The heart of a man is sensitive {distress of his soul's}; but whenever he should be glad, he shall not intermix insult. 

#### Proverbs 14:11 The houses of the impious shall be obliterated; but the tents of the ones keeping straight shall stand. 

#### Proverbs 14:12 There is a way which seems to be straight by men, but the finalities of it come into the lower branch of Hades. 

#### Proverbs 14:13 {with gladness does not mingle Distress}; and the finality of joy {into mourning comes}. 

#### Proverbs 14:14 {his own ways shall be filled with The bold-hearted}; {with and his thoughts man a good}. 

#### Proverbs 14:15 The guileless believe every word; but the astute one comes to repentance. 

#### Proverbs 14:16 A wise man, fearing, turns aside from evil; but the fool, yielding to himself, mixes in with the lawless one. 

#### Proverbs 14:17 A man quick to rage acts with thoughtlessness; {man but an intelligent many things endures}. 

#### Proverbs 14:18 {shall portion Fools} evil; but the astute shall hold to good sense. 

#### Proverbs 14:19 {shall slip Evil men} before good men; and the impious will attend the doors of the just. 

#### Proverbs 14:20 Friends shall detest {friends poor}; but friends of the rich are many. 

#### Proverbs 14:21 The one dishonoring the needy sins; but the one showing mercy on the poor is most blessed. 

#### Proverbs 14:22 The ones wandering contrive evils; but mercy and truth are contrived by the good. {do not have knowledge of mercy and trust The fabricators of evils}; but charity and trust are by {fabricators good}. 

#### Proverbs 14:23 With every one having concern there is extra; but the pleasure-bent and unfeeling {with lack will be}. 

#### Proverbs 14:24 The crown of the wise is their riches; but the pastime of fools is evil. 

#### Proverbs 14:25 {shall rescue from evils a soul witness A trustworthy}; {kindles but lying a deceitful man}. 

#### Proverbs 14:26 In the fear of the LORD hope is strength; and to his children he leaves a support. 

#### Proverbs 14:27 The order of the LORD is a spring of life, and it causes one to turn aside from the snare of death. 

#### Proverbs 14:28 {is in an abundant nation Glory of a king}; but in a wanting people there is destruction of a mighty one. 

#### Proverbs 14:29 A lenient man is abundant in intelligence; but the faint-hearted is strongly foolish. 

#### Proverbs 14:30 A gentle-minded man {of the heart is a healer}; {is a moth but for the bones heart a sensitive}. 

#### Proverbs 14:31 The one extorting the needy provokes the one making him; but the one esteeming him shows mercy on the poor. 

#### Proverbs 14:32 {in his evil shall be thrust away The impious}; the one complying in his own sacredness is just. 

#### Proverbs 14:33 {in the heart of a good man rests Wisdom}; but in the heart of fools it is not determined. 

#### Proverbs 14:34 Righteousness raises up high a nation; {lessen but tribes sins}. 

#### Proverbs 14:35 {is acceptable to a king officer An intelligent}; and by his own versatility he removes dishonor. 

#### Proverbs 15:1 Anger destroys even the intelligent; but the answer of a penitent man returns rage; {word but a distressing} raises up angers. 

#### Proverbs 15:2 The tongue of the wise {of good has knowledge}; but the mouth of fools announces evils. 

#### Proverbs 15:3 In every place the eyes of the LORD watch {bad both} and good. 

#### Proverbs 15:4 The healing tongue is a tree of life, and the one preserving it shall be filled of spirit. 

#### Proverbs 15:5 A fool sneers at the instruction of his father; but the one keeping his commandments is more astute. In superabundant righteousness {strength is abundant}; but the impious entirely rooted from the earth shall be destroyed. 

#### Proverbs 15:6 In the houses of the just {strength is much}; but the fruits of the impious shall be destroyed. 

#### Proverbs 15:7 The lips of the wise are bound by good sense; but the hearts of fools are not safe. 

#### Proverbs 15:8 The sacrifices of the impious are an abomination to the LORD; but the vows of the ones going straight are accepted by him. 

#### Proverbs 15:9 {are an abomination to the LORD The ways of the impious}; {the ones pursuing righteousness he loves}. 

#### Proverbs 15:10 The instruction of the guileless is made known by the ones passing by; but the ones detesting reproofs come to an end disgracefully. 

#### Proverbs 15:11 Hades and destruction are made apparent by the LORD; how not also the hearts of men? 

#### Proverbs 15:12 {shall not love The uninstructed} the ones reproving him; and with the wise he shall not consort. 

#### Proverbs 15:13 With the heart being glad the face flourishes; {in but distresses being} it looks downcast. 

#### Proverbs 15:14 {heart An upright} seeks perception; but the mouth of the uninstructed shall know evils. 

#### Proverbs 15:15 All the time the eyes of evil ones favorably receive evil things; but the good {tranquil are always}. 

#### Proverbs 15:16 Better a small portion with the fear of the LORD; than {treasures great} with fearlessness. 

#### Proverbs 15:17 Better hospitality of vegetables with friendship and favor, than a fete of calves with hatred. 

#### Proverbs 15:18 A man inclined to rage makes preparations for battle; but a lenient man {even the one about to go to battle soothes}. The lenient man shall extinguish litigations; but the impious raises them rather. 

#### Proverbs 15:19 The ways of the idle make a bed in thorn-bushes; but the ways of the vigorous are very busy. 

#### Proverbs 15:20 {son A wise} gladdens a father; {son but a foolish} sneers at his mother. 

#### Proverbs 15:21 {of an unthinking man The roads} are lacking of sense; {man but an intelligent in a straightened way goes}. 

#### Proverbs 15:22 {procrastinate by devices The ones not honoring the sanhedrins}; but in the hearts of ones counseling abides counsel; 

#### Proverbs 15:23 for in no way shall {obey an evil man} it; nor shall he say {timely anything}, even for {good the common}. 

#### Proverbs 15:24 {are ways of life The thoughts of the discerning}; that turning aside from Hades he should be delivered. 

#### Proverbs 15:25 {the houses of the arrogant tears down The LORD}; and he supports the boundary of the widow. 

#### Proverbs 15:26 {is an abomination to the LORD The devise of the unjust}; {of the pure but the sayings} are serious. 

#### Proverbs 15:27 {totally ruins himself The one receiving bribes}; but the one detesting {of bribes the receipts} is delivered. Charity and trust clear away sins; and the fear of the LORD turns aside every one from evil. 

#### Proverbs 15:28 The hearts of the just meditate trust; but the mouth of the impious answers evil things. {are acceptable with the LORD The ways men of just}; and through them even enemies {friends become}. 

#### Proverbs 15:29 {is far at a distance God} from the impious; but vows of just ones he heeds. Better are few receipts with righteousness, than abundant produce with injustice. 

#### Proverbs 15:30 {viewing The eye} good gladdens the heart; {reputation and a good} fattens the bones. 

#### Proverbs 15:31 The one hearing reproofs of life {in the midst of the wise shall lodge}. 

#### Proverbs 15:32 The one who thrusts away instruction detests himself; but the one giving heed to reproofs loves his life. 

#### Proverbs 15:33 The fear of the LORD is instruction and wisdom; and the sum of glory shall be the response for it. {go before But the humble} glory; 

#### Proverbs 16:1 Let the heart of a man consider just things, that {by God should set right his footsteps}. All the works of the humble are apparent by God; but the impious {in day an evil shall be destroyed}. 

#### Proverbs 16:2  

#### Proverbs 16:3  

#### Proverbs 16:4  

#### Proverbs 16:5 {is unclean with God Every proud heart}; {a hand and against hands a man putting} unjustly shall not be acquitted. The beginning {way of a good} is to do just things; and it is more acceptable by God rather than to sacrifice sacrifices. The one seeking the LORD shall find knowledge with righteousness; and the ones rightly seeking him shall find peace. All the works of the LORD are with righteousness; {is kept and the impious} for {day the evil}. 

#### Proverbs 16:8  

#### Proverbs 16:10 An oracle is upon the lips of a king; but in judgment, in no way should {be misled his mouth}. 

#### Proverbs 16:11 The crux of the yoke balance scale is righteousness with God; and {works his weights are just}. 

#### Proverbs 16:12 {is an abomination to a king The one doing evils}; for with righteousness {is prepared the throne of sovereignty}. 

#### Proverbs 16:13 {are acceptable to the king lips Just}; {words and straight loves the LORD}. 

#### Proverbs 16:14 The rage of a king is a messenger of death; {man but a wise} will appease him. 

#### Proverbs 16:15 {is in the light of life The son of a king}; and the ones acceptable to him are as a cloud of late rain. 

#### Proverbs 16:16 Nests of wisdom are more preferred than gold; and nests of intelligence more preferred than silver. 

#### Proverbs 16:17 The paths of life turn aside from evils; {are length and of existence the ways of righteousness}. The one receiving instruction {among good things will be}; and the one keeping reproofs shall be made wise. The one who guards his own ways gives heed to his own soul; and the one loving his life shall spare his mouth. 

#### Proverbs 16:18 {before destruction takes the lead Insolence}; and before a calamitous downfall evil thinking. 

#### Proverbs 16:19 Better a gentle-minded one with a low estate, than one who divides spoils with the arrogant. 

#### Proverbs 16:20 The one discerning in matters is an inventor of good things; and the one yielding upon God is most blessed. 

#### Proverbs 16:21 {the wise and discerning vile Men call}; but the ones sweet in words {much shall be heard}. 

#### Proverbs 16:22 The spring of life is insight to the ones acquiring; but the instruction of fools is evil. 

#### Proverbs 16:23 The heart of the wise shall comprehend the things from his own mouth; and upon lips he shall wear knowledge. 

#### Proverbs 16:24 {are honeycombs of honey words Good}; and the sweetness of them is healing for the soul. 

#### Proverbs 16:25 There are ways that seem to be straight to a man, however the finalities of them look into the lower branch of Hades. 

#### Proverbs 16:26 A man in toils toils for himself, and expels {from him destruction}. 

#### Proverbs 16:27 However the crooked man {upon his own mouth wears destruction}. {man A foolish} digs {for himself evils}; and upon his own lips treasures up fire. 

#### Proverbs 16:28 {man A crooked} spreads evils, and by the torch of treachery lights a fire for evils, and he parts friends. 

#### Proverbs 16:29 A man who is a lawbreaker puts {to test his friends}, and takes them ways not good. 

#### Proverbs 16:30 Fixing firmly his eyes, he devises perverted things; and he confirms with his lips all the evils; this man is a furnace of evil. 

#### Proverbs 16:31 The crown of boasting is old age; {in and the ways of righteousness it is found}. 

#### Proverbs 16:32 Better {man a lenient} than a strong man; and a man of intelligence than one having {farm a great}; and the one holding his anger is better than one overtaking a city. 

#### Proverbs 16:33 Into enfolded arms come all things to the unjust; {are from but the LORD all just things}. 

#### Proverbs 17:1 Better a morsel with satisfaction in peace, than a house full of many good things, and unjust things offered for sacrifices with battles. 

#### Proverbs 17:2 {servant An intelligent} shall prevail over {masters foolish}; and among brethren he shall divide portions. 

#### Proverbs 17:3 As {tried in a furnace silver and gold}; so choice hearts by the LORD. 

#### Proverbs 17:4 A bad man obeys the tongue of lawbreakers; and an unjust man heeds {lips lying}. 

#### Proverbs 17:5 The one ridiculing the poor provokes the one making him. And the one rejoicing at one being destroyed shall not be acquitted; but the one showing compassion shall be shown mercy. 

#### Proverbs 17:6 {are the crown of the aged Children's children}; {are the boasting and children} of their fathers. {is of the trustworthy The entire world of things}; but for the unbelieving not an obolus. 

#### Proverbs 17:7 {shall not suit a fool lips Trustworthy}, nor {to the just lips lying}. 

#### Proverbs 17:8 {wage is a favorable Instruction to the ones employing it}; and where ever it shall turn, the way shall be prosperous. 

#### Proverbs 17:9 The one who hides offences seeks friendship; but the one who detests hiding it sets apart friends and family members. 

#### Proverbs 17:10 {breaks down Intimidation} the heart of the intelligent; but a fool being whipped does not perceive. 

#### Proverbs 17:11 Disputes arise with every evil man; but the LORD {angel an unmerciful shall send forth} against him. 

#### Proverbs 17:12 {shall fall unto Anxiety man an intelligent}; but the fools shall argue evil things. 

#### Proverbs 17:13 The one who repays evil things for good things, {shall not be moved evil things} from out of his house. 

#### Proverbs 17:14 {authority shall give to words The sovereignty of righteousness}; {lead but to lack faction and fighting}. 

#### Proverbs 17:15 The one who {as just judges the unjust}, {as unjust or the just}, is unclean and abominable before God. 

#### Proverbs 17:16 Why did {exist riches} to the fool? {to acquire for wisdom the heartless will not be able}. The one who {high makes his own house} seeks destruction; and the one being crooked to learn shall fall into evils. 

#### Proverbs 17:17 For all time {the friend let} exist to you! {the brethren in distresses profitable let be}! for this favor they were born. 

#### Proverbs 17:18 {man A foolish} claps and rejoices over himself, as also the one guaranteeing a loan by surety for his own friend. 

#### Proverbs 17:19 The one fond of sinning rejoices in fights; 

#### Proverbs 17:20 and the hard-hearted one does not meet with good things. A man with a changeable tongue will fall into evils; 

#### Proverbs 17:21 and the heart of a fool is grief to its possessor. {is not glad A father} over {son an uninstructed}; {son but an intelligent} gladdens his mother. 

#### Proverbs 17:22 A heart being glad {to be in good health makes}; {man but a distressed} dries the bones. 

#### Proverbs 17:23 One receiving gifts in enfolded arms unjustly does not greatly prosper in the ways; and an impious man turns aside the ways of righteousness. 

#### Proverbs 17:24 The countenance {is discerning man of a wise}; but the eyes of the fool are unto the uttermost parts of the earth. 

#### Proverbs 17:25 {is anger to a father son A foolish}, and grief to the one birthing him. 

#### Proverbs 17:26 To penalize {man a just} is not good; nor is it sacred to plot against {monarchs just}. 

#### Proverbs 17:27 The one sparing {word to let go a hard} is an arbitrator; and a lenient man is intelligent. 

#### Proverbs 17:28 To an unthinking man asking, wisdom shall be imputed; {dumb man and any for himself doing} shall seem to be intelligent. 

#### Proverbs 18:1 {excuses seeks A man wanting to separate from friends}; {at all but} time he will be reviled. 

#### Proverbs 18:2 {no need has for wisdom One lacking of sense}; for rather he is led by folly. 

#### Proverbs 18:3 Whenever {should come the impious} into a depth of evils, he pays no attention, and there comes upon him dishonor and scorn. 

#### Proverbs 18:4 {water is deep A word in the heart of a man}; and a river {jump up and a spring of life}. 

#### Proverbs 18:5 To admire the face of the impious is not good; nor is it sacred to turn aside the just in a judgment. 

#### Proverbs 18:6 Lips of a fool lead him into evils; and {mouth his bold death calls unto}. 

#### Proverbs 18:7 The mouth of a fool is destruction to him; and his lips are a snare for his soul. 

#### Proverbs 18:8 The lazy are thrown down by fear; and the souls of effeminate ones shall hunger. 

#### Proverbs 18:9 The one not repairing himself by his works is brother of the one laying himself waste. 

#### Proverbs 18:10 {is of great strength The name of the LORD}; {to it and running up the just are raised up high}. 

#### Proverbs 18:11 The substance of a rich man {city is a fortified}; and its glory {greatly overshadows}. 

#### Proverbs 18:12 Before destruction {is raised up high the heart of a man}, and before glory it is humbled. 

#### Proverbs 18:13 The one who answers a word before hearing the matter, {folly to him it is and scorn}. 

#### Proverbs 18:14 {the rage of a man calms attendant An intelligent}; but a faint hearted man, who can endure. 

#### Proverbs 18:15 The heart of an intelligent man acquires perception; and ears of the wise seek insight. 

#### Proverbs 18:16 A gift of a man widens him; and {by monarchs sits him}. 

#### Proverbs 18:17 A just man, {of himself is an accuser} at the beginning of speaking; but when ever {demands attention the opponent} he is reproved. 

#### Proverbs 18:18 {disputes ceases The lot}, and among the monarchs it defines the bounds. 

#### Proverbs 18:19 A brother {by a brother being helped} is as {city fortified and a high}; and is strong as a well founded palace. 

#### Proverbs 18:20 From fruits of the mouth a man fills his belly; and from fruits of his lips he shall be filled up. 

#### Proverbs 18:21 Death and life are in the handle of the tongue; and the ones holding it shall eat of its fruits. 

#### Proverbs 18:22 The one who found {wife a good}, found favors; and he received {from the LORD happiness}. The one who casts out {woman a good}, casts out good things; but the one holding on to an adulteress is foolish and impious. 

#### Proverbs 18:23 {of supplications utter sounds The needy}; but the rich man responds harsh. 

#### Proverbs 18:24 A man having friends is for friendship; and there is a friend cleaving to over a brother. 

#### Proverbs 19:1 Better is one poor going in his simplicity, than one crooked of his lips, and he is unthinking. 

#### Proverbs 19:2 And even {without higher knowledge a soul} is not good; and the one hastening with the feet sins. 

#### Proverbs 19:3 The folly of a man lays waste his ways; and {God he blames} in his heart. 

#### Proverbs 19:4 Riches add {friends many}; but the poor one {even by the that exists friend is forsaken}. 

#### Proverbs 19:5 {witness A lying not unpunished shall be}; and the one accusing unjustly shall not escape. 

#### Proverbs 19:6 Many attend to the persons of a king; but every evil man becomes scorn to men. 

#### Proverbs 19:7 Every one who {brother a poor detests} {also from friendship far will be}. {insight Good to the ones perceiving it approaches}; {man and an intelligent} will find it. The many doing evil perfect a work of evil; and the one who aggravates by words shall not be delivered. 

#### Proverbs 19:8 The one acquiring intelligence loves himself; and the one guarding intelligence shall find good. 

#### Proverbs 19:9 {witness A lying not unpunished shall be}; and who ever shall kindle evil shall perish by it. 

#### Proverbs 19:10 {is not advantageous to a fool Luxury}, nor is it seemly if a servant should begin {by insult to be in power}. 

#### Proverbs 19:11 A merciful man is lenient, and his boasting comes upon lawbreakers. 

#### Proverbs 19:12 {of a king The intimidation} is likened to {gnashing a lion's}; but as dew upon the grass so is his making one happy. 

#### Proverbs 19:13 {is shame to a father son A foolish}; and {are not pure vows paid out from the hire of a mistress}. 

#### Proverbs 19:14 A house and substance is portioned by fathers to children; but by the LORD {is accorded a wife} to a man. 

#### Proverbs 19:15 Dread holds down an effeminate man; and the soul of the idle hungers. 

#### Proverbs 19:16 The one who keeps the commandment gives heed to his own soul; but the one disdaining his own ways shall perish. 

#### Proverbs 19:17 {lends to God The one showing mercy on the poor}; and according to his gift he shall make recompense to him. 

#### Proverbs 19:18 Correct your son! for thus he will be confident; {to but insult do not lift up the soul}! 

#### Proverbs 19:19 An evil-minded man {much shall be penalized}; and if there should be injury, {even his life he shall add}. 

#### Proverbs 19:20 Hear, O son, the instruction of your father! that {wise you should become} unto your last days. 

#### Proverbs 19:21 Many devices are in the heart of a man; but the counsel of the LORD {into the eon abides}. 

#### Proverbs 19:22 {is a fruit to a man Charity}; but better a poor just man, than a rich liar. 

#### Proverbs 19:23 Fear of the LORD is life to a man; but the one without fear shall lodge in places where {is not overseen knowledge}. 

#### Proverbs 19:24 The man hiding {in his enfolded arm his hands unjust}, not even {to his mouth will he in any way bring them}. 

#### Proverbs 19:25 {of his mischievousness being whipped A fool more clever will be}; but if you should reprove {man an intelligent} he shall comprehend for good sense. 

#### Proverbs 19:26 The one dishonoring his father, and thrusting away his mother, {disgraced and reviled he will be}. 

#### Proverbs 19:27 A son ceasing to guard the instruction of a father shall meditate upon {sayings evil}. 

#### Proverbs 19:28 The one guaranteeing a loan {child of a foolish} insults the ordinance; and the mouth of the impious shall swallow down judgments. 

#### Proverbs 19:29 {are prepared for the unrestrained The whips}; and punishments in like manner for fools. 

#### Proverbs 20:1 Unrestrained wine and outrageous intoxication, and all being laid waste shall not be wise. 

#### Proverbs 20:2 {differs not The intimidation of a king} from the rage of a lion; and the one provoking him even is intermixing sins against his own soul. 

#### Proverbs 20:3 It is glory for man to turn from reviling; but every fool {in such matters is closely joined}. 

#### Proverbs 20:4 Berating a lazy one does not shame him, likewise also the one borrowing grain in harvest. 

#### Proverbs 20:5 {water is deep Counsel} for the heart of a man; {man and an intelligent} shall draw it out. 

#### Proverbs 20:6 A great man, and {is precious man a merciful}; {man but a trustworthy it is work to find}. 

#### Proverbs 20:7 The one who behaves unblemished in righteousness, {blessed his children shall leave}. 

#### Proverbs 20:8 Whenever {king a just} shall sit upon a throne, not {withstands before his eyes any evil}. 

#### Proverbs 20:9 Who shall boast {a pure to have} heart? or who shall speak openly to be clean from sins? 

#### Proverbs 20:10 An untrue weight, great and small, and {measures untrue double} are unclean before the LORD -- even both; even the one making them. 

#### Proverbs 20:11 {in his practices will be bound hand and foot The young man with a sacred man}, and {will be straight his way}. 

#### Proverbs 20:12 The ear hears, and the eye sees; {of the LORD are the works and both}. 

#### Proverbs 20:13 Do not love to speak ill! that you should not be lifted away; but open wide your eyes, and be filled up with bread loaves! 

#### Proverbs 20:14 Bad, bad says the one buying, but when he should depart then he shall boast. 

#### Proverbs 20:15 There is gold and multitude {stones of very costly}, and {vessel the valued} -- lips of understanding. 

#### Proverbs 20:16 Remove the garment of the one guaranteeing a loan for a stranger, and {for a strange woman take security from him}! 

#### Proverbs 20:17 {agreeable to man Bread of falsehood}, and thereupon {shall be filled up his mouth} of gravel. 

#### Proverbs 20:18 A device with counsel solidifies, and {with guidance let be war}! 

#### Proverbs 20:19 The one uncovering counsel in a sanhedrin goes double-tongued; and {with the one widening the things of his own be not mixed} lips! 

#### Proverbs 20:20 One speaking evil of father or mother, {shall be extinguished his torch}; and the pupils of his eyes shall see darkness. 

#### Proverbs 20:21 A portion being hastily gotten at first, in the finalities shall not be blessed. 

#### Proverbs 20:22 You should not say, I will pay back the enemy; but wait on the LORD that he should help you. 

#### Proverbs 20:23 {is an abomination to the LORD A double weight}; and {yoke balance scale a deceitful} is not good before him. 

#### Proverbs 20:24 {by the LORD are straightened The footsteps of a man}; but a mortal, how can he comprehend his ways? 

#### Proverbs 20:25 It is a snare to a man quickly {anything of his own to sanctify}; for after vowing it, changing of the mind happens. 

#### Proverbs 20:26 {is a winnower of the impious king A wise}; and he puts {to them the wheel}. 

#### Proverbs 20:27 The light of the LORD is the breath of men, which searches the storerooms of the bellies. 

#### Proverbs 20:28 Charity and truth are a guard to a king, and they will surround {in righteousness his throne}. 

#### Proverbs 20:29 An ornament to young men is wisdom; and the glory of older men is gray hair. 

#### Proverbs 20:30 Bruises and breaks meet with bad men; and calamities shall come to the storerooms of their bellies. 

#### Proverbs 21:1 As a rush of water, so is the heart of a king in the hand of God; where ever wishing he should nod, there he leans it. 

#### Proverbs 21:2 Every man appears {to himself just}; {straightens out but the heart the LORD}. 

#### Proverbs 21:3 To do just things and to be truthful are more pleasing to God rather, than a sacrifice of blood. 

#### Proverbs 21:4 A high-minded man {in his insolence is bold-hearted}; and the torch of the impious is sin. 

#### Proverbs 21:5 The thoughts of the vigorous are in plenty; and every one hastening is unto less. 

#### Proverbs 21:6 The one producing treasures {tongue by a lying} {vanity pursues}, and comes unto the snare of death. 

#### Proverbs 21:7 The ruin of the impious is welcomed as a guest; for they do not prefer to do the just things. 

#### Proverbs 21:8 To the crooked ones, {crooked ways sends God}; {are pure for and straight his works}. 

#### Proverbs 21:9 Better to live upon a corner of the housetop in the open air, than houses being whitewashed with injustice, and in {house a profane}. 

#### Proverbs 21:10 The soul of the impious desires evils; it shall not be shown mercy by anyone of men. 

#### Proverbs 21:11 With the penalizing of an unrestrained man, {more clever becomes the guileless man}; but by perceiving, a wise man will receive knowledge. 

#### Proverbs 21:12 {perceives A just man} the hearts of the impious; and he treats {as worthless the impious} in their evils. 

#### Proverbs 21:13 The one who shuts up his ears to not heed the weak, even himself shall call out, and there will not be one listening. 

#### Proverbs 21:14 {present A private} prostrates angers; {gifts but the one sparing rage shall raise up strong}. 

#### Proverbs 21:15 It is with gladness for the just to have equity; but a sacred man is unclean by evildoers. 

#### Proverbs 21:16 A man wandering from the way of righteousness {in the gathering of giants shall rest}. 

#### Proverbs 21:17 A man lacking, loves gladness, being fond of wine and oil in wealth; 

#### Proverbs 21:18 and the rubbish of the just is a lawless man, and for upright ones a lawbreaker. 

#### Proverbs 21:19 Better to live in the wilderness than with a wife being combative and talkative and prone to anger. 

#### Proverbs 21:20 {treasure A desirable} shall rest upon the mouth of the wise; but foolish men will swallow it. 

#### Proverbs 21:21 The way of righteousness and charity shall find life and glory. 

#### Proverbs 21:22 {cities fortified mounts against A wise man}, and demolishes the fortress upon which {relied upon the impious}. 

#### Proverbs 21:23 The one who guards his mouth and the tongue carefully keeps {from affliction his soul}. 

#### Proverbs 21:24 A bold and self-willed and ostentatious man {pestilent is called}; and the man who resents is a lawbreaker. 

#### Proverbs 21:25 Desires {the lazy kill}, {to not for resolve his hands} do anything. 

#### Proverbs 21:26 An impious man lusts {the whole day lusts evil}; but the just one desires mercy, and he pities unsparingly. 

#### Proverbs 21:27 Sacrifices of the impious are an abomination to the LORD; for even {unlawfully they bring them}. 

#### Proverbs 21:28 {witness A lying} shall perish; a man who is subject {guardedly will speak}. 

#### Proverbs 21:29 An impious man impudently stands in front; but the upright man himself perceives his ways. 

#### Proverbs 21:30 There is no wisdom, there is no courage, there is no counsel to the impious. 

#### Proverbs 21:31 A horse is prepared for a day of battle; {is by but the LORD help}. 

#### Proverbs 22:1 {is more preferred name A good} than {riches many}; {over and silver and gold favor good}. 

#### Proverbs 22:2 Rich and poor meet with one another; {both but the LORD made}. 

#### Proverbs 22:3 A clever man seeing the wicked {being punished forcefully} is himself corrected; but the fools passing by are penalized. 

#### Proverbs 22:4 {is the generation of wisdom The fear of the LORD}, and riches, and glory, and life. 

#### Proverbs 22:5 Thistles and snares are in {ways crooked}; but the one guarding his own soul is at a distance from them. 

#### Proverbs 22:6 Dedicate the child according to his way; and indeed if he should grow old, he will not depart from it. 

#### Proverbs 22:7 The rich {the poor shall control}, and servants {to their own masters will lend}. 

#### Proverbs 22:8 The one sowing heedlessly harvests bad things; and the calamity of his works he shall complete. {man A happy} and a giver God loves; and the folly of his works he shall end. 

#### Proverbs 22:9 The one showing mercy on the poor {himself nourishes}; for of his own bread loaves he gives to the poor. {victory and honor procures The one gifts giving}; however {the life it removes} of the ones possessing. 

#### Proverbs 22:10 Cast out from the sanhedrin the mischievous one! and {shall go out together with him altercation}. For whenever he sits in the sanhedrin {all he dishonors}. 

#### Proverbs 22:11 The LORD loves sacred hearts; {are acceptable and to him all unblemished ones} in their ways. {with his lips tends A king}. 

#### Proverbs 22:12 But the eyes of the LORD carefully keep good sense; but he treats as worthless the words of a lawbreaker. 

#### Proverbs 22:13 {makes an excuse and says The lazy one}, There is a lion in the streets, and in the squares are murderers. 

#### Proverbs 22:14 {cesspool is a deep The mouth of a lawbreaker}; and the one being detested by the LORD shall fall into it. 

#### Proverbs 22:15 Thoughtlessness lights up the heart of a young person; but the rod and instruction will drive it far from him. 

#### Proverbs 22:16 The one extorting the needy {many produces for himself evils}; and he gives to the rich to make it less. 

#### Proverbs 22:17 {to the words of the wise Set aside your ear}, and hear my words! and {your heart set} that you should know! 

#### Proverbs 22:18 for they are good, and if you put them in your heart, they shall gladden you at the same time upon your lips; 

#### Proverbs 22:19 that your {should be upon the LORD hope}, and he shall make known to you his way; 

#### Proverbs 22:20 but also you register them to yourself, even thrice for counsel and knowledge! 

#### Proverbs 22:21 I teach you then a true word, and knowledge good to hearken to; for you to answer words of truth to the ones propounding things to you. 

#### Proverbs 22:22 Do not repel the needy! {poor for he is}. And you shall not dishonor the weak at the gates; 

#### Proverbs 22:23 for the LORD will arbitrate his cause, and you shall rescue your {against reprisal soul}. 

#### Proverbs 22:24 Be not a companion to a man inclined to rage! and a friend prone to anger do not lodge with! 

#### Proverbs 22:25 lest at any time you should learn of his ways, and should receive nooses for your soul. 

#### Proverbs 22:26 Do not give yourself for surety! shaming the face, 

#### Proverbs 22:27 for if you should not have from any place to pay, they shall take the bedding under your sides. 

#### Proverbs 22:28 Do not remove {boundaries the everlasting}! which {set your fathers}. 

#### Proverbs 22:29 An observant man, and one sharp in his works {kings must stand beside}, and should not stand beside {men dull}. 

#### Proverbs 23:1 If you should sit to have supper at the table of a monarch, intelligibly comprehend the things being placed near you! 

#### Proverbs 23:2 And give attention to your hand! beholding that {for such things for you it is a must to make preparations}; but if you are insatiable, 

#### Proverbs 23:3 do not desire his food; for these have {life a false}. 

#### Proverbs 23:4 Do not reach forth, {needy being}, to the rich! but in your insight be at a distance! 

#### Proverbs 23:5 If you set your eye upon him, he shall not at all appear; for there are carefully prepared for him wings as of an eagle, and he returns to the house being set for him. 

#### Proverbs 23:6 Do not dine with {man a bewitching}, nor desire his foods; 

#### Proverbs 23:7 {in which manner for} as if any may swallow down a hair, thus he eats and drinks; nor {to yourself should you bring him}, nor you should eat your morsel with him, 

#### Proverbs 23:8 for he will vomit it, and lay waste {words your good}. 

#### Proverbs 23:9 {into the ears of a fool Do not speak}! lest at any time he sneer at discerning your words. 

#### Proverbs 23:10 You should not transpose {boundaries the everlasting}; and to the possession of orphans you should not enter to take; 

#### Proverbs 23:11 for the one ransoming them is the LORD; he is strong, and he arbitrates their case with you. 

#### Proverbs 23:12 Give {for instruction heart your}! and {your ears prepare} for words of good sense! 

#### Proverbs 23:13 You should not be at a distance {the simple to correct}; for if you strike him with a rod in no way should he die. 

#### Proverbs 23:14 Forasmuch as you struck him with a rod, then {his soul from death you rescued}. 

#### Proverbs 23:15 O son, if {wise you should make your heart}, you shall gladden also my heart; 

#### Proverbs 23:16 and {shall spend time the words of your lips} with my lips, if they should be straight. 

#### Proverbs 23:17 Let not {be jealous your heart} of sinners, but {in the fear of the LORD be} the whole day! 

#### Proverbs 23:18 For if you should give heed to these things there will be a progeny for you, and your hope will not leave. 

#### Proverbs 23:19 Hear, O son, and {wise be}, and straighten out the reflections of your heart! 

#### Proverbs 23:20 Do not be a winebibber, nor stretch out couplings, {of meats nor purchasings}! 

#### Proverbs 23:21 For every intoxicated one and whoremonger shall be poor; and {shall put on torn and ragged garments every sleepy one}. 

#### Proverbs 23:22 Hear, O son, the father engendering you, and do not disdain that {has grown old your mother}! 

#### Proverbs 23:23 {truth Acquire}! and you should not thrust away wisdom and instruction and understanding. 

#### Proverbs 23:24 {well nourishes father A just}; {by and son a wise is gladdened his soul}. 

#### Proverbs 23:25 Let your {be glad father and mother} over you, and let {rejoice the one who gave birth to you}! 

#### Proverbs 23:26 Give to me, O son, your heart, and let your eyes {my ways give heed to}! 

#### Proverbs 23:27 {a cask For having been drilled is a strange house}; and {well is narrow a strange}. 

#### Proverbs 23:28 For this one suddenly shall perish, and every lawbreaker shall be consumed. 

#### Proverbs 23:29 To whom is there woe? to whom a tumult? to whom litigations? to whom rancor and intrigue? to whom breaks without cause? to whom dark colored eyes? 

#### Proverbs 23:30 is it not the ones lingering in wines? is it not the ones prowling where parties happen? Do not be intoxicated by wine, but consort {men with just}, and consort in the promenades! 

#### Proverbs 23:31 For if in the bowls and the cups you should give your eyes, afterwards you shall walk more naked than a pestle. 

#### Proverbs 23:32 But at last it will be as if {by a serpent being struck} he stretches out, and as if by a horned serpent {diffuses throughout him the poison}. 

#### Proverbs 23:33 {eyes your Whenever} behold the strange woman, your mouth then speaks perverse things; 

#### Proverbs 23:34 and you shall recline as if in the heart of the sea; and as a navigator in a great swell; 

#### Proverbs 23:35 and you shall say, They beat me, and I did not have pain; and, They mocked me, but I did not know. When will it be dawn that coming I shall seek after one who shall go together with me to drink? 

#### Proverbs 24:1 O son, you should not be jealous of evil men, nor should you desire to be with them. 

#### Proverbs 24:2 {lying For meditates on their heart}, and {of miseries their lips speak}. 

#### Proverbs 24:3 {with wisdom is built A house}, and {with skillfulness is erected}. 

#### Proverbs 24:4 With good sense {are filled up the storerooms} of all {wealth valuable and good}. 

#### Proverbs 24:5 {is better A wise man} than a strong man; a man of intelligence than one having {farm a great}. 

#### Proverbs 24:6 {with guidance takes place War}, but help comes with the heart of a counselor. 

#### Proverbs 24:7 Wisdom and {insight good} are in the gates of the wise. The wise do not turn aside from the law of the LORD, but consider things in the sanhedrins; but the uninstructed ones meet with death, 

#### Proverbs 24:9 {dies but the fool} in sins. Uncleanness {man to a pestilent} -- 

#### Proverbs 24:10 he shall be contaminated in {day the evil}, and in the day of affliction, until whenever he should cease. 

#### Proverbs 24:11 Rescue the ones being led unto death, and buy off the ones for slaying! You should not spare. 

#### Proverbs 24:12 But if you should say, I do not know this; know that the LORD {the heart of all knows}; even the one shaping the breath in all, he knows all things. He is the one who renders to each according to his works. 

#### Proverbs 24:13 Eat honey, O son, {is good for the honeycomb}! that {should be sweetened your throat}. 

#### Proverbs 24:14 For thus you shall perceive wisdom in your soul; for if you should find it, {will be good your decease}, and hope {you shall not forsake}. 

#### Proverbs 24:15 You should not lead the impious to the pasture of the just; nor should you be deceived in filling the belly. 

#### Proverbs 24:16 For seven times {shall fall the just}, and rise up; but the impious will weaken in evils. 

#### Proverbs 24:17 If {should fall your enemy}, you should not rejoice over him; and in his fall be not lifted up! 

#### Proverbs 24:18 For the LORD shall see it, and it will not please him; and he will return his rage upon him. 

#### Proverbs 24:19 Do not rejoice over ones doing evil, nor be jealous of sinners! 

#### Proverbs 24:20 For in no way shall there be a progeny of wicked ones; and the torch of the impious shall be extinguished. 

#### Proverbs 24:21 Fear God, O son, and the king! and to neither one of them should you resist persuasion. 

#### Proverbs 24:22 For suddenly they will pay the impious; and the punishment of both, who shall know? 

#### Proverbs 24:23 But these things I say to you, to the wise, to realize that to stand in awe of a person in a judgment is not good. 

#### Proverbs 24:24 The one having said, The impious is just, {accursed among the peoples will be}, and detested among the nations. 

#### Proverbs 24:25 But the ones reproving {the best shall appear}, {upon them and shall come blessing a good}; 

#### Proverbs 24:26 but lips shall kiss the ones answering {words with good}. 

#### Proverbs 24:27 Prepare {for the departure your works}, and make preparations for the field, and go after me! and you shall rebuild your house. 

#### Proverbs 24:28 Do not be a lying witness against your fellow-countryman, nor open wide with your lips! 

#### Proverbs 24:29 You should not say, In which manner he treated me, I shall treat him; and I shall pay him who wronged me. 

#### Proverbs 24:30 {is as a farm man A foolish}, and {is as a vineyard a man lacking of sense}; 

#### Proverbs 24:31 if you should let it go barren, then it shall become {overgrown entirely}; and {takes place failing}; and {fences of stones his} shall be razed. 

#### Proverbs 24:32 Afterwards I changed my mind; I looked to choose instruction. 

#### Proverbs 24:33 {a little I slumber}; {a little and I sleep soundly}, {a little and I fold my hands to my breasts}. 

#### Proverbs 24:34 But if you should do this, {shall come before poverty} you, and lack as a good runner. 

#### Proverbs 25:1 These are the {parables of Solomon impartial}, which {wrote out the friends of Hezekiah the king of Judea}. 

#### Proverbs 25:2 The glory of God hides a matter; but the glory of a king esteems things. 

#### Proverbs 25:3 Heaven is high, and the earth is deep; but the heart of a king is unascertained. 

#### Proverbs 25:4 Beat unproven silver! and it shall be cleansed clean all together. 

#### Proverbs 25:5 Slay the impious from the presence of the king! and you shall set up {in righteousness his throne}. 

#### Proverbs 25:6 Do not act ostentatiously in the presence of the king, nor {in places of mighty ones stand}! 

#### Proverbs 25:7 For better the saying to you, Ascend to me! than to humble you in the presence of a mighty one. What you beheld with your eyes, speak! 

#### Proverbs 25:8 Do not fall into a fight quickly! lest you should change your mind at the last. When ever {should berate you a friend}, 

#### Proverbs 25:9 withdraw to the rear, do not disdain him! 

#### Proverbs 25:10 lest {should berate you indeed the friend}; and your fight and hatred do not go away, but will be to you equal of death! Favor and friendship frees, which you give heed to yourself! that {not reviled you should be}. But keep your ways conciliatory! 

#### Proverbs 25:11 {apple As a golden} in a pendant of sardius, so is it to speak a wise word. 

#### Proverbs 25:12 In an ear-ring of gold {sardius a very costly} is bound; so a {word wise} to a heedful ear. 

#### Proverbs 25:13 As a delivery of snow in the harvest for sweltering heat, {benefits so messenger a trustworthy} the ones sending him; for the souls of the ones dealing with him derive benefit. 

#### Proverbs 25:14 As winds, and clouds, and rains are apparent, so the men boasting over {portions false}. 

#### Proverbs 25:15 {by long-suffering Success comes to kings}; {tongue and a soft} breaks the bones. 

#### Proverbs 25:16 {honey In finding}, eat what is enough! lest at any time being overfilled, you should vomit forth. 

#### Proverbs 25:17 Sparingly bring your foot to your own friend! lest at any time he be filled of you, and should detest you. 

#### Proverbs 25:18 As a club, and a sword, and {bow a pointed}, so also the man bearing {friend against his witness false}. 

#### Proverbs 25:19 {way An evil} and the foot of a lawbreaker shall be destroyed in {day an evil}. 

#### Proverbs 25:20 As vinegar draws hurtful; so {falling passion} on a body {the heart distresses}. As a moth in a garment, and a worm in wood, so distress of a man hurts the heart. 

#### Proverbs 25:21 If {hungers enemy your} nourish him, if he thirsts give him to drink! 

#### Proverbs 25:22 {this For doing coals of fire you shall heap} upon his head; and the LORD will recompense to you good things. 

#### Proverbs 25:23 {wind The north} arouses clouds, and the face of an impudent tongue aggravates. 

#### Proverbs 25:24 Better to live upon the corner of a roof, than with {wife a reviling} in {house a common}. 

#### Proverbs 25:25 As {water cold soul to a thirsting is kind}, so {message a good} from a land far off. 

#### Proverbs 25:26 As if any one {a spring may shut up}, and {of water an exiting lay waste}; so it is unbecoming for a just man to fall before the impious. 

#### Proverbs 25:27 To eat {honey much} is not good; {to esteem but it behooves words honorable}. 

#### Proverbs 25:28 As a city with walls having been thrown down and unwalled, so a man who {with no counsel in anything acts}. 

#### Proverbs 26:1 As dew in harvest, and as rain in summer, so {not is seemly for a fool honor}. 

#### Proverbs 26:2 As birds {spread out to fly and sparrows}, so {oath a vain} shall not come unto one thing. 

#### Proverbs 26:3 As a whip to a horse, and a spur to a donkey, so a rod {nation to a lawbreaking}. 

#### Proverbs 26:4 Do not give an answer to a fool according to that one's folly, lest {likened you should become} to him! 

#### Proverbs 26:5 But answer a fool to the folly of that one! lest he should appear wise of himself. 

#### Proverbs 26:6 {by his own ways scorn shall cause The one sending through messenger a foolish a word}. 

#### Proverbs 26:7 Remove the goings of legs, and proverbs from out of the mouth of fools. 

#### Proverbs 26:8 The one who binds up a stone in a sling, is likened to the one giving a fool glory. 

#### Proverbs 26:9 Thorn-bushes germinate in the hand of the intoxicated; and servitude in the hand of fools. 

#### Proverbs 26:10 {much is tossed by a storm All the flesh of fools}; {is destroyed for their ecstasy}. 

#### Proverbs 26:11 As a dog whenever it comes upon its own vomit, and {detested becomes}; so a fool {to his own evil returning}, unto his own sin. 

#### Proverbs 26:12 I beheld a man seeming {of himself wise to be}, {more hope however had rather than a fool} he. 

#### Proverbs 26:13 {says The lazy one} when being sent into the way, A lion is in the ways, and in the squares are murderers. 

#### Proverbs 26:14 As a door turns upon the hinge, so the lazy one upon his bed. 

#### Proverbs 26:15 {hiding The lazy one} the hand in his bosom shall not be able to bring it unto the mouth. 

#### Proverbs 26:16 {wiser to himself The lazy one appears} in fulfilling transmitting a message. 

#### Proverbs 26:17 As the one holding the tail of a dog; so the one setting himself over a stranger's case. 

#### Proverbs 26:18 As the ones needing healing propounds words unto men, and the {one meeting the word first} shall be tripped up. 

#### Proverbs 26:19 Thus are all the ones lying in wait for their own friends; and whenever they should be caught in the act, they say that, In playing I acted. 

#### Proverbs 26:20 With much wood {flourishes fire}; but where there is no man at variance with others {is stilled a fight}. 

#### Proverbs 26:21 A grate for coals, and wood for a fire; {man and a reviling} for a disturbance to a fight. 

#### Proverbs 26:22 Words of mischievous men are soft; but these beat into the inner chambers of the intestines. 

#### Proverbs 26:23 Silver given with treachery, is as a potsherd esteemed. {lips Smooth heart cover a distressed}. 

#### Proverbs 26:24 {with his lips all things assents to weeping An enemy}; but in the heart he contrives treachery. 

#### Proverbs 26:25 If {should beseech you the enemy} with a great voice, do not yield to him; {seven for there are} wickednesses in his heart. 

#### Proverbs 26:26 The one hiding hatred stands together with treachery, and he conceals the things of his own {sins well-known} in the sanhedrin. 

#### Proverbs 26:27 The one digging a pit for his neighbor shall fall into it; and the one rolling a stone, {upon himself rolls it}. 

#### Proverbs 26:28 {tongue A lying} detests truth; {mouth and an open-mouthed} makes commotion. 

#### Proverbs 27:1 Do not boast concerning the things for tomorrow! for you do not know what {shall give birth the coming day}. 

#### Proverbs 27:2 Let {laud you the one near}! and not your mouth; a stranger, and not your lips. 

#### Proverbs 27:3 {is heavy A stone}, and {hard to bear sand}; but the anger of a fool is heavier than both. 

#### Proverbs 27:4 {is unmerciful Rage}, and {is sharp anger}, but no one stands before jealousy. 

#### Proverbs 27:5 {is better than reproofs Revealing} hiding friendship. 

#### Proverbs 27:6 More worthy of trust are wounds of a friend, than voluntary kisses of an enemy. 

#### Proverbs 27:7 A soul {in fullness being honeycombs mocks}; but to a soul lacking, even the bitter things {sweet appear}. 

#### Proverbs 27:8 As a bird whenever it flies down from out of its own nest; so a man is enslaved whenever he estranges himself from out of his own places. 

#### Proverbs 27:9 Perfumes, and wines, and incenses make {happy the heart}; {breaks down but by adverse incidents the soul}. 

#### Proverbs 27:10 {friend Your} or {friend paternal} you should not abandon; but to the house of your brother you should not enter in adversity; better a friend near, than a brother {far living}. 

#### Proverbs 27:11 {wise Become}, O son! that {should gladden me the heart}. And turn {from you reviling words}! 

#### Proverbs 27:12 A clever man, of evils coming along, conceals himself; but fools coming along, {a penalty shall pay}. 

#### Proverbs 27:13 Remove his garment! {passed by for an insulting man}, the one who {a stranger's goods lays waste}. 

#### Proverbs 27:14 Who ever shall bless a friend in the morning with a great voice, {from one cursing shall not to differ seem}. 

#### Proverbs 27:15 Drops of rain {shall cast a man on a day of winter} from out of his house; likewise also {wife a reviling} drives a man from out of his own house. 

#### Proverbs 27:16 The north {is hard wind}, {by name but fittingly is called}. 

#### Proverbs 27:17 Iron {iron sharpens}; and a man sharpens the face of his companion. 

#### Proverbs 27:18 The one who plants a fig-tree shall eat the fruits of it; and the one who guards his own master shall be esteemed. 

#### Proverbs 27:19 As {are not likened faces} to other faces, so not even are the hearts {to other men's likened}. 

#### Proverbs 27:20 Hades and destruction are not filled up; likewise also the eyes of the {man insatiable}. {is an abomination to the LORD One fixing the eye}, and the uninstructed ones are immoderate in tongue. 

#### Proverbs 27:21 Proving silver and gold is through burning by fire; but a man is tried by the mouth of ones lauding him. 

#### Proverbs 27:22 If you whip a fool in the midst of a sanhedrin, dishonoring him, in no way shall {be removed his folly}. 

#### Proverbs 27:23 Knowingly, you shall recognize things concerning the lives of your flock, and you shall set {over your heart} your herds. 

#### Proverbs 27:24 For {are not into the eon to a man might and strength}; nor does he deliver it up from generation to generation. 

#### Proverbs 27:25 Care for the {in the field green things}! and you shall shear the herbage; and gather together grass of the mountainous area! 

#### Proverbs 27:26 that you should have sheep's wool for clothes. Esteem the field! that there might be lambs for you. 

#### Proverbs 27:27 O son, {from me you have sayings strong} for your life, and for the life of your attendants. 

#### Proverbs 28:1 {flees An impious man} with no one pursuing; but the just man {as a lion is secure}. 

#### Proverbs 28:2 Because of the sins of the impious, litigations arise; {man but a clever} extinguishes them. 

#### Proverbs 28:3 A vigorous man with impious deeds extorts the poor as {rain a fierce and unprofitable}. 

#### Proverbs 28:4 Thus the ones abandoning the law laud impiety; but the ones loving the law put {around themselves a wall}. 

#### Proverbs 28:5 {men Evil} do not comprehend equity; but the ones seeking the LORD perceive in all. 

#### Proverbs 28:6 Better a poor man going in truth, than a rich liar. 

#### Proverbs 28:7 {keeps the law son A discerning}; but the one who tends carnality dishonors his father. 

#### Proverbs 28:8 The one multiplying his wealth with interest and usury, {for one showing mercy on the poor gathers it}. 

#### Proverbs 28:9 The one turning aside his ear to not hear the law, even he {his own prayer abhors}. 

#### Proverbs 28:10 The one who wanders upright men in {way an evil}, {into corruption himself shall fall}; and the lawless ones shall go through good things, and they shall not enter to them. 

#### Proverbs 28:11 {is wise to himself man A rich}; {needy man but an intelligent} shall condemn him. 

#### Proverbs 28:12 Through the help of the just ones much {comes to pass glory}; but in the places of the impious {are being captured men}. 

#### Proverbs 28:13 The one covering over his impiety, {not his way shall} be prospered; but the one describing and reproving shall be loved. 

#### Proverbs 28:14 Blessed is a man who is struck with awe of all things through veneration; but the hard of heart shall fall into evils. 

#### Proverbs 28:15 A lion hungering, and a wolf thirsting is the one who is sovereign {poor being nation of a destitute}. 

#### Proverbs 28:16 A king lacking revenue is a great extortioner; but the one detesting injustice {a long time shall live}. 

#### Proverbs 28:17 {of a man under accusation of murder The one guaranteeing a loan an exile will be}, and not in safety. 

#### Proverbs 28:18 The one going justly is helped; but the one {crooked ways going by} shall be entangled. 

#### Proverbs 28:19 The one working his own land shall be filled with bread loaves; but the one pursuing ease shall be filled with poverty. 

#### Proverbs 28:20 A man worthy of trust in many things shall be blessed; but the evil one shall not be unpunished. 

#### Proverbs 28:21 The one who does not feel respect for persons of the just, is not good; such a one {for a morsel of bread will deliver over a man}. 

#### Proverbs 28:22 {hastens to be rich man A bewitching}, and does not know that a merciful man will prevail over him. 

#### Proverbs 28:23 The one reproving a man's ways {favors shall have}, rather than the flatterer with the tongue. 

#### Proverbs 28:24 The one who throws off his father or mother, and assumes he does not sin; this one is partner {man of an impious}. 

#### Proverbs 28:25 An insatiable man judges in vain; but the one yielding upon the LORD {in care will be}. 

#### Proverbs 28:26 The one who yields to a rash heart, such a one is a fool; but the one who goes in wisdom shall be delivered. 

#### Proverbs 28:27 The one who gives to the poor shall not be in want; but the one who turns his eye {in much perplexity will be}. 

#### Proverbs 28:28 In the places of the impious {moan the just}; but in the destruction of those {shall be multiplied the just}. 

#### Proverbs 29:1 Better a man of reproofs, than a man hard-necked; for suddenly {blazing up for him there is no healing}. 

#### Proverbs 29:2 In the lauding of the just {will be glad peoples}; {the rule but of the impious moan over men}. 

#### Proverbs 29:3 A man fond of wisdom gladdens his father; but the one tending harlots destroys wealth. 

#### Proverbs 29:4 {king A just} establishes regions; {man but a lawbreaking} razes them. 

#### Proverbs 29:5 The one who makes preparations {against the person of his own friend with a net} puts it around his own feet. 

#### Proverbs 29:6 {sinning against a man A great snare is set}; but the just {in joy and in gladness will be}. 

#### Proverbs 29:7 {has knowledge A just man} to judge for the destitute; but the impious do not comprehend knowledge; and to the poor there does not exist the mind of an arbitrator. 

#### Proverbs 29:8 {men Mischievous} burn away a city; but wise men turn away anger. 

#### Proverbs 29:9 {man A wise} judges nations; {man but a heedless}, in provoking to anger, ridicules and is not struck with awe. 

#### Proverbs 29:10 Men {in blood being partners} shall detest the sacred; but the upright will seek after his soul. 

#### Proverbs 29:11 {entire rage his brings forth The fool}; but the wise stores his up in part. 

#### Proverbs 29:12 A king hearkening {matter in an unjust} makes all the ones under him lawbreakers. 

#### Proverbs 29:13 A money-lender and debtor, when one another come together {to oversee commits both the LORD}. 

#### Proverbs 29:14 A king {in truth judging the poor}, his throne {for a good testimony shall be established}. 

#### Proverbs 29:15 Strokes and reproofs give wisdom; but a child wandering shames his parents. 

#### Proverbs 29:16 {of many With the being} impious, many {take place sins}; but with the just, at the falling of those, fear takes place. 

#### Proverbs 29:17 Correct your son, and he will cause you rest, and he will give a decoration to your soul. 

#### Proverbs 29:18 In no way should there exist an expositor {nation to a lawbreaking}; but the one keeping the law is most blessed. 

#### Proverbs 29:19 {by words will not be corrected domestic servant A recalcitrant}; for even if he comprehends he will not obey. 

#### Proverbs 29:20 If you should behold a man hasty in words, know that {hope has rather than the fool} he! 

#### Proverbs 29:21 The one who lives wastefully from child hood will be a domestic servant; and at the end will grieve over himself. 

#### Proverbs 29:22 A man inclined to rage digs up altercation; and a man prone to anger gouges up sin. 

#### Proverbs 29:23 Insolence {a man abases}; but the {the humble-minded establishes in glory LORD}. 

#### Proverbs 29:24 The one who shares with a thief detests his own soul. And if an oath having been set before ones hearing, but they should not announce it, 

#### Proverbs 29:25 they, fearing and shaming men, shall be tripped up; but the one yielding upon the LORD shall be glad. Impiety in man makes a man trip; but the one yielding unto the master shall be preserved. 

#### Proverbs 29:26 Many attend to the persons of leaders; but by the LORD {happens justice} to a man. 

#### Proverbs 29:27 {is an abomination A just man man to an unjust}; and an abomination to the lawless one is a straight way. 

#### Proverbs 30:1 Thus speaks the man to the ones trusting in God. And now I will cease. 

#### Proverbs 30:2 {most foolish For I am all together} of men, and the intelligence of man is not in me. 

#### Proverbs 30:3 God has taught me wisdom, and {the knowledge of the holies I know}. 

#### Proverbs 30:4 Who ascended into the heaven, and came down? Who brought together the winds in his bosom? Who bundled up waters in his cloak? Who holds all the extremities of the earth? What name is given to him? or what name to his children that you should know? 

#### Proverbs 30:5 For all the words of God are purified. {shields And he himself} the ones venerating him. 

#### Proverbs 30:6 You should not add to his words, lest he reprove you, and {a liar you should become}. 

#### Proverbs 30:7 Two things I ask from you; you should not remove {from me favor} before my dying; 

#### Proverbs 30:8 {the vain word and false far from me appoint}; and riches and poverty you should not give to me; but order up for me the things necessary and the things to be self-sufficient; 

#### Proverbs 30:9 that {not in being filled up false I should become}, and should say, Who sees me? Or to be in need that I shall steal, and I shall swear an oath by the name of God. 

#### Proverbs 30:10 You should not deliver a bondservant into the hands of a master, lest at any time he should curse you, and you should be obliterated. 

#### Proverbs 30:11 {progeny A bad a father curses}, {the and mother he does not bless}. 

#### Proverbs 30:12 {progeny A bad as just himself judges}, and {his going out not washes}. 

#### Proverbs 30:13 {progeny A bad lofty eyes has}, and with his eyelids he lifts himself up. 

#### Proverbs 30:14 {progeny A bad swords for teeth has}, and the molars as pruning knives, so as to consume the weak from the earth, and the needy of them from among men. 

#### Proverbs 30:15 {to the leech three daughters There were in affection being loved}, these three did not fulfill her, and to the fourth it was not sufficient to say, Enough -- 

#### Proverbs 30:16 Hades, and passion of a woman, and earth not filled with water; and water and fire in no way shall say, It sufficies. 

#### Proverbs 30:17 The eye ridiculing a father, and dishonoring the old age of a mother -- {cut it out let the crows from the ravines}, and may {devour it the young of the eagles}. 

#### Proverbs 30:18 {three things And there are} impossible for me to comprehend, and the fourth I do not know -- 

#### Proverbs 30:19 the traces {eagle of a flying}, and the ways of a serpent upon a rock, and the paths of a ship passing through the sea, and the ways of a man in youth. 

#### Proverbs 30:20 Such is the way {woman of an adulterous}, whenever she should act in washing herself, {not she says} to have acted out of place. 

#### Proverbs 30:21 By three things {is shaken the earth}, and the fourth it is not able to bear -- 

#### Proverbs 30:22 if a domestic servant should reign, and a fool should be filled with food, 

#### Proverbs 30:23 and a female domestic servant, if she is cast out by her own lady, and a hateful wife if she should attain {man a good}. 

#### Proverbs 30:24 {four And there are} lesser things upon the earth, and these are wiser than the wise -- 

#### Proverbs 30:25 the ants in whom there is no strength, and they prepare {in summer nourishment}. 

#### Proverbs 30:26 And the rabbits -- a nation not being strong, the ones making {in the rocks their own houses}. 

#### Proverbs 30:27 {independent is The locust}, but she marches {from one word of command orderly}. 

#### Proverbs 30:28 And the newt, with its hands sticking, and {easily caught being}, it dwells in the fortresses of kings. 

#### Proverbs 30:29 {three And there are} which {prosperously go}, and the fourth which {well passes over} -- 

#### Proverbs 30:30 {cub a lion} is stronger than the beasts, which does not turn away, nor is struck with awe of any beast, 

#### Proverbs 30:31 and a rooster walking about among females confidently, and a he-goat taking the lead of a flock of goats, and a king delivering a public address to a nation. 

#### Proverbs 30:32 If you should let go of yourself in gladness, and should stretch out your hand for a fight you shall be dishonored. 

#### Proverbs 30:33 Extract milk, and there will be butter; but if you should pressure the nostrils there shall come forth blood; and if you should drag out words, there shall come forth litigations and fights. 

#### Proverbs 31:1 My words have been spoken by God; {by a king the divine answer}, whom {instructed his mother}. 

#### Proverbs 31:2 What, O child, will you give heed to? What sayings of God, O first-born, to you I speak, O son? What, O child of my belly? What, O child of my vows? 

#### Proverbs 31:3 You should not give {to women your wealth}, nor your mind and livelihood for an afterthought. {with counsel all things Do}! {with counsel Drink wine}! 

#### Proverbs 31:4 The mighty ones are inclined to rage; {wine let them not drink}! 

#### Proverbs 31:5 lest drinking they should forget wisdom, and {rightly to judge in no way are able} the weak. 

#### Proverbs 31:6 Give intoxicating drink to the ones in distresses, and wine to drink to the ones in griefs! 

#### Proverbs 31:7 that they should forget their poverty, and their miseries should not be remembered any longer. 

#### Proverbs 31:8 O Son, open your mouth with the word of God, and judge all fairly! 

#### Proverbs 31:9 Open your mouth, and judge justly, and litigate for the needy and weak! 

#### Proverbs 31:10 {wife a vigorous Who shall find}? {more esteemed than For is stones very costly such}. 

#### Proverbs 31:11 {takes courage over her The heart of her husband}. Such a one {of good spoils will not be distressed by the lack}. 

#### Proverbs 31:12 For she exacts energy to her husband for good, and not bad for all the livelihood. 

#### Proverbs 31:13 {furling wool and flax She makes useful her hands}. 

#### Proverbs 31:14 She became as a ship trading far off. She gathers together her wealth, 

#### Proverbs 31:15 and she rises up at nights, and appoints foods to the household, and works to the female attendants. 

#### Proverbs 31:16 In viewing a farm, she buys; and from the fruits of her hands she plants a possession. 

#### Proverbs 31:17 Girding up {strongly her loin}, she establishes her arms for work. 

#### Proverbs 31:18 She tastes that it is good to work; and {is not extinguished her lamp} all the night. 

#### Proverbs 31:19 {her cubits She stretches out} unto the things being advantageous; and the things of her hands she sticks to the spindle. 

#### Proverbs 31:20 {hands And her she opens wide} to the needy, and her wrist she stretches out to the poor. 

#### Proverbs 31:21 {does not take thought of the things in the house Her husband} whenever {somewhere he passes time}; for all the ones of hers are being clothed. 

#### Proverbs 31:22 A double goat's hair coat she made for her husband; and from out of linen and purple material garments for herself. 

#### Proverbs 31:23 {admired And is her husband} at the gate when ever he should sit in the sanhedrin with the aged of the land. 

#### Proverbs 31:24 {fine linen She makes}, and gives back loincloths to the Canaanites. 

#### Proverbs 31:25 {strength and beauty She puts on}, and is glad in {days the last}. 

#### Proverbs 31:26 {mouth And of her} she opens wisely and lawfully; and her charity is in her tongue. 

#### Proverbs 31:27 {are roofed The pastimes to her house}, and the grain of laziness she does not eat. 

#### Proverbs 31:28 She raises up her children, and they grow rich; and her husband praises her. 

#### Proverbs 31:29 Many daughters acquired riches; many acted with ability; but you have precedence -- you are elevated above all. 

#### Proverbs 31:30 {is false Allurement}, and {vain beauty} it is not in you. {woman For a discerning} is blessed; {the fear and of the LORD let her praise}! 

#### Proverbs 31:31 Give to her from the fruits of her lips! and let {be praised at the gates her husband}!